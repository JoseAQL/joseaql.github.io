# Amplificador de audio discreto de 3 etapas — LTspice

**Autor:** José Antonio Quiroz Luna · Ingeniería Electrónica, UAA

Amplificador clase AB totalmente con transistores, alimentado con **12 V**, para una bocina de **8 Ω**.

| Parámetro (simulado) | Valor |
|---|---|
| Ganancia de voltaje @ 1 kHz | ≈ 19 V/V (25.6 dB) |
| Ancho de banda (−3 dB) | ≈ 28 Hz – 265 kHz |
| Potencia con THD < 1 % | ≈ 0.25 W |
| Potencia con THD ≈ 2 % | ≈ 0.85 – 1 W |
| Potencia máxima (recortando, THD > 5 %) | ≈ 1.2 – 1.3 W |
| Corriente de reposo total | ≈ 43 mA (≈ 30 mA en la salida) |
| Punto medio de salida V(OUT) | ≈ 6.0 V |

---

## Contenido del zip

| Archivo | Para qué sirve |
|---|---|
| `Amplificador_3_Etapas.asc` | Esquemático principal, simulación **transitoria** con medición de ganancia, potencia y THD (`.four`) |
| `Amplificador_3_Etapas_AC.asc` | El mismo circuito con simulación **AC** (diagrama de Bode y ancho de banda) |
| `modelos.lib` | Modelos SPICE de 2N3904, TIP41C, TIP42C y 1N4148 (va junto a los .asc) |
| `Amplificador_3_Etapas.cir` | Netlist equivalente (sirve para ngspice o para revisar las conexiones) |
| `graficas/` | Resultados de la simulación: transitorio, Bode y THD vs potencia |

> **Importante:** deja los archivos juntos en la misma carpeta. Los .asc buscan `modelos.lib` ahí mismo.

## Cómo usarlo en LTspice

1. Descomprime el zip y abre `Amplificador_3_Etapas.asc`.
2. Dale **Run** (el monito corriendo).
3. Haz clic en las etiquetas `IN` y `SPK` para ver entrada y salida.
4. Para ver las mediciones (ganancia, potencia, THD): **View → SPICE Error Log** (Ctrl+L).
5. Para la respuesta en frecuencia, abre `Amplificador_3_Etapas_AC.asc` y grafica `V(spk)`.

Las conexiones del esquemático están hechas con **etiquetas de red** (net labels): todo pin con el mismo nombre está conectado. Si quieres comprobarlo: **View → SPICE Netlist**.

### Experimentos para hacerlo más interesante
- **Potencia máxima:** cambia `.param va=50m` a `va=200m` (200 mV pico) y vuelve a correr.
- **Barrido de volumen:** quita el `;` de la línea `.step param va list ...` para ver varias amplitudes juntas.
- **Distorsión de cruce:** cambia `RV1` a `100` y verás la "muesca" en el cruce por cero de la señal.
- **Sin bootstrap:** borra `CB` y verás cómo baja la potencia máxima.

---

## Cómo funciona cada etapa

```
IN → [1. Preamp EC] → [2. Driver / VAS] → [3. Push-pull AB] → C. salida → Bocina 8 Ω
                              ↑_______ realimentación RF ________|
```

### Etapa 1 — Preamplificador en emisor común (Q1, 2N3904)
- Divisor: R1 = 47 k, R2 = 10 k → V_B ≈ 12·10/57 ≈ **2.1 V** (simulado 2.04 V)
- V_E ≈ 2.1 − 0.7 = **1.4 V** → I_C ≈ 1.4 V / (220 + 1 k) ≈ **1.15 mA**
- V_C = 12 − 1.15 mA·4.7 k ≈ **6.7 V** (centrado, máxima excursión)
- r_e = 26 mV / 1.15 mA ≈ 22.6 Ω
- **A_v1 ≈ −R_C / (r_e + R_E1) = −4.7 k / 243 ≈ −19**
- RE2 (1 k) está desacoplada con CE1 (100 µF): fija la polarización sin bajar la ganancia de AC. RE1 (220 Ω) se queda sin desacoplar para estabilizar la ganancia y bajar la distorsión.

### Etapa 2 — Driver / VAS (Q2, 2N3904)
- Es el que da la "ganancia de voltaje grande". Trabaja con I_C ≈ 10 mA.
- **RF (5.1 k) + RB2 (2.2 k)** forman una realimentación negativa desde la salida:
  - en DC fija el punto medio: V(OUT) ≈ V_B2·(1 + RF/RB2) ≈ **6 V = Vcc/2**
  - en AC baja la distorsión y hace que la ganancia total dependa de resistencias, no del β.
- **CC = 100 pF** (compensación Miller): evita oscilaciones en alta frecuencia.

### Bootstrap (RC2A, RC2B, CB)
La carga de colector del driver está partida en dos resistencias de 270 Ω y el punto medio se conecta a la salida con **CB = 220 µF**. Cuando la salida sube, el capacitor "jala" ese punto hacia arriba, así la corriente hacia la base de Q3 se mantiene constante. Resultado: la señal puede subir casi hasta Vcc → **más potencia**.

### Multiplicador de V_BE (Q5 + RV1 + RV2)
Reemplaza a los dos diodos clásicos. Genera
**V_bias ≈ V_BE·(1 + RV1/RV2)** ≈ 1.2 V entre las bases de Q3 y Q4.
- Con RV1 ajustas la corriente de reposo de la salida (≈ 30 mA) → elimina la **distorsión de cruce**.
- En la placa real, monta Q5 pegado al disipador de los TIP: si se calientan, baja V_BE y se compensa sola (evita el *thermal runaway*).

### Etapa 3 — Push-pull clase AB (Q3 TIP41C / Q4 TIP42C)
- Seguidores de emisor complementarios: ganancia ≈ 1, pero dan la **corriente** que necesita la bocina.
- RE4 y RE5 (0.47 Ω) estabilizan la corriente de reposo.
- CO = 2200 µF bloquea los 6 V de DC para que no lleguen a la bocina. Con 8 Ω, f_c = 1/(2π·8·2200 µF) ≈ 9 Hz.

---

## Lista de materiales (BOM)

| Ref. | Valor | Nota |
|---|---|---|
| Q1, Q2, Q5 | 2N3904 | Q5 pegado al disipador |
| Q3 | TIP41C | Con disipador + mica aislante |
| Q4 | TIP42C | Con disipador + mica aislante |
| R1 | 47 kΩ ¼ W | |
| R2 | 10 kΩ ¼ W | |
| RC1 | 4.7 kΩ ¼ W | |
| RE1 | 220 Ω ¼ W | |
| RE2 | 1 kΩ ¼ W | |
| RF | 5.1 kΩ ¼ W | O trimpot de 10 kΩ para ajustar el punto medio |
| RB2 | 2.2 kΩ ¼ W | |
| RE3 | 100 Ω ¼ W | |
| RC2A, RC2B | 270 Ω ½ W | |
| RV1 | 560 Ω | **Mejor trimpot de 1 kΩ** (empieza al mínimo) |
| RV2 | 1 kΩ ¼ W | |
| RE4, RE5 | 0.47 Ω 1 W | |
| C1, C2, CV | 10 µF / 25 V electrolítico | |
| CE1, CE2 | 100 µF / 16 V electrolítico | |
| CB | 220 µF / 25 V electrolítico | |
| CO | 2200 µF / 25 V electrolítico | |
| CC | 100 pF cerámico | |
| — | Potenciómetro 10 kΩ log | Control de volumen a la entrada (opcional) |
| — | Bocina 8 Ω, ≥ 2 W | |
| — | Fuente 12 V / 1 A | Pon un electrolítico de 1000 µF + cerámico 100 nF en la alimentación |

---

## Puesta en marcha (en físico)

1. **Antes de conectar:** RV1 al mínimo (0 Ω) y sin bocina; en su lugar pon una resistencia de 10 Ω en serie con la fuente o usa fuente con límite de corriente (~200 mA).
2. Mide en reposo, sin señal:
   - V(B1) ≈ 2 V, V(COL1) ≈ 6.7 V
   - V(OUT) ≈ 6 V → si no, ajusta RF
3. Sube RV1 despacio midiendo el voltaje en RE4: **≈ 14 mV** = 30 mA de reposo.
4. Conecta la bocina, mete 1 kHz a ~50 mV pico y revisa con el osciloscopio que no haya recorte ni muesca en el cruce por cero.
5. Deja trabajar 10 min y vuelve a medir RE4: si la corriente sube sola, baja RV1 un poco y acerca Q5 al disipador.

## Siguientes mejoras
- Fuente simétrica ±15 V + par diferencial a la entrada → ~10 W y menos distorsión.
- Par Darlington (TIP120/TIP125) o salida cuasi-complementaria para más corriente.
- VU meter con LM3915 o control de tonos Baxandall antes de la etapa 1.
