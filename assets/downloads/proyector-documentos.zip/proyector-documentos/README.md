# Proyector de Documentos

App de escritorio para proyectar **PDF, PowerPoint y Word** sin batallar con el proyector.
Si el proyector queda chueco, de lado o apuntando desde abajo, arrastras 4 esquinas y la imagen queda derecha en la pared.
Se maneja desde la laptop, con un clicker o desde el celular.

Hecha con Electron. Se compila para **Windows (.exe)** y **Linux (AppImage)** en GitHub Actions.

![Ventana del presentador](imagenes/presentador.png)

| Ajustar esquinas en la laptop | En la pared: guía y resultado |
|---|---|
| ![](imagenes/ajustar_esquinas.png) | ![](imagenes/proyector_antes_despues.png) |

## Descargar

1. Pestaña **Actions** del repositorio > **Proyector de Documentos** > la ejecución más reciente con palomita verde.
2. En **Artifacts**:
   - **Proyector-Documentos-Windows**: trae el instalador (`Setup`) y una versión **portable** que no se instala.
   - **Proyector-Documentos-Linux**: el `.AppImage`. Dale permiso de ejecución (`chmod +x`) y ábrelo.

Para abrir **PowerPoint y Word** hace falta [LibreOffice](https://es.libreoffice.org/descarga/libreoffice/) (gratis).
Los PDF y las imágenes se abren sin él. Si no está instalado, la app lo avisa y da el enlace.

## Cómo se usa

1. Conecta el proyector. La app abre la proyección sola en la pantalla externa
   (en Windows, pon la pantalla en modo **Extender**, no Duplicar: tecla `Win + P`).
2. **Abre** o arrastra un archivo a la ventana.
3. Si la imagen sale chueca, dale **Ajustar esquinas** (`E`): en la pared aparece una cuadrícula verde con las esquinas numeradas.
   Arrastra los puntos en la laptop hasta que se vea rectangular. Se guarda para ese proyector.
4. Presenta: `→` `←` o un clicker, `B` para pantalla en negro, `P` para puntero láser con el mouse.

### Desde el celular
Escanea el QR de la ventana del presentador (misma red WiFi). Tienes botones grandes de anterior/siguiente,
pantalla en negro, y si dejas el dedo sobre la imagen aparece un **puntero láser** en la proyección.
El enlace lleva un código, así que nadie más en la red puede controlarlo.
En Windows, la primera vez el firewall pregunta si permitir la conexión: dale **Permitir** en redes privadas.

### Word y documentos largos
**Al ancho** agranda la página para que se lea, y con `↑` `↓`, la rueda del mouse o los botones del celular te desplazas por ella.

## Qué hace por dentro

- PowerPoint y Word se convierten a PDF con LibreOffice en modo oculto (y se guardan en caché, la segunda vez abre al instante).
- Los PDF se dibujan con pdf.js a la resolución completa del proyector.
- La corrección de esquinas es una homografía (el mismo cálculo que el [Mapeador de proyección](../mapeador-proyeccion/)).
- El control desde el celular es un servidor local dentro de la app (puerto 8765).

## Limitaciones

- Las **animaciones y transiciones** de PowerPoint no se ven, porque se convierte a PDF. Las diapositivas sí, completas.
- Los **videos** dentro de un PowerPoint no se reproducen.
- Las notas del orador no se muestran todavía.

## Desarrollo

```
cd app
npm install
npm start                  # abrir la app
npm run dist:win           # .exe (en Windows)
npm run dist:linux         # AppImage (en Linux)
```

| Archivo | Qué hace |
|---|---|
| `app/main.js` | Ventanas, pantallas, conversión con LibreOffice, servidor para el celular |
| `app/control.*` | Ventana del presentador |
| `app/proyector.*` | Ventana de proyección con la corrección de esquinas |
| `app/telefono.html` | Control remoto para el celular |
| `app/shared/` | Homografía y dibujo de páginas (pdf.js) |

## Versiones

| Versión | Cambios |
|---|---|
| v1 | PDF, PowerPoint, Word e imágenes; corrección de 4 esquinas guardada por proyector; vista del presentador con siguiente página, miniaturas y reloj; modo "al ancho" con desplazamiento; pantalla en negro; puntero láser; control desde el celular por QR con código de acceso. |
