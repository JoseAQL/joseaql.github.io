// Ventana de proyección: dibuja la página a resolución completa y la deforma con las 4 esquinas.
import { matrix3d } from './shared/warp.js';
import { cargarDoc, componer } from './shared/doc.js';

const api = window.api;
const marco = document.getElementById('marco'), pag = document.getElementById('pag'), capa = document.getElementById('capa');
const ayuda = document.getElementById('ayuda');
let doc = null, docId = -1, est = null, W = 0, H = 0, generacion = 0, ultimaClave = '';

function medir() {
  W = innerWidth; H = innerHeight;
  const r = devicePixelRatio || 1;
  for (const c of [pag, capa]) { c.width = Math.round(W * r); c.height = Math.round(H * r); c.style.width = W + 'px'; c.style.height = H + 'px'; }
  marco.style.width = W + 'px'; marco.style.height = H + 'px';
  api.tamProyector({ w: W, h: H });
  ultimaClave = '';
  if (est) aplicar(est);
}

async function dibujarPagina() {
  if (!doc || !est) return;
  const clave = `${docId}|${est.pagina}|${est.ajuste}|${est.scroll.toFixed(4)}|${pag.width}x${pag.height}`;
  if (clave === ultimaClave) return;
  ultimaClave = clave;
  const g = ++generacion;
  const tmp = document.createElement('canvas'); tmp.width = pag.width; tmp.height = pag.height;
  await componer(doc, tmp, est.pagina, tmp.width, tmp.height, est.ajuste, est.scroll);
  if (g !== generacion) return;                     // ya se pidió otra página
  pag.getContext('2d').drawImage(tmp, 0, 0);
}

function dibujarCapa() {
  const c = capa.getContext('2d'), w = capa.width, h = capa.height;
  c.clearRect(0, 0, w, h);
  if (est.editar) {                                  // cuadrícula para alinear con la pared
    c.strokeStyle = 'rgba(65,240,200,.85)'; c.lineWidth = Math.max(2, w / 640);
    c.beginPath();
    for (let i = 1; i < 8; i++) { const x = i * w / 8; c.moveTo(x, 0); c.lineTo(x, h); }
    for (let i = 1; i < 6; i++) { const y = i * h / 6; c.moveTo(0, y); c.lineTo(w, y); }
    c.stroke();
    c.lineWidth = Math.max(6, w / 200); c.strokeStyle = '#41f0c8'; c.strokeRect(c.lineWidth / 2, c.lineWidth / 2, w - c.lineWidth, h - c.lineWidth);
    c.fillStyle = '#ffffff'; c.font = `700 ${Math.round(h / 12)}px system-ui, sans-serif`; c.textBaseline = 'top';
    const m = h / 30;
    c.textAlign = 'left'; c.fillText('1', m * 1.5, m); c.textAlign = 'right'; c.fillText('2', w - m * 1.5, m);
    c.textBaseline = 'bottom'; c.fillText('3', w - m * 1.5, h - m); c.textAlign = 'left'; c.fillText('4', m * 1.5, h - m);
  }
  if (est.puntero) {                                 // puntero láser
    const [x, y] = [est.puntero[0] * w, est.puntero[1] * h], r = Math.max(10, h / 70);
    const g = c.createRadialGradient(x, y, 0, x, y, r * 2.4);
    g.addColorStop(0, 'rgba(255,40,40,1)'); g.addColorStop(.35, 'rgba(255,40,40,.9)'); g.addColorStop(1, 'rgba(255,0,0,0)');
    c.fillStyle = g; c.beginPath(); c.arc(x, y, r * 2.4, 0, Math.PI * 2); c.fill();
  }
}

async function aplicar(s) {
  est = s;
  if (s.docId !== docId) {
    docId = s.docId; ultimaClave = '';
    if (doc) { doc.destruir(); doc = null; }
    const bytes = await api.leerDocumento();
    if (bytes && s.docId === docId) doc = await cargarDoc(new Uint8Array(bytes), s.tipo);
  }
  ayuda.hidden = !!doc || s.editar;
  const q = s.esquinas.map(([x, y]) => [x * W, y * H]);
  marco.style.transform = matrix3d(W, H, q);
  marco.classList.toggle('oculto', s.negro && !s.editar);
  dibujarCapa();
  if (doc && !s.editar) { pag.hidden = false; await dibujarPagina(); }
  else if (s.editar) { const c = pag.getContext('2d'); c.fillStyle = '#0b1416'; c.fillRect(0, 0, pag.width, pag.height); ultimaClave = ''; }
}

api.alEstado(aplicar);
addEventListener('resize', medir);
addEventListener('dblclick', () => api.pantallaCompleta());
addEventListener('keydown', e => {                  // por si el clicker está enfocado en esta ventana
  const k = e.key;
  if (['ArrowRight', 'PageDown', ' ', 'Enter'].includes(k)) api.cmd({ accion: 'sig' });
  else if (['ArrowLeft', 'PageUp', 'Backspace'].includes(k)) api.cmd({ accion: 'ant' });
  else if (k === 'b' || k === 'B' || k === '.') api.cmd({ accion: 'negro' });
  else if (k === 'Escape') api.cmd({ accion: 'editar', valor: false });
});
medir();
api.estado().then(aplicar);
