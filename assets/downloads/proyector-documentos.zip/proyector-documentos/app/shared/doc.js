// Carga un documento (PDF o imagen) y dibuja una página dentro de un "cuadro" del tamaño del proyector.
import * as pdfjs from '../node_modules/pdfjs-dist/build/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc = new URL('../node_modules/pdfjs-dist/build/pdf.worker.mjs', import.meta.url).href;

export async function cargarDoc(bytes, tipo) {
  if (tipo === 'img') {
    const url = URL.createObjectURL(new Blob([bytes]));
    const img = new Image(); img.src = url; await img.decode();
    return { n: 1, async tam() { return { w: img.naturalWidth, h: img.naturalHeight }; },
      async dibujar(ctx, i, x, y, w, h) { ctx.drawImage(img, x, y, w, h); }, destruir() { URL.revokeObjectURL(url); } };
  }
  const pdf = await pdfjs.getDocument({ data: bytes, isEvalSupported: false }).promise;
  return {
    n: pdf.numPages,
    async tam(i) { const p = await pdf.getPage(i + 1); const v = p.getViewport({ scale: 1 }); return { w: v.width, h: v.height }; },
    async dibujar(ctx, i, x, y, w, h) {
      const p = await pdf.getPage(i + 1);
      const v1 = p.getViewport({ scale: 1 });
      const viewport = p.getViewport({ scale: w / v1.width });
      await p.render({ canvasContext: ctx, viewport, transform: [1, 0, 0, 1, x, y], background: 'white' }).promise;
    },
    destruir() { pdf.destroy(); },
  };
}

/**
 * Dibuja la página i en un canvas de W×H (el cuadro del proyector).
 * ajuste: 'pagina' = completa, 'ancho' = al ancho, con scroll (0..1) vertical.
 * Devuelve true si en modo ancho la página se sale del cuadro (hay para dónde desplazar).
 */
export async function componer(doc, canvas, i, W, H, ajuste, scroll) {
  const ctx = canvas.getContext('2d');
  const t = await doc.tam(i);
  let w, h, x, y, sobra = false;
  if (ajuste === 'ancho') {
    w = W; h = t.h * W / t.w; x = 0;
    sobra = h > H; y = sobra ? -(h - H) * Math.min(1, Math.max(0, scroll)) : (H - h) / 2;
  } else {
    const k = Math.min(W / t.w, H / t.h); w = t.w * k; h = t.h * k; x = (W - w) / 2; y = (H - h) / 2;
  }
  // se dibuja en un canvas aparte y luego se copia, para no ver la página a medio dibujar
  const tmp = document.createElement('canvas'); tmp.width = W; tmp.height = H;
  const tc = tmp.getContext('2d'); tc.fillStyle = '#000'; tc.fillRect(0, 0, W, H);
  await doc.dibujar(tc, i, x, y, w, h);
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); ctx.drawImage(tmp, 0, 0);
  return sobra;
}
