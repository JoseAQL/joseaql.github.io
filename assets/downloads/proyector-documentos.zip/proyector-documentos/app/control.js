// Ventana del presentador: vista previa, miniaturas, siguiente página, editor de esquinas, puntero, reloj y QR.
import { cargarDoc, componer } from './shared/doc.js';

const api = window.api;
const $ = id => document.getElementById(id);
const vista = $('vista'), actual = $('actual'), sobre = $('sobre'), escenario = $('escenario');
let est = null, doc = null, docId = -1, gen = 0, ultimaClave = '', punteroOn = false;
let vw = 0, vh = 0;                      // tamaño de la vista previa (px CSS)
let arrastre = null, ultimaEsquina = null, t0 = null;

// ---------------------------------------------------------------- tamaños
function medir() {
  if (!est) return;
  const pw = est.proyector.w, ph = est.proyector.h;
  const r = escenario.getBoundingClientRect();
  const maxW = r.width - 36, maxH = r.height - 36 - (est.editar ? 70 : 0);
  const k = Math.min(maxW / pw, maxH / ph);
  vw = Math.max(50, Math.floor(pw * k)); vh = Math.max(30, Math.floor(ph * k));
  const dpr = devicePixelRatio || 1;
  vista.style.width = vw + 'px'; vista.style.height = vh + 'px';
  for (const c of [actual, sobre]) { c.width = Math.round(vw * dpr); c.height = Math.round(vh * dpr); c.style.width = vw + 'px'; c.style.height = vh + 'px'; }
  const sig = $('siguiente'); sig.width = 512; sig.height = Math.round(512 * ph / pw);
  ultimaClave = '';
}

// ---------------------------------------------------------------- dibujo
async function dibujarActual() {
  if (!doc || !est) return;
  const clave = `${docId}|${est.pagina}|${est.ajuste}|${est.scroll.toFixed(4)}|${actual.width}x${actual.height}`;
  if (clave === ultimaClave) return;
  ultimaClave = clave;
  const g = ++gen;
  const tmp = document.createElement('canvas'); tmp.width = actual.width; tmp.height = actual.height;
  await componer(doc, tmp, est.pagina, tmp.width, tmp.height, est.ajuste, est.scroll);
  if (g !== gen) return;
  actual.getContext('2d').drawImage(tmp, 0, 0);
  // miniatura para el celular
  const m = document.createElement('canvas'); m.width = 640; m.height = Math.round(640 * tmp.height / tmp.width);
  m.getContext('2d').drawImage(tmp, 0, 0, m.width, m.height);
  api.miniatura(m.toDataURL('image/jpeg', 0.7));
  // siguiente
  const sig = $('siguiente');
  if (est.pagina + 1 < doc.n) { await componer(doc, sig, est.pagina + 1, sig.width, sig.height, 'pagina', 0); $('sigTxt').textContent = `Página ${est.pagina + 2}`; }
  else { const c = sig.getContext('2d'); c.fillStyle = '#000'; c.fillRect(0, 0, sig.width, sig.height); $('sigTxt').textContent = 'Fin del documento'; }
}

// mapea un punto (u,v) del cuadro 0..1 a la vista con las esquinas (bilineal, suficiente para la guía)
function mapa(q, u, v) {
  const top = [q[0][0] + (q[1][0] - q[0][0]) * u, q[0][1] + (q[1][1] - q[0][1]) * u];
  const bot = [q[3][0] + (q[2][0] - q[3][0]) * u, q[3][1] + (q[2][1] - q[3][1]) * u];
  return [(top[0] + (bot[0] - top[0]) * v) * vw, (top[1] + (bot[1] - top[1]) * v) * vh];
}
function dibujarSobre() {
  const c = sobre.getContext('2d'), dpr = devicePixelRatio || 1;
  c.setTransform(dpr, 0, 0, dpr, 0, 0); c.clearRect(0, 0, vw, vh);
  if (!est) return;
  if (est.editar) {
    c.fillStyle = 'rgba(5,10,11,.86)'; c.fillRect(0, 0, vw, vh);
    c.strokeStyle = 'rgba(255,255,255,.25)'; c.setLineDash([4, 4]); c.strokeRect(.5, .5, vw - 1, vh - 1); c.setLineDash([]);
    c.fillStyle = 'rgba(255,255,255,.4)'; c.font = '600 11px system-ui'; c.fillText('ÁREA COMPLETA DEL PROYECTOR', 8, 16);
    const q = est.esquinas;
    c.strokeStyle = 'rgba(65,240,200,.5)'; c.lineWidth = 1; c.beginPath();
    for (let i = 1; i < 8; i++) { const a = mapa(q, i / 8, 0), b = mapa(q, i / 8, 1); c.moveTo(...a); c.lineTo(...b); }
    for (let i = 1; i < 6; i++) { const a = mapa(q, 0, i / 6), b = mapa(q, 1, i / 6); c.moveTo(...a); c.lineTo(...b); }
    c.stroke();
    c.strokeStyle = '#41f0c8'; c.lineWidth = 2.5; c.beginPath();
    q.forEach(([x, y], i) => (i ? c.lineTo(x * vw, y * vh) : c.moveTo(x * vw, y * vh))); c.closePath(); c.stroke();
    q.forEach(([x, y], i) => {
      c.beginPath(); c.arc(x * vw, y * vh, 11, 0, Math.PI * 2);
      c.fillStyle = i === ultimaEsquina ? '#41f0c8' : '#0b1011'; c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 2; c.stroke();
      c.fillStyle = i === ultimaEsquina ? '#03130f' : '#fff'; c.font = '700 12px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(String(i + 1), x * vw, y * vh); c.textAlign = 'start'; c.textBaseline = 'alphabetic';
    });
  } else if (est.puntero) {
    const [x, y] = [est.puntero[0] * vw, est.puntero[1] * vh];
    c.fillStyle = 'rgba(255,40,40,.9)'; c.beginPath(); c.arc(x, y, 7, 0, Math.PI * 2); c.fill();
  }
}

// ---------------------------------------------------------------- miniaturas
let observador = null;
function construirMiniaturas() {
  const nav = $('miniaturas'); nav.innerHTML = '';
  if (observador) observador.disconnect();
  if (!doc) return;
  const pw = est.proyector.w, ph = est.proyector.h;
  observador = new IntersectionObserver(entradas => {
    for (const e of entradas) if (e.isIntersecting && !e.target.dataset.listo) {
      e.target.dataset.listo = '1';
      const i = +e.target.dataset.i, cv = e.target.querySelector('canvas');
      componer(doc, cv, i, cv.width, cv.height, 'pagina', 0).catch(() => {});
    }
  }, { root: nav, rootMargin: '300px' });
  for (let i = 0; i < doc.n; i++) {
    const b = document.createElement('button'); b.className = 'mini'; b.dataset.i = i; b.title = `Ir a la página ${i + 1}`;
    const cv = document.createElement('canvas'); cv.width = 300; cv.height = Math.round(300 * ph / pw);
    const s = document.createElement('span'); s.textContent = i + 1;
    b.append(cv, s); b.onclick = () => api.cmd({ accion: 'ir', pagina: i });
    nav.append(b); observador.observe(b);
  }
}
function marcarMiniatura() {
  document.querySelectorAll('.mini').forEach(b => {
    const on = +b.dataset.i === est.pagina; b.classList.toggle('actual', on);
    if (on) b.scrollIntoView({ block: 'nearest' });
  });
}

// ---------------------------------------------------------------- estado
async function aplicar(s) {
  const antes = est; est = s;
  const tamCambio = !antes || antes.proyector.w !== s.proyector.w || antes.proyector.h !== s.proyector.h || antes.editar !== s.editar;
  if (tamCambio) medir();
  if (s.docId !== docId) {
    docId = s.docId; ultimaClave = '';
    if (doc) { doc.destruir(); doc = null; }
    const bytes = await api.leerDocumento();
    if (bytes && s.docId === docId) {
      doc = await cargarDoc(new Uint8Array(bytes), s.tipo);
      api.paginas(doc.n);
      if (t0 == null) t0 = Date.now();
      construirMiniaturas();
    }
  } else if (tamCambio && doc) construirMiniaturas();
  // barra
  $('vacio').hidden = !!doc; vista.hidden = !doc && !s.editar;
  $('nombre').textContent = s.nombre || 'Sin documento'; $('nombre').title = s.nombre || '';
  $('contador').textContent = doc ? `${s.pagina + 1} / ${doc.n}` : '– / –';
  $('ant').disabled = !doc || s.pagina === 0; $('sig').disabled = !doc || s.pagina >= (doc ? doc.n : 1) - 1;
  $('negro').classList.toggle('on', s.negro); $('negro').textContent = s.negro ? 'Negro (activo)' : 'Negro';
  $('ajPagina').classList.toggle('on', s.ajuste === 'pagina'); $('ajAncho').classList.toggle('on', s.ajuste === 'ancho');
  $('editar').classList.toggle('on', s.editar); $('editorAyuda').hidden = !s.editar;
  $('puntero').classList.toggle('on', punteroOn); vista.classList.toggle('puntero', punteroOn);
  if (antes && antes.pagina !== s.pagina || !antes) marcarMiniatura();
  dibujarSobre();
  if (doc) await dibujarActual();
}

// ---------------------------------------------------------------- editor de esquinas y puntero (sobre la vista)
function punto(e) { const r = sobre.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; }
sobre.addEventListener('pointerdown', e => {
  if (!est) return;
  if (est.editar) {
    const [x, y] = punto(e);
    let mejor = -1, d = 1e9;
    est.esquinas.forEach(([qx, qy], i) => { const dd = Math.hypot((qx - x) * vw, (qy - y) * vh); if (dd < d) { d = dd; mejor = i; } });
    if (d < 40) { arrastre = mejor; ultimaEsquina = mejor; sobre.setPointerCapture(e.pointerId); dibujarSobre(); }
  } else if (punteroOn) { sobre.setPointerCapture(e.pointerId); api.cmd({ accion: 'puntero', valor: punto(e) }); }
});
sobre.addEventListener('pointermove', e => {
  if (!est) return;
  if (est.editar && arrastre != null) {
    const [x, y] = punto(e), q = est.esquinas.map(p => p.slice());
    q[arrastre] = [Math.max(-.2, Math.min(1.2, x)), Math.max(-.2, Math.min(1.2, y))];
    api.cmd({ accion: 'esquinas', valor: q });
  } else if (punteroOn && !est.editar) api.cmd({ accion: 'puntero', valor: punto(e) });
});
sobre.addEventListener('pointerup', () => { if (arrastre != null) { arrastre = null; api.cmd({ accion: 'esquinas', guardar: true }); } });
sobre.addEventListener('pointerleave', () => { if (punteroOn && est && est.puntero) api.cmd({ accion: 'puntero', valor: null }); });

// ---------------------------------------------------------------- botones
const cmd = c => api.cmd(c);
$('abrir').onclick = $('abrir2').onclick = () => api.abrirDialogo();
$('ant').onclick = () => cmd({ accion: 'ant' });
$('sig').onclick = () => cmd({ accion: 'sig' });
$('negro').onclick = () => cmd({ accion: 'negro' });
$('ajPagina').onclick = () => cmd({ accion: 'ajuste', valor: 'pagina' });
$('ajAncho').onclick = () => cmd({ accion: 'ajuste', valor: 'ancho' });
$('editar').onclick = () => cmd({ accion: 'editar' });
$('listo').onclick = () => cmd({ accion: 'editar', valor: false });
$('reset').onclick = () => cmd({ accion: 'reset-esquinas' });
$('puntero').onclick = () => { punteroOn = !punteroOn; if (!punteroOn) cmd({ accion: 'puntero', valor: null }); aplicar(est); };
$('reiniciar').onclick = () => { t0 = Date.now(); tic(); };
$('pantalla').onchange = async e => { await api.elegirPantalla(+e.target.value); cargarPantallas(); };

async function cargarPantallas() {
  const sel = $('pantalla'), lista = await api.pantallas();
  sel.innerHTML = '';
  for (const p of lista) { const o = document.createElement('option'); o.value = p.id; o.textContent = p.nombre; o.selected = p.elegida; sel.append(o); }
}

addEventListener('keydown', e => {
  if (e.target.tagName === 'SELECT') return;
  const k = e.key;
  if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === 'o') { e.preventDefault(); api.abrirDialogo(); return; }
  if (!est) return;
  if (est.editar && ultimaEsquina != null && k.startsWith('Arrow')) {
    e.preventDefault();
    const paso = (e.shiftKey ? 10 : 1), q = est.esquinas.map(p => p.slice());
    const dx = { ArrowLeft: -1, ArrowRight: 1 }[k] || 0, dy = { ArrowUp: -1, ArrowDown: 1 }[k] || 0;
    q[ultimaEsquina][0] += dx * paso / est.proyector.w; q[ultimaEsquina][1] += dy * paso / est.proyector.h;
    cmd({ accion: 'esquinas', valor: q, guardar: true }); return;
  }
  if (['ArrowRight', 'PageDown', ' ', 'Enter'].includes(k)) { e.preventDefault(); cmd({ accion: 'sig' }); }
  else if (['ArrowLeft', 'PageUp', 'Backspace'].includes(k)) { e.preventDefault(); cmd({ accion: 'ant' }); }
  else if (k === 'ArrowDown') { e.preventDefault(); est.ajuste === 'ancho' ? cmd({ accion: 'scroll', delta: .12 }) : cmd({ accion: 'sig' }); }
  else if (k === 'ArrowUp') { e.preventDefault(); est.ajuste === 'ancho' ? cmd({ accion: 'scroll', delta: -.12 }) : cmd({ accion: 'ant' }); }
  else if (k === 'Home') cmd({ accion: 'ir', pagina: 0 });
  else if (k === 'End') cmd({ accion: 'ir', pagina: 1e6 });
  else if (k === 'b' || k === 'B' || k === '.') cmd({ accion: 'negro' });
  else if (k === 'e' || k === 'E') cmd({ accion: 'editar' });
  else if (k === 'p' || k === 'P') $('puntero').click();
  else if (k === 'Escape' && est.editar) cmd({ accion: 'editar', valor: false });
});
escenario.addEventListener('wheel', e => { if (est && est.ajuste === 'ancho' && doc) { e.preventDefault(); cmd({ accion: 'scroll', delta: e.deltaY / 1500 }); } }, { passive: false });

// arrastrar y soltar
const vacio = $('vacio');
addEventListener('dragover', e => { e.preventDefault(); vacio.classList.add('encima'); });
addEventListener('dragleave', e => { if (!e.relatedTarget) vacio.classList.remove('encima'); });
addEventListener('drop', e => { e.preventDefault(); vacio.classList.remove('encima'); const f = e.dataTransfer.files[0]; if (f) api.abrirArchivo(f); });

// avisos
let relojAviso = null;
api.alAviso(a => {
  const el = $('aviso'); el.className = 'aviso ' + a.tipo; el.hidden = false; el.textContent = a.texto;
  if (a.tipo === 'libreoffice') {
    const b = document.createElement('button'); b.className = 'chico'; b.textContent = 'Descargar LibreOffice';
    b.onclick = () => api.abrirEnlace('https://es.libreoffice.org/descarga/libreoffice/'); el.append(b);
  }
  clearTimeout(relojAviso);
  if (a.tipo !== 'espera') relojAviso = setTimeout(() => { el.hidden = true; }, a.tipo === 'ok' ? 2500 : 9000);
});

// reloj
function tic() {
  const s = t0 ? Math.floor((Date.now() - t0) / 1000) : 0;
  $('reloj').textContent = `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
setInterval(tic, 1000);

// inicio
api.alEstado(aplicar);
addEventListener('resize', () => { medir(); if (est) { construirMiniaturas(); marcarMiniatura(); dibujarSobre(); dibujarActual(); } });
api.estado().then(aplicar);
cargarPantallas();
api.red().then(r => { $('qr').src = r.qr; $('url').textContent = r.url; });
api.libreoffice().then(l => { $('estadoLO').textContent = l.hay ? 'PDF, PowerPoint, Word e imágenes.' : 'PDF e imágenes. Para PowerPoint y Word instala LibreOffice (gratis).'; });
