const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  abrirDialogo: () => ipcRenderer.invoke('abrir-dialogo'),
  abrirArchivo: file => ipcRenderer.invoke('abrir-ruta', webUtils.getPathForFile(file)),
  leerDocumento: () => ipcRenderer.invoke('leer-documento'),
  estado: () => ipcRenderer.invoke('estado'),
  pantallas: () => ipcRenderer.invoke('pantallas'),
  elegirPantalla: id => ipcRenderer.invoke('elegir-pantalla', id),
  red: () => ipcRenderer.invoke('red'),
  libreoffice: () => ipcRenderer.invoke('libreoffice'),
  cmd: c => ipcRenderer.send('cmd', c),
  paginas: n => ipcRenderer.send('paginas', n),
  miniatura: d => ipcRenderer.send('miniatura', d),
  tamProyector: t => ipcRenderer.send('tam-proyector', t),
  pantallaCompleta: () => ipcRenderer.send('pantalla-completa'),
  abrirEnlace: url => ipcRenderer.send('abrir-enlace', url),
  alEstado: fn => ipcRenderer.on('estado', (e, s) => fn(s)),
  alAviso: fn => ipcRenderer.on('aviso', (e, a) => fn(a)),
});
