// Proyector de Documentos — proceso principal.
// Ventana "control" (presentador, en la laptop) + ventana "proyector" (pantalla externa, con corrección de 4 esquinas)
// + servidor local para manejarlo desde el celular.
const { app, BrowserWindow, ipcMain, dialog, screen, shell, protocol, net } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');
const QRCode = require('qrcode');

const OFFICE = ['ppt', 'pptx', 'pps', 'ppsx', 'odp', 'key', 'doc', 'docx', 'odt', 'rtf', 'txt', 'xls', 'xlsx', 'ods'];
const IMAGEN = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'];
const PRUEBA = process.env.PROYECTOR_PRUEBA === '1';   // solo para pruebas automáticas

let control = null, proyector = null;
const estado = {
  docId: 0, nombre: '', tipo: null, paginas: 0, pagina: 0,
  negro: false, ajuste: 'pagina', scroll: 0, editar: false,
  esquinas: [[0, 0], [1, 0], [1, 1], [0, 1]], puntero: null,
  proyector: { w: 1920, h: 1080, externo: false, pantalla: null },
};
let rutaPdf = null;            // archivo que se muestra (PDF o imagen)
let miniatura = null;          // JPEG de la página actual, para el celular

// ------------------------------------------------------------------ configuración guardada
const archivoConfig = () => path.join(app.getPath('userData'), 'config.json');
let config = { esquinas: {}, pantalla: null };
function leerConfig() { try { config = Object.assign(config, JSON.parse(fs.readFileSync(archivoConfig(), 'utf8'))); } catch (e) { } }
function guardarConfig() { try { fs.writeFileSync(archivoConfig(), JSON.stringify(config, null, 2)); } catch (e) { } }
const clavePantalla = () => `${estado.proyector.w}x${estado.proyector.h}`;

// ------------------------------------------------------------------ archivos de la app por app://
protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true } }]);
function registrarProtocolo() {
  protocol.handle('app', req => {
    const p = decodeURIComponent(new URL(req.url).pathname);
    const ruta = path.normalize(path.join(__dirname, p));
    if (!ruta.startsWith(__dirname)) return new Response('', { status: 403 });
    return net.fetch(pathToFileURL(ruta).href);
  });
}

// ------------------------------------------------------------------ ventanas
const prefs = { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false };

function crearControl() {
  control = new BrowserWindow({ width: 1280, height: 800, minWidth: 900, minHeight: 600, backgroundColor: '#101415', title: 'Proyector de Documentos', webPreferences: prefs });
  control.setMenuBarVisibility(false);
  control.loadURL('app://local/control.html');
  control.on('closed', () => { control = null; if (proyector) proyector.close(); app.quit(); });
}

function pantallaDestino() {
  const todas = screen.getAllDisplays(), primaria = screen.getPrimaryDisplay();
  if (config.pantalla != null) { const d = todas.find(x => x.id === config.pantalla); if (d) return d; }
  return todas.find(d => d.id !== primaria.id) || primaria;
}

function crearProyector() {
  if (proyector) { const p = proyector; proyector = null; p.destroy(); }
  const d = pantallaDestino(), primaria = screen.getPrimaryDisplay();
  const externo = d.id !== primaria.id;
  const b = d.bounds;
  proyector = new BrowserWindow({
    x: externo ? b.x : b.x + 80, y: externo ? b.y : b.y + 80,
    width: externo ? b.width : 960, height: externo ? b.height : 540,
    frame: !externo, fullscreen: externo, backgroundColor: '#000000', title: 'Proyección', autoHideMenuBar: true,
    webPreferences: prefs, show: false,
  });
  estado.proyector = { w: b.width, h: b.height, externo, pantalla: d.id };
  estado.esquinas = config.esquinas[clavePantalla()] || [[0, 0], [1, 0], [1, 1], [0, 1]];
  proyector.loadURL('app://local/proyector.html');
  proyector.once('ready-to-show', () => { proyector.showInactive(); if (control) control.focus(); });
  proyector.on('closed', () => { if (proyector && proyector.isDestroyed()) proyector = null; });
  difundir();
}

function listaPantallas() {
  const primaria = screen.getPrimaryDisplay();
  return screen.getAllDisplays().map((d, i) => ({
    id: d.id, nombre: `Pantalla ${i + 1}${d.id === primaria.id ? ' (esta laptop)' : ''} · ${d.bounds.width}×${d.bounds.height}`,
    elegida: d.id === estado.proyector.pantalla,
  }));
}

// ------------------------------------------------------------------ estado compartido
const clientesSSE = new Set();
function difundir() {
  const s = JSON.stringify(estado);
  for (const w of [control, proyector]) if (w && !w.isDestroyed()) w.webContents.send('estado', estado);
  for (const res of clientesSSE) res.write(`data: ${s}\n\n`);
}
function avisar(texto, tipo = 'info') { if (control && !control.isDestroyed()) control.webContents.send('aviso', { texto, tipo }); }

function aplicar(c) {
  const n = Math.max(1, estado.paginas);
  switch (c.accion) {
    case 'sig': if (estado.pagina < n - 1) { estado.pagina++; estado.scroll = 0; } break;
    case 'ant': if (estado.pagina > 0) { estado.pagina--; estado.scroll = 0; } break;
    case 'ir': estado.pagina = Math.max(0, Math.min(n - 1, c.pagina | 0)); estado.scroll = 0; break;
    case 'negro': estado.negro = c.valor != null ? !!c.valor : !estado.negro; break;
    case 'ajuste': estado.ajuste = c.valor === 'ancho' ? 'ancho' : 'pagina'; estado.scroll = 0; break;
    case 'scroll': estado.scroll = Math.max(0, Math.min(1, c.valor != null ? +c.valor : estado.scroll + (+c.delta || 0))); break;
    case 'editar': estado.editar = c.valor != null ? !!c.valor : !estado.editar; break;
    case 'esquinas':
      if (Array.isArray(c.valor) && c.valor.length === 4) { estado.esquinas = c.valor.map(p => [+p[0], +p[1]]); }
      if (c.guardar) { config.esquinas[clavePantalla()] = estado.esquinas; guardarConfig(); }
      break;
    case 'reset-esquinas': estado.esquinas = [[0, 0], [1, 0], [1, 1], [0, 1]]; config.esquinas[clavePantalla()] = estado.esquinas; guardarConfig(); break;
    case 'puntero': estado.puntero = c.valor ? [+c.valor[0], +c.valor[1]] : null; break;
    default: return;
  }
  difundir();
}

// ------------------------------------------------------------------ abrir y convertir documentos
function buscarSoffice() {
  const pf = process.env.ProgramFiles || 'C:\\Program Files', pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const cand = process.platform === 'win32'
    ? [path.join(pf, 'LibreOffice', 'program', 'soffice.exe'), path.join(pf86, 'LibreOffice', 'program', 'soffice.exe')]
    : ['/usr/bin/soffice', '/usr/bin/libreoffice', '/usr/local/bin/soffice', '/snap/bin/libreoffice', '/opt/libreoffice/program/soffice',
       '/var/lib/flatpak/exports/bin/org.libreoffice.LibreOffice', '/Applications/LibreOffice.app/Contents/MacOS/soffice'];
  return cand.find(p => { try { return fs.existsSync(p); } catch (e) { return false; } }) || null;
}

function convertirPdf(ruta) {
  return new Promise((resolve, reject) => {
    const soffice = buscarSoffice();
    if (!soffice) return reject(Object.assign(new Error('sin-libreoffice'), { codigo: 'sin-libreoffice' }));
    const st = fs.statSync(ruta);
    const hash = crypto.createHash('sha1').update(ruta + st.size + st.mtimeMs).digest('hex').slice(0, 16);
    const base = path.join(app.getPath('temp'), 'proyector-documentos');
    const dir = path.join(base, hash);
    const esperado = path.join(dir, path.parse(ruta).name + '.pdf');
    if (fs.existsSync(esperado)) return resolve(esperado);          // ya convertido antes
    fs.mkdirSync(dir, { recursive: true });
    const perfil = pathToFileURL(path.join(base, 'perfil-libreoffice')).href;
    const p = spawn(soffice, [`-env:UserInstallation=${perfil}`, '--headless', '--norestore', '--nolockcheck', '--convert-to', 'pdf', '--outdir', dir, ruta], { windowsHide: true });
    const reloj = setTimeout(() => { p.kill(); reject(new Error('tiempo')); }, 180000);
    p.on('error', e => { clearTimeout(reloj); reject(e); });
    p.on('close', () => {
      clearTimeout(reloj);
      const pdf = fs.readdirSync(dir).find(f => f.toLowerCase().endsWith('.pdf'));
      pdf ? resolve(path.join(dir, pdf)) : reject(new Error('sin-salida'));
    });
  });
}

async function abrir(ruta) {
  if (!ruta || !fs.existsSync(ruta)) return { ok: false };
  const ext = path.extname(ruta).slice(1).toLowerCase();
  let tipo, final;
  try {
    if (ext === 'pdf') { tipo = 'pdf'; final = ruta; }
    else if (IMAGEN.includes(ext)) { tipo = 'img'; final = ruta; }
    else if (OFFICE.includes(ext)) {
      avisar(`Convirtiendo ${path.basename(ruta)}… (la primera vez tarda unos segundos)`, 'espera');
      tipo = 'pdf'; final = await convertirPdf(ruta);
    } else { avisar('Ese tipo de archivo no se puede abrir. Usa PDF, PowerPoint, Word o una imagen.', 'error'); return { ok: false }; }
  } catch (e) {
    if (e.codigo === 'sin-libreoffice') {
      avisar('Para abrir PowerPoint y Word hace falta LibreOffice (gratis). Instálalo y vuelve a abrir el archivo. Los PDF sí se abren sin él.', 'libreoffice');
    } else avisar('No se pudo convertir el archivo. Prueba guardarlo como PDF desde PowerPoint o Word.', 'error');
    return { ok: false };
  }
  rutaPdf = final;
  Object.assign(estado, { docId: estado.docId + 1, nombre: path.basename(ruta), tipo, paginas: 0, pagina: 0, scroll: 0, negro: false, puntero: null });
  avisar(`Abierto: ${path.basename(ruta)}`, 'ok');
  difundir();
  return { ok: true };
}

// ------------------------------------------------------------------ control desde el celular
const TOKEN = crypto.randomBytes(3).toString('hex');
let puertoWeb = null;
function ipLocal() {
  const ips = [];
  for (const lista of Object.values(os.networkInterfaces())) for (const i of lista || []) if (i.family === 'IPv4' && !i.internal) ips.push(i.address);
  return ips.find(a => a.startsWith('192.168.')) || ips.find(a => a.startsWith('10.')) || ips[0] || '127.0.0.1';
}
function iniciarServidor(puerto = 8765, intentos = 10) {
  const srv = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.searchParams.get('t') !== TOKEN) { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Escanea el código QR que aparece en la laptop.'); }
    if (req.method === 'GET' && u.pathname === '/') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      return fs.createReadStream(path.join(__dirname, 'telefono.html')).pipe(res);
    }
    if (u.pathname === '/eventos') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(`data: ${JSON.stringify(estado)}\n\n`); clientesSSE.add(res);
      req.on('close', () => clientesSSE.delete(res)); return;
    }
    if (u.pathname === '/actual.jpg') {
      if (!miniatura) { res.writeHead(204); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'no-store' }); return res.end(miniatura);
    }
    if (req.method === 'POST' && u.pathname === '/cmd') {
      let body = ''; req.on('data', d => { body += d; if (body.length > 1e5) req.destroy(); });
      req.on('end', () => { try { aplicar(JSON.parse(body)); } catch (e) { } res.writeHead(204); res.end(); }); return;
    }
    res.writeHead(404); res.end();
  });
  srv.on('error', () => { if (intentos > 0) iniciarServidor(puerto + 1, intentos - 1); });
  srv.listen(puerto, '0.0.0.0', () => { puertoWeb = puerto; });
}

// ------------------------------------------------------------------ IPC con las ventanas
ipcMain.handle('abrir-dialogo', async () => {
  const r = await dialog.showOpenDialog(control, {
    title: 'Abrir documento', properties: ['openFile'],
    filters: [{ name: 'Documentos', extensions: ['pdf', ...OFFICE, ...IMAGEN] }, { name: 'Todos', extensions: ['*'] }],
  });
  if (r.canceled || !r.filePaths[0]) return { ok: false };
  return abrir(r.filePaths[0]);
});
ipcMain.handle('abrir-ruta', (e, ruta) => abrir(ruta));
ipcMain.handle('leer-documento', () => (rutaPdf ? fs.readFileSync(rutaPdf) : null));
ipcMain.handle('estado', () => estado);
ipcMain.handle('pantallas', () => listaPantallas());
ipcMain.handle('elegir-pantalla', (e, id) => { config.pantalla = id; guardarConfig(); crearProyector(); return listaPantallas(); });
ipcMain.handle('red', async () => {
  const url = `http://${ipLocal()}:${puertoWeb || 8765}/?t=${TOKEN}`;
  return { url, qr: await QRCode.toDataURL(url, { margin: 1, width: 320, color: { dark: '#0b1011', light: '#ffffff' } }) };
});
ipcMain.handle('libreoffice', () => ({ hay: !!buscarSoffice() }));
ipcMain.on('cmd', (e, c) => aplicar(c));
ipcMain.on('paginas', (e, n) => { estado.paginas = n | 0; difundir(); });
ipcMain.on('miniatura', (e, dataUrl) => { if (typeof dataUrl === 'string') miniatura = Buffer.from(dataUrl.split(',')[1] || '', 'base64'); });
ipcMain.on('tam-proyector', (e, t) => {
  if (proyector && e.sender === proyector.webContents && t.w > 0) {
    const cambio = estado.proyector.w !== t.w || estado.proyector.h !== t.h;
    estado.proyector.w = t.w; estado.proyector.h = t.h;
    if (cambio) estado.esquinas = config.esquinas[clavePantalla()] || [[0, 0], [1, 0], [1, 1], [0, 1]];
    difundir();
  }
});
ipcMain.on('pantalla-completa', () => { if (proyector) proyector.setFullScreen(!proyector.isFullScreen()); });
ipcMain.on('abrir-enlace', (e, url) => { if (/^https:\/\//.test(url)) shell.openExternal(url); });

// ------------------------------------------------------------------ arranque
app.whenReady().then(() => {
  leerConfig();
  registrarProtocolo();
  iniciarServidor();
  crearControl();
  crearProyector();
  const recolocar = () => setTimeout(crearProyector, 600);
  screen.on('display-added', recolocar);
  screen.on('display-removed', recolocar);
  // archivo pasado al abrir (doble clic sobre un PDF, "Abrir con…", o línea de comandos)
  const archivoInicial = process.argv.slice(1).find(a => !a.startsWith('-') && /\.[a-z0-9]{2,5}$/i.test(a) && fs.existsSync(a) && fs.statSync(a).isFile() && path.resolve(a) !== __filename);
  if (archivoInicial) control.webContents.once('did-finish-load', () => setTimeout(() => abrir(path.resolve(archivoInicial)), 300));
});
app.on('window-all-closed', () => app.quit());
