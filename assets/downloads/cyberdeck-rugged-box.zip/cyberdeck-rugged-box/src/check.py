import sys, json, math
import cadquery as cq
V = sys.argv[1]
O = f"out{V}"
P = json.load(open(f"{O}/params.json"))
HX, HY = P["IN_X"] / 2, P["IN_Y"] / 2
imp = lambda n: cq.importers.importStep(f"{O}/cyberdeck{V}-{n}.step").val()
base, lid, deck, plate = imp("base"), imp("lid"), imp("deck"), imp("display-bezel")
DISP = {"5": (121.0, 76.0), "7": (164.9, 100.0)}[V]

def B(x0, x1, y0, y1, z0, z1):
    return cq.Solid.makeBox(x1 - x0, y1 - y0, z1 - z0, cq.Vector(x0, y0, z0))

px0, py0, py1 = P["PI"]
comps = {
    "pi_board": B(px0, px0 + 85, py0, py1, 5.4, 6.9),
    "pi_ports": B(px0 - 2.5, px0 + 20, py0 + 1.5, py1 - 1.5, 6.9, 20.6),
    "pi_heatsink": B(px0 + 25, px0 + 55, py0 + 15, py0 + 45, 6.9, 17.0),
    "hdmi_plugs": B(px0 + 40, px0 + 64, py1, py1 + 17, 6.9, 14.0),
    "bank": B(-75, 75, -HY + 1, -HY + 73, 2.4, 19.4),
    "keyboard": B(-73, 73, P["kb_cy"] - 47.5, P["kb_cy"] + 47.5, P["DECK_Z"] + P["DECK_T"], P["DECK_Z"] + P["DECK_T"] + 22),
}
deck_p = deck.translate(cq.Vector(0, 0, P["DECK_Z"]))
# plate in lid: flip about Y axis, top at PLATE_TOP
plate_l = plate.rotate(cq.Vector(0, 0, 0), cq.Vector(0, 1, 0), 180).translate(cq.Vector(0, 0, P["PLATE_TOP"]))
pt = P["PLATE_TOP"] - 1.6
lid_comps = {
    "panel": B(-DISP[0] / 2, DISP[0] / 2, -DISP[1] / 2, DISP[1] / 2, pt - 5.5, pt),
    "lcd_pcb": B(-DISP[0] / 2 + 5, DISP[0] / 2 - 5, -DISP[1] / 2 + 3, DISP[1] / 2 - 3, pt - 5.5 - 9, pt - 5.5),
}

def vol(a, b):
    try:
        return a.intersect(b).Volume()
    except Exception as e:
        return f"err {e}"

print("--- base side")
for n, c in comps.items():
    print(n, "base", round(vol(c, base), 2), "deck", round(vol(c, deck_p), 2))
print("deck vs base", round(vol(deck_p, base), 2))
print("--- lid side")
for n, c in lid_comps.items():
    print(n, "lid", round(vol(c, lid), 2), "plate", round(vol(c, plate_l), 2))
print("plate vs lid", round(vol(plate_l, lid), 2))

# closed transform
yb, zb = HY + 7.86, 50.4          # base hinge axis
yl, zl = -HY - 7.89, 22.4         # lid hinge axis (lid frame)
def lid_at(shape, ang):
    s = shape.translate(cq.Vector(0, yb - yl, zb - zl))  # open flat (180)
    return s.rotate(cq.Vector(0, yb, zb), cq.Vector(1, yb, zb), (180 - ang))
for ang in (0,):
    L = lid_at(lid, ang)
    print("closed lid vs base", round(vol(L, base), 2))
    print("closed plate vs keyboard", round(vol(lid_at(plate_l, ang), comps["keyboard"]), 2),
          "gap kb-top to plate:", round(lid_at(plate_l, 0).BoundingBox().zmin - comps["keyboard"].BoundingBox().zmax, 2))
for ang in (0, 30, 60, 90, 100, 105, 108, 110, 112, 115, 120, 140):
    print("open", ang, "lid vs base", round(vol(lid_at(lid, ang), base), 2))

parts = {"base": base, "deck": deck_p, **comps}
lparts = {"lid": lid, "plate": plate_l, **lid_comps}
for ang, tag in ((0, "closed"), (105, "open")):
    for n, s in parts.items():
        cq.exporters.export(cq.Workplane().add(s), f"{O}/asm_{n}.stl", tolerance=0.05, angularTolerance=0.2)
    for n, s in lparts.items():
        cq.exporters.export(cq.Workplane().add(lid_at(s, ang)), f"{O}/asm_{tag}_{n}.stl", tolerance=0.05, angularTolerance=0.2)
