"""Cyberdeck remix of Whity's Rugged Box (Parametric) — CC BY-NC-SA.
Stretches the original v2 box/lid (hinges, latches, ribs untouched) and adds
internals for a Raspberry Pi 4B, power bank, Rii mini i8 keyboard and a 5"/7" HDMI screen.
"""
import sys, os, json
import cadquery as cq
from stretch import stretch

VARIANT = sys.argv[1] if len(sys.argv) > 1 else "7"
OUT = sys.argv[2] if len(sys.argv) > 2 else f"out{VARIANT}"
os.makedirs(OUT, exist_ok=True)

# ---------------- parameters ----------------
DISPLAYS = {
    # panel outline (w, h), active area (w, h)
    "5": dict(panel=(121.0, 76.0), active=(108.0, 64.8)),
    "7": dict(panel=(164.9, 100.0), active=(154.2, 85.9)),
}
D = DISPLAYS[VARIANT]
IN_X = 160.0 if VARIANT == "5" else 174.0   # interior length
IN_Y = 152.0                                 # interior depth
DZ = 18.0                                    # extra base height
S_HINGE, S_FRONT = 62.0, 20.0                # Y stretch split (hinge side / latch side)
DX = IN_X - 120.0
assert abs(S_HINGE + S_FRONT - (IN_Y - 70.0)) < 1e-6

FLOOR = 2.4              # floor top (base & lid)
R_IN = 5.0               # interior corner radius
CLR = 0.5                # fit clearance per side for drop-in plates

# base stack (absolute z in base)
PI_STANDOFF = 3.0
DECK_Z = 22.5            # deck underside
DECK_T = 2.5
KB = (146.0, 95.0)       # Rii mini i8 footprint
KB_CLR = 2.0
KB_RIM = 3.0
BANK = (150.0, 72.0)     # power bank max footprint (h <= 17)

# lid stack (z in lid frame, floor bottom = 0)
PLATE_TOP = 21.8
PLATE_FACE = 1.6
PLATE_POCKET = 3.0
PLATE_T = PLATE_FACE + PLATE_POCKET

NOTCH_W, NOTCH_D = 28.0, 7.0   # cable pass-through at hinge side (each half)

# ---------------- load & stretch ----------------
asm = cq.importers.importStep(os.path.join(os.path.dirname(__file__), "original/rugged-box-parametric-v2.step"))
S = asm.solids().vals()
box0, latch0, lid0 = S[0], S[1], S[3]

# base: hinge side is +Y
box = stretch(box0, 0, 0.0, DX)
box = stretch(box, 1, 23.0, S_HINGE)
box = stretch(box, 1, -23.0, S_FRONT)
box = stretch(box, 2, 18.0, DZ)
# recentre interior on XY origin
box = box.translate(cq.Vector(-DX / 2, -(S_FRONT + (S_HINGE - S_FRONT) / 2), 0))

# lid (printed/opened orientation): hinge side is -Y. centre at y=85.75, z from 10
lid = lid0.translate(cq.Vector(0, -85.75, -10.0))
lid = stretch(lid, 0, 0.0, DX)
lid = stretch(lid, 1, 23.0, S_FRONT)        # latch side of lid (+Y)
lid = stretch(lid, 1, -23.0, S_HINGE)       # hinge side of lid (-Y)
lid = lid.translate(cq.Vector(-DX / 2, -(S_HINGE + (S_FRONT - S_HINGE) / 2), 0))

HX, HY = IN_X / 2, IN_Y / 2


def rrect(w, h, r, t, z0=0.0, x=0.0, y=0.0):
    return (cq.Workplane("XY").workplane(offset=z0).center(x, y)
            .rect(w, h).extrude(t).edges("|Z").fillet(r))


def slot(L, W, t, z0, x, y, ang=0):
    return cq.Workplane("XY").workplane(offset=z0).center(x, y).slot2D(L, W, ang).extrude(t)

# ---------------- base internals ----------------
base = cq.Workplane().add(box)

# Pi 4B: USB/Ethernet end against -X wall, HDMI edge toward hinge (+Y)
PI_X0 = -HX + 1.0
PI_Y1 = HY - 20.0
PI_Y0 = PI_Y1 - 56.0
pi_holes = [(PI_X0 + dx, PI_Y0 + dy) for dx in (23.5, 81.5) for dy in (3.5, 52.5)]
for (x, y) in pi_holes:
    base = base.union(cq.Workplane("XY").workplane(offset=FLOOR - 0.5).center(x, y)
                      .circle(3.0).circle(1.1).extrude(PI_STANDOFF + 0.5))
# port window (USB x4 + Ethernet)
pz0 = FLOOR + PI_STANDOFF + 0.4
pz1 = FLOOR + PI_STANDOFF + 1.5 + 14.2
win = (cq.Workplane("YZ").workplane(offset=-HX - 8).center((PI_Y0 + PI_Y1) / 2, (pz0 + pz1) / 2)
       .rect(55.0, pz1 - pz0).extrude(9.0).edges("|X").fillet(1.0))
# floor vents under Pi (between standoffs)
vents = None
for i in range(5):
    vx = PI_X0 + 32 + i * 9.5
    v = slot(38, 3.0, 10, -2, vx, (PI_Y0 + PI_Y1) / 2, 90)
    vents = v if vents is None else vents.union(v)

# power bank zone + divider rail
rail = cq.Workplane("XY").workplane(offset=FLOOR - 0.5).center(-HX + 10 + 50, PI_Y0 - 1.5).rect(100, 2.0).extrude(7.5)
base = base.union(rail)

# deck support ledge (45 deg) around the walls
led_out = rrect(IN_X + 3, IN_Y + 3, R_IN + 1.5, 3.0, DECK_Z - 3.0)
led_in_bot = (cq.Workplane("XY").workplane(offset=DECK_Z - 3.3).rect(IN_X + 0.6, IN_Y + 0.6)
              .workplane(offset=3.6).rect(IN_X - 6.6, IN_Y - 6.6).loft())
ledge = led_out.cut(led_in_bot)
base = base.union(ledge)

# cable notch on hinge-side rim (+Y)
rim_top_base = box.BoundingBox().zmax
notch_b = (cq.Workplane("XY").workplane(offset=50.6 - NOTCH_D).center(0, HY + 3)
           .rect(NOTCH_W, 14).extrude(20).edges("|Y").fillet(2.5))
base = base.cut(win).cut(vents).cut(notch_b)

# lid-stop brackets behind the hinge so the screen stays up at ~110 deg
YB, ZB = HY + 7.86, 32.4 + DZ
STOP_REACH, STOP_TOP = 12.0, 1.4
prof = [(HY + 1.9, ZB - 20), (YB + STOP_REACH, ZB - 20 + (YB + STOP_REACH - HY - 1.9)),
        (YB + STOP_REACH, ZB + STOP_TOP), (HY + 5.0, ZB + STOP_TOP), (HY + 5.0, ZB - 4.5), (HY + 1.9, ZB - 4.5)]
for sx in (-1, 1):
    blk = cq.Workplane("YZ").workplane(offset=sx * 27 - 6).polyline(prof).close().extrude(12)
    base = base.union(blk)

# deck plate
deck = rrect(IN_X - 2 * CLR, IN_Y - 2 * CLR, R_IN - CLR, DECK_T, 0)
kbw, kbh = KB[0] + 2 * KB_CLR, KB[1] + 2 * KB_CLR
kb_cy = -4.0
rim = rrect(kbw + 4, kbh + 4, 3, KB_RIM, DECK_T, 0, kb_cy).cut(rrect(kbw, kbh, 2, KB_RIM + 1, DECK_T - 0.5, 0, kb_cy))
deck = deck.union(rim)
# finger notches front edge + cable cutout at hinge edge
for fx in (-HX * 0.55, HX * 0.55):
    deck = deck.cut(cq.Workplane("XY").workplane(offset=-1).center(fx, -HY).circle(11).extrude(10))
deck = deck.cut(cq.Workplane("XY").workplane(offset=-1).center(-HX + 1 + 52, HY).rect(34, 22).extrude(10)
                .edges("|Z").fillet(3))
# vent slots in deck over the Pi area (under keyboard) and over bank
for i in range(7):
    deck = deck.cut(slot(30, 3.0, 10, -1, -HX + 22 + i * 9, kb_cy + 25, 90))
deck = deck.cut(slot(30, 3.0, 10, -1, 0, 0, 0)) if False else deck

# ---------------- lid internals ----------------
lidw = cq.Workplane().add(lid)
post_pts = [(sx * (HX - 5.0), sy * (HY - 5.0)) for sx in (-1, 1) for sy in (-1, 1)]
post_h = PLATE_TOP - PLATE_T
for (x, y) in post_pts:
    p = (cq.Workplane("XY").workplane(offset=FLOOR - 0.5).center(x, y).circle(5.5).extrude(post_h - FLOOR + 0.5)
         .faces(">Z").workplane().hole(2.6, 12))
    lidw = lidw.union(p)
# cable notch on lid hinge side (-Y)
notch_l = (cq.Workplane("XY").workplane(offset=PLATE_TOP + 0.6 - NOTCH_D + 3.6 if False else 25.8 - NOTCH_D).center(0, -HY - 3)
           .rect(NOTCH_W, 14).extrude(20).edges("|Y").fillet(2.5))
lidw = lidw.cut(notch_l)

# display bezel plate (modelled face-down: face on z=0, pocket opens to +z)
pw, ph = D["panel"][0] + 0.8, D["panel"][1] + 0.8
aw, ah = D["active"][0] + 1.0, D["active"][1] + 1.0
plate = rrect(IN_X - 2 * CLR, IN_Y - 2 * CLR, R_IN - CLR, PLATE_T, 0)
plate = plate.cut(rrect(pw, ph, 1.0, PLATE_POCKET + 1, PLATE_FACE))
plate = plate.cut(cq.Workplane("XY").workplane(offset=-0.01).rect(aw + 2 * PLATE_FACE, ah + 2 * PLATE_FACE)
                  .workplane(offset=PLATE_FACE + 0.02).rect(aw, ah).loft())
for (x, y) in post_pts:
    plate = plate.cut(cq.Workplane("XY").workplane(offset=-1).center(x, y).circle(1.7).extrude(10))
    plate = plate.cut(cq.Workplane("XY").workplane(offset=-0.01).center(x, y).circle(3.2).workplane(offset=1.6).circle(1.7).loft())
# cable notch in plate edge (hinge side, -Y in lid frame)
plate = plate.cut(cq.Workplane("XY").workplane(offset=-1).center(0, -HY).rect(NOTCH_W + 6, 2 * 9).extrude(10)
                  .edges("|Z").fillet(2))
# cable channel from panel pocket to notch on the back
plate = plate.cut(cq.Workplane("XY").workplane(offset=PLATE_FACE).center(0, -(ph / 2 + HY) / 2)
                  .rect(NOTCH_W, HY - ph / 2 + 1).extrude(10))

# ---------------- export ----------------
def exp(w, name):
    shp = w if isinstance(w, cq.Shape) else w.val() if len(w.vals()) == 1 else cq.Compound.makeCompound(w.vals())
    sols = shp.Solids()
    print(name, "solids:", len(sols), "valid:", shp.isValid(), "bbox:",
          [round(v, 1) for v in (shp.BoundingBox().xlen, shp.BoundingBox().ylen, shp.BoundingBox().zlen)])
    cq.exporters.export(cq.Workplane().add(shp), f"{OUT}/{name}.stl", tolerance=0.03, angularTolerance=0.15)
    cq.exporters.export(cq.Workplane().add(shp), f"{OUT}/{name}.step")
    return shp

b = exp(base, f"cyberdeck{VARIANT}-base")
l = exp(lidw, f"cyberdeck{VARIANT}-lid")
d = exp(deck, f"cyberdeck{VARIANT}-deck")
p = exp(plate, f"cyberdeck{VARIANT}-display-bezel")
cq.exporters.export(cq.Workplane().add(latch0.translate(-latch0.Center())), f"{OUT}/cyberdeck-latch-x2.stl", tolerance=0.03, angularTolerance=0.15)

json.dump(dict(IN_X=IN_X, IN_Y=IN_Y, DECK_Z=DECK_Z, DECK_T=DECK_T, PLATE_TOP=PLATE_TOP, PLATE_T=PLATE_T,
               PI=[PI_X0, PI_Y0, PI_Y1], kb_cy=kb_cy), open(f"{OUT}/params.json", "w"))
