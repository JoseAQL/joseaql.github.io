import cadquery as cq
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common

BIG = 1000.0


def halfspace(axis, pos, side):
    lo = [-BIG / 2] * 3
    size = [BIG] * 3
    if side < 0:
        lo[axis] = pos - BIG
    else:
        lo[axis] = pos
    size[axis] = BIG
    return cq.Solid.makeBox(*size, cq.Vector(*lo))


def section_faces(sol, axis, pos):
    n = [0, 0, 0]; n[axis] = 1
    o = [0, 0, 0]; o[axis] = pos
    plane = cq.Face.makePlane(BIG, BIG, cq.Vector(*o), cq.Vector(*n))
    return sol.intersect(plane).Faces()


def stretch(sol, axis, pos, L):
    if L == 0:
        return sol
    a = sol.intersect(halfspace(axis, pos, -1))
    b = sol.intersect(halfspace(axis, pos, +1))
    d = [0, 0, 0]; d[axis] = L
    b = b.translate(cq.Vector(*d))
    mids = [cq.Solid.extrudeLinear(f, cq.Vector(*d)) for f in section_faces(sol, axis, pos)]
    res = a.fuse(b, *mids).clean()
    sols = res.Solids()
    assert len(sols) == 1, len(sols)
    return sols[0]
