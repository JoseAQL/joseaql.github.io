# Cyberdeck Rugged Box: Raspberry Pi 4B + pantalla + teclado

Carcasa tipo cyberdeck imprimible en 3D para una **Raspberry Pi 4B**, una **pantalla HDMI de 5" o 7"**,
un **teclado Rii mini i8** y una **power bank** interna.

Es un remix del [**Rugged Box (Parametric)**](https://www.printables.com/model/258431-rugged-box-parametric) de **Whity**.
El diseño original es suyo.

![Versión 7" abierta](imagenes/prev7_abierta.png)

| Cerrada | Interior (sin bandeja) | Versión 5" |
|---|---|---|
| ![](imagenes/prev7_cerrada.png) | ![](imagenes/interior7.png) | ![](imagenes/prev5_abierta.png) |

## Versiones del diseño

| Versión | Cambios |
|---|---|
| v1 | Primera versión: caja estirada, Pi 4B + power bank, bandeja para el Rii i8, marco de pantalla de 5" y 7", muesca de cable y topes de bisagra. |

## Qué cambia respecto al original

La caja y la tapa son el diseño v2 de Whity, estirado solo en sus zonas rectas. Las bisagras, los latches,
los ribs y la ranura del borde siguen iguales, así que los latches y tornillos originales siguen sirviendo. Se agregó:

- Postes para la Raspberry Pi 4B y una ventana para sus USB y su Ethernet.
- Hueco para la power bank y rejillas de ventilación en el piso.
- Una ceja perimetral y una **bandeja removible** con bolsillo para el teclado.
- Postes en la tapa y un **marco atornillable** para la pantalla.
- Una muesca de paso de cable junto a la bisagra.
- **Topes de bisagra**: la tapa se queda abierta a ~110°, como laptop.

## Tamaños

| Carpeta | Pantalla | Medidas exteriores (cerrada) |
|---|---|---|
| `pantalla-7in` | HDMI 7" genérica 1024x600 (panel 164.9 x 100 mm) | 182.5 x 183 x ~73 mm |
| `pantalla-5in` | HDMI 5" genérica 800x480 (panel 121 x 76 mm) | 168.5 x 183 x ~73 mm |

Todas las piezas caben en una cama de 235 x 235 mm.

## Piezas para imprimir

Están en `stl/` (y en STEP en `step/`):

| Archivo | Cant. | Orientación | Notas |
|---|---|---|---|
| `cyberdeckN-base.stl` | 1 | Como viene (piso abajo) | Soportes solo en la ventana de puertos |
| `cyberdeckN-lid.stl` | 1 | Como viene (piso abajo) | |
| `cyberdeckN-deck.stl` | 1 | Como viene | Bandeja del teclado |
| `cyberdeckN-display-bezel.stl` | 1 | Cara plana en la cama | Marco de la pantalla |
| `comunes/latch-imprimir-x2.stl` | 2 | Como viene | Latch original de Whity |

Sugerencia: PLA o PETG, 3-4 perímetros, 15-20 % de relleno.

## Componentes y tornillería

- Raspberry Pi 4B (con disipadores pasivos)
- Pantalla HDMI de 5" o 7"
- Teclado Rii mini i8 (146 x 95 mm, hasta 24 mm de alto)
- Power bank de **máx. 150 x 70 x 17 mm**
- Cable HDMI **plano tipo ribbon/FPV** (micro-HDMI a HDMI). Un cable normal no cabe por la muesca.
- Cable USB-A a USB-C corto (power bank a Pi) y USB a micro-USB corto (pantalla)
- 6 x M3x30: 2 para las bisagras y 4 para los latches
- 4 x M3x8 autorroscante, cabeza avellanada: marco de la pantalla
- 4 x M2.5x6 autorroscante o insertos: Raspberry Pi

## Ajustar a tu pantalla

Las pantallas genéricas varían. Mide el vidrio de tu panel y el área visible, y cambia `DISPLAYS` en `src/build.py`.
Ahí también están las medidas del teclado, de la power bank y la altura.

```bash
pip install cadquery
cd src
python build.py 7   # o 5 -> genera out7/ con STL y STEP
python check.py 7   # revisa interferencias y el ángulo de apertura
```

## Advertencias

- **Ya no es hermética**: la ventana de puertos y la muesca del cable rompen el sello. No uses el sello de TPU.
- La Pi va bajo la bandeja. Para trabajo pesado deja la tapa abierta o agrega un ventilador.
- Para cambiar la microSD hay que quitar la bandeja.

## Licencia

Este remix y el modelo original están bajo **CC BY-NC-SA 4.0**:
uso **no comercial**, dando crédito a **Whity** y compartiendo bajo la misma licencia.
Ver [LICENSE](LICENSE).
