#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
using namespace std;

// ============================================================
// ABRIR PUERTO SERIAL
// ============================================================
int abrirSerial(const char* puerto) {
    int fd = open(puerto, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) { cerr << "[ERROR] No se pudo abrir " << puerto << endl; return -1; }

    struct termios tty;
    tcgetattr(fd, &tty);
    cfsetospeed(&tty, B9600);
    cfsetispeed(&tty, B9600);
    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_iflag &= ~IGNBRK;
    tty.c_lflag = 0;
    tty.c_oflag = 0;
    tty.c_cc[VMIN]  = 1;
    tty.c_cc[VTIME] = 5;
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~(PARENB | PARODD);
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;
    tcsetattr(fd, TCSANOW, &tty);
    return fd;
}

void enviar(int fd, const unsigned char* data, int len) {
    write(fd, data, len);
    usleep(50000);
}

void enviarTexto(int fd, const char* texto) {
    write(fd, texto, strlen(texto));
    usleep(50000);
}

// ============================================================
// IMPRIMIR QR por texto (modo QR nativo ESC/POS)
// ============================================================
void imprimirQR(int fd, const char* url) {
    int len = strlen(url);

    // Tamaño del QR
    unsigned char qr_size[] = {0x1d, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x43, 0x06};
    enviar(fd, qr_size, sizeof(qr_size));

    // Nivel de corrección
    unsigned char qr_level[] = {0x1d, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x45, 0x31};
    enviar(fd, qr_level, sizeof(qr_level));

    // Datos del QR
    int pL = (len + 3) % 256;
    int pH = (len + 3) / 256;
    unsigned char qr_data_header[] = {0x1d, 0x28, 0x6b, (unsigned char)pL, (unsigned char)pH, 0x31, 0x50, 0x30};
    enviar(fd, qr_data_header, sizeof(qr_data_header));
    write(fd, url, len);
    usleep(100000);

    // Imprimir QR
    unsigned char qr_print[] = {0x1d, 0x28, 0x6b, 0x03, 0x00, 0x31, 0x51, 0x30};
    enviar(fd, qr_print, sizeof(qr_print));
    usleep(500000);
}

// ============================================================
// MAIN
// ============================================================
int main() {
    int fd = abrirSerial("/dev/ttyUSB0");
    if (fd < 0) return -1;

    // Inicializar
    unsigned char init[] = {0x1b, 0x40};
    enviar(fd, init, 2);

    // Centrar
    unsigned char center[] = {0x1b, 0x61, 0x01};
    enviar(fd, center, 3);

    // Texto grande
    unsigned char big[] = {0x1b, 0x21, 0x30};
    enviar(fd, big, 3);
    enviarTexto(fd, "PARCIAL 3\n");

    // Texto normal
    unsigned char normal[] = {0x1b, 0x21, 0x00};
    enviar(fd, normal, 3);
    enviarTexto(fd, "========================\n");

    // Negrita ON
    unsigned char bold_on[] = {0x1b, 0x45, 0x01};
    enviar(fd, bold_on, 3);
    enviarTexto(fd, "  DETECCION KINECT\n");

    // Negrita OFF
    unsigned char bold_off[] = {0x1b, 0x45, 0x00};
    enviar(fd, bold_off, 3);
    enviarTexto(fd, "========================\n");
    enviarTexto(fd, "\n");

    // Imprimir QR
    imprimirQR(fd, "https://es.aliexpress.com/item/1005007855703624.html");

    enviarTexto(fd, "\n");
    enviarTexto(fd, "aliexpress.com\n");
    enviarTexto(fd, "\n\n\n");

    close(fd);
    cout << "Listo! Impreso!" << endl;
    return 0;
}
