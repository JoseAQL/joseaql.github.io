// DETECCION_V1.cpp
// C++ + freenect + MediaPipe Pose + MediaPipe Hands via Python C API
// Layout 2x2:
//   [MANOS landmarks]  [DEPTH distancia]
//   [CUERPO esqueleto] [INFO + POSTURAS]
//
// Compilar:
//   g++ DETECCION_V1.cpp -o deteccion_v1 \
//       $(pkg-config --cflags --libs opencv4 libfreenect) \
//       $(python3-config --includes --ldflags) \
//       -lpython3.9 -pthread -lm
// Correr: ./deteccion_v1

#include <libfreenect.h>
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <Python.h>
#include <iostream>
#include <mutex>
#include <thread>
#include <atomic>
#include <fstream>
#include <vector>
#include <cmath>
#include <ctime>

using namespace std;
using namespace cv;
using namespace cv::dnn;

// ── Globals Kinect ───────────────────────────────────────────────────────────
Mat frame_actual, depth_actual;
mutex frame_mutex, depth_mutex;
atomic<bool> nuevo_frame(false), nuevo_depth(false), ejecutando(true);
freenect_context *f_ctx;

void video_callback(freenect_device *dev, void *rgb, uint32_t timestamp) {
    lock_guard<mutex> lock(frame_mutex);
    Mat temp(480, 640, CV_8UC3, rgb);
    Mat bgr; cvtColor(temp, bgr, COLOR_RGB2BGR);
    flip(bgr, frame_actual, 1);
    nuevo_frame = true;
}

void depth_callback(freenect_device *dev, void *v_depth, uint32_t timestamp) {
    lock_guard<mutex> lock(depth_mutex);
    uint16_t *d = (uint16_t*)v_depth;
    Mat dm(480, 640, CV_16UC1, d);
    Mat d8; dm.convertTo(d8, CV_8UC1, 255.0/2048.0);
    flip(d8, depth_actual, 1);
    nuevo_depth = true;
}

void freenect_loop() {
    while (ejecutando && freenect_process_events(f_ctx) >= 0) {}
}

float obtener_temp() {
    ifstream f("/sys/class/thermal/thermal_zone0/temp");
    float t=0; if(f.is_open()){f>>t;t/=1000.0;} return t;
}

// ── Captura mouse ────────────────────────────────────────────────────────────
bool captura_pendiente = false;
void mouse_cb(int event, int, int, int, void*) {
    if (event == EVENT_LBUTTONDOWN) captura_pendiente = true;
}

// ════════════════════════════════════════════════════════════════════════════
//  PYTHON C API — MediaPipe Pose + Hands
// ════════════════════════════════════════════════════════════════════════════
PyObject *py_procesar = nullptr;

const char* CODIGO_PYTHON = R"PYCODE(
import mediapipe as mp
import numpy as np

mp_pose  = mp.solutions.pose
mp_hands = mp.solutions.hands

pose_detector = mp_pose.Pose(
    static_image_mode=False,
    model_complexity=0,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)
hands_detector = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.6,
    min_tracking_confidence=0.5
)

TIPS = [4, 8, 12, 16, 20]
PIPS = [3, 6, 10, 14, 18]

def clasificar_mano(landmarks):
    pts = [(lm.x, lm.y) for lm in landmarks]
    dedos = [pts[4][0] < pts[3][0]]
    for tip,pip in zip(TIPS[1:], PIPS[1:]):
        dedos.append(pts[tip][1] < pts[pip][1])
    n = sum(dedos)
    p,i,m,a,me = dedos
    if n==0:                              return "CERRADA", n
    if n==5:                              return "ABIERTA", n
    if i and not m and not a and not me:  return "1-INDICE", n
    if i and m and not a and not me:      return "2-PAZ", n
    if i and m and a and not me:          return "3-TRES", n
    if i and m and a and me:              return "4-CUATRO", n
    if p and not i and not m and not a and not me: return "PULGAR", n
    if me and not i and not m and not a:  return "MENIQUE", n
    if p and me and not i and not m and not a: return "ROCK", n
    return f"{n} dedos", n

def calcular_angulo(a, b, c):
    """Angulo en el punto b entre segmentos ba y bc"""
    a = np.array(a); b = np.array(b); c = np.array(c)
    ba = a - b; bc = c - b
    cos = np.dot(ba,bc)/(np.linalg.norm(ba)*np.linalg.norm(bc)+1e-6)
    return np.degrees(np.arccos(np.clip(cos,-1,1)))

def detectar_postura(lm):
    """
    Detecta posturas usando angulos de articulaciones.
    lm = lista de 33 landmarks (x,y,z,visibility)
    """
    def pt(i): return [lm[i][0], lm[i][1]]

    # Landmarks clave
    nariz     = pt(0)
    hombro_i  = pt(11); hombro_d  = pt(12)
    codo_i    = pt(13); codo_d    = pt(14)
    muno_i    = pt(15); muno_d    = pt(16)
    cadera_i  = pt(23); cadera_d  = pt(24)
    rodilla_i = pt(25); rodilla_d = pt(26)
    tobillo_i = pt(27); tobillo_d = pt(28)

    # Angulos
    ang_rodilla_i = calcular_angulo(cadera_i, rodilla_i, tobillo_i)
    ang_rodilla_d = calcular_angulo(cadera_d, rodilla_d, tobillo_d)
    ang_codo_i    = calcular_angulo(hombro_i, codo_i, muno_i)
    ang_codo_d    = calcular_angulo(hombro_d, codo_d, muno_d)
    ang_cadera_i  = calcular_angulo(hombro_i, cadera_i, rodilla_i)
    ang_cadera_d  = calcular_angulo(hombro_d, cadera_d, rodilla_d)

    # Posiciones relativas
    brazos_arriba   = muno_i[1] < hombro_i[1] and muno_d[1] < hombro_d[1]
    brazos_lados    = (abs(muno_i[1]-hombro_i[1])<0.15 and
                       abs(muno_d[1]-hombro_d[1])<0.15)
    piernas_abiertas = abs(tobillo_i[0]-tobillo_d[0]) > 0.3
    cuerpo_bajo     = cadera_i[1] > 0.7 and cadera_d[1] > 0.7
    rodillas_dobladas = ang_rodilla_i < 120 and ang_rodilla_d < 120
    cuerpo_horizontal = abs(hombro_i[1]-cadera_i[1]) < 0.15

    # ── Detectar posturas ────────────────────────────────────────────────────
    # PORTERIA: brazos extendidos a los lados + piernas abiertas
    if brazos_lados and piernas_abiertas and not rodillas_dobladas:
        return "PORTERIA", (0,255,255)

    # SALTO: brazos arriba + piernas juntas o extendidas
    if brazos_arriba and not cuerpo_bajo:
        return "SALTO", (0,255,0)

    # LAGARTIJA: cuerpo horizontal + codos doblados
    if cuerpo_horizontal and ang_codo_i < 120 and ang_codo_d < 120:
        return "LAGARTIJA", (0,165,255)

    # SENTADO: caderas bajas + rodillas dobladas
    if cuerpo_bajo and rodillas_dobladas:
        return "SENTADO", (255,200,0)

    # PARADO: piernas rectas + cuerpo vertical
    if ang_rodilla_i > 160 and ang_rodilla_d > 160:
        return "PARADO", (200,200,200)

    return "DETECTANDO...", (100,100,100)

def procesar_frame(frame_bytes, width, height):
    """
    Retorna dict con:
      - manos: lista de [gesto, n_dedos, lm0x,lm0y,...,lm20x,lm20y]
      - pose:  lista de 33*4 floats (x,y,z,vis) o vacia
      - postura: string
      - color_postura: [r,g,b]
      - dist_persona: float (de MobileNet, 0 si no hay)
    """
    arr = np.frombuffer(frame_bytes, dtype=np.uint8).reshape((height,width,3))
    rgb = arr[:,:,::-1].copy()

    # ── Manos ────────────────────────────────────────────────────────────────
    res_hands = hands_detector.process(rgb)
    manos_out = []
    if res_hands.multi_hand_landmarks:
        for hlm in res_hands.multi_hand_landmarks:
            gesto, n = clasificar_mano(hlm.landmark)
            fila = [gesto, n]
            for lm in hlm.landmark:
                fila.append(lm.x); fila.append(lm.y)
            manos_out.append(fila)

    # ── Pose ─────────────────────────────────────────────────────────────────
    res_pose = pose_detector.process(rgb)
    pose_out = []
    postura  = "Sin persona"
    col_pos  = [100,100,100]
    if res_pose.pose_landmarks:
        lm_list = []
        for lm in res_pose.pose_landmarks.landmark:
            pose_out.extend([lm.x, lm.y, lm.z, lm.visibility])
            lm_list.append([lm.x, lm.y, lm.z, lm.visibility])
        postura, (r,g,b) = detectar_postura(lm_list)
        col_pos = [r,g,b]

    return {
        'manos':         manos_out,
        'pose':          pose_out,
        'postura':       postura,
        'color_postura': col_pos
    }
)PYCODE";

bool iniciar_python() {
    Py_Initialize();
    PyRun_SimpleString(CODIGO_PYTHON);
    PyObject *m = PyImport_AddModule("__main__");
    py_procesar = PyObject_GetAttrString(m, "procesar_frame");
    if (!py_procesar || !PyCallable_Check(py_procesar)) {
        cerr << "[ERROR] No se pudo obtener procesar_frame\n";
        return false;
    }
    cout << "[OK] MediaPipe Pose + Hands via Python C API\n";
    return true;
}

// ── Estructuras de resultado ──────────────────────────────────────────────────
struct LM2D { float x, y; };
struct ResultMano {
    string gesto; int n_dedos;
    vector<LM2D> lm; // 21 puntos
    Scalar color;
};
struct ResultPose {
    vector<LM2D> lm; // 33 puntos
    string postura;
    Scalar color_postura;
};

struct ResultadoFrame {
    vector<ResultMano> manos;
    ResultPose pose;
};

ResultadoFrame llamar_python(const Mat& frame) {
    ResultadoFrame res;
    if (!py_procesar) return res;
    int h=frame.rows, w=frame.cols;
    PyObject *pb = PyBytes_FromStringAndSize((const char*)frame.data, h*w*3);
    PyObject *pw = PyLong_FromLong(w);
    PyObject *ph = PyLong_FromLong(h);
    PyObject *ret = PyObject_CallFunctionObjArgs(py_procesar,pb,pw,ph,nullptr);
    Py_DECREF(pb); Py_DECREF(pw); Py_DECREF(ph);
    if (!ret) { PyErr_Print(); return res; }

    // ── Parsear manos ─────────────────────────────────────────────────────────
    PyObject *py_manos = PyDict_GetItemString(ret, "manos");
    for (Py_ssize_t i=0; i<PyList_Size(py_manos); i++) {
        PyObject *m = PyList_GetItem(py_manos, i);
        ResultMano rm;
        rm.gesto   = PyUnicode_AsUTF8(PyList_GetItem(m,0));
        rm.n_dedos = (int)PyLong_AsLong(PyList_GetItem(m,1));
        for (int j=0;j<21;j++) {
            LM2D p;
            p.x=(float)PyFloat_AsDouble(PyList_GetItem(m,2+j*2));
            p.y=(float)PyFloat_AsDouble(PyList_GetItem(m,2+j*2+1));
            rm.lm.push_back(p);
        }
        if      (rm.gesto=="ABIERTA")  rm.color=Scalar(0,255,0);
        else if (rm.gesto=="CERRADA")  rm.color=Scalar(0,0,255);
        else if (rm.gesto=="2-PAZ")    rm.color=Scalar(255,200,0);
        else                            rm.color=Scalar(0,200,255);
        res.manos.push_back(rm);
    }

    // ── Parsear pose ──────────────────────────────────────────────────────────
    PyObject *py_pose = PyDict_GetItemString(ret, "pose");
    Py_ssize_t np = PyList_Size(py_pose);
    for (Py_ssize_t i=0; i<np; i+=4) {
        LM2D p;
        p.x=(float)PyFloat_AsDouble(PyList_GetItem(py_pose,i));
        p.y=(float)PyFloat_AsDouble(PyList_GetItem(py_pose,i+1));
        res.pose.lm.push_back(p);
    }

    // ── Postura ───────────────────────────────────────────────────────────────
    res.pose.postura = PyUnicode_AsUTF8(PyDict_GetItemString(ret,"postura"));
    PyObject *pc = PyDict_GetItemString(ret,"color_postura");
    int r=(int)PyLong_AsLong(PyList_GetItem(pc,0));
    int g=(int)PyLong_AsLong(PyList_GetItem(pc,1));
    int b=(int)PyLong_AsLong(PyList_GetItem(pc,2));
    res.pose.color_postura = Scalar(b,g,r);

    Py_DECREF(ret);
    return res;
}

// ── Conexiones del esqueleto MediaPipe Pose ──────────────────────────────────
const vector<pair<int,int>> POSE_CONEX = {
    {11,12},{11,13},{13,15},{12,14},{14,16}, // brazos
    {11,23},{12,24},{23,24},                 // torso
    {23,25},{25,27},{24,26},{26,28},         // piernas
    {27,29},{27,31},{28,30},{28,32}          // pies
};

// Colores por segmento
const vector<Scalar> POSE_COLS = {
    Scalar(255,100,100),Scalar(255,100,100),Scalar(255,100,100),
    Scalar(100,100,255),Scalar(100,100,255),
    Scalar(100,255,100),Scalar(100,255,100),Scalar(100,255,100),
    Scalar(0,255,255),Scalar(0,255,255),Scalar(0,255,255),Scalar(0,255,255),
    Scalar(200,200,0),Scalar(200,200,0),Scalar(200,200,0),Scalar(200,200,0)
};

// Conexiones mano
const vector<pair<int,int>> HAND_CONEX = {
    {0,1},{1,2},{2,3},{3,4},
    {0,5},{5,6},{6,7},{7,8},
    {0,9},{9,10},{10,11},{11,12},
    {0,13},{13,14},{14,15},{15,16},
    {0,17},{17,18},{18,19},{19,20},
    {5,9},{9,13},{13,17}
};

const int TIPS_IDS[] = {4,8,12,16,20};
const int PIPS_IDS[] = {3,6,10,14,18};

void dibujar_mano(Mat& panel, const ResultMano& rm, int w, int h) {
    if (rm.lm.size()<21) return;
    // Conexiones
    for (auto& c:HAND_CONEX) {
        Point p1(rm.lm[c.first].x*w, rm.lm[c.first].y*h);
        Point p2(rm.lm[c.second].x*w,rm.lm[c.second].y*h);
        line(panel,p1,p2,Scalar(255,180,0),2);
    }
    // Landmarks
    for (int i=0;i<21;i++) {
        Point p(rm.lm[i].x*w,rm.lm[i].y*h);
        circle(panel,p,4,Scalar(0,200,255),-1);
    }
    // Puntas dedos
    for (int j=0;j<5;j++) {
        int tip=TIPS_IDS[j],pip=PIPS_IDS[j];
        bool ext = (tip==4) ? rm.lm[tip].x<rm.lm[pip].x
                            : rm.lm[tip].y<rm.lm[pip].y;
        Point p(rm.lm[tip].x*w,rm.lm[tip].y*h);
        circle(panel,p,8,ext?Scalar(0,255,0):Scalar(0,0,255),-1);
        circle(panel,p,9,Scalar(255,255,255),1);
    }
    // Etiqueta
    string label=rm.gesto+" ("+to_string(rm.n_dedos)+" dedos)";
    float xmn=1,ymn=1,xmx=0,ymx=0;
    for(auto&l:rm.lm){xmn=min(xmn,l.x);ymn=min(ymn,l.y);
                       xmx=max(xmx,l.x);ymx=max(ymx,l.y);}
    Point org(max((int)(xmn*w)-5,0),max((int)(ymn*h)-8,15));
    int bl=0; Size ts=getTextSize(label,FONT_HERSHEY_DUPLEX,0.55,2,&bl);
    rectangle(panel,Point(org.x-2,org.y-ts.height-4),
              Point(org.x+ts.width+2,org.y+4),Scalar(0,0,0),FILLED);
    putText(panel,label,org,FONT_HERSHEY_DUPLEX,0.55,rm.color,2);
}

void dibujar_pose(Mat& panel, const ResultPose& rp, int w, int h) {
    if (rp.lm.size()<33) return;
    // Conexiones coloreadas
    for (int i=0;i<(int)POSE_CONEX.size();i++) {
        auto& c=POSE_CONEX[i];
        Point p1(rp.lm[c.first].x*w, rp.lm[c.first].y*h);
        Point p2(rp.lm[c.second].x*w,rp.lm[c.second].y*h);
        Scalar col = i<(int)POSE_COLS.size()?POSE_COLS[i]:Scalar(200,200,200);
        line(panel,p1,p2,col,3);
    }
    // Puntos articulaciones
    for (int i=11;i<33;i++) { // solo cuerpo, no cara
        Point p(rp.lm[i].x*w,rp.lm[i].y*h);
        circle(panel,p,6,Scalar(255,255,255),-1);
        circle(panel,p,7,Scalar(0,0,0),1);
    }
}

// ════════════════════════════════════════════════════════════════════════════
int main() {
    if (!iniciar_python()) return -1;

    freenect_device *f_dev;
    if(freenect_init(&f_ctx,NULL)<0) return -1;
    freenect_set_log_level(f_ctx,FREENECT_LOG_WARNING);
    if(freenect_open_device(f_ctx,&f_dev,0)<0){
        freenect_shutdown(f_ctx); return -1;
    }
    freenect_set_video_mode(f_dev,
        freenect_find_video_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_VIDEO_RGB));
    freenect_set_video_callback(f_dev,video_callback);
    freenect_start_video(f_dev);
    freenect_set_depth_mode(f_dev,
        freenect_find_depth_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_DEPTH_11BIT));
    freenect_set_depth_callback(f_dev,depth_callback);
    freenect_start_depth(f_dev);
    thread kinect_thread(freenect_loop);

    // ── MobileNet SSD ─────────────────────────────────────────────────────────
    Net ssd_net; bool ok_ssd=false;
    try {
        ssd_net=readNetFromCaffe("MobileNetSSD_deploy.prototxt",
                                  "MobileNetSSD_deploy.caffemodel");
        ssd_net.setPreferableBackend(DNN_BACKEND_OPENCV);
        ssd_net.setPreferableTarget(DNN_TARGET_CPU);
        ok_ssd=true; cout<<"[OK] MobileNet SSD\n";
    } catch(...){ cout<<"[WARN] Sin MobileNet\n"; }

    namedWindow("DETECCION V1 - UAA", WINDOW_AUTOSIZE);
    setMouseCallback("DETECCION V1 - UAA", mouse_cb);
    cout<<"CLIC o C=captura | ESC=salir\n";

    int fc=0; const int SSD_C=20;
    float dist_persona=0;
    Mat ultimo;

    while(ejecutando){
        Mat rgb_raw,depth_raw;
        {lock_guard<mutex> lk(frame_mutex);
         if(nuevo_frame){rgb_raw=frame_actual.clone();nuevo_frame=false;}}
        {lock_guard<mutex> lk(depth_mutex);
         if(nuevo_depth){depth_raw=depth_actual.clone();nuevo_depth=false;}}
        if(rgb_raw.empty()){waitKey(10);continue;}

        Mat rgb,depth_small;
        resize(rgb_raw,rgb,Size(320,240));
        if(!depth_raw.empty()) resize(depth_raw,depth_small,Size(320,240));

        // ── MobileNet distancia persona ───────────────────────────────────────
        fc++;
        if(ok_ssd && fc%SSD_C==0 && !depth_small.empty()){
            Mat blob=blobFromImage(rgb,0.007843f,Size(300,300),127.5f);
            ssd_net.setInput(blob);
            Mat det=ssd_net.forward();
            Mat dm(det.size[2],det.size[3],CV_32F,det.ptr<float>());
            for(int i=0;i<dm.rows;i++){
                if((int)dm.at<float>(i,1)!=15||dm.at<float>(i,2)<0.45f) continue;
                int x1=max((int)(dm.at<float>(i,3)*320),0);
                int y1=max((int)(dm.at<float>(i,4)*240),0);
                int x2=min((int)(dm.at<float>(i,5)*320),319);
                int y2=min((int)(dm.at<float>(i,6)*240),239);
                if(x2<=x1||y2<=y1) continue;
                Mat roi=depth_small(Rect(x1,y1,x2-x1,y2-y1));
                Scalar m=mean(roi,roi>2);
                dist_persona=(float)(m[0]*2048.0/255.0/10.0);
                break;
            }
        }

        // ── Llamar MediaPipe ──────────────────────────────────────────────────
        ResultadoFrame res = llamar_python(rgb);

        // ════════════════════════════════════════════════════════════════════
        // PANEL 1: MANOS (arriba izquierda)
        // ════════════════════════════════════════════════════════════════════
        Mat panel_manos = rgb.clone();
        if(res.manos.empty()){
            putText(panel_manos,"Sin mano",Point(80,120),
                    FONT_HERSHEY_DUPLEX,0.8,Scalar(100,100,100),2);
        }
        for(auto& rm:res.manos)
            dibujar_mano(panel_manos,rm,320,240);

        // Barra gesto arriba
        rectangle(panel_manos,Point(0,0),Point(320,42),Scalar(0,0,0),FILLED);
        if(!res.manos.empty()){
            string g=res.manos[0].gesto+" ("+to_string(res.manos[0].n_dedos)+" ded)";
            putText(panel_manos,g,Point(5,32),
                    FONT_HERSHEY_DUPLEX,0.7,res.manos[0].color,2);
        } else {
            putText(panel_manos,"MANOS",Point(5,32),
                    FONT_HERSHEY_SIMPLEX,0.7,Scalar(150,150,150),1);
        }

        // ════════════════════════════════════════════════════════════════════
        // PANEL 2: DEPTH (arriba derecha)
        // ════════════════════════════════════════════════════════════════════
        Mat panel_depth=Mat::zeros(Size(320,240),CV_8UC3);
        if(!depth_small.empty())
            applyColorMap(depth_small,panel_depth,COLORMAP_JET);
        // Distancia persona encima
        rectangle(panel_depth,Point(0,0),Point(320,42),Scalar(0,0,0),FILLED);
        char dbuf[50];
        if(dist_persona>5 && dist_persona<500)
            snprintf(dbuf,sizeof(dbuf),"PERSONA: %.0f cm",dist_persona);
        else
            snprintf(dbuf,sizeof(dbuf),"DEPTH");
        putText(panel_depth,dbuf,Point(5,32),
                FONT_HERSHEY_DUPLEX,0.7,Scalar(0,255,255),2);

        // ════════════════════════════════════════════════════════════════════
        // PANEL 3: CUERPO/POSE (abajo izquierda)
        // ════════════════════════════════════════════════════════════════════
        Mat panel_pose=Mat::zeros(Size(320,240),CV_8UC3);
        // Fondo oscuro para que se vea el esqueleto
        panel_pose.setTo(Scalar(30,30,30));
        dibujar_pose(panel_pose,res.pose,320,240);
        // Postura detectada
        rectangle(panel_pose,Point(0,0),Point(320,42),Scalar(0,0,0),FILLED);
        putText(panel_pose,res.pose.postura,Point(5,32),
                FONT_HERSHEY_DUPLEX,0.8,res.pose.color_postura,2);

        // ════════════════════════════════════════════════════════════════════
        // PANEL 4: INFO (abajo derecha)
        // ════════════════════════════════════════════════════════════════════
        Mat panel_info=Mat::zeros(Size(320,240),CV_8UC3);
        char buf[60];
        putText(panel_info,"DETECCION V1 UAA",Point(5,28),
                FONT_HERSHEY_DUPLEX,0.55,Scalar(255,255,255),1);
        rectangle(panel_info,Point(5,34),Point(315,36),Scalar(255,255,255),FILLED);

        snprintf(buf,sizeof(buf),"TEMP CPU: %.1f C",obtener_temp());
        putText(panel_info,buf,Point(10,58),FONT_HERSHEY_SIMPLEX,0.48,Scalar(0,255,0),1);

        if(dist_persona>5)
            snprintf(buf,sizeof(buf),"DISTANCIA: %.0f cm",dist_persona);
        else
            snprintf(buf,sizeof(buf),"DISTANCIA: --");
        putText(panel_info,buf,Point(10,78),FONT_HERSHEY_SIMPLEX,0.48,Scalar(0,255,255),1);

        // Gesto mano
        string gesto_info = res.manos.empty() ? "Sin mano" : res.manos[0].gesto;
        Scalar col_g = res.manos.empty() ? Scalar(100,100,100) :
                       res.manos[0].color;
        snprintf(buf,sizeof(buf),"MANO: %s",gesto_info.c_str());
        putText(panel_info,buf,Point(10,98),FONT_HERSHEY_SIMPLEX,0.48,col_g,1);

        // Postura
        snprintf(buf,sizeof(buf),"POSTURA: %s",res.pose.postura.c_str());
        putText(panel_info,buf,Point(10,118),
                FONT_HERSHEY_SIMPLEX,0.48,res.pose.color_postura,1);

        // Leyenda posturas
        putText(panel_info,"POSTURAS:",Point(10,148),
                FONT_HERSHEY_SIMPLEX,0.42,Scalar(200,200,200),1);
        putText(panel_info,"PARADO  SENTADO  SALTO",Point(10,166),
                FONT_HERSHEY_SIMPLEX,0.38,Scalar(180,180,180),1);
        putText(panel_info,"LAGARTIJA  PORTERIA",Point(10,182),
                FONT_HERSHEY_SIMPLEX,0.38,Scalar(180,180,180),1);

        // Leyenda manos
        putText(panel_info,"MANOS:",Point(10,205),
                FONT_HERSHEY_SIMPLEX,0.42,Scalar(200,200,200),1);
        putText(panel_info,"VERDE=ext ROJO=cerr CYAN=lm",Point(10,221),
                FONT_HERSHEY_SIMPLEX,0.36,Scalar(160,160,160),1);
        putText(panel_info,"CLIC/C=captura ESC=salir",Point(10,237),
                FONT_HERSHEY_SIMPLEX,0.36,Scalar(120,120,120),1);

        // ── Ensamblar 2x2 ─────────────────────────────────────────────────────
        Mat top,bot,combined;
        hconcat(panel_manos, panel_depth, top);
        hconcat(panel_pose,  panel_info,  bot);
        vconcat(top,bot,combined);
        ultimo=combined.clone();
        imshow("DETECCION V1 - UAA",combined);

        // ── Captura ───────────────────────────────────────────────────────────
        if(captura_pendiente){
            char fn[60];
            snprintf(fn,sizeof(fn),"captura_%ld.png",(long)time(nullptr));
            imwrite(fn,ultimo);
            cout<<"[CAPTURA] "<<fn<<"\n";
            captura_pendiente=false;
        }
        int key=waitKey(10);
        if(key==27){ejecutando=false;break;}
        if(key=='c'||key=='C'){
            char fn[60];
            snprintf(fn,sizeof(fn),"captura_%ld.png",(long)time(nullptr));
            imwrite(fn,ultimo);
            cout<<"[CAPTURA] "<<fn<<"\n";
        }
    }

    Py_XDECREF(py_procesar);
    Py_Finalize();
    freenect_stop_depth(f_dev);
    freenect_stop_video(f_dev);
    kinect_thread.join();
    freenect_close_device(f_dev);
    freenect_shutdown(f_ctx);
    destroyAllWindows();
    return 0;
}
