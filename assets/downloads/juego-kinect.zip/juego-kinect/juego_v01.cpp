#include <libfreenect.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <string>
#include <mutex>
#include <atomic>
#include <chrono>
#include <signal.h>

using namespace cv;
using namespace std;

#ifndef SIGQUIT
#define SIGQUIT SIGTERM
#endif

enum Pantalla {
    MENU,
    INSTRUCCIONES,
    RETO,
    PRUEBA_KINECT,
    CALIBRACION,
    RESULTADOS,
    SALIR
};

Pantalla pantallaActual = MENU;
int opcionActual = 0;

vector<string> opciones = {
    "Iniciar reto",
    "Instrucciones",
    "Probar Kinect",
    "Calibracion",
    "Resultados",
    "Salir"
};

volatile bool running = true;

Mat frameKinect;
mutex mutexFrame;
atomic<bool> hayFrame(false);

Mat fondoMovimiento;
int opcionAnteriorCamara = -1;
chrono::steady_clock::time_point tiempoSeleccion;
bool temporizadorActivo = false;

void signalHandler(int signal)
{
    if (signal == SIGINT || signal == SIGTERM || signal == SIGQUIT) {
        running = false;
    }
}

void depth_cb(freenect_device* dev, void* data, uint32_t timestamp)
{
    // Depth activo, pero por ahora no se usa en el menu
}

void video_cb(freenect_device* dev, void* data, uint32_t timestamp)
{
    Mat img_rgb(480, 640, CV_8UC3, data);
    Mat img_bgr;

    cvtColor(img_rgb, img_bgr, COLOR_RGB2BGR);

    lock_guard<mutex> lock(mutexFrame);
    frameKinect = img_bgr.clone();
    hayFrame = true;
}

void textoCentrado(Mat& img, const string& texto, int y, double escala, Scalar color, int grosor = 2)
{
    int baseline = 0;
    Size tam = getTextSize(texto, FONT_HERSHEY_SIMPLEX, escala, grosor, &baseline);
    int x = (img.cols - tam.width) / 2;
    putText(img, texto, Point(x, y), FONT_HERSHEY_SIMPLEX, escala, color, grosor, LINE_AA);
}

void panel(Mat& img, Rect r, Scalar color, Scalar borde)
{
    rectangle(img, r, color, FILLED);
    rectangle(img, r, borde, 2, LINE_AA);
}

void ejecutarOpcion()
{
    switch (opcionActual) {
        case 0: pantallaActual = RETO; break;
        case 1: pantallaActual = INSTRUCCIONES; break;
        case 2: pantallaActual = PRUEBA_KINECT; break;
        case 3: pantallaActual = CALIBRACION; break;
        case 4: pantallaActual = RESULTADOS; break;
        case 5: pantallaActual = SALIR; break;
    }
}

int detectarOpcionPorCamara(Mat& camara)
{
    if (camara.empty()) return opcionActual;

    Mat gris, suavizado, diferencia, binaria;
    cvtColor(camara, gris, COLOR_BGR2GRAY);
    GaussianBlur(gris, suavizado, Size(21, 21), 0);

    if (fondoMovimiento.empty()) {
        suavizado.copyTo(fondoMovimiento);
        return opcionActual;
    }

    absdiff(fondoMovimiento, suavizado, diferencia);
    threshold(diferencia, binaria, 30, 255, THRESH_BINARY);
    erode(binaria, binaria, Mat(), Point(-1, -1), 2);
    dilate(binaria, binaria, Mat(), Point(-1, -1), 2);

    vector<vector<Point>> contornos;
    findContours(binaria, contornos, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    double mayorArea = 0;
    Rect mejorRect;

    for (auto& c : contornos) {
        double area = contourArea(c);
        if (area > mayorArea) {
            mayorArea = area;
            mejorRect = boundingRect(c);
        }
    }

    if (mayorArea < 1200) {
        return opcionActual;
    }

    int centroY = mejorRect.y + mejorRect.height / 2;

    int nuevaOpcion = centroY / (camara.rows / opciones.size());
    if (nuevaOpcion < 0) nuevaOpcion = 0;
    if (nuevaOpcion >= (int)opciones.size()) nuevaOpcion = opciones.size() - 1;

    rectangle(camara, mejorRect, Scalar(0, 255, 0), 2);
    circle(camara, Point(mejorRect.x + mejorRect.width / 2, centroY), 8, Scalar(0, 255, 255), FILLED);

    return nuevaOpcion;
}

void dibujarMenu(Mat& img, Mat camara)
{
    img = Mat::zeros(720, 1280, CV_8UC3);
    img.setTo(Scalar(18, 18, 24));

    textoCentrado(img, "PUSH-UP VISION CHALLENGE", 85, 1.35, Scalar(255,255,255), 3);
    textoCentrado(img, "Sistema de conteo de lagartijas con Kinect", 130, 0.75, Scalar(0,220,220), 2);

    panel(img, Rect(70, 180, 470, 470), Scalar(28,28,38), Scalar(0,180,180));

    int x = 115;
    int y = 220;
    int ancho = 380;
    int alto = 55;
    int sep = 70;

    for (int i = 0; i < (int)opciones.size(); i++) {
        Scalar color = (i == opcionActual) ? Scalar(0,180,100) : Scalar(55,55,70);
        Rect boton(x, y + i * sep, ancho, alto);

        rectangle(img, boton, color, FILLED);
        rectangle(img, boton, Scalar(230,230,230), 2, LINE_AA);

        putText(img, opciones[i], Point(x + 35, y + i * sep + 37),
                FONT_HERSHEY_SIMPLEX, 0.75, Scalar(255,255,255), 2, LINE_AA);
    }

    panel(img, Rect(610, 180, 570, 470), Scalar(25,25,34), Scalar(0,180,180));
    textoCentrado(img, "Control por camara", 225, 0.8, Scalar(255,255,255), 2);

    Rect zonaPreview(690, 260, 410, 300);

    if (!camara.empty()) {
        Mat preview;
        resize(camara, preview, Size(zonaPreview.width, zonaPreview.height));
        preview.copyTo(img(zonaPreview));
    } else {
        rectangle(img, zonaPreview, Scalar(0,180,180), 2, LINE_AA);
        putText(img, "ESPERANDO KINECT", Point(790, 410),
                FONT_HERSHEY_SIMPLEX, 0.75, Scalar(0,220,220), 2);
    }

    rectangle(img, zonaPreview, Scalar(0,220,220), 2, LINE_AA);

    putText(img, "Mueve tu mano/cuerpo arriba-abajo", Point(680, 590),
            FONT_HERSHEY_SIMPLEX, 0.55, Scalar(255,255,255), 1);

    putText(img, "Mantente 1.5 s para seleccionar", Point(710, 620),
            FONT_HERSHEY_SIMPLEX, 0.55, Scalar(0,255,140), 1);

    textoCentrado(img, "Camara: seleccionar | W/S: mover | ENTER: elegir | ESC: salir", 690, 0.55, Scalar(180,180,180), 1);
}

void dibujarPantallaSimple(Mat& img, string titulo, vector<string> lineas)
{
    img = Mat::zeros(720, 1280, CV_8UC3);
    img.setTo(Scalar(18,18,24));

    textoCentrado(img, titulo, 100, 1.3, Scalar(255,255,255), 3);

    int y = 220;
    for (auto& l : lineas) {
        textoCentrado(img, l, y, 0.75, Scalar(230,230,230), 2);
        y += 65;
    }

    textoCentrado(img, "Presiona ESC para volver", 660, 0.6, Scalar(0,220,220), 2);
}

int main()
{
    freenect_context* f_ctx;
    freenect_device* f_dev;

    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    signal(SIGQUIT, signalHandler);

    if (freenect_init(&f_ctx, NULL) < 0) {
        cout << "Error: no se pudo inicializar libfreenect" << endl;
        return -1;
    }

    freenect_set_log_level(f_ctx, FREENECT_LOG_WARNING);

    if (freenect_open_device(f_ctx, &f_dev, 0) < 0) {
        cout << "Error: no se pudo abrir Kinect" << endl;
        freenect_shutdown(f_ctx);
        return -1;
    }

    freenect_set_depth_callback(f_dev, depth_cb);
    freenect_set_video_callback(f_dev, video_cb);

    freenect_set_video_mode(f_dev, freenect_find_video_mode(FREENECT_RESOLUTION_MEDIUM, FREENECT_VIDEO_RGB));
    freenect_set_depth_mode(f_dev, freenect_find_depth_mode(FREENECT_RESOLUTION_MEDIUM, FREENECT_DEPTH_11BIT));

    freenect_start_depth(f_dev);
    freenect_start_video(f_dev);

    Mat pantalla;
    namedWindow("Push-Up Vision Challenge", WINDOW_NORMAL);
    setWindowProperty("Push-Up Vision Challenge", WND_PROP_FULLSCREEN, WINDOW_FULLSCREEN);

    while (running && freenect_process_events(f_ctx) >= 0) {
        Mat camara;

        {
            lock_guard<mutex> lock(mutexFrame);
            if (hayFrame && !frameKinect.empty()) {
                camara = frameKinect.clone();
            }
        }

        if (pantallaActual == MENU) {
            if (!camara.empty()) {
                Mat camaraDeteccion = camara.clone();
                int opcionCamara = detectarOpcionPorCamara(camaraDeteccion);
                opcionActual = opcionCamara;
                camara = camaraDeteccion;

                if (opcionCamara != opcionAnteriorCamara) {
                    opcionAnteriorCamara = opcionCamara;
                    tiempoSeleccion = chrono::steady_clock::now();
                    temporizadorActivo = true;
                } else if (temporizadorActivo) {
                    auto ahora = chrono::steady_clock::now();
                    auto ms = chrono::duration_cast<chrono::milliseconds>(ahora - tiempoSeleccion).count();

                    if (ms > 1500) {
                        ejecutarOpcion();
                        temporizadorActivo = false;
                    }
                }
            }

            dibujarMenu(pantalla, camara);
        }

        else if (pantallaActual == INSTRUCCIONES) {
            dibujarPantallaSimple(pantalla, "INSTRUCCIONES", {
                "1. Colocate de lado frente al Kinect.",
                "2. Mantente dentro de la zona de deteccion.",
                "3. Baja y sube de forma controlada.",
                "4. Una repeticion cuenta cuando completas abajo y arriba.",
                "5. Al finalizar se mostrara tu resultado."
            });
        }

        else if (pantallaActual == RETO) {
            dibujarPantallaSimple(pantalla, "RETO", {
                "Aqui ira la pantalla del reto con contador real.",
                "Kinect ya esta activo.",
                "ESC para volver al menu."
            });
        }

        else if (pantallaActual == PRUEBA_KINECT) {
            if (!camara.empty()) {
                resize(camara, pantalla, Size(1280, 720));
                putText(pantalla, "PRUEBA KINECT - ESC para volver",
                        Point(40, 60), FONT_HERSHEY_SIMPLEX, 1.0,
                        Scalar(0,255,255), 3);
            } else {
                dibujarPantallaSimple(pantalla, "PRUEBA KINECT", {
                    "Esperando imagen del Kinect..."
                });
            }
        }

        else if (pantallaActual == CALIBRACION) {
            dibujarPantallaSimple(pantalla, "CALIBRACION", {
                "1. Posicion ARRIBA.",
                "2. Posicion ABAJO.",
                "3. Guardar umbrales."
            });
        }

        else if (pantallaActual == RESULTADOS) {
            dibujarPantallaSimple(pantalla, "RESULTADOS", {
                "Lagartijas validas: 0",
                "Nivel: Pendiente",
                "Premio desbloqueado: No"
            });
        }

        else if (pantallaActual == SALIR) {
            running = false;
        }

        imshow("Push-Up Vision Challenge", pantalla);

        int tecla = waitKey(1);

        if (tecla == 27) {
            if (pantallaActual == MENU) running = false;
            else pantallaActual = MENU;
        }

        if (pantallaActual == MENU) {
            if (tecla == 'w' || tecla == 'W' || tecla == 82) {
                opcionActual--;
                if (opcionActual < 0) opcionActual = opciones.size() - 1;
                opcionAnteriorCamara = opcionActual;
            }

            if (tecla == 's' || tecla == 'S' || tecla == 84) {
                opcionActual++;
                if (opcionActual >= (int)opciones.size()) opcionActual = 0;
                opcionAnteriorCamara = opcionActual;
            }

            if (tecla == 13 || tecla == 10) {
                ejecutarOpcion();
            }
        }
    }

    freenect_stop_depth(f_dev);
    freenect_stop_video(f_dev);
    freenect_close_device(f_dev);
    freenect_shutdown(f_ctx);
    destroyAllWindows();

    return 0;
}
