/*
 * ============================================================
 *  Juego con Puntero por Color  —  Menú estilo Xbox Dashboard
 *  Jonathan Caldera Barajas  —  Electrónica en corto
 * ============================================================
 *  Compilar:
 *    g++ main.cpp -o juego \
 *        $(pkg-config --cflags --libs opencv4 sdl2 SDL2_ttf)
 * ============================================================
 *
 *  Puntero recomendado: pelota de tenis o plumón verde fluorescente
 *  Activación: mantener el puntero 2 segundos sobre un botón
 * ============================================================
 */

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>

using namespace std;
using namespace cv;

/* ─────────────────────────────────────────────
   CONSTANTES
───────────────────────────────────────────── */
static const int ANCHO          = 1280;
static const int ALTO           = 720;
static const int DWELL_MS       = 2000;
static const int FLASH_MS       = 500;
static const int NUM_BOTONES    = 3;
static const int ALTO_BARRA_HUD = 48;

/* ─────────────────────────────────────────────
   COLORES
───────────────────────────────────────────── */
struct Color { Uint8 r, g, b, a; };

static const Color COL_BG_TOP       = {  6,   6,   6, 255 };
static const Color COL_BG_BOT       = { 10,  22,  10, 255 };
static const Color COL_XBOX_GREEN   = { 16, 124,  16, 255 };
static const Color COL_XBOX_GREEN2  = { 90, 200,  90, 255 };
static const Color COL_METAL_LIGHT  = { 90,  90,  90, 255 };
static const Color COL_TARJETA_BG   = { 18,  18,  18, 230 };
static const Color COL_TARJETA_HOV  = { 12,  40,  12, 240 };
static const Color COL_BORDE_IDLE   = { 55,  55,  55, 255 };
static const Color COL_BORDE_HOV    = { 16, 124,  16, 255 };
static const Color COL_BORDE_FLASH  = {160, 255, 160, 255 };
static const Color COL_TEXTO        = {240, 240, 240, 255 };
static const Color COL_SUBTEXTO     = {130, 130, 130, 255 };
static const Color COL_HUD_BG       = {  8,  14,   8, 245 };
static const Color COL_HUD_TEXT     = {180, 220, 180, 255 };
static const Color COL_HUD_BAR_BG   = { 35,  35,  35, 255 };
static const Color COL_HUD_BAR_FG   = { 16, 124,  16, 255 };
static const Color COL_HUD_BAR_WARN = {200, 140,   0, 255 };
static const Color COL_HUD_BAR_CRIT = {200,  30,  30, 255 };

/* ─────────────────────────────────────────────
   HELPERS SDL
───────────────────────────────────────────── */
void set_color(SDL_Renderer* r, Color c)
{
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
}

Color lerp_color(Color a, Color b, float t)
{
    if (t < 0) t = 0; if (t > 1) t = 1;
    return {
        (Uint8)(a.r + (b.r - a.r) * t),
        (Uint8)(a.g + (b.g - a.g) * t),
        (Uint8)(a.b + (b.b - a.b) * t),
        (Uint8)(a.a + (b.a - a.a) * t)
    };
}

void fill_rect_blend(SDL_Renderer* r, SDL_Rect rect, Color c)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    SDL_RenderFillRect(r, &rect);
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_rect_outline(SDL_Renderer* r, SDL_Rect rect, Color c, int grosor)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    for (int i = 0; i < grosor; i++)
    {
        SDL_Rect b = { rect.x-i, rect.y-i, rect.w+2*i, rect.h+2*i };
        SDL_RenderDrawRect(r, &b);
    }
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_line_blend(SDL_Renderer* r,
                     int x1, int y1, int x2, int y2, Color c)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    SDL_RenderDrawLine(r, x1, y1, x2, y2);
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_circle_filled(SDL_Renderer* r, int cx, int cy, int radio, Color c)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    for (int dy = -radio; dy <= radio; dy++)
    {
        int dx = (int)sqrt((double)(radio*radio - dy*dy));
        SDL_RenderDrawLine(r, cx-dx, cy+dy, cx+dx, cy+dy);
    }
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_text(SDL_Renderer* r, TTF_Font* f,
               const string& txt, int cx, int cy, Color c,
               bool centrado = true)
{
    SDL_Color sc = { c.r, c.g, c.b, c.a };
    SDL_Surface* s = TTF_RenderUTF8_Blended(f, txt.c_str(), sc);
    if (!s) return;
    SDL_Texture* t = SDL_CreateTextureFromSurface(r, s);
    SDL_Rect dst;
    if (centrado)
        dst = { cx - s->w/2, cy - s->h/2, s->w, s->h };
    else
        dst = { cx, cy - s->h/2, s->w, s->h };
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    SDL_RenderCopy(r, t, nullptr, &dst);
    SDL_FreeSurface(s);
    SDL_DestroyTexture(t);
}

/* ─────────────────────────────────────────────
   FONDO: degradado + cuadrícula HUD + viñeta
───────────────────────────────────────────── */
void dibujar_fondo(SDL_Renderer* r)
{
    int zona = ALTO - ALTO_BARRA_HUD;

    // Degradado vertical
    for (int y = 0; y < zona; y++)
    {
        float t = (float)y / zona;
        Color c = lerp_color(COL_BG_TOP, COL_BG_BOT, t);
        SDL_SetRenderDrawColor(r, c.r, c.g, c.b, 255);
        SDL_RenderDrawLine(r, 0, y, ANCHO, y);
    }

    // Cuadrícula tenue tipo HUD
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r, 16, 50, 16, 18);
    for (int x = 0; x < ANCHO; x += 60)
        SDL_RenderDrawLine(r, x, 0, x, zona);
    for (int y = 0; y < zona; y += 60)
        SDL_RenderDrawLine(r, 0, y, ANCHO, y);
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);

    // Viñeta lateral verde oscuro
    for (int i = 0; i < 80; i++)
    {
        Uint8 alpha = (Uint8)(40 * (1.0f - i / 80.0f));
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(r, 0, 60, 0, alpha);
        SDL_RenderDrawLine(r, i, 0, i, zona);
        SDL_RenderDrawLine(r, ANCHO-1-i, 0, ANCHO-1-i, zona);
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
    }
}

/* ─────────────────────────────────────────────
   HEADER
───────────────────────────────────────────── */
void dibujar_header(SDL_Renderer* r,
                    TTF_Font* f_titulo,
                    TTF_Font* f_chica,
                    Uint32 ahora)
{
    // Línea separadora con brillo pulsante
    float pulso = (float)(sin(ahora / 1200.0) * 0.5 + 0.5);
    Uint8 al    = (Uint8)(120 + pulso * 80);
    draw_line_blend(r, 0, 80, ANCHO, 80, { 16, 124, 16, al });
    draw_line_blend(r, 0, 82, ANCHO, 82, { 16, 124, 16, (Uint8)(al/3) });

    // Círculo estilo logo Xbox
    draw_circle_filled(r, 55, 40, 28, { 16, 124, 16, 200 });
    draw_circle_filled(r, 55, 40, 22, { 10,  10,  10, 255 });
    draw_circle_filled(r, 55, 40, 18, { 16, 124, 16, 180 });
    // X interior (doble línea para grosor)
    draw_line_blend(r, 45, 30, 65, 50, {240,240,240,230});
    draw_line_blend(r, 65, 30, 45, 50, {240,240,240,230});
    draw_line_blend(r, 46, 30, 66, 50, {240,240,240,230});
    draw_line_blend(r, 66, 30, 46, 50, {240,240,240,230});

    // Título centrado
    draw_text(r, f_titulo, "MENU PRINCIPAL", ANCHO/2, 42, COL_TEXTO);

    // Subtítulo derecho
    draw_text(r, f_chica, "PUNTERO VERDE  |  MANTENER 2s",
              ANCHO - 30, 42, COL_SUBTEXTO, false);
}

/* ─────────────────────────────────────────────
   BORDE DWELL ANIMADO (recorre perímetro)
───────────────────────────────────────────── */
void dibujar_dwell_borde(SDL_Renderer* r, SDL_Rect rect, float t)
{
    if (t <= 0.0f) return;

    Color col = lerp_color(COL_XBOX_GREEN, COL_XBOX_GREEN2, t);
    int g = 4;

    float perimetro = 2.0f * (rect.w + rect.h);
    float longitud  = perimetro * t;

    struct Seg { int x1,y1,x2,y2; float largo; };
    Seg segs[4] = {
        { rect.x,        rect.y,        rect.x+rect.w, rect.y,        (float)rect.w },
        { rect.x+rect.w, rect.y,        rect.x+rect.w, rect.y+rect.h, (float)rect.h },
        { rect.x+rect.w, rect.y+rect.h, rect.x,        rect.y+rect.h, (float)rect.w },
        { rect.x,        rect.y+rect.h, rect.x,        rect.y,        (float)rect.h }
    };

    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    float restante = longitud;
    for (auto& s : segs)
    {
        if (restante <= 0) break;
        float frac = (restante >= s.largo) ? 1.0f : restante / s.largo;
        int ex = (int)(s.x1 + (s.x2-s.x1)*frac);
        int ey = (int)(s.y1 + (s.y2-s.y1)*frac);
        for (int gi = 0; gi < g; gi++)
        {
            bool horiz = (s.y1 == s.y2);
            int ox = horiz ? 0 : gi;
            int oy = horiz ? gi : 0;
            SDL_SetRenderDrawColor(r, col.r, col.g, col.b,
                                   (Uint8)(col.a * (1.0f - gi * 0.2f)));
            SDL_RenderDrawLine(r, s.x1+ox, s.y1+oy, ex+ox, ey+oy);
        }
        restante -= s.largo;
    }
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

/* ─────────────────────────────────────────────
   ESTRUCTURA BOTÓN
───────────────────────────────────────────── */
struct Boton
{
    SDL_Rect  rect;
    string    etiqueta;
    string    subtexto;
    bool      en_hover;
    bool      activado;
    Uint32    t_hover;
    Uint32    t_flash;
};

/* ─────────────────────────────────────────────
   TARJETA ESTILO XBOX
───────────────────────────────────────────── */
void dibujar_tarjeta(SDL_Renderer* r,
                     TTF_Font* f_grande,
                     TTF_Font* f_chica,
                     Boton& b,
                     Uint32 ahora)
{
    bool en_flash = b.activado && (ahora - b.t_flash < (Uint32)FLASH_MS);

    float progreso = 0.0f;
    if (b.en_hover && !b.activado)
    {
        Uint32 elapsed = ahora - b.t_hover;
        progreso = (float)elapsed / DWELL_MS;
        if (progreso > 1.0f) progreso = 1.0f;
    }

    // Sombra
    SDL_Rect sombra = { b.rect.x+6, b.rect.y+6, b.rect.w, b.rect.h };
    fill_rect_blend(r, sombra, { 0, 0, 0, 120 });

    // Fondo
    Color col_fondo = b.en_hover ? COL_TARJETA_HOV : COL_TARJETA_BG;
    if (en_flash) col_fondo = { 20, 80, 20, 250 };
    fill_rect_blend(r, b.rect, col_fondo);

    // Brillo superior (reflection)
    SDL_Rect brillo = { b.rect.x+2, b.rect.y+2, b.rect.w-4, b.rect.h/3 };
    Color col_brillo = b.en_hover ? Color{30,100,30,35} : Color{60,60,60,20};
    fill_rect_blend(r, brillo, col_brillo);

    // Borde base
    Color col_borde = en_flash ? COL_BORDE_FLASH
                    : b.en_hover ? COL_BORDE_HOV
                    : COL_BORDE_IDLE;
    draw_rect_outline(r, b.rect, col_borde, 2);

    // Esquinas decorativas estilo Xbox
    int sz = 14;
    Color col_esq = b.en_hover ? COL_XBOX_GREEN : COL_METAL_LIGHT;
    // sup-izq
    draw_line_blend(r, b.rect.x, b.rect.y, b.rect.x+sz, b.rect.y, col_esq);
    draw_line_blend(r, b.rect.x, b.rect.y, b.rect.x, b.rect.y+sz, col_esq);
    // sup-der
    draw_line_blend(r, b.rect.x+b.rect.w,   b.rect.y, b.rect.x+b.rect.w-sz, b.rect.y,    col_esq);
    draw_line_blend(r, b.rect.x+b.rect.w,   b.rect.y, b.rect.x+b.rect.w,    b.rect.y+sz, col_esq);
    // inf-izq
    draw_line_blend(r, b.rect.x, b.rect.y+b.rect.h, b.rect.x+sz, b.rect.y+b.rect.h,    col_esq);
    draw_line_blend(r, b.rect.x, b.rect.y+b.rect.h, b.rect.x,    b.rect.y+b.rect.h-sz, col_esq);
    // inf-der
    draw_line_blend(r, b.rect.x+b.rect.w, b.rect.y+b.rect.h, b.rect.x+b.rect.w-sz, b.rect.y+b.rect.h,    col_esq);
    draw_line_blend(r, b.rect.x+b.rect.w, b.rect.y+b.rect.h, b.rect.x+b.rect.w,    b.rect.y+b.rect.h-sz, col_esq);

    // Borde dwell animado
    if (!en_flash && progreso > 0.0f)
        dibujar_dwell_borde(r, b.rect, progreso);

    // Barra de progreso inferior
    if (b.en_hover && progreso > 0.0f && !en_flash)
    {
        SDL_Rect bg = { b.rect.x+8, b.rect.y+b.rect.h-14, b.rect.w-16, 7 };
        SDL_Rect fg = { bg.x, bg.y, (int)(bg.w * progreso), bg.h };
        fill_rect_blend(r, bg, { 30, 30, 30, 200 });
        Color col_bar = lerp_color(COL_XBOX_GREEN, {220,220,20,255}, progreso);
        fill_rect_blend(r, fg, col_bar);
        draw_rect_outline(r, bg, { 50, 50, 50, 150 }, 1);
    }

    // Línea separadora decorativa
    int lx1 = b.rect.x + 20;
    int lx2 = b.rect.x + b.rect.w - 20;
    int ly  = b.rect.y + b.rect.h/2 + 18;
    draw_line_blend(r, lx1, ly, lx2, ly, { 60, 60, 60, 100 });

    // Textos
    int cx       = b.rect.x + b.rect.w / 2;
    int cy_label = b.rect.y + b.rect.h/2 - 8;
    int cy_sub   = b.rect.y + b.rect.h/2 + 35;

    Color col_label = en_flash ? Color{200,255,200,255} : COL_TEXTO;
    draw_text(r, f_grande, b.etiqueta, cx, cy_label, col_label);
    draw_text(r, f_chica,  b.subtexto, cx, cy_sub,   COL_SUBTEXTO);
}

/* ─────────────────────────────────────────────
   CURSOR con halo pulsante
───────────────────────────────────────────── */
void dibujar_cursor(SDL_Renderer* r, int x, int y, Uint32 ahora)
{
    float pulso  = (float)(sin(ahora / 180.0) * 0.5 + 0.5);
    int r_halo   = (int)(28 + pulso * 14);

    draw_circle_filled(r, x, y, r_halo,    { 16, 124, 16, 25 });
    draw_circle_filled(r, x, y, r_halo-8,  { 16, 124, 16, 40 });
    draw_circle_filled(r, x, y, 13,        {  0,   0,  0, 180 });
    draw_circle_filled(r, x+1, y+1, 12,    { 80, 255,  80, 255 });
    draw_rect_outline(r, { x-14, y-14, 28, 28 }, { 16, 124, 16, 200 }, 1);

    // Cruz
    SDL_SetRenderDrawColor(r, 0, 0, 0, 220);
    SDL_RenderDrawLine(r, x-6, y, x+6, y);
    SDL_RenderDrawLine(r, x, y-6, x, y+6);
}

/* ─────────────────────────────────────────────
   MONITOR CPU / RAM  (/proc/)
───────────────────────────────────────────── */
struct EstadoCPU { long idle, total; };

EstadoCPU leer_cpu()
{
    ifstream f("/proc/stat");
    string linea;
    getline(f, linea);
    istringstream ss(linea);
    string lbl;
    long user, nice, system, idle, iowait, irq, softirq, steal;
    ss >> lbl >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
    return { idle + iowait,
             user + nice + system + idle + iowait + irq + softirq + steal };
}

float calcular_cpu_pct(EstadoCPU prev, EstadoCPU curr)
{
    long d_idle  = curr.idle  - prev.idle;
    long d_total = curr.total - prev.total;
    if (d_total == 0) return 0.0f;
    return 100.0f * (1.0f - (float)d_idle / d_total);
}

float leer_ram_pct()
{
    ifstream f("/proc/meminfo");
    long total = 1, disponible = 0;
    string clave, unidad;
    long valor;
    // Leer primeras 10 líneas para encontrar MemTotal y MemAvailable
    for (int i = 0; i < 10; i++)
    {
        if (!(f >> clave >> valor >> unidad)) break;
        if (clave == "MemTotal:")     total      = valor;
        if (clave == "MemAvailable:") disponible = valor;
    }
    return 100.0f * (1.0f - (float)disponible / total);
}

void dibujar_hud(SDL_Renderer* r,
                 TTF_Font* f_chica,
                 float cpu_pct,
                 float ram_pct,
                 Uint32 ahora)
{
    int y0 = ALTO - ALTO_BARRA_HUD;

    // Fondo HUD
    fill_rect_blend(r, { 0, y0, ANCHO, ALTO_BARRA_HUD }, COL_HUD_BG);

    // Línea separadora superior verde Xbox
    draw_line_blend(r, 0, y0,   ANCHO, y0,   COL_XBOX_GREEN);
    draw_line_blend(r, 0, y0+1, ANCHO, y0+1, { 16, 124, 16, 60 });

    int cy = y0 + ALTO_BARRA_HUD / 2;

    // ── Función lambda para cada recurso ────
    auto dibujar_recurso = [&](const string& label, float pct, int x_base)
    {
        draw_text(r, f_chica, label, x_base, cy, COL_HUD_TEXT, false);

        SDL_Rect bg = { x_base + 55, cy - 7, 220, 14 };
        fill_rect_blend(r, bg, COL_HUD_BAR_BG);

        int fill_w = (int)(bg.w * pct / 100.0f);
        SDL_Rect fg = { bg.x, bg.y, fill_w, bg.h };
        Color col_bar = pct > 85.0f ? COL_HUD_BAR_CRIT
                      : pct > 65.0f ? COL_HUD_BAR_WARN
                      : COL_HUD_BAR_FG;
        fill_rect_blend(r, fg, col_bar);
        draw_rect_outline(r, bg, { 60, 60, 60, 180 }, 1);

        char buf[16];
        snprintf(buf, sizeof(buf), "%.1f%%", pct);
        draw_text(r, f_chica, string(buf),
                  bg.x + bg.w + 8, cy, col_bar, false);
    };

    dibujar_recurso("CPU", cpu_pct, 40);
    dibujar_recurso("RAM", ram_pct, 400);

    // Separador central
    draw_line_blend(r, ANCHO/2, y0+8, ANCHO/2, ALTO-8, { 40, 80, 40, 100 });

    // Reloj de sesión (derecha)
    Uint32 seg = ahora / 1000;
    char buf[32];
    snprintf(buf, sizeof(buf), "T+  %02d:%02d", seg/60, seg%60);
    draw_text(r, f_chica, string(buf), ANCHO - 80, cy, COL_SUBTEXTO);
}

/* ─────────────────────────────────────────────
   MAIN
───────────────────────────────────────────── */
int main()
{
    /* ── Cámara ── */
    VideoCapture cam(0);
    if (!cam.isOpened())
    {
        cout << "No se pudo abrir la webcam" << endl;
        return -1;
    }
    cam.set(CAP_PROP_FRAME_WIDTH,  320);
    cam.set(CAP_PROP_FRAME_HEIGHT, 240);

    /* ── SDL2 + TTF ── */
    if (SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        cout << "Error SDL_Init: " << SDL_GetError() << endl;
        return -1;
    }
    if (TTF_Init() < 0)
    {
        cout << "Error TTF_Init: " << TTF_GetError() << endl;
        return -1;
    }

    SDL_Window* ventana = SDL_CreateWindow(
        "Juego con Puntero por Color",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        ANCHO, ALTO,
        SDL_WINDOW_SHOWN
    );
    if (!ventana) { cout << "Error ventana: " << SDL_GetError() << endl; return -1; }

    SDL_Renderer* renderer = SDL_CreateRenderer(
        ventana, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
    );
    if (!renderer) { cout << "Error renderer: " << SDL_GetError() << endl; return -1; }

    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);

    /* ── Fuentes ── */
    const char* FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
    TTF_Font* f_titulo = TTF_OpenFont(FUENTE, 34);
    TTF_Font* f_grande = TTF_OpenFont(FUENTE, 26);
    TTF_Font* f_chica  = TTF_OpenFont(FUENTE, 15);
    if (!f_titulo || !f_grande || !f_chica)
    {
        cout << "Error fuente: " << TTF_GetError() << endl;
        return -1;
    }

    /* ── Botones ── */
    int ancho_t = 280;
    int alto_t  = 200;
    int margen  = 60;
    int total_w = NUM_BOTONES * ancho_t + (NUM_BOTONES-1) * margen;
    int ox = (ANCHO - total_w) / 2;
    int oy = (ALTO - ALTO_BARRA_HUD - alto_t) / 2 + 30;

    vector<Boton> botones = {
        { {ox,                       oy, ancho_t, alto_t}, "JUGAR",    "Iniciar partida",    false, false, 0, 0 },
        { {ox + ancho_t + margen,    oy, ancho_t, alto_t}, "OPCIONES", "Configuracion",      false, false, 0, 0 },
        { {ox + 2*(ancho_t+margen),  oy, ancho_t, alto_t}, "SALIR",    "Cerrar aplicacion",  false, false, 0, 0 }
    };

    /* ── Estado visión ── */
    int cursor_x = ANCHO / 2;
    int cursor_y = ALTO  / 2;
    Mat frame, hsv, mascara;

    /* ── CPU / RAM ── */
    EstadoCPU cpu_prev   = leer_cpu();
    float     cpu_pct    = 0.0f;
    float     ram_pct    = 0.0f;
    Uint32    t_cpu      = 0;

    /* ── Loop ── */
    bool ejecutando  = true;
    int  boton_activo = -1;
    SDL_Event evento;

    while (ejecutando)
    {
        Uint32 ahora = SDL_GetTicks();

        /* ── Eventos ── */
        while (SDL_PollEvent(&evento))
        {
            if (evento.type == SDL_QUIT) ejecutando = false;
            if (evento.type == SDL_KEYDOWN &&
                evento.key.keysym.sym == SDLK_ESCAPE) ejecutando = false;
        }

        /* ── CPU/RAM cada 800ms ── */
        if (ahora - t_cpu >= 800)
        {
            EstadoCPU cpu_curr = leer_cpu();
            cpu_pct = calcular_cpu_pct(cpu_prev, cpu_curr);
            cpu_prev = cpu_curr;
            ram_pct  = leer_ram_pct();
            t_cpu    = ahora;
        }

        /* ── Captura y umbralización ── */
        for (int i = 0; i < 3; i++) cam.grab();
	cam >> frame;
        if (!frame.empty())
        {
            flip(frame, frame, 1);
            cvtColor(frame, hsv, COLOR_BGR2HSV);

            // ── Ajusta estos rangos según tu objeto verde ──
            Scalar bajo(10, 80, 80);
            Scalar alto(20, 255, 255);
            inRange(hsv, bajo, alto, mascara);

            erode (mascara, mascara, Mat(), Point(-1,-1), 2);
            dilate(mascara, mascara, Mat(), Point(-1,-1), 2);

            vector<vector<Point>> contornos;
            findContours(mascara, contornos, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

            double area_mayor   = 0;
            int    indice_mayor = -1;
            for (int i = 0; i < (int)contornos.size(); i++)
            {
                double a = contourArea(contornos[i]);
                if (a > area_mayor) { area_mayor = a; indice_mayor = i; }
            }

            if (indice_mayor >= 0 && area_mayor > 800)
            {
                Moments m = moments(contornos[indice_mayor]);
                if (m.m00 != 0)
                {
                    int cx_cam = (int)(m.m10 / m.m00);
                    int cy_cam = (int)(m.m01 / m.m00);
                    cursor_x = (cx_cam * ANCHO) / frame.cols;
                    cursor_y = (cy_cam * (ALTO - ALTO_BARRA_HUD)) / frame.rows;
                }
            }
        }

        /* ── Lógica dwell ── */
        for (int i = 0; i < NUM_BOTONES; i++)
        {
            Boton& b = botones[i];
            bool dentro = (cursor_x >= b.rect.x &&
                           cursor_x <= b.rect.x + b.rect.w &&
                           cursor_y >= b.rect.y &&
                           cursor_y <= b.rect.y + b.rect.h);
            if (dentro)
            {
                if (!b.en_hover) { b.en_hover = true; b.t_hover = ahora; }
                if (!b.activado && (ahora - b.t_hover) >= (Uint32)DWELL_MS)
                {
                    b.activado   = true;
                    b.t_flash    = ahora;
                    boton_activo = i;
                    cout << ">> Seleccionado: " << b.etiqueta << endl;
                }
            }
            else
            {
                b.en_hover = false;
                if (!b.activado) { /* nada */ }
            }
        }

        /* ── Post-flash ── */
        if (boton_activo >= 0)
        {
            Boton& b = botones[boton_activo];
            if (b.activado && (ahora - b.t_flash) >= (Uint32)FLASH_MS)
            {
                if (boton_activo == 2) ejecutando = false;   // SALIR
                // JUGAR / OPCIONES: añade aquí la lógica de escena
                b.activado   = false;
                b.en_hover   = false;
                boton_activo = -1;
            }
        }

        /* ──────── RENDER ──────── */
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        dibujar_fondo(renderer);
        dibujar_header(renderer, f_titulo, f_chica, ahora);
        for (auto& b : botones)
            dibujar_tarjeta(renderer, f_grande, f_chica, b, ahora);
        dibujar_cursor(renderer, cursor_x, cursor_y, ahora);
        dibujar_hud(renderer, f_chica, cpu_pct, ram_pct, ahora);

        SDL_RenderPresent(renderer);
    }

    /* ── Limpieza ── */
    cam.release();
    TTF_CloseFont(f_titulo);
    TTF_CloseFont(f_grande);
    TTF_CloseFont(f_chica);
    TTF_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(ventana);
    SDL_Quit();
    return 0;
}