// ============================================================
//  juego.cpp  —  V17
//  BASE: ConteoEjercicio_v16.cpp
//  NUEVO v17:
//    - Pantalla OPCIONES con meta ajustable por dwell
//    - Boton OPCIONES en menu junto a SALIR
//    - Layout menu rebalanceado (botones centrados)
//    - Iconos mejorados: salto con flechas, lagartija lateral, portero
//    - Boton VOLVER visible en los 3 modos de ejercicio
//    - Compilar con python3.11-config
//
//  Compilar:
//    g++ juego.cpp -o juego \
//        -O3 -march=armv8-a \
//        $(pkg-config --cflags --libs opencv4 libfreenect sdl2 SDL2_ttf) \
//        $(python3.11-config --includes --ldflags --embed) \
//        -lSDL2_mixer -pthread -lm
// ============================================================

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <opencv2/opencv.hpp>
#include <libfreenect.h>
#include <Python.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <cmath>
#include <mutex>
#include <thread>
#include <atomic>
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace cv;

// ── Impresion de ticket al completar meta ──────────────────────
// Llama al binario imprimir_v3 con un numero de premio aleatorio (1-10)
// Esto corre en background (&) para no congelar el juego mientras imprime.
void imprimir_ticket_aleatorio(){
    int premio = (rand()%10)+1; // 1 a 10
    char comando[256];
    snprintf(comando,sizeof(comando),
        "/home/raspberrypi/opencv/Parcial3/IMPRESORA/V3/imprimir_v3 %d &",premio);
    system(comando);
}

// ══════════════════════════════════════════════════════════════
//  CAPTURA — Kinect (prioritario) o Webcam (fallback)
// ══════════════════════════════════════════════════════════════
static Mat   g_rgb, g_depth;
static mutex g_rgb_mtx, g_depth_mtx;
static atomic<bool> g_running(true);
static bool g_usar_kinect = false;

static freenect_context* g_ctx=nullptr;
static freenect_device*  g_dev=nullptr;

static void video_cb(freenect_device*,void* rgb,uint32_t){
    lock_guard<mutex> lk(g_rgb_mtx);
    Mat tmp(480,640,CV_8UC3,rgb);
    Mat bgr; cvtColor(tmp,bgr,COLOR_RGB2BGR);
    Mat fl; flip(bgr,fl,1);
    resize(fl,g_rgb,Size(160,120));
}
static void depth_cb(freenect_device*,void* d,uint32_t){
    lock_guard<mutex> lk(g_depth_mtx);
    Mat dm(480,640,CV_16UC1,(uint16_t*)d);
    Mat d8; dm.convertTo(d8,CV_8UC1,255.0/2048.0);
    Mat fl; flip(d8,fl,1);
    resize(fl,g_depth,Size(160,120));
}
static void kinect_loop(){while(g_running&&freenect_process_events(g_ctx)>=0){}}

bool kinect_init(){
    if(freenect_init(&g_ctx,NULL)<0)return false;
    freenect_set_log_level(g_ctx,FREENECT_LOG_WARNING);
    if(freenect_open_device(g_ctx,&g_dev,0)<0){freenect_shutdown(g_ctx);return false;}
    freenect_set_video_mode(g_dev,freenect_find_video_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_VIDEO_RGB));
    freenect_set_video_callback(g_dev,video_cb);
    freenect_start_video(g_dev);
    freenect_set_depth_mode(g_dev,freenect_find_depth_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_DEPTH_11BIT));
    freenect_set_depth_callback(g_dev,depth_cb);
    freenect_start_depth(g_dev);
    return true;
}
Mat kinect_get_rgb()  {lock_guard<mutex> lk(g_rgb_mtx);  return g_rgb.clone();}
Mat kinect_get_depth(){lock_guard<mutex> lk(g_depth_mtx);return g_depth.clone();}

static VideoCapture g_cap;
static Mat          g_wcam_rgb;
static mutex        g_wcam_mtx;

static void webcam_loop(){
    while(g_running){
        Mat frame;
        if(g_cap.read(frame)&&!frame.empty()){
            Mat fl; flip(frame,fl,1);
            Mat small; resize(fl,small,Size(160,120));
            lock_guard<mutex> lk(g_wcam_mtx);
            g_wcam_rgb=small.clone();
        }
    }
}

bool webcam_init(){
    g_cap.open(0);
    if(!g_cap.isOpened())return false;
    g_cap.set(CAP_PROP_FRAME_WIDTH,640);
    g_cap.set(CAP_PROP_FRAME_HEIGHT,480);
    cout<<"[OK] Webcam — modo fallback\n";
    return true;
}

Mat webcam_get_rgb(){lock_guard<mutex> lk(g_wcam_mtx);return g_wcam_rgb.clone();}

Mat captura_get_rgb(){
    if(g_usar_kinect) return kinect_get_rgb();
    else              return webcam_get_rgb();
}

// ══════════════════════════════════════════════════════════════
//  MEDIAPIPE
// ══════════════════════════════════════════════════════════════
static PyObject* g_py=nullptr;

static const char* PY_CODE=R"PYCODE(
import mediapipe as mp
import numpy as np

pose_det=mp.solutions.pose.Pose(
    static_image_mode=False,
    model_complexity=0,
    min_detection_confidence=0.45,
    min_tracking_confidence=0.45
)

def ang(a,b,c):
    ba=np.array(a)-np.array(b); bc=np.array(c)-np.array(b)
    cos=np.dot(ba,bc)/(np.linalg.norm(ba)*np.linalg.norm(bc)+1e-6)
    return float(np.degrees(np.arccos(np.clip(cos,-1,1))))

def procesar(fb,w,h):
    arr=np.frombuffer(fb,dtype=np.uint8).reshape((h,w,3))
    rgb=arr[:,:,::-1].copy()
    rp=pose_det.process(rgb)
    if not rp.pose_landmarks:
        return None

    lm=rp.pose_landmarks.landmark
    hi=[lm[11].x,lm[11].y]; hd=[lm[12].x,lm[12].y]
    ci=[lm[13].x,lm[13].y]; cd=[lm[14].x,lm[14].y]
    mi=[lm[15].x,lm[15].y]; md=[lm[16].x,lm[16].y]
    cai=[lm[23].x,lm[23].y];cad=[lm[24].x,lm[24].y]

    cur_x=float(lm[16].x); cur_y=float(lm[16].y)

    ac=(ang(hi,ci,mi)+ang(hd,cd,md))*0.5
    try:
        ri=[lm[25].x,lm[25].y];rd=[lm[26].x,lm[26].y]
        ti=[lm[27].x,lm[27].y];td=[lm[28].x,lm[28].y]
        ar=(ang(cai,ri,ti)+ang(cad,rd,td))*0.5
    except: ar=180

    cy=(cai[1]+cad[1])*0.5
    hy=(hi[1]+hd[1])*0.5
    ba=mi[1]<hi[1] and md[1]<hd[1]
    bl=abs(mi[0]-md[0])>0.4
    ch=abs(hy-cy)<0.12
    cb=cy>0.72; rd2=ar<120

    if ba and not cb:     pos="SALTO"
    elif ch and ac<100:   pos="LAGARTIJA_ABAJO"
    elif ch and ac>150:   pos="LAGARTIJA_ARRIBA"
    elif bl and not rd2:  pos="PORTERIA"
    elif cb and rd2:      pos="SENTADO"
    elif ar>160:          pos="PARADO"
    else:                 pos="DETECTANDO"

    pts=[hi[0],hi[1],hd[0],hd[1],ci[0],ci[1],cd[0],cd[1],
         mi[0],mi[1],md[0],md[1],cai[0],cai[1],cad[0],cad[1]]

    return [cur_x,cur_y,ac,ar,cy,pos]+pts
)PYCODE";

bool mediapipe_init(){
    Py_Initialize();
    PyRun_SimpleString(PY_CODE);
    PyObject* m=PyImport_AddModule("__main__");
    g_py=PyObject_GetAttrString(m,"procesar");
    if(!g_py||!PyCallable_Check(g_py)){cerr<<"[ERROR] MediaPipe\n";return false;}
    cout<<"[OK] MediaPipe Pose — cursor muneca derecha\n";
    return true;
}

struct DatosPose{
    bool   det=false;
    float  cur_x=0.5f,cur_y=0.5f;
    float  pt[8][2]={};
    float  ac=180,ar=180,cy=0.5f;
    string pos="Sin persona";
};

static deque<float> h_cy(5,0.5f),h_ac(5,180.f);
static deque<float> h_cx(4,0.5f),h_cy2(4,0.5f);

DatosPose mediapipe_proc(const Mat& frame){
    DatosPose r;
    if(!g_py||frame.empty())return r;
    int h=frame.rows,w=frame.cols;
    PyObject* pb=PyBytes_FromStringAndSize((const char*)frame.data,h*w*3);
    PyObject* pw=PyLong_FromLong(w);
    PyObject* ph=PyLong_FromLong(h);
    PyObject* ret=PyObject_CallFunctionObjArgs(g_py,pb,pw,ph,nullptr);
    Py_DECREF(pb);Py_DECREF(pw);Py_DECREF(ph);
    if(!ret||ret==Py_None){Py_XDECREF(ret);return r;}

    r.det=true;
    float cx=(float)PyFloat_AsDouble(PyList_GetItem(ret,0));
    float cy2=(float)PyFloat_AsDouble(PyList_GetItem(ret,1));
    h_cx.push_back(cx);  h_cx.pop_front();
    h_cy2.push_back(cy2);h_cy2.pop_front();
    float scx=0,scy=0;
    for(float v:h_cx)scx+=v;  r.cur_x=scx/h_cx.size();
    for(float v:h_cy2)scy+=v; r.cur_y=scy/h_cy2.size();

    float ac=(float)PyFloat_AsDouble(PyList_GetItem(ret,2));
    float cy=(float)PyFloat_AsDouble(PyList_GetItem(ret,4));
    h_ac.push_back(ac);h_ac.pop_front();
    h_cy.push_back(cy);h_cy.pop_front();
    float sa=0,sy=0;
    for(float v:h_ac)sa+=v; r.ac=sa/h_ac.size();
    for(float v:h_cy)sy+=v; r.cy=sy/h_cy.size();
    r.ar=(float)PyFloat_AsDouble(PyList_GetItem(ret,3));
    r.pos=PyUnicode_AsUTF8(PyList_GetItem(ret,5));
    for(int i=0;i<8;i++){
        r.pt[i][0]=(float)PyFloat_AsDouble(PyList_GetItem(ret,6+i*2));
        r.pt[i][1]=(float)PyFloat_AsDouble(PyList_GetItem(ret,6+i*2+1));
    }
    Py_DECREF(ret);
    return r;
}

void dibujar_esqueleto(Mat& img,const DatosPose& d){
    if(!d.det)return;
    int W=img.cols,H=img.rows;
    auto P=[&](int i)->Point{return Point((int)(d.pt[i][0]*W),(int)(d.pt[i][1]*H));};
    line(img,P(0),P(2),Scalar(255,100,100),3);line(img,P(2),P(4),Scalar(255,100,100),3);
    line(img,P(1),P(3),Scalar(100,100,255),3);line(img,P(3),P(5),Scalar(100,100,255),3);
    line(img,P(0),P(1),Scalar(100,255,100),3);
    line(img,P(0),P(6),Scalar(100,255,100),3);line(img,P(1),P(7),Scalar(100,255,100),3);
    line(img,P(6),P(7),Scalar(100,255,100),3);
    Scalar cs[]={Scalar(255,150,150),Scalar(150,150,255),
                 Scalar(255,150,150),Scalar(150,150,255),
                 Scalar(255,200,100),Scalar(200,200,255),
                 Scalar(0,255,255), Scalar(0,255,255)};
    for(int i=0;i<8;i++){circle(img,P(i),8,cs[i],-1);circle(img,P(i),9,Scalar(255,255,255),1);}
    circle(img,P(5),14,Scalar(0,255,255),3);
}

// ══════════════════════════════════════════════════════════════
//  EJERCICIOS
// ══════════════════════════════════════════════════════════════
enum ModoEj{M_SALTO=0,M_LAG=1,M_PORT=2};
enum EstadoCR{CR_INACTIVO,CR_CONTANDO,CR_LISTO};

struct Ej{
    int   cnt=0,meta=10;
    bool  flag=false;
    float cbase=-1.f;
    float hombro_base=-1.f;
    ModoEj modo=M_SALTO;
    string txt="LISTO";
    bool fin=false;
    EstadoCR cr=CR_INACTIVO;
    Uint32   cr_inicio=0;
    int      cr_num=3;
};

static deque<float> hsal(8,0.5f);

void iniciar_cuenta(Ej& e, Uint32 now){
    e.cr=CR_CONTANDO; e.cr_inicio=now; e.cr_num=3;
    e.cnt=0;e.flag=false;e.cbase=-1.f;e.hombro_base=-1.f;e.fin=false;e.txt="LISTO";
    hsal.assign(8,0.5f);
    h_cy.assign(5,0.5f);h_ac.assign(5,180.f);
    h_cx.assign(4,0.5f);h_cy2.assign(4,0.5f);
}

bool update_cuenta(Ej& e, const DatosPose& d, Uint32 now){
    if(e.cr==CR_INACTIVO||e.cr==CR_LISTO)return e.cr==CR_LISTO;
    Uint32 elapsed=now-e.cr_inicio;
    e.cr_num=3-(int)(elapsed/1000);
    if(e.cr_num<=0){
        if(d.det&&d.cy>0.1f&&d.cy<0.9f){
            e.cbase=d.cy; e.hombro_base=(d.pt[0][1]+d.pt[1][1])*0.5f;
            e.cr=CR_LISTO; e.txt="SUELO"; return true;
        }
    }
    return false;
}

bool act_ej(Ej& e, const DatosPose& d){
    if(!d.det||e.cr!=CR_LISTO)return false;
    bool nuevo=false;
    if(e.modo==M_SALTO){
        hsal.push_back(d.cy);hsal.pop_front();
        float cy=0;for(float v:hsal)cy+=v;cy/=hsal.size();
        if(e.hombro_base>0){
            float hy_actual=(d.pt[0][1]+d.pt[1][1])*0.5f;
            float umbral=e.hombro_base*0.90f;
            if(!e.flag&&hy_actual<umbral){
                e.flag=true;e.cnt++;e.txt="ARRIBA! "+to_string(e.cnt);nuevo=true;
            } else if(e.flag&&hy_actual>=umbral){
                e.flag=false;e.txt="SUELO";
            }
        }
    }
    else if(e.modo==M_LAG){
        if(!e.flag&&d.ac<90.f){e.flag=true;e.txt="ABAJO";}
        else if(e.flag&&d.ac>155.f){e.flag=false;e.cnt++;e.txt="ARRIBA";nuevo=true;}
        else if(!e.flag)e.txt="ARRIBA";
    }
    else{
        bool ok=(d.pos=="PORTERIA");
        if(ok&&!e.flag){e.flag=true;e.cnt++;e.txt="BLOQUEADO";nuevo=true;}
        else if(!ok){e.flag=false;e.txt="Extiende brazos";}
    }
    if(e.cnt>=e.meta)e.fin=true;
    return nuevo;
}

// ══════════════════════════════════════════════════════════════
//  SDL2 — helpers
// ══════════════════════════════════════════════════════════════
struct Col{Uint8 r,g,b,a;};
static const Col BT={6,6,6,255},BB={10,22,10,255};
static const Col GR={16,124,16,255},GR2={90,200,90,255};
static const Col TJ={18,18,18,230},TJH={12,40,12,240};
static const Col BI={55,55,55,255},BH={16,124,16,255},BF={160,255,160,255};
static const Col TX={240,240,240,255},ST={130,130,130,255};
static const Col HB={8,14,8,245},HT={180,220,180,255};
static const Col BR={35,35,35,255},BG={16,124,16,255};
static const Col AM={220,180,0,255},CY={50,220,220,255},RJ={200,50,50,255};
static const int SW=1280,SH=720,HUD=48,DN=1500,FM=500;

Col lc(Col a,Col b,float t){
    if(t<0)t=0;if(t>1)t=1;
    return{(Uint8)(a.r+(b.r-a.r)*t),(Uint8)(a.g+(b.g-a.g)*t),
           (Uint8)(a.b+(b.b-a.b)*t),(Uint8)(a.a+(b.a-a.a)*t)};}

void fb(SDL_Renderer* r,SDL_Rect rc,Col c){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);SDL_RenderFillRect(r,&rc);
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

void ob(SDL_Renderer* r,SDL_Rect rc,Col c,int g=1){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
    for(int i=0;i<g;i++){SDL_Rect b={rc.x-i,rc.y-i,rc.w+2*i,rc.h+2*i};SDL_RenderDrawRect(r,&b);}
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

void lb(SDL_Renderer* r,int x1,int y1,int x2,int y2,Col c){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);SDL_RenderDrawLine(r,x1,y1,x2,y2);
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

void cc(SDL_Renderer* r,int cx,int cy,int rd,Col c){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
    for(int dy=-rd;dy<=rd;dy++){
        int dx=(int)sqrt((double)(rd*rd-dy*dy));
        SDL_RenderDrawLine(r,cx-dx,cy+dy,cx+dx,cy+dy);}
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

void dt(SDL_Renderer* r,TTF_Font* f,const string& s,int cx,int cy,Col c,bool cen=true){
    SDL_Color sc={c.r,c.g,c.b,c.a};
    SDL_Surface* su=TTF_RenderUTF8_Blended(f,s.c_str(),sc);if(!su)return;
    SDL_Texture* t=SDL_CreateTextureFromSurface(r,su);
    SDL_Rect d=cen?SDL_Rect{cx-su->w/2,cy-su->h/2,su->w,su->h}
                  :SDL_Rect{cx,cy-su->h/2,su->w,su->h};
    SDL_SetTextureBlendMode(t,SDL_BLENDMODE_BLEND);
    SDL_RenderCopy(r,t,nullptr,&d);SDL_FreeSurface(su);SDL_DestroyTexture(t);}

void fondo(SDL_Renderer* r){
    int z=SH-HUD;
    for(int y=0;y<z;y++){
        Col c=lc(BT,BB,(float)y/z);
        SDL_SetRenderDrawColor(r,c.r,c.g,c.b,255);
        SDL_RenderDrawLine(r,0,y,SW,y);}
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,16,50,16,18);
    for(int x=0;x<SW;x+=60)SDL_RenderDrawLine(r,x,0,x,z);
    for(int y=0;y<z;y+=60)SDL_RenderDrawLine(r,0,y,SW,y);
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// ── CPU / RAM ─────────────────────────────────────────────────
struct EstadoCPU{long long idle,total;};
EstadoCPU leer_cpu2(){
    ifstream f("/proc/stat");string l;getline(f,l);
    istringstream ss(l);string t;ss>>t;
    long long u,n,s,i,w,x,y,z;ss>>u>>n>>s>>i>>w>>x>>y>>z;
    return{i,u+n+s+i+w+x+y+z};}
float cpct(const EstadoCPU& p,const EstadoCPU& c){
    long long dt=c.total-p.total,di=c.idle-p.idle;
    if(!dt)return 0;return(1-(float)di/dt)*100;}
float lram(){
    ifstream f("/proc/meminfo");string k;long long v,tot=0,av=0;
    for(int i=0;i<30&&f;i++){f>>k>>v;f.ignore(256,'\n');
    if(k=="MemTotal:")tot=v;if(k=="MemAvailable:")av=v;if(tot&&av)break;}
    return tot?((float)(tot-av)/tot*100):0;}

// ── HUD ──────────────────────────────────────────────────────
void hud(SDL_Renderer* r,TTF_Font* f,float cpu,float ram,
         bool det,Uint32 now,const string& modo,bool kinect){
    int hy=SH-HUD;fb(r,{0,hy,SW,HUD},HB);lb(r,0,hy,SW,hy,{16,124,16,80});
    int cy2=hy+HUD/2;
    dt(r,f,"CPU",60,cy2,HT);fb(r,{100,cy2-7,180,14},BR);
    Col cc2=(cpu>80)?RJ:(cpu>60)?AM:BG;
    if((int)(180*cpu/100)>0)fb(r,{100,cy2-7,(int)(180*cpu/100),14},cc2);
    char buf[40];snprintf(buf,sizeof(buf),"%.0f%%",cpu);dt(r,f,buf,300,cy2,HT);
    dt(r,f,"RAM",360,cy2,HT);fb(r,{400,cy2-7,180,14},BR);
    if((int)(180*ram/100)>0)fb(r,{400,cy2-7,(int)(180*ram/100),14},BG);
    snprintf(buf,sizeof(buf),"%.0f%%",ram);dt(r,f,buf,600,cy2,HT);
    dt(r,f,det?"Persona: OK":"Persona: --",780,cy2,det?Col{16,200,16,255}:RJ);
    dt(r,f,kinect?"CAM: KINECT":"CAM: WEBCAM",980,cy2,
       kinect?Col{50,220,220,255}:Col{220,180,0,255});
    dt(r,f,"Modo: "+modo,1160,cy2,CY);
    Uint32 s=now/1000;snprintf(buf,sizeof(buf),"%02d:%02d",s/60,s%60);
    dt(r,f,buf,SW-40,cy2,ST);}

// ── Cursor ───────────────────────────────────────────────────
void cur(SDL_Renderer* r,int cx,int cy,Uint32 now){
    float p=(float)(sin(now/300.0)*0.5+0.5);
    int rd=14+(int)(p*3);Uint8 al=(Uint8)(180+p*60);
    cc(r,cx,cy,rd,{16,124,16,al});cc(r,cx,cy,rd-5,{0,0,0,200});
    cc(r,cx,cy,4,{16,124,16,255});
    lb(r,cx-20,cy,cx-8,cy,{255,255,255,180});
    lb(r,cx+8,cy,cx+20,cy,{255,255,255,180});
    lb(r,cx,cy-20,cx,cy-8,{255,255,255,180});
    lb(r,cx,cy+8,cx,cy+20,{255,255,255,180});}

// ══════════════════════════════════════════════════════════════
//  ICONOS MEJORADOS v2
// ══════════════════════════════════════════════════════════════

// Linea gruesa helper
void lkg(SDL_Renderer* r,int x1,int y1,int x2,int y2,Col c,int g=3){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
    for(int i=-g/2;i<=g/2;i++){
        SDL_RenderDrawLine(r,x1+i,y1,x2+i,y2);
        SDL_RenderDrawLine(r,x1,y1+i,x2,y2+i);
    }
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);
}

// Flecha hacia arriba
void flecha_arriba(SDL_Renderer* r,int cx,int cy,Col c,int tam=12){
    lkg(r,cx,cy+tam,cx,cy-tam,c,3);
    lkg(r,cx,cy-tam,cx-6,cy-2,c,3);
    lkg(r,cx,cy-tam,cx+6,cy-2,c,3);
}

// SALTO
void icono_salto(SDL_Renderer* r,int cx,int cy){
    Col c  ={240,240,240,255};
    Col ca ={90,200,90,255};

    // cabeza
    cc(r,cx,cy-26,8,c);

    // cuerpo
    lkg(r,cx,cy-16,cx,cy+10,c,3);

    // brazos arriba
    lkg(r,cx,cy-10,cx-22,cy-30,c,3);
    lkg(r,cx,cy-10,cx+22,cy-30,c,3);

    // piernas abiertas
    lkg(r,cx,cy+10,cx-18,cy+34,c,3);
    lkg(r,cx,cy+10,cx+18,cy+34,c,3);

    // flechas de movimiento
    flecha_arriba(r,cx-30,cy-26,ca,10);
    flecha_arriba(r,cx+30,cy-26,ca,10);
}

// LAGARTIJA
void icono_lagartija(SDL_Renderer* r,int cx,int cy){
    Col c={240,240,240,255};

    // cabeza
    cc(r,cx+34,cy-8,6,c);

    // torso horizontal
    lkg(r,cx-30,cy,cx+20,cy,c,3);

    // brazo delantero
    lkg(r,cx+10,cy,cx+4,cy+18,c,3);
    lkg(r,cx+4,cy+18,cx+14,cy+18,c,3);

    // brazo trasero
    lkg(r,cx-6,cy,cx-12,cy+18,c,3);
    lkg(r,cx-12,cy+18,cx-2,cy+18,c,3);

    // pierna trasera
    lkg(r,cx-30,cy,cx-42,cy+16,c,3);
    lkg(r,cx-42,cy+16,cx-34,cy+16,c,3);

    // pierna media / apoyo
    lkg(r,cx-16,cy,cx-22,cy+18,c,3);
    lkg(r,cx-22,cy+18,cx-14,cy+18,c,3);
}

// PORTERO
void icono_portero(SDL_Renderer* r,int cx,int cy){
    Col c  ={240,240,240,255};
    Col cb ={50,220,220,255};

    // cabeza
    cc(r,cx+8,cy-20,7,c);

    // torso en diagonal (volando a la derecha)
    lkg(r,cx-6,cy+6,cx+10,cy-10,c,3);

    // brazo izquierdo
    lkg(r,cx+6,cy-10,cx-18,cy,c,3);

    // brazo derecho extendido hacia el balón
    lkg(r,cx+10,cy-10,cx+34,cy-24,c,3);
    lkg(r,cx+34,cy-24,cx+50,cy-36,c,3);

    // piernas
    lkg(r,cx-6,cy+6,cx-28,cy+24,c,3);
    lkg(r,cx-6,cy+6,cx+10,cy+28,c,3);

    // balón
    cc(r,cx+58,cy-42,5,cb);
}
// ══════════════════════════════════════════════════════════════
//  BOTONES con dwell
// ══════════════════════════════════════════════════════════════
struct Btn{SDL_Rect rect;string etiq,sub;bool hover,flash;Uint32 th,tf;};

void dwb(SDL_Renderer* r,SDL_Rect rect,float t){
    if(t<=0)return;Col col=lc(GR,GR2,t);
    float per=2.f*(rect.w+rect.h),lon=per*t;
    struct Seg{int x1,y1,x2,y2;float l;};
    Seg sg[4]={
        {rect.x,       rect.y,       rect.x+rect.w,rect.y,       (float)rect.w},
        {rect.x+rect.w,rect.y,       rect.x+rect.w,rect.y+rect.h,(float)rect.h},
        {rect.x+rect.w,rect.y+rect.h,rect.x,       rect.y+rect.h,(float)rect.w},
        {rect.x,       rect.y+rect.h,rect.x,       rect.y,       (float)rect.h}};
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);float res=lon;
    for(auto& s:sg){
        if(res<=0)break;float f2=(res>=s.l)?1:res/s.l;
        int ex=(int)(s.x1+(s.x2-s.x1)*f2),ey=(int)(s.y1+(s.y2-s.y1)*f2);
        for(int gi=0;gi<4;gi++){bool h2=(s.y1==s.y2);
            SDL_SetRenderDrawColor(r,col.r,col.g,col.b,(Uint8)(200-gi*40));
            SDL_RenderDrawLine(r,s.x1+(h2?0:gi),s.y1+(h2?gi:0),
                                 ex  +(h2?0:gi),ey  +(h2?gi:0));}
        res-=s.l;}
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

void drb(SDL_Renderer* r,TTF_Font* fg,TTF_Font* fc,const Btn& b,Uint32 now){
    float td=0;if(b.hover&&!b.flash)td=min(1.f,(float)(now-b.th)/DN);
    Col bg=b.hover?lc(TJ,TJH,td):TJ;fb(r,b.rect,bg);
    Col bd=b.flash?BF:b.hover?BH:BI;ob(r,b.rect,bd,2);
    if(!b.flash){
        dwb(r,b.rect,td);
        if(b.hover&&b.th>0){
            fb(r,{b.rect.x,b.rect.y+b.rect.h+3,b.rect.w,5},BR);
            int bw=(int)(b.rect.w*td);
            if(bw>0)fb(r,{b.rect.x,b.rect.y+b.rect.h+3,bw,5},CY);}}
    int cx2=b.rect.x+b.rect.w/2,cy2=b.rect.y+b.rect.h/2;
    dt(r,fg,b.etiq,cx2,b.rect.y+b.rect.h-45,TX);
    dt(r,fc,b.sub, cx2,b.rect.y+b.rect.h-18,ST);}

bool upb(Btn& b,int cx,int cy,Uint32 now){
    bool en=(cx>=b.rect.x&&cx<=b.rect.x+b.rect.w&&
             cy>=b.rect.y&&cy<=b.rect.y+b.rect.h);
    if(en){
        if(!b.hover){b.hover=true;b.th=now;}
        if(!b.flash&&(now-b.th)>=(Uint32)DN){b.flash=true;b.tf=now;return true;}}
    else b.hover=false;
    return false;}

bool enb(const Btn& b,int px,int py){
    return px>=b.rect.x&&px<=b.rect.x+b.rect.w&&
           py>=b.rect.y&&py<=b.rect.y+b.rect.h;}

void reset_btn(Btn& b){b.hover=false;b.flash=false;b.th=0;b.tf=0;}

// ── Cuenta regresiva SDL ──────────────────────────────────────
void render_cuenta_sdl(SDL_Renderer* r,TTF_Font* ft,TTF_Font* fg,
                       const Ej& e,Uint32 now){
    fb(r,{0,0,SW,SH-HUD},{0,0,0,180});
    if(e.cr_num>0){
        char buf[4];snprintf(buf,sizeof(buf),"%d",e.cr_num);
        dt(r,ft,buf,SW/2,SH/2-60,{90,200,90,255});
        dt(r,fg,"Ponte en posicion de SUELO",SW/2,SH/2+60,TX);
    } else {
        dt(r,ft,"YA!",SW/2,SH/2-60,{90,200,90,255});
        dt(r,fg,"Posicion calibrada!",SW/2,SH/2+60,TX);}}

// ══════════════════════════════════════════════════════════════
//  ESTADOS
// ══════════════════════════════════════════════════════════════
enum Estado{MENU,OPCIONES,JUEGO,RESULTADO};

// ══════════════════════════════════════════════════════════════
//  MAIN
// ══════════════════════════════════════════════════════════════
int main(){
    srand((unsigned)time(NULL));
    thread kthr,wthr;
    if(kinect_init()){
        g_usar_kinect=true;
        kthr=thread(kinect_loop);
        cout<<"[OK] Kinect detectado\n";
    } else {
        g_usar_kinect=false;
        if(!webcam_init()){cerr<<"[ERROR] No hay Kinect ni Webcam\n";return -1;}
        wthr=thread(webcam_loop);
        cout<<"[OK] Usando Webcam\n";
    }
    if(!mediapipe_init()){
        g_running=false;
        if(g_usar_kinect&&kthr.joinable())kthr.join();
        if(!g_usar_kinect&&wthr.joinable())wthr.join();
        return -1;
    }

    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)<0)return -1;
    if(TTF_Init()<0)return -1;
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048);
    Mix_Music* mm=Mix_LoadMUS("assets/menuprincipal.wav");
    Mix_Music* mj=Mix_LoadMUS("assets/jugando.wav");
    if(mm)Mix_PlayMusic(mm,-1);

    const char* titulo=g_usar_kinect?"Conteo Ejercicios v17 - UAA [KINECT]"
                                     :"Conteo Ejercicios v17 - UAA [WEBCAM]";
    SDL_Window* win = SDL_CreateWindow(
    titulo,
    SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,
    SW,SH,
    SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
	);    
	SDL_Renderer* ren = SDL_CreateRenderer(win,-1,
    SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
	);

	SDL_RenderSetLogicalSize(ren, SW, SH);
	SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    const char* F1="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
    const char* F2="/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf";
    TTF_Font* ft=TTF_OpenFont(F1,72);
    TTF_Font* fg=TTF_OpenFont(F1,28);
    TTF_Font* fc=TTF_OpenFont(F2,16);

    const char* cv_win=g_usar_kinect?"Vision v17 - KINECT":"Vision v17 - WEBCAM";
    namedWindow(cv_win, WINDOW_NORMAL);

	// Preview pequeño de la cámara
	resizeWindow(cv_win, 480, 270);
	moveWindow(cv_win, 20, 20);

    // ── Layout menú ───────────────────────────────────────────
    // 3 botones grandes centrados verticalmente
    int aw=280,ah=220,mg=55;
    int tw=3*aw+2*mg;
    int ox=(SW-tw)/2;
    int oy=160;   // mas arriba para dejar espacio a botones inferiores

    vector<Btn> bm={
        {{ox,          oy,aw,ah},"SALTOS",   "[1]",false,false,0,0},
        {{ox+aw+mg,    oy,aw,ah},"LAGARTIJA","[2]",false,false,0,0},
        {{ox+2*(aw+mg),oy,aw,ah},"PORTERO",  "[3]",false,false,0,0},
    };

    // Botones inferiores: OPCIONES y SALIR lado a lado
    int bw2=220,bh2=65;
    int by2=oy+ah+40;
    Btn bopc={{SW/2-bw2-20,by2,bw2,bh2},"OPCIONES","[O]",false,false,0,0};
    Btn bsal={{SW/2+20,    by2,bw2,bh2},"SALIR",   "[ESC]",false,false,0,0};

    // Botones en juego
    Btn bv ={{20,10,180,50},"< VOLVER","",false,false,0,0};
    // Botones en resultado
    Btn br ={{SW/2-170,500,300,70},"REINICIAR","",false,false,0,0};
    Btn bmr={{SW/2+150,500,200,70},"MENU","",false,false,0,0};

    // Botones en opciones
    int meta_tmp=10;
    Btn bmen={{SW/2-140,300,100,70},"-","",false,false,0,0};
    Btn bmas={{SW/2+40, 300,100,70},"+","",false,false,0,0};
    Btn bguard={{SW/2-140,430,280,70},"GUARDAR","y volver",false,false,0,0};

    Ej ej;
    Estado estado=MENU;
    DatosPose datos;
    Mat fk;
    int fc2=0,cur_x=SW/2,cur_y=SH/2;
    Uint32 t0=0;
    string NM[]={"SALTOS","LAGARTIJAS","PORTERIA"};
    Col CM[]={{16,200,16,255},{50,220,220,255},{220,180,0,255}};

    EstadoCPU cpup=leer_cpu2();
    float cpup2=0,ramp=0;Uint32 tcpu=0;
    bool run=true;SDL_Event ev;

    while(run){
        Uint32 now=SDL_GetTicks();

        // ── Eventos ──────────────────────────────────────────
        while(SDL_PollEvent(&ev)){
            if(ev.type==SDL_QUIT)run=false;
            if(ev.type==SDL_MOUSEBUTTONDOWN&&ev.button.button==SDL_BUTTON_LEFT){
                int mx=ev.button.x,my=ev.button.y;
                if(estado==MENU){
                    for(int i=0;i<3;i++)if(enb(bm[i],mx,my)){
                        ej.modo=(ModoEj)i;estado=JUEGO;t0=now;
                        iniciar_cuenta(ej,now);
                        Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(enb(bopc,mx,my)){
                        meta_tmp=ej.meta;
                        reset_btn(bmen);reset_btn(bmas);reset_btn(bguard);
                        estado=OPCIONES;}
                    if(enb(bsal,mx,my))run=false;
                }
                if(estado==JUEGO && enb(bv,mx,my)){
    		estado=MENU;
    		reset_btn(bv);
    		Mix_HaltMusic();
    		if(mm) Mix_PlayMusic(mm,-1);
		}
                if(estado==RESULTADO){
                    if(enb(br,mx,my)){estado=JUEGO;t0=now;iniciar_cuenta(ej,now);
                        Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(enb(bmr,mx,my)){estado=MENU;
                        Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);}
                }
                if(estado==OPCIONES){
                    if(enb(bmen,mx,my)) meta_tmp=max(5,meta_tmp-5);
                    if(enb(bmas,mx,my)) meta_tmp=min(50,meta_tmp+5);
                    if(enb(bguard,mx,my)){ej.meta=meta_tmp;estado=MENU;}
                }
            }
            if(ev.type==SDL_KEYDOWN){
                auto k=ev.key.keysym.sym;
                if(k==SDLK_ESCAPE){
                    if(estado==MENU)run=false;
                    else if(estado==OPCIONES){estado=MENU;}
                    else{estado=MENU;Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);}}
                if(estado==MENU){
                    if(k==SDLK_o){
                        meta_tmp=ej.meta;
                        reset_btn(bmen);reset_btn(bmas);reset_btn(bguard);
                        estado=OPCIONES;}
                    if(k==SDLK_1||k==SDLK_KP_1){ej.modo=M_SALTO;estado=JUEGO;t0=now;iniciar_cuenta(ej,now);Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(k==SDLK_2||k==SDLK_KP_2){ej.modo=M_LAG;  estado=JUEGO;t0=now;iniciar_cuenta(ej,now);Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(k==SDLK_3||k==SDLK_KP_3){ej.modo=M_PORT; estado=JUEGO;t0=now;iniciar_cuenta(ej,now);Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                }
                if(estado==JUEGO){
                    if(k==SDLK_r)iniciar_cuenta(ej,now);
                    if(k==SDLK_PLUS ||k==SDLK_KP_PLUS) ej.meta=min(50,ej.meta+5);
                    if(k==SDLK_MINUS||k==SDLK_KP_MINUS)ej.meta=max(5, ej.meta-5);
                }
                if(estado==OPCIONES){
                    if(k==SDLK_PLUS ||k==SDLK_KP_PLUS) meta_tmp=min(50,meta_tmp+5);
                    if(k==SDLK_MINUS||k==SDLK_KP_MINUS)meta_tmp=max(5, meta_tmp-5);
                    if(k==SDLK_RETURN){ej.meta=meta_tmp;estado=MENU;}
                }
            }
        }

        // ── Captura ───────────────────────────────────────────
        fc2++;
        fk=captura_get_rgb();
        if(!fk.empty()&&fc2%3==0)
            datos=mediapipe_proc(fk);

        // Cursor
        if(datos.det){
            float nx=(datos.cur_x-0.25f)/(1.0f-2.0f*0.25f);
            float ny=(datos.cur_y-0.20f)/(1.0f-2.0f*0.20f);
            nx=max(0.f,min(1.f,nx));ny=max(0.f,min(1.f,ny));
            cur_x=(int)(nx*SW);cur_y=(int)(ny*(SH-HUD));}

        if(now-tcpu>=800){
            EstadoCPU c=leer_cpu2();cpup2=cpct(cpup,c);
            cpup=c;ramp=lram();tcpu=now;}

        if(estado==JUEGO){
            bool calibrado=update_cuenta(ej,datos,now);
            if(calibrado&&!ej.fin){
                act_ej(ej,datos);
                if(ej.fin){
                    Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);
                    estado=RESULTADO;
                    imprimir_ticket_aleatorio();
                }
            }
        }

        // ── Ventana OpenCV ────────────────────────────────────
        if(!fk.empty()){
            Mat disp;resize(fk,disp,Size(SW,SH));
            dibujar_esqueleto(disp,datos);
            if(!datos.det){
                Mat verde(SH,SW,CV_8UC3,Scalar(0,120,0));
                addWeighted(disp,0.3,verde,0.7,0,disp);
                putText(disp,"JUGADOR NO DETECTADO",Point(SW/2-300,SH/2),
                        FONT_HERSHEY_DUPLEX,1.5,Scalar(255,255,255),3);}
            rectangle(disp,Point(0,0),Point(SW-1,SH-1),Scalar(0,255,255),8);
            rectangle(disp,Point(4,4),Point(SW-5,SH-5),Scalar(0,150,150),2);
            rectangle(disp,Point(0,0),Point(SW,55),Scalar(0,0,0),-1);
            Scalar cp2(150,150,150);
            if(datos.pos=="SALTO")           cp2=Scalar(0,255,0);
            if(datos.pos=="LAGARTIJA_ABAJO") cp2=Scalar(255,165,0);
            if(datos.pos=="PORTERIA")        cp2=Scalar(255,255,0);
            putText(disp,datos.pos,Point(10,40),FONT_HERSHEY_DUPLEX,1.0,cp2,2);
            char sc2[50];snprintf(sc2,sizeof(sc2),"%s %d/%d  %s",
                NM[ej.modo].c_str(),ej.cnt,ej.meta,ej.txt.c_str());
            putText(disp,sc2,Point(SW/2-300,40),FONT_HERSHEY_DUPLEX,0.85,Scalar(0,255,255),2);
            if(estado==JUEGO&&ej.cr==CR_CONTANDO){
                char cr_buf[10];snprintf(cr_buf,sizeof(cr_buf),"%d",max(0,ej.cr_num));
                putText(disp,cr_buf,Point(SW/2-40,SH/2+30),
                        FONT_HERSHEY_DUPLEX,5.0,Scalar(0,255,0),8);}
            if(ej.hombro_base>0&&estado==JUEGO){
                int ly=(int)(ej.hombro_base*0.90f*SH);
                line(disp,Point(0,ly),Point(SW,ly),Scalar(0,0,255),3);
                putText(disp,"umbral salto",Point(10,ly-8),
                        FONT_HERSHEY_SIMPLEX,0.6,Scalar(0,0,255),2);}
            imshow(cv_win,disp);}
        waitKey(1);

        // ── SDL Render ────────────────────────────────────────
        fondo(ren);

        // ════ MENU ════════════════════════════════════════════
        if(estado==MENU){
            cc(ren,55,42,28,{16,124,16,200});
            cc(ren,55,42,22,{10,10,10,255});
            cc(ren,55,42,18,{16,124,16,180});
            lb(ren,0,100,SW,100,{16,124,16,150});
            dt(ren,fg,"CONTEO DE EJERCICIOS",SW/2,52,TX);

            // 3 botones de ejercicio
            for(int i=0;i<3;i++){
                if(upb(bm[i],cur_x,cur_y,now)){
                    ej.modo=(ModoEj)i;estado=JUEGO;t0=now;
                    iniciar_cuenta(ej,now);
                    Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);bm[i].flash=false;}
                drb(ren,fg,fc,bm[i],now);
                // Iconos centrados en la tarjeta (zona superior)
                int ico_cx=bm[i].rect.x+bm[i].rect.w/2;
                int ico_cy=bm[i].rect.y+bm[i].rect.h/2-30;
                if(i==0) icono_salto(    ren,ico_cx,ico_cy);
                if(i==1) icono_lagartija(ren,ico_cx,ico_cy);
                if(i==2) icono_portero(  ren,ico_cx,ico_cy);
                if(bm[i].flash&&(now-bm[i].tf)>=(Uint32)FM)
                    {bm[i].flash=false;bm[i].hover=false;}
            }

            // OPCIONES y SALIR
            if(upb(bopc,cur_x,cur_y,now)){
                meta_tmp=ej.meta;
                reset_btn(bmen);reset_btn(bmas);reset_btn(bguard);
                estado=OPCIONES;bopc.flash=false;}
            if(upb(bsal,cur_x,cur_y,now))run=false;
            drb(ren,fg,fc,bopc,now);
            drb(ren,fg,fc,bsal,now);
            if(bopc.flash&&(now-bopc.tf)>=(Uint32)FM){bopc.flash=false;bopc.hover=false;}
            if(bsal.flash&&(now-bsal.tf)>=(Uint32)FM){bsal.flash=false;bsal.hover=false;}

            // Info inferior
            char mb[30];snprintf(mb,sizeof(mb),"Meta actual: %d reps",ej.meta);
            dt(ren,fc,mb,SW/2,by2+bh2+25,GR2);
            dt(ren,fc,"[1]Salto  [2]Lagartija  [3]Porteria  [O]Opciones  [+/-]Meta",
               SW/2,by2+bh2+50,ST);
        }

        // ════ OPCIONES ════════════════════════════════════════
        else if(estado==OPCIONES){
            lb(ren,0,100,SW,100,{16,124,16,150});
            dt(ren,fg,"OPCIONES",SW/2,52,TX);

            dt(ren,fg,"Meta de repeticiones",SW/2,220,TX);

            // Numero grande
            char mb[10];snprintf(mb,sizeof(mb),"%d",meta_tmp);
            dt(ren,ft,mb,SW/2,290,GR2);

            // Botones - y +
            drb(ren,ft,fc,bmen,now);
            drb(ren,ft,fc,bmas,now);

            // Barra de progreso visual de la meta
            int bx=SW/2-200,bw=400,bh2b=12,byb=370;
            fb(ren,{bx,byb,bw,bh2b},{30,30,30,200});
            float prog=(float)(meta_tmp-5)/45.f;
            if((int)(bw*prog)>0)fb(ren,{bx,byb,(int)(bw*prog),bh2b},lc(GR,GR2,prog));
            ob(ren,{bx,byb,bw,bh2b},{80,80,80,255},1);
            dt(ren,fc,"5",bx-15,byb+bh2b/2,ST);
            dt(ren,fc,"50",bx+bw+18,byb+bh2b/2,ST);

            // Boton guardar
            if(upb(bguard,cur_x,cur_y,now)){
                ej.meta=meta_tmp;estado=MENU;bguard.flash=false;}
            drb(ren,fg,fc,bguard,now);
            if(bguard.flash&&(now-bguard.tf)>=(Uint32)FM)
                {bguard.flash=false;bguard.hover=false;}

            // Dwell en - y +
            if(upb(bmen,cur_x,cur_y,now)){
                meta_tmp=max(5,meta_tmp-5);reset_btn(bmen);}
            if(upb(bmas,cur_x,cur_y,now)){
                meta_tmp=min(50,meta_tmp+5);reset_btn(bmas);}

            dt(ren,fc,"[+/-] ajustar   [ENTER] guardar   [ESC] cancelar",
               SW/2,530,ST);
        }

        // ════ JUEGO ═══════════════════════════════════════════
        else if(estado==JUEGO){
    Col cm=CM[ej.modo];
    lb(ren,0,75,SW,75,{cm.r,cm.g,cm.b,150});
    dt(ren,fg,NM[ej.modo],SW/2,40,cm);

    if(ej.cr==CR_CONTANDO){
        render_cuenta_sdl(ren,ft,fg,ej,now);
    } 
    else {
        // Contador grande
        char cnt[10];snprintf(cnt,sizeof(cnt),"%d",ej.cnt);
        dt(ren,ft,cnt,SW/2,220,TX);
        dt(ren,fg,"repeticiones",SW/2,310,ST);

        // Barra progreso
        float prog=min(1.f,(float)ej.cnt/ej.meta);
        int bx=SW/2-350,bw=700,bh=30,by=360;
        fb(ren,{bx,by,bw,bh},{30,30,30,200});
        if((int)(bw*prog)>0)
            fb(ren,{bx,by,(int)(bw*prog),bh},lc(GR,GR2,prog));
        ob(ren,{bx,by,bw,bh},{80,80,80,255},1);

        char pb[20];snprintf(pb,sizeof(pb),"%d / %d",ej.cnt,ej.meta);
        dt(ren,fc,pb,SW/2,by+bh/2,TX);

        dt(ren,fg,ej.txt,SW/2,430,AM);

        Uint32 s=(now-t0)/1000;
        char tb[20];snprintf(tb,sizeof(tb),"Tiempo: %02d:%02d",s/60,s%60);
        dt(ren,fc,tb,SW/2,490,ST);

        dt(ren,fc,"[R]Reiniciar  [ESC]Menu  [+/-]Meta",
           SW/2,530,{80,80,80,255});
    }

    // Boton VOLVER visible siempre en JUEGO,
    // incluso durante la cuenta regresiva
    if(upb(bv,cur_x,cur_y,now)){
        estado=MENU;
        reset_btn(bv);
        Mix_HaltMusic();
        if(mm) Mix_PlayMusic(mm,-1);
    }

    drb(ren,fc,fc,bv,now);

    if(bv.flash&&(now-bv.tf)>=(Uint32)FM){
        bv.flash=false;
        bv.hover=false;
    }
}

        // ════ RESULTADO ═══════════════════════════════════════
        else if(estado==RESULTADO){
            float p=(float)(sin(now/600.0)*0.5+0.5);
            fb(ren,{0,0,SW,SH-HUD},{0,(Uint8)(30+p*20),0,(Uint8)(40+p*30)});
            dt(ren,ft,"COMPLETADO!",SW/2,120,GR2);
            char buf[10];snprintf(buf,sizeof(buf),"%d",ej.cnt);
            dt(ren,ft,buf,SW/2,280,TX);
            dt(ren,fg,NM[ej.modo]+" realizadas",SW/2,360,ST);
            if(upb(br, cur_x,cur_y,now)){
                estado=JUEGO;t0=now;iniciar_cuenta(ej,now);br.flash=false;
                Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
            if(upb(bmr,cur_x,cur_y,now)){
                estado=MENU;bmr.flash=false;
                Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);}
            drb(ren,fg,fc,br, now);
            drb(ren,fg,fc,bmr,now);
            if(br.flash &&(now-br.tf) >=(Uint32)FM){br.flash=false; br.hover=false;}
            if(bmr.flash&&(now-bmr.tf)>=(Uint32)FM){bmr.flash=false;bmr.hover=false;}
        }

        cur(ren,cur_x,cur_y,now);
        hud(ren,fc,cpup2,ramp,datos.det,now,NM[ej.modo],g_usar_kinect);
        SDL_RenderPresent(ren);
    }

    // ── Limpieza ──────────────────────────────────────────────
    destroyAllWindows();
    g_running=false;
    if(g_usar_kinect){
        freenect_stop_video(g_dev);freenect_stop_depth(g_dev);
        if(kthr.joinable())kthr.join();
        freenect_close_device(g_dev);freenect_shutdown(g_ctx);
    } else {
        if(wthr.joinable())wthr.join();
        g_cap.release();}
    Py_XDECREF(g_py);Py_Finalize();
    Mix_HaltMusic();
    if(mm)Mix_FreeMusic(mm);if(mj)Mix_FreeMusic(mj);
    Mix_CloseAudio();
    TTF_CloseFont(ft);TTF_CloseFont(fg);TTF_CloseFont(fc);TTF_Quit();
    SDL_DestroyRenderer(ren);SDL_DestroyWindow(win);SDL_Quit();
    return 0;
}
