// ============================================================
//  juego.cpp  —  V17.2
//  BASE: ConteoEjercicio_v16.cpp
//  NUEVO v17:
//    - Pantalla OPCIONES con meta ajustable por dwell
//    - Boton OPCIONES en menu junto a SALIR
//    - Layout menu rebalanceado (botones centrados)
//    - Iconos mejorados: salto con flechas, lagartija lateral, portero
//    - Boton VOLVER visible en los 3 modos de ejercicio
//    - Compilar con python3.11-config
//
//  NUEVO v17.1 (premios):
//    - Catalogo de 10 premios (igual al programa standalone de impresion)
//    - Al completar un reto se elige un premio AL AZAR
//    - El premio elegido NUNCA es el mismo que el premio anterior
//      (ver elegir_premio_aleatorio()), dando la sensacion de que
//      los premios "no se repiten"
//    - srand() ahora se siembra una sola vez al inicio de main()
//
//  NUEVO v17.2 (comentarios extendidos):
//    - Comentarios linea por linea en las partes mas "magicas" del
//      codigo: el codigo Python embebido (clasificacion de postura),
//      el puente C++ <-> Python (mediapipe_proc), los callbacks de
//      camara, los comandos ESC/POS de la impresora, y la animacion
//      del borde de los botones (dwell). La idea es que, leyendo el
//      comentario de cada linea, puedas explicar que hace SIN tener
//      que adivinar a partir del codigo solo.
//
//  Compilar:
//    g++ juego.cpp -o juego \
//        -O3 -march=armv8-a -rdynamic \
//        $(pkg-config --cflags --libs opencv4 libfreenect sdl2 SDL2_ttf) \
//        $(python3.11-config --includes --ldflags --embed) \
//        -lSDL2_mixer -pthread -lm
// ============================================================

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <opencv2/opencv.hpp>
#include <libfreenect.h>
#include <Python.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <cmath>
#include <mutex>
#include <thread>
#include <atomic>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <ctime>
#include <cstdio>
#include <cstring>
#include <cstdlib>   // rand() / srand() — los necesitamos para el premio aleatorio

using namespace std;
using namespace cv;

// --------------------------------------------------------------
//  CAPTURA — Kinect (prioritario) o Webcam (fallback)
// --------------------------------------------------------------
static Mat   g_rgb, g_depth;          // ultimo frame de color y de profundidad capturados
static mutex g_rgb_mtx, g_depth_mtx;  // candados para que dos hilos no toquen g_rgb/g_depth al mismo tiempo
static atomic<bool> g_running(true);  // bandera global "sigue corriendo el programa" (atomic = segura entre hilos)
static bool g_usar_kinect = false;    // true si se detecto Kinect; false si se usa webcam de respaldo

static freenect_context* g_ctx=nullptr;  // contexto de la libreria libfreenect (representa la conexion con el driver)
static freenect_device*  g_dev=nullptr;  // el dispositivo Kinect en si (una vez abierto)

// Callback del Kinect: la libreria libfreenect llama esta funcion SOLA,
// automaticamente, cada vez que llega un frame nuevo de video RGB.
// Convierte de RGB a BGR (formato de OpenCV), lo refleja horizontalmente
// (efecto espejo, para que el usuario se vea como en un espejo) y lo
// guarda reducido de tamano en la variable global g_rgb.
static void video_cb(freenect_device*,void* rgb,uint32_t){
    lock_guard<mutex> lk(g_rgb_mtx);          // bloquea el mutex mientras dura esta funcion (se libera solo al salir)
    Mat tmp(480,640,CV_8UC3,rgb);             // envuelve el buffer crudo del Kinect como una Mat de OpenCV (480x640, 3 canales)
    Mat bgr; cvtColor(tmp,bgr,COLOR_RGB2BGR); // el Kinect entrega en RGB; OpenCV espera BGR internamente
    Mat fl; flip(bgr,fl,1);                   // flip(...,1) = espejo horizontal (eje vertical de simetria)
    resize(fl,g_rgb,Size(160,120));           // reduce a 160x120 (rapido de procesar) y lo deja en la variable compartida
}
// Callback del Kinect para el sensor de profundidad: convierte el mapa de
// profundidad de 16 bits a 8 bits (para poder visualizarlo facilmente),
// lo refleja igual que el video, y lo guarda reducido en g_depth.
static void depth_cb(freenect_device*,void* d,uint32_t){
    lock_guard<mutex> lk(g_depth_mtx);
    Mat dm(480,640,CV_16UC1,(uint16_t*)d);          // cada pixel es un entero de 16 bits = distancia en mm aproximada
    Mat d8; dm.convertTo(d8,CV_8UC1,255.0/2048.0);  // reescala el rango 0-2048mm a 0-255 para poder verlo como imagen normal
    Mat fl; flip(d8,fl,1);
    resize(fl,g_depth,Size(160,120));
    // NOTA: g_depth se captura pero NO se usa todavia en la logica de
    // ejercicios — es una posible mejora futura (ej. distinguir a la
    // persona del fondo usando distancia, no solo color).
}
// Hilo dedicado a mantener viva la conexion con el Kinect: mientras el
// programa este corriendo, procesa los eventos/callbacks del dispositivo.
// freenect_process_events() es BLOQUEANTE y dispara video_cb/depth_cb
// internamente cada vez que hay datos nuevos del sensor.
static void kinect_loop(){while(g_running&&freenect_process_events(g_ctx)>=0){}}

// Inicializa el Kinect: abre el contexto, abre el dispositivo 0, configura
// los modos de video y profundidad, y arranca ambos streams.
// Devuelve false si no se encontro ningun Kinect conectado.
bool kinect_init(){
    if(freenect_init(&g_ctx,NULL)<0)return false;                 // crea el contexto de libfreenect; falla si no hay driver/permisos
    freenect_set_log_level(g_ctx,FREENECT_LOG_WARNING);           // silencia logs informativos, solo muestra warnings/errores
    if(freenect_open_device(g_ctx,&g_dev,0)<0){freenect_shutdown(g_ctx);return false;} // abre el Kinect #0 (el primero conectado)
    freenect_set_video_mode(g_dev,freenect_find_video_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_VIDEO_RGB));
    freenect_set_video_callback(g_dev,video_cb);   // registra que funcion llamar cuando llegue un frame de video
    freenect_start_video(g_dev);                   // empieza a transmitir video
    freenect_set_depth_mode(g_dev,freenect_find_depth_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_DEPTH_11BIT));
    freenect_set_depth_callback(g_dev,depth_cb);   // registra el callback de profundidad
    freenect_start_depth(g_dev);                   // empieza a transmitir profundidad
    return true;
}
// Devuelven una copia segura (protegida con mutex) del ultimo frame
// capturado por el Kinect, para que el hilo principal lo pueda usar
// sin pelearse con el hilo de captura. clone() hace una copia real de
// los datos (no solo un puntero), asi nadie mas la puede modificar.
Mat kinect_get_rgb()  {lock_guard<mutex> lk(g_rgb_mtx);  return g_rgb.clone();}
Mat kinect_get_depth(){lock_guard<mutex> lk(g_depth_mtx);return g_depth.clone();}

static VideoCapture g_cap;       // objeto de OpenCV que representa la webcam abierta
static Mat          g_wcam_rgb;  // ultimo frame leido de la webcam
static mutex        g_wcam_mtx;

// Hilo de respaldo: si no hay Kinect, lee continuamente frames de una
// webcam normal, los refleja igual que el Kinect y los guarda reducidos.
// A diferencia del Kinect (que llama callbacks solo), aqui SI tenemos
// que pedir el frame manualmente en un bucle infinito (cap.read).
static void webcam_loop(){
    while(g_running){
        Mat frame;
        if(g_cap.read(frame)&&!frame.empty()){   // intenta leer un frame nuevo; puede fallar si la camara se desconecta
            Mat fl; flip(frame,fl,1);
            Mat small; resize(fl,small,Size(160,120));
            lock_guard<mutex> lk(g_wcam_mtx);
            g_wcam_rgb=small.clone();
        }
    }
}

// Abre la webcam por defecto (indice 0) y configura su resolucion.
// Devuelve false si no se pudo abrir ninguna camara.
bool webcam_init(){
    g_cap.open(0);                              // 0 = primera camara disponible en el sistema
    if(!g_cap.isOpened())return false;
    g_cap.set(CAP_PROP_FRAME_WIDTH,640);
    g_cap.set(CAP_PROP_FRAME_HEIGHT,480);
    cout<<"[OK] Webcam — modo fallback\n";
    return true;
}

Mat webcam_get_rgb(){lock_guard<mutex> lk(g_wcam_mtx);return g_wcam_rgb.clone();}

// Funcion "puente": devuelve el frame actual sin que el resto del
// programa tenga que preocuparse de si la fuente es Kinect o webcam.
// Es el unico lugar donde se revisa g_usar_kinect para decidir de
// donde viene la imagen — el resto del codigo solo llama a esta funcion.
Mat captura_get_rgb(){
    if(g_usar_kinect) return kinect_get_rgb();
    else              return webcam_get_rgb();
}

// --------------------------------------------------------------
//  MEDIAPIPE
// --------------------------------------------------------------
static PyObject* g_py=nullptr;   // puntero a la funcion Python "procesar", guardado para llamarla en cada frame

// Codigo Python embebido: carga MediaPipe Pose y define la funcion
// "procesar", que recibe un frame y devuelve la posicion del cursor,
// los angulos de brazos/piernas y una clasificacion de la postura
// (SALTO, LAGARTIJA_ARRIBA/ABAJO, PORTERIA, SENTADO, PARADO, etc).
// Comentado linea por linea porque es la parte mas "magica" del codigo:
// aqui se decide, con pura matematica de coordenadas, en que postura
// esta la persona.
static const char* PY_CODE=R"PYCODE(
import mediapipe as mp
import numpy as np

# Creamos el detector de pose UNA SOLA VEZ aqui afuera (no dentro de
# procesar), para no recargar el modelo de IA en cada frame — eso
# seria muchisimo mas lento.
pose_det=mp.solutions.pose.Pose(
    static_image_mode=False,        # modo "video": usa el frame anterior para rastrear mas rapido (no trata cada frame como foto suelta)
    model_complexity=0,             # 0=Lite (mas rapido y liviano), 1=Full, 2=Heavy — usamos el mas liviano por el hardware de la Pi
    min_detection_confidence=0.45,  # que tan segura debe estar la IA para decir "aqui hay una persona" (default de MediaPipe es 0.5)
    min_tracking_confidence=0.45    # que tan segura debe estar para seguir seleccionando a la MISMA persona entre frames
)

# Calcula el angulo (en grados) en el vertice 'b', formado por los
# puntos a-b-c. Ejemplo de uso: ang(hombro, codo, muneca) = angulo del codo.
def ang(a,b,c):
    ba=np.array(a)-np.array(b); bc=np.array(c)-np.array(b)            # vectores desde b hacia a, y desde b hacia c
    cos=np.dot(ba,bc)/(np.linalg.norm(ba)*np.linalg.norm(bc)+1e-6)    # coseno del angulo = producto punto / (magnitud * magnitud)
    return float(np.degrees(np.arccos(np.clip(cos,-1,1))))            # arccos -> radianes -> grados. clip evita NaN si cos sale 1.0000001 por redondeo

# Recibe un frame crudo (bytes) + su ancho/alto, y regresa una lista de
# numeros/texto que C++ va a leer despues, o None si no se detecto a nadie.
def procesar(fb,w,h):
    arr=np.frombuffer(fb,dtype=np.uint8).reshape((h,w,3))   # convierte los bytes crudos en una matriz (alto, ancho, 3 canales)
    rgb=arr[:,:,::-1].copy()                                 # invierte el orden de canales: BGR (OpenCV) -> RGB (lo que espera MediaPipe)
    rp=pose_det.process(rgb)                                 # AQUI ocurre la deteccion real de los 33 landmarks del cuerpo
    if not rp.pose_landmarks:
        return None                                          # nadie detectado en este frame especifico

    lm=rp.pose_landmarks.landmark   # lista de 33 landmarks; cada uno tiene .x .y .z .visibility, todos normalizados entre 0 y 1
    # Extraemos solo los landmarks que nos interesan para este juego
    # (indices estandar de MediaPipe Pose — ver guia de estudio):
    hi=[lm[11].x,lm[11].y]; hd=[lm[12].x,lm[12].y]    # hombro izquierdo (11) / derecho (12)
    ci=[lm[13].x,lm[13].y]; cd=[lm[14].x,lm[14].y]    # codo izquierdo (13) / derecho (14)
    mi=[lm[15].x,lm[15].y]; md=[lm[16].x,lm[16].y]    # muneca izquierda (15) / derecha (16)
    cai=[lm[23].x,lm[23].y];cad=[lm[24].x,lm[24].y]   # cadera izquierda (23) / derecha (24)

    # El "cursor" que se ve en pantalla sigue siempre la muneca derecha (landmark 16)
    cur_x=float(lm[16].x); cur_y=float(lm[16].y)

    # Angulo promedio de AMBOS codos (hombro-codo-muneca). ~180 = brazo
    # extendido, ~0-90 = brazo doblado contra el cuerpo.
    ac=(ang(hi,ci,mi)+ang(hd,cd,md))*0.5
    try:
        # Angulo promedio de AMBAS rodillas (cadera-rodilla-tobillo).
        ri=[lm[25].x,lm[25].y];rd=[lm[26].x,lm[26].y]   # rodilla izquierda / derecha
        ti=[lm[27].x,lm[27].y];td=[lm[28].x,lm[28].y]   # tobillo izquierdo / derecho
        ar=(ang(cai,ri,ti)+ang(cad,rd,td))*0.5
    except: ar=180   # si algun landmark de pierna no es visible (camara recortada, etc), asumimos pierna recta por defecto

    cy=(cai[1]+cad[1])*0.5   # altura promedio de la cadera (recuerda: en imagenes, Y crece hacia ABAJO)
    hy=(hi[1]+hd[1])*0.5     # altura promedio de los hombros

    # --- Banderas booleanas que se combinan para clasificar la postura ---
    ba=mi[1]<hi[1] and md[1]<hd[1]   # ambas munecas estan MAS ARRIBA (Y menor) que su propio hombro -> brazos levantados
    bl=abs(mi[0]-md[0])>0.4          # las munecas estan separadas mas del 40% del ancho de imagen -> brazos extendidos a los lados
    ch=abs(hy-cy)<0.12               # hombros y cadera casi a la misma altura -> torso horizontal (acostado/doblado)
    cb=cy>0.72                       # cadera en el 72% inferior de la imagen -> agachado o sentado
    rd2=ar<120                       # pierna con menos de 120 grados -> rodilla flexionada

    # --- Arbol de decision: se evalua de arriba hacia abajo, gana la primera que aplique ---
    if ba and not cb:     pos="SALTO"             # brazos arriba Y no esta agachado -> esta saltando
    elif ch and ac<100:   pos="LAGARTIJA_ABAJO"   # cuerpo horizontal + brazo muy doblado -> lagartija en la posicion baja
    elif ch and ac>150:   pos="LAGARTIJA_ARRIBA"  # cuerpo horizontal + brazo casi extendido -> lagartija en la posicion alta
    elif bl and not rd2:  pos="PORTERIA"          # brazos extendidos a los lados + piernas no muy dobladas -> postura de portero
    elif cb and rd2:      pos="SENTADO"           # agachado + rodillas dobladas -> sentado/en cuclillas
    elif ar>160:          pos="PARADO"            # piernas casi rectas y ninguna de las anteriores -> de pie normal
    else:                 pos="DETECTANDO"        # transicion entre posturas, todavia no calza en ningun caso claro

    # Empaquetamos los 8 puntos (x,y) que C++ va a usar para dibujar el esqueleto
    pts=[hi[0],hi[1],hd[0],hd[1],ci[0],ci[1],cd[0],cd[1],
         mi[0],mi[1],md[0],md[1],cai[0],cai[1],cad[0],cad[1]]

    # Python regresa UNA lista plana de numeros (y el texto de postura en
    # medio). El orden importa: debe coincidir EXACTO con como C++ la lee
    # despues en mediapipe_proc() usando PyList_GetItem(ret, indice).
    return [cur_x,cur_y,ac,ar,cy,pos]+pts
)PYCODE";

// Arranca el interprete embebido de Python, ejecuta PY_CODE (que define
// MediaPipe Pose y la funcion "procesar") y guarda un puntero a esa
// funcion para poder llamarla despues desde C++ en cada frame.
bool mediapipe_init(){
    Py_Initialize();                                  // arranca el interprete de Python DENTRO de este mismo proceso C++
    PyRun_SimpleString(PY_CODE);                       // ejecuta todo el bloque de Python de una vez (imports, definiciones)
    PyObject* m=PyImport_AddModule("__main__");        // obtiene el "modulo principal" donde quedo definida la funcion procesar
    g_py=PyObject_GetAttrString(m,"procesar");         // guarda un puntero/referencia a esa funcion para usarla despues
    if(!g_py||!PyCallable_Check(g_py)){cerr<<"[ERROR] MediaPipe\n";return false;}
    cout<<"[OK] MediaPipe Pose — cursor muneca derecha\n";
    return true;
}

// Estructura con todo lo que necesitamos de la deteccion de pose en
// un frame: si se detecto persona, posicion del cursor, puntos del
// esqueleto, angulos suavizados y la postura clasificada.
struct DatosPose{
    bool   det=false;            // true si en este frame SI se detecto a una persona
    float  cur_x=0.5f,cur_y=0.5f;// posicion (normalizada 0-1) del cursor de mano
    float  pt[8][2]={};          // los 8 puntos del esqueleto (hombros, codos, munecas, caderas), x e y
    float  ac=180,ar=180,cy=0.5f;// angulo de brazo, angulo de pierna, altura de cadera (ya suavizados)
    string pos="Sin persona";    // texto de la postura clasificada por Python
};

// Historiales (colas) usados para suavizar (promedio movil) la posicion
// del cursor y los angulos, evitando que tiemblen frame a frame.
// El tamano de cada deque es cuantos frames se promedian: mas grande =
// mas suave pero con mas retraso (lag); mas chico = mas rapido pero
// con mas temblor.
static deque<float> h_cy(5,0.5f),h_ac(5,180.f);   // suavizado de cadera y angulo de brazo: ventana de 5 frames
static deque<float> h_cx(4,0.5f),h_cy2(4,0.5f);   // suavizado del cursor: ventana de 4 frames (un poco mas reactivo)

// Llama a la funcion Python "procesar" pasandole el frame actual, y
// convierte el resultado (lista de Python) a la estructura DatosPose,
// aplicando el suavizado con los historiales declarados arriba.
// Este es el "puente" entre C++ y Python: aqui se empaquetan los datos
// para mandarlos, se llama a Python, y se desempaquetan los datos de vuelta.
DatosPose mediapipe_proc(const Mat& frame){
    DatosPose r;
    if(!g_py||frame.empty())return r;     // si Python no esta listo o no hay imagen, regresa "sin deteccion" sin tronar

    int h=frame.rows,w=frame.cols;
    // Empaquetamos el frame de OpenCV (bytes crudos BGR) como un objeto de Python (PyBytes)
    PyObject* pb=PyBytes_FromStringAndSize((const char*)frame.data,h*w*3);
    PyObject* pw=PyLong_FromLong(w);
    PyObject* ph=PyLong_FromLong(h);
    // Llamamos directamente a procesar(fb, w, h) desde C++, como si fuera una funcion normal
    PyObject* ret=PyObject_CallFunctionObjArgs(g_py,pb,pw,ph,nullptr);
    Py_DECREF(pb);Py_DECREF(pw);Py_DECREF(ph);   // liberamos los objetos temporales (Python cuenta referencias manualmente desde C)
    if(!ret||ret==Py_None){Py_XDECREF(ret);return r;}   // None = Python no detecto a nadie en este frame

    r.det=true;
    // --- Posicion del cursor (muneca derecha), suavizada con ventana de 4 frames ---
    float cx=(float)PyFloat_AsDouble(PyList_GetItem(ret,0));
    float cy2=(float)PyFloat_AsDouble(PyList_GetItem(ret,1));
    h_cx.push_back(cx);  h_cx.pop_front();    // entra el valor nuevo por un lado, sale el mas viejo por el otro (ventana deslizante)
    h_cy2.push_back(cy2);h_cy2.pop_front();
    float scx=0,scy=0;
    for(float v:h_cx)scx+=v;  r.cur_x=scx/h_cx.size();   // promedio simple de los ultimos 4 valores
    for(float v:h_cy2)scy+=v; r.cur_y=scy/h_cy2.size();

    // --- Angulo de brazo y altura de cadera, suavizados con ventana de 5 frames ---
    float ac=(float)PyFloat_AsDouble(PyList_GetItem(ret,2));
    float cy=(float)PyFloat_AsDouble(PyList_GetItem(ret,4));
    h_ac.push_back(ac);h_ac.pop_front();
    h_cy.push_back(cy);h_cy.pop_front();
    float sa=0,sy=0;
    for(float v:h_ac)sa+=v; r.ac=sa/h_ac.size();
    for(float v:h_cy)sy+=v; r.cy=sy/h_cy.size();

    r.ar=(float)PyFloat_AsDouble(PyList_GetItem(ret,3));    // angulo de pierna, SIN suavizar (se usa tal cual viene de Python)
    r.pos=PyUnicode_AsUTF8(PyList_GetItem(ret,5));           // texto de la postura clasificada ("SALTO", "PARADO", etc)
    // Los siguientes 8 puntos (16 numeros: x,y x,y...) son las coordenadas del esqueleto para dibujar
    for(int i=0;i<8;i++){
        r.pt[i][0]=(float)PyFloat_AsDouble(PyList_GetItem(ret,6+i*2));
        r.pt[i][1]=(float)PyFloat_AsDouble(PyList_GetItem(ret,6+i*2+1));
    }
    Py_DECREF(ret);   // liberamos la lista completa que regreso Python
    return r;
}

// Dibuja sobre la imagen de la camara las lineas y circulos que
// representan el esqueleto detectado (hombros, codos, manos, caderas).
// Solo es retroalimentacion visual para el usuario (ventana "Vision v17");
// no afecta la logica del juego.
void dibujar_esqueleto(Mat& img,const DatosPose& d){
    if(!d.det)return;   // si no hay persona detectada, no hay nada que dibujar
    int W=img.cols,H=img.rows;
    // Convierte un punto normalizado (0-1) a coordenadas reales de pixel en esta imagen
    auto P=[&](int i)->Point{return Point((int)(d.pt[i][0]*W),(int)(d.pt[i][1]*H));};
    // Lineas de los "huesos": hombro-codo, codo-muneca (brazo izq=rojizo, der=azulado)
    line(img,P(0),P(2),Scalar(255,100,100),3);line(img,P(2),P(4),Scalar(255,100,100),3);
    line(img,P(1),P(3),Scalar(100,100,255),3);line(img,P(3),P(5),Scalar(100,100,255),3);
    line(img,P(0),P(1),Scalar(100,255,100),3);                          // linea entre hombros
    line(img,P(0),P(6),Scalar(100,255,100),3);line(img,P(1),P(7),Scalar(100,255,100),3); // hombro-cadera de cada lado
    line(img,P(6),P(7),Scalar(100,255,100),3);                          // linea entre caderas
    Scalar cs[]={Scalar(255,150,150),Scalar(150,150,255),
                 Scalar(255,150,150),Scalar(150,150,255),
                 Scalar(255,200,100),Scalar(200,200,255),
                 Scalar(0,255,255), Scalar(0,255,255)};
    for(int i=0;i<8;i++){circle(img,P(i),8,cs[i],-1);circle(img,P(i),9,Scalar(255,255,255),1);} // un circulo de color por articulacion + borde blanco
    circle(img,P(5),14,Scalar(0,255,255),3);   // resalta la muneca derecha (P(5)) ya que es el "cursor"
}

// --------------------------------------------------------------
//  EJERCICIOS
// --------------------------------------------------------------
enum ModoEj{M_SALTO=0,M_LAG=1,M_PORT=2};
enum EstadoCR{CR_INACTIVO,CR_CONTANDO,CR_LISTO};   // estados de la cuenta regresiva/calibracion

// Estado de un "reto" en curso: contador de repeticiones, meta,
// bandera de arriba/abajo, valores base de calibracion, modo de
// ejercicio, texto a mostrar, y si ya termino / ya se imprimio ticket.
struct Ej{
    int   cnt=0,meta=10;          // repeticiones hechas / repeticiones que se necesitan para terminar
    bool  flag=false;             // bandera generica de "arriba/abajo" usada distinto en cada modo
    float cbase=-1.f;             // altura de cadera al momento de calibrar (-1 = todavia sin calibrar)
    float hombro_base=-1.f;       // altura de hombros al momento de calibrar (-1 = todavia sin calibrar)
    ModoEj modo=M_SALTO;          // que ejercicio se esta haciendo
    string txt="LISTO";           // texto de estado que se muestra en pantalla ("ARRIBA!", "SUELO", etc)
    bool fin=false;                // true cuando ya se alcanzo la meta
    bool ticket_impreso=false;     // evita imprimir el ticket mas de una vez al terminar
    EstadoCR cr=CR_INACTIVO;       // en que parte de la cuenta regresiva/calibracion estamos
    Uint32   cr_inicio=0;          // timestamp (ms) de cuando empezo la cuenta regresiva
    int      cr_num=3;             // numero que se muestra en pantalla (3,2,1)
};
static deque<float> hsal(8,0.5f);   // ventana de suavizado especifica para el modo SALTO (mas larga, movimiento mas brusco)

// Reinicia el contador y arranca la cuenta regresiva de 3 segundos
// antes de empezar a contar repeticiones de un nuevo reto.
void iniciar_cuenta(Ej& e, Uint32 now){
    e.cr=CR_CONTANDO; e.cr_inicio=now; e.cr_num=3;   // arranca el reloj de la cuenta regresiva en este instante
    e.cnt=0;
e.flag=false;
e.cbase=-1.f;
e.hombro_base=-1.f;
e.fin=false;
e.ticket_impreso=false;
e.txt="LISTO";
    hsal.assign(8,0.5f);                  // reinicia TODOS los historiales de suavizado a su valor neutral
    h_cy.assign(5,0.5f);h_ac.assign(5,180.f);
    h_cx.assign(4,0.5f);h_cy2.assign(4,0.5f);
}

// Avanza la cuenta regresiva (3,2,1). Cuando llega a 0 y hay una
// persona detectada en una posicion razonable, calibra los valores
// base (altura de hombro/cadera) y marca el reto como CR_LISTO.
bool update_cuenta(Ej& e, const DatosPose& d, Uint32 now){
    if(e.cr==CR_INACTIVO||e.cr==CR_LISTO)return e.cr==CR_LISTO;   // si no esta contando, no hay nada que avanzar
    Uint32 elapsed=now-e.cr_inicio;          // milisegundos transcurridos desde que empezo la cuenta
    e.cr_num=3-(int)(elapsed/1000);          // convierte ms a "segundos enteros restantes" (3,2,1,0,-1...)
    if(e.cr_num<=0){                         // la cuenta ya llego a "YA!"
        if(d.det&&d.cy>0.1f&&d.cy<0.9f){     // solo calibra si hay persona Y esta razonablemente encuadrada
            e.cbase=d.cy; e.hombro_base=(d.pt[0][1]+d.pt[1][1])*0.5f;   // guarda la altura de cadera y hombros como "base" de referencia
            e.cr=CR_LISTO; e.txt="SUELO"; return true;   // calibracion exitosa, ya se puede empezar a contar
        }
    }
    return false;   // todavia contando, o no se pudo calibrar este frame (se reintenta en el siguiente)
}

// Logica central de conteo de repeticiones, distinta para cada modo:
//  - SALTO: cuenta cuando los hombros suben por encima de un umbral
//    relativo a la base calibrada, y vuelven a bajar.
//  - LAGARTIJA: cuenta cuando el angulo del brazo baja de 90 (abajo)
//    y luego sube arriba de 155 (arriba completada).
//  - PORTERO: cuenta cada vez que la postura detectada es "PORTERIA"
//    (brazos extendidos hacia los lados).
// Marca e.fin=true si se alcanza la meta de repeticiones.
bool act_ej(Ej& e, const DatosPose& d){
    if(!d.det||e.cr!=CR_LISTO)return false;   // no cuenta nada si no hay persona o todavia no se calibro
    bool nuevo=false;   // se pone true SOLO en el frame exacto donde se suma una repeticion (para futuros efectos de sonido, etc)
    if(e.modo==M_SALTO){
        hsal.push_back(d.cy);hsal.pop_front();          // suaviza la altura de cadera especificamente para saltos
        float cy=0;for(float v:hsal)cy+=v;cy/=hsal.size();   // (este promedio 'cy' local no se usa mas abajo, es un remanente)
        if(e.hombro_base>0){
            float hy_actual=(d.pt[0][1]+d.pt[1][1])*0.5f;    // altura ACTUAL de hombros (promedio de ambos)
            float umbral=e.hombro_base*0.90f;                // 90% de la altura base = "lo suficientemente arriba" para contar
            if(!e.flag&&hy_actual<umbral){                   // todavia no estaba "arriba" Y ahora si subio lo suficiente
                e.flag=true;e.cnt++;e.txt="ARRIBA! "+to_string(e.cnt);nuevo=true;   // CUENTA la repeticion aqui
            } else if(e.flag&&hy_actual>=umbral){             // estaba "arriba" y ya volvio a bajar
                e.flag=false;e.txt="SUELO";                   // resetea la bandera, listo para el siguiente salto
            }
        }
    }
    else if(e.modo==M_LAG){
        if(!e.flag&&d.ac<90.f){e.flag=true;e.txt="ABAJO";}                     // brazo se dobla lo suficiente -> marca "abajo"
        else if(e.flag&&d.ac>155.f){e.flag=false;e.cnt++;e.txt="ARRIBA";nuevo=true;}  // de "abajo" pasa a brazo extendido -> CUENTA aqui
        else if(!e.flag)e.txt="ARRIBA";   // si no esta en "abajo" y no cumple el umbral de subida, solo muestra el texto por defecto
    }
    else{ // M_PORT
        bool ok=(d.pos=="PORTERIA");           // usa directamente la clasificacion de postura que ya calculo Python
        if(ok&&!e.flag){e.flag=true;e.cnt++;e.txt="BLOQUEADO";nuevo=true;}   // entra a postura PORTERIA -> CUENTA aqui
        else if(!ok){e.flag=false;e.txt="Extiende brazos";}                   // sale de la postura -> resetea para la siguiente
    }
    if(e.cnt>=e.meta)e.fin=true;   // si ya se llego a la meta, marca el reto como terminado
    return nuevo;
}

// ══════════════════════════════════════════════════════════════
//  IMPRESORA TERMICA / TICKET
// ══════════════════════════════════════════════════════════════

// Busca en /dev el primer dispositivo serial USB (ttyUSB*). Asumimos
// que ahi esta conectada la impresora termica. Devuelve 0 si no
// encuentra ninguno.
int prn_encontrar_puerto(char *puerto) {
    DIR *d = opendir("/dev");          // abre el directorio /dev para listar sus archivos
    if (!d) return 0;

    struct dirent *dir;
    while ((dir = readdir(d)) != NULL) {                       // recorre cada entrada (archivo) dentro de /dev
        if (strncmp(dir->d_name, "ttyUSB", 6) == 0) {          // compara solo los primeros 6 caracteres del nombre
            sprintf(puerto, "/dev/%s", dir->d_name);           // construye la ruta completa, ej. "/dev/ttyUSB0"
            closedir(d);
            return 1;   // encontrado, deja de buscar en cuanto aparece el primero
        }
    }

    closedir(d);
    return 0;   // se recorrio todo /dev y no habia ningun ttyUSB*
}

// Envia un comando ESC/POS crudo (bytes) a la impresora, con una
// pequena pausa despues para no saturar su buffer interno.
void prn_cmd(int fd, const char *b, int len) {
    write(fd, b, len);     // escribe directamente los bytes al descriptor de archivo (puerto serial)
    usleep(300000);        // pausa de 300ms para darle tiempo a la impresora de procesar el comando
}

// Envia texto normal (no es comando, es lo que se va a imprimir).
void prn_txt(int fd, const char *s) {
    write(fd, s, strlen(s));
    usleep(150000);
}

// Envia un salto de linea.
void prn_nl(int fd) {
    write(fd, "\n", 1);
    usleep(100000);
}

// Imprime una linea separadora hecha de guiones.
void prn_linea_simple(int fd) {
    write(fd, "--------------------------------\n", 33);
    usleep(150000);
}

// Imprime una linea separadora hecha de signos igual (mas marcada).
void prn_linea_doble(int fd) {
    write(fd, "================================\n", 33);
    usleep(150000);
}

// Las siguientes 6 funciones mandan comandos ESC/POS (secuencias de
// bytes que esta familia de impresoras entiende como "ordenes", no
// como texto) para controlar la alineacion, negritas y tamano de fuente.
void prn_centro(int fd) {
    prn_cmd(fd, "\x1B\x61\x01", 3);    // ESC a 1  -> alineacion centrada
}

void prn_izquierda(int fd) {
    prn_cmd(fd, "\x1B\x61\x00", 3);    // ESC a 0  -> alineacion a la izquierda
}

void prn_bold_on(int fd) {
    prn_cmd(fd, "\x1B\x45\x01", 3);    // ESC E 1  -> activa negritas
}

void prn_bold_off(int fd) {
    prn_cmd(fd, "\x1B\x45\x00", 3);    // ESC E 0  -> desactiva negritas
}

void prn_grande(int fd) {
    prn_cmd(fd, "\x1D\x21\x11", 3);    // GS !  0x11 -> texto al doble de ancho y alto (0x11 = bit de ancho + bit de alto)
}

void prn_normal(int fd) {
    prn_cmd(fd, "\x1D\x21\x00", 3);    // GS !  0x00 -> tamano de texto normal
}

// Genera un folio unico con formato "SCxxxxxxxx" usando numeros
// pseudo-aleatorios. NOTA: ya no siembra rand() aqui (ese trabajo
// ahora lo hace main() una sola vez al inicio); esto evita que se
// reinicie la secuencia aleatoria cada vez que se imprime un ticket,
// lo cual tambien hace mas confiable la eleccion aleatoria de premios.
void prn_gen_folio(char *f) {
    sprintf(f, "SC%04d%04d", rand() % 9999 + 1, rand() % 9999 + 1);  // dos bloques de 4 digitos (0001-9999) pegados
}

// Formatea la fecha/hora actual como texto "dd/mm/aaaa hh:mm:ss".
void prn_get_fecha(char *b) {
    time_t t = time(NULL);                     // segundos desde 1970 (epoch)
    struct tm *tm_info = localtime(&t);        // convierte a fecha/hora local (anio, mes, dia, hora...)
    strftime(b, 32, "%d/%m/%Y %H:%M:%S", tm_info);  // formatea como texto legible
}

// Manda los comandos ESC/POS especificos del modelo de impresora para
// generar e imprimir un codigo QR con la URL de validacion del premio.
// Todos estos comandos siguen el formato "GS ( k <parametros>", que es
// la familia de comandos para codigos de barras 2D (QR) en este tipo
// de impresoras termicas.
void prn_imprimir_qr(int fd, const char *url) {
    int url_len = strlen(url);
    int total = url_len + 3;   // longitud del "payload" que se le va a mandar a la impresora (texto + 3 bytes de control fijos)
    unsigned char store[10];

    prn_centro(fd);
    usleep(300000);

    // Selecciona el modelo de simbolo QR (casi siempre se usa el modelo 2, el mas comun y compatible)
    prn_cmd(fd, "\x1D\x28\x6B\x04\x00\x31\x41\x32\x00", 9);

    // Tamano del "modulo" (cada punto individual del QR). El byte 0x06
    // = 6 puntos de impresora por modulo: mas grande = QR mas grande y
    // mas facil de escanear, pero ocupa mas papel.
    prn_cmd(fd, "\x1D\x28\x6B\x03\x00\x31\x43\x06", 8);

    // Nivel de correccion de error del QR. 0x31 = nivel "L" (el mas
    // bajo): el QR sigue siendo legible con algo de dano/manchas, pero
    // no tanto como en niveles M/Q/H (que ocupan mas espacio).
    prn_cmd(fd, "\x1D\x28\x6B\x03\x00\x31\x45\x31", 8);

    // Aqui se le manda a la impresora el contenido real que va a
    // codificar el QR (en este caso, la URL completa con el folio).
    store[0] = 0x1D;
    store[1] = 0x28;
    store[2] = 0x6B;
    store[3] = total & 0xFF;          // longitud del payload, byte bajo
    store[4] = (total >> 8) & 0xFF;   // longitud del payload, byte alto (por si la URL es larga y no cabe en un solo byte)
    store[5] = 0x31;
    store[6] = 0x50;                  // comando especifico: "almacenar datos del simbolo QR"
    store[7] = 0x30;

    write(fd, store, 8);
    write(fd, url, url_len);          // el texto real de la URL se manda aparte, justo despues del encabezado de 8 bytes
    usleep(500000);

    // Comando final: "imprime el QR que ya quedo almacenado arriba"
    prn_cmd(fd, "\x1D\x28\x6B\x03\x00\x31\x51\x30", 8);
    usleep(1000000); // 1 segundo completo: imprimir un QR tarda mas que una linea de texto normal
}

// ----------------------------------------------------------------
//  CATALOGO DE PREMIOS
// ----------------------------------------------------------------
// Misma lista de 10 premios que usa el programa standalone de
// impresion de premios, para que ambos sistemas sean consistentes.
// Cada premio tiene titulo grande, dos lineas de descripcion, dos
// lineas de condiciones, y una URL base propia para su QR de validacion.
typedef struct {
    int  id;            // numero de premio (1 al 10), tambien se imprime en el ticket
    char tag[6];         // etiqueta corta entre corchetes, ej "[H]" (no se usa en este ticket, solo es metadata del catalogo)
    char titulo[64];      // nombre grande del premio
    char linea1[64];      // primera linea de descripcion
    char linea2[64];      // segunda linea de descripcion
    char cond1[64];       // primera linea de condiciones/restricciones
    char cond2[64];       // segunda linea de condiciones/restricciones
    char base_url[80];    // dominio + ruta corta usada para construir el QR de validacion de ESTE premio
} Premio;

Premio premios[] = {
    {1,"[H]","HAMBURGUESA GRATIS",
        "Canjea 1 hamburguesa clasica","completamente GRATIS",
        "Valida hoy. 1 por persona.","No acumulable con otras promos.","cdmx.mx/p/hb"},
    {2,"[I]","HELADO GRATIS",
        "Cono de helado suave","de vainilla para ti!",
        "Valida hoy. Presenta en caja","antes de ordenar.","cdmx.mx/p/hl"},
    {3,"[P]","PAPITAS GRATIS",
        "Papas fritas medianas","100% gratis con tu compra",
        "Valida hoy. Al comprar","cualquier bebida regular.","cdmx.mx/p/pp"},
    {4,"[R]","REFRESCO GRATIS",
        "Refresco mediano gratis","al comprar cualquier combo",
        "Valida hoy. Tamano mediano.","No aplica en delivery.","cdmx.mx/p/rf"},
    {5,"[N]","6 NUGGETS GRATIS",
        "6 nuggets de pollo crujientes","completamente gratis!",
        "Valida hoy. Con salsa a elegir.","1 por persona.","cdmx.mx/p/ng"},
    {6,"[%]","50% DE DESCUENTO",
        "Mitad de precio en cualquier","producto de la carta",
        "Valida hoy. Max 1 producto.","No aplica en combos.","cdmx.mx/p/d5"},
    {7,"[2]","2x1 EN HAMBURGUESAS",
        "Lleva 2 hamburguesas","pagando solo 1!",
        "Valida hoy. Misma hamburguesa.","No acumulable.","cdmx.mx/p/2h"},
    {8,"[2]","2x1 EN HELADOS",
        "Dos helados al precio de uno!","Mismo sabor.",
        "Valida hoy. Solo tienda fisica.","1 por persona.","cdmx.mx/p/2i"},
    {9,"[%]","30% DE DESCUENTO",
        "30% de descuento en","tu proximo pedido",
        "Valida hoy. Minimo $100 MXN.","No acumulable.","cdmx.mx/p/d3"},
    {10,"[C]","COMBO A MITAD DE PRECIO",
        "Cualquier combo del menu","al 50% de descuento!",
        "Valida hoy. 1 por persona.","No aplica en desayunos.","cdmx.mx/p/cb"},
};
#define NUM_PREMIOS 10   // debe coincidir con la cantidad real de elementos en premios[] (ver guia de estudio: punto debil si se desincroniza)

// ----------------------------------------------------------------
//  SELECCION DE PREMIO ALEATORIO, SIN REPETIR EL INMEDIATO ANTERIOR
// ----------------------------------------------------------------
// Guarda el indice (0..NUM_PREMIOS-1) del ultimo premio entregado.
// Se inicializa en -1 = "todavia no se ha entregado ningun premio".
static int g_ultimo_premio = -1;

// Elige un indice de premio al azar dentro de premios[], pero nunca
// devuelve el mismo indice que la vez anterior (g_ultimo_premio).
// Esto evita que dos personas seguidas (o la misma persona dos retos
// seguidos) se lleven el mismo premio, dando la sensacion de que la
// secuencia de premios "no se repite".
// Con 10 premios, en promedio solo hace falta 1 o 2 vueltas del dado
// para encontrar un indice distinto, asi que el costo es minimo.
int elegir_premio_aleatorio() {
    if (NUM_PREMIOS <= 1) return 0;   // si solo hay 1 premio en el catalogo, no hay nada que elegir

    int idx;
    do {
        idx = rand() % NUM_PREMIOS;       // numero al azar entre 0 y NUM_PREMIOS-1
    } while (idx == g_ultimo_premio);     // si salio igual al anterior, se vuelve a tirar el dado

    g_ultimo_premio = idx;    // recuerda este premio para la siguiente llamada
    return idx;
}

// Imprime el ticket cuando se completa un reto (e.fin == true).
// 1) Busca la impresora termica por USB.
// 2) Elige un premio al azar sin repetir el anterior.
// 3) Imprime: encabezado, resultado del reto (modo + repeticiones),
//    el premio ganado (titulo + descripcion), su QR de validacion
//    propio, folio, fecha y condiciones del premio.
void imprimir_ticket_juego(const Ej& e) {
    char puerto[64];

    if (!prn_encontrar_puerto(puerto)) {
        cerr << "[TICKET] No se encontro impresora ttyUSB\n";
        return;   // sin impresora conectada, simplemente no imprime nada (no crashea el juego)
    }

    int fd = open(puerto, O_WRONLY);   // abre el puerto serial solo para ESCRITURA
    if (fd < 0) {
        perror("[TICKET] open");
        return;
    }

    // --- Elegir el premio de esta vez (nunca igual al anterior) ---
    int idx = elegir_premio_aleatorio();
    Premio* p = &premios[idx];

    char folio[32];
    char fecha[32];
    char linea[128];
    char qr_url[160];

    prn_gen_folio(folio);
    prn_get_fecha(fecha);
    // El QR de validacion usa la URL propia del premio elegido + el folio unico de esta impresion
    sprintf(qr_url, "%s/%s", p->base_url, folio);

    const char* modo_txt = "EJERCICIO";
    if (e.modo == M_SALTO)      modo_txt = "SALTOS";
    else if (e.modo == M_LAG)   modo_txt = "LAGARTIJAS";
    else if (e.modo == M_PORT)  modo_txt = "PORTERO";

    // Reset impresora: limpia cualquier configuracion residual de un ticket anterior
    prn_cmd(fd, "\x1B\x40", 2);    // ESC @ -> "Initialize printer"
    usleep(600000);

    // --- Encabezado ---
    prn_centro(fd);
    prn_bold_on(fd);
    prn_grande(fd);
    prn_txt(fd, "CDMX SMART CITY\n");
    usleep(400000);

    prn_normal(fd);
    prn_bold_off(fd);
    prn_txt(fd, "Sistema Kinect Challenge\n");
    prn_txt(fd, "Raspberry Pi + MediaPipe\n");
    prn_linea_doble(fd);

    // --- Resultado del reto (cuantas repeticiones hizo, en que modo) ---
    prn_nl(fd);
    prn_centro(fd);
    prn_bold_on(fd);
    prn_grande(fd);
    prn_txt(fd, "COMPLETADO!\n");
    usleep(400000);

    prn_normal(fd);
    prn_bold_off(fd);
    prn_nl(fd);

    sprintf(linea, "Modo: %s\n", modo_txt);
    prn_txt(fd, linea);
    sprintf(linea, "Reps: %d / %d\n", e.cnt, e.meta);
    prn_txt(fd, linea);
    prn_linea_doble(fd);

    // --- Premio ganado: titulo grande + descripcion del catalogo ---
    prn_nl(fd);
    prn_centro(fd);
    prn_bold_on(fd);
    prn_grande(fd);
    prn_txt(fd, p->titulo);
    prn_txt(fd, "\n");
    usleep(400000);

    prn_normal(fd);
    prn_bold_off(fd);
    prn_nl(fd);

    prn_linea_simple(fd);
    prn_centro(fd);
    prn_txt(fd, p->linea1); prn_nl(fd);
    prn_txt(fd, p->linea2); prn_nl(fd);
    prn_linea_simple(fd);

    // --- QR de validacion propio de este premio ---
    prn_nl(fd);
    prn_imprimir_qr(fd, qr_url);
    prn_nl(fd);

    prn_centro(fd);
    prn_bold_on(fd);
    prn_txt(fd, "Escanea para validar\n");
    prn_bold_off(fd);
    prn_txt(fd, qr_url);
    prn_nl(fd);
    prn_linea_simple(fd);

    // --- Folio, fecha y numero de premio ---
    prn_izquierda(fd);
    sprintf(linea, "Folio : %s\n", folio);
    prn_txt(fd, linea);
    sprintf(linea, "Fecha : %s\n", fecha);
    prn_txt(fd, linea);
    sprintf(linea, "Premio: #%02d\n", p->id);
    prn_txt(fd, linea);
    prn_linea_simple(fd);

    // --- Condiciones propias del premio elegido ---
    prn_centro(fd);
    prn_txt(fd, p->cond1); prn_nl(fd);
    prn_txt(fd, p->cond2); prn_nl(fd);
    prn_linea_doble(fd);

    // --- Pie ---
    prn_centro(fd);
    prn_txt(fd, "Powered by Raspberry Pi\n");
    prn_txt(fd, "CDMX Smart City 2026\n");
    prn_bold_on(fd);
    prn_txt(fd, "Gracias por participar!\n");
    prn_bold_off(fd);

    // Alimentar papel para poder cortar el ticket comodamente
    prn_txt(fd, "\n\n\n\n\n\n\n\n");
    usleep(800000);

    close(fd);   // cierra el puerto serial; importante para que el siguiente ticket pueda volver a abrirlo limpio

    cout << "[TICKET] Impreso en " << puerto << " -> " << modo_txt
         << " | Premio #" << p->id << " " << p->titulo << endl;
}



// --------------------------------------------------------------
//  SDL2 — helpers
// --------------------------------------------------------------
struct Col{Uint8 r,g,b,a;};   // un color RGBA simple (cada canal 0-255)
static const Col BT={6,6,6,255},BB={10,22,10,255};               // colores del degradado de fondo (arriba/abajo)
static const Col GR={16,124,16,255},GR2={90,200,90,255};         // verdes usados en barras de progreso/bordes animados
static const Col TJ={18,18,18,230},TJH={12,40,12,240};           // fondo de botones (normal / con hover)
static const Col BI={55,55,55,255},BH={16,124,16,255},BF={160,255,160,255};  // bordes de boton (inactivo / hover / flash)
static const Col TX={240,240,240,255},ST={130,130,130,255};      // texto principal / texto secundario (gris tenue)
static const Col HB={8,14,8,245},HT={180,220,180,255};           // fondo del HUD / texto del HUD
static const Col BR={35,35,35,255},BG={16,124,16,255};           // fondo de barras / relleno verde de barras
static const Col AM={220,180,0,255},CY={50,220,220,255},RJ={200,50,50,255};  // amarillo / cyan / rojo de acento
static const int SW=1280,SH=720,HUD=48,DN=1500,FM=500;    // ancho, alto, altura del HUD, tiempo de dwell (ms), tiempo de flash (ms)

// Interpola linealmente entre dos colores (t entre 0 y 1). Se usa para
// degradados de fondo y animaciones de color en botones/barras.
Col lc(Col a,Col b,float t){
    if(t<0)t=0;if(t>1)t=1;     // asegura que t quede dentro del rango valido aunque el llamador se pase
    return{(Uint8)(a.r+(b.r-a.r)*t),(Uint8)(a.g+(b.g-a.g)*t),
           (Uint8)(a.b+(b.b-a.b)*t),(Uint8)(a.a+(b.a-a.a)*t)};}

// "fill box": rellena un rectangulo con un color (con transparencia).
void fb(SDL_Renderer* r,SDL_Rect rc,Col c){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);   // activa mezcla alfa (para que la transparencia funcione)
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);SDL_RenderFillRect(r,&rc);
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// "outline box": dibuja el borde de un rectangulo, opcionalmente con
// varias capas (g) para dar efecto de grosor.
void ob(SDL_Renderer* r,SDL_Rect rc,Col c,int g=1){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
    for(int i=0;i<g;i++){SDL_Rect b={rc.x-i,rc.y-i,rc.w+2*i,rc.h+2*i};SDL_RenderDrawRect(r,&b);}   // cada capa un poco mas grande/afuera
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// Dibuja una linea recta entre dos puntos.
void lb(SDL_Renderer* r,int x1,int y1,int x2,int y2,Col c){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);SDL_RenderDrawLine(r,x1,y1,x2,y2);
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// Dibuja un circulo relleno (se usa para cursor, iconos, etc). SDL2 no
// tiene una funcion nativa de circulo, asi que se dibuja linea por linea
// horizontal usando la ecuacion del circulo (x^2+y^2=r^2) para calcular
// cuanto se extiende cada linea segun su altura dy.
void cc(SDL_Renderer* r,int cx,int cy,int rd,Col c){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
    for(int dy=-rd;dy<=rd;dy++){
        int dx=(int)sqrt((double)(rd*rd-dy*dy));   // ancho horizontal del circulo a esta altura especifica
        SDL_RenderDrawLine(r,cx-dx,cy+dy,cx+dx,cy+dy);}
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// "draw text": renderiza un texto con una fuente TTF y lo dibuja
// centrado (cen=true) o alineado a la izquierda en (cx,cy).
void dt(SDL_Renderer* r,TTF_Font* f,const string& s,int cx,int cy,Col c,bool cen=true){
    SDL_Color sc={c.r,c.g,c.b,c.a};
    SDL_Surface* su=TTF_RenderUTF8_Blended(f,s.c_str(),sc);if(!su)return;   // renderiza el texto a una superficie en memoria
    SDL_Texture* t=SDL_CreateTextureFromSurface(r,su);                      // la convierte a textura para poder dibujarla rapido
    SDL_Rect d=cen?SDL_Rect{cx-su->w/2,cy-su->h/2,su->w,su->h}               // centrado: resta la mitad del ancho/alto
                  :SDL_Rect{cx,cy-su->h/2,su->w,su->h};                      // izquierda: x se queda fijo, solo se centra verticalmente
    SDL_SetTextureBlendMode(t,SDL_BLENDMODE_BLEND);
    SDL_RenderCopy(r,t,nullptr,&d);SDL_FreeSurface(su);SDL_DestroyTexture(t);}   // dibuja y libera memoria temporal de inmediato

// Dibuja el fondo: un degradado vertical mas una cuadricula sutil,
// simulando una pantalla de "centro de control".
void fondo(SDL_Renderer* r){
    int z=SH-HUD;   // el degradado solo cubre hasta donde empieza el HUD, no toda la pantalla
    for(int y=0;y<z;y++){
        Col c=lc(BT,BB,(float)y/z);                 // interpola color segun que tan abajo esta esta linea (0 arriba, 1 abajo)
        SDL_SetRenderDrawColor(r,c.r,c.g,c.b,255);
        SDL_RenderDrawLine(r,0,y,SW,y);}
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,16,50,16,18);           // verde casi invisible (alpha=18) para la cuadricula sutil
    for(int x=0;x<SW;x+=60)SDL_RenderDrawLine(r,x,0,x,z);   // lineas verticales cada 60px
    for(int y=0;y<z;y+=60)SDL_RenderDrawLine(r,0,y,SW,y);   // lineas horizontales cada 60px
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// -- CPU / RAM -------------------------------------------------
struct EstadoCPU{long long idle,total;};
// Lee /proc/stat y devuelve los contadores de tiempo idle/total de CPU.
// La primera linea de /proc/stat tiene el formato:
// "cpu  user nice system idle iowait irq softirq" (acumulado desde el boot)
EstadoCPU leer_cpu2(){
    ifstream f("/proc/stat");string l;getline(f,l);   // lee solo la primera linea (totales agregados de todos los nucleos)
    istringstream ss(l);string t;ss>>t;                // descarta la palabra "cpu" al inicio
    long long u,n,s,i,w,x,y,z;ss>>u>>n>>s>>i>>w>>x>>y>>z;  // lee los 8 contadores en orden
    return{i,u+n+s+i+w+x+y+z};}                         // regresa {idle, total} (la suma de todos los estados)
// Calcula el % de uso de CPU comparando dos lecturas de leer_cpu2().
float cpct(const EstadoCPU& p,const EstadoCPU& c){
    long long dt=c.total-p.total,di=c.idle-p.idle;    // cuanto tiempo paso en total, y cuanto de eso fue idle
    if(!dt)return 0;return(1-(float)di/dt)*100;}       // % usado = 100% - % idle
// Lee /proc/meminfo y devuelve el % de RAM usada actualmente.
float lram(){
    ifstream f("/proc/meminfo");string k;long long v,tot=0,av=0;
    for(int i=0;i<30&&f;i++){f>>k>>v;f.ignore(256,'\n');        // lee "Clave: valor" linea por linea, ignorando el resto (unidades, etc)
    if(k=="MemTotal:")tot=v;if(k=="MemAvailable:")av=v;if(tot&&av)break;}  // se detiene en cuanto ya tiene los 2 datos que necesita
    return tot?((float)(tot-av)/tot*100):0;}

// -- HUD ------------------------------------------------------
// Dibuja la barra inferior (HUD) con: uso de CPU, uso de RAM, si se
// detecta a una persona, que camara se esta usando (Kinect/Webcam),
// el modo de ejercicio actual y el tiempo transcurrido.
void hud(SDL_Renderer* r,TTF_Font* f,float cpu,float ram,
         bool det,Uint32 now,const string& modo,bool kinect){
    int hy=SH-HUD;fb(r,{0,hy,SW,HUD},HB);lb(r,0,hy,SW,hy,{16,124,16,80});   // fondo del HUD + linea superior decorativa
    int cy2=hy+HUD/2;   // centro vertical del HUD, para alinear todo el texto
    dt(r,f,"CPU",60,cy2,HT);fb(r,{100,cy2-7,180,14},BR);    // etiqueta + fondo gris de la barra de CPU (180px de ancho maximo)
    Col cc2=(cpu>80)?RJ:(cpu>60)?AM:BG;                     // color segun severidad: rojo >80%, amarillo >60%, verde el resto
    if((int)(180*cpu/100)>0)fb(r,{100,cy2-7,(int)(180*cpu/100),14},cc2);  // relleno proporcional al % de uso
    char buf[40];snprintf(buf,sizeof(buf),"%.0f%%",cpu);dt(r,f,buf,300,cy2,HT);
    dt(r,f,"RAM",360,cy2,HT);fb(r,{400,cy2-7,180,14},BR);
    if((int)(180*ram/100)>0)fb(r,{400,cy2-7,(int)(180*ram/100),14},BG);   // la barra de RAM siempre se ve verde (no cambia de color)
    snprintf(buf,sizeof(buf),"%.0f%%",ram);dt(r,f,buf,600,cy2,HT);
    dt(r,f,det?"Persona: OK":"Persona: --",780,cy2,det?Col{16,200,16,255}:RJ);
    dt(r,f,kinect?"CAM: KINECT":"CAM: WEBCAM",980,cy2,
       kinect?Col{50,220,220,255}:Col{220,180,0,255});
    dt(r,f,"Modo: "+modo,1160,cy2,CY);
    Uint32 s=now/1000;snprintf(buf,sizeof(buf),"%02d:%02d",s/60,s%60);   // SDL_GetTicks() desde que arranco el programa, no del reto actual
    dt(r,f,buf,SW-40,cy2,ST);}

// -- Cursor ---------------------------------------------------
// Dibuja el cursor controlado con la mano: un circulo con efecto de
// pulso (cambia de tamano/opacidad con el tiempo) mas una mira.
void cur(SDL_Renderer* r,int cx,int cy,Uint32 now){
    float p=(float)(sin(now/300.0)*0.5+0.5);     // onda seno reescalada de 0 a 1, oscila suavemente con el tiempo
    int rd=14+(int)(p*3);Uint8 al=(Uint8)(180+p*60);   // el radio y la opacidad "respiran" siguiendo esa onda
    cc(r,cx,cy,rd,{16,124,16,al});cc(r,cx,cy,rd-5,{0,0,0,200});   // anillo verde afuera, circulo negro adentro (efecto de "donut")
    cc(r,cx,cy,4,{16,124,16,255});                                  // punto central solido
    lb(r,cx-20,cy,cx-8,cy,{255,255,255,180});    // las 4 lineas de la mira (como una cruz con hueco en medio)
    lb(r,cx+8,cy,cx+20,cy,{255,255,255,180});
    lb(r,cx,cy-20,cx,cy-8,{255,255,255,180});
    lb(r,cx,cy+8,cx,cy+20,{255,255,255,180});}

// --------------------------------------------------------------
//  ICONOS MEJORADOS v2
// --------------------------------------------------------------

// Linea "gruesa" (dibuja varias lineas paralelas) para que los iconos
// se vean con trazos mas visibles que una linea de 1px.
void lkg(SDL_Renderer* r,int x1,int y1,int x2,int y2,Col c,int g=3){
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);
    for(int i=-g/2;i<=g/2;i++){              // dibuja la misma linea desplazada un poco hacia cada lado (g veces en total)
        SDL_RenderDrawLine(r,x1+i,y1,x2+i,y2);
        SDL_RenderDrawLine(r,x1,y1+i,x2,y2+i);
    }
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);
}

// Flecha apuntando hacia arriba (usada en el icono de saltos).
void flecha_arriba(SDL_Renderer* r,int cx,int cy,Col c,int tam=12){
    lkg(r,cx,cy+tam,cx,cy-tam,c,3);          // el "palo" vertical de la flecha
    lkg(r,cx,cy-tam,cx-6,cy-2,c,3);          // ala izquierda de la punta
    lkg(r,cx,cy-tam,cx+6,cy-2,c,3);          // ala derecha de la punta
}

// Icono del modo SALTOS: figura humana con brazos arriba y piernas
// abiertas, mas dos flechas a los lados indicando movimiento vertical.
// Todas las coordenadas son relativas a (cx,cy), el centro del icono.
void icono_salto(SDL_Renderer* r,int cx,int cy){
    Col c  ={240,240,240,255};
    Col ca ={90,200,90,255};

    cc(r,cx,cy-26,8,c);                       // cabeza

    lkg(r,cx,cy-16,cx,cy+10,c,3);              // torso (linea vertical)

    lkg(r,cx,cy-10,cx-22,cy-30,c,3);           // brazo izquierdo levantado
    lkg(r,cx,cy-10,cx+22,cy-30,c,3);           // brazo derecho levantado

    lkg(r,cx,cy+10,cx-18,cy+34,c,3);           // pierna izquierda abierta
    lkg(r,cx,cy+10,cx+18,cy+34,c,3);           // pierna derecha abierta

    flecha_arriba(r,cx-30,cy-26,ca,10);        // flecha decorativa a la izquierda
    flecha_arriba(r,cx+30,cy-26,ca,10);        // flecha decorativa a la derecha
}

// Icono del modo LAGARTIJA: figura humana horizontal apoyada en
// brazos y piernas, vista de lado.
void icono_lagartija(SDL_Renderer* r,int cx,int cy){
    Col c={240,240,240,255};

    cc(r,cx+34,cy-8,6,c);                      // cabeza (a la derecha, vista de perfil)

    lkg(r,cx-30,cy,cx+20,cy,c,3);               // torso horizontal

    lkg(r,cx+10,cy,cx+4,cy+18,c,3);             // brazo delantero (parte superior)
    lkg(r,cx+4,cy+18,cx+14,cy+18,c,3);          // brazo delantero (mano apoyada en el piso)

    lkg(r,cx-6,cy,cx-12,cy+18,c,3);             // brazo trasero
    lkg(r,cx-12,cy+18,cx-2,cy+18,c,3);

    lkg(r,cx-30,cy,cx-42,cy+16,c,3);            // pierna trasera
    lkg(r,cx-42,cy+16,cx-34,cy+16,c,3);

    lkg(r,cx-16,cy,cx-22,cy+18,c,3);            // pierna/punto de apoyo intermedio
    lkg(r,cx-22,cy+18,cx-14,cy+18,c,3);
}

// Icono del modo PORTERO: figura humana "volando" lateralmente con un
// brazo extendido hacia un balon, simulando una atajada.
void icono_portero(SDL_Renderer* r,int cx,int cy){
    Col c  ={240,240,240,255};
    Col cb ={50,220,220,255};

    cc(r,cx+8,cy-20,7,c);                       // cabeza

    lkg(r,cx-6,cy+6,cx+10,cy-10,c,3);            // torso en diagonal (cuerpo "volando")

    lkg(r,cx+6,cy-10,cx-18,cy,c,3);              // brazo izquierdo (de apoyo)

    lkg(r,cx+10,cy-10,cx+34,cy-24,c,3);          // brazo derecho, primer segmento hacia el balon
    lkg(r,cx+34,cy-24,cx+50,cy-36,c,3);          // brazo derecho, segundo segmento (extendido del todo)

    lkg(r,cx-6,cy+6,cx-28,cy+24,c,3);            // pierna izquierda
    lkg(r,cx-6,cy+6,cx+10,cy+28,c,3);            // pierna derecha

    cc(r,cx+58,cy-42,5,cb);                      // el balon, justo donde llega la mano extendida
}
// --------------------------------------------------------------
//  BOTONES con dwell
// --------------------------------------------------------------
// Un Btn se "activa" no con clic, sino dejando el cursor (controlado
// con la mano) encima durante DN milisegundos ("dwell" = permanencia).
struct Btn{SDL_Rect rect;string etiq,sub;bool hover,flash;Uint32 th,tf;};
// rect=area del boton | etiq/sub=textos | hover=si el cursor esta encima
// ahora | flash=si se acaba de activar (para el efecto visual) |
// th=timestamp de cuando empezo el hover | tf=timestamp de cuando empezo el flash

// "dwell border": dibuja un borde animado que se va llenando alrededor
// del boton mientras el cursor permanece encima, dando feedback visual
// de cuanto falta para que se active.
// Truco de implementacion: en vez de dibujar un rectangulo completo,
// vamos "desenrollando" el perimetro poco a poco segun el progreso t
// (de 0 a 1), como si fuera un solo trazo continuo dando la vuelta al
// boton en sentido horario (arriba -> derecha -> abajo -> izquierda).
void dwb(SDL_Renderer* r,SDL_Rect rect,float t){
    if(t<=0)return;Col col=lc(GR,GR2,t);
    float per=2.f*(rect.w+rect.h),lon=per*t;   // 'per'=perimetro total del rectangulo; 'lon'=cuanto de ese perimetro ya se dibuja
    struct Seg{int x1,y1,x2,y2;float l;};
    Seg sg[4]={   // los 4 lados del rectangulo en orden: arriba, derecha, abajo, izquierda
        {rect.x,       rect.y,       rect.x+rect.w,rect.y,       (float)rect.w},
        {rect.x+rect.w,rect.y,       rect.x+rect.w,rect.y+rect.h,(float)rect.h},
        {rect.x+rect.w,rect.y+rect.h,rect.x,       rect.y+rect.h,(float)rect.w},
        {rect.x,       rect.y+rect.h,rect.x,       rect.y,       (float)rect.h}};
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);float res=lon;   // 'res'=longitud restante por repartir entre los lados
    for(auto& s:sg){
        if(res<=0)break;                                  // ya se acabo la longitud a dibujar, no sigue con los lados restantes
        float f2=(res>=s.l)?1:res/s.l;                     // si alcanza para todo este lado dibuja completo (f2=1); si no, solo una fraccion
        int ex=(int)(s.x1+(s.x2-s.x1)*f2),ey=(int)(s.y1+(s.y2-s.y1)*f2);  // punto final de este segmento parcial (interpolacion lineal)
        for(int gi=0;gi<4;gi++){bool h2=(s.y1==s.y2);      // dibuja 4 lineas paralelas para simular un borde grueso con brillo
            SDL_SetRenderDrawColor(r,col.r,col.g,col.b,(Uint8)(200-gi*40));  // cada capa hacia afuera un poco mas transparente
            SDL_RenderDrawLine(r,s.x1+(h2?0:gi),s.y1+(h2?gi:0),
                                 ex  +(h2?0:gi),ey  +(h2?gi:0));}
        res-=s.l;}    // resta lo que ya se dibujo de este lado y sigue con el siguiente (si todavia queda longitud)
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_NONE);}

// "draw button": dibuja el boton completo (fondo, borde, animacion de
// dwell, etiqueta y subtitulo).
void drb(SDL_Renderer* r,TTF_Font* fg,TTF_Font* fc,const Btn& b,Uint32 now){
    float td=0;if(b.hover&&!b.flash)td=min(1.f,(float)(now-b.th)/DN);   // progreso del dwell (0 a 1) = cuanto tiempo lleva el hover / DN
    Col bg=b.hover?lc(TJ,TJH,td):TJ;fb(r,b.rect,bg);                    // el fondo se va aclarando segun el progreso del dwell
    Col bd=b.flash?BF:b.hover?BH:BI;ob(r,b.rect,bd,2);                  // color de borde segun el estado actual
    if(!b.flash){
        dwb(r,b.rect,td);                          // dibuja el borde animado de "llenado" mientras no se haya activado
        if(b.hover&&b.th>0){
            fb(r,{b.rect.x,b.rect.y+b.rect.h+3,b.rect.w,5},BR);          // barrita debajo del boton: fondo gris
            int bw=(int)(b.rect.w*td);
            if(bw>0)fb(r,{b.rect.x,b.rect.y+b.rect.h+3,bw,5},CY);}}      // relleno cyan proporcional al progreso (barra de carga adicional)
    int cx2=b.rect.x+b.rect.w/2,cy2=b.rect.y+b.rect.h/2;
    dt(r,fg,b.etiq,cx2,b.rect.y+b.rect.h-45,TX);
    dt(r,fc,b.sub, cx2,b.rect.y+b.rect.h-18,ST);}

// "update button": revisa si el cursor esta sobre el boton; si se
// mantiene ahi DN milisegundos, lo marca como activado (dwell-click)
// y dispara el efecto visual de "flash". Devuelve true justo cuando
// se activa (un solo frame).
bool upb(Btn& b,int cx,int cy,Uint32 now){
    bool en=(cx>=b.rect.x&&cx<=b.rect.x+b.rect.w&&
             cy>=b.rect.y&&cy<=b.rect.y+b.rect.h);     // el cursor esta dentro del rectangulo del boton?
    if(en){
        if(!b.hover){b.hover=true;b.th=now;}            // si recien entra, marca el inicio del hover (reinicia el reloj de dwell)
        if(!b.flash&&(now-b.th)>=(Uint32)DN){b.flash=true;b.tf=now;return true;}}  // ya paso suficiente tiempo -> se activa AHORA
    else b.hover=false;    // si el cursor sale del boton, se cancela el hover (hay que empezar de cero si vuelve a entrar)
    return false;}

// "en boton": revisa si una coordenada (por ejemplo, un clic de mouse)
// cae dentro del area del boton.
bool enb(const Btn& b,int px,int py){
    return px>=b.rect.x&&px<=b.rect.x+b.rect.w&&
           py>=b.rect.y&&py<=b.rect.y+b.rect.h;}

// Reinicia el estado visual (hover/flash) de un boton, normalmente al
// cambiar de pantalla para que no se quede "activado" de antes.
void reset_btn(Btn& b){b.hover=false;b.flash=false;b.th=0;b.tf=0;}

// -- Cuenta regresiva SDL --------------------------------------
// Dibuja la pantalla de cuenta regresiva (3,2,1 y luego "YA!") antes
// de empezar a contar repeticiones de un reto.
void render_cuenta_sdl(SDL_Renderer* r,TTF_Font* ft,TTF_Font* fg,
                       const Ej& e,Uint32 now){
    fb(r,{0,0,SW,SH-HUD},{0,0,0,180});    // oscurece toda la pantalla de juego (no el HUD) para resaltar el numero
    if(e.cr_num>0){
        char buf[4];snprintf(buf,sizeof(buf),"%d",e.cr_num);
        dt(r,ft,buf,SW/2,SH/2-60,{90,200,90,255});
        dt(r,fg,"Ponte en posicion de SUELO",SW/2,SH/2+60,TX);
    } else {
        dt(r,ft,"YA!",SW/2,SH/2-60,{90,200,90,255});
        dt(r,fg,"Posicion calibrada!",SW/2,SH/2+60,TX);}}

// --------------------------------------------------------------
//  ESTADOS
// --------------------------------------------------------------
enum Estado{MENU,OPCIONES,JUEGO,RESULTADO};   // las 4 "pantallas" posibles; el programa siempre esta en exactamente una

// --------------------------------------------------------------
//  MAIN
// --------------------------------------------------------------
int main(){
    // Sembramos el generador de numeros aleatorios UNA SOLA VEZ aqui,
    // al arrancar el programa. Antes se reseembraba dentro de
    // prn_gen_folio() cada vez que se imprimia un ticket, lo cual no
    // es ideal para elegir premios al azar (podia repetir secuencias
    // si se imprimian varios tickets en el mismo segundo). Con una
    // sola semilla al inicio, tanto los folios como los premios
    // aleatorios quedan bien distribuidos durante toda la ejecucion.
    srand((unsigned)time(NULL));

    // --- Paso 1: decidir la fuente de video (Kinect o webcam) ---
    thread kthr,wthr;
    if(kinect_init()){
        g_usar_kinect=true;
        kthr=thread(kinect_loop);    // lanza el hilo que mantiene viva la conexion con el Kinect
        cout<<"[OK] Kinect detectado\n";
    } else {
        g_usar_kinect=false;
        if(!webcam_init()){cerr<<"[ERROR] No hay Kinect ni Webcam\n";return -1;}   // sin ninguna camara, no hay nada que hacer
        wthr=thread(webcam_loop);    // lanza el hilo que lee la webcam en bucle
        cout<<"[OK] Usando Webcam\n";
    }

    // --- Paso 2: arrancar Python + MediaPipe ---
    if(!mediapipe_init()){
        g_running=false;                                          // avisa a los hilos de captura que deben terminar
        if(g_usar_kinect&&kthr.joinable())kthr.join();             // espera a que el hilo correspondiente termine limpio
        if(!g_usar_kinect&&wthr.joinable())wthr.join();
        return -1;
    }

    // --- Paso 3: arrancar SDL2 (ventana, render, fuentes, audio) ---
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)<0)return -1;
    if(TTF_Init()<0)return -1;
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,2048);    // 44.1kHz, formato default, estereo, buffer de 2048 muestras
    Mix_Music* mm=Mix_LoadMUS("assets/menuprincipal.wav");   // musica de fondo del menu
    Mix_Music* mj=Mix_LoadMUS("assets/jugando.wav");          // musica de fondo mientras se hace ejercicio
    if(mm)Mix_PlayMusic(mm,-1);    // -1 = repetir en bucle infinito

    const char* titulo=g_usar_kinect?"Conteo Ejercicios v17 - UAA [KINECT]"
                                     :"Conteo Ejercicios v17 - UAA [WEBCAM]";
    SDL_Window* win = SDL_CreateWindow(
    titulo,
    SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,
    SW,SH,
    SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
	);    
	SDL_Renderer* ren = SDL_CreateRenderer(win,-1,
    SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
	);

	SDL_RenderSetLogicalSize(ren, SW, SH);   // resolucion "logica" fija: SDL2 escala automaticamente a cualquier tamano real de ventana
	SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    const char* F1="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
    const char* F2="/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf";
    TTF_Font* ft=TTF_OpenFont(F1,72);   // fuente grande (numeros de contador, cuenta regresiva)
    TTF_Font* fg=TTF_OpenFont(F1,28);   // fuente mediana (titulos, etiquetas de boton)
    TTF_Font* fc=TTF_OpenFont(F2,16);   // fuente chica (HUD, subtitulos, ayuda de teclas)

    // Ventana extra de OpenCV: solo para que el usuario vea la camara
    // con el esqueleto dibujado encima (retroalimentacion/debug visual)
    const char* cv_win=g_usar_kinect?"Vision v17 - KINECT":"Vision v17 - WEBCAM";
    namedWindow(cv_win, WINDOW_NORMAL);

	resizeWindow(cv_win, 480, 270);   // preview chico para que no tape la ventana principal de SDL2
	moveWindow(cv_win, 20, 20);

    // -- Layout menu -------------------------------------------
    // 3 botones grandes centrados horizontalmente
    int aw=280,ah=220,mg=55;          // ancho/alto de cada boton, margen entre ellos
    int tw=3*aw+2*mg;                  // ancho total ocupado por los 3 botones + 2 margenes entre ellos
    int ox=(SW-tw)/2;                  // offset X para que el bloque completo quede centrado en la pantalla
    int oy=160;   // mas arriba para dejar espacio a botones inferiores

    vector<Btn> bm={
        {{ox,          oy,aw,ah},"SALTOS",   "[1]",false,false,0,0},
        {{ox+aw+mg,    oy,aw,ah},"LAGARTIJA","[2]",false,false,0,0},
        {{ox+2*(aw+mg),oy,aw,ah},"PORTERO",  "[3]",false,false,0,0},
    };

    // Botones inferiores: OPCIONES y SALIR lado a lado
    int bw2=220,bh2=65;
    int by2=oy+ah+40;
    Btn bopc={{SW/2-bw2-20,by2,bw2,bh2},"OPCIONES","[O]",false,false,0,0};
    Btn bsal={{SW/2+20,    by2,bw2,bh2},"SALIR",   "[ESC]",false,false,0,0};

    // Boton en pantalla de juego (visible en los 3 modos)
    Btn bv ={{20,10,180,50},"< VOLVER","",false,false,0,0};
    // Botones en pantalla de resultado
    Btn br ={{SW/2-170,500,300,70},"REINICIAR","",false,false,0,0};
    Btn bmr={{SW/2+150,500,200,70},"MENU","",false,false,0,0};

    // Botones en pantalla de opciones
    int meta_tmp=10;    // valor temporal de la meta mientras se esta ajustando (no se aplica hasta "GUARDAR")
    Btn bmen={{SW/2-140,300,100,70},"-","",false,false,0,0};
    Btn bmas={{SW/2+40, 300,100,70},"+","",false,false,0,0};
    Btn bguard={{SW/2-140,430,280,70},"GUARDAR","y volver",false,false,0,0};

    Ej ej;                      // estado del reto/ejercicio actual
    Estado estado=MENU;         // empieza siempre en el menu principal
    DatosPose datos;            // ultima deteccion de pose (se actualiza cada pocos frames)
    Mat fk;                     // ultimo frame de camara obtenido
    int fc2=0,cur_x=SW/2,cur_y=SH/2;   // contador de frames, posicion inicial del cursor (centro de pantalla)
    Uint32 t0=0;                // timestamp de cuando empezo el reto actual (para el cronometro)
    string NM[]={"SALTOS","LAGARTIJAS","PORTERIA"};                          // nombres legibles por modo (indexado por ModoEj)
    Col CM[]={{16,200,16,255},{50,220,220,255},{220,180,0,255}};             // color de acento por modo

    EstadoCPU cpup=leer_cpu2();
    float cpup2=0,ramp=0;Uint32 tcpu=0;   // valores actuales de % CPU / % RAM, y cuando se actualizaron por ultima vez
    bool run=true;SDL_Event ev;

    // -- Bucle principal del juego -------------------------------
    // Cada vuelta: procesa eventos (mouse/teclado), captura y procesa
    // un frame con MediaPipe, actualiza la logica de conteo segun el
    // estado actual (MENU/OPCIONES/JUEGO/RESULTADO), dibuja la ventana
    // de OpenCV con el esqueleto superpuesto, y dibuja toda la
    // interfaz SDL2 (fondo, botones, HUD, cursor).
    while(run){
        Uint32 now=SDL_GetTicks();   // milisegundos desde que arranco el programa (reloj global usado para todas las animaciones)

        // -- Eventos ------------------------------------------
        // Aunque el control principal es con la mano (dwell), tambien
        // se aceptan mouse y teclado como alternativa/respaldo.
        while(SDL_PollEvent(&ev)){
            if(ev.type==SDL_QUIT)run=false;   // se cerro la ventana con la X
            if(ev.type==SDL_MOUSEBUTTONDOWN&&ev.button.button==SDL_BUTTON_LEFT){
                int mx=ev.button.x,my=ev.button.y;
                if(estado==MENU){
                    for(int i=0;i<3;i++)if(enb(bm[i],mx,my)){       // clic en alguno de los 3 botones de ejercicio
                        ej.modo=(ModoEj)i;estado=JUEGO;t0=now;
                        iniciar_cuenta(ej,now);
                        Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(enb(bopc,mx,my)){
                        meta_tmp=ej.meta;
                        reset_btn(bmen);reset_btn(bmas);reset_btn(bguard);
                        estado=OPCIONES;}
                    if(enb(bsal,mx,my))run=false;
                }
                if(estado==JUEGO && enb(bv,mx,my)){
    		estado=MENU;
    		reset_btn(bv);
    		Mix_HaltMusic();
    		if(mm) Mix_PlayMusic(mm,-1);
		}
                if(estado==RESULTADO){
                    if(enb(br,mx,my)){estado=JUEGO;t0=now;iniciar_cuenta(ej,now);
                        Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(enb(bmr,mx,my)){estado=MENU;
                        Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);}
                }
                if(estado==OPCIONES){
                    if(enb(bmen,mx,my)) meta_tmp=max(5,meta_tmp-5);   // resta 5, nunca baja de 5
                    if(enb(bmas,mx,my)) meta_tmp=min(50,meta_tmp+5);  // suma 5, nunca pasa de 50
                    if(enb(bguard,mx,my)){ej.meta=meta_tmp;estado=MENU;}   // recien aqui se aplica el cambio de meta de verdad
                }
            }
            if(ev.type==SDL_KEYDOWN){
                auto k=ev.key.keysym.sym;
                if(k==SDLK_ESCAPE){
                    if(estado==MENU)run=false;                 // ESC en el menu = salir del programa
                    else if(estado==OPCIONES){estado=MENU;}    // ESC en opciones = cancelar sin guardar
                    else{estado=MENU;Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);}}   // ESC en juego/resultado = volver al menu
                if(estado==MENU){
                    if(k==SDLK_o){
                        meta_tmp=ej.meta;
                        reset_btn(bmen);reset_btn(bmas);reset_btn(bguard);
                        estado=OPCIONES;}
                    if(k==SDLK_1||k==SDLK_KP_1){ej.modo=M_SALTO;estado=JUEGO;t0=now;iniciar_cuenta(ej,now);Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(k==SDLK_2||k==SDLK_KP_2){ej.modo=M_LAG;  estado=JUEGO;t0=now;iniciar_cuenta(ej,now);Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                    if(k==SDLK_3||k==SDLK_KP_3){ej.modo=M_PORT; estado=JUEGO;t0=now;iniciar_cuenta(ej,now);Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
                }
                if(estado==JUEGO){
                    if(k==SDLK_r)iniciar_cuenta(ej,now);                       // R = reiniciar el reto actual desde cero
                    if(k==SDLK_PLUS ||k==SDLK_KP_PLUS) ej.meta=min(50,ej.meta+5);
                    if(k==SDLK_MINUS||k==SDLK_KP_MINUS)ej.meta=max(5, ej.meta-5);
                }
                if(estado==OPCIONES){
                    if(k==SDLK_PLUS ||k==SDLK_KP_PLUS) meta_tmp=min(50,meta_tmp+5);
                    if(k==SDLK_MINUS||k==SDLK_KP_MINUS)meta_tmp=max(5, meta_tmp-5);
                    if(k==SDLK_RETURN){ej.meta=meta_tmp;estado=MENU;}
                }
            }
        }

        // -- Captura -------------------------------------------
        fc2++;
        fk=captura_get_rgb();              // toma el frame mas reciente disponible (Kinect o webcam, sin importar cual)
        if(!fk.empty()&&fc2%3==0)          // solo procesa con MediaPipe 1 de cada 3 frames (ahorro de CPU)
            datos=mediapipe_proc(fk);

        // Mapea la posicion de la mano (0-1 normalizado, con cierto
        // margen no usable en los bordes) a coordenadas reales de pantalla
        if(datos.det){
            float nx=(datos.cur_x-0.25f)/(1.0f-2.0f*0.25f);   // recorta 25% de margen en X y reescala el resto a 0-1 completo
            float ny=(datos.cur_y-0.20f)/(1.0f-2.0f*0.20f);   // recorta 20% de margen en Y
            nx=max(0.f,min(1.f,nx));ny=max(0.f,min(1.f,ny));  // asegura que quede dentro de 0-1 aunque la mano se salga del margen
            cur_x=(int)(nx*SW);cur_y=(int)(ny*(SH-HUD));}

        if(now-tcpu>=800){                 // actualiza CPU/RAM solo cada 800ms, no en cada frame (innecesario y un poco costoso)
            EstadoCPU c=leer_cpu2();cpup2=cpct(cpup,c);
            cpup=c;ramp=lram();tcpu=now;}

        // -- Logica del reto (solo si estamos en la pantalla JUEGO) --
        if(estado==JUEGO){
    bool calibrado=update_cuenta(ej,datos,now);   // avanza la cuenta regresiva; true si ya se calibro y se puede contar
    if(calibrado&&!ej.fin){
        act_ej(ej,datos);                          // aqui se suman (o no) las repeticiones segun el modo

        if(ej.fin){                                 // se acaba de alcanzar la meta en esta misma vuelta del bucle
            if(!ej.ticket_impreso){                 // protege contra imprimir el ticket muchas veces (el bucle corre muy rapido)
                imprimir_ticket_juego(ej);
                ej.ticket_impreso = true;
            }

            Mix_HaltMusic();
            if(mm) Mix_PlayMusic(mm,-1);
            estado=RESULTADO;
        }
    }
}
        // -- Ventana OpenCV ------------------------------------
        if(!fk.empty()){
            Mat disp;resize(fk,disp,Size(SW,SH));     // agranda el frame chico (160x120) al tamano completo de la ventana de preview
            dibujar_esqueleto(disp,datos);
            if(!datos.det){
                Mat verde(SH,SW,CV_8UC3,Scalar(0,120,0));
                addWeighted(disp,0.3,verde,0.7,0,disp);          // mezcla la imagen con un tinte verde fuerte si no hay deteccion
                putText(disp,"JUGADOR NO DETECTADO",Point(SW/2-300,SH/2),
                        FONT_HERSHEY_DUPLEX,1.5,Scalar(255,255,255),3);}
            rectangle(disp,Point(0,0),Point(SW-1,SH-1),Scalar(0,255,255),8);     // marco amarillo grueso decorativo
            rectangle(disp,Point(4,4),Point(SW-5,SH-5),Scalar(0,150,150),2);     // marco interior mas delgado
            rectangle(disp,Point(0,0),Point(SW,55),Scalar(0,0,0),-1);            // franja negra superior para el texto de estado
            Scalar cp2(150,150,150);
            if(datos.pos=="SALTO")           cp2=Scalar(0,255,0);
            if(datos.pos=="LAGARTIJA_ABAJO") cp2=Scalar(255,165,0);
            if(datos.pos=="PORTERIA")        cp2=Scalar(255,255,0);
            putText(disp,datos.pos,Point(10,40),FONT_HERSHEY_DUPLEX,1.0,cp2,2);   // texto de la postura clasificada, coloreado
            char sc2[50];snprintf(sc2,sizeof(sc2),"%s %d/%d  %s",
                NM[ej.modo].c_str(),ej.cnt,ej.meta,ej.txt.c_str());
            putText(disp,sc2,Point(SW/2-300,40),FONT_HERSHEY_DUPLEX,0.85,Scalar(0,255,255),2);
            if(estado==JUEGO&&ej.cr==CR_CONTANDO){
                char cr_buf[10];snprintf(cr_buf,sizeof(cr_buf),"%d",max(0,ej.cr_num));
                putText(disp,cr_buf,Point(SW/2-40,SH/2+30),
                        FONT_HERSHEY_DUPLEX,5.0,Scalar(0,255,0),8);}
            if(ej.hombro_base>0&&estado==JUEGO){
                int ly=(int)(ej.hombro_base*0.90f*SH);                            // dibuja la linea del umbral de salto EN PIXELES reales
                line(disp,Point(0,ly),Point(SW,ly),Scalar(0,0,255),3);
                putText(disp,"umbral salto",Point(10,ly-8),
                        FONT_HERSHEY_SIMPLEX,0.6,Scalar(0,0,255),2);}
            imshow(cv_win,disp);}
        waitKey(1);   // necesario para que OpenCV procese eventos de su propia ventana (sin esto, la ventana se "congela")

        // -- SDL Render ----------------------------------------
        fondo(ren);   // siempre se dibuja el fondo primero, antes de cualquier pantalla especifica

        // ---- MENU --------------------------------------------
        if(estado==MENU){
            cc(ren,55,42,28,{16,124,16,200});
            cc(ren,55,42,22,{10,10,10,255});
            cc(ren,55,42,18,{16,124,16,180});       // 3 circulos concentricos = un pequeno "logo"
            lb(ren,0,100,SW,100,{16,124,16,150});
            dt(ren,fg,"CONTEO DE EJERCICIOS",SW/2,52,TX);

            // 3 botones de ejercicio
            for(int i=0;i<3;i++){
                if(upb(bm[i],cur_x,cur_y,now)){            // se activo este boton por dwell (mano encima suficiente tiempo)
                    ej.modo=(ModoEj)i;estado=JUEGO;t0=now;
                    iniciar_cuenta(ej,now);
                    Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);bm[i].flash=false;}
                drb(ren,fg,fc,bm[i],now);
                // Iconos centrados en la tarjeta (zona superior)
                int ico_cx=bm[i].rect.x+bm[i].rect.w/2;
                int ico_cy=bm[i].rect.y+bm[i].rect.h/2-30;
                if(i==0) icono_salto(    ren,ico_cx,ico_cy);
                if(i==1) icono_lagartija(ren,ico_cx,ico_cy);
                if(i==2) icono_portero(  ren,ico_cx,ico_cy);
                if(bm[i].flash&&(now-bm[i].tf)>=(Uint32)FM)
                    {bm[i].flash=false;bm[i].hover=false;}   // apaga el efecto de "flash" despues de FM milisegundos
            }

            // OPCIONES y SALIR
            if(upb(bopc,cur_x,cur_y,now)){
                meta_tmp=ej.meta;
                reset_btn(bmen);reset_btn(bmas);reset_btn(bguard);
                estado=OPCIONES;bopc.flash=false;}
            if(upb(bsal,cur_x,cur_y,now))run=false;
            drb(ren,fg,fc,bopc,now);
            drb(ren,fg,fc,bsal,now);
            if(bopc.flash&&(now-bopc.tf)>=(Uint32)FM){bopc.flash=false;bopc.hover=false;}
            if(bsal.flash&&(now-bsal.tf)>=(Uint32)FM){bsal.flash=false;bsal.hover=false;}

            // Info inferior
            char mb[30];snprintf(mb,sizeof(mb),"Meta actual: %d reps",ej.meta);
            dt(ren,fc,mb,SW/2,by2+bh2+25,GR2);
            dt(ren,fc,"[1]Salto  [2]Lagartija  [3]Porteria  [O]Opciones  [+/-]Meta",
               SW/2,by2+bh2+50,ST);
        }

        // ---- OPCIONES ----------------------------------------
        else if(estado==OPCIONES){
            lb(ren,0,100,SW,100,{16,124,16,150});
            dt(ren,fg,"OPCIONES",SW/2,52,TX);

            dt(ren,fg,"Meta de repeticiones",SW/2,220,TX);

            // Numero grande
            char mb[10];snprintf(mb,sizeof(mb),"%d",meta_tmp);
            dt(ren,ft,mb,SW/2,290,GR2);

            // Botones - y +
            drb(ren,ft,fc,bmen,now);
            drb(ren,ft,fc,bmas,now);

            // Barra de progreso visual de la meta (rango 5-50)
            int bx=SW/2-200,bw=400,bh2b=12,byb=370;
            fb(ren,{bx,byb,bw,bh2b},{30,30,30,200});
            float prog=(float)(meta_tmp-5)/45.f;             // normaliza meta_tmp (5-50) a un porcentaje 0-1
            if((int)(bw*prog)>0)fb(ren,{bx,byb,(int)(bw*prog),bh2b},lc(GR,GR2,prog));
            ob(ren,{bx,byb,bw,bh2b},{80,80,80,255},1);
            dt(ren,fc,"5",bx-15,byb+bh2b/2,ST);
            dt(ren,fc,"50",bx+bw+18,byb+bh2b/2,ST);

            // Boton guardar
            if(upb(bguard,cur_x,cur_y,now)){
                ej.meta=meta_tmp;estado=MENU;bguard.flash=false;}   // aqui SI se aplica meta_tmp a la meta real del juego
            drb(ren,fg,fc,bguard,now);
            if(bguard.flash&&(now-bguard.tf)>=(Uint32)FM)
                {bguard.flash=false;bguard.hover=false;}

            // Dwell en - y +
            if(upb(bmen,cur_x,cur_y,now)){
                meta_tmp=max(5,meta_tmp-5);reset_btn(bmen);}     // reset_btn aqui permite repetir el dwell varias veces seguidas (bajar de 5 en 5 repetidamente)
            if(upb(bmas,cur_x,cur_y,now)){
                meta_tmp=min(50,meta_tmp+5);reset_btn(bmas);}

            dt(ren,fc,"[+/-] ajustar   [ENTER] guardar   [ESC] cancelar",
               SW/2,530,ST);
        }

        // ---- JUEGO -------------------------------------------
        else if(estado==JUEGO){
    Col cm=CM[ej.modo];
    lb(ren,0,75,SW,75,{cm.r,cm.g,cm.b,150});
    dt(ren,fg,NM[ej.modo],SW/2,40,cm);

    if(ej.cr==CR_CONTANDO){
        render_cuenta_sdl(ren,ft,fg,ej,now);     // mientras se calibra, se muestra SOLO la cuenta regresiva (no el contador)
    } 
    else {
        // Contador grande
        char cnt[10];snprintf(cnt,sizeof(cnt),"%d",ej.cnt);
        dt(ren,ft,cnt,SW/2,220,TX);
        dt(ren,fg,"repeticiones",SW/2,310,ST);

        // Barra progreso
        float prog=min(1.f,(float)ej.cnt/ej.meta);
        int bx=SW/2-350,bw=700,bh=30,by=360;
        fb(ren,{bx,by,bw,bh},{30,30,30,200});
        if((int)(bw*prog)>0)
            fb(ren,{bx,by,(int)(bw*prog),bh},lc(GR,GR2,prog));
        ob(ren,{bx,by,bw,bh},{80,80,80,255},1);

        char pb[20];snprintf(pb,sizeof(pb),"%d / %d",ej.cnt,ej.meta);
        dt(ren,fc,pb,SW/2,by+bh/2,TX);

        dt(ren,fg,ej.txt,SW/2,430,AM);

        Uint32 s=(now-t0)/1000;    // cronometro DESDE que empezo este reto (distinto al reloj del HUD que es desde que arranco el programa)
        char tb[20];snprintf(tb,sizeof(tb),"Tiempo: %02d:%02d",s/60,s%60);
        dt(ren,fc,tb,SW/2,490,ST);

        dt(ren,fc,"[R]Reiniciar  [ESC]Menu  [+/-]Meta",
           SW/2,530,{80,80,80,255});
    }

    // Boton VOLVER visible siempre en JUEGO,
    // incluso durante la cuenta regresiva
    if(upb(bv,cur_x,cur_y,now)){
        estado=MENU;
        reset_btn(bv);
        Mix_HaltMusic();
        if(mm) Mix_PlayMusic(mm,-1);
    }

    drb(ren,fc,fc,bv,now);

    if(bv.flash&&(now-bv.tf)>=(Uint32)FM){
        bv.flash=false;
        bv.hover=false;
    }
}

        // ---- RESULTADO ---------------------------------------
        else if(estado==RESULTADO){
            float p=(float)(sin(now/600.0)*0.5+0.5);                 // onda que hace "respirar" el fondo verde de fiesta
            fb(ren,{0,0,SW,SH-HUD},{0,(Uint8)(30+p*20),0,(Uint8)(40+p*30)});
            dt(ren,ft,"COMPLETADO!",SW/2,120,GR2);
            char buf[10];snprintf(buf,sizeof(buf),"%d",ej.cnt);
            dt(ren,ft,buf,SW/2,280,TX);
            dt(ren,fg,NM[ej.modo]+" realizadas",SW/2,360,ST);
            if(upb(br, cur_x,cur_y,now)){
                estado=JUEGO;t0=now;iniciar_cuenta(ej,now);br.flash=false;
                Mix_HaltMusic();if(mj)Mix_PlayMusic(mj,-1);}
            if(upb(bmr,cur_x,cur_y,now)){
                estado=MENU;bmr.flash=false;
                Mix_HaltMusic();if(mm)Mix_PlayMusic(mm,-1);}
            drb(ren,fg,fc,br, now);
            drb(ren,fg,fc,bmr,now);
            if(br.flash &&(now-br.tf) >=(Uint32)FM){br.flash=false; br.hover=false;}
            if(bmr.flash&&(now-bmr.tf)>=(Uint32)FM){bmr.flash=false;bmr.hover=false;}
        }

        cur(ren,cur_x,cur_y,now);    // el cursor se dibuja ENCIMA de cualquier pantalla, siempre visible
        hud(ren,fc,cpup2,ramp,datos.det,now,NM[ej.modo],g_usar_kinect);   // el HUD tambien se dibuja encima de todo, al final
        SDL_RenderPresent(ren);       // muestra en pantalla todo lo dibujado en este frame de una sola vez (evita parpadeos)
    }

    // -- Limpieza ----------------------------------------------
    // Libera todos los recursos en orden inverso a como se crearon,
    // para evitar fugas de memoria o crashes al cerrar el programa.
    destroyAllWindows();
    g_running=false;       // avisa a los hilos de captura que deben terminar su bucle
    if(g_usar_kinect){
        freenect_stop_video(g_dev);freenect_stop_depth(g_dev);
        if(kthr.joinable())kthr.join();          // espera a que el hilo del Kinect termine antes de seguir
        freenect_close_device(g_dev);freenect_shutdown(g_ctx);
    } else {
        if(wthr.joinable())wthr.join();          // espera a que el hilo de la webcam termine antes de seguir
        g_cap.release();}
    Py_XDECREF(g_py);Py_Finalize();    // libera la referencia a la funcion Python y cierra el interprete embebido
    Mix_HaltMusic();
    if(mm)Mix_FreeMusic(mm);if(mj)Mix_FreeMusic(mj);
    Mix_CloseAudio();
    TTF_CloseFont(ft);TTF_CloseFont(fg);TTF_CloseFont(fc);TTF_Quit();
    SDL_DestroyRenderer(ren);SDL_DestroyWindow(win);SDL_Quit();
    return 0;
}
