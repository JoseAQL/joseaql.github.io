# Juego de ejercicios con Kinect

Juego en C++ con menú tipo Xbox que se controla con el cuerpo y las manos. Usa un Kinect (libfreenect), OpenCV, SDL2 y MediaPipe llamado desde C++ por la API de Python. Cuenta repeticiones de ejercicios y, al completar un reto, imprime un premio en una impresora térmica.

La autoría que aparece en los encabezados de algunas versiones se dejó tal cual.

## Versiones

Todas las versiones están numeradas en esta misma carpeta. La más alta es la vigente.

| Versión | Archivo | Qué tiene |
|---|---|---|
| v1 | `juego_v01.cpp` | Primer menú con el Kinect (libfreenect + OpenCV) |
| v2 | `juego_v02_puntero_color.cpp` | Menú estilo Xbox con puntero por color (pelota o plumón fluorescente) y SDL2 |
| v3 | `juego_v03_impresora_serial.cpp` | Prueba de impresión por puerto serial |
| v4 | `juego_v04_puntero_mano.cpp` | Puntero con la mano: palma abierta mueve, puño selecciona |
| v5 | `juego_v05_deteccion_mano.cpp` | Detección de mano con MediaPipe desde C++ + MobileNet SSD |
| v6 | `juego_v06_deteccion_esqueleto.cpp` | Manos y esqueleto completo (MediaPipe Pose + Hands) con vista 2 × 2 |
| v7 | `juego_v07_pasos_instalar.txt` | Pasos de instalación (OpenCV, SDL2, dependencias y compilación) |
| v8 | `juego_v08_sin_impresora.cpp` | Juego V17: pantalla de opciones, meta ajustable y botón VOLVER (sin impresora) |
| v9 | `juego_v09_con_impresora.cpp` | V17.1: catálogo de 10 premios al azar, impresos al completar un reto |
| **v10 (vigente)** | `juego_v10_todas_las_funciones.cpp` | V17.2: todas las funciones con comentarios línea por línea |

También están `juego_entrega.cpp` (la versión V17 que se entregó) y `codigo_final.txt` (otra copia de la V17 marcada como código final).

## Compilar (v8 en adelante)

```bash
g++ juego_v10_todas_las_funciones.cpp -o juego -O3 -march=armv8-a -rdynamic \
    $(pkg-config --cflags --libs opencv4 libfreenect sdl2 SDL2_ttf) \
    $(python3.11-config --includes --ldflags --embed) -lSDL2_mixer -pthread -lm
```

El encabezado de cada archivo trae su propio comando de compilación.
