/*
 * ============================================================
 *  Juego con Puntero por Mano  â€”  MenÃº estilo Xbox Dashboard
 *  Jonathan Caldera Barajas  â€”  ElectrÃ³nica en corto
 * ============================================================
 *  Compilar:
 *    g++ main.cpp detector_mano.cpp -o juego \
 *        $(pkg-config --cflags --libs opencv4 sdl2 SDL2_ttf)
 * ============================================================
 *  Control:
 *    Palma abierta  â†’ mover cursor
 *    PuÃ±o cerrado   â†’ seleccionar botÃ³n
 * ============================================================
 */

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include "detector_mano.hpp"

using namespace std;
using namespace cv;

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   CONSTANTES
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
static const int ANCHO          = 1280;
static const int ALTO           = 720;
static const int DWELL_MS       = 2000;
static const int FLASH_MS       = 500;
static const int NUM_BOTONES    = 3;
static const int ALTO_BARRA_HUD = 48;

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   COLORES
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
struct Color { Uint8 r, g, b, a; };

static const Color COL_BG_TOP       = {  6,   6,   6, 255 };
static const Color COL_BG_BOT       = { 10,  22,  10, 255 };
static const Color COL_XBOX_GREEN   = { 16, 124,  16, 255 };
static const Color COL_XBOX_GREEN2  = { 90, 200,  90, 255 };
static const Color COL_METAL_LIGHT  = { 90,  90,  90, 255 };
static const Color COL_TARJETA_BG   = { 18,  18,  18, 230 };
static const Color COL_TARJETA_HOV  = { 12,  40,  12, 240 };
static const Color COL_BORDE_IDLE   = { 55,  55,  55, 255 };
static const Color COL_BORDE_HOV    = { 16, 124,  16, 255 };
static const Color COL_BORDE_FLASH  = {160, 255, 160, 255 };
static const Color COL_TEXTO        = {240, 240, 240, 255 };
static const Color COL_SUBTEXTO     = {130, 130, 130, 255 };
static const Color COL_HUD_BG       = {  8,  14,   8, 245 };
static const Color COL_HUD_TEXT     = {180, 220, 180, 255 };
static const Color COL_HUD_BAR_BG   = { 35,  35,  35, 255 };
static const Color COL_HUD_BAR_FG   = { 16, 124,  16, 255 };
static const Color COL_HUD_BAR_WARN = {200, 140,   0, 255 };
static const Color COL_HUD_BAR_CRIT = {200,  30,  30, 255 };

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   HELPERS SDL
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
void set_color(SDL_Renderer* r, Color c)
{
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
}

Color lerp_color(Color a, Color b, float t)
{
    if (t < 0) t = 0; if (t > 1) t = 1;
    return {
        (Uint8)(a.r + (b.r - a.r) * t),
        (Uint8)(a.g + (b.g - a.g) * t),
        (Uint8)(a.b + (b.b - a.b) * t),
        (Uint8)(a.a + (b.a - a.a) * t)
    };
}

void fill_rect_blend(SDL_Renderer* r, SDL_Rect rect, Color c)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    SDL_RenderFillRect(r, &rect);
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_rect_outline(SDL_Renderer* r, SDL_Rect rect, Color c, int grosor)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    for (int i = 0; i < grosor; i++)
    {
        SDL_Rect b = { rect.x-i, rect.y-i, rect.w+2*i, rect.h+2*i };
        SDL_RenderDrawRect(r, &b);
    }
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_line_blend(SDL_Renderer* r,
                     int x1, int y1, int x2, int y2, Color c)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    SDL_RenderDrawLine(r, x1, y1, x2, y2);
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_circle_filled(SDL_Renderer* r, int cx, int cy, int radio, Color c)
{
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    set_color(r, c);
    for (int dy = -radio; dy <= radio; dy++)
    {
        int dx = (int)sqrt((double)(radio*radio - dy*dy));
        SDL_RenderDrawLine(r, cx-dx, cy+dy, cx+dx, cy+dy);
    }
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

void draw_text(SDL_Renderer* r, TTF_Font* f,
               const string& txt, int cx, int cy, Color c,
               bool centrado = true)
{
    SDL_Color sc = { c.r, c.g, c.b, c.a };
    SDL_Surface* s = TTF_RenderUTF8_Blended(f, txt.c_str(), sc);
    if (!s) return;
    SDL_Texture* t = SDL_CreateTextureFromSurface(r, s);
    SDL_Rect dst;
    if (centrado)
        dst = { cx - s->w/2, cy - s->h/2, s->w, s->h };
    else
        dst = { cx, cy - s->h/2, s->w, s->h };
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    SDL_RenderCopy(r, t, nullptr, &dst);
    SDL_FreeSurface(s);
    SDL_DestroyTexture(t);
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   FONDO: degradado + cuadrÃ­cula HUD + viÃ±eta
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
void dibujar_fondo(SDL_Renderer* r)
{
    int zona = ALTO - ALTO_BARRA_HUD;

    for (int y = 0; y < zona; y++)
    {
        float t = (float)y / zona;
        Color c = lerp_color(COL_BG_TOP, COL_BG_BOT, t);
        SDL_SetRenderDrawColor(r, c.r, c.g, c.b, 255);
        SDL_RenderDrawLine(r, 0, y, ANCHO, y);
    }

    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(r, 16, 50, 16, 18);
    for (int x = 0; x < ANCHO; x += 60)
        SDL_RenderDrawLine(r, x, 0, x, zona);
    for (int y = 0; y < zona; y += 60)
        SDL_RenderDrawLine(r, 0, y, ANCHO, y);
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);

    for (int i = 0; i < 80; i++)
    {
        Uint8 alpha = (Uint8)(40 * (1.0f - i / 80.0f));
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(r, 0, 60, 0, alpha);
        SDL_RenderDrawLine(r, i, 0, i, zona);
        SDL_RenderDrawLine(r, ANCHO-1-i, 0, ANCHO-1-i, zona);
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
    }
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   HEADER
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
void dibujar_header(SDL_Renderer* r,
                    TTF_Font* f_titulo,
                    TTF_Font* f_chica,
                    Uint32 ahora)
{
    float pulso = (float)(sin(ahora / 1200.0) * 0.5 + 0.5);
    Uint8 al    = (Uint8)(120 + pulso * 80);
    draw_line_blend(r, 0, 80, ANCHO, 80, { 16, 124, 16, al });
    draw_line_blend(r, 0, 82, ANCHO, 82, { 16, 124, 16, (Uint8)(al/3) });

    draw_circle_filled(r, 55, 40, 28, { 16, 124, 16, 200 });
    draw_circle_filled(r, 55, 40, 22, { 10,  10,  10, 255 });
    draw_circle_filled(r, 55, 40, 18, { 16, 124, 16, 180 });
    draw_line_blend(r, 45, 30, 65, 50, {240,240,240,230});
    draw_line_blend(r, 65, 30, 45, 50, {240,240,240,230});
    draw_line_blend(r, 46, 30, 66, 50, {240,240,240,230});
    draw_line_blend(r, 66, 30, 46, 50, {240,240,240,230});

    draw_text(r, f_titulo, "MENU PRINCIPAL", ANCHO/2, 42, COL_TEXTO);
    draw_text(r, f_chica, "PALMA = MOVER  |  PUNO = SELECCIONAR",
              ANCHO - 30, 42, COL_SUBTEXTO, false);
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   BORDE DWELL ANIMADO (hover visual)
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
void dibujar_dwell_borde(SDL_Renderer* r, SDL_Rect rect, float t)
{
    if (t <= 0.0f) return;

    Color col = lerp_color(COL_XBOX_GREEN, COL_XBOX_GREEN2, t);
    int g = 4;

    float perimetro = 2.0f * (rect.w + rect.h);
    float longitud  = perimetro * t;

    struct Seg { int x1,y1,x2,y2; float largo; };
    Seg segs[4] = {
        { rect.x,        rect.y,        rect.x+rect.w, rect.y,        (float)rect.w },
        { rect.x+rect.w, rect.y,        rect.x+rect.w, rect.y+rect.h, (float)rect.h },
        { rect.x+rect.w, rect.y+rect.h, rect.x,        rect.y+rect.h, (float)rect.w },
        { rect.x,        rect.y+rect.h, rect.x,        rect.y,        (float)rect.h }
    };

    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    float restante = longitud;
    for (auto& s : segs)
    {
        if (restante <= 0) break;
        float frac = (restante >= s.largo) ? 1.0f : restante / s.largo;
        int ex = (int)(s.x1 + (s.x2-s.x1)*frac);
        int ey = (int)(s.y1 + (s.y2-s.y1)*frac);
        for (int gi = 0; gi < g; gi++)
        {
            bool horiz = (s.y1 == s.y2);
            int ox = horiz ? 0 : gi;
            int oy = horiz ? gi : 0;
            SDL_SetRenderDrawColor(r, col.r, col.g, col.b,
                                   (Uint8)(col.a * (1.0f - gi * 0.2f)));
            SDL_RenderDrawLine(r, s.x1+ox, s.y1+oy, ex+ox, ey+oy);
        }
        restante -= s.largo;
    }
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_NONE);
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   ESTRUCTURA BOTÃ“N
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
struct Boton
{
    SDL_Rect  rect;
    string    etiqueta;
    string    subtexto;
    bool      en_hover;
    bool      activado;
    Uint32    t_hover;
    Uint32    t_flash;
};

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   TARJETA ESTILO XBOX
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
void dibujar_tarjeta(SDL_Renderer* r,
                     TTF_Font* f_grande,
                     TTF_Font* f_chica,
                     Boton& b,
                     Uint32 ahora)
{
    bool en_flash = b.activado && (ahora - b.t_flash < (Uint32)FLASH_MS);

    float progreso = 0.0f;
    if (b.en_hover && !b.activado)
    {
        Uint32 elapsed = ahora - b.t_hover;
        progreso = (float)elapsed / DWELL_MS;
        if (progreso > 1.0f) progreso = 1.0f;
    }

    SDL_Rect sombra = { b.rect.x+6, b.rect.y+6, b.rect.w, b.rect.h };
    fill_rect_blend(r, sombra, { 0, 0, 0, 120 });

    Color col_fondo = b.en_hover ? COL_TARJETA_HOV : COL_TARJETA_BG;
    if (en_flash) col_fondo = { 20, 80, 20, 250 };
    fill_rect_blend(r, b.rect, col_fondo);

    SDL_Rect brillo = { b.rect.x+2, b.rect.y+2, b.rect.w-4, b.rect.h/3 };
    Color col_brillo = b.en_hover ? Color{30,100,30,35} : Color{60,60,60,20};
    fill_rect_blend(r, brillo, col_brillo);

    Color col_borde = en_flash ? COL_BORDE_FLASH
                    : b.en_hover ? COL_BORDE_HOV
                    : COL_BORDE_IDLE;
    draw_rect_outline(r, b.rect, col_borde, 2);

    int sz = 14;
    Color col_esq = b.en_hover ? COL_XBOX_GREEN : COL_METAL_LIGHT;
    draw_line_blend(r, b.rect.x, b.rect.y, b.rect.x+sz, b.rect.y, col_esq);
    draw_line_blend(r, b.rect.x, b.rect.y, b.rect.x, b.rect.y+sz, col_esq);
    draw_line_blend(r, b.rect.x+b.rect.w,   b.rect.y, b.rect.x+b.rect.w-sz, b.rect.y,    col_esq);
    draw_line_blend(r, b.rect.x+b.rect.w,   b.rect.y, b.rect.x+b.rect.w,    b.rect.y+sz, col_esq);
    draw_line_blend(r, b.rect.x, b.rect.y+b.rect.h, b.rect.x+sz, b.rect.y+b.rect.h,    col_esq);
    draw_line_blend(r, b.rect.x, b.rect.y+b.rect.h, b.rect.x,    b.rect.y+b.rect.h-sz, col_esq);
    draw_line_blend(r, b.rect.x+b.rect.w, b.rect.y+b.rect.h, b.rect.x+b.rect.w-sz, b.rect.y+b.rect.h,    col_esq);
    draw_line_blend(r, b.rect.x+b.rect.w, b.rect.y+b.rect.h, b.rect.x+b.rect.w,    b.rect.y+b.rect.h-sz, col_esq);

    if (!en_flash && progreso > 0.0f)
        dibujar_dwell_borde(r, b.rect, progreso);

    if (b.en_hover && progreso > 0.0f && !en_flash)
    {
        SDL_Rect bg = { b.rect.x+8, b.rect.y+b.rect.h-14, b.rect.w-16, 7 };
        SDL_Rect fg = { bg.x, bg.y, (int)(bg.w * progreso), bg.h };
        fill_rect_blend(r, bg, { 30, 30, 30, 200 });
        Color col_bar = lerp_color(COL_XBOX_GREEN, {220,220,20,255}, progreso);
        fill_rect_blend(r, fg, col_bar);
        draw_rect_outline(r, bg, { 50, 50, 50, 150 }, 1);
    }

    int lx1 = b.rect.x + 20;
    int lx2 = b.rect.x + b.rect.w - 20;
    int ly  = b.rect.y + b.rect.h/2 + 18;
    draw_line_blend(r, lx1, ly, lx2, ly, { 60, 60, 60, 100 });

    int cx       = b.rect.x + b.rect.w / 2;
    int cy_label = b.rect.y + b.rect.h/2 - 8;
    int cy_sub   = b.rect.y + b.rect.h/2 + 35;

    Color col_label = en_flash ? Color{200,255,200,255} : COL_TEXTO;
    draw_text(r, f_grande, b.etiqueta, cx, cy_label, col_label);
    draw_text(r, f_chica,  b.subtexto, cx, cy_sub,   COL_SUBTEXTO);
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   CURSOR con halo pulsante
   Verde = palma abierta  |  Rojo = puÃ±o cerrado
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
void dibujar_cursor(SDL_Renderer* r, int x, int y, bool puno, Uint32 ahora)
{
    float pulso = (float)(sin(ahora / 180.0) * 0.5 + 0.5);
    int r_halo  = (int)(28 + pulso * 14);

    Color col_halo  = puno ? Color{200,  30, 30,  40} : Color{ 16, 124, 16, 25};
    Color col_core  = puno ? Color{255,  80, 80, 255} : Color{ 80, 255, 80,255};
    Color col_borde = puno ? Color{200,  30, 30, 200} : Color{ 16, 124, 16,200};

    draw_circle_filled(r, x, y, r_halo,   col_halo);
    draw_circle_filled(r, x, y, r_halo-8, {col_halo.r,col_halo.g,col_halo.b,60});
    draw_circle_filled(r, x, y, 13,       {  0,  0,  0, 180});
    draw_circle_filled(r, x+1, y+1, 12,   col_core);
    draw_rect_outline (r, {x-14, y-14, 28, 28}, col_borde, 1);

    SDL_SetRenderDrawColor(r, 0, 0, 0, 220);
    SDL_RenderDrawLine(r, x-6, y, x+6, y);
    SDL_RenderDrawLine(r, x, y-6, x, y+6);
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   MONITOR CPU / RAM  (/proc/)
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
struct EstadoCPU { long idle, total; };

EstadoCPU leer_cpu()
{
    ifstream f("/proc/stat");
    string linea;
    getline(f, linea);
    istringstream ss(linea);
    string lbl;
    long user, nice, system, idle, iowait, irq, softirq, steal;
    ss >> lbl >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
    return { idle + iowait,
             user + nice + system + idle + iowait + irq + softirq + steal };
}

float calcular_cpu_pct(EstadoCPU prev, EstadoCPU curr)
{
    long d_idle  = curr.idle  - prev.idle;
    long d_total = curr.total - prev.total;
    if (d_total == 0) return 0.0f;
    return 100.0f * (1.0f - (float)d_idle / d_total);
}

float leer_ram_pct()
{
    ifstream f("/proc/meminfo");
    long total = 1, disponible = 0;
    string clave, unidad;
    long valor;
    for (int i = 0; i < 10; i++)
    {
        if (!(f >> clave >> valor >> unidad)) break;
        if (clave == "MemTotal:")     total      = valor;
        if (clave == "MemAvailable:") disponible = valor;
    }
    return 100.0f * (1.0f - (float)disponible / total);
}

void dibujar_hud(SDL_Renderer* r,
                 TTF_Font* f_chica,
                 float cpu_pct,
                 float ram_pct,
                 bool puno,
                 bool mano_detectada,
                 Uint32 ahora)
{
    int y0 = ALTO - ALTO_BARRA_HUD;

    fill_rect_blend(r, { 0, y0, ANCHO, ALTO_BARRA_HUD }, COL_HUD_BG);
    draw_line_blend(r, 0, y0,   ANCHO, y0,   COL_XBOX_GREEN);
    draw_line_blend(r, 0, y0+1, ANCHO, y0+1, { 16, 124, 16, 60 });

    int cy = y0 + ALTO_BARRA_HUD / 2;

    auto dibujar_recurso = [&](const string& label, float pct, int x_base)
    {
        draw_text(r, f_chica, label, x_base, cy, COL_HUD_TEXT, false);
        SDL_Rect bg = { x_base + 55, cy - 7, 220, 14 };
        fill_rect_blend(r, bg, COL_HUD_BAR_BG);
        int fill_w = (int)(bg.w * pct / 100.0f);
        SDL_Rect fg = { bg.x, bg.y, fill_w, bg.h };
        Color col_bar = pct > 85.0f ? COL_HUD_BAR_CRIT
                      : pct > 65.0f ? COL_HUD_BAR_WARN
                      : COL_HUD_BAR_FG;
        fill_rect_blend(r, fg, col_bar);
        draw_rect_outline(r, bg, { 60, 60, 60, 180 }, 1);
        char buf[16];
        snprintf(buf, sizeof(buf), "%.1f%%", pct);
        draw_text(r, f_chica, string(buf), bg.x + bg.w + 8, cy, col_bar, false);
    };

    dibujar_recurso("CPU", cpu_pct, 40);
    dibujar_recurso("RAM", ram_pct, 400);

    draw_line_blend(r, ANCHO/2, y0+8, ANCHO/2, ALTO-8, { 40, 80, 40, 100 });

    // â”€â”€ Indicador de estado de mano â”€â”€
    string estado_txt;
    Color  estado_col;
    if (!mano_detectada)
    {
        estado_txt = "MANO: NO DETECTADA";
        estado_col = COL_SUBTEXTO;
    }
    else if (puno)
    {
        estado_txt = "PUNO  [SELECCIONAR]";
        estado_col = { 200, 80, 80, 255 };
    }
    else
    {
        estado_txt = "PALMA  [MOVER]";
        estado_col = { 80, 220, 80, 255 };
    }
    draw_text(r, f_chica, estado_txt, ANCHO*3/4, cy, estado_col);

    // Reloj de sesiÃ³n
    Uint32 seg = ahora / 1000;
    char buf[32];
    snprintf(buf, sizeof(buf), "T+  %02d:%02d", seg/60, seg%60);
    draw_text(r, f_chica, string(buf), ANCHO - 80, cy, COL_SUBTEXTO);
}

/* â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
   MAIN
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€ */
int main()
{
    /* â”€â”€ CÃ¡mara â”€â”€ */
    VideoCapture cam(0);
    if (!cam.isOpened())
    {
        cout << "No se pudo abrir la webcam" << endl;
        return -1;
    }
    cam.set(CAP_PROP_FRAME_WIDTH,  320);
    cam.set(CAP_PROP_FRAME_HEIGHT, 240);

    /* â”€â”€ SDL2 + TTF â”€â”€ */
    if (SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        cout << "Error SDL_Init: " << SDL_GetError() << endl;
        return -1;
    }
    if (TTF_Init() < 0)
    {
        cout << "Error TTF_Init: " << TTF_GetError() << endl;
        return -1;
    }

    SDL_Window* ventana = SDL_CreateWindow(
        "Juego con Puntero por Mano",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        ANCHO, ALTO,
        SDL_WINDOW_SHOWN
    );
    if (!ventana) { cout << "Error ventana: " << SDL_GetError() << endl; return -1; }

    SDL_Renderer* renderer = SDL_CreateRenderer(
        ventana, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
    );
    if (!renderer) { cout << "Error renderer: " << SDL_GetError() << endl; return -1; }

    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);

    /* â”€â”€ Fuentes â”€â”€ */
    const char* FUENTE = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
    TTF_Font* f_titulo = TTF_OpenFont(FUENTE, 34);
    TTF_Font* f_grande = TTF_OpenFont(FUENTE, 26);
    TTF_Font* f_chica  = TTF_OpenFont(FUENTE, 15);
    if (!f_titulo || !f_grande || !f_chica)
    {
        cout << "Error fuente: " << TTF_GetError() << endl;
        return -1;
    }

    /* â”€â”€ Botones â”€â”€ */
    int ancho_t = 280;
    int alto_t  = 200;
    int margen  = 60;
    int total_w = NUM_BOTONES * ancho_t + (NUM_BOTONES-1) * margen;
    int ox = (ANCHO - total_w) / 2;
    int oy = (ALTO - ALTO_BARRA_HUD - alto_t) / 2 + 30;

    vector<Boton> botones = {
        { {ox,                       oy, ancho_t, alto_t}, "JUGAR",    "Iniciar partida",    false, false, 0, 0 },
        { {ox + ancho_t + margen,    oy, ancho_t, alto_t}, "OPCIONES", "Configuracion",      false, false, 0, 0 },
        { {ox + 2*(ancho_t+margen),  oy, ancho_t, alto_t}, "SALIR",    "Cerrar aplicacion",  false, false, 0, 0 }
    };

    /* â”€â”€ Detector de mano â”€â”€ */
    DetectorMano detector(
        "/home/jcb/modelos_mano/hand_pose.caffemodel",
        "/home/jcb/modelos_mano/hand_pose.prototxt",
        ANCHO,
        ALTO - ALTO_BARRA_HUD
    );

    /* â”€â”€ Ventana de debug OpenCV â”€â”€ */
    namedWindow("Debug Mano", WINDOW_NORMAL);
    resizeWindow("Debug Mano", 400, 300);
    moveWindow("Debug Mano", ANCHO + 10, 0);   // a la derecha del menÃº

    /* â”€â”€ Estado visiÃ³n â”€â”€ */
    int  cursor_x       = ANCHO / 2;
    int  cursor_y       = ALTO  / 2;
    bool estado_puno    = false;
    bool mano_detectada = false;
    Mat  frame;
    Mat  frame_debug;

    /* â”€â”€ CPU / RAM â”€â”€ */
    EstadoCPU cpu_prev = leer_cpu();
    float     cpu_pct  = 0.0f;
    float     ram_pct  = 0.0f;
    Uint32    t_cpu    = 0;

    /* â”€â”€ Loop â”€â”€ */
    bool   ejecutando    = true;
    int    boton_activo  = -1;
    int    contador_frames = 0;
    SDL_Event evento;

    while (ejecutando)
    {
        Uint32 ahora = SDL_GetTicks();

        /* â”€â”€ Eventos SDL â”€â”€ */
        while (SDL_PollEvent(&evento))
        {
            if (evento.type == SDL_QUIT) ejecutando = false;
            if (evento.type == SDL_KEYDOWN &&
                evento.key.keysym.sym == SDLK_ESCAPE) ejecutando = false;
        }

        /* â”€â”€ Eventos OpenCV (necesario para que imshow funcione) â”€â”€ */
        if (waitKey(1) == 27) ejecutando = false;

        /* â”€â”€ CPU/RAM cada 800ms â”€â”€ */
        if (ahora - t_cpu >= 800)
        {
            EstadoCPU cpu_curr = leer_cpu();
            cpu_pct  = calcular_cpu_pct(cpu_prev, cpu_curr);
            cpu_prev = cpu_curr;
            ram_pct  = leer_ram_pct();
            t_cpu    = ahora;
        }

        /* â”€â”€ Captura y detecciÃ³n de mano â”€â”€
           Infiere 1 de cada 2 frames para aliviar CPU            */
        for (int i = 0; i < 3; i++) cam.grab();
        cam >> frame;
        if (!frame.empty())
        {
            flip(frame, frame, 1);
            contador_frames++;

            DetectorMano::ResultadoMano mano;
            if (contador_frames % 2 == 0)
            {
                mano = detector.procesar(frame);
                // Actualizar ventana de debug solo cuando hay inferencia
                frame_debug = detector.get_frame_debug(frame, mano.puno);
            }
            else
            {
                // Frame intermedio: reutilizar Ãºltimo resultado
                mano = { mano_detectada, cursor_x, cursor_y, estado_puno };
            }

            mano_detectada = mano.detectada;
            if (mano.detectada)
            {
                cursor_x    = mano.cursor_x;
                cursor_y    = mano.cursor_y;
                estado_puno = mano.puno;
            }
            else
            {
                estado_puno = false;
            }

            // Mostrar ventana de debug
            if (!frame_debug.empty())
                imshow("Debug Mano", frame_debug);
        }

        /* â”€â”€ LÃ³gica selecciÃ³n por puÃ±o â”€â”€ */
        int cx_int = cursor_x;
        int cy_int = cursor_y;
        for (int i = 0; i < NUM_BOTONES; i++)
        {
            Boton& b = botones[i];
            bool dentro = (cx_int >= b.rect.x &&
                           cx_int <= b.rect.x + b.rect.w &&
                           cy_int >= b.rect.y &&
                           cy_int <= b.rect.y + b.rect.h);
            if (dentro)
            {
                if (!b.en_hover) { b.en_hover = true; b.t_hover = ahora; }

                // PuÃ±o cerrado sobre el botÃ³n â†’ activar
                if (!b.activado && estado_puno)
                {
                    b.activado   = true;
                    b.t_flash    = ahora;
                    boton_activo = i;
                    cout << ">> Seleccionado: " << b.etiqueta << endl;
                }
            }
            else
            {
                b.en_hover = false;
            }
        }

        /* â”€â”€ Post-flash â”€â”€ */
        if (boton_activo >= 0)
        {
            Boton& b = botones[boton_activo];
            if (b.activado && (ahora - b.t_flash) >= (Uint32)FLASH_MS)
            {
                if (boton_activo == 2) ejecutando = false;   // SALIR
                b.activado   = false;
                b.en_hover   = false;
                boton_activo = -1;
            }
        }

        /* â”€â”€â”€â”€â”€â”€â”€â”€ RENDER SDL â”€â”€â”€â”€â”€â”€â”€â”€ */
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        dibujar_fondo(renderer);
        dibujar_header(renderer, f_titulo, f_chica, ahora);
        for (auto& b : botones)
            dibujar_tarjeta(renderer, f_grande, f_chica, b, ahora);
        dibujar_cursor(renderer, cx_int, cy_int, estado_puno, ahora);
        dibujar_hud(renderer, f_chica, cpu_pct, ram_pct,
                    estado_puno, mano_detectada, ahora);

        SDL_RenderPresent(renderer);
    }

    /* â”€â”€ Limpieza â”€â”€ */
    destroyAllWindows();
    cam.release();
    TTF_CloseFont(f_titulo);
    TTF_CloseFont(f_grande);
    TTF_CloseFont(f_chica);
    TTF_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(ventana);
    SDL_Quit();
    return 0;
}