// DETECCION_MANOV7.cpp
// C++ + freenect + MediaPipe via Python C API + MobileNet SSD
// MediaPipe corre dentro de C++ llamando Python directamente
//
// Compilar:
//   g++ DETECCION_MANOV7.cpp -o detmano_v7 \
//       $(pkg-config --cflags --libs opencv4 libfreenect) \
//       $(python3-config --includes --ldflags) \
//       -lpython3.9 -pthread -lm
// Correr: ./detmano_v7

#include <libfreenect.h>
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <Python.h>
#include <iostream>
#include <mutex>
#include <thread>
#include <atomic>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <ctime>

using namespace std;
using namespace cv;
using namespace cv::dnn;

// ── Globals Kinect ───────────────────────────────────────────────────────────
Mat frame_actual, depth_actual;
mutex frame_mutex, depth_mutex;
atomic<bool> nuevo_frame(false), nuevo_depth(false), ejecutando(true);
freenect_context *f_ctx;

void video_callback(freenect_device *dev, void *rgb, uint32_t timestamp) {
    lock_guard<mutex> lock(frame_mutex);
    Mat temp(480, 640, CV_8UC3, rgb);
    Mat bgr; cvtColor(temp, bgr, COLOR_RGB2BGR);
    flip(bgr, frame_actual, 1);
    nuevo_frame = true;
}

void depth_callback(freenect_device *dev, void *v_depth, uint32_t timestamp) {
    lock_guard<mutex> lock(depth_mutex);
    uint16_t *d = (uint16_t*)v_depth;
    Mat depthMat(480, 640, CV_16UC1, d);
    Mat depth8; depthMat.convertTo(depth8, CV_8UC1, 255.0/2048.0);
    flip(depth8, depth_actual, 1);
    nuevo_depth = true;
}

void freenect_loop() {
    while (ejecutando && freenect_process_events(f_ctx) >= 0) {}
}

float obtener_temp() {
    ifstream f("/sys/class/thermal/thermal_zone0/temp");
    float t=0; if(f.is_open()){f>>t;t/=1000.0;} return t;
}

// ── Captura mouse ────────────────────────────────────────────────────────────
bool captura_pendiente = false;
Mat  ultimo_combined;
void mouse_cb(int event, int x, int y, int, void*) {
    if (event == EVENT_LBUTTONDOWN) captura_pendiente = true;
}

// ════════════════════════════════════════════════════════════════════════════
//  MEDIAPIPE via Python C API
//  Estructura de landmark: 21 puntos (x,y) normalizados 0-1
// ════════════════════════════════════════════════════════════════════════════
struct Landmark { float x, y; };
struct ResultadoMP {
    bool detectada = false;
    vector<Landmark> landmarks; // 21 puntos
    string gesto;
    int    num_dedos;
    Scalar color;
};

// Modulo Python embebido — se inicializa una vez
PyObject *py_module   = nullptr;
PyObject *py_procesar = nullptr;

bool iniciar_mediapipe() {
    Py_Initialize();

    // Codigo Python embebido en C++
    const char* codigo_python = R"PYCODE(
import mediapipe as mp
import numpy as np

mp_hands = mp.solutions.hands
hands_detector = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.6,
    min_tracking_confidence=0.5
)

TIPS = [4,  8,  12, 16, 20]
PIPS = [3,  6,  10, 14, 18]

def clasificar(landmarks):
    pts = [(lm.x, lm.y) for lm in landmarks]
    dedos = []
    dedos.append(pts[4][0] < pts[3][0])
    for tip,pip in zip(TIPS[1:], PIPS[1:]):
        dedos.append(pts[tip][1] < pts[pip][1])
    p,i,m,a,me = dedos
    n = sum(dedos)
    if n==0:                           return "CERRADA", n
    if n==5:                           return "ABIERTA", n
    if i and not m and not a and not me: return "1-INDICE", n
    if i and m and not a and not me:   return "2-PAZ", n
    if i and m and a and not me:       return "3-TRES", n
    if i and m and a and me:           return "4-CUATRO", n
    if p and not i and not m and not a and not me: return "PULGAR", n
    if me and not i and not m and not a: return "MENIQUE", n
    if p and me and not i and not m and not a: return "ROCK", n
    return f"{n} dedos", n

def procesar_frame(frame_bytes, width, height):
    """
    Recibe frame BGR como bytes, retorna lista de manos detectadas.
    Cada mano: [gesto, num_dedos, lm0x, lm0y, lm1x, lm1y, ..., lm20x, lm20y]
    """
    arr = np.frombuffer(frame_bytes, dtype=np.uint8).reshape((height, width, 3))
    rgb = arr[:,:,::-1].copy()  # BGR a RGB
    resultado = hands_detector.process(rgb)
    salida = []
    if resultado.multi_hand_landmarks:
        for hand_lm in resultado.multi_hand_landmarks:
            gesto, n = clasificar(hand_lm.landmark)
            fila = [gesto, n]
            for lm in hand_lm.landmark:
                fila.append(lm.x)
                fila.append(lm.y)
            salida.append(fila)
    return salida
)PYCODE";

    // Ejecutar el codigo Python
    PyRun_SimpleString(codigo_python);

    // Obtener referencia a la funcion procesar_frame
    PyObject *main_mod = PyImport_AddModule("__main__");
    py_procesar = PyObject_GetAttrString(main_mod, "procesar_frame");

    if (!py_procesar || !PyCallable_Check(py_procesar)) {
        cerr << "[ERROR] No se pudo obtener procesar_frame de Python" << endl;
        return false;
    }
    cout << "[OK] MediaPipe inicializado via Python C API" << endl;
    return true;
}

// Llamar a MediaPipe con el frame actual
vector<ResultadoMP> llamar_mediapipe(const Mat& frame) {
    vector<ResultadoMP> resultados;
    if (!py_procesar) return resultados;

    int h = frame.rows, w = frame.cols;
    size_t nbytes = h * w * 3;

    // Convertir frame a bytes Python
    PyObject *py_bytes = PyBytes_FromStringAndSize(
        (const char*)frame.data, nbytes);
    PyObject *py_w = PyLong_FromLong(w);
    PyObject *py_h = PyLong_FromLong(h);

    // Llamar procesar_frame(bytes, width, height)
    PyObject *py_result = PyObject_CallFunctionObjArgs(
        py_procesar, py_bytes, py_w, py_h, nullptr);

    Py_DECREF(py_bytes);
    Py_DECREF(py_w);
    Py_DECREF(py_h);

    if (!py_result) { PyErr_Print(); return resultados; }

    // Parsear resultado: lista de manos
    Py_ssize_t num_manos = PyList_Size(py_result);
    for (Py_ssize_t i = 0; i < num_manos; i++) {
        PyObject *mano = PyList_GetItem(py_result, i);
        ResultadoMP r;
        r.detectada = true;

        // gesto (string)
        PyObject *py_gesto = PyList_GetItem(mano, 0);
        r.gesto = PyUnicode_AsUTF8(py_gesto);

        // num_dedos (int)
        r.num_dedos = (int)PyLong_AsLong(PyList_GetItem(mano, 1));

        // Color segun gesto
        if      (r.gesto == "ABIERTA")  r.color = Scalar(0,255,0);
        else if (r.gesto == "CERRADA")  r.color = Scalar(0,0,255);
        else if (r.gesto == "2-PAZ")    r.color = Scalar(255,200,0);
        else if (r.gesto == "PULGAR")   r.color = Scalar(255,50,200);
        else if (r.gesto == "ROCK")     r.color = Scalar(50,50,255);
        else                             r.color = Scalar(0,200,255);

        // 21 landmarks (x,y) desde indice 2
        for (int j = 0; j < 21; j++) {
            Landmark lm;
            lm.x = (float)PyFloat_AsDouble(PyList_GetItem(mano, 2 + j*2));
            lm.y = (float)PyFloat_AsDouble(PyList_GetItem(mano, 2 + j*2 + 1));
            r.landmarks.push_back(lm);
        }
        resultados.push_back(r);
    }
    Py_DECREF(py_result);
    return resultados;
}

// ── Dibujar landmarks de MediaPipe ───────────────────────────────────────────
// Conexiones de la mano segun MediaPipe
const vector<pair<int,int>> CONEXIONES = {
    {0,1},{1,2},{2,3},{3,4},       // pulgar
    {0,5},{5,6},{6,7},{7,8},       // indice
    {0,9},{9,10},{10,11},{11,12},  // medio
    {0,13},{13,14},{14,15},{15,16},// anular
    {0,17},{17,18},{18,19},{19,20},// menique
    {5,9},{9,13},{13,17}           // palma
};

const int TIPS_IDS[] = {4,8,12,16,20};
const int PIPS_IDS[] = {3,6,10,14,18};

void dibujar_mano(Mat& img, const ResultadoMP& r, int w, int h) {
    if (!r.detectada || r.landmarks.size() < 21) return;

    // Dibujar conexiones
    for (const auto& con : CONEXIONES) {
        Point p1(r.landmarks[con.first].x  * w,
                 r.landmarks[con.first].y  * h);
        Point p2(r.landmarks[con.second].x * w,
                 r.landmarks[con.second].y * h);
        line(img, p1, p2, Scalar(255,180,0), 2);
    }

    // Dibujar todos los landmarks
    for (int i = 0; i < 21; i++) {
        Point p(r.landmarks[i].x * w, r.landmarks[i].y * h);
        circle(img, p, 4, Scalar(0,200,255), -1);
        circle(img, p, 5, Scalar(0,0,0), 1);
    }

    // Puntas de dedos: verde=extendido, rojo=cerrado
    for (int j = 0; j < 5; j++) {
        int tip = TIPS_IDS[j];
        int pip = PIPS_IDS[j];
        bool ext;
        if (tip == 4) // pulgar
            ext = r.landmarks[tip].x < r.landmarks[pip].x;
        else
            ext = r.landmarks[tip].y < r.landmarks[pip].y;
        Point p(r.landmarks[tip].x * w, r.landmarks[tip].y * h);
        Scalar col_tip = ext ? Scalar(0,255,0) : Scalar(0,0,255);
        circle(img, p, 8,  col_tip, -1);
        circle(img, p, 9,  Scalar(255,255,255), 1);
    }

    // Bounding box y etiqueta
    float xmin=1,ymin=1,xmax=0,ymax=0;
    for (const Landmark& lm : r.landmarks) {
        xmin=min(xmin,lm.x); ymin=min(ymin,lm.y);
        xmax=max(xmax,lm.x); ymax=max(ymax,lm.y);
    }
    int bx1=max((int)(xmin*w)-10,0), by1=max((int)(ymin*h)-10,0);
    int bx2=min((int)(xmax*w)+10,w), by2=min((int)(ymax*h)+10,h);
    rectangle(img, Point(bx1,by1), Point(bx2,by2), r.color, 2);

    // Etiqueta con fondo
    string label = r.gesto + " (" + to_string(r.num_dedos) + " dedos)";
    int bl=0;
    Size ts = getTextSize(label, FONT_HERSHEY_DUPLEX, 0.6, 2, &bl);
    Point org(bx1, max(by1-8, 20));
    rectangle(img, Point(org.x-2,org.y-ts.height-4),
              Point(org.x+ts.width+2,org.y+4), Scalar(0,0,0), FILLED);
    putText(img, label, org, FONT_HERSHEY_DUPLEX, 0.6, r.color, 2);
}

// ════════════════════════════════════════════════════════════════════════════
//  MOBILENET SSD
// ════════════════════════════════════════════════════════════════════════════
struct Persona { Rect bbox; float dist_cm; };

vector<Persona> detectar_personas(Net& net, const Mat& rgb,
                                   const Mat& depth_small) {
    vector<Persona> personas;
    if (net.empty()) return personas;
    int h=rgb.rows, w=rgb.cols;
    Mat blob = blobFromImage(rgb, 0.007843f, Size(300,300), 127.5f);
    net.setInput(blob);
    Mat det = net.forward();
    Mat dm(det.size[2], det.size[3], CV_32F, det.ptr<float>());
    for (int i=0;i<dm.rows;i++){
        if((int)dm.at<float>(i,1)!=15||dm.at<float>(i,2)<0.45f) continue;
        int x1=max((int)(dm.at<float>(i,3)*w),0);
        int y1=max((int)(dm.at<float>(i,4)*h),0);
        int x2=min((int)(dm.at<float>(i,5)*w),w-1);
        int y2=min((int)(dm.at<float>(i,6)*h),h-1);
        if(x2<=x1||y2<=y1) continue;
        Persona p; p.bbox=Rect(x1,y1,x2-x1,y2-y1); p.dist_cm=0;
        if(!depth_small.empty()){
            Mat roi=depth_small(p.bbox&Rect(0,0,w,h));
            Scalar m=mean(roi,roi>2);
            p.dist_cm=(float)(m[0]*2048.0/255.0/10.0);
        }
        personas.push_back(p);
    }
    return personas;
}

Mat mascara_manos(const Mat& depth_small,
                  const vector<Persona>& personas, int w, int h) {
    Mat mask=Mat::zeros(h,w,CV_8UC1);
    if(depth_small.empty()) return Mat::ones(h,w,CV_8UC1)*255;
    if(!personas.empty()){
        for(const Persona& p:personas){
            if(p.dist_cm<5) continue;
            float cm_max=max(p.dist_cm-15.0f,20.0f);
            int vmin=max((int)(15.0*10.0/2048.0*255.0),1);
            int vmax=min((int)(cm_max*10.0/2048.0*255.0),254);
            if(vmax<=vmin) continue;
            Mat zona; inRange(depth_small,vmin,vmax,zona);
            bitwise_or(mask,zona,mask);
        }
    } else {
        vector<uchar> vals;
        for(int y=0;y<depth_small.rows;y++)
            for(int x=0;x<depth_small.cols;x++){
                uchar v=depth_small.at<uchar>(y,x);
                if(v>2) vals.push_back(v);
            }
        if(vals.size()>200){
            sort(vals.begin(),vals.end());
            int vmin=max((int)vals[vals.size()*0.02]-3,1);
            int vmax=min((int)vals[vals.size()*0.20]+10,254);
            inRange(depth_small,vmin,vmax,mask);
        }
    }
    return mask;
}

// ════════════════════════════════════════════════════════════════════════════
int main() {
    // ── Iniciar MediaPipe ────────────────────────────────────────────────────
    if (!iniciar_mediapipe()) return -1;

    // ── Init Kinect ──────────────────────────────────────────────────────────
    freenect_device *f_dev;
    if(freenect_init(&f_ctx,NULL)<0) return -1;
    freenect_set_log_level(f_ctx,FREENECT_LOG_WARNING);
    if(freenect_open_device(f_ctx,&f_dev,0)<0){
        freenect_shutdown(f_ctx); return -1;
    }
    freenect_set_video_mode(f_dev,
        freenect_find_video_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_VIDEO_RGB));
    freenect_set_video_callback(f_dev,video_callback);
    freenect_start_video(f_dev);
    freenect_set_depth_mode(f_dev,
        freenect_find_depth_mode(FREENECT_RESOLUTION_MEDIUM,FREENECT_DEPTH_11BIT));
    freenect_set_depth_callback(f_dev,depth_callback);
    freenect_start_depth(f_dev);
    thread kinect_thread(freenect_loop);

    // ── MobileNet SSD ────────────────────────────────────────────────────────
    Net ssd_net;
    bool ok_ssd=false;
    try {
        ssd_net=readNetFromCaffe(
            "MobileNetSSD_deploy.prototxt",
            "MobileNetSSD_deploy.caffemodel");
        ssd_net.setPreferableBackend(DNN_BACKEND_OPENCV);
        ssd_net.setPreferableTarget(DNN_TARGET_CPU);
        ok_ssd=true;
        cout<<"[OK] MobileNet SSD"<<endl;
    } catch(...){ cout<<"[WARN] Sin MobileNet SSD"<<endl; }

    // ── Cascade cara ─────────────────────────────────────────────────────────
    CascadeClassifier cc_cara;
    bool ok_ca=cc_cara.load("haarcascade_frontalface_default.xml");

    namedWindow("DETECCION MANO V7 - UAA", WINDOW_AUTOSIZE);
    setMouseCallback("DETECCION MANO V7 - UAA", mouse_cb);
    cout<<"CLIC o C=captura | ESC=salir"<<endl;

    int frame_count=0;
    const int SSD_CADA=15;
    vector<Persona> personas_cache;

    while(ejecutando){
        Mat rgb_raw, depth_raw;
        {lock_guard<mutex> lk(frame_mutex);
         if(nuevo_frame){rgb_raw=frame_actual.clone();nuevo_frame=false;}}
        {lock_guard<mutex> lk(depth_mutex);
         if(nuevo_depth){depth_raw=depth_actual.clone();nuevo_depth=false;}}
        if(rgb_raw.empty()){waitKey(10);continue;}

        Mat rgb, depth_small;
        resize(rgb_raw,rgb,Size(320,240));
        if(!depth_raw.empty()) resize(depth_raw,depth_small,Size(320,240));

        Mat display=rgb.clone();
        Mat gray; cvtColor(rgb,gray,COLOR_BGR2GRAY); equalizeHist(gray,gray);

        // ── MobileNet SSD ─────────────────────────────────────────────────────
        frame_count++;
        if(ok_ssd&&frame_count%SSD_CADA==0)
            personas_cache=detectar_personas(ssd_net,rgb,depth_small);

        for(const Persona& p:personas_cache){
            rectangle(display,p.bbox,Scalar(255,100,0),1);
            char pbuf[30]; snprintf(pbuf,sizeof(pbuf),"P %.0fcm",p.dist_cm);
            putText(display,pbuf,Point(p.bbox.x,max(p.bbox.y-4,10)),
                    FONT_HERSHEY_SIMPLEX,0.32,Scalar(255,100,0),1);
        }

        // ── Mascara depth ─────────────────────────────────────────────────────
        Mat mask_prof=mascara_manos(depth_small,personas_cache,320,240);

        // ── Excluir caras ─────────────────────────────────────────────────────
        if(ok_ca){
            vector<Rect> caras;
            cc_cara.detectMultiScale(gray,caras,1.1,5,0,Size(40,40));
            for(const Rect& c:caras){
                int dx=(int)(c.width*0.4),dy=(int)(c.height*0.5);
                Rect zona(max(c.x-dx,0),max(c.y-dy,0),
                          min(c.width+2*dx,320-max(c.x-dx,0)),
                          min(c.height+2*dy,240-max(c.y-dy,0)));
                mask_prof(zona)=Scalar(0);
                rectangle(display,zona,Scalar(0,165,255),1);
                putText(display,"CARA",Point(c.x,max(c.y-4,10)),
                        FONT_HERSHEY_SIMPLEX,0.35,Scalar(0,165,255),1);
            }
        }

        // ── Frame enmascarado para MediaPipe ──────────────────────────────────
        Mat rgb_masked; rgb.copyTo(rgb_masked,mask_prof);

        // ── Llamar MediaPipe via Python C API ─────────────────────────────────
        vector<ResultadoMP> manos = llamar_mediapipe(rgb_masked);

        // Dibujar cada mano
        string gesto_final="Sin mano"; Scalar col_g(100,100,100);
        for(const ResultadoMP& r:manos){
            dibujar_mano(display,r,320,240);
            gesto_final=r.gesto;
            col_g=r.color;
        }

        // ── Barra superior ────────────────────────────────────────────────────
        rectangle(display,Point(0,0),Point(320,48),Scalar(0,0,0),FILLED);
        putText(display,gesto_final,Point(6,38),
                FONT_HERSHEY_DUPLEX,0.85,col_g,2);
        if(!manos.empty()){
            char dbuf[20];
            snprintf(dbuf,sizeof(dbuf),"[%d ded]",manos[0].num_dedos);
            putText(display,dbuf,Point(230,38),
                    FONT_HERSHEY_SIMPLEX,0.5,Scalar(255,220,50),1);
        }

        // ── Panel depth ───────────────────────────────────────────────────────
        Mat depth_panel=Mat::zeros(Size(320,240),CV_8UC3);
        if(!depth_small.empty()){
            applyColorMap(depth_small,depth_panel,COLORMAP_JET);
            Mat zb; cvtColor(mask_prof,zb,COLOR_GRAY2BGR);
            addWeighted(depth_panel,0.6,zb,0.4,0,depth_panel);
        }
        char npbuf[30];
        snprintf(npbuf,sizeof(npbuf),"Personas:%d",(int)personas_cache.size());
        putText(depth_panel,npbuf,Point(5,18),
                FONT_HERSHEY_SIMPLEX,0.42,Scalar(255,255,255),1);

        // ── Panel status ──────────────────────────────────────────────────────
        Mat status=Mat::zeros(Size(320,240),CV_8UC3);
        char buf[60];
        putText(status,"DETECCION MANO V7 UAA",Point(5,24),
                FONT_HERSHEY_DUPLEX,0.5,Scalar(255,255,255),1);
        rectangle(status,Point(5,30),Point(315,32),Scalar(255,255,255),FILLED);
        snprintf(buf,sizeof(buf),"TEMP: %.1fC",obtener_temp());
        putText(status,buf,Point(10,52),FONT_HERSHEY_SIMPLEX,0.45,Scalar(0,255,0),1);
        putText(status,"MediaPipe: OK (Python C API)",
                Point(10,70),FONT_HERSHEY_SIMPLEX,0.42,Scalar(0,255,0),1);
        putText(status,ok_ssd?"MobileNet: OK":"MobileNet: OFF",
                Point(10,88),FONT_HERSHEY_SIMPLEX,0.42,
                ok_ssd?Scalar(0,255,0):Scalar(100,100,100),1);
        snprintf(buf,sizeof(buf),"Manos detectadas: %d",(int)manos.size());
        putText(status,buf,Point(10,108),FONT_HERSHEY_SIMPLEX,0.42,Scalar(200,200,200),1);
        putText(status,"VERDE  = dedo extendido",
                Point(10,132),FONT_HERSHEY_SIMPLEX,0.4,Scalar(0,255,0),1);
        putText(status,"ROJO   = dedo cerrado",
                Point(10,150),FONT_HERSHEY_SIMPLEX,0.4,Scalar(0,0,255),1);
        putText(status,"CYAN   = landmarks mano",
                Point(10,168),FONT_HERSHEY_SIMPLEX,0.4,Scalar(0,200,255),1);
        putText(status,"AZUL   = persona (MobileNet)",
                Point(10,186),FONT_HERSHEY_SIMPLEX,0.4,Scalar(255,100,0),1);
        putText(status,"NARANJA= cara excluida",
                Point(10,204),FONT_HERSHEY_SIMPLEX,0.4,Scalar(0,165,255),1);
        putText(status,"CLIC o C=captura | ESC=salir",
                Point(10,224),FONT_HERSHEY_SIMPLEX,0.38,Scalar(150,150,150),1);

        // ── Ensamblar 2x2 ─────────────────────────────────────────────────────
        Mat top,bot,combined;
        hconcat(display,    depth_panel,  top);
        hconcat(rgb_masked, status,       bot);
        vconcat(top,bot,combined);
        ultimo_combined=combined.clone();
        imshow("DETECCION MANO V7 - UAA",combined);

        // ── Captura ───────────────────────────────────────────────────────────
        if(captura_pendiente){
            char fname[60];
            snprintf(fname,sizeof(fname),"captura_%ld.png",(long)time(nullptr));
            imwrite(fname,ultimo_combined);
            cout<<"[CAPTURA] "<<fname<<endl;
            captura_pendiente=false;
        }
        int key=waitKey(10);
        if(key==27){ejecutando=false;break;}
        if(key=='c'||key=='C'){
            char fname[60];
            snprintf(fname,sizeof(fname),"captura_%ld.png",(long)time(nullptr));
            imwrite(fname,ultimo_combined);
            cout<<"[CAPTURA] "<<fname<<endl;
        }
    }

    // ── Limpiar ───────────────────────────────────────────────────────────────
    Py_XDECREF(py_procesar);
    Py_Finalize();
    freenect_stop_depth(f_dev);
    freenect_stop_video(f_dev);
    kinect_thread.join();
    freenect_close_device(f_dev);
    freenect_shutdown(f_ctx);
    destroyAllWindows();
    return 0;
}
