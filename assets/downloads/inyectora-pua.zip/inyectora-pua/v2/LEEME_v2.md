# Inyectora PUA – versión 2

La v1 queda tal cual en las carpetas `07_scada_nodered` y `08_entrega_scada`. La v2 está aquí.

## plc/
- `inyectora_v2.gx3`: proyecto de GX Works3 con el ladder completo de la inyectora (109 renglones, 689 pasos, 0 errores).
  La entrada analógica CH1 está activada para el sensor de distancia de la tolva.
- `escalera_inyectora_v2.txt`: el mismo ladder en texto (lista de instrucciones).

Mapa principal:

| Registro o bit | Qué es |
|---|---|
| D130 | Paso del ciclo (0 a 9) |
| M100–M109 | Bits de paso (M100 = paso 0 … M109 = paso 9) |
| D121 | Piezas hechas |
| D120 | Meta del lote |
| D140 | Nivel de la tolva en % (de SD6020, calibrado con D142 = vacía y D143 = llena) |
| M0 / M1 / M2 | Iniciar / paro / reset desde el HMI o el SCADA |
| M20 | Modo simulación: simula los sensores X5 a X10 y el paro de emergencia |
| M60 | Falla (se enclava) |
| M70–M77 | Alarmas |
| M50 | Sistema listo |
| M51 | El molde montado coincide con el seleccionado |
| M10 | En producción |

Salidas:

| Salida | Función |
|---|---|
| Y0 | Resistencias |
| Y1 | Cerrar molde |
| Y2 | Bajar émbolo |
| Y3 | Abrir molde |
| Y4 | Subir émbolo |
| Y5 | Torreta verde |
| Y6 | Torreta ámbar |
| Y7 | Torreta roja |

## hmi/
`HMI_Inyectora_v2.GTX` (GT Designer3, GS21). Se probó con GT Simulator3 conectado a GX Simulator3.

Pantalla B-1:
- La barra "Sensor" muestra D140 (nivel de la tolva).
- El foco "Sistema listo" es M50.
- El foco de la tolva es M73 (falta material).
- El botón INICIAR PROCESO pasa a la pantalla B-3.

Pantalla B-3:

| Objeto | Dispositivo |
|---|---|
| Piezas hechas | D121 |
| Meta | D120 (se puede escribir) |
| Nivel de tolva | D140 |
| START | M0 |
| RESET | M2 |
| Falla | M60 |
| Material | M73 |
| Molde | M51 |
| Producción | M10 |
| Focos de las partes de la máquina | Y0–Y2, M103, M108 |

## nodered/
`flujo_inyectora_v2.json` (lo genera `make_flow_v2.py` junto con `maquina.jpg`). Cambios:
- La página web se ve igual que la pantalla B-3 del HMI: los mismos colores grises, la imagen de la máquina, los focos encima de cada parte, los números de piezas, meta y tolva, y los botones verde y azul. Ver `vista_tablero_v2.png`.
- La alarma M74 ahora dice "ciclo detenido por paro".
- Hay un botón de modo simulación (M20).
- Muestra las piezas de la última hora y el último tiempo de ciclo.
- Guarda un historial en `~/produccion.csv`, que se descarga en `http://<pi>:1880/api/produccion.csv`.

Para instalarlo en la Raspberry: copia el json como `~/.node-red/flows.json` y ejecuta `sudo systemctl restart nodered`.
