# Diagrama de flujo del ciclo

Secuencia del PLC en 7 etapas: detección de pellets (X1), calentamiento (Y1/X2), verificación del molde (X3/X4), inyección (Y2), enfriamiento (Y3), desmoldado (X5) y conteo de piezas.

- `flujo-inyector.png` / `.svg`: imagen lista para Word, Canva o presentación.
- `flujo-inyector.mmd`: código Mermaid; se edita en https://mermaid.live
- `diagrama_flujo.html`: diagrama con tabla de E/S y puntos por confirmar.

Las señales con `*` (Y4/Y5, motor del molde) son propuestas: el avance aún no las define.

![Diagrama](flujo-inyector.png)

## Versión en Canva

- Diseño editable (2 diapositivas: diagrama de flujo + tabla de E/S): https://canva.link/0wk0zztwaitzjgy
- `Ciclo_inyector_plastico.pdf`: la misma versión en formato póster 16:9.
