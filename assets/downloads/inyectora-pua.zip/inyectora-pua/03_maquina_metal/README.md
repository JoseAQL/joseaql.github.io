# Máquina de metal (tornillo directo, boceto 1)

- `planos/Planos_cortes_despiece.pdf`: plano de corte de mi material, barrenos de cada placa, escuadras, base, tornillería por unión, lista de compras, despiece y plantillas 1:1.
- `visor_maquina_3D.html`: modelo 3D; toca una pieza para ver origen, proceso y tornillos.
- `DXF_piezas/`, `STL/`: piezas para CNC o revisión.
- `imprimir_3D/`: soporte LM12UU (4 piezas: 2 normales y 2 en espejo, PETG).
