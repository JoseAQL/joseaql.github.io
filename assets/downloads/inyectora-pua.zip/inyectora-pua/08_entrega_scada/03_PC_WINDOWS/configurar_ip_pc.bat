@echo off
REM Ejecutar como ADMINISTRADOR (clic derecho > Ejecutar como administrador)
REM Deja el Ethernet de la PC con dos IPs: una para la Raspberry y otra para el PLC.
set ADAPTADOR=Ethernet
netsh interface ip set address name="%ADAPTADOR%" static 192.168.60.1 255.255.255.0
netsh interface ip add address name="%ADAPTADOR%" 192.168.3.13 255.255.255.0
echo.
echo Listo. IPs del adaptador %ADAPTADOR%:
netsh interface ip show address name="%ADAPTADOR%"
ping -n 2 192.168.60.2
ping -n 2 192.168.3.10
pause
