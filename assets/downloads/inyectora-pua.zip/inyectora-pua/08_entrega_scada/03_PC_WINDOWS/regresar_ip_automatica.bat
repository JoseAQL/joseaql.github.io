@echo off
REM Ejecutar como ADMINISTRADOR. Regresa el Ethernet a automatico (para tu casa / internet por cable).
netsh interface ip set address name="Ethernet" dhcp
echo Listo, Ethernet en automatico.
pause
