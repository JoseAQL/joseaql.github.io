#!/bin/bash
# =====================================================================
#  Inyectora PUA - instalador completo de la Raspberry Pi (SCADA)
#  Deja: Node-RED + nodos del PLC y del tablero, autoplc (encuentra al PLC
#  solo), IP fija de servicio en el cable y el flujo del tablero cargado.
#
#  Uso (en esta carpeta 01_RASPBERRY, con internet por WiFi):
#      sudo bash instalar_todo.sh
#  Se puede volver a correr sin problema (actualiza lo que haya cambiado).
#
#  Probado en: Raspberry Pi 4B, Raspberry Pi OS Bullseye 64 bits,
#              Node-RED 4.0.9, Node.js 20, FX5U con SLMP TCP 1025.
# =====================================================================
set -e

# ---------------- AJUSTA AQUI SI CAMBIAN LAS IPs ----------------------
IP_SERVICIO="192.168.60.2/24"   # IP fija para entrar desde tu PC por cable (PC = 192.168.60.1)
REDES="192.168.3"               # red del PLC (tres primeros numeros)
IP_PI="12"                      # ultimo numero de la Raspberry en la red del PLC (192.168.3.12)
PUERTO="1025"                   # puerto SLMP configurado en GX Works3
# -----------------------------------------------------------------------

if [ "$EUID" -ne 0 ]; then echo "Correlo con sudo:  sudo bash $0"; exit 1; fi
USUARIO="${SUDO_USER:-$(logname 2>/dev/null || echo pi)}"
CASA=$(getent passwd "$USUARIO" | cut -d: -f6)
AQUI="$(cd "$(dirname "$0")" && pwd)"
paso() { echo; echo "=================== $* ==================="; }

paso "1/7 Paquetes basicos"
apt-get update -y || true
apt-get install -y curl iputils-arping python3 || true

paso "2/7 Node-RED (si no esta instalado)"
if ! command -v node-red >/dev/null 2>&1; then
  sudo -u "$USUARIO" bash -c 'bash <(curl -sL https://github.com/node-red/linux-installers/releases/latest/download/install-update-nodered-deb) --confirm-install --confirm-pi'
else
  echo "Node-RED ya esta: $(node-red --version 2>/dev/null | head -1)"
fi

paso "3/7 Nodos del PLC (mcprotocol) y del tablero (Dashboard 2.0)"
sudo -u "$USUARIO" mkdir -p "$CASA/.node-red"
sudo -u "$USUARIO" bash -c "cd '$CASA/.node-red' && npm install --no-fund --no-audit node-red-contrib-mcprotocol@1.2.1 @flowfuse/node-red-dashboard@1.26.0"

paso "4/7 Servicio de Node-RED con TU usuario (arranca solo al prender)"
# Algunas imagenes traen el servicio apuntando a otro usuario (nos paso con 'DarthMalgus')
mkdir -p /etc/systemd/system/nodered.service.d
cat > /etc/systemd/system/nodered.service.d/usuario.conf <<EOF
[Service]
User=$USUARIO
Group=$USUARIO
WorkingDirectory=$CASA
Environment="HOME=$CASA"
EOF
cat > /etc/systemd/system/nodered.service.d/plc.conf <<'EOF'
[Service]
Environment="PLC_IP=127.0.0.1" "PLC_PORT=1025"
EnvironmentFile=-/etc/autoplc/plc.env
EOF

paso "5/7 autoplc (busca al PLC en el cable y le pasa la IP a Node-RED)"
install -m 755 "$AQUI/autoplc/autoplc.py" /usr/local/bin/autoplc.py
mkdir -p /etc/autoplc
cat > /etc/autoplc/autoplc.conf <<EOF
# Configuracion de autoplc. Despues de cambiarla: sudo systemctl restart autoplc
PUERTO=$PUERTO
REDES=$REDES
IP_PI=$IP_PI
IP_SERVICIO=$IP_SERVICIO
EOF
cat > /etc/systemd/system/autoplc.service <<'EOF'
[Unit]
Description=autoplc: busca el PLC FX5U en el cable y conecta Node-RED
After=network.target

[Service]
ExecStart=/usr/bin/python3 -u /usr/local/bin/autoplc.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

paso "6/7 IP fija de servicio en el cable ($IP_SERVICIO)"
# Funciona aunque eth0 lo maneje dhcpcd (Bullseye) en lugar de NetworkManager
cat > /etc/systemd/system/ip-cable.service <<EOF
[Unit]
Description=IP fija del cable para entrar desde la PC
After=network-online.target

[Service]
Type=oneshot
ExecStart=/bin/sh -c 'sleep 5; ip addr add $IP_SERVICIO dev eth0 || true'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
ip addr add "$IP_SERVICIO" dev eth0 2>/dev/null || true

paso "7/7 Flujo del tablero y arranque"
if [ -f "$CASA/.node-red/flows.json" ]; then
  cp "$CASA/.node-red/flows.json" "$CASA/.node-red/flows_respaldo_$(date +%Y%m%d_%H%M).json"
fi
install -o "$USUARIO" -g "$USUARIO" -m 644 "$AQUI/nodered/flujo_inyectora.json" "$CASA/.node-red/flows.json"
pkill -u "$USUARIO" -f "node-red" || true
sleep 2
systemctl daemon-reload
systemctl enable ip-cable.service autoplc.service nodered.service
systemctl restart nodered.service autoplc.service
echo "Esperando 30 s a que encuentre al PLC..."
sleep 30
echo
systemctl --no-pager is-active nodered autoplc || true
cat /run/autoplc/estado.json 2>/dev/null; echo
curl -s localhost:1880/api/estado | python3 -c "import json,sys;d=json.load(sys.stdin);print('>>> PLC EN LINEA' if d.get('conectado') else '>>> Todavia sin PLC: '+str(d.get('error')))" || true
echo
echo "LISTO."
echo "  Tablero:        http://192.168.60.2:1880/dashboard   (desde tu PC por cable)"
echo "  Editor:         http://192.168.60.2:1880"
echo "  Ver autoplc:    sudo journalctl -u autoplc -f"
echo "  Ver Node-RED:   sudo journalctl -u nodered -f"
