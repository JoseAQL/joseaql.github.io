#!/bin/bash
# Solo actualiza el flujo del tablero y autoplc (sin reinstalar nada).
# Uso:  bash actualizar.sh      (pide la contraseña de sudo)
set -e
cd "$(dirname "$0")"
cp ~/.node-red/flows.json ~/.node-red/flows_respaldo_$(date +%Y%m%d_%H%M).json 2>/dev/null || true
cp nodered/flujo_inyectora.json ~/.node-red/flows.json
sudo install -m 755 autoplc/autoplc.py /usr/local/bin/autoplc.py
sudo systemctl restart nodered autoplc
echo "Esperando 25 s..."; sleep 25
curl -s localhost:1880/api/estado | python3 -c "import json,sys;d=json.load(sys.stdin);print('>>> PLC EN LINEA' if d['conectado'] else '>>> Sin PLC: '+str(d['error']))"
