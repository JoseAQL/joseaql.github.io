#!/bin/bash
# Arranca el PLC de mentiras (para practicar sin el FX5U). autoplc lo usa solo si no hay PLC real.
# Apagarlo:  pkill -f plc_simulado.py
cd "$(dirname "$0")/nodered" && nohup python3 plc_simulado.py > ~/plc_simulado.log 2>&1 &
echo "PLC simulado corriendo en 127.0.0.1:1025 (log en ~/plc_simulado.log)"
