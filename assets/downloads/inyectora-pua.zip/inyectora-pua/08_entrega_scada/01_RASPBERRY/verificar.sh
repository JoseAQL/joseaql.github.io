#!/bin/bash
# Revisión rápida de todo (no cambia nada). Uso: bash verificar.sh
echo "== IPs del cable (eth0) y WiFi (wlan0) =="; ip -br addr show eth0; ip -br addr show wlan0
echo; echo "== Servicios =="; for s in nodered autoplc ip-cable; do printf "%-10s %s\n" $s "$(systemctl is-active $s)"; done
echo; echo "== Lo que encontro autoplc =="; cat /run/autoplc/estado.json 2>/dev/null; echo; cat /etc/autoplc/plc.env 2>/dev/null
PLC=$(grep -oP 'PLC_IP=\K.*' /etc/autoplc/plc.env 2>/dev/null)
if [ -n "$PLC" ] && [ "$PLC" != "127.0.0.1" ]; then echo; echo "== Ping al PLC $PLC =="; ping -c 2 -W 1 "$PLC" | tail -2; fi
echo; echo "== Tablero =="
curl -s localhost:1880/api/estado | python3 -c "import json,sys;d=json.load(sys.stdin);print('PLC EN LINEA' if d['conectado'] else 'Sin PLC: '+str(d['error']))" 2>/dev/null || echo "Node-RED no responde"
