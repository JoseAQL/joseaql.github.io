import json, sys

PLC_HOST = sys.argv[1] if len(sys.argv) > 1 else "${PLC_IP}"   # ${PLC_IP} lo llena autoplc
PLC_PORT = sys.argv[3] if len(sys.argv) > 3 else "${PLC_PORT}"
OUT = sys.argv[2] if len(sys.argv) > 2 else "flujo_inyectora.json"
Z = "tab_iny"
nodes = []
def add(n): nodes.append(n); return n

add({"id": Z, "type": "tab", "label": "Inyectora PUA", "disabled": False,
     "info": "Tablero SCADA de la inyectora PUA.\nLee el FX5U por SLMP (MC Protocol 3E) cada 0.5 s y lo muestra en /dashboard."})

# ---------- configuracion ----------
add({"id": "cfg_plc", "type": "MC Protocol Connection", "name": "FX5U inyectora", "host": PLC_HOST, "port": PLC_PORT,
     "protocol": "TCP", "frame": "3E", "plcType": "Q", "ascii": False, "PLCStation": "", "PCStation": "",
     "PLCModuleNo": "", "network": "", "octalInputOutput": True, "timeout": "1500"})
add({"id": "ui_base", "type": "ui-base", "name": "Inyectora", "path": "/dashboard", "appIcon": "", "includeClientData": True,
     "acceptsClientConfig": ["ui-notification", "ui-control"], "showPathInSidebar": False, "headerContent": "page",
     "navigationStyle": "none", "titleBarStyle": "default", "showReconnectNotification": True, "notificationDisplayTime": 1,
     "showDisconnectNotification": True, "allowInstall": True})
add({"id": "ui_theme", "type": "ui-theme", "name": "Planta",
     "colors": {"surface": "#1F3B66", "primary": "#2457D6", "bgPage": "#ECEEE9", "groupBg": "#ffffff", "groupOutline": "#D2D7D0"},
     "sizes": {"density": "default", "pagePadding": "12px", "groupGap": "12px", "groupBorderRadius": "8px", "widgetGap": "12px"}})
add({"id": "ui_page", "type": "ui-page", "name": "Inyectora PUA", "ui": "ui_base", "path": "/inyectora", "icon": "factory",
     "layout": "grid", "theme": "ui_theme",
     "breakpoints": [{"name": "Default", "px": 0, "cols": 3}, {"name": "Tablet", "px": 576, "cols": 6},
                     {"name": "Small Desktop", "px": 768, "cols": 9}, {"name": "Desktop", "px": 1024, "cols": 12}],
     "order": 1, "className": "", "visible": "true", "disabled": "false"})
def group(gid, name, width, order):
    return add({"id": gid, "type": "ui-group", "name": name, "page": "ui_page", "width": str(width), "height": "1",
                "order": order, "showTitle": True, "className": "", "visible": "true", "disabled": "false", "groupType": "default"})
group("g_panel", "Estado de la maquina", 12, 1)
group("g_temp", "Nivel de material en la tolva", 12, 2)

# ---------- lectura ----------
add({"id": "inj_leer", "type": "inject", "z": Z, "name": "cada 0.5 s", "props": [{"p": "payload"}], "repeat": "0.5",
     "crontab": "", "once": True, "onceDelay": "1", "topic": "", "payload": "true", "payloadType": "bool",
     "x": 130, "y": 140, "wires": [[f"rd_{i}" for i in range(8)]]})
LECTURAS = [("D100,2", "temp_sp"), ("D110,2", "molde"), ("D120,2", "meta_pz"), ("D140,1", "laser"),
            ("D150,2", "xy"), ("M50,2", "m50"), ("M70,8", "alarmas"), ("M100,10", "pasos")]
for i, (addr, key) in enumerate(LECTURAS):
    y = 60 + i * 50
    add({"id": f"rd_{i}", "type": "MC Read", "z": Z, "name": addr, "topic": key, "connection": "cfg_plc", "address": addr,
         "addressType": "str", "outputFormat": "1", "errorHandling": "msg", "outputs": 1, "x": 330, "y": y, "wires": [[f"sv_{i}"]]})
    add({"id": f"sv_{i}", "type": "function", "z": Z, "name": f"guardar {key}",
         "func": ("if (msg.error || msg.payload === null || msg.payload === undefined) {\n"
                  "    flow.set('error', String(msg.error || 'sin respuesta'));\n    flow.set('ultimoError', Date.now());\n    return null;\n}\n"
                  f"let v = msg.payload;\nif (!Array.isArray(v)) v = [v];\nflow.set('{key}', v);\nflow.set('ultimaLectura', Date.now());\nreturn null;"),
         "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 540, "y": y, "wires": [[]]})

ARMAR = r"""
// Junta todas las lecturas en un solo objeto "estado" y detecta alarmas nuevas.
const g = k => flow.get(k) || [];
const n = v => Number(v) || 0;
const b = v => (v === true || v === 1 || v === '1') ? 1 : 0;
const PASOS = ['Reposo','Calentando','Cerrando molde','Inyectando','Sosteniendo presion','Subiendo embolo','Enfriando','Abriendo molde','Expulsando pieza','Lote completo'];
const ALM = [['M70','PARO DE EMERGENCIA ACTIVADO',2],['M71','SENSOR NO CONFIRMA POSICION',2],['M72','MOLDE MONTADO NO COINCIDE',2],['M73','FALTA MATERIAL EN TOLVA',2],['M74','TERMOPAR DESCONECTADO',2],['M75','CALENTANDO, ESPERE',1],['M76','CICLO TERMINADO',1],['M77','LOTE COMPLETO',1]];
const XN = ['X0 Iniciar','X1 Paro','X2 Paro emergencia','X3 Reset','X4 (sin uso)','X5 S1 molde abierto','X6 S2 molde cerrado','X7 S3 embolo arriba','X10 S4 embolo abajo'];
const YN = ['Y0 Resistencias','Y1 Cerrar molde','Y2 Bajar embolo','Y3 Abrir molde','Y4 Subir embolo','Y5 Torreta verde','Y6 Torreta ambar','Y7 Torreta roja'];
const ts = g('temp_sp'), mo = g('molde'), mp = g('meta_pz'), xy = g('xy'), m50 = g('m50'), al = g('alarmas').map(b), pa = g('pasos').map(b);
const vivo = Date.now() - (flow.get('ultimaLectura') || 0) < 3000;
const paso = Math.max(0, pa.indexOf(1));
const activas = ALM.filter((a, i) => al[i]).map(a => ({bit: a[0], msg: a[1], nivel: a[2]}));
// historial: compara con la lectura anterior
const antes = flow.get('activasAntes') || [];
const ahoraBits = activas.map(a => a.bit);
const hist = flow.get('hist') || [];
const D = new Date(), z2 = v => String(v).padStart(2, '0');
const fecha = `${D.getFullYear()}-${z2(D.getMonth() + 1)}-${z2(D.getDate())} ${z2(D.getHours())}:${z2(D.getMinutes())}:${z2(D.getSeconds())}`;
const lineas = [];
ALM.forEach(a => {
    const on = ahoraBits.includes(a[0]), was = antes.includes(a[0]);
    if (vivo && on !== was) {
        const ev = {fecha, bit: a[0], mensaje: a[1], evento: on ? 'OCURRIO' : 'RESET'};
        hist.unshift(ev); lineas.push(`${fecha},${a[0]},${a[1]},${ev.evento}`);
    }
});
if (vivo) flow.set('activasAntes', ahoraBits);
flow.set('hist', hist.slice(0, 50));
const red = flow.get('red') || null;
const redVieja = Date.now() - (flow.get('redHora') || 0) > 30000;
const estado = {
    red: redVieja ? {estado: 'autoplc no esta corriendo', equipos: []} : red,
    conectado: vivo, error: vivo ? '' : (flow.get('error') || 'esperando datos del PLC'),
    hora: new Date().toLocaleTimeString('es-MX', {hour12: false}),
    temp: n(ts[0]), sp: n(ts[1]), molde: n(mo[0]), montado: n(mo[1]), meta: n(mp[0]), piezas: n(mp[1]),
    laser: n(g('laser')[0]), tolva: Math.max(0, Math.min(100, n(g('laser')[0]))), rr: b(m50[0]), moldeOk: b(m50[1]),
    paso, pasoNombre: PASOS[paso], alarmas: activas, hist: hist.slice(0, 15),
    x: XN.map((nm, i) => ({n: nm, v: (n(xy[0]) >> i) & 1})), y: YN.map((nm, i) => ({n: nm, v: (n(xy[1]) >> i) & 1}))
};
flow.set('estado', estado);
return [
    {payload: estado},
    vivo ? {topic: 'Nivel %', payload: estado.tolva} : null,
    vivo ? {topic: 'Minimo (alarma M73)', payload: 10} : null,
    lineas.length ? {payload: lineas.join('\n'), filename: (env.get('HOME') || '/home/pi') + '/alarmas.csv'} : null
];
"""
add({"id": "inj_armar", "type": "inject", "z": Z, "name": "armar cada 0.5 s", "props": [{"p": "payload"}], "repeat": "0.5",
     "crontab": "", "once": True, "onceDelay": "1.5", "topic": "", "payload": "", "payloadType": "date",
     "x": 150, "y": 520, "wires": [["fn_armar"]]})
add({"id": "fn_armar", "type": "function", "z": Z, "name": "armar estado", "func": ARMAR.strip(), "outputs": 4,
     "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 360, "y": 520,
     "wires": [["ui_panel"], ["ui_chart"], ["ui_chart"], ["csv_file"]]})
add({"id": "csv_file", "type": "file", "z": Z, "name": "alarmas.csv", "filename": "filename", "filenameType": "msg",
     "appendNewline": True, "createDir": True, "overwriteFile": "false", "encoding": "utf8", "x": 590, "y": 580, "wires": [[]]})

PANEL = r"""<template>
  <div class="iny" v-if="msg && msg.payload">
    <div class="top" v-if="msg.payload.red">
      <span class="pill">Red del cable: {{ msg.payload.red.estado }}<template v-if="msg.payload.red.plc_ip"> · PLC {{ msg.payload.red.plc_ip }} · Raspberry {{ msg.payload.red.pi_ip || '-' }}</template></span>
      <span class="pill" v-for="e in msg.payload.red.equipos" :key="e.ip">{{ e.ip }} · {{ e.tipo }}</span>
    </div>
    <div class="top">
      <span :class="['pill', msg.payload.conectado ? 'ok' : 'bad']">{{ msg.payload.conectado ? 'PLC en linea ' + msg.payload.hora : 'Sin PLC: ' + msg.payload.error }}</span>
      <span class="pill">Paso M{{ 100 + msg.payload.paso }} · {{ msg.payload.pasoNombre }}</span>
      <span :class="['pill', msg.payload.rr ? 'ok' : 'warn']">Red Rabbit {{ msg.payload.rr ? 'OK' : 'pendiente' }}</span>
      <span :class="['pill', msg.payload.moldeOk ? 'ok' : 'bad']">Molde {{ msg.payload.molde }} / montado {{ msg.payload.montado }}</span>
    </div>
    <div class="kpis">
      <div class="kpi heat"><small>Nivel de tolva D140</small><b>{{ msg.payload.tolva }} %</b><div class="bar"><i :style="{width: msg.payload.tolva + '%'}"></i></div></div>
      <div class="kpi good"><small>Piezas / meta</small><b>{{ msg.payload.piezas }} / {{ msg.payload.meta }}</b></div>
      <div class="kpi"><small>Alarmas activas</small><b>{{ msg.payload.alarmas.length }}</b></div>
    </div>
    <div class="alarms">
      <div v-for="a in msg.payload.alarmas" :key="a.bit" :class="['alarm', a.nivel === 1 ? 'info' : '']">{{ a.bit }} · {{ a.msg }}</div>
      <div v-if="!msg.payload.alarmas.length" class="none">Sin alarmas</div>
    </div>
    <div class="btns">
      <button class="g" @click="cmd('iniciar')">INICIAR</button>
      <button class="r" @click="cmd('paro')">PARO</button>
      <button class="b" @click="cmd('reset')">RESET</button>
      <label>Meta <input type="number" min="1" max="999" v-model.number="meta"></label>
      <button class="b" @click="guardarMeta">Guardar meta</button>
      <span class="note">{{ nota }}</span>
    </div>
    <div class="io">
      <div><b>Entradas</b><div v-for="i in msg.payload.x" :key="i.n"><span :class="['led', i.v ? 'on' : '']"></span>{{ i.n }}</div></div>
      <div><b>Salidas</b><div v-for="i in msg.payload.y" :key="i.n"><span :class="['led', i.v ? 'on' : '']"></span>{{ i.n }}</div></div>
    </div>
    <table>
      <thead><tr><th>Fecha y hora</th><th>Bit</th><th>Mensaje</th><th>Evento</th></tr></thead>
      <tbody>
        <tr v-for="(h, k) in msg.payload.hist" :key="k"><td>{{ h.fecha }}</td><td>{{ h.bit }}</td><td>{{ h.mensaje }}</td><td>{{ h.evento }}</td></tr>
        <tr v-if="!msg.payload.hist.length"><td colspan="4" class="none">Sin eventos</td></tr>
      </tbody>
    </table>
  </div>
  <div v-else class="none">Esperando datos…</div>
</template>
<script>
export default {
  data () { return { meta: 10, nota: '' } },
  methods: {
    cmd (orden) { this.send({ topic: 'cmd', payload: orden }); this.nota = 'Enviado: ' + orden },
    guardarMeta () {
      if (!(this.meta >= 1 && this.meta <= 999)) { this.nota = 'La meta debe ser de 1 a 999'; return }
      this.send({ topic: 'meta', payload: this.meta }); this.nota = 'Meta enviada a D120'
    }
  }
}
</script>
<style scoped>
.iny{display:grid;gap:12px;font-size:14px}
.top{display:flex;flex-wrap:wrap;gap:6px}
.pill{font-family:monospace;font-size:12px;padding:3px 10px;border-radius:99px;border:1px solid #c9cec7}
.pill.ok{color:#17845A;border-color:#17845A}.pill.bad{color:#C8322B;border-color:#C8322B}.pill.warn{color:#B7790F;border-color:#B7790F}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.kpi{border-top:3px solid #D2D7D0;padding-top:4px}.kpi small{display:block;color:#5A655F}.kpi b{font-family:monospace;font-size:24px;font-weight:500}
.kpi.heat{border-top-color:#E0661A}.bar{height:6px;background:#E4E7E2;border-radius:3px;margin-top:4px}.bar i{display:block;height:6px;background:#E0661A;border-radius:3px}.kpi.good{border-top-color:#17845A}
.alarm{background:#C8322B;color:#fff;border-radius:6px;padding:7px 10px;font-weight:600;margin-bottom:4px}.alarm.info{background:#17845A}
.none{color:#5A655F}
.btns{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.btns button{border:0;border-radius:6px;padding:9px 14px;color:#fff;font-weight:600;cursor:pointer}
.g{background:#1E8A56}.r{background:#B8322B}.b{background:#2457D6}
.btns input{width:70px;padding:5px;border:1px solid #c9cec7;border-radius:6px}
.note{color:#5A655F;font-size:13px}
.io{display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;font-size:13px}
.led{display:inline-block;width:11px;height:11px;border-radius:50%;background:#BFC5BE;margin-right:6px;vertical-align:-1px}.led.on{background:#2BCB72;box-shadow:0 0 6px #2BCB72}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:4px 6px;border-bottom:1px solid #D2D7D0}
th{font-size:11px;text-transform:uppercase;color:#5A655F}
</style>"""
add({"id": "ui_panel", "type": "ui-template", "z": Z, "group": "g_panel", "page": "", "ui": "", "name": "panel principal",
     "order": 1, "width": "0", "height": "0", "head": "", "format": PANEL, "storeOutMessages": True, "passthru": False,
     "resendOnRefresh": True, "templateScope": "local", "className": "", "x": 610, "y": 460, "wires": [["fn_mando"]]})
add({"id": "ui_chart", "type": "ui-chart", "z": Z, "group": "g_temp", "name": "nivel tolva", "label": "Nivel de tolva (%), ultimos 2 min",
     "order": 1, "chartType": "line", "category": "topic", "categoryType": "msg", "xAxisLabel": "", "xAxisProperty": "",
     "xAxisPropertyType": "timestamp", "xAxisType": "time", "xAxisFormat": "", "xAxisFormatType": "auto", "xmin": "", "xmax": "",
     "yAxisLabel": "%", "yAxisProperty": "payload", "yAxisPropertyType": "msg", "ymin": "0", "ymax": "100", "bins": 10,
     "action": "append", "stackSeries": False, "pointShape": "false", "pointRadius": 4, "showLegend": True,
     "removeOlder": "2", "removeOlderUnit": "60", "removeOlderPoints": "", "colors": ["#E0661A", "#5A655F", "#2457D6", "#17845A", "#C8322B", "#B7790F", "#6B5BB8", "#1F3B66", "#999999"],
     "textColor": ["#666666"], "textColorDefault": True, "gridColor": ["#e5e5e5"], "gridColorDefault": True,
     "width": "12", "height": "6", "className": "", "interpolation": "linear", "x": 600, "y": 520, "wires": [[]]})

MANDO = r"""
// Botones de la pagina -> pulso en el PLC. INICIAR=M0, PARO=M1, RESET=M2 (1 y a los 0.3 s, 0)
if (msg.topic === 'meta') {
    const v = Math.round(Number(msg.payload));
    if (!(v >= 1 && v <= 999)) return null;
    return [{topic: 'D120', payload: v}, null];
}
const dev = {iniciar: 'M0', paro: 'M1', reset: 'M2'}[msg.payload];
if (!dev) return null;
return [{topic: dev, payload: true}, {topic: dev, payload: false}];
"""
add({"id": "fn_mando", "type": "function", "z": Z, "name": "orden -> pulso", "func": MANDO.strip(), "outputs": 2,
     "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 830, "y": 460, "wires": [["wr_plc"], ["dly_pulso"]]})
add({"id": "dly_pulso", "type": "delay", "z": Z, "name": "0.3 s", "pauseType": "delay", "timeout": "300", "timeoutUnits": "milliseconds",
     "rate": "1", "nbRateUnits": "1", "rateUnits": "second", "randomFirst": "1", "randomLast": "5", "randomUnits": "seconds",
     "drop": False, "allowrate": False, "outputs": 1, "x": 1010, "y": 500, "wires": [["wr_plc"]]})
add({"id": "wr_plc", "type": "MC Write", "z": Z, "name": "escribir en PLC", "topic": "", "connection": "cfg_plc",
     "data": "payload", "address": "topic", "addressType": "msg", "dataType": "msg", "errorHandling": "msg", "outputs": 1,
     "x": 1190, "y": 460, "wires": [[]]})

# ---------- reconexion (el nodo mcprotocol 1.2.1 no se reconecta solo) ----------
add({"id": "inj_recon", "type": "inject", "z": Z, "name": "cada 5 s", "props": [{"p": "payload"}], "repeat": "5",
     "crontab": "", "once": False, "onceDelay": "", "topic": "", "payload": "", "payloadType": "date",
     "x": 130, "y": 720, "wires": [["fn_recon"]]})
add({"id": "fn_recon", "type": "function", "z": Z, "name": "si no hay datos, reconectar",
     "func": "// Si en 3 s no llegan datos (PLC reiniciado, cable, socket colgado):\n// se cierra la conexion y se abre de nuevo 1 s despues.\nif (Date.now() - (flow.get('ultimaLectura') || 0) < 3000) return null;\nnode.status({fill: 'red', shape: 'ring', text: 'reconectando ' + new Date().toLocaleTimeString()});\nnode.send({topic: 'disconnect'});\nsetTimeout(() => node.send({topic: 'connect'}), 1000);\nreturn null;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 340, "y": 720, "wires": [["rd_0"]]})

# ---------- estado de la red (lo escribe el servicio autoplc) ----------
add({"id": "inj_red", "type": "inject", "z": Z, "name": "cada 5 s", "props": [{"p": "payload"}], "repeat": "5",
     "crontab": "", "once": True, "onceDelay": "2", "topic": "", "payload": "", "payloadType": "date",
     "x": 130, "y": 780, "wires": [["file_red"]]})
add({"id": "file_red", "type": "file in", "z": Z, "name": "/run/autoplc/estado.json", "filename": "/run/autoplc/estado.json",
     "filenameType": "str", "format": "utf8", "chunk": False, "sendError": False, "encoding": "utf8", "allProps": False,
     "x": 340, "y": 780, "wires": [["json_red"]]})
add({"id": "json_red", "type": "json", "z": Z, "name": "", "property": "payload", "action": "obj", "pretty": False,
     "x": 530, "y": 780, "wires": [["fn_red"]]})
add({"id": "fn_red", "type": "function", "z": Z, "name": "guardar red",
     "func": "flow.set('red', msg.payload);\nflow.set('redHora', Date.now());\nnode.status({fill: msg.payload.plc_ip ? 'green' : 'yellow', shape: 'dot', text: msg.payload.estado});\nreturn null;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 690, "y": 780, "wires": [[]]})

# ---------- API JSON (para revisar o usar desde otra app) ----------
add({"id": "http_in", "type": "http in", "z": Z, "name": "", "url": "/api/estado", "method": "get", "upload": False,
     "swaggerDoc": "", "x": 150, "y": 640, "wires": [["fn_api"]]})
add({"id": "fn_api", "type": "function", "z": Z, "name": "estado en JSON", "func": "msg.payload = flow.get('estado') || {};\nreturn msg;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 360, "y": 640, "wires": [["http_out"]]})
add({"id": "http_out", "type": "http response", "z": Z, "name": "", "statusCode": "", "headers": {}, "x": 560, "y": 640, "wires": []})

for c, (t, x, y) in enumerate([
        ("1) LECTURA: cada 0.5 s se piden los registros del FX5U por SLMP y se guardan en variables del flujo", 400, 20),
        ("2) ARMADO: se juntan en un objeto 'estado', se detectan alarmas nuevas y se mandan al tablero", 380, 480),
        ("4) RECONEXION: si en 3 s no llegan datos, pide reconectar (cable desconectado, PLC apagado)", 380, 690),
        ("5) RED: el servicio autoplc encuentra al PLC y deja aqui su IP y los equipos del cable", 420, 750),
        ("3) MANDO: los botones del tablero mandan un pulso de 0.3 s a M0/M1/M2 o escriben la meta en D120", 940, 420)]):
    add({"id": f"cm_{c}", "type": "comment", "z": Z, "name": t, "info": "", "x": x, "y": y, "wires": []})

json.dump(nodes, open(OUT, "w"), indent=1, ensure_ascii=False)
print("ok", OUT, len(nodes), "nodos")
