# Código que genera los archivos

Python 3 con: `trimesh manifold3d shapely ezdxf matplotlib numpy`. Las vistas 3D usan Node + Playwright (`shot.js`) y three.js r128.

Corre cada script **desde su carpeta** y en este orden:

| Paso | Carpeta | Script | Genera |
|---|---|---|---|
| 1 | `molde` | `mold.py` | Placas A y B del molde (STL, SVG) desde `01_pieza/pua_triangular.stl` |
| 2 | `molde` | `build.py` | Ensamble con expulsión (`parts.pkl`, `info_expulsion.json`) |
| 3 | `molde` | `gen.py` | G-code del molde (`GCODE/`) |
| 4 | `maquina_metal` | `geo4.py` → `chk.py` → `vdata.py` → `shot.js` → `pdf4.py` | Máquina de metal, revisión de choques, visor y PDF |
| 5 | `prueba_madera` | `geo_m.py` → `chk_m.py` → `wood_cnc.py` → `pdf_wood.py` | Versión en madera, SVG/DXF/G-code y PDF |

`despiece.py` y `despiece_m.py` tienen la lista de piezas, procesos y tornillería (los usan el PDF y el visor).
`herramientas/simnc.py` dibuja los recorridos de un G-code para revisarlo.
