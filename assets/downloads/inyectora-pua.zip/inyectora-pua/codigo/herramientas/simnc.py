import re,sys,math,glob,matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fs=sorted(glob.glob('wood_out/GCODE/*_22mm.nc'))
fig,axs=plt.subplots(2,2,figsize=(16,8));axs=axs.ravel()
for a,f in zip(axs,fs):
    x=y=0;z=5;segs=[];mn=[1e9,1e9,1e9];mx=[-1e9,-1e9,-1e9]
    for l in open(f):
        if l.startswith('('): continue
        c=dict(re.findall(r'([XYZIJ])(-?[\d.]+)',l)); 
        nx=float(c.get('X',x)); ny=float(c.get('Y',y)); nz=float(c.get('Z',z))
        if l.startswith('G2 '):
            i,j=float(c['I']),float(c['J']); cx,cy=x+i,y+j; r=math.hypot(i,j)
            pts=[(cx+r*math.cos(t),cy+r*math.sin(t)) for t in [2*math.pi*k/24 for k in range(25)]]
            for p,q in zip(pts,pts[1:]): segs.append((p,q,nz))
        elif l.startswith('G1 ') and nz<0: segs.append(((x,y),(nx,ny),nz))
        if nz<0:
            for k,v in enumerate((nx,ny,nz)): mn[k]=min(mn[k],v); mx[k]=max(mx[k],v)
        x,y,z=nx,ny,nz
    for p,q,zz in segs[::3]: a.plot([p[0],q[0]],[p[1],q[1]],color=plt.cm.viridis(-zz/16),lw=.4)
    a.set_aspect('equal');a.set_title(f.split('/')[-1]+f"\nX {mn[0]:.1f}..{mx[0]:.1f}  Y {mn[1]:.1f}..{mx[1]:.1f}  Zmin {mn[2]:.1f}",fontsize=8)
plt.tight_layout();plt.savefig('sim_wood.png',dpi=70)
