import re,sys,numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union
def load(f):
    s=open(f).read(); out={}
    for pid,d in re.findall(r'<path id="([^"]+)"[^>]*?d="([^"]+)"',s,re.S)+[(b,a) for a,b in re.findall(r'<path d="([^"]+)"[^>]*?id="([^"]+)"',s,re.S)]:
        rings=[]
        for sub in re.split(r'[Mm]',d)[1:]:
            nums=list(map(float,re.findall(r'-?\d+\.?\d*',sub)))
            pts=list(zip(nums[0::2],nums[1::2]))
            if len(pts)>=3: rings.append(Polygon(pts).buffer(0))
        g=None
        for r in rings: g=r if g is None else g.symmetric_difference(r)
        out[pid]=g
    return out
for f in sys.argv[1:]:
    G=load(f); g=G['GRABADO_dibujo']; c=G['CORTE_contorno_atravesar']
    print(f.split('/')[-1],'contorno',np.round(c.bounds,1),'area grabado',round(g.area,1))
    for d in (3.175,2.0,1.0,0.5,0.3):
        r=d/2; reach=g.buffer(-r).buffer(r)
        print(f'  fresa {d} mm: alcanza {reach.area/g.area*100:.0f}% del negro')
    gaps=c.buffer(-0.01).difference(g)  # blanco dentro
    for d in (1.0,0.5,0.3):
        lost=gaps.area-gaps.buffer(-d/2).buffer(d/2).area
    hole=G['CORTE_agujero_argolla']; print('  agujero argolla',np.round(hole.bounds,1), 'diam', round(hole.bounds[2]-hole.bounds[0],2))
    # margin between drawing and contour
    print('  distancia minima dibujo-contorno', round(g.distance(c.exterior),2))
