import json,math,numpy as np,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Polygon as Pg,FancyBboxPatch
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.image as mpimg
exec(open('geo3.py').read().split('# ---------------- helpers de malla')[0])
INK='#1d2329';MUT='#5d6873';RED='#c0392b';BLUE='#1f6fb2'
MC={'U1':'#5b6670','U2':'#2a9d4f','T6':'#2f6db5','P5':'#8a4fd1','A':'#e2611b','L25':'#5fae73','buy':'#9aa3ab'}
plt.rcParams['font.family']='DejaVu Sans'
def page(title,sub=None,size=(11,8.5)):
    f=plt.figure(figsize=size); f.text(.04,.955,title,fontsize=17,weight='bold',color=INK)
    if sub: f.text(.04,.925,sub,fontsize=9.5,color=MUT)
    return f
def foot(f,n): f.text(.96,.02,f'Inyectora con tornillo directo · hoja {n}',ha='right',fontsize=7,color=MUT)
# ---------- placas en vista (h,v) mm desde esquina inferior izquierda vista de frente de la máquina
def fixed_view():
    W=H=PL; hv=lambda y,z:(-y+W/2,z-Z0)
    new=[(*hv(*p),12,'eje 12 mm → broca 12 (entra justo)') for p in BARS]+[(*hv(*p),5.5,'M5 al molde B → broca 5.5') for p in B_MOUNT]
    return dict(name='PLACA FIJA',W=W,H=H,new=new,old=[],stock='Placa trapecio 6 mm (130 × 130).',
      face='Vista desde el FRENTE de la máquina.',
      notes=['Se suelda al ángulo delantero (cordón por atrás y a los lados), abajo a ras de la base.',
             'El molde B se atornilla desde el frente: 4 tornillos M5 × 16.',
             'Barrena los ejes con fija + móvil + trasera prensadas juntas (la móvil después se agranda a 16).'])
def rear_view():
    W=H=PL; hv=lambda y,z:(-y+W/2,z-Z0)
    new=[(*hv(*p),12,'eje 12 mm') for p in BARS]+[(*hv(0,ZC),14,'tornillo ½" (gira libre) → 14')]+[(*hv(*p),8.5,'varilla expulsora 5/16" → 8.5') for p in KO]+[(*hv(*p),6.5,'poste motor M6 → 6.5') for p in STAND]
    old=[(*hv(y,z),d,t) for y,z,d,t in OLD_REAR]
    return dict(name='PLACA TRASERA',W=W,H=H,new=new,old=old,stock='Fondo de tu 2º canal U sin cejas: pedazo de 145 a 275 mm (lado de las ranuras).',
      face='Vista desde el FRENTE de la máquina (el motor queda detrás).',
      notes=['Los 2 ejes de la izquierda caen en los Ø10 viejos: solo agrándalos a 12.',
             'Se suelda a las 2 escuadras traseras, abajo a ras de la base.',
             'Adelante: rondana de bronce + tuerca. Atrás: rondana de bronce + tuerca + engrane + contratuerca.'])
def moving_view():
    W,H=MW,MH; hv=lambda y,z:(-y+W/2,z-(ZC-MH/2))
    new=[(*hv(*p),16,'paso del eje (no toca) → 16') for p in BARS]+[(*hv(*p),4.5,'M4 soporte LM12UU → 4.5') for p in HOLD_BOLTS]+[(*hv(*p),9,'expulsora → 9') for p in KO]+[(*hv(*p),5.5,'M5 al molde → 5.5') for p in A_MOUNT]+[(*hv(*p),6.6,'¼" soporte → 6.6') for p in BR_BOLTS]+[(*hv(0,ZC),14,'paso del tornillo → 14')]
    return dict(name='PLACA MÓVIL',W=W,H=H,new=new,old=[],stock='Lámina 2.5 mm (de la parte sin agujeros).',
      face='Vista desde el FRENTE de la máquina (cara del molde A hacia ti).',
      notes=['Los 4 soportes impresos de LM12UU van atrás, con 2 tornillos M4 cada uno (tuerca de seguridad del lado del molde).',
             'Queda prensada entre el molde A (adelante) y el soporte de tuerca (atrás): por eso basta 2.5 mm.',
             'El molde A se fija con 4 M5 × 12 desde atrás (puntos ya marcados en tu G-code M1).'])
def bracket_view():
    W,H=BR_W,BR_H; hv=lambda y,z:(-y+W/2,z-(ZC-BR_H/2))
    new=[(*hv(*p),6.6,'¼"') for p in BR_BOLTS]+[(*hv(0,ZC),14,'tornillo → 14')]+[(*hv(*p),9,'expulsora') for p in KO]
    return dict(name='SOPORTE DE TUERCA',W=W,H=H,new=new,old=[],stock='Placa 5 mm #1',face='',notes=[])
def motor_view():
    W=MPL_W;H=MPL_Z[1]-MPL_Z[0]; hv=lambda y,z:(-y+W/2,z-MPL_Z[0])
    new=[(*hv(*p),6.5,'poste M6') for p in STAND]
    slots=[(hv(0,MOT_Z-SLOT),hv(0,MOT_Z+SLOT),23,'ranura Ø23 (centro motor)')]+[(hv(sy*15.5,MOT_Z+sz*15.5-SLOT),hv(sy*15.5,MOT_Z+sz*15.5+SLOT),3.4,'M3') for sy in(-1,1) for sz in(-1,1)]
    return dict(name='PLACA DEL MOTOR',W=W,H=H,new=new,old=[],slots=slots,stock='Placa 5 mm #1',face='',notes=[])
def angF_h():   # pata horizontal del ángulo delantero vista desde arriba: h = Y desde la izquierda (visto de frente), v = distancia desde la punta
    W,H=PL,LA; new=[(-y+W/2, x-XA_F[0],10.0,'⅜" a la base (agujeros que ya tiene)') for x,y in BASE_F]
    return dict(name='ÁNGULO DELANTERO — pata de abajo',W=W,H=H,new=new,old=[],stock='',face='',notes=[])
def angF_v():
    W,H=PL,LA; new=[(-y+W/2,z-Z0,12,'eje 12 de abajo') for y,z in LOWBARS]
    return dict(name='ÁNGULO DELANTERO — pata parada',W=W,H=H,new=new,old=[],stock='',face='',notes=[])
def angR_h():
    W,H=RA_Y[1]-RA_Y[0],LA; new=[(y-RA_Y[0],x-XR1,10.0,'⅜"') for x,y in BASE_R if y>0]
    return dict(name='TRASERA — pata abajo (×2)',W=W,H=H,new=new,old=[],stock='',face='',notes=[])
def angR_v():
    W,H=RA_Y[1]-RA_Y[0],LA; new=[(y-RA_Y[0],z-Z0,12,'eje 12 de abajo') for y,z in LOWBARS if y>0]
    return dict(name='TRASERA — pata parada (×2)',W=W,H=H,new=new,old=[],stock='',face='',notes=[])
def draw_plate(a,V,dims=True,fs=7,label=True):
    W,H=V['W'],V['H']
    a.add_patch(Rectangle((0,0),W,H,fc='#f4f6f8',ec=INK,lw=1.3))
    for h,v,d,t in V['old']:
        if t=='o': a.add_patch(Circle((h,v),d/2,fc='none',ec='#9aa3ab',lw=.8,ls='--'))
        else:
            x1=0 if h<W/2 else W
            a.add_patch(Rectangle((min(h,x1),v-d/2),abs(x1-h),d,fc='none',ec='#9aa3ab',lw=.8,ls='--'))
    for h,v,d,t in V['new']:
        a.add_patch(Circle((h,v),d/2,fc='white',ec=RED,lw=1.2)); a.plot([h-d/2-2,h+d/2+2],[v,v],color=RED,lw=.4);a.plot([h,h],[v-d/2-2,v+d/2+2],color=RED,lw=.4)
    for p0,p1,w,t in V.get('slots',[]):
        from shapely.geometry import LineString
        g=LineString([p0,p1]).buffer(w/2,24); a.add_patch(Pg(np.array(g.exterior.coords),fc='white',ec=RED,lw=1.2))
    if dims:
        hs=sorted({round(h,1) for h,v,d,t in V['new']}|{round((p0[0]),1) for p0,p1,w,t in V.get('slots',[])})
        vs=sorted({round(v,1) for h,v,d,t in V['new']}|{round(p0[1]+w/2*0,1) for p0,p1,w,t in V.get('slots',[])})
        for h in hs: a.text(h,-4,f'{h:g}',ha='center',va='top',fontsize=fs,color=BLUE,rotation=90)
        for v in vs: a.text(-3,v,f'{v:g}',ha='right',va='center',fontsize=fs,color=BLUE)
        a.text(W/2,H+3,f'{W:g} mm',ha='center',fontsize=fs+1); a.text(W+3,H/2,f'{H:g} mm',va='center',fontsize=fs+1,rotation=90)
    a.set_aspect('equal'); a.axis('off')
def hole_table(V):
    rows={}
    for h,v,d,t in V['new']:
        rows.setdefault((d,t),[]).append(f'({h:g}, {v:g})')
    return [(f'Ø{d:g}',t,len(c),'  '.join(c)) for (d,t),c in rows.items()]
VIEWS=[fixed_view(),rear_view(),moving_view(),bracket_view(),motor_view(),angF_h(),angF_v(),angR_h(),angR_v()]
# ---------- cálculos
AREA=680+75   # pieza + canal mm²
LEAD=25.4/13; ETA=0.30; TM_=0.30
def Fz(i,T=TM_): return 2*math.pi*T*i*ETA/(LEAD/1000)
with PdfPages('Inyectora_planos_y_cortes_v3.pdf') as pdf:
    # 1 portada
    f=page('Inyectora con tornillo directo — diseño completo con TU material','Igual que el boceto 1: escuadras de ángulo abajo, tornillo directo. Todo lo de color sale de tus piezas; lo gris se compra.')
    for i,(im,t,ax) in enumerate([('v_iso.png','Cerrado',[.02,.33,.48,.58]),('v_iso_ab.png','Abierto 25 mm (expulsa la pieza)',[.5,.33,.48,.58])]):
        a=f.add_axes(ax);a.imshow(mpimg.imread(im)[60:1000,150:1450]);a.axis('off');a.set_title(t,fontsize=11,loc='left',weight='bold')
    leg=[(MC['U1'],'Base: canal U #1 completo (cejas abajo)'),(MC['T6'],'Placa fija: trapecio 6 mm'),(MC['L25'],'Placa móvil: lámina 2.5 mm'),(MC['U2'],'Placa trasera: fondo del 2º canal, sin cejas'),(MC['A'],'Escuadras: ángulo 6.5 cm (1 delantera + 2 traseras)'),(MC['P5'],'Soporte de tuerca y placa del motor: placa 5 mm'),
         ('#c9cfd4','Comprar: 4 ejes 12 mm, 4 baleros LM12UU, cople, tornillería'),('#f2b705','Varillas expulsoras 5/16" (sacan la pieza al abrir)'),('#e9dcb5','Engrane grande + tu piñón blanco (reducción)'),('#13a3b4','4 soportes impresos para los LM12UU')]
    for i,(c,t) in enumerate(leg):
        y=.29-i*.031; f.patches.append(Rectangle((.05,y-.008),.018,.022,transform=f.transFigure,fc=c,ec=INK,lw=.5)); f.text(.075,y+.003,t,fontsize=9.5,va='center')
    spec=[('Carrera de apertura','25 mm'),('Expulsión','6.35 mm (automática al abrir)'),('Alto del centro del molde',f'{ZC:g} mm sobre la mesa'),('Largo total',f'{X_MOT[1]:.0f} mm (motor sale {X_MOT[1]-LU:.0f} mm)'),
          ('Fuerza de cierre con motor',f'≈ {Fz(4)/9.81:.0f} kgf con reducción 4:1'),('Con reducción 5:1',f'≈ {Fz(5)/9.81:.0f} kgf'),('Te sobra','1 m de ángulo y más')]
    for i,(k,v) in enumerate(spec):
        f.text(.56,.27-i*.034,k,fontsize=9.5,color=MUT); f.text(.76,.27-i*.034,v,fontsize=9.5,weight='bold')
    foot(f,1); pdf.savefig(f); plt.close(f)
    # 2 plano de corte
    f=page('Plano de corte — de qué pedazo sale cada pieza','Línea punteada = tu material. Color = pieza. Deja ~2 mm para el disco. Lo que queda en beige es sobrante que guardas.')
    def stock(ax,w,h,title,poly=None):
        if poly is not None: ax.add_patch(Pg(poly,fc='#ece7df',ec=INK,lw=1.1,ls='--'))
        else: ax.add_patch(Rectangle((0,0),w,h,fc='#ece7df',ec=INK,lw=1.1,ls='--'))
        ax.set_title(title,fontsize=9.5,weight='bold',loc='left'); ax.set_aspect('equal'); ax.axis('off'); ax.set_xlim(-10,w+10); ax.set_ylim(-16,h+8)
        ax.text(w/2,-11,f'{w:g} mm',ha='center',fontsize=7,color=MUT); ax.text(-7,h/2,f'{h:g} mm',rotation=90,va='center',fontsize=7,color=MUT)
    def part(ax,x,y,w,h,lab,c,fs=7.5):
        ax.add_patch(Rectangle((x,y),w,h,fc=c,ec=INK,alpha=.9)); ax.text(x+w/2,y+h/2,lab,ha='center',va='center',fontsize=fs,color='white',weight='bold')
    ax=f.add_axes([.02,.53,.2,.36]); stock(ax,155,250,'1) Trapecio 6 mm',poly=[(0,25),(25,0),(155,0),(155,250),(25,250),(0,225)])
    part(ax,155-PL-2,250-PL-2,PL,PL,'PLACA FIJA\n130 × 130',MC['T6'],8); ax.text(80,55,'sobrante\n~155 × 115',ha='center',fontsize=7,color=MUT)
    ax=f.add_axes([.24,.53,.17,.36]); stock(ax,140,310,'2) Lámina 2.5 mm')
    for yy in (35,95,175,280): ax.add_patch(Circle((132,yy),7,fc='white',ec=MUT))
    part(ax,2,310-MH-2,MW,MH,'PLACA\nMÓVIL\n128 × 128',MC['L25'],8); ax.text(65,90,'sobrante\n130 × 175',ha='center',fontsize=7,color=MUT)
    ax=f.add_axes([.44,.53,.33,.36]); stock(ax,280,140,'3) 2º canal U: corta de 145 a 275 y quítale las cejas')
    ax.add_patch(Rectangle((0,0),280,5,fc='#d8d2c7',ec=MUT,lw=.6)); ax.add_patch(Rectangle((0,135),280,5,fc='#d8d2c7',ec=MUT,lw=.6))
    part(ax,RW0,5,PL,PL,'PLACA\nTRASERA\n130 × 130',MC['U2'],8)
    for x,y,d,t in OLD_BASE:
        if RW0<x<RW0+PL and t=='o': ax.add_patch(Circle((x,y+70),d/2,fc='none',ec='white',lw=.8))
    ax.text(70,70,'sobrante\n(medio canal\ncon cejas)',ha='center',fontsize=7,color=MUT); ax.text(140,-2,'cejas = tiras de arriba y abajo',ha='center',fontsize=6.5,color=MUT,va='top')
    ax=f.add_axes([.8,.53,.18,.36]); stock(ax,100,200,'4) Placa 5 mm #1')
    part(ax,2,2,MPL_W,MPL_Z[1]-MPL_Z[0],'PLACA\nMOTOR\n76 × 60',MC['P5'],7.5); part(ax,2,66,BR_W,BR_H,'SOPORTE\nTUERCA\n54 × 54',MC['P5'],7)
    ax.text(50,165,'sobrante',ha='center',fontsize=7,color=MUT)
    ax=f.add_axes([.02,.30,.96,.16]); L=1219
    ax.add_patch(Rectangle((0,0),L,65,fc='#ece7df',ec=INK,ls='--')); x=0
    for w,lab in [(PL,'DELANTERA 130'),(40,'TRAS.\n40'),(40,'TRAS.\n40')]:
        part(ax,x,0,w,65,lab,MC['A'],7.5); x+=w+3
    ax.text(x+(L-x)/2,32,f'sobrante ≈ {L-x:.0f} mm (te queda para la torre del inyector)',ha='center',fontsize=8.5,color=MUT)
    ax.set_title('5) Ángulo 6.5 × 6.5 cm × 1 cm (4 pies) — 3 cortes',fontsize=9.5,weight='bold',loc='left');ax.set_xlim(-10,L+10);ax.set_ylim(-5,75);ax.set_aspect('equal');ax.axis('off')
    ax=f.add_axes([.04,.03,.92,.24]); ax.axis('off')
    txt=[('Canal U #1','BASE, sin cortar. Usa 6 de sus agujeros y lleva 2 nuevos (hoja 8).'),('Placa 5 mm #2','no se usa (repuesto)'),
         ('Tu varilla roscada ½"',f'cortar a {X_RODEND-X_RODTIP:.0f} mm'),('Ejes cromados 12 mm (comprar 70 cm)',f'2 de {X_ROD_UP[1]-X_ROD_UP[0]:.0f} y 2 de {X_ROD_LO[1]-X_ROD_LO[0]:.0f} mm, machuelo M6 en las puntas'),
         ('Varilla roscada 5/16" (comprar)',f'2 de {XR1+9-X_KO_TIP:.0f} mm (expulsoras)')]
    for i,(k,v) in enumerate(txt): ax.text(0 if i<3 else .5,.85-(i%3)*.32,k,fontsize=9.5,weight='bold',transform=ax.transAxes); ax.text(0 if i<3 else .5,.85-(i%3)*.32-.14,v,fontsize=9,color=MUT,transform=ax.transAxes)
    foot(f,2); pdf.savefig(f); plt.close(f)
    # 3-6 planos de placas
    n=3
    for V in VIEWS[:3]:
        f=page(f'{V["name"]} — barrenos',V['stock']+'.  '+V['face'])
        a=f.add_axes([.05,.2,.5,.66]); draw_plate(a,V); a.set_xlim(-14,V['W']+12); a.set_ylim(-16,V['H']+10)
        f.text(.6,.85,'Medidas en mm desde la ESQUINA INFERIOR IZQUIERDA',fontsize=9.5,weight='bold')
        f.text(.6,.82,'rojo = barreno nuevo   ·   gris punteado = agujero que ya trae (aprox.)',fontsize=8.5,color=MUT)
        y=.77
        for d,t,c,coords in hole_table(V):
            f.text(.6,y,f'{d}  × {c}   {t}',fontsize=9,weight='bold'); y-=.025
            for k in range(0,len(coords),60): f.text(.62,y,coords[k:k+60],fontsize=7.5,color=MUT); y-=.022
            y-=.008
        y-=.02
        for t in V['notes']: f.text(.6,y,'• '+t,fontsize=8.5,wrap=True); y-=.06
        foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    f=page('SOPORTE DE TUERCA y PLACA DEL MOTOR (placa 5 mm #1)','Vistas desde el frente de la máquina. Medidas desde la esquina inferior izquierda.')
    a=f.add_axes([.05,.3,.3,.5]); draw_plate(a,VIEWS[3]); a.set_xlim(-14,BR_W+12); a.set_ylim(-16,BR_H+10); a.set_title('Soporte de tuerca 54 × 54',fontsize=10,weight='bold')
    a=f.add_axes([.4,.3,.5,.5]); draw_plate(a,VIEWS[4]); a.set_xlim(-14,MPL_W+12); a.set_ylim(-16,MPL_Z[1]-MPL_Z[0]+10); a.set_title('Placa del motor 76 × 60',fontsize=10,weight='bold')
    notes=['SOPORTE: el cople ½"×1¾" se suelda centrado sobre el agujero de 14.',' Truco: enrosca el cople en tu varilla, pasa la varilla por el soporte','  y la placa móvil, y suelda así para que quede derecho. Puntea en','  cruz y deja enfriar. Se atornilla a la placa móvil con 4 tornillos ¼".',
           '','PLACA MOTOR: va detrás de la placa trasera, separada 25 mm','  con 4 tornillos M6 × 50 y tubitos de 25 mm.',' Las ranuras dejan subir/bajar el motor ±5 mm para que tu piñón',f'  engrane con el grande (distancia entre centros {GEAR_R+PIN_R-SLOT:g}–{GEAR_R+PIN_R+SLOT:g} mm).']
    for i,t in enumerate(notes): f.text(.05+.47*(i>=5),.17-(i-5*(i>=5))*.032,t,fontsize=8.6)
    foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    f=page('ESCUADRAS de ángulo 6.5 × 6.5 × 1 cm','Medidas en mm. Pata de abajo vista desde arriba (abajo del dibujo = punta de la pata). Pata parada vista desde el frente.')
    for V,ax_ in [(VIEWS[5],[.04,.5,.42,.36]),(VIEWS[6],[.52,.5,.42,.36]),(VIEWS[7],[.08,.08,.2,.34]),(VIEWS[8],[.36,.08,.2,.34])]:
        a=f.add_axes(ax_); draw_plate(a,V); a.set_xlim(-14,V['W']+12); a.set_ylim(-16,V['H']+10); a.set_title(V['name'],fontsize=9,weight='bold')
    nt=['DELANTERA (130): la pata de abajo va al frente y sale 10 mm','  de la base; sus 4 agujeros caen en los Ø10 que ya tiene tu','  base. La pata parada se suelda al frente de la placa fija y la','  atraviesan los 2 ejes de abajo.','',
        'TRASERAS (2 de 40): pata de abajo hacia atrás, hasta el final','  de la base. La pata parada se suelda atrás de la placa trasera.','  Van a los lados (de 25 a 65 mm del centro) para dejar libre','  el engrane y el motor en medio.']
    for i,t in enumerate(nt): f.text(.6,.4-i*.032,t,fontsize=8.6)
    foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    # base
    f=page('BASE — canal U #1 (cejas hacia abajo)','Solo 2 barrenos nuevos. Las escuadras se atornillan en agujeros que ya tiene.')
    a=f.add_axes([.05,.3,.9,.55])
    a.add_patch(Rectangle((0,0),LU,WU,fc='#f4f6f8',ec=INK,lw=1.3))
    a.add_patch(Rectangle((XA_F[0],70-PL/2),LA,PL,fc=MC['A'],alpha=.22,ec=MC['A'])); a.text(15,70,'escuadra\ndelantera',ha='center',va='center',fontsize=7.5)
    for s_ in(-1,1): a.add_patch(Rectangle((XR1,70+min(s_*RA_Y[0],s_*RA_Y[1])),LA,RA_Y[1]-RA_Y[0],fc=MC['A'],alpha=.22,ec=MC['A']))
    a.text(XR1+LA/2,70,'engrane\ny motor',ha='center',va='center',fontsize=7,color=MUT)
    a.add_patch(Rectangle((XF0,70-PL/2),6,PL,fc=MC['T6'],alpha=.5)); a.add_patch(Rectangle((XR,70-PL/2),TU,PL,fc=MC['U2'],alpha=.5))
    for x,y,d,t in OLD_BASE:
        used=(x,y) in [(px,py) for px,py in BASE_F+BASE_R]
        if t=='o': a.add_patch(Circle((x,y+70),d/2,fc='#ffd6cc' if used else 'none',ec=RED if used else '#9aa3ab',lw=1.2 if used else .8,ls='-' if used else '--'))
        else: a.add_patch(Rectangle((x,y+65),25,10,fc='none',ec='#9aa3ab',ls='--'))
    for x,y in BASE_R:
        if x==247: a.add_patch(Circle((x,y+70),5,fc='white',ec=RED,lw=1.4)); a.text(x,y+70+(8 if y>0 else -11),'nuevo',ha='center',fontsize=7,color=RED)
    for x in (XH_F,247,260): a.text(x,-7,f'{x:g}',ha='center',fontsize=8,color=BLUE)
    for y in(-46,-38,-23,23,38,46): a.text(-14,y+70,f'{y+70:g}',ha='right',va='center',fontsize=7.5,color=BLUE)
    a.annotate('',xy=(0,WU+8),xytext=(LU,WU+8),arrowprops=dict(arrowstyle='<->'));a.text(LU/2,WU+10,'280 (frente = izquierda)',ha='center',fontsize=8)
    a.set_xlim(-25,LU+5);a.set_ylim(-14,WU+16);a.set_aspect('equal');a.axis('off')
    for i,t in enumerate(['Rojo = agujeros que se usan: 4 en la columna de 20 mm (escuadra delantera) y 2 en la de 260 mm (escuadras traseras).',
        'Nuevos: 2 barrenos Ø10 a 247 mm del frente y a 32 / 108 mm del borde (uno por escuadra trasera).',
        'Tornillos ⅜" × 1½" con tuerca y rondana abajo (hay 30 mm de hueco bajo la base por las cejas).',
        'Medidas de agujeros viejos tomadas de tus fotos: confírmalas con la plantilla de la base que te mandé antes.']):
        f.text(.05,.24-i*.04,'• '+t,fontsize=9)
    foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    # TORNILLERÍA POR UNIÓN
    import textwrap
    D_={}; exec(open('despiece.py').read(),D_); PARTS_,JOINTS_=D_['PARTS'],D_['JOINTS']
    f=page('Tornillería por unión — qué tornillo va en cada lugar','Allen = cabeza cilíndrica con hexágono por dentro. Hexagonal = cabeza de seis caras por fuera. U1…U13 aparecen en el despiece.')
    cols=[.04,.08,.33,.6,.83,.88]; y=.86
    for x,t in zip(cols,['#','Qué une','Tornillo','Tuerca / rondana','Cant.','Herramienta']): f.text(x,y,t,weight='bold',fontsize=9)
    for j in JOINTS_:
        y-=.056
        for x,t,w in zip(cols,j,[6,40,44,38,6,14]): f.text(x,y,'\n'.join(textwrap.wrap(str(t),w)),fontsize=7.8,va='top')
        f.add_artist(plt.Line2D([.04,.97],[y+.012,y+.012],color='#dde2e6',lw=.6,transform=f.transFigure))
    foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    f=page('Lista de compras','Todo lo que no sale de tu material.')
    bom=[('Eje lineal cromado 12 mm (h6)','70 cm',f'4 ejes: 2 × {X_ROD_UP[1]-X_ROD_UP[0]:.0f} y 2 × {X_ROD_LO[1]-X_ROD_LO[0]:.0f} mm'),('Balero lineal LM12UU','4','12 × 21 × 30 mm'),
         ('Filamento PETG o ASA','~60 g','4 soportes de balero (y el engrane si lo imprimes)'),('Cople ½"-13 × 1¾" (acero negro)','1','tuerca larga del cierre'),
         ('Tuerca ½"-13','3','tornillo de cierre'),('Rondana de bronce ½"','2','placa trasera'),('Varilla roscada 5/16"-18 + 4 tuercas + 4 rondanas','25 cm','expulsoras'),
         ('Hexagonal ⅜"-16 × 1¼" + tuerca + rondanas','8','escuadras a la base'),('Allen M6 × 16 + rondana ancha + presión','8','puntas de los ejes'),
         ('Allen M6 × 16 + tuerca M6','4','soporte de tuerca'),('Allen M6 × 40 + tuerca + tubo 25 mm','4','postes del motor'),
         ('Allen M5 × 10 / × 14 / × 35','4 / 4 / 4','molde A, molde B, armado del molde'),('Allen M4 × 12 + tuerca de seguridad','8','soportes LM12UU'),
         ('Allen M3 × 16 + tuerca / M3 × 10 / M3 × 8','4 / 4 / 4','abrazaderas, motor, placas expulsoras'),('Allen M4 × 30 / M6 × 30 rosca parcial','5 / 4','se tornean: botadores y retornos'),
         ('Grasa de alta temperatura + aceite ligero','—','botadores, rosca, ejes')]
    y=.86
    for a_,b_,c_ in bom:
        y-=.044; f.text(.05,y,a_,fontsize=9.3); f.text(.5,y,b_,fontsize=9.3); f.text(.6,y,c_,fontsize=8.6,color=MUT)
        f.add_artist(plt.Line2D([.05,.95],[y-.013,y-.013],color='#dde2e6',lw=.6,transform=f.transFigure))
    foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    per=4; chunks=[PARTS_[i:i+per] for i in range(0,len(PARTS_),per)]
    for ch in chunks:
        f=page('Despiece — de dónde sale cada pieza y qué se le hace','Cada ficha: origen, medidas, proceso en orden y tornillería.')
        for k,p in enumerate(ch):
            x0=.04+(k%2)*.48; y0=.88-(k//2)*.43
            f.text(x0,y0,f"{p['id']}  {p['nombre']}  × {p['cant']}",fontsize=10.5,weight='bold',color=INK)
            yy=y0-.028
            for ln in textwrap.wrap('Sale de: '+p['origen'],88): f.text(x0,yy,ln,fontsize=8,color=BLUE); yy-=.022
            f.text(x0,yy,'Medidas: '+p['medidas'],fontsize=8); yy-=.03
            for i,t in enumerate(p['proceso']):
                for ln in textwrap.wrap(f'{i+1}. '+t,94): f.text(x0,yy,ln,fontsize=7.3); yy-=.0185
            yy-=.006
            for t in p['tornilleria']:
                for ln in textwrap.wrap('▸ '+t,94): f.text(x0,yy,ln,fontsize=7.3,color='#8a5200'); yy-=.0185
        foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    # armado + fuerza
    f=page('Armado, ajuste y fuerza de cierre')
    steps=['1. Corta: fija del trapecio (130×130), móvil de la lámina 2.5 (124×118), trasera del 2º canal (de 145 a 275, sin cejas),',
     '    las 3 escuadras de ángulo (130, 40, 40) y las 2 piezas de la placa 5 mm.',
     '2. Pega las plantillas 1:1 (últimas hojas), marca con punzón y barrena primero con broca chica (⅛").',
     '3. Prensa juntas fija + móvil + trasera, alineadas abajo y al centro, y barrena los 4 ejes con broca de 12 de una vez.',
     '4. Barrena las escuadras (hoja 7) y atorníllalas a la base con ⅜".',
     '5. Mete los ejes y atorníllalos (M6) con la fija y la trasera paradas sobre la base contra sus escuadras.',
     f'    Ajusta {XR-XF:.1f} mm entre la cara de atrás de la fija (donde va el molde B) y el frente de la trasera; escuadra y',
     '    entonces SUELDA las placas a sus escuadras (puntos primero, revisa escuadra, luego cordón).',
     '6. Baleros en sus soportes impresos y soportes a la móvil: debe correr suave. Si se traba, afloja los M4 y reacomoda.',
     '7. Suelda el cople al soporte (con la varilla puesta), atornilla el soporte a la móvil.',
     '8. Varilla: tuerca + rondana bronce adelante de la trasera; rondana bronce + tuerca + engrane + contratuerca atrás.',
     '    Aprieta para que la varilla gire sin juego. Engrasa.',
     '9. Molde B a la fija (M5), molde A a la móvil (M5). Cierra a mano y revisa que los pernos guía entren.',
     '10. Expulsoras: ajústalas con sus tuercas para que empujen los botadores justo al final de la apertura.',
     '11. Motor con piñón en su placa; sube/baja en las ranuras hasta que engrane sin apretar.']
    for i,t in enumerate(steps): f.text(.05,.88-i*.034,t,fontsize=9)
    f.text(.05,.38,'Fuerza de cierre (aprox.)',fontsize=12,weight='bold')
    calc=[f'Rosca ½"-13: avance {LEAD:.2f} mm por vuelta, eficiencia ≈ {ETA:.0%}. NEMA 17 a baja velocidad ≈ {TM_} N·m.',
          f'F = 2π · T · reducción · η / avance   →   3:1 ≈ {Fz(3)/9.81:.0f} kgf    4:1 ≈ {Fz(4)/9.81:.0f} kgf    5:1 ≈ {Fz(5)/9.81:.0f} kgf',
          f'La pieza + canal ocupan ≈ {AREA} mm². Con 5:1 aguanta ≈ {Fz(5)/AREA:.1f} MPa de plástico antes de abrirse (rebaba).',
          'La rosca ½" es autobloqueante: el plástico NO puede regresar el tornillo.',
          'Si sale rebaba, sube la reducción. No le metas llave grande: la trasera es delgada y se doblaría.']
    for i,t in enumerate(calc): f.text(.05,.34-i*.033,t,fontsize=9)
    foot(f,n); pdf.savefig(f); plt.close(f); n+=1
    # plantillas 1:1 (carta vertical 215.9 x 279.4)
    PWm,PHm=215.9,279.4
    for V in VIEWS[:3]+['combo']:
        f=plt.figure(figsize=(PWm/25.4,PHm/25.4)); a=f.add_axes([0,0,1,1]); a.set_xlim(0,PWm); a.set_ylim(0,PHm); a.axis('off')
        def put(V,ox,oy):
            import matplotlib.transforms as mt
            sub=f.add_axes([ox/PWm,oy/PHm,(V['W']+40)/PWm,(V['H']+40)/PHm]); sub.set_xlim(-20,V['W']+20); sub.set_ylim(-20,V['H']+20)
            draw_plate(sub,V,dims=True,fs=5.5); sub.text(V['W']/2,V['H']+12,V['name']+' · escala 1:1',ha='center',fontsize=7,weight='bold')
        if V=='combo':
            put(VIEWS[3],20,120); put(VIEWS[4],90,130)
            a.text(10,265,'Plantillas 1:1 — imprimir al 100 % ("tamaño real"), carta vertical',fontsize=7)
        else:
            put(V,(PWm-V['W']-40)/2,(PHm-V['H']-40)/2+20)
            a.text(10,270,'Plantilla 1:1 — imprimir al 100 % ("tamaño real"), carta vertical. Vista desde el frente de la máquina.',fontsize=7)
        a.plot([20,70],[20,20],color='k',lw=1.5); a.text(45,23,'50 mm (verifica con regla)',ha='center',fontsize=6)
        pdf.savefig(f); plt.close(f)
print('ok')
