# Inyectora: tornillo directo, igual al BOCETO 1.  mm.  X = largo (frente=0), Y = ancho, Z = altura
import numpy as np, trimesh, pickle, json
from shapely.geometry import Polygon, Point, box, LineString
from shapely.ops import unary_union
from trimesh.creation import extrude_polygon, cylinder
Rm=trimesh.transformations.rotation_matrix
LU=280; WU=140; HU=30; TU=4.5            # canal U *aprox (espesor por confirmar)
Z0=HU                                    # cara de arriba de la base
PL=130.0                                 # placas fija y trasera 130 x 130
ZC=Z0+70.0                               # centro del molde (5 mm arriba del centro de las placas)
BY,BZ=49.5,46.0
BAR=12.7; BUSH_OD=15.875; BUSH_L=19.05
MW,MH,TM=128.0,128.0,2.5                 # placa móvil: lámina 2.5 mm (sin la orilla con agujeros)
RD=12.0; LMD,LML=21.0,30.0               # ejes lisos 12 mm + baleros LM12UU (12x21x30)
X_ROD_UP=(XA_F[1] if False else 55.0, 215.0); X_ROD_LO=(45.0,225.0)
def hb(y,z):
    sy=1 if y>0 else -1; sz=1 if z>ZC else -1
    return [(y-22*sy,z+4*sz),(y+4*sy,z-22*sz)]
HOLD_BOLTS=[p for b in [(sy*49.5,ZC+sz*46.0) for sy in(-1,1) for sz in(-1,1)] for p in hb(*b)]
S=25.0; Q=6.35
KOY=19.5; KOD=7.94; KO_AF=12.7
ROD=12.7; NUT_T=11.0; NUT_AF=19.05; CPL_L=44.45; JAM_T=7.0; BW=1.5
LA,LT=65.0,10.0                          # ángulo 65 x 65 x 10
XA_F=(-10.0,55.0)                        # ángulo delantero: pata horizontal (sale 10 mm al frente de la base)
XF0=XA_F[1]; XF=XF0+6.0                  # placa fija trapecio 6 mm; XF = cara del molde B
XH_F=20.0                                # agujeros de tu base usados por el ángulo delantero
MOLD=57.15
XMB=XF+MOLD
XMP0,XMP1=XMB,XMB+TM
XBR0,XBR1=XMP1,XMP1+5.0
XC0,XC1=XBR1,XBR1+CPL_L
XR1=LU-LA; XR=XR1-TU                     # placa trasera; sus escuadras llegan justo al final de la base
X_BW=(XR-BW,XR); X_TN=(X_BW[0]-NUT_T,X_BW[0])
GAP_OPEN=X_TN[0]-(XC1+S); assert GAP_OPEN>=2.5,GAP_OPEN
X_RODTIP=XC0+S+2.0
X_NW=(XR1,XR1+BW); X_RN=(X_NW[1],X_NW[1]+NUT_T); X_GEAR=(X_RN[1]+1,X_RN[1]+9); X_JAM=(X_GEAR[1],X_GEAR[1]+JAM_T)
X_RODEND=X_JAM[1]+2
X_MPL=(X_GEAR[1]+3,X_GEAR[1]+8); X_MOT=(X_MPL[1],X_MPL[1]+48)
GEAR_R=30.0; PIN_R=9.0; MOT_Z=ZC+GEAR_R+PIN_R
X_KO_TIP=(XMB-12.7)+S-Q
BARS=[(sy*BY,ZC+sz*BZ) for sy in(-1,1) for sz in(-1,1)]
LOWBARS=[p for p in BARS if p[1]<ZC]
X_BAR=(XF0-LT-NUT_T-2, XR1+LT+NUT_T+2)
MPL_W=76; MPL_Z=(ZC+12,ZC+72); SLOT=5.0
STAND=[(sy*30,ZC+24) for sy in(-1,1)]+[(sy*30,ZC+52) for sy in(-1,1)]
BR_W=BR_H=54.0; BR_BOLTS=[(sy*20,ZC+sz*20) for sy in(-1,1) for sz in(-1,1)]
A_MOUNT=[(sy*31.75,ZC+sz*28.1) for sy in(-1,1) for sz in(-1,1)]
B_MOUNT=[(sy*31.75,ZC+sz*8.1) for sy in(-1,1) for sz in(-1,1)]
KO=[(sy*KOY,ZC) for sy in(-1,1)]
RA_Y=(25.0,65.0)                         # escuadras traseras en |Y| 25..65
BASE_F=[(XH_F,y) for y in(-46,-23,23,46)]            # ya existen (Ø10)
BASE_R=[(260.0,y) for y in(-46,46)]+[(247.0,y) for y in(-38,38)]   # 260 ya existen; 247 nuevos
def u_holes():
    H=[]
    for y in(-46,-23,23,46): H.append((20,y,10,'o'))
    for c in(85,195):
        for y in(-46,-23,23,46): H.append((c,y,20 if abs(y)==46 else 14,'o'))
    for y in(-46,46): H.append((260,y,10,'o'))
    for y in(-23,23): H.append((260,y,10,'slot'))
    return H
OLD_BASE=u_holes()
RW0=260-BY-PL/2                       # pedazo del 2o canal: X viejo [145.5, 275.5]
RCEN=RW0+PL/2
OLD_REAR=[]
for x,y,d,t in u_holes():
    if RW0-5<x<RW0+PL+5: OLD_REAR.append((x-RCEN,ZC+y,d,t))
# ---------------- helpers de malla
def ext(poly,a0,a1,axis):
    m=extrude_polygon(poly,a1-a0)
    if axis=='X': M=np.array([[0,0,1,a0],[1,0,0,0],[0,1,0,0],[0,0,0,1]],float)   # poly(Y,Z)
    elif axis=='Z': M=np.array([[1,0,0,0],[0,1,0,0],[0,0,1,a0],[0,0,0,1]],float) # poly(X,Y)
    else: M=np.array([[1,0,0,0],[0,0,1,a0],[0,1,0,0],[0,0,0,1]],float)           # poly(X,Z) along Y
    m.apply_transform(M)
    if m.volume<0: m.invert()
    return m
def cX(x0,x1,y,z,d,s=40): return cylinder(d/2,x1-x0,sections=s).apply_transform(Rm(np.pi/2,[0,1,0])).apply_translation([(x0+x1)/2,y,z])
def cZ(z0,z1,x,y,d,s=32): return cylinder(d/2,z1-z0,sections=s).apply_translation([x,y,(z0+z1)/2])
def hexX(x0,x1,y,z,af): return cX(x0,x1,y,z,af*2/np.sqrt(3),6)
def hexZ(z0,z1,x,y,af): return cZ(z0,z1,x,y,af*2/np.sqrt(3),6)
def C(p,d): return Point(p).buffer(d/2,48)
def slot(p0,p1,w): return LineString([p0,p1]).buffer(w/2,24)
# ---------------- piezas
P=[]
def add(n,mat,g,m): P.append((n,mat,g,m))
web=box(0,-WU/2,LU,WU/2)
web=web.difference(unary_union([C((x,y),d) if t=='o' else slot((x,y),(LU+5,y),d) for x,y,d,t in OLD_BASE]+[C(p,10) for p in BASE_R if p[0]==247]))
base=[ext(web,Z0-TU,Z0,'Z')]
for s in(-1,1):
    y0,y1=sorted([s*(WU/2-TU),s*WU/2]); base.append(ext(box(0,0,LU,Z0-TU),y0,y1,'Y'))
add('Base (canal U #1)','U1','fijo',trimesh.util.concatenate(base))
# placa fija trapecio 6 mm
fp=box(-PL/2,Z0,PL/2,Z0+PL).difference(unary_union([C(p,12.2) for p in BARS]+[C(p,5.5) for p in B_MOUNT]))
add('Placa fija (trapecio 6 mm)','T6','fijo',ext(fp,XF0,XF,'X'))
# placa trasera: alma del 2o canal sin cejas
rp=box(-PL/2,Z0,PL/2,Z0+PL)
cut=[C(p,12.2) for p in BARS]+[C((0,ZC),14.0)]+[C(p,8.5) for p in KO]+[C(p,6.5) for p in STAND]
cut+=[C((y,z),d) if t=='o' else slot((y,z),(PL/2+5 if y>0 else -PL/2-5,z),d) for y,z,d,t in OLD_REAR]
add('Placa trasera (2o canal, sin cejas)','U2','fijo',ext(rp.difference(unary_union(cut)),XR,XR1,'X'))
# ángulos
def angle(xh0,xh1,xv0,xv1,y0,y1,hholes,vholes):
    h=box(xh0,y0,xh1,y1).difference(unary_union([C(p,10.0) for p in hholes])) if hholes else box(xh0,y0,xh1,y1)
    v=box(y0,Z0,y1,Z0+LA).difference(unary_union([C(p,13.5) for p in vholes])) if vholes else box(y0,Z0,y1,Z0+LA)
    return trimesh.util.concatenate([ext(h,Z0,Z0+LT,'Z'),ext(v,xv0,xv1,'X')])
add('Ángulo delantero (escuadra)','A','fijo',angle(XA_F[0],XA_F[1],XA_F[1]-LT,XA_F[1],-PL/2,PL/2,BASE_F,LOWBARS))
for s in(-1,1):
    y0,y1=sorted([s*RA_Y[0],s*RA_Y[1]])
    add('Escuadras traseras (ángulo)','A','fijo',angle(XR1,LU,XR1,XR1+LT,y0,y1,[p for p in BASE_R if p[1]*s>0],[p for p in LOWBARS if p[0]*s>0]))
bars=[cX(*(X_ROD_LO if z<ZC else X_ROD_UP),y,z,RD) for y,z in BARS]
add('Ejes lisos 12 mm (comprar)','compra','fijo',trimesh.util.concatenate(bars))
eb=[]
for y,z in BARS:
    x0,x1=X_ROD_LO if z<ZC else X_ROD_UP
    eb+=[cX(x0-1.6,x0,y,z,18),cX(x0-7.6,x0-1.6,y,z,10),cX(x1,x1+1.6,y,z,18),cX(x1+1.6,x1+7.6,y,z,10)]
add('Tornillos de los ejes','tornillo','fijo',trimesh.util.concatenate(eb))






mp,mpins=pickle.load(open('../molde/parts.pkl','rb'))
def m2m(m):
    m=m.copy(); T=np.array([[0,0,-1,XF+MOLD],[1,0,0,-38.1],[0,-1,0,38.1+ZC],[0,0,0,1]],float); m.apply_transform(T); return m
add('Molde B (fijo)','molde','fijo',m2m(mp['1_Placa_B_fija']))
movA=[m2m(mp[k]) for k in ['2_Placa_A_cavidad','3_Separador_izq','4_Separador_der']]
movA.append(m2m(mp['7_Placa_base']).difference(trimesh.util.concatenate([cX(XMB-14,XMB+1,y,z,9.0) for y,z in KO])))
add('Molde A + separadores + placa base','molde','movil',trimesh.util.concatenate(movA))
add('Placas expulsoras + botadores','molde','expulsor',trimesh.util.concatenate([m2m(mp['5_Porta_botadores']),m2m(mp['6_Placa_expulsora'])]+[m2m(p) for p in mpins]))
mpl=box(-MW/2,ZC-MH/2,MW/2,ZC+MH/2).difference(unary_union([C(p,16.0) for p in BARS]+[C(p,9.0) for p in KO]+[C(p,5.5) for p in A_MOUNT]+[C(p,6.6) for p in BR_BOLTS]+[C((0,ZC),14.0)]+[C(p,4.5) for p in HOLD_BOLTS]))
add('Placa móvil (lámina 2.5 mm)','L25','movil',ext(mpl,XMP0,XMP1,'X'))
from shapely.geometry import MultiPoint
lm=[];hold=[];hb_=[]
for y,z in BARS:
    sy=1 if y>0 else -1; sz=1 if z>ZC else -1
    lm.append(cX(XMP1+0.5,XMP1+0.5+LML,y,z,LMD).difference(cX(XMP1-1,XMP1+LML+2,y,z,RD+0.3)))
    bolts=hb(y,z); FT=6.0
    def holder2d(y,z,sy):
        fl=unary_union([Point(y,z).buffer(15.5,48)]+[Point(p).buffer(5.5,24) for p in bolts]).convex_hull
        fl=fl.difference(unary_union([Point(y,z).buffer(LMD/2+0.1,48)]+[Point(p).buffer(2.25,16) for p in bolts]))
        ear=box(min(y,y+sy*26),z-5,max(y,y+sy*26),z+5)
        ring=unary_union([Point(y,z).buffer(15.5,48),ear]).difference(Point(y,z).buffer(LMD/2+0.05,48)).difference(box(min(y,y+sy*27),z-1,max(y,y+sy*27),z+1))
        return fl,ring
    fl,ring=holder2d(y,z,sy)
    nuttrap=[ext(Point(p).buffer(7.0/np.sqrt(3)*1.0,6),XMP1+FT-3.6,XMP1+FT+0.01,'X') for p in bolts]
    h=[ext(fl,XMP1,XMP1+FT,'X').difference(trimesh.util.concatenate(nuttrap))]+[ext(g,XMP1+FT,XMP1+31,'X').difference(cZ(z-9,z+9,XMP1+18,y+sy*20,3.4,16)) for g in getattr(ring,'geoms',[ring])]+[cX(XMP1+31,XMP1+33,y,z,31).difference(cX(XMP1+30,XMP1+34,y,z,17))]
    hold.append(trimesh.util.concatenate(h))
    for p in bolts: hb_+=[cX(XMP0-4,XMP0,*p,7.0,24),hexX(XMP1+FT-3.4,XMP1+FT-0.2,*p,6.9)]
    cs=cZ(z-7,z+7,XMP1+18,y+sy*20,3.0,12); hb_.append(cs)
add('Baleros lineales LM12UU (comprar)','compra','movil',trimesh.util.concatenate(lm))
add('Soportes impresos de LM12UU','print','movil',trimesh.util.concatenate(hold))
add('Tornillería soportes LM12UU','tornillo','movil',trimesh.util.concatenate(hb_))




br=box(-BR_W/2,ZC-BR_H/2,BR_W/2,ZC+BR_H/2).difference(unary_union([C(p,6.6) for p in BR_BOLTS]+[C((0,ZC),14.0)]+[C(p,9.0) for p in KO]))
add('Soporte de tuerca (placa 5 mm)','P5','movil',ext(br,XBR0,XBR1,'X'))
add('Cople ½" × 1¾" soldado al soporte','tornillo','movil',hexX(XC0,XC1,0,ZC,NUT_AF).difference(cX(XC0-1,XC1+1,0,ZC,ROD)))
add('Tornillería placa móvil','tornillo','movil',trimesh.util.concatenate([hexX(XBR1,XBR1+5,y,z,10) for y,z in BR_BOLTS]+[cX(XMP1,XMP1+4,y,z,8.5) for y,z in A_MOUNT]))
add('Tu varilla roscada ½"','varilla','giro',cX(X_RODTIP,X_RODEND,0,ZC,ROD))
add('Tuercas del tornillo','tornillo','giro',trimesh.util.concatenate([hexX(*X_TN,0,ZC,NUT_AF),hexX(*X_RN,0,ZC,NUT_AF),hexX(*X_JAM,0,ZC,NUT_AF)]))
add('Rondanas de bronce (comprar)','compra','fijo',trimesh.util.concatenate([cX(*X_BW,0,ZC,22).difference(cX(X_BW[0]-1,X_BW[1]+1,0,ZC,13)),cX(*X_NW,0,ZC,22).difference(cX(X_NW[0]-1,X_NW[1]+1,0,ZC,13))]))
def gear(r,n,x0,x1,y,z):
    pts=[]
    for i in range(n*4):
        a=2*np.pi*i/(n*4); rr=r if (i%4) in(1,2) else r-2.2
        pts.append((y+rr*np.cos(a),z+rr*np.sin(a)))
    return ext(Polygon(pts).buffer(0),x0,x1,'X')
add('Engrane grande (en la varilla)','engrane','giro',gear(GEAR_R,48,*X_GEAR,0,ZC).difference(cX(X_GEAR[0]-1,X_GEAR[1]+1,0,ZC,ROD)))
add('Tu piñón blanco','pinon','fijo',gear(PIN_R,14,*X_GEAR,0,MOT_Z))
ko=[cX(X_KO_TIP,XR1+9,y,z,KOD) for y,z in KO]+[hexX(XR-7,XR,y,z,KO_AF) for y,z in KO]+[hexX(XR1,XR1+7,y,z,KO_AF) for y,z in KO]
add('Varillas expulsoras 5/16"','varilla','fijo',trimesh.util.concatenate(ko))
mplate=box(-MPL_W/2,MPL_Z[0],MPL_W/2,MPL_Z[1]).difference(unary_union([C(p,6.5) for p in STAND]+[slot((0,MOT_Z-SLOT),(0,MOT_Z+SLOT),23)]+[slot((sy*15.5,MOT_Z+sz*15.5-SLOT),(sy*15.5,MOT_Z+sz*15.5+SLOT),3.4) for sy in(-1,1) for sz in(-1,1)]))
add('Placa del motor (placa 5 mm)','P5','fijo',ext(mplate,*X_MPL,'X'))
add('Postes del motor (tornillo M6 + tubo)','tornillo','fijo',trimesh.util.concatenate([cX(XR1,X_MPL[0],y,z,10) for y,z in STAND]+[cX(XR-2,X_MPL[1]+6,y,z,6) for y,z in STAND]))
mot=trimesh.creation.box([X_MOT[1]-X_MOT[0],42.3,42.3]).apply_translation([(X_MOT[0]+X_MOT[1])/2,0,MOT_Z])
add('Motor NEMA 17','motor','fijo',trimesh.util.concatenate([mot,cX(X_GEAR[0],X_MOT[0],0,MOT_Z,5)]))
bb=[]
for x,y in BASE_F+BASE_R: bb+=[cZ(Z0-TU-14,Z0+LT+6,x,y,9.5),hexZ(Z0+LT,Z0+LT+6,x,y,14.3),hexZ(Z0-TU-9,Z0-TU,x,y,14.3)]
add('Tornillos ⅜" escuadras–base','tornillo','fijo',trimesh.util.concatenate(bb))
add('Boquilla del inyector (referencia)','ref','fijo',cZ(ZC+38.1+1,ZC+38.1+70,XF+12.7,0,16))
pickle.dump(dict(P=P),open('parts.pkl','wb'))
D={k:v for k,v in globals().items() if k.isupper() and k!='P' and isinstance(v,(int,float,tuple,list))}
json.dump(D,open('dims.json','w'),indent=0,default=float)
print('XF',XF,'XMB',XMB,'XR',XR,'gap',round(GAP_OPEN,2),'rod',X_RODTIP,X_RODEND,round(X_RODEND-X_RODTIP,1),'bar',X_BAR,X_BAR[1]-X_BAR[0],'KO',round(X_KO_TIP,2),round(XR1+9-X_KO_TIP,1),'motor',X_MOT,'RW0',RW0,'old rear',[(round(a,1),b-ZC,d,t) for a,b,d,t in OLD_REAR])
