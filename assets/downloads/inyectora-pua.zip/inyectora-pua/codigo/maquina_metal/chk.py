import pickle,numpy as np,trimesh,itertools,json
P=pickle.load(open('parts.pkl','rb'))['P']; D=json.load(open('dims.json')); S=D['S'];Q=D['Q']
def shift(g,t):
    s=S*t
    if g=='movil': return s
    if g=='expulsor': return s-max(0,s-(S-Q))
    return 0
# split concatenated meshes into bodies for robust booleans
def bodies(m):
    try: return [b for b in m.split(only_watertight=False)]
    except: return [m]
B=[(n,g,bodies(m)) for n,_,g,m in P]
BAR='Ejes lisos 12 mm (comprar)'; NUT='Tornillos de los ejes'; ROD='Tu varilla roscada ½"'; RP='Placa trasera (2o canal, sin cejas)'; FP='Placa fija (trapecio 6 mm)'
TOR='Tornillos ⅜" escuadras–base'; ANGF='Ángulo delantero (escuadra)'; ANGR='Escuadras traseras (ángulo)'; MA='Molde A + separadores + placa base'; MB='Molde B (fijo)'; EX='Placas expulsoras + botadores'
IGN={frozenset(x) for x in [(BAR,NUT),(BAR,'Baleros lineales LM12UU (comprar)'),('Baleros lineales LM12UU (comprar)','Soportes impresos de LM12UU'),('Tornillería soportes LM12UU','Placa móvil (lámina 2.5 mm)'),('Soportes impresos de LM12UU','Placa móvil (lámina 2.5 mm)'),(BAR,FP),(BAR,RP),(BAR,ANGF),(BAR,ANGR),(ROD,'Tuercas del tornillo'),(ROD,'Cople ½" × 1¾" soldado al soporte'),(ROD,'Engrane grande (en la varilla)'),(ROD,'Rondanas de bronce (comprar)'),(ROD,RP),
 (TOR,'Base (canal U #1)'),(TOR,ANGF),(TOR,ANGR),('Varillas expulsoras 5/16"',RP),('Postes del motor (tornillo M6 + tubo)',RP),('Postes del motor (tornillo M6 + tubo)','Placa del motor (placa 5 mm)'),
 ('Motor NEMA 17','Tu piñón blanco'),('Motor NEMA 17','Placa del motor (placa 5 mm)'),('Engrane grande (en la varilla)','Tu piñón blanco'),('Tornillería placa móvil','Placa móvil (lámina 2.5 mm)'),('Tornillería placa móvil','Soporte de tuerca (placa 5 mm)'),('Tornillería placa móvil',MA),
 (EX,MA),(MB,MA),(EX,MB),(NUT,RP),(NUT,FP),(NUT,ANGF),(NUT,ANGR)]}
res={}
for t in (0,0.5,1.0):
    for (n1,g1,b1),(n2,g2,b2) in itertools.combinations(B,2):
        if frozenset((n1,n2)) in IGN: continue
        for a in b1:
            A=a.copy().apply_translation([shift(g1,t),0,0])
            for b in b2:
                Bm=b.copy().apply_translation([shift(g2,t),0,0])
                lo=np.maximum(A.bounds[0],Bm.bounds[0]); hi=np.minimum(A.bounds[1],Bm.bounds[1])
                if np.any(hi-lo<=0.05): continue
                try: v=A.intersection(Bm).volume
                except Exception as e: v=-1
                if abs(v)>1.0: res.setdefault((n1,n2),[]).append((t,round(v,1),np.round(lo,1).tolist(),np.round(hi,1).tolist()))
for k,v in res.items(): print(k,v[:2])
print('done',len(res))
