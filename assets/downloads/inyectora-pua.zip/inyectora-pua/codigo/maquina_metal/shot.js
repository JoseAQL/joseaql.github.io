const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium',args:['--use-gl=swiftshader','--enable-unsafe-swiftshader','--allow-file-access-from-files']});
const p=await b.newPage({viewport:{width:1600,height:1100}});p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file://'+process.cwd()+'/r.html');await p.waitForFunction(()=>window.ready,null,{timeout:60000});
const V=JSON.parse(process.argv[2]);
for(const [n,x,y,z,t,tx,ty] of V){await p.evaluate(a=>window.view(...a),[x,y,z,t,tx,ty]);await p.waitForTimeout(200);await p.locator('#c').screenshot({path:n+'.png'});}
await b.close();})();
