import numpy as np,trimesh,json,math,os
from shapely.geometry import Polygon,box,Point,MultiPolygon,LineString
from shapely.ops import unary_union
W=76.2; T=12.7; PY=24.0; gx=W/2
TD=3.175; TR=TD/2; STEP=1.2
F_CUT=400; F_PLUNGE=100; SAFE=5.0; RPM=10000
info=json.load(open('info_expulsion.json')); old=json.load(open('info_molde.json'))
part=trimesh.load('../../01_pieza/pua_triangular.stl'); b=part.bounds
OX=W/2-(b[0,0]+b[1,0])/2; OY=PY-b[0,1]
def region(z):
    s=part.section([0,0,1],[0,0,z]); p,M=s.to_2D(); polys=[]
    def tr(c):
        c=np.array(c); q=np.c_[c,np.zeros(len(c)),np.ones(len(c))]@M.T; return q[:,:2]+[OX,OY]
    for pf in p.polygons_full: polys.append(Polygon(tr(pf.exterior.coords),[tr(i.coords) for i in pf.interiors]))
    return unary_union(polys).buffer(0)
class G:
    def __init__(s,name,title,stock,notes):
        s.name=name;s.L=[f'( {title} )',f'( Material: {stock} )','( Herramienta: fresa plana 1/8" (3.175 mm) carburo para aluminio )','( Cero X0 Y0: esquina inferior izquierda | Z0: cara superior del material )']+[f'( {n} )' for n in notes]+['G21 G90 G17 G94',f'G0 Z{SAFE}',f'M3 S{RPM}','G4 P3'];s.z=SAFE;s.len=0
    def up(s): s.L.append(f'G0 Z{SAFE}'); s.z=SAFE
    def rapid(s,x,y): s.L.append(f'G0 X{x:.3f} Y{y:.3f}')
    def plunge(s,z): s.L.append(f'G0 Z0.5'); s.L.append(f'G1 Z{z:.3f} F{F_PLUNGE}')
    def cut(s,x,y,z=None): s.L.append(f'G1 X{x:.3f} Y{y:.3f}'+(f' Z{z:.3f}' if z is not None else '')+f' F{F_CUT}')
    def ring(s,coords,z):
        c=list(coords); s.L.append('G0 Z0.5'); s.rapid(*c[0]); s.L.append(f'G1 Z{z:.3f} F{F_PLUNGE}')
        for x,y in c[1:]: s.cut(x,y)
    def pocket(s,poly,z):
        rings=[]; cur=poly.buffer(-TR,join_style=1)
        while not cur.is_empty:
            gs=cur.geoms if hasattr(cur,'geoms') else [cur]
            for g in gs:
                if g.area<1e-4 and g.length<0.05: continue
                rings.append(g.exterior.coords)
                for i in g.interiors: rings.append(i.coords)
            cur=cur.buffer(-STEP,join_style=1)
        for r in reversed(rings): s.ring(r,z)
        return len(rings)
    def hole(s,x,y,d,depth,stepdown=0.15):
        # helical bore; d>=tool
        r=(d-TD)/2
        s.up(); 
        if r<0.05:  # straight peck
            s.rapid(x,y); z=0
            while z>-depth: z=max(z-0.5,-depth); s.L.append(f'G1 Z{z:.3f} F{F_PLUNGE//2}'); s.L.append('G0 Z0.5')
            return
        s.rapid(x+r,y); s.L.append('G0 Z0.5'); s.L.append(f'G1 Z0 F{F_PLUNGE}'); z=0
        while z>-depth+1e-6:
            z=max(z-stepdown,-depth); s.L.append(f'G2 X{x+r:.3f} Y{y:.3f} I{-r:.3f} J0 Z{z:.3f} F{F_CUT//2}')
        s.L.append(f'G2 X{x+r:.3f} Y{y:.3f} I{-r:.3f} J0 F{F_CUT//2}')
        # widen if large: concentric passes
        rr=r
        while rr+STEP < (d-TD)/2+1e-6: pass
        s.L.append(f'G1 X{x:.3f} Y{y:.3f}'); s.up()
    def counterbore(s,x,y,d,depth,stepdown=0.2):
        rmax=(d-TD)/2; radii=[]; rr=rmax
        while rr>0.2: radii.append(rr); rr-=STEP
        radii=radii[::-1]
        s.up(); s.rapid(x,y); s.L.append('G0 Z0.5'); s.L.append(f'G1 Z0 F{F_PLUNGE}'); z=0
        while z>-depth+1e-6:
            z=max(z-stepdown,-depth)
            first=True
            for r in radii:
                s.cut(x+r,y,z if first else None); first=False
                s.L.append(f'G2 X{x+r:.3f} Y{y:.3f} I{-r:.3f} J0 F{F_CUT//2}')
            s.cut(x,y)
        s.up()
    def spot(s,x,y,depth=0.4):
        s.up(); s.rapid(x,y); s.plunge(-depth); s.up()
    def profile_out(s,poly,depth,tabs=4,tabh=0.8,stepdown=0.25):
        path=poly.buffer(TR,join_style=1).exterior; Lp=path.length
        tabpos=[Lp*(i+0.5)/tabs for i in range(tabs)]; tw=TD+3
        pts=[path.interpolate(d) for d in np.arange(0,Lp,0.5)]+[path.interpolate(0)]
        ds=list(np.arange(0,Lp,0.5))+[Lp]
        s.up(); s.rapid(pts[0].x,pts[0].y); s.L.append('G0 Z0.5'); z=0
        while z>-depth+1e-6:
            z=max(z-stepdown,-depth)
            for p,d in zip(pts,ds):
                zz=z
                if z< -depth+tabh and any(abs(d-t)<tw/2 for t in tabpos): zz=-depth+tabh
                s.cut(p.x,p.y,zz)
        s.up()
    def save(s,folder):
        s.L+= [f'G0 Z{SAFE}','M5','G0 X0 Y0','M30']
        open(f'{folder}/{s.name}.nc','w').write(('\n'.join(s.L)+'\n').replace('Ø','D')); return len(s.L)
OUT='GCODE'; os.makedirs(OUT,exist_ok=True)
# ===== Plate A face
sprue=Polygon([(gx-4.5,-4),(gx+4.5,-4),(gx+2.5,7),(gx-2.5,7)])
runner=box(gx-2.5,6,gx+2.5,PY-3); gate=box(gx-1.75,PY-3.5,gx+1.75,PY+1.0)
vents=[box(gx-1.75,PY+28,gx+1.75,W+4)]
R1=region(-0.29); minx,miny,maxx,maxy=R1.bounds
vents+=[box(-4,PY+4.0,minx+2,PY+7.5),box(maxx-2,PY+4.0,W+4,PY+7.5)]
feats=[(sprue,3.0),(runner,2.5),(gate,1.5)]+[(v,0.1) for v in vents]
g=G('A1_cara_cavidad','PLACA A - cara de cavidad: cavidad, canal, entrada, venteos, pernos guia, puntos de barreno','bloque aluminio 3x3x1/2 in (76.2x76.2x12.7 mm)',
    ['Orden: 1 pernos guia Ø6.30 prof 8 | 2 puntos de barreno botadores/retornos | 3 cavidad por niveles de 0.1 mm','Despues: barrenar en taladro Ø3.0 (5 botadores) y Ø6.1 (4 retornos) atravesando'])
for x,y in old['pinsA']: g.hole(x,y,6.30,8.0)
for x,y,_,_ in info['ej']: g.spot(x,y)
for x,y in info['ret']: g.spot(x,y)
levels=np.round(np.arange(0.1,3.0+1e-6,0.1),2); total=0
cache={}
for L in levels:
    zc=L-0.3-0.005
    parts=[]
    if L<=2.3: parts.append(region(zc) if zc>-0.3 else R1)
    parts+=[f for f,d in feats if d>=L-1e-6]
    reg=unary_union(parts).buffer(0)
    if reg.is_empty: continue
    total+=g.pocket(reg,-L)
print('A1 rings',total,'lines',g.save(OUT))
# ===== Plate A back
g=G('A2_cara_trasera','PLACA A - cara trasera (voltear A, cavidad hacia abajo; usar la misma esquina como cero)','placa A ya maquinada',['Solo marca 4 puntos: barrenar Ø4.2 prof 10 y machuelo M5','Patron simetrico: no importa si volteas izquierda-derecha'])
for x,y in info['m5']: g.spot(x,y,0.5)
g.save(OUT)
# ===== Plate B
g=G('B1_cara_cierre','PLACA B - cara de cierre (solo pernos guia)','bloque aluminio 3x3x1/2 in',['Pernos guia Ø6.30 prof 8 (patron espejo de A)','Luego lijar la cara plana sobre vidrio'])
for x,y in old['pinsB']: g.hole(x,y,6.30,8.0)
g.save(OUT)
# ===== Porta-botadores & expulsora (part at X5 Y5 in stock)
ex0,ey0=info['EPX'][0],info['EPY'][0]; ew=info['EPX'][1]-ex0; eh=info['EPY'][1]-ey0; M=5.0
P=lambda x,y:(x-ex0+M,y-ey0+M)
outline=box(M,M,M+ew,M+eh)
g=G('C1_porta_botadores','PORTA-BOTADORES - cara de abajo (la que toca la placa expulsora)','placa aluminio 1/4 in (6.35 mm), minimo 60x82 mm',
    ['Pieza queda en X5 Y5 del material','Cajas cabezas: Ø7.5 prof 4.1 (botadores de tornillo M4) y Ø10.5 prof 5.1 (retornos)','Puntos: barrenar Ø3.2 y Ø6.2 atravesando; M3: broca 2.5 y machuelo','Ultimo: contorno 48x70 atravesando con 4 puentes; cortar puentes y limar'])
for x,y,_,_ in info['ej']: g.counterbore(*P(x,y),7.5,4.1)
for x,y in info['ret']: g.counterbore(*P(x,y),10.5,5.1)
for x,y in info['m3']: g.spot(*P(x,y))
g.profile_out(outline,6.35+0.2); g.save(OUT)
g=G('D1_placa_expulsora','PLACA EXPULSORA - cara de abajo (la que mira a la placa base)','placa aluminio 1/4 in (6.35 mm), minimo 60x82 mm',
    ['Pieza queda en X5 Y5 del material','Cajas cabeza tornillo M3: Ø6 prof 3.2, luego barrenar Ø3.4 atravesando','Ultimo: contorno 48x70 con 4 puentes'])
for x,y in info['m3']: g.counterbore(*P(x,y),6.0,3.2)
g.profile_out(outline,6.35+0.2); g.save(OUT)
# ===== Placa base
g=G('E1_placa_base','PLACA BASE - cara de abajo (donde va el piston)','bloque aluminio 3x3x1/2 in',
    ['Cajas cabeza M5: Ø9.5 prof 5.5; luego barrenar Ø5.5 atravesando','Barreno central Ø16.5 atravesando: necesitas fresa con filo de 13 mm o mas. Si tu fresa es corta, corta 6 mm por cada lado o usa broca escalonada'])
for x,y in info['m5']: g.counterbore(x,y,9.5,5.5); g.spot(x,y,6.0)
g.counterbore(gx,gx,16.5,T+0.3,stepdown=0.25); g.save(OUT)
# ===== Separadores
g=G('F1_separador_x2','SEPARADOR (hacer 2) - cara superior','solera aluminio 3/4 x 1/2 in cortada a 76.2 mm, acostada con la cara de 12.7 mm hacia arriba',['Solo marca 2 puntos: barrenar Ø5.5 atravesando (19.05 mm)'])
for y in (26,50): g.spot(6.35,y,0.5)
g.save(OUT)
print(os.listdir(OUT))
