import trimesh, numpy as np
from shapely.geometry import Polygon, box, Point, MultiPolygon
from shapely.ops import unary_union
from shapely import affinity
W=76.2; T=12.7
part=trimesh.load('../../01_pieza/pua_triangular.stl')
# place part: x centered, bottom y at PY, flat face at block top, flipped down into block
PY=24.0
b=part.bounds
cav=part.copy()
cav.apply_translation([W/2-(b[0,0]+b[1,0])/2, PY-b[0,1], 0.3])   # flat face z=0, top up to 2.3
cav.apply_transform(np.diag([1,1,-1,1]))   # mirror into -z
cav.invert() if cav.volume<0 else None
cav.apply_translation([0,0,T])
cav.fix_normals()
gx=W/2
# features (2D shape, depth)
def slab(poly,depth,top=T,extra=0.5):
    return trimesh.creation.extrude_polygon(poly,depth+extra).apply_translation([0,0,top-depth])
feats={}
# sprue entry (nozzle seat) at bottom edge, runner, gate
sprue=Polygon([(gx-4,-1),(gx+4,-1),(gx+2.5,7),(gx-2.5,7)])
runner=box(gx-2.5,6,gx+2.5,PY-3)
gate=box(gx-1.75,PY-3.5,gx+1.75,PY+1.0)
# vents (0.1 mm) from the three tips
tipT=(gx,PY+30); 
vents=[box(gx-1.75,PY+28,gx+1.75,W+1)]
# bottom tips: find from part outline
sec=part.section([0,0,1],[0,0,-0.29]); P2,M=sec.to_2D()
outline=P2.polygons_full[0]
# transform 2D back to world xy
pts=np.c_[np.array(outline.exterior.coords),np.zeros(len(outline.exterior.coords)),np.ones(len(outline.exterior.coords))]@M.T
xy=pts[:,:2]+[W/2-(b[0,0]+b[1,0])/2, PY-b[0,1]]
outline=Polygon(xy).buffer(0)
minx,miny,maxx,maxy=outline.bounds
vents+= [box(-1,PY+4.0,minx+2,PY+7.5), box(maxx-2,PY+4.0,W+1,PY+7.5)]
pins=[(9,9),(W-9,9),(9,W-9),(W-9,W-14)]   # one pin offset = only closes one way
PIN_D=6.35; PIN_DEPTH=8.0
A=trimesh.creation.box([W,W,T]).apply_translation([W/2,W/2,T/2])
cuts=[cav, slab(sprue,3.0), slab(runner,2.5), slab(gate,1.5)]+[slab(v,0.1) for v in vents]
cuts+=[trimesh.creation.cylinder(PIN_D/2,PIN_DEPTH+0.5,sections=64).apply_translation([x,y,T-PIN_DEPTH/2+0.25]) for x,y in pins]
A=A.difference(trimesh.boolean.union(cuts))
B=trimesh.creation.box([W,W,T]).apply_translation([W/2,W/2,T/2])
pinsB=[(W-x,y) for x,y in pins]
B=B.difference(trimesh.boolean.union([trimesh.creation.cylinder(PIN_D/2,PIN_DEPTH+0.5,sections=64).apply_translation([x,y,T-PIN_DEPTH/2+0.25]) for x,y in pinsB]))
print('A watertight',A.is_watertight,A.bounds,'B',B.is_watertight)
A.export('Molde_A_cavidad.stl'); B.export('Molde_B_tapa.stl')
# check cavity = part volume
print('cavity vol',W*W*T-A.volume, 'part',part.volume)
# ---- stepped 2D regions for free Easel
def region(z):
    s=part.section([0,0,1],[0,0,z]); p,M=s.to_2D(); polys=[]
    for pf in p.polygons_full:
        def tr(c):
            c=np.array(c); q=np.c_[c,np.zeros(len(c)),np.ones(len(c))]@M.T
            return q[:,:2]+[W/2-(b[0,0]+b[1,0])/2, PY-b[0,1]]
        polys.append(Polygon(tr(pf.exterior.coords),[tr(i.coords) for i in pf.interiors]))
    return unary_union(polys).buffer(0)
R1=region(-0.29); R2=region(0.95); R3=region(1.5)
import json
def path_d(g):
    gs=g.geoms if hasattr(g,'geoms') else [g]; d=''
    for p in gs:
        for ring in [p.exterior]+list(p.interiors):
            c=list(ring.coords)
            d+='M '+' L '.join(f'{x:.3f} {W-y:.3f}' for x,y in c)+' Z '
    return d
def svg(items,fname,title):
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="76.2mm" height="76.2mm" viewBox="0 0 76.2 76.2">',
       f'<title>{title}</title>',
       f'<rect x="0" y="0" width="76.2" height="76.2" fill="none" stroke="#999" stroke-width="0.1" id="CONTORNO_bloque_NO_CORTAR"/>']
    for name,g,depth,col in items:
        s.append(f'<path id="{name}_prof_{depth}mm" d="{path_d(g)}" fill="{col}" fill-rule="evenodd" stroke="none"/>')
    s.append('</svg>'); open(fname,'w').write('\n'.join(s))
pinpolys=unary_union([Point(p).buffer(PIN_D/2,64) for p in pins])
itemsA=[('1_contorno_pieza',R1,0.8,'#9ecae1'),('2_base_pieza',R2,1.3,'#4292c6'),('3_anillo',R3,2.3,'#08306b'),
        ('4_entrada_boquilla',sprue.intersection(box(0,0,W,W)),3.0,'#e6550d'),('5_canal',runner,2.5,'#fd8d3c'),('6_compuerta',gate,1.5,'#fdae6b'),
        ('7_venteos',unary_union(vents).intersection(box(0,0,W,W)).difference(R1),0.1,'#31a354'),('8_pernos',pinpolys,8.0,'#636363')]
svg(itemsA,'Molde_A_cavidad.svg','Molde A - cavidad')
svg([('1_pernos',unary_union([Point(p).buffer(PIN_D/2,64) for p in pinsB]),8.0,'#636363')],'Molde_B_tapa.svg','Molde B - tapa plana')
json.dump({'pinsA':pins,'pinsB':pinsB,'outline_bounds':outline.bounds},open('info_molde.json','w'))
print(outline.bounds, R1.area,R2.area,R3.area)
