import trimesh,numpy as np,json
from trimesh.creation import box as tbox, cylinder
W=76.2; T=12.7; SP=19.05; EP=6.35
gx=38.1
def bx(x0,y0,z0,x1,y1,z1): return tbox([x1-x0,y1-y0,z1-z0]).apply_translation([(x0+x1)/2,(y0+y1)/2,(z0+z1)/2])
def cyl(x,y,z0,z1,d): return cylinder(d/2,z1-z0,sections=48).apply_translation([x,y,(z0+z1)/2])
# Z stack (z=0 bottom of placa base)
Z_BASE=(0,T); Z_SP=(T,T+SP); Z_A=(T+SP,2*T+SP); Z_B=(2*T+SP,3*T+SP)
Z_BACK=(T,T+EP); Z_RET=(T+EP,T+2*EP)
FACE=Z_A[1]
# ---- positions
ej=[(gx,36.0,1.3,'centro'),(gx,47.25,2.3,'anillo arriba'),(28.357,30.375,2.3,'anillo izq'),(47.843,30.375,2.3,'anillo der'),(gx,13.0,2.5,'canal')]
ret=[(gx-17.1,12),(gx+17.1,12),(gx-17.1,66),(gx+17.1,66)]
m3=[(21,25),(W-21,25),(21,52),(W-21,52)]
m5=[(6.35,26),(W-6.35,26),(6.35,50),(W-6.35,50)]
EJ_D=3.0; EJ_HD=6.0; EJ_HT=3.0; RP_D=6.0; RP_HD=10.0; RP_HT=5.0
EPX=(14.1,62.1); EPY=(3.1,73.1)
# ---- Plate A: previous mold A (z 0..T) moved up, plus holes
A=trimesh.load('Molde_A_cavidad.stl').apply_translation([0,0,Z_A[0]])
cutsA=[cyl(x,y,Z_A[0]-1,FACE+1,EJ_D) for x,y,_,_ in ej]+[cyl(x,y,Z_A[0]-1,FACE+1,RP_D+0.1) for x,y in ret]+[cyl(x,y,Z_A[0]-1,Z_A[0]+10,4.2) for x,y in m5]
A=A.difference(trimesh.boolean.union(cutsA))
B=trimesh.load('Molde_B_tapa.stl')
# B on top, face down: mirror x then flip z
B.apply_transform(np.diag([1,1,-1,1])); B.apply_translation([0,0,T]); 
B.apply_transform(trimesh.transformations.reflection_matrix([gx,0,0],[1,0,0])); B.apply_translation([0,0,Z_B[0]])
B.fix_normals()
# spacers
SPs=[bx(0,0,Z_SP[0],12.7,W,Z_SP[1]),bx(W-12.7,0,Z_SP[0],W,W,Z_SP[1])]
SPs=[s.difference(trimesh.boolean.union([cyl(x,y,Z_SP[0]-1,Z_SP[1]+1,5.5) for x,y in m5])) for s in SPs]
# placa base
BASE=bx(0,0,0,W,W,T)
BASE=BASE.difference(trimesh.boolean.union([cyl(gx,gx,-1,T+1,16.5)]+[cyl(x,y,-1,T+1,5.5) for x,y in m5]+[cyl(x,y,-1,5.5,9.5) for x,y in m5]))
# placa expulsora (backing) and porta-botadores (retainer)
BACK=bx(EPX[0],EPY[0],Z_BACK[0],EPX[1],EPY[1],Z_BACK[1])
BACK=BACK.difference(trimesh.boolean.union([cyl(x,y,Z_BACK[0]-1,Z_BACK[1]+1,3.4) for x,y in m3]+[cyl(x,y,Z_BACK[0]-1,Z_BACK[0]+3.2,6.0) for x,y in m3]))
RET=bx(EPX[0],EPY[0],Z_RET[0],EPX[1],EPY[1],Z_RET[1])
RET=RET.difference(trimesh.boolean.union([cyl(x,y,Z_RET[0]-1,Z_RET[1]+1,EJ_D+0.2) for x,y,_,_ in ej]+[cyl(x,y,Z_RET[0]-1,Z_RET[0]+EJ_HT+0.1,EJ_HD+0.5) for x,y,_,_ in ej]
   +[cyl(x,y,Z_RET[0]-1,Z_RET[1]+1,RP_D+0.2) for x,y in ret]+[cyl(x,y,Z_RET[0]-1,Z_RET[0]+RP_HT+0.1,RP_HD+0.5) for x,y in ret]
   +[cyl(x,y,Z_RET[0]-1,Z_RET[1]+1,2.5) for x,y in m3]))
# pins
pins=[]; table=[]
for x,y,dep,name in ej:
    top=FACE-dep; L=top-Z_RET[0]
    pins.append(trimesh.boolean.union([cyl(x,y,Z_RET[0],Z_RET[0]+EJ_HT,EJ_HD),cyl(x,y,Z_RET[0],top,EJ_D)])); table.append(('Botador Ø3 '+name,round(L,2)))
for x,y in ret:
    L=FACE-Z_RET[0]; pins.append(trimesh.boolean.union([cyl(x,y,Z_RET[0],Z_RET[0]+RP_HT,RP_HD),cyl(x,y,Z_RET[0],FACE,RP_D)])); table.append(('Retorno Ø6',round(L,2)))
parts={'1_Placa_B_fija':B,'2_Placa_A_cavidad':A,'3_Separador_izq':SPs[0],'4_Separador_der':SPs[1],'5_Porta_botadores':RET,'6_Placa_expulsora':BACK,'7_Placa_base':BASE}
for k,v in parts.items(): print(k,v.is_watertight,np.round(v.bounds,2).tolist())
json.dump({'ej':ej,'ret':ret,'m3':m3,'m5':m5,'table':table,'EPX':EPX,'EPY':EPY},open('info_expulsion.json','w'))
import pickle; pickle.dump((parts,pins),open('parts.pkl','wb'))
print(table)
