import json, sys

PLC_HOST = sys.argv[1] if len(sys.argv) > 1 else "${PLC_IP}"   # ${PLC_IP} lo llena autoplc
PLC_PORT = sys.argv[3] if len(sys.argv) > 3 else "${PLC_PORT}"
OUT = sys.argv[2] if len(sys.argv) > 2 else "flujo_inyectora.json"
Z = "tab_iny"
nodes = []
def add(n): nodes.append(n); return n

add({"id": Z, "type": "tab", "label": "Inyectora PUA", "disabled": False,
     "info": "Tablero SCADA de la inyectora PUA.\nLee el FX5U por SLMP (MC Protocol 3E) cada 0.5 s y lo muestra en /dashboard."})

# ---------- configuracion ----------
add({"id": "cfg_plc", "type": "MC Protocol Connection", "name": "FX5U inyectora", "host": PLC_HOST, "port": PLC_PORT,
     "protocol": "TCP", "frame": "3E", "plcType": "Q", "ascii": False, "PLCStation": "", "PCStation": "",
     "PLCModuleNo": "", "network": "", "octalInputOutput": True, "timeout": "1500"})
add({"id": "ui_base", "type": "ui-base", "name": "Inyectora", "path": "/dashboard", "appIcon": "", "includeClientData": True,
     "acceptsClientConfig": ["ui-notification", "ui-control"], "showPathInSidebar": False, "headerContent": "page",
     "navigationStyle": "none", "titleBarStyle": "default", "showReconnectNotification": True, "notificationDisplayTime": 1,
     "showDisconnectNotification": True, "allowInstall": True})
add({"id": "ui_theme", "type": "ui-theme", "name": "Planta",
     "colors": {"surface": "#3C3C3C", "primary": "#3559A8", "bgPage": "#8D8D8B", "groupBg": "#D6D6D4", "groupOutline": "#3C3C3C"},
     "sizes": {"density": "default", "pagePadding": "12px", "groupGap": "12px", "groupBorderRadius": "8px", "widgetGap": "12px"}})
add({"id": "ui_page", "type": "ui-page", "name": "Inyectora PUA", "ui": "ui_base", "path": "/inyectora", "icon": "factory",
     "layout": "grid", "theme": "ui_theme",
     "breakpoints": [{"name": "Default", "px": 0, "cols": 3}, {"name": "Tablet", "px": 576, "cols": 6},
                     {"name": "Small Desktop", "px": 768, "cols": 9}, {"name": "Desktop", "px": 1024, "cols": 12}],
     "order": 1, "className": "", "visible": "true", "disabled": "false"})
def group(gid, name, width, order):
    return add({"id": gid, "type": "ui-group", "name": name, "page": "ui_page", "width": str(width), "height": "1",
                "order": order, "showTitle": True, "className": "", "visible": "true", "disabled": "false", "groupType": "default"})
group("g_panel", "Inyectora PUA - HMI", 12, 1)
group("g_temp", "Nivel de material en la tolva", 12, 2)

# ---------- lectura ----------
LECTURAS = [("D100,2", "temp_sp"), ("D110,2", "molde"), ("D120,2", "meta_pz"), ("D140,1", "laser"),
            ("D150,2", "xy"), ("M50,2", "m50"), ("M70,8", "alarmas"), ("M100,10", "pasos"), ("M20,1", "sim"), ("M10,1", "marcha"), ("M60,1", "falla")]
add({"id": "inj_leer", "type": "inject", "z": Z, "name": "cada 0.5 s", "props": [{"p": "payload"}], "repeat": "0.5",
     "crontab": "", "once": True, "onceDelay": "1", "topic": "", "payload": "true", "payloadType": "bool",
     "x": 130, "y": 140, "wires": [[f"rd_{i}" for i in range(len(LECTURAS))]]})
for i, (addr, key) in enumerate(LECTURAS):
    y = 60 + i * 50
    add({"id": f"rd_{i}", "type": "MC Read", "z": Z, "name": addr, "topic": key, "connection": "cfg_plc", "address": addr,
         "addressType": "str", "outputFormat": "1", "errorHandling": "msg", "outputs": 1, "x": 330, "y": y, "wires": [[f"sv_{i}"]]})
    add({"id": f"sv_{i}", "type": "function", "z": Z, "name": f"guardar {key}",
         "func": ("if (msg.error || msg.payload === null || msg.payload === undefined) {\n"
                  "    flow.set('error', String(msg.error || 'sin respuesta'));\n    flow.set('ultimoError', Date.now());\n    return null;\n}\n"
                  f"let v = msg.payload;\nif (!Array.isArray(v)) v = [v];\nflow.set('{key}', v);\nflow.set('ultimaLectura', Date.now());\nreturn null;"),
         "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 540, "y": y, "wires": [[]]})

ARMAR = r"""
// Junta todas las lecturas en un solo objeto "estado" y detecta alarmas nuevas.
const g = k => flow.get(k) || [];
const n = v => Number(v) || 0;
const b = v => (v === true || v === 1 || v === '1') ? 1 : 0;
const PASOS = ['Reposo','Calentando','Cerrando molde','Inyectando','Sosteniendo presion','Subiendo embolo','Enfriando','Abriendo molde','Expulsando pieza','Lote completo'];
const ALM = [['M70','PARO DE EMERGENCIA ACTIVADO',2],['M71','SENSOR NO CONFIRMA POSICION',2],['M72','MOLDE MONTADO NO COINCIDE',2],['M73','FALTA MATERIAL EN TOLVA',2],['M74','CICLO DETENIDO POR PARO',1],['M75','CALENTANDO, ESPERE',1],['M76','CICLO TERMINADO',1],['M77','LOTE COMPLETO',1]];
const XN = ['X0 Iniciar','X1 Paro','X2 Paro emergencia','X3 Reset','X4 (sin uso)','X5 S1 molde abierto','X6 S2 molde cerrado','X7 S3 embolo arriba','X10 S4 embolo abajo'];
const YN = ['Y0 Resistencias','Y1 Cerrar molde','Y2 Bajar embolo','Y3 Abrir molde','Y4 Subir embolo','Y5 Torreta verde','Y6 Torreta ambar','Y7 Torreta roja'];
const ts = g('temp_sp'), mo = g('molde'), mp = g('meta_pz'), xy = g('xy'), m50 = g('m50'), al = g('alarmas').map(b), pa = g('pasos').map(b);
const vivo = Date.now() - (flow.get('ultimaLectura') || 0) < 3000;
const paso = Math.max(0, pa.indexOf(1));
const activas = ALM.filter((a, i) => al[i]).map(a => ({bit: a[0], msg: a[1], nivel: a[2]}));
// historial: compara con la lectura anterior
const antes = flow.get('activasAntes') || [];
const ahoraBits = activas.map(a => a.bit);
const hist = flow.get('hist') || [];
const D = new Date(), z2 = v => String(v).padStart(2, '0');
const fecha = `${D.getFullYear()}-${z2(D.getMonth() + 1)}-${z2(D.getDate())} ${z2(D.getHours())}:${z2(D.getMinutes())}:${z2(D.getSeconds())}`;
const lineas = [];
ALM.forEach(a => {
    const on = ahoraBits.includes(a[0]), was = antes.includes(a[0]);
    if (vivo && on !== was) {
        const ev = {fecha, bit: a[0], mensaje: a[1], evento: on ? 'OCURRIO' : 'RESET'};
        hist.unshift(ev); lineas.push(`${fecha},${a[0]},${a[1]},${ev.evento}`);
    }
});
if (vivo) flow.set('activasAntes', ahoraBits);
flow.set('hist', hist.slice(0, 50));
// produccion: cada vez que D121 sube se registra la pieza con su tiempo de ciclo
const pzAhora = n(mp[1]), pzAntes = flow.get('pzAntes');
let lineaPz = null;
const piezasT = flow.get('piezasT') || [];          // marcas de tiempo de las piezas (ultima hora)
if (vivo && pzAntes !== undefined && pzAhora > pzAntes) {
    const ahoraMs = Date.now(), ultima = flow.get('ultimaPieza') || 0;
    const ciclo = ultima ? ((ahoraMs - ultima) / 1000).toFixed(1) : '';
    flow.set('ultimaPieza', ahoraMs); flow.set('ultimoCiclo', ciclo);
    piezasT.push(ahoraMs);
    lineaPz = `${fecha},${pzAhora},${n(mp[0])},${ciclo},${n(mo[0])},${Math.max(0, Math.min(100, n(g('laser')[0])))}`;
}
if (vivo) flow.set('pzAntes', pzAhora);
const hora1 = Date.now() - 3600000;
while (piezasT.length && piezasT[0] < hora1) piezasT.shift();
flow.set('piezasT', piezasT);
const red = flow.get('red') || null;
const redVieja = Date.now() - (flow.get('redHora') || 0) > 30000;
const estado = {
    red: redVieja ? {estado: 'autoplc no esta corriendo', equipos: []} : red,
    conectado: vivo, error: vivo ? '' : (flow.get('error') || 'esperando datos del PLC'),
    hora: new Date().toLocaleTimeString('es-MX', {hour12: false}),
    temp: n(ts[0]), sp: n(ts[1]), molde: n(mo[0]), montado: n(mo[1]), meta: n(mp[0]), piezas: n(mp[1]),
    laser: n(g('laser')[0]), tolva: Math.max(0, Math.min(100, n(g('laser')[0]))), rr: b(m50[0]), moldeOk: b(m50[1]),
    paso, pasoNombre: PASOS[paso], alarmas: activas,
    bits: {y0: (n(xy[1]) >> 0) & 1, y1: (n(xy[1]) >> 1) & 1, y2: (n(xy[1]) >> 2) & 1, m10: b(g('marcha')[0]), m60: b(g('falla')[0]), m73: al[3] || 0, m51: b(m50[1]), m103: pa[3] || 0, m108: pa[8] || 0},
    sim: b(g('sim')[0]), piezasHora: piezasT.length, ciclo: flow.get('ultimoCiclo') || '-', hist: hist.slice(0, 15),
    x: XN.map((nm, i) => ({n: nm, v: (n(xy[0]) >> i) & 1})), y: YN.map((nm, i) => ({n: nm, v: (n(xy[1]) >> i) & 1}))
};
flow.set('estado', estado);
return [
    {payload: estado},
    vivo ? {topic: 'Nivel %', payload: estado.tolva} : null,
    vivo ? {topic: 'Minimo (alarma M73)', payload: 10} : null,
    lineas.length ? {payload: lineas.join('\n'), filename: (env.get('HOME') || '/home/pi') + '/alarmas.csv'} : null,
    lineaPz ? {payload: lineaPz, filename: (env.get('HOME') || '/home/pi') + '/produccion.csv'} : null
];
"""
add({"id": "inj_armar", "type": "inject", "z": Z, "name": "armar cada 0.5 s", "props": [{"p": "payload"}], "repeat": "0.5",
     "crontab": "", "once": True, "onceDelay": "1.5", "topic": "", "payload": "", "payloadType": "date",
     "x": 150, "y": 520, "wires": [["fn_armar"]]})
add({"id": "fn_armar", "type": "function", "z": Z, "name": "armar estado", "func": ARMAR.strip(), "outputs": 5,
     "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 360, "y": 520,
     "wires": [["ui_panel"], ["ui_chart"], ["ui_chart"], ["csv_file"], ["csv_head"]]})
add({"id": "csv_file", "type": "file", "z": Z, "name": "alarmas.csv", "filename": "filename", "filenameType": "msg",
     "appendNewline": True, "createDir": True, "overwriteFile": "false", "encoding": "utf8", "x": 590, "y": 580, "wires": [[]]})
CSV_HEAD = r"""if (!fs.existsSync(msg.filename)) msg.payload = 'fecha,pieza,meta,ciclo_s,molde,tolva_%\n' + msg.payload;
return msg;"""
# produccion.csv: si el archivo es nuevo le pone encabezado
add({"id": "csv_head", "type": "function", "z": Z, "name": "encabezado si es nuevo",
     "func": CSV_HEAD,
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [{"var": "fs", "module": "fs"}],
     "x": 590, "y": 620, "wires": [["csv_prod"]]})
add({"id": "csv_prod", "type": "file", "z": Z, "name": "produccion.csv", "filename": "filename", "filenameType": "msg",
     "appendNewline": True, "createDir": True, "overwriteFile": "false", "encoding": "utf8", "x": 800, "y": 620, "wires": [[]]})

import base64, os
_IMG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "maquina.jpg")
MAQ = "data:image/jpeg;base64," + base64.b64encode(open(_IMG, "rb").read()).decode()
PANEL = r"""<template>
  <div class="hmi-wrap" v-if="msg && msg.payload">
    <div class="estado">
      <span :class="['chip', p.conectado ? 'ok' : 'bad']">{{ p.conectado ? 'PLC EN LINEA ' + p.hora : 'SIN PLC: ' + p.error }}</span>
      <span class="chip">PASO M{{ 100 + p.paso }} · {{ p.pasoNombre }}</span>
      <span v-if="p.red && p.red.plc_ip" class="chip">PLC {{ p.red.plc_ip }}</span>
      <span v-if="p.sim" class="chip warn">MODO SIMULACION (M20)</span>
    </div>
    <!-- Pantalla igual a la B-3 del GOT (800x480) -->
    <div class="hmi">
      <img class="maq" :src="maq" alt="">
      <div v-for="l in lamparasMaq" :key="l.k" :class="['lmp','sm', l.on ? l.c : '']" :style="{left: l.x + '%', top: l.y + '%'}" :title="l.t"></div>
      <div class="lbl" style="left:49.8%;top:7%">Piezas Hechas:</div>
      <div class="lbl" style="left:65.8%;top:7%">Meta Programada:</div>
      <div class="seg" style="left:55%;top:14%;width:12%">{{ p.piezas }}</div>
      <div class="seg" style="left:70.5%;top:14%;width:12%">{{ p.meta }}</div>
      <div :class="['lmp','big', b.m60 ? 'r' : '']" style="left:65.1%;top:45.2%" title="Falla M60"></div>
      <div class="seg" style="left:72%;top:37%;width:10%">{{ p.tolva }}</div>
      <div class="unit" style="left:81%;top:47%">%</div>
      <div :class="['lmp','big', b.m73 ? 'r' : '']" style="left:89%;top:16.3%" title="Falta material M73"></div>
      <div class="lbl c" style="left:89%;top:23.5%">Material</div>
      <div :class="['lmp','big', b.m51 ? 'g' : '']" style="left:89%;top:49.2%" title="Molde correcto M51"></div>
      <div class="lbl c" style="left:89%;top:56.5%">Molde</div>
      <div :class="['lmp','big', b.m10 ? 'g' : '']" style="left:89%;top:82.5%" title="Produccion M10"></div>
      <div class="lbl c" style="left:89%;top:89.8%">Producción</div>
      <div class="lbl" style="left:48.2%;top:63.5%">&gt;&gt; START CICLO &lt;&lt;</div>
      <div class="lbl" style="left:66.8%;top:63.5%">RESET CONTADOR</div>
      <button class="hbtn g" style="left:48.2%;top:67.3%" @click="cmd('iniciar')"></button>
      <button class="hbtn b" style="left:66.3%;top:67.3%" @click="cmd('reset')"></button>
    </div>
    <!-- barra de tolva como en la pantalla B-1 -->
    <div class="panel fila">
      <div class="barra"><i :style="{height: p.tolva + '%'}"></i><span>{{ p.tolva }} %</span></div>
      <div class="col">
        <div class="tit">NIVEL DE TOLVA (D140) · sensor de distancia</div>
        <div class="kpis">
          <div><small>Piezas última hora</small><b>{{ p.piezasHora }}</b></div>
          <div><small>Último ciclo</small><b>{{ p.ciclo }} s</b></div>
          <div><small>Sistema listo (M50)</small><b>{{ p.rr ? 'SI' : 'NO' }}</b></div>
        </div>
        <div class="btns">
          <button class="hbtn2 r" @click="cmd('paro')">PARO</button>
          <button :class="['hbtn2', p.sim ? 'a' : 'gr']" @click="simular(!p.sim)">{{ p.sim ? 'SIMULACION ON' : 'SIMULACION OFF' }}</button>
          <label>META <input type="number" min="1" max="999" v-model.number="meta"></label>
          <button class="hbtn2 b" @click="guardarMeta">GUARDAR META</button>
          <a class="dl" href="/api/produccion.csv">produccion.csv</a>
        </div>
        <div class="nota">{{ nota }}</div>
      </div>
    </div>
    <div class="panel">
      <div class="tit">ALARMAS</div>
      <div v-for="a in p.alarmas" :key="a.bit" :class="['alarm', a.nivel === 1 ? 'info' : '']">{{ a.bit }} · {{ a.msg }}</div>
      <div v-if="!p.alarmas.length" class="none">Sin alarmas</div>
    </div>
    <div class="panel io">
      <div><div class="tit">ENTRADAS</div><div v-for="i in p.x" :key="i.n"><span :class="['led', i.v ? 'on' : '']"></span>{{ i.n }}</div></div>
      <div><div class="tit">SALIDAS</div><div v-for="i in p.y" :key="i.n"><span :class="['led', i.v ? 'on' : '']"></span>{{ i.n }}</div></div>
    </div>
    <div class="panel">
      <div class="tit">HISTORIAL DE ALARMAS</div>
      <table>
        <thead><tr><th>Fecha y hora</th><th>Bit</th><th>Mensaje</th><th>Evento</th></tr></thead>
        <tbody>
          <tr v-for="(h, k) in p.hist" :key="k"><td>{{ h.fecha }}</td><td>{{ h.bit }}</td><td>{{ h.mensaje }}</td><td>{{ h.evento }}</td></tr>
          <tr v-if="!p.hist.length"><td colspan="4" class="none">Sin eventos</td></tr>
        </tbody>
      </table>
    </div>
  </div>
  <div v-else class="none">Esperando datos del PLC…</div>
</template>
<script>
export default {
  data () { return { meta: 10, nota: '', maq: '__MAQ__' } },
  computed: {
    p () { return this.msg.payload },
    b () { return this.msg.payload.bits || {} },
    lamparasMaq () {
      const b = this.b
      return [
        {k: 1, x: 17.9, y: 23.5, on: b.y2, c: 'g', t: 'Cilindro neumatico (Y2)'},
        {k: 2, x: 26, y: 37.1, on: b.m73, c: 'r', t: 'Tolva sin material (M73)'},
        {k: 3, x: 26, y: 53.8, on: b.y0, c: 'o', t: 'Resistencias (Y0)'},
        {k: 4, x: 26, y: 63.5, on: b.y0, c: 'o', t: 'Banda calefactora (Y0)'},
        {k: 5, x: 26, y: 73.5, on: b.y1, c: 'g', t: 'Sujecion del molde (Y1)'},
        {k: 6, x: 26, y: 83.5, on: b.m108, c: 'g', t: 'Expulsando (M108)'},
        {k: 7, x: 26, y: 90, on: b.m103, c: 'g', t: 'Inyectando (M103)'}
      ]
    }
  },
  methods: {
    simular (on) { this.send({ topic: 'sim', payload: on }); this.nota = on ? 'Modo simulacion encendido' : 'Modo simulacion apagado' },
    cmd (orden) { this.send({ topic: 'cmd', payload: orden }); this.nota = 'Enviado: ' + orden },
    guardarMeta () {
      if (!(this.meta >= 1 && this.meta <= 999)) { this.nota = 'La meta debe ser de 1 a 999'; return }
      this.send({ topic: 'meta', payload: this.meta }); this.nota = 'Meta enviada a D120'
    }
  }
}
</script>
<style scoped>
.hmi-wrap{display:grid;gap:12px;font-family:Consolas,'Courier New',monospace;color:#1d1d1d}
.estado{display:flex;flex-wrap:wrap;gap:6px}
.chip{font-size:12px;padding:3px 10px;border:1px solid #6f6f6d;background:#d6d6d4;border-radius:2px}
.chip.ok{background:#2f9e44;color:#fff;border-color:#1f6e2f}.chip.bad{background:#c92a2a;color:#fff;border-color:#8a1c1c}.chip.warn{background:#e8a317;color:#000}
.hmi{position:relative;width:100%;max-width:960px;aspect-ratio:800/480;background:#bebebc;border:6px solid #3c3c3c;border-radius:6px;box-shadow:inset 0 0 0 2px #8d8d8b;overflow:hidden;container-type:inline-size}
.maq{position:absolute;left:0;top:0;width:48.1%;height:100%;object-fit:fill}
.lbl{position:absolute;font-size:1.65cqw;white-space:nowrap}
.lbl.c{transform:translateX(-50%)}
.unit{position:absolute;font-size:3cqw;color:#fff;text-shadow:0 0 2px #000}
.seg{position:absolute;text-align:center;font-size:7.4cqw;line-height:1;color:#fff;font-weight:100;transform:scaleY(1.45);transform-origin:top;-webkit-text-stroke:.15cqw #2b2b2b;letter-spacing:-.04em}
.lmp{position:absolute;border-radius:50%;transform:translate(-50%,-50%);background:radial-gradient(circle at 50% 45%,#4a2a2c 0,#2a1214 55%,#120607 100%);box-shadow:0 0 0 .35cqw #b9b9b9,0 0 0 .6cqw #555,inset 0 -.6cqw 1cqw rgba(255,255,255,.08)}
.lmp.big{width:8.2cqw;height:8.2cqw}.lmp.sm{width:3.3cqw;height:3.3cqw}
.lmp.g{background:radial-gradient(circle at 50% 40%,#e8ffe8 0,#5cf06a 35%,#18a52c 75%,#0d6b1c 100%);box-shadow:0 0 0 .35cqw #b9b9b9,0 0 0 .6cqw #555,0 0 2cqw #4cff64}
.lmp.r{background:radial-gradient(circle at 50% 40%,#ffe9e9 0,#ff7a7a 35%,#e02424 75%,#8a0d0d 100%);box-shadow:0 0 0 .35cqw #b9b9b9,0 0 0 .6cqw #555,0 0 2cqw #ff4040}
.lmp.o{background:radial-gradient(circle at 50% 40%,#fff1e2 0,#ffb066 35%,#f07818 75%,#9a4808 100%);box-shadow:0 0 0 .35cqw #b9b9b9,0 0 0 .6cqw #555,0 0 2cqw #ff9a3c}
.hbtn{position:absolute;width:15.8cqw;height:16.3cqw;border:.5cqw solid #2c2c2c;outline:.35cqw solid #e0e0de;cursor:pointer;padding:0}
.hbtn.g{background:linear-gradient(#5cc46c,#2f8f3f 55%,#24742f)}.hbtn.b{background:linear-gradient(#5f86d6,#3559a8 55%,#284684)}
.hbtn:active{filter:brightness(1.3);transform:translateY(1px)}
.panel{background:#bebebc;border:3px solid #3c3c3c;border-radius:4px;padding:10px 12px;max-width:936px}
.tit{font-size:13px;letter-spacing:.08em;border-bottom:1px solid #8d8d8b;margin-bottom:6px;padding-bottom:3px}
.fila{display:flex;gap:16px;align-items:stretch}
.barra{position:relative;width:46px;min-height:150px;background:#bebebc;border:2px solid #fff;outline:1px solid #555}
.barra i{position:absolute;left:0;right:0;bottom:0;background:#2fdc3c;border-top:2px solid #fff}
.barra span{position:absolute;bottom:4px;left:50%;transform:translateX(-50%);font-size:11px;font-weight:700;white-space:nowrap}
.col{flex:1;display:grid;gap:8px}
.kpis{display:flex;flex-wrap:wrap;gap:18px}.kpis small{display:block;font-size:11px;color:#3d3d3d}.kpis b{font-size:22px;font-weight:600}
.btns{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.hbtn2{border:2px solid #2c2c2c;outline:2px solid #e0e0de;color:#fff;font-family:inherit;font-weight:700;padding:8px 14px;cursor:pointer}
.hbtn2.r{background:linear-gradient(#e05a5a,#b52a2a)}.hbtn2.b{background:linear-gradient(#5f86d6,#3559a8)}.hbtn2.a{background:linear-gradient(#f2c14e,#d08a10);color:#000}.hbtn2.gr{background:linear-gradient(#8d8d8b,#5d5d5b)}
.btns input{width:64px;padding:5px;border:2px solid #555;background:#fff;font-family:inherit}
.dl{color:#284684;font-size:13px}
.nota{font-size:12px;color:#3d3d3d;min-height:14px}
.alarm{background:#c92a2a;color:#fff;padding:6px 10px;font-weight:700;margin-bottom:4px;border:2px solid #6e1414}.alarm.info{background:#2f9e44;border-color:#1f6e2f}
.none{color:#4d4d4b;font-size:13px}
.io{display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;font-size:13px}
.led{display:inline-block;width:11px;height:11px;border-radius:50%;background:#3a1a1c;margin-right:6px;vertical-align:-1px;border:1px solid #777}.led.on{background:#2fdc3c;box-shadow:0 0 6px #2fdc3c}
table{width:100%;border-collapse:collapse;font-size:12px}th,td{text-align:left;padding:3px 6px;border-bottom:1px solid #9a9a98}
th{font-size:11px;color:#3d3d3d}
</style>""".replace("__MAQ__", MAQ)
add({"id": "ui_panel", "type": "ui-template", "z": Z, "group": "g_panel", "page": "", "ui": "", "name": "panel principal",
     "order": 1, "width": "0", "height": "0", "head": "", "format": PANEL, "storeOutMessages": True, "passthru": False,
     "resendOnRefresh": True, "templateScope": "local", "className": "", "x": 610, "y": 460, "wires": [["fn_mando"]]})
add({"id": "ui_chart", "type": "ui-chart", "z": Z, "group": "g_temp", "name": "nivel tolva", "label": "Nivel de tolva (%), ultimos 2 min",
     "order": 1, "chartType": "line", "category": "topic", "categoryType": "msg", "xAxisLabel": "", "xAxisProperty": "",
     "xAxisPropertyType": "timestamp", "xAxisType": "time", "xAxisFormat": "", "xAxisFormatType": "auto", "xmin": "", "xmax": "",
     "yAxisLabel": "%", "yAxisProperty": "payload", "yAxisPropertyType": "msg", "ymin": "0", "ymax": "100", "bins": 10,
     "action": "append", "stackSeries": False, "pointShape": "false", "pointRadius": 4, "showLegend": True,
     "removeOlder": "2", "removeOlderUnit": "60", "removeOlderPoints": "", "colors": ["#E0661A", "#5A655F", "#2457D6", "#17845A", "#C8322B", "#B7790F", "#6B5BB8", "#1F3B66", "#999999"],
     "textColor": ["#666666"], "textColorDefault": True, "gridColor": ["#e5e5e5"], "gridColorDefault": True,
     "width": "12", "height": "6", "className": "", "interpolation": "linear", "x": 600, "y": 520, "wires": [[]]})

MANDO = r"""
// Botones de la pagina -> pulso en el PLC. INICIAR=M0, PARO=M1, RESET=M2 (1 y a los 0.3 s, 0)
if (msg.topic === 'meta') {
    const v = Math.round(Number(msg.payload));
    if (!(v >= 1 && v <= 999)) return null;
    return [{topic: 'D120', payload: v}, null];
}
if (msg.topic === 'sim') return [{topic: 'M20', payload: !!msg.payload}, null];
const dev = {iniciar: 'M0', paro: 'M1', reset: 'M2'}[msg.payload];
if (!dev) return null;
return [{topic: dev, payload: true}, {topic: dev, payload: false}];
"""
add({"id": "fn_mando", "type": "function", "z": Z, "name": "orden -> pulso", "func": MANDO.strip(), "outputs": 2,
     "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 830, "y": 460, "wires": [["wr_plc"], ["dly_pulso"]]})
add({"id": "dly_pulso", "type": "delay", "z": Z, "name": "0.3 s", "pauseType": "delay", "timeout": "300", "timeoutUnits": "milliseconds",
     "rate": "1", "nbRateUnits": "1", "rateUnits": "second", "randomFirst": "1", "randomLast": "5", "randomUnits": "seconds",
     "drop": False, "allowrate": False, "outputs": 1, "x": 1010, "y": 500, "wires": [["wr_plc"]]})
add({"id": "wr_plc", "type": "MC Write", "z": Z, "name": "escribir en PLC", "topic": "", "connection": "cfg_plc",
     "data": "payload", "address": "topic", "addressType": "msg", "dataType": "msg", "errorHandling": "msg", "outputs": 1,
     "x": 1190, "y": 460, "wires": [[]]})

# ---------- reconexion (el nodo mcprotocol 1.2.1 no se reconecta solo) ----------
add({"id": "inj_recon", "type": "inject", "z": Z, "name": "cada 5 s", "props": [{"p": "payload"}], "repeat": "5",
     "crontab": "", "once": False, "onceDelay": "", "topic": "", "payload": "", "payloadType": "date",
     "x": 130, "y": 720, "wires": [["fn_recon"]]})
add({"id": "fn_recon", "type": "function", "z": Z, "name": "si no hay datos, reconectar",
     "func": "// Si en 3 s no llegan datos (PLC reiniciado, cable, socket colgado):\n// se cierra la conexion y se abre de nuevo 1 s despues.\nif (Date.now() - (flow.get('ultimaLectura') || 0) < 3000) return null;\nnode.status({fill: 'red', shape: 'ring', text: 'reconectando ' + new Date().toLocaleTimeString()});\nnode.send({topic: 'disconnect'});\nsetTimeout(() => node.send({topic: 'connect'}), 1000);\nreturn null;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 340, "y": 720, "wires": [["rd_0"]]})

# ---------- estado de la red (lo escribe el servicio autoplc) ----------
add({"id": "inj_red", "type": "inject", "z": Z, "name": "cada 5 s", "props": [{"p": "payload"}], "repeat": "5",
     "crontab": "", "once": True, "onceDelay": "2", "topic": "", "payload": "", "payloadType": "date",
     "x": 130, "y": 780, "wires": [["file_red"]]})
add({"id": "file_red", "type": "file in", "z": Z, "name": "/run/autoplc/estado.json", "filename": "/run/autoplc/estado.json",
     "filenameType": "str", "format": "utf8", "chunk": False, "sendError": False, "encoding": "utf8", "allProps": False,
     "x": 340, "y": 780, "wires": [["json_red"]]})
add({"id": "json_red", "type": "json", "z": Z, "name": "", "property": "payload", "action": "obj", "pretty": False,
     "x": 530, "y": 780, "wires": [["fn_red"]]})
add({"id": "fn_red", "type": "function", "z": Z, "name": "guardar red",
     "func": "flow.set('red', msg.payload);\nflow.set('redHora', Date.now());\nnode.status({fill: msg.payload.plc_ip ? 'green' : 'yellow', shape: 'dot', text: msg.payload.estado});\nreturn null;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 690, "y": 780, "wires": [[]]})

# ---------- API JSON (para revisar o usar desde otra app) ----------
add({"id": "http_in", "type": "http in", "z": Z, "name": "", "url": "/api/estado", "method": "get", "upload": False,
     "swaggerDoc": "", "x": 150, "y": 640, "wires": [["fn_api"]]})
add({"id": "fn_api", "type": "function", "z": Z, "name": "estado en JSON", "func": "msg.payload = flow.get('estado') || {};\nreturn msg;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 360, "y": 640, "wires": [["http_out"]]})
add({"id": "http_out", "type": "http response", "z": Z, "name": "", "statusCode": "", "headers": {}, "x": 560, "y": 640, "wires": []})

add({"id": "http_csv", "type": "http in", "z": Z, "name": "", "url": "/api/produccion.csv", "method": "get", "upload": False,
     "swaggerDoc": "", "x": 170, "y": 860, "wires": [["fn_csv"]]})
add({"id": "fn_csv", "type": "function", "z": Z, "name": "ruta del archivo",
     "func": "msg.filename = (env.get('HOME') || '/home/pi') + '/produccion.csv';\nreturn msg;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 380, "y": 860, "wires": [["file_csv"]]})
add({"id": "file_csv", "type": "file in", "z": Z, "name": "leer produccion.csv", "filename": "filename", "filenameType": "msg",
     "format": "utf8", "chunk": False, "sendError": False, "encoding": "utf8", "allProps": False, "x": 580, "y": 860, "wires": [["fn_csv2"]]})
add({"id": "fn_csv2", "type": "function", "z": Z, "name": "como descarga",
     "func": "if (msg.error || typeof msg.payload !== 'string') msg.payload = 'fecha,pieza,meta,ciclo_s,molde,tolva_%\\n';\nmsg.headers = {'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename=produccion.csv'};\nreturn msg;",
     "outputs": 1, "timeout": 0, "noerr": 0, "initialize": "", "finalize": "", "libs": [], "x": 780, "y": 860, "wires": [["http_out"]]})
add({"id": "catch_csv", "type": "catch", "z": Z, "name": "si no existe el csv", "scope": ["file_csv"], "uncaught": False,
     "x": 590, "y": 900, "wires": [["fn_csv2"]]})
for c, (t, x, y) in enumerate([
        ("1) LECTURA: cada 0.5 s se piden los registros del FX5U por SLMP y se guardan en variables del flujo", 400, 20),
        ("2) ARMADO: se juntan en un objeto 'estado', se detectan alarmas nuevas y se mandan al tablero", 380, 480),
        ("4) RECONEXION: si en 3 s no llegan datos, pide reconectar (cable desconectado, PLC apagado)", 380, 690),
        ("5) RED: el servicio autoplc encuentra al PLC y deja aqui su IP y los equipos del cable", 420, 750),
        ("3) MANDO: los botones del tablero mandan un pulso de 0.3 s a M0/M1/M2 o escriben la meta en D120", 940, 420)]):
    add({"id": f"cm_{c}", "type": "comment", "z": Z, "name": t, "info": "", "x": x, "y": y, "wires": []})

json.dump(nodes, open(OUT, "w"), indent=1, ensure_ascii=False)
print("ok", OUT, len(nodes), "nodos")
