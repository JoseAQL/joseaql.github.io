import pickle,numpy as np,trimesh,itertools,json
P=pickle.load(open('parts_m.pkl','rb'))['P']; D=json.load(open('dims_m.json')); S=D['S'];Q=D['Q']
def shift(g,t):
    s=S*t
    if g=='movil': return s
    if g=='expulsor': return s-max(0,s-(S-Q))
    return 0
# split concatenated meshes into bodies for robust booleans
def bodies(m):
    try: return [b for b in m.split(only_watertight=False)]
    except: return [m]
B=[(n,g,bodies(m)) for n,_,g,m in P]
BAR='Ejes lisos 12 mm (comprar)'; NUT='Tornillos de los ejes'; ROD='Tu varilla roscada ½"'; RP='Placa trasera (madera)'; FP='Placa fija (madera)'; MPL='Placa móvil (madera)'
TOR='Tornillos ⅜" pies–base'; MA='Molde A + separadores + placa base'; MB='Molde B (fijo)'; EX='Placas expulsoras + botadores'; LM='Baleros lineales LM12UU (comprar)'; HO='Soportes impresos de LM12UU'; HT='Tornillería soportes LM12UU'
IGN={frozenset(x) for x in [(BAR,NUT),(BAR,LM),(BAR,FP),(BAR,RP),(ROD,'Tuercas del tornillo'),(ROD,'Cople ½" (pegado en la caja hexagonal)'),(ROD,'Rondanas de bronce (comprar)'),(ROD,RP),
 (TOR,'Base (tu canal U)'),(TOR,'Pie delantero (madera)'),(TOR,'Pie trasero (madera)'),('Varillas expulsoras 5/16"',RP),(LM,HO),(HT,MPL),(HO,MPL),
 (EX,MA),(MB,MA),(EX,MB),(NUT,RP),(NUT,FP),('Tornillos del molde A',MPL),('Tornillos del molde A',MA),('Cople ½" (pegado en la caja hexagonal)',MPL),
 ('Placa fija (madera)','Pie delantero (madera)'),('Placa trasera (madera)','Pie trasero (madera)'),('Cartabón delantero (madera)','Pie delantero (madera)'),('Cartabones traseros (madera)','Pie trasero (madera)'),('Cartabón delantero (madera)',FP),('Cartabones traseros (madera)',RP),('Pie delantero (madera)','Base (tu canal U)'),('Pie trasero (madera)','Base (tu canal U)')]}
res={}
for t in (0,0.5,1.0):
    for (n1,g1,b1),(n2,g2,b2) in itertools.combinations(B,2):
        if frozenset((n1,n2)) in IGN: continue
        for a in b1:
            A=a.copy().apply_translation([shift(g1,t),0,0])
            for b in b2:
                Bm=b.copy().apply_translation([shift(g2,t),0,0])
                lo=np.maximum(A.bounds[0],Bm.bounds[0]); hi=np.minimum(A.bounds[1],Bm.bounds[1])
                if np.any(hi-lo<=0.05): continue
                try: v=A.intersection(Bm).volume
                except Exception as e: v=-1
                if abs(v)>1.0: res.setdefault((n1,n2),[]).append((t,round(v,1),np.round(lo,1).tolist(),np.round(hi,1).tolist()))
for k,v in res.items(): print(k,v[:2])
print('done',len(res))
