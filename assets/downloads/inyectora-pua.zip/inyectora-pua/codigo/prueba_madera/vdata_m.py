import pickle,json,base64,numpy as np
P=pickle.load(open('parts_m.pkl','rb'))['P']
COL={'U1':'#5b6670','U2':'#2a9d4f','T6':'#2f6db5','L25':'#7fc28f','A':'#e2611b','W':'#b5733f','P5':'#8a4fd1','print':'#13a3b4','compra':'#c9cfd4','tornillo':'#3d4247','molde':'#b8c2cc','varilla':'#9aa1a8','engrane':'#e9dcb5','pinon':'#ffffff','motor':'#2b2f33','ref':'#d62828'}
items=[]; tri=0
for n,mat,g,m in P:
    c=COL[mat]
    if n.startswith('Varillas expulsoras'): c='#f2b705'
    if n.startswith('Placas expulsoras'): c='#e0a526'
    if n.startswith('Molde B'): c='#a7b4c2'
    v=m.vertices[m.faces].astype(np.float32).ravel(); tri+=len(m.faces)
    items.append(dict(n=n,mat=mat,g=g,c=c,d=base64.b64encode(v.tobytes()).decode()))
D=json.load(open('dims_m.json'))
json.dump(dict(items=items,S=D['S'],Q=D['Q']),open('vdata_m.json','w'))
print(tri, round(len(open('vdata.json').read())/1e6,2),'MB')
