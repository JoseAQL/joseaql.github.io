import math,json,textwrap,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt, matplotlib.image as mpimg
from matplotlib.patches import Rectangle,Circle,Polygon as Pg
from matplotlib.backends.backend_pdf import PdfPages
exec(open('wood_cnc.py').read().split('# ---------- SVG + DXF')[0])
INK='#1d2329';MUT='#5d6873';RED='#c0392b';BLUE='#1f6fb2';WOOD='#e3c39a'
def page(t,sub=None,size=(11,8.5)):
    f=plt.figure(figsize=size); f.text(.04,.955,t,fontsize=17,weight='bold',color=INK)
    if sub: f.text(.04,.925,sub,fontsize=9.5,color=MUT)
    return f
def draw_piece(a,p,dims=True,fs=6.5,mirror=False):
    W,H=p['W'],p['H']; a.add_patch(Rectangle((0,0),W,H,fc=WOOD,ec=INK,lw=1.2))
    for h,v,d in p['holes']:
        hh=W-h if mirror else h
        a.add_patch(Circle((hh,v),d/2,fc='white',ec=RED,lw=1)); a.plot([hh-d/2-2,hh+d/2+2],[v,v],color=RED,lw=.35); a.plot([hh,hh],[v-d/2-2,v+d/2+2],color=RED,lw=.35)
    for pk in p['pockets']:
        xy=[(W-x if mirror else x,y) for x,y in pk.exterior.coords]; a.add_patch(Pg(xy,fc='#9a9a9a',ec=INK,lw=.8,alpha=.8))
    if dims:
        hs=sorted({round(W-h if mirror else h,1) for h,v,d in p['holes']}); vs=sorted({round(v,1) for h,v,d in p['holes']})
        for h in hs: a.text(h,-3,f'{h:g}',ha='center',va='top',fontsize=fs,color=BLUE,rotation=90)
        for v in vs: a.text(-2,v,f'{v:g}',ha='right',va='center',fontsize=fs,color=BLUE)
        a.text(W/2,H+2,f'{W:g} mm',ha='center',fontsize=fs+1); a.text(W+2,H/2,f'{H:g} mm',va='center',rotation=90,fontsize=fs+1)
    a.set_aspect('equal'); a.axis('off')
def tri(a,size):
    a.add_patch(Pg([(0,0),(size,0),(0,size)],fc=WOOD,ec=INK,lw=1.2)); a.text(size/4,size/4,f'{size} × {size}',fontsize=7); a.set_aspect('equal'); a.axis('off')
D_={}; exec(open('despiece_m.py').read(),D_)
with PdfPages('Prueba_madera_piezas_y_lista.pdf') as pdf:
    # 1 portada + lista
    f=page('Inyectora · prueba en madera — piezas y lista de materiales','Aglomerado de 15 mm (tus 2 tablas de 28 × 13 y 2 tiras de 28 × 7). Sirve para probar cierre, apertura y expulsión, no para inyectar.')
    for im,ax,t in [('m_iso.png',[.01,.47,.34,.43],'Cerrada'),('m_iso_ab.png',[.34,.47,.34,.43],'Abierta 25 mm')]:
        a=f.add_axes(ax); a.imshow(mpimg.imread(im)[80:1020,180:1420]); a.axis('off'); a.set_title(t,fontsize=10,loc='left',weight='bold')
    rows=[('W1','Placa fija','130 × 130 × 15','Tabla 1'),('W2','Placa trasera','130 × 130 × 15','Tabla 1'),('W3','Placa móvil','130 × 130 × 15','Tabla 2'),('WT','Plantilla (barrenar metal)','130 × 130 × 15','Tabla 2'),
          ('W4','Pie delantero','130 × 70 × 15','Tira 1'),('W5','Pie trasero','130 × 60 × 15','Tira 1'),('W6','Cartabones (3)','55, 42, 42 (triángulos)','Tira 2')]
    f.text(.7,.88,'Piezas de madera',fontsize=11,weight='bold')
    for i,r in enumerate(rows):
        y=.85-i*.033; f.text(.7,y,r[0],fontsize=8.5,color=RED,weight='bold'); f.text(.735,y,r[1],fontsize=8.5); f.text(.885,y,r[2],fontsize=7.5,color=MUT); f.text(.885,y-.013,r[3],fontsize=7,color=BLUE)
    bom=[('Ejes lisos cromados 12 mm × 180','4','machuelo M6 en las puntas'),('Balero lineal LM12UU','4',''),('Soporte impreso LM12UU (PETG)','4','2 normales + 2 en espejo'),
         ('Cople ½"-13 × 1¾"','1','epóxico en W3'),('Tu varilla ½" ',f'{X_RODEND-X_RODTIP:.0f} mm',''),('Tuerca ½"-13','3',''),('Rondana de bronce ½"','2','+1 rondana grande'),
         ('Varilla 5/16" + 4 tuercas + 4 rondanas',f'2 × {XR1+9-X_KO_TIP:.0f} mm','expulsoras'),('Hexagonal ⅜" × 2" + tuerca + 2 rondanas','4','pies a la base'),
         ('Allen M6 × 16 + rondana ancha','8','puntas de los ejes'),('Allen M5 × 20 + rondana','8','molde A y molde B'),('Allen M4 × 25 + tuerca M4','8','soportes LM12UU'),
         ('Allen M3 × 16 + tuerca M3','4','oreja de los soportes'),('Pija para madera #8 × 1½"','12','placas a pies y cartabones'),('Cola blanca + epóxico','—','')]
    f.text(.04,.42,'Lista de compras y tornillería',fontsize=11,weight='bold')
    for i,(a_,b_,c_) in enumerate(bom):
        col=i//8; y=.385-(i%8)*.04; x0=.04+col*.49
        f.text(x0,y,a_,fontsize=8.3); f.text(x0+.235,y,b_,fontsize=8.3,weight='bold'); f.text(x0+.3,y,c_,fontsize=7.2,color=MUT)
    pdf.savefig(f); plt.close(f)
    # 2 plano de corte
    f=page('Plano de corte — cómo sale cada pieza de tus tablas','Línea roja = corte. Círculos = barrenos. Hexágono gris = caja de 12 mm. Igual que los archivos para la CNC (cero = esquina inferior izquierda).')
    for k,sh in enumerate(SHEETS):
        a=f.add_axes([.04+(k%2)*.48,.5-(k//2)*.42,.44,.36]); W,H=sh['W'],sh['H']
        a.add_patch(Rectangle((0,0),W,H,fc='#f1ebe1',ec=INK,ls='--'))
        for p,x0,y0 in sh['place']:
            a.add_patch(Rectangle((x0,y0),p['W'],p['H'],fc=WOOD,ec=INK,lw=.6))
            for h,v,d in p['holes']: a.add_patch(Circle((x0+h,y0+v),d/2,fc='white',ec=INK,lw=.4))
            for pk in p['pockets']: a.add_patch(Pg([(x0+x,y0+y) for x,y in pk.exterior.coords],fc='#999',ec=INK,lw=.4))
            a.text(x0+p['W']/2,y0+p['H']/2+(0 if p['H']>80 else 0),p['id'],ha='center',va='center',fontsize=11,weight='bold',color=RED,alpha=.85)
        for (x1,y1),(x2_,y2_) in sh['lines']: a.plot([x1,x2_],[y1,y2_],color=RED,lw=1.4)
        for g,t in sh['polys']:
            a.add_patch(Pg(list(t.exterior.coords),fc=WOOD,ec=RED,lw=1.2)); a.text(t.centroid.x,t.centroid.y,'W6',fontsize=9,color=RED,weight='bold',ha='center')
        a.set_xlim(-8,W+8);a.set_ylim(-8,H+8);a.set_aspect('equal');a.axis('off');a.set_title(f"{sh['name'].replace('_',' ')}  ({W} × {H} mm)",fontsize=10,loc='left',weight='bold')
    pdf.savefig(f); plt.close(f)
    # 3 instrucciones CNC
    f=page('Cómo cortarlo en tu CNC','Dos formas: con Easel (vectores SVG) o mandando directo el G-code.')
    txt=['1. Material: fija la tira con prensas FUERA de las líneas rojas. Cinta masking encima de la melamina para que no se despostille.',
     '2. Cero: X0 Y0 en la esquina inferior izquierda de la tira (como en el plano de corte). Z0 en la cara de arriba.',
     '3. Fresa: plana de 1/8" (3.175 mm), mejor de 1 filo.',
     '   • Si tu fresa corta 12 mm de largo: usa los G-code "_fresa_largo_12mm". Hace todo a 12 mm de hondo; los barrenos los terminas con',
     '     taladro (el de la CNC sirve de guía) y los cortes con cutter o serrucho siguiendo la ranura.',
     '   • Si compras la de 22 mm de largo de corte (DSP1F-D3.1-L22, de la misma tienda): usa "_fresa_largo_22mm"; atraviesa los 15 mm.',
     '4. Orden dentro de cada archivo: barrenos → caja hexagonal (solo tabla 2) → cortes al final con 2 puentes de 2 mm por línea.',
     '   Los puentes se cortan con cutter y se lijan.',
     '5. Velocidades en el G-code: 12,000 rpm, avance 600 mm/min, bajando 1–1.5 mm por pasada. Si tu CNC sufre, baja el avance en GRBL (override).',
     '',
     'CON EASEL (SVG):',
     '   • Círculos negros → "Fill" (relleno) a 15.5 mm de hondo (o 12 si tu fresa es corta).',
     '   • Hexágono gris (tabla 2) → "Fill" a 12 mm de hondo. Va por la cara de ATRÁS de la placa móvil.',
     '   • Líneas rojas → "On path" (sobre la línea) a todo el grueso, con 2 puentes ("tabs").',
     '   • Triángulos rojos (tira 2) → "Outline" por AFUERA, con 2 puentes.',
     '   • El rectángulo gris es solo la referencia del material: no lo cortes.',
     '',
     'Revisa con la vista previa de Easel antes de cortar, y haz el primer corte con la fresa 1 mm arriba (en el aire) para ver el recorrido.']
    for i,t in enumerate(txt): f.text(.05,.87-i*.04,t,fontsize=9.4)
    pdf.savefig(f); plt.close(f)
    # plantillas 1:1 (carta vertical)
    PWm,PHm=215.9,279.4
    def tpl(items,title):
        f=plt.figure(figsize=(PWm/25.4,PHm/25.4)); a=f.add_axes([0,0,1,1]); a.set_xlim(0,PWm); a.set_ylim(0,PHm); a.axis('off')
        a.text(10,270,title+' · ESCALA 1:1 · imprime al 100 % ("tamaño real"), carta vertical',fontsize=7)
        a.plot([20,70],[12,12],color='k',lw=1.5); a.text(45,15,'50 mm (verifica con regla)',ha='center',fontsize=6)
        for fn,ox,oy,w,h in items:
            s=f.add_axes([ox/PWm,oy/PHm,(w+30)/PWm,(h+30)/PHm]); s.set_xlim(-15,w+15); s.set_ylim(-15,h+15); fn(s)
        pdf.savefig(f); plt.close(f)
    for p,mir,t in [(W1,False,'W1 PLACA FIJA (vista de frente). La WT es igual.'),(W2,False,'W2 PLACA TRASERA (vista de frente)'),(W3,True,'W3 PLACA MÓVIL (vista de FRENTE; la caja hexagonal va por ATRÁS)')]:
        tpl([(lambda s,p=p,m=mir: (draw_piece(s,p,mirror=m),s.text(p['W']/2,p['H']+8,p['id']+' '+p['name'],ha='center',fontsize=7,weight='bold')),(PWm-160)/2,90,130,130)],t)
    tpl([(lambda s: (draw_piece(s,W4),s.text(65,78,'W4 pie delantero (abajo = frente de la máquina)',ha='center',fontsize=7,weight='bold')),(PWm-160)/2,170,130,70),
         (lambda s: (draw_piece(s,W5),s.text(65,68,'W5 pie trasero (abajo = lado de la placa trasera)',ha='center',fontsize=7,weight='bold')),(PWm-160)/2,60,130,60)],'W4 y W5 PIES')
    tpl([(lambda s: (tri(s,55),s.text(0,62,'W6 cartabón delantero',fontsize=7,weight='bold')),20,160,55,55),(lambda s: (tri(s,42),s.text(0,48,'W6 cartabón trasero ×2',fontsize=7,weight='bold')),110,170,42,42)],'W6 CARTABONES')
print('ok')
