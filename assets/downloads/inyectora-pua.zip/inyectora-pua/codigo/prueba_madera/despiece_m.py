exec(open('geo_m.py').read().split('# ---------------- helpers')[0].split('def hb(y,z):')[0])
BASE_F=[(20.0,y) for y in(-46,46)]; BASE_R=[(260.0,y) for y in(-46,46)]
def hb(y,z):
    sy=1 if y>0 else -1; sz=1 if z>ZC else -1
    return [(y-22*sy,z+4*sz),(y+4*sy,z-22*sz)]
CNC='En tu CNC con fresa de ⅛": barrenos y cajas a 12 mm de hondo (lo que alcanza la fresa). Luego termina los barrenos con taladro, usando el de la CNC como guía. El contorno lo cortas a mano con serrucho.'
PARTS=[
 dict(id='W1',mesh=['Placa fija (madera)'],nombre='Placa fija',cant=1,origen='Tabla 1 (28 × 13 cm): primer cuadro',medidas='130 × 130 × 15 mm',
  proceso=[CNC,'Barrenos: 4 × Ø12.2 (ejes, que entren justos) y 4 × Ø5.5 (molde B).','Atorníllala al pie delantero: 3 pijas #8 × 1½" desde abajo, con barreno guía de 3 mm y cola blanca.','El cartabón va adelante al centro, con cola y 2 pijas.'],
  tornilleria=['4 Allen M5 × 20 al molde B desde el frente, con rondana','2 Allen M6 × 16 + rondana ancha en los ejes de arriba y 2 en los de abajo']),
 dict(id='W2',mesh=['Placa trasera (madera)'],nombre='Placa trasera',cant=1,origen='Tabla 1 (28 × 13 cm): segundo cuadro',medidas='130 × 130 × 15 mm',
  proceso=[CNC,'Barrenos: 4 × Ø12.2 ejes, Ø14 centro (el tornillo gira libre), 2 × Ø8.5 expulsoras.','Atorníllala al pie trasero (3 pijas desde abajo + cola) y pon los 2 cartabones atrás.','Truco: atrás del tornillo pon una rondana grande o un cuadrito de lámina para que la tuerca no se hunda en la madera.'],
  tornilleria=['Tuerca ½" + rondana de bronce a cada lado','Tuercas 5/16" de las expulsoras a cada lado']),
 dict(id='W3',mesh=['Placa móvil (madera)'],nombre='Placa móvil',cant=1,origen='Tabla 2 (28 × 13 cm)',medidas='130 × 130 × 15 mm',
  proceso=[CNC,'Barrenos: 4 × Ø16 (pasan los ejes sin tocar), 8 × Ø4.5 soportes, 4 × Ø5.5 molde A, 2 × Ø9 expulsoras, Ø14 centro.',
           'Caja hexagonal de 19.2 mm entre caras × 12 mm de hondo por la cara de ATRÁS: ahí entra el cople.','Pega el cople en la caja con epóxico (o resina de 2 componentes) con la varilla puesta para que quede derecho.'],
  tornilleria=['8 Allen M4 × 25 desde el frente a las tuercas atrapadas de los soportes','4 Allen M5 × 20 al molde A (desde atrás)']),
 dict(id='W4',mesh=['Pie delantero (madera)'],nombre='Pie delantero',cant=1,origen='Tira (28 × 7 cm)',medidas='130 × 70 × 15 mm',
  proceso=['Corta con serrucho.','2 barrenos Ø10 que caen en los agujeros que ya tiene tu base (a 20 mm del frente, a 24 y 116 mm del borde).'],tornilleria=['2 tornillos ⅜" × 2" con rondana y tuerca abajo de la base']),
 dict(id='W5',mesh=['Pie trasero (madera)'],nombre='Pie trasero',cant=1,origen='Tira (28 × 7 cm)',medidas='130 × 60 × 15 mm',
  proceso=['Corta con serrucho.','2 barrenos Ø10 sobre los agujeros de tu base a 260 mm del frente.'],tornilleria=['2 tornillos ⅜" × 2" con rondana y tuerca']),
 dict(id='W6',mesh=['Cartabón delantero (madera)','Cartabones traseros (madera)'],nombre='Cartabones (triángulos)',cant=3,origen='Sobrante de la tira de 28 × 7',medidas='1 de 55 × 55 y 2 de 42 × 42 (triángulo), 15 de grueso',
  proceso=['Corta un cuadro y pártelo en diagonal.','Pégalos con cola y 2 pijas a la placa y al pie.'],tornilleria=['Pijas #8 × 1¼"']),
 dict(id='C01',mesh=['Ejes lisos 12 mm (comprar)'],nombre='Ejes lisos 12 mm',cant=4,origen='Comprar 4 de 180 mm (después 2 se recortan a 160 para la de metal)',medidas='Ø12 × 180 mm',
  proceso=['Machuelo M6 en cada punta (torno).'],tornilleria=['Allen M6 × 16 + rondana ancha en cada punta']),
 dict(id='C02',mesh=['Baleros lineales LM12UU (comprar)','Soportes impresos de LM12UU','Tornillería soportes LM12UU'],nombre='LM12UU + soportes impresos',cant=4,origen='Los mismos de la versión de metal (se reusan)',medidas='12 × 21 × 30',
  proceso=['Mismo STL de soporte; tuerca M4 atrapada y M3 en la oreja.'],tornilleria=['M4 × 25 (más largo por la madera de 15 mm)']),
 dict(id='C03',mesh=['Cople ½" (pegado en la caja hexagonal)'],nombre='Cople ½"-13 × 1¾"',cant=1,origen='Tornillería',medidas='19 mm entre caras × 44.5',proceso=['Pegado con epóxico en la caja de la placa móvil (no se suelda en esta prueba).'],tornilleria=['—']),
 dict(id='C04',mesh=['Tu varilla roscada ½"','Tuercas del tornillo','Rondanas de bronce (comprar)'],nombre='Tornillo de cierre',cant=1,origen='Tu varilla ½"',medidas=f'{X_RODEND-X_RODTIP:.0f} mm',
  proceso=['Para la prueba gírala con llave de ¾" o con taladro y dado de ¾" en la contratuerca de atrás: así pruebas antes de poner el motor.'],tornilleria=['3 tuercas ½" + 2 rondanas de bronce']),
 dict(id='C05',mesh=['Varillas expulsoras 5/16"'],nombre='Varillas expulsoras',cant=2,origen='Varilla 5/16"',medidas=f'{XR1+9-X_KO_TIP:.0f} mm',proceso=['Punta plana.'],tornilleria=['2 tuercas c/u']),
 dict(id='M',mesh=['Molde B (fijo)','Molde A + separadores + placa base','Placas expulsoras + botadores'],nombre='Tu molde de aluminio',cant=1,origen='El mismo',medidas='76.2 × 76.2',proceso=['Igual que en la de metal.'],tornilleria=['Ver despiece de la máquina']),
]
JOINTS=[('U1','Pies → base','Hexagonal ⅜" × 2"','tuerca + 2 rondanas',4,'llave 9/16"'),
 ('U2','Placas ↔ pies y cartabones','Pija #8 × 1½" + cola blanca','barreno guía 3 mm',12,'desarmador'),
 ('U3','Puntas de los ejes','Allen M6 × 16','rondana ancha Ø18',8,'Allen 5'),
 ('U4','Soportes LM12UU → placa móvil','Allen M4 × 25 + M3 × 16','tuerca atrapada M4 + tuerca M3',12,'Allen 3 y 2.5'),
 ('U5','Molde A → placa móvil / Molde B → placa fija','Allen M5 × 20','rondana',8,'Allen 4'),
 ('U6','Cople en placa móvil','Epóxico','—',1,'—'),
 ('U7','Tornillo en placa trasera','Tuerca ½" (3)','2 rondanas de bronce + rondana grande atrás',3,'llave ¾"'),
 ('U8','Expulsoras','Tuerca 5/16"','rondana',4,'llave ½"')]
MESH2ID={m:p['id'] for p in PARTS for m in p['mesh']}
JMESH={'Tornillos de los ejes':'U3','Tornillos del molde A':'U5','Tornillos ⅜" pies–base':'U1'}
