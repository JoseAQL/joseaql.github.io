import math,os,json,numpy as np,ezdxf
from shapely.geometry import Polygon,Point,box,LineString
exec(open('despiece_m.py').read())
src=open('../molde/gen.py').read(); cls="class G"+src.split("class G")[1].split("OUT=")[0]
TD=3.175; TR=TD/2; STEP=1.2; F_CUT=600; F_PLUNGE=150; SAFE=5.0; RPM=12000
exec(cls)
KERF=TD
def hexpoly(c,af):
    R=af/math.sqrt(3); return Polygon([(c[0]+R*math.cos(math.radians(30+60*i)),c[1]+R*math.sin(math.radians(30+60*i))) for i in range(6)])
# ---------- piezas (coordenadas propias, mm, origen esquina inf. izq.)
def plate_front(holes):  # (y,z,d) -> (h,v,d)
    return [(-y+PL/2, z-(ZC-PL/2), d) for y,z,d in holes]
HB=[p for b in BARS for p in hb(*b)]
W1=dict(id='W1',name='Placa fija',W=130,H=130,holes=plate_front([(y,z,12.2) for y,z in BARS]+[(y,z,5.5) for y,z in B_MOUNT]),pockets=[])
W2=dict(id='W2',name='Placa trasera',W=130,H=130,holes=plate_front([(y,z,12.2) for y,z in BARS]+[(0,ZC,14)]+[(y,z,8.5) for y,z in KO]),pockets=[])
W3=dict(id='W3',name='Placa móvil (cara de ATRÁS hacia arriba)',W=130,H=130,holes=[(y+65,z-(ZC-65),d) for y,z,d in [(y,z,16) for y,z in BARS]+[(y,z,4.5) for y,z in HB]+[(y,z,5.5) for y,z in A_MOUNT]+[(y,z,9) for y,z in KO]+[(0,ZC,14)]],
        pockets=[hexpoly((65,ZC-(ZC-65)),19.2)])
WT=dict(W1,id='WT',name='Plantilla para barrenar placas de METAL (copia de W1)')
W4=dict(id='W4',name='Pie delantero',W=130,H=70,holes=[(65-y,x,10) for x,y in BASE_F],pockets=[])
W5=dict(id='W5',name='Pie trasero',W=130,H=60,holes=[(65-y,x-XR,10) for x,y in BASE_R],pockets=[])
GUS=[dict(id='W6',name='Cartabón 55',tri=55),dict(id='W6',name='Cartabón 42',tri=42),dict(id='W6',name='Cartabón 42',tri=42)]
# ---------- acomodo en cada tira (lo que mediste: 28 x 13 y 28 x 7)
SHEETS=[]
x2=130+KERF
SHEETS.append(dict(name='Tabla_1_fija_y_trasera',W=280,H=130,place=[(W1,0,0),(W2,x2,0)],lines=[((130+TR,-3),(130+TR,133)),((x2+130+TR,-3),(x2+130+TR,133))],polys=[]))
SHEETS.append(dict(name='Tabla_2_movil_y_plantilla',W=280,H=130,place=[(W3,0,0),(WT,x2,0)],lines=[((130+TR,-3),(130+TR,133)),((x2+130+TR,-3),(x2+130+TR,133))],polys=[]))
SHEETS.append(dict(name='Tira_1_pies',W=280,H=70,place=[(W4,0,0),(W5,x2,0)],lines=[((130+TR,-3),(130+TR,73)),((x2+130+TR,-3),(x2+130+TR,73)),((130+TR,60+TR),(x2+130+TR,60+TR))],polys=[]))
tris=[]; x=6
for g in GUS:
    a=g['tri']; tris.append((g,Polygon([(x,6),(x+a,6),(x,6+a)]))); x+=a+10
SHEETS.append(dict(name='Tira_2_cartabones',W=280,H=70,place=[],lines=[],polys=tris))
# ---------- SVG + DXF
os.makedirs('wood_out/VECTORES_CNC',exist_ok=True); os.makedirs('wood_out/GCODE',exist_ok=True)
def sheet_features(sh):
    holes=[];pockets=[];labels=[]
    for p,x0,y0 in sh['place']:
        holes+=[(x0+h,y0+v,d) for h,v,d in p['holes']]
        pockets+=[Polygon([(x0+a,y0+b) for a,b in pk.exterior.coords]) for pk in p['pockets']]
        labels.append((x0+p['W']/2,y0+p['H']/2,p['id']))
    for g,t in sh['polys']: labels.append((t.centroid.x,t.centroid.y,g['id']))
    return holes,pockets,labels
for sh in SHEETS:
    W,H=sh['W'],sh['H']; holes,pockets,labels=sheet_features(sh)
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}mm" height="{H}mm" viewBox="0 0 {W} {H}">',f'<title>{sh["name"]}</title>',
       f'<rect id="MATERIAL_referencia_NO_CORTAR" x="0" y="0" width="{W}" height="{H}" fill="none" stroke="#999999" stroke-width="0.3"/>']
    for (a,b),(c,d) in sh['lines']: s.append(f'<line id="CORTE_sobre_la_linea_atraviesa" x1="{a:.3f}" y1="{H-b:.3f}" x2="{c:.3f}" y2="{H-d:.3f}" stroke="#e00000" stroke-width="0.3"/>')
    for g,t in sh['polys']: s.append('<polygon id="CORTE_por_fuera_atraviesa" points="'+' '.join(f'{px:.3f},{H-py:.3f}' for px,py in list(t.exterior.coords)[:-1])+'" fill="none" stroke="#e00000" stroke-width="0.3"/>')
    for x,y,d in holes: s.append(f'<circle id="BARRENO_D{d:g}_atraviesa" cx="{x:.3f}" cy="{H-y:.3f}" r="{d/2:.3f}" fill="#000000"/>')
    for pk in pockets: s.append('<polygon id="CAJA_HEX_12mm_hondo" points="'+' '.join(f'{px:.3f},{H-py:.3f}' for px,py in list(pk.exterior.coords)[:-1])+'" fill="#777777"/>')
    s.append('</svg>'); open(f'wood_out/VECTORES_CNC/{sh["name"]}.svg','w').write('\n'.join(s))
    doc=ezdxf.new(); doc.units=4; m=doc.modelspace()
    for n,c in [('MATERIAL',8),('CORTE',1),('BARRENOS',5),('CAJA_HEX_12mm',3)]: doc.layers.add(n,color=c)
    m.add_lwpolyline([(0,0),(W,0),(W,H),(0,H)],close=True,dxfattribs={'layer':'MATERIAL'})
    for a,b in sh['lines']: m.add_line(a,b,dxfattribs={'layer':'CORTE'})
    for g,t in sh['polys']: m.add_lwpolyline(list(t.exterior.coords),close=True,dxfattribs={'layer':'CORTE'})
    for x,y,d in holes: m.add_circle((x,y),d/2,dxfattribs={'layer':'BARRENOS'})
    for pk in pockets: m.add_lwpolyline(list(pk.exterior.coords),close=True,dxfattribs={'layer':'CAJA_HEX_12mm'})
    doc.saveas(f'wood_out/VECTORES_CNC/{sh["name"]}.dxf')
# ---------- G-code: 2 versiones de profundidad
def line_cut(g,p0,p1,depth,step=1.5,tabs=2,tabh=2.0):
    L=math.dist(p0,p1); tp=[L*(i+1)/(tabs+1) for i in range(tabs)]; tw=TD+4
    g.up(); g.rapid(*p0); g.L.append('G0 Z0.5'); z=0; fwd=True
    while z>-depth+1e-6:
        z=max(z-step,-depth); a,b=(p0,p1) if fwd else (p1,p0)
        n=max(2,int(L/1.0))
        for i in range(n+1):
            t=i/n; px=a[0]+(b[0]-a[0])*t; py=a[1]+(b[1]-a[1])*t; d=math.dist(p0,(px,py))
            zz=z
            if z<-depth+tabh and any(abs(d-q)<tw/2 for q in tp): zz=-depth+tabh
            g.cut(px,py,zz)
        fwd=not fwd
    g.up()
for depth,tag,note in [(12.0,'fresa_largo_12mm','Fresa con largo de corte 12 mm: corta 12 mm; termina con taladro, cutter o serrucho.'),(15.6,'fresa_largo_22mm','Fresa 1/8" con largo de corte 22 mm (DSP1F-D3.1-L22): atraviesa los 15 mm.')]:
    for sh in SHEETS:
        holes,pockets,labels=sheet_features(sh)
        g=G(f'{sh["name"]}_{tag}',f'PRUEBA EN MADERA - {sh["name"]}',f'aglomerado 15 mm, {sh["W"]} x {sh["H"]} mm',
            ['Fresa plana 1/8 in (3.175), 1 filo de preferencia','Cero X0 Y0: esquina inferior izquierda de la tira; Z0: cara de arriba',note,'Orden: barrenos, caja hexagonal, cortes al final (con puentes de 2 mm)','Prensa la tira fuera de las lineas de corte; cinta masking encima'])
        g.L=[l.replace('aluminio','madera') for l in g.L]
        for x,y,d in holes:
            if d<=6.4: g.hole(x,y,d,depth,stepdown=0.6)
            else: g.counterbore(x,y,d,depth,stepdown=1.0)
        for pk in pockets:
            z=0
            while z>-12+1e-6: z=max(z-1.0,-12.0); g.pocket(pk,z)
            g.up()
        for a,b in sh['lines']: line_cut(g,a,b,depth)
        for gg,t in sh['polys']: g.profile_out(t,depth,tabs=2,tabh=2.0,stepdown=1.5)
        g.save('wood_out/GCODE')
json.dump({sh['name']:[(p['id'],x0,y0) for p,x0,y0 in sh['place']] for sh in SHEETS},open('wood_out/layout.json','w'))
print(os.listdir('wood_out/GCODE'))
