# PRUEBA DE FUNCIONAMIENTO EN MADERA (aglomerado 15 mm).  mm.  X = largo (frente=0), Y = ancho, Z = altura
import numpy as np, trimesh, pickle, json
from shapely.geometry import Polygon, Point, box, LineString
from shapely.ops import unary_union
from trimesh.creation import extrude_polygon, cylinder
Rm=trimesh.transformations.rotation_matrix
LU=280; WU=140; HU=30; TU=4.5; Z0=HU
TW=15.0                                   # grueso de la madera
PL=130.0; MW=MH=130.0
ZB=Z0+TW                                  # las placas se paran sobre los pies de madera
ZC=ZB+PL/2                                # centro del molde
BY,BZ=49.5,46.0
RD=12.0; LMD,LML=21.0,30.0
S=25.0; Q=6.35; KOY=19.5; KOD=7.94
ROD=12.7; NUT_T=11.0; NUT_AF=19.05; CPL_L=44.45; JAM_T=7.0; BW=1.5
MOLD=57.15
XF0=55.0; XF=XF0+TW                       # placa fija
XMB=XF+MOLD
XMP0,XMP1=XMB,XMB+TW                      # placa móvil de madera
POCK=12.0                                 # caja hexagonal para el cople (desde atrás)
XC0=XMP1-POCK; XC1=XC0+CPL_L
ROD_L=180.0
XR1=XF0+ROD_L; XR=XR1-TW                  # placa trasera: ejes de 180 mm de cara a cara
X_BW=(XR-BW,XR); X_TN=(X_BW[0]-NUT_T,X_BW[0])
GAP_OPEN=X_TN[0]-(XC1+S); assert GAP_OPEN>=3,GAP_OPEN
X_RODTIP=XC0+S+2.0
X_NW=(XR1,XR1+BW); X_RN=(X_NW[1],X_NW[1]+NUT_T); X_JAM=(X_RN[1],X_RN[1]+JAM_T); X_RODEND=X_JAM[1]+2
X_KO_TIP=(XMB-12.7)+S-Q
BARS=[(sy*BY,ZC+sz*BZ) for sy in(-1,1) for sz in(-1,1)]
KO=[(sy*KOY,ZC) for sy in(-1,1)]
A_MOUNT=[(sy*31.75,ZC+sz*28.1) for sy in(-1,1) for sz in(-1,1)]
B_MOUNT=[(sy*31.75,ZC+sz*8.1) for sy in(-1,1) for sz in(-1,1)]
FOOT_F=(0.0,XF);  FOOT_R=(XR,LU)          # pies de madera
GUS_F=dict(x=(XF0-55,XF0),y=(-7.5,7.5),h=55)            # 1 cartabón al centro adelante
GUS_R=[dict(x=(XR1,XR1+42),y=(s*17,s*32),h=42) for s in(-1,1)]  # 2 atrás (deja libre el centro)
def hb(y,z):
    sy=1 if y>0 else -1; sz=1 if z>ZC else -1
    return [(y-22*sy,z+4*sz),(y+4*sy,z-22*sz)]
HOLD_BOLTS=[p for b in BARS for p in hb(*b)]
BASE_F=[(20.0,y) for y in(-46,46)]; BASE_R=[(260.0,y) for y in(-46,46)]   # agujeros que ya tiene tu base
def u_holes():
    H=[]
    for y in(-46,-23,23,46): H.append((20,y,10,'o'))
    for c in(85,195):
        for y in(-46,-23,23,46): H.append((c,y,20 if abs(y)==46 else 14,'o'))
    for y in(-46,46): H.append((260,y,10,'o'))
    for y in(-23,23): H.append((260,y,10,'slot'))
    return H
OLD_BASE=u_holes()
RW0=260-BY-PL/2                       # pedazo del 2o canal: X viejo [145.5, 275.5]
RCEN=RW0+PL/2
OLD_REAR=[]
for x,y,d,t in u_holes():
    if RW0-5<x<RW0+PL+5: OLD_REAR.append((x-RCEN,ZC+y,d,t))
# ---------------- helpers de malla
def ext(poly,a0,a1,axis):
    m=extrude_polygon(poly,a1-a0)
    if axis=='X': M=np.array([[0,0,1,a0],[1,0,0,0],[0,1,0,0],[0,0,0,1]],float)   # poly(Y,Z)
    elif axis=='Z': M=np.array([[1,0,0,0],[0,1,0,0],[0,0,1,a0],[0,0,0,1]],float) # poly(X,Y)
    else: M=np.array([[1,0,0,0],[0,0,1,a0],[0,1,0,0],[0,0,0,1]],float)           # poly(X,Z) along Y
    m.apply_transform(M)
    if m.volume<0: m.invert()
    return m
def cX(x0,x1,y,z,d,s=40): return cylinder(d/2,x1-x0,sections=s).apply_transform(Rm(np.pi/2,[0,1,0])).apply_translation([(x0+x1)/2,y,z])
def cZ(z0,z1,x,y,d,s=32): return cylinder(d/2,z1-z0,sections=s).apply_translation([x,y,(z0+z1)/2])
def hexX(x0,x1,y,z,af): return cX(x0,x1,y,z,af*2/np.sqrt(3),6)
def hexZ(z0,z1,x,y,af): return cZ(z0,z1,x,y,af*2/np.sqrt(3),6)
def C(p,d): return Point(p).buffer(d/2,48)
def slot(p0,p1,w): return LineString([p0,p1]).buffer(w/2,24)
# ---------------- piezas
OLD_BASE=u_holes()
P=[]
def add(n,mat,g,m): P.append((n,mat,g,m))
# base (tu canal U)
web=box(0,-WU/2,LU,WU/2).difference(unary_union([C((x,y),d) if t=='o' else slot((x,y),(LU+5,y),d) for x,y,d,t in OLD_BASE]))
base=[ext(web,Z0-TU,Z0,'Z')]
for s in(-1,1):
    y0,y1=sorted([s*(WU/2-TU),s*WU/2]); base.append(ext(box(0,0,LU,Z0-TU),y0,y1,'Y'))
add('Base (tu canal U)','U1','fijo',trimesh.util.concatenate(base))
# pies
add('Pie delantero (madera)','W','fijo',ext(box(FOOT_F[0],-PL/2,FOOT_F[1],PL/2).difference(unary_union([C(p,10) for p in BASE_F])),Z0,ZB,'Z'))
add('Pie trasero (madera)','W','fijo',ext(box(FOOT_R[0],-PL/2,FOOT_R[1],PL/2).difference(unary_union([C(p,10) for p in BASE_R])),Z0,ZB,'Z'))
def gusset(g):
    x0,x1=g['x']; h=g['h']; front=x1<=XF0+0.1
    tri=Polygon([(x1,ZB),(x0,ZB),(x1,ZB+h)]) if front else Polygon([(x0,ZB),(x1,ZB),(x0,ZB+h)])
    return ext(tri,g['y'][0] if g['y'][0]<g['y'][1] else g['y'][1],max(g['y']),'Y')
add('Cartabón delantero (madera)','W','fijo',gusset(GUS_F))
add('Cartabones traseros (madera)','W','fijo',trimesh.util.concatenate([gusset(g) for g in GUS_R]))
# placas
fp=box(-PL/2,ZB,PL/2,ZB+PL).difference(unary_union([C(p,12.2) for p in BARS]+[C(p,5.5) for p in B_MOUNT]))
add('Placa fija (madera)','W','fijo',ext(fp,XF0,XF,'X'))
rp=box(-PL/2,ZB,PL/2,ZB+PL).difference(unary_union([C(p,12.2) for p in BARS]+[C((0,ZC),14.0)]+[C(p,8.5) for p in KO]))
add('Placa trasera (madera)','W','fijo',ext(rp,XR,XR1,'X'))
mp_=box(-MW/2,ZC-MH/2,MW/2,ZC+MH/2).difference(unary_union([C(p,16.0) for p in BARS]+[C(p,9.0) for p in KO]+[C(p,5.5) for p in A_MOUNT]+[C(p,4.5) for p in HOLD_BOLTS]+[C((0,ZC),14.0)]))
mpm=ext(mp_,XMP0,XMP1,'X').difference(hexX(XC0,XMP1+1,0,ZC,NUT_AF+0.2))
add('Placa móvil (madera)','W','movil',mpm)
# ejes y tornillos
add('Ejes lisos 12 mm (comprar)','compra','fijo',trimesh.util.concatenate([cX(XF0,XR1,y,z,RD) for y,z in BARS]))
eb=[]
for y,z in BARS: eb+=[cX(XF0-1.6,XF0,y,z,18),cX(XF0-7.6,XF0-1.6,y,z,10),cX(XR1,XR1+1.6,y,z,18),cX(XR1+1.6,XR1+7.6,y,z,10)]
add('Tornillos de los ejes','tornillo','fijo',trimesh.util.concatenate(eb))
# molde
mp,mpins=pickle.load(open('../molde/parts.pkl','rb'))
def m2m(m):
    m=m.copy(); T=np.array([[0,0,-1,XF+MOLD],[1,0,0,-38.1],[0,-1,0,38.1+ZC],[0,0,0,1]],float); m.apply_transform(T); return m
add('Molde B (fijo)','molde','fijo',m2m(mp['1_Placa_B_fija']))
movA=[m2m(mp[k]) for k in ['2_Placa_A_cavidad','3_Separador_izq','4_Separador_der']]
movA.append(m2m(mp['7_Placa_base']).difference(trimesh.util.concatenate([cX(XMB-14,XMB+1,y,z,9.0) for y,z in KO])))
add('Molde A + separadores + placa base','molde','movil',trimesh.util.concatenate(movA))
add('Placas expulsoras + botadores','molde','expulsor',trimesh.util.concatenate([m2m(mp['5_Porta_botadores']),m2m(mp['6_Placa_expulsora'])]+[m2m(p) for p in mpins]))
# LM12UU + soportes impresos (mismos que la versión de metal)
lm=[];hold=[];hb_=[]
for y,z in BARS:
    sy=1 if y>0 else -1
    lm.append(cX(XMP1+0.5,XMP1+0.5+LML,y,z,LMD).difference(cX(XMP1-1,XMP1+LML+2,y,z,RD+0.3)))
    bolts=hb(y,z); FT=6.0
    fl=unary_union([Point(y,z).buffer(15.5,48)]+[Point(p).buffer(5.5,24) for p in bolts]).convex_hull.difference(unary_union([Point(y,z).buffer(LMD/2+0.1,48)]+[Point(p).buffer(2.25,16) for p in bolts]))
    ear=box(min(y,y+sy*26),z-5,max(y,y+sy*26),z+5)
    ring=unary_union([Point(y,z).buffer(15.5,48),ear]).difference(Point(y,z).buffer(LMD/2+0.05,48)).difference(box(min(y,y+sy*27),z-1,max(y,y+sy*27),z+1))
    nt=[ext(Point(p).buffer(7.0/np.sqrt(3),6),XMP1+FT-3.6,XMP1+FT+0.01,'X') for p in bolts]
    h=[ext(fl,XMP1,XMP1+FT,'X').difference(trimesh.util.concatenate(nt))]+[ext(g,XMP1+FT,XMP1+31,'X').difference(cZ(z-9,z+9,XMP1+18,y+sy*20,3.4,16)) for g in getattr(ring,'geoms',[ring])]+[cX(XMP1+31,XMP1+33,y,z,31).difference(cX(XMP1+30,XMP1+34,y,z,17))]
    hold.append(trimesh.util.concatenate(h))
    for p in bolts: hb_+=[cX(XMP0-4,XMP0,*p,7.0,24),hexX(XMP1+FT-3.4,XMP1+FT-0.2,*p,6.9)]
    hb_.append(cZ(z-7,z+7,XMP1+18,y+sy*20,3.0,12))
add('Baleros lineales LM12UU (comprar)','compra','movil',trimesh.util.concatenate(lm))
add('Soportes impresos de LM12UU','print','movil',trimesh.util.concatenate(hold))
add('Tornillería soportes LM12UU','tornillo','movil',trimesh.util.concatenate(hb_))
add('Tornillos del molde A','tornillo','movil',trimesh.util.concatenate([cX(XMP1,XMP1+4,y,z,8.5) for y,z in A_MOUNT]))
# cople en la caja hexagonal + tornillo
add('Cople ½" (pegado en la caja hexagonal)','tornillo','movil',hexX(XC0,XC1,0,ZC,NUT_AF).difference(cX(XC0-1,XC1+1,0,ZC,ROD)))
add('Tu varilla roscada ½"','varilla','giro',cX(X_RODTIP,X_RODEND,0,ZC,ROD))
add('Tuercas del tornillo','tornillo','giro',trimesh.util.concatenate([hexX(*X_TN,0,ZC,NUT_AF),hexX(*X_RN,0,ZC,NUT_AF),hexX(*X_JAM,0,ZC,NUT_AF)]))
add('Rondanas de bronce (comprar)','compra','fijo',trimesh.util.concatenate([cX(*X_BW,0,ZC,22).difference(cX(X_BW[0]-1,X_BW[1]+1,0,ZC,13)),cX(*X_NW,0,ZC,22).difference(cX(X_NW[0]-1,X_NW[1]+1,0,ZC,13))]))
ko=[cX(X_KO_TIP,XR1+9,y,z,KOD) for y,z in KO]+[hexX(XR-7,XR,y,z,12.7) for y,z in KO]+[hexX(XR1,XR1+7,y,z,12.7) for y,z in KO]
add('Varillas expulsoras 5/16"','varilla','fijo',trimesh.util.concatenate(ko))
bb=[]
for x,y in BASE_F+BASE_R: bb+=[cZ(Z0-TU-14,ZB+6,x,y,9.5),hexZ(ZB,ZB+6,x,y,14.3),hexZ(Z0-TU-9,Z0-TU,x,y,14.3)]
add('Tornillos ⅜" pies–base','tornillo','fijo',trimesh.util.concatenate(bb))
pickle.dump(dict(P=P),open('parts_m.pkl','wb'))
D={k:v for k,v in globals().items() if k.isupper() and k!='P' and isinstance(v,(int,float,tuple,list,dict))}
json.dump(D,open('dims_m.json','w'),indent=0,default=float)
print('XF',XF,'XMB',XMB,'XR',XR,'gap',round(GAP_OPEN,1),'rod',X_RODTIP,X_RODEND,round(X_RODEND-X_RODTIP,1),'KO',round(XR1+9-X_KO_TIP,1),'ZC',ZC)
