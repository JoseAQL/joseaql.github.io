# Estado y pendientes

## Listo
- Molde de aluminio con expulsión: STL, G-code y SVG (`02_molde`).
- Máquina de metal, versión del boceto 1 con escuadras de ángulo (`03_maquina_metal`), revisada sin choques cerrada, a medio abrir y abierta.
- Despiece completo: de qué material sale cada pieza, proceso y tornillería por unión (en el PDF y en el visor 3D).
- Soporte impreso para LM12UU (tuercas M4 atrapadas, oreja de apriete).
- Prueba de funcionamiento en madera con archivos para CNC (`04_prueba_madera`).

## Falta medir (cambia medidas del diseño)
| Dato | Supuesto actual | Dónde afecta |
|---|---|---|
| Espesor de la lámina del canal U | 4.5 mm | Placa trasera, base |
| Varilla roscada del cierre | ½"-13 | Cople, tuercas |
| Agujeros viejos de los canales | medidos en fotos | Plantilla `docs/Plantilla_base_canal_U.pdf` |
| Motor con reductor de banda: diámetro de la flecha, medidas de la caja, reducción | — | Cople flexible y soporte del motor |

## Decisión en curso
Cambiar el engrane grande por un **cople flexible** (tipo L050 o ciruela) directo entre la flecha del motor con reductor y el tornillo. Falta: medidas del motor (tabla de arriba). Hasta entonces los planos muestran la versión con engrane.

## Siguiente
1. Cortar y armar la prueba en madera; girar el tornillo con taladro y dado de ¾".
2. Confirmar las medidas pendientes y actualizar la versión de metal.
