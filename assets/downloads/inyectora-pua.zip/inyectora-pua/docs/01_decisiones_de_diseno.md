# Decisiones de diseño (historial)

| Fecha | Cambio | Por qué |
|---|---|---|
| 1 oct | Molde de 2 placas (3" × 3" × ½") con bebedero, canal, compuerta, venteos de 0.1 mm y 4 pernos guía (uno desfasado) | Se maquina en CNC casera con fresa de ⅛" |
| 1 oct | Sistema de expulsión: porta-botadores, placa expulsora, 5 botadores Ø3, 4 retornos Ø6 | Sacar la pieza sin tocarla |
| 1 oct | Botadores hechos de tornillos Allen torneados (M4 → Ø3, M6 para retornos) | Se consiguen fácil y se hacen en torno |
| 1 oct | Unidad de cierre de rodilleras (toggle) | Primera idea (en `archivo/rodilleras_v1`) |
| 6 oct | Cambio a **tornillo directo** horizontal | Más simple; las rodilleras eran demasiado complicadas para el material disponible |
| 6 oct | Base: canal U de 28 cm con cejas abajo; placas fija/trasera con **escuadras de ángulo abajo** (boceto 1) | Usar el metal que tengo sin desperdiciar |
| 6 oct | Placa fija: trapecio 6 mm · trasera: fondo del 2º canal sin cejas · móvil: lámina 2.5 mm | Lo acordado en el boceto 1 |
| 6 oct | Bujes de bronce → **ejes 12 mm + LM12UU** con soportes impresos | Corre más suave; estilo de la CNC impresa |
| 6 oct | Soporte LM12UU corregido: oreja hacia un lado y tuercas M4 atrapadas | La oreja chocaba con un tornillo |
| 9 oct | Versión de **prueba en madera** (aglomerado 15 mm) | Probar el mecanismo antes de cortar y soldar metal |
| pendiente | Engrane → cople flexible con el motor de reductor de banda | Quitar el engrane (difícil de cortar con fresa de ⅛") |
