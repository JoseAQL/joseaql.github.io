# Dónde comprar (Aguascalientes)

Llama antes: ninguna tienda publica su inventario.

| Qué | Dónde | Cómo pedirlo |
|---|---|---|
| Cople ½"-13 × 1¾", tuercas, Allen M3–M6, varilla 5/16" | Tornillos Monterrey (Av. Héroe de Nacozari 2005, 449 912 5709) · Torniexpress (Blvd. Ruiz Cortines 913, 449 976 4343; también hacen roscas) | "cople roscado de media", "tuerca cople ½-13" |
| LM12UU, eje cromado 12 mm, acople flexible, rondanas de bronce | ATI Refacciones (Av. Héroe de Nacozari 2211, 449 978 9290) · Rodamientos Industriales (Av. Convención 730-A, 449 916 4402) · Rebasa (Av. Convención Sur 609) | "balero lineal LM12UU", "flecha cromada 12 mm", "acople L050 con maza de ½" |
| Si no hay LM12UU / eje | Mercado Libre o AliExpress | mismos nombres |
| Impresión 3D (si no tienes impresora) | Print al Cubo (Los Bosques) | soportes en PETG |
| Fresas para CNC | AliExpress | 1 filo carburo ⅛": D3.1-L12 (corte 12 mm) o D3.1-L22 (corte 22 mm); D2.0-L08 para engranes chicos |
