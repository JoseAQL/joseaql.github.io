# Cómo cortar en la CNC (GRBL + Easel)

- Fresa: plana de ⅛" (3.175 mm). Para plástico y madera, mejor de 1 filo.
- Cero: X0 Y0 en la esquina inferior izquierda de la pieza o tira; Z0 en la cara de arriba.
- Antes de cortar: vista previa en Easel y una pasada en el aire (Z +1 mm).

## Colores en los SVG
| Color | Operación |
|---|---|
| Negro (círculos) | Barreno: "Fill" a la profundidad indicada (o atravesar) |
| Gris (hexágono, cajas) | Caja: "Fill" a la profundidad del nombre |
| Rojo | Corte: "On path" (líneas) u "Outline" por afuera (contornos), con puentes |
| Gris claro (rectángulo) | Referencia del material: no cortar |

## Profundidad
La fresa D3.1-L12 corta 12 mm. En madera de 15 mm usa los G-code `_fresa_largo_12mm` y termina con taladro y cutter, o compra la D3.1-L22 y usa `_fresa_largo_22mm`.

## Llaveros
Negro = grabado 0.3–0.5 mm con fresa en V; rojo = corte que atraviesa (contorno por afuera, argolla por adentro). Orden: grabado → agujero → contorno.
