# Llaveros

Negro (`GRABADO_dibujo`): grabar 0.3–0.5 mm con fresa en V. Rojo (`CORTE_*`): atravesar con fresa de ⅛" (contorno por afuera, argolla por adentro). Los dibujos son míos.
