# Archivo

Versiones anteriores de la máquina (v1 a v4) y los bocetos del tornillo directo. La tabla de cambios está en el README principal.
