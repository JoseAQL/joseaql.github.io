# Prueba en madera (aglomerado 15 mm)

Para probar cierre, apertura, expulsión y que la placa móvil corra suave. No es para inyectar.

- `planos/Prueba_madera_piezas_y_lista.pdf`: lista de materiales, plano de corte, cómo cortar y plantillas 1:1.
- `VECTORES_CNC/`: SVG y DXF de cada tabla ya acomodada.
- `GCODE/`: dos versiones (fresa de 12 mm o de 22 mm de corte) y simulación.
- `visor_madera_3D.html`: modelo 3D.
