#!/bin/bash
# Raspberry Pi 4B <-> PLC FX5U (SLMP por Ethernet)
# Internet y Tailscale van por WiFi (wlan0); el cable (eth0) es SOLO para el PLC.
#
# Puerto SLMP del PLC: 1025 (el FX5U reserva 5000-5009 para el sistema)
PUERTO=${PUERTO:-1025}
#
# Uso:
#   bash setup_pi.sh instalar                 -> instala Node-RED y los nodos (necesita internet)
#   bash setup_pi.sh red <IP_PLC> <IP_PI>     -> configura el cable hacia el PLC
#        ej: bash setup_pi.sh red 192.168.3.250 192.168.3.20
#   bash setup_pi.sh estado                   -> muestra IPs, rutas y prueba ping
set -e

instalar() {
  sudo apt update
  sudo apt install -y netcat-openbsd

  echo "== Node-RED (instalador oficial) =="
  bash <(curl -sL https://github.com/node-red/linux-installers/releases/latest/download/install-update-nodered-deb) --confirm-install --confirm-pi
  sudo systemctl enable nodered.service
  sudo systemctl start nodered.service

  echo "== Nodos Mitsubishi + Dashboard =="
  cd ~/.node-red
  npm install node-red-contrib-mcprotocol@1.2.1 @flowfuse/node-red-dashboard@1.26.0
  sudo systemctl restart nodered.service
  echo "LISTO. Node-RED en el puerto 1880 (por Tailscale: http://<nombre-o-IP-tailscale>:1880)"
}

red() {
  PLC_IP="$1"; PI_IP="$2"
  if [ -z "$PLC_IP" ] || [ -z "$PI_IP" ]; then
    echo "Falta: bash setup_pi.sh red <IP_PLC> <IP_PI>"; exit 1
  fi
  CON=$(nmcli -t -f NAME,DEVICE con show | grep ':eth0$' | cut -d: -f1 || true)
  if [ -z "$CON" ]; then
    sudo nmcli con add type ethernet ifname eth0 con-name plc-eth
    CON="plc-eth"
  fi
  # IP fija, SIN gateway y sin ruta por defecto: asi el internet y Tailscale siguen por WiFi
  sudo nmcli con mod "$CON" ipv4.method manual ipv4.addresses "$PI_IP/24" \
       ipv4.gateway "" ipv4.never-default yes ipv6.method disabled connection.autoconnect yes
  sudo nmcli con up "$CON"
  echo "$PLC_IP" > ~/plc_ip.txt
  echo "Probando PLC $PLC_IP ..."
  ping -c 3 "$PLC_IP" && echo "PLC OK (ping)" || echo "!! El PLC no responde: cable, IP o PLC apagado"
  nc -zv -w 3 "$PLC_IP" "$PUERTO" && echo "SLMP OK (puerto $PUERTO abierto)" || echo "!! Ping bien pero el puerto $PUERTO no abre: revisa SLMP en GX Works3 y reinicia el PLC"
}

estado() {
  ip -br addr
  echo "--- rutas ---"; ip route
  if [ -f ~/plc_ip.txt ]; then ping -c 2 "$(cat ~/plc_ip.txt)" || true; nc -zv -w 3 "$(cat ~/plc_ip.txt)" "$PUERTO" || true; fi
  systemctl is-active nodered.service && echo "Node-RED corriendo" || echo "Node-RED detenido"
  ping -c 2 8.8.8.8 >/dev/null && echo "Internet OK (WiFi)" || echo "Sin internet"
}

case "$1" in
  instalar) instalar ;;
  red) red "$2" "$3" ;;
  estado) estado ;;
  *) echo "Uso: bash setup_pi.sh instalar | red <IP_PLC> <IP_PI> | estado" ;;
esac
