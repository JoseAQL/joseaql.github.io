#!/usr/bin/env python3
"""
autoplc: detecta solo al FX5U en el cable (eth0) y deja a Node-RED conectado.

Que hace, en un ciclo que nunca termina (corre como servicio de systemd, como root):
  1. Espera a que el cable este conectado (eth0 con enlace).
  2. Escucha 8 s los mensajes ARP del cable (el HMI y el PLC se los mandan entre si)
     para saber en que red estan, y le suma las redes de /etc/autoplc/autoplc.conf
     y la de fabrica de Mitsubishi (192.168.3.x).
  3. Para cada red candidata: se pone una IP libre de esa red en eth0 y busca un
     equipo con el puerto SLMP abierto que conteste como PLC Mitsubishi (trama 3E).
  4. Cuando lo encuentra: deja la IP de la Raspberry fija en esa red (sin gateway,
     el internet sigue por WiFi), escribe PLC_IP en /etc/autoplc/plc.env y reinicia
     Node-RED solo si la IP cambio. El flujo usa ${PLC_IP} en el nodo de conexion.
  5. Despues solo vigila con ping. Si el PLC desaparece, vuelve a buscar.
  6. Si no hay PLC pero esta corriendo el simulador (127.0.0.1:1025), usa ese.
  7. Escribe /run/autoplc/estado.json con la IP del PLC y los equipos vistos en el
     cable (el tablero lo muestra).

Probar sin instalar:  sudo python3 autoplc.py --una-vez
"""
import ipaddress
import json
import os
import socket
import struct
import subprocess
import sys
import threading
import time

IFACE = "eth0"
PUERTO = 1025
CONF = "/etc/autoplc/autoplc.conf"
ENV = "/etc/autoplc/plc.env"
ESTADO = "/run/autoplc/estado.json"
HOST_PI = [200, 201, 202, 210, 220]        # ultimo numero que intenta usar la Raspberry
LOCAL = "127.0.0.1"


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


def sh(cmd, check=False):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if check and r.returncode:
        raise RuntimeError(f"{cmd}: {r.stderr.strip()}")
    return r.stdout.strip()


# ---------------------------------------------------------------- configuracion
def leer_conf():
    """Archivo simple:  PUERTO=1025 / REDES=192.168.3,10.0.0 / IP_PI=200"""
    c = {"PUERTO": str(PUERTO), "REDES": "", "IP_PI": "", "IP_SERVICIO": ""}
    try:
        for ln in open(CONF):
            ln = ln.split("#")[0].strip()
            if "=" in ln:
                k, v = ln.split("=", 1)
                c[k.strip().upper()] = v.strip()
    except FileNotFoundError:
        pass
    return c


# ---------------------------------------------------------------- red
def hay_enlace():
    try:
        return open(f"/sys/class/net/{IFACE}/carrier").read().strip() == "1"
    except OSError:
        return False


def redes_de_otras_interfaces():
    """Redes /24 que ya usan wlan0, tailscale, etc.: nunca se buscan en el cable."""
    out = set()
    for ln in sh("ip -o -4 addr show").splitlines():
        p = ln.split()
        if p[1] in (IFACE, "lo"):
            continue
        out.add(".".join(p[3].split("/")[0].split(".")[:3]))
    return out


def escuchar_arp(segundos=8):
    """Junta las IPs que aparecen en mensajes ARP del cable (sin mandar nada)."""
    vistas = set()
    try:
        s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.htons(0x0806))
        s.bind((IFACE, 0))
        s.settimeout(0.5)
    except (PermissionError, OSError) as e:
        log("no puedo escuchar ARP:", e)
        return vistas
    fin = time.time() + segundos
    while time.time() < fin:
        try:
            pkt = s.recv(128)
        except socket.timeout:
            continue
        if len(pkt) < 42:
            continue
        for ip_b in (pkt[28:32], pkt[38:42]):          # IP de quien manda y a quien busca
            ip = socket.inet_ntoa(ip_b)
            if not ip.startswith(("0.", "169.254.", "255.")):
                vistas.add(ip)
    s.close()
    return vistas


def poner_ip_temporal(red, conf):
    """Agrega a eth0 una IP libre de la red (ej. 192.168.3.200/24). Regresa la IP."""
    pref = [int(conf["IP_PI"])] if conf["IP_PI"].isdigit() else []
    for n in pref + HOST_PI:
        ip = f"{red}.{n}"
        sh(f"ip addr add {ip}/24 dev {IFACE} 2>/dev/null")
        # si alguien ya tiene esa IP, arping responde: buscamos otra
        if sh(f"arping -c 1 -w 1 -I {IFACE} -D {ip} >/dev/null 2>&1; echo $?") == "1":
            sh(f"ip addr del {ip}/24 dev {IFACE} 2>/dev/null")
            continue
        return ip
    return None


def quitar_ip(ip):
    sh(f"ip addr del {ip}/24 dev {IFACE} 2>/dev/null")


# ---------------------------------------------------------------- SLMP
TRAMA_LEER_D0 = bytes.fromhex("5000" "00" "FF" "FF03" "00" "0C00" "1000" "0104" "0000" "000000" "A8" "0100")


def es_plc(ip, puerto, timeout=0.6):
    """Conecta y pide D0 con trama 3E binaria. Si contesta D000 ... es un PLC."""
    try:
        with socket.create_connection((ip, puerto), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall(TRAMA_LEER_D0)
            r = s.recv(64)
        return len(r) >= 11 and r[0] == 0xD0 and r[1] == 0x00 and struct.unpack("<H", r[9:11])[0] == 0
    except OSError:
        return False


def puerto_abierto(ip, puerto, timeout=0.35):
    try:
        with socket.create_connection((ip, puerto), timeout=timeout):
            return True
    except OSError:
        return False


def buscar_plc_en(red, puerto, propia):
    """Prueba .1 a .254 en paralelo; regresa la IP del primer equipo que conteste SLMP."""
    abiertos, lock = [], threading.Lock()

    def probar(n):
        ip = f"{red}.{n}"
        if ip != propia and puerto_abierto(ip, puerto):
            with lock:
                abiertos.append(ip)

    hilos = [threading.Thread(target=probar, args=(n,)) for n in range(1, 255)]
    for i in range(0, len(hilos), 64):
        for h in hilos[i:i + 64]:
            h.start()
        for h in hilos[i:i + 64]:
            h.join()
    for ip in sorted(abiertos, key=lambda x: int(x.split(".")[-1])):
        if es_plc(ip, puerto):
            return ip
    return None


def ping(ip):
    return sh(f"ping -c 1 -W 1 {ip} >/dev/null 2>&1; echo $?") == "0"


# ---------------------------------------------------------------- dejarlo fijo
def perfil_cable():
    for ln in sh("nmcli -t -f NAME,DEVICE,TYPE con show").splitlines():
        p = ln.split(":")
        if len(p) >= 3 and p[2] == "802-3-ethernet" and p[1] in (IFACE, ""):
            return p[0]
    sh(f"nmcli con add type ethernet ifname {IFACE} con-name plc-eth")
    return "plc-eth"


def eth0_con_networkmanager():
    for ln in sh("nmcli -t -f DEVICE,STATE dev status").splitlines():
        d, _, st = ln.partition(":")
        if d == IFACE:
            return st != "unmanaged"
    return False


def asegurar_ip_servicio(conf):
    """IP fija extra para entrar desde la PC por cable; se repone si alguien la quita."""
    serv = conf.get("IP_SERVICIO", "")
    if serv and serv.split("/")[0] not in sh(f"ip -o -4 addr show dev {IFACE}"):
        sh(f"ip addr add {serv} dev {IFACE} 2>/dev/null")


def fijar_ip_pi(ip_pi, conf=None):
    if not eth0_con_networkmanager():
        # eth0 lo maneja dhcpcd (Raspberry Pi OS Bullseye): la IP temporal ya quedo puesta con ip addr
        log(f"eth0 no lo maneja NetworkManager: dejo {ip_pi}/24 puesta directo (se repone al reiniciar)")
        return
    prof = perfil_cable()
    serv = (conf or {}).get("IP_SERVICIO", "")
    lista = f"{serv},{ip_pi}/24" if serv else f"{ip_pi}/24"     # IP fija para tu PC + la de la red del PLC
    sh(f'nmcli con mod "{prof}" ipv4.method manual ipv4.addresses {lista} ipv4.gateway "" '
       f'ipv4.never-default yes ipv6.method disabled connection.autoconnect yes')
    sh(f'nmcli con up "{prof}"')
    log(f"Raspberry fija en {ip_pi}/24 (perfil '{prof}', sin gateway)")


def escribir_plc_ip(ip, puerto):
    actual = ""
    try:
        actual = open(ENV).read()
    except FileNotFoundError:
        pass
    nuevo = f"PLC_IP={ip}\nPLC_PORT={puerto}\n"
    if actual == nuevo:
        return False
    os.makedirs(os.path.dirname(ENV), exist_ok=True)
    open(ENV, "w").write(nuevo)
    log(f"PLC_IP={ip} guardado; reiniciando Node-RED")
    sh("systemctl restart nodered.service")
    return True


def equipos_en_cable(plc_ip, ip_pi):
    eq = []
    for ln in sh(f"ip neigh show dev {IFACE}").splitlines():
        p = ln.split()
        if "lladdr" not in p or p[0] == ip_pi:
            continue
        ip, mac = p[0], p[p.index("lladdr") + 1]
        tipo = "PLC FX5U (SLMP)" if ip == plc_ip else "otro equipo (HMI, PC, switch...)"
        eq.append({"ip": ip, "mac": mac, "tipo": tipo})
    return sorted(eq, key=lambda e: tuple(int(x) for x in e["ip"].split(".")))


def guardar_estado(**kw):
    kw["actualizado"] = time.strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs(os.path.dirname(ESTADO), exist_ok=True)
    tmp = ESTADO + ".tmp"
    with open(tmp, "w") as f:
        json.dump(kw, f, ensure_ascii=False)
    os.chmod(tmp, 0o644)
    os.replace(tmp, ESTADO)


# ---------------------------------------------------------------- ciclo principal
def buscar(conf):
    puerto = int(conf["PUERTO"])
    ocupadas = redes_de_otras_interfaces()
    log("escuchando ARP en el cable 8 s...")
    vistas = escuchar_arp()
    cand = []
    for ip in sorted(vistas):
        cand.append(".".join(ip.split(".")[:3]))
    cand += [r.strip() for r in conf["REDES"].split(",") if r.strip()]
    cand.append("192.168.3")
    redes = []
    for r in cand:
        if r not in redes and r not in ocupadas:
            redes.append(r)
    log("redes candidatas:", redes or "ninguna", "| IPs vistas por ARP:", sorted(vistas))
    for red in redes:
        ip_pi = poner_ip_temporal(red, conf)
        if not ip_pi:
            log(f"{red}.x: no encontre IP libre para la Raspberry")
            continue
        log(f"buscando PLC en {red}.1-254 puerto {puerto} (yo soy {ip_pi})")
        plc = buscar_plc_en(red, puerto, ip_pi)
        if plc:
            log(f"PLC encontrado en {plc}")
            return plc, ip_pi, red
        quitar_ip(ip_pi)
    return None, None, None


def ip_guardada():
    """IP del PLC que ya se habia encontrado (para no pelear la conexion SLMP con Node-RED)."""
    try:
        for ln in open(ENV):
            if ln.startswith("PLC_IP="):
                ip = ln.split("=", 1)[1].strip()
                return None if ip == LOCAL else ip
    except FileNotFoundError:
        pass
    return None


def main():
    una_vez = "--una-vez" in sys.argv
    plc_ip = ip_pi = None
    # Si ya conociamos al PLC y contesta ping, lo damos por bueno sin abrir otra conexion SLMP
    # (el modulo SLMP del FX5U acepta una sola conexion y esa es de Node-RED).
    guardada = ip_guardada()
    if guardada and hay_enlace():
        red = ".".join(guardada.split(".")[:3])
        for ln in sh(f"ip -o -4 addr show dev {IFACE}").split():
            if ln.startswith(red + ".") and "/" in ln:
                ip_pi = ln.split("/")[0]
        if not ip_pi:
            ip_pi = poner_ip_temporal(red, leer_conf())
        if ip_pi and ping(guardada):
            plc_ip = guardada
            log(f"uso el PLC ya conocido {plc_ip} (yo soy {ip_pi})")
    while True:
        conf = leer_conf()
        puerto = int(conf["PUERTO"])
        asegurar_ip_servicio(conf)
        if not hay_enlace():
            guardar_estado(estado="cable desconectado", plc_ip=None, equipos=[])
            if es_plc(LOCAL, puerto):
                escribir_plc_ip(LOCAL, puerto)
                guardar_estado(estado="sin cable: usando PLC simulado", plc_ip=LOCAL, equipos=[])
            plc_ip = None
        elif plc_ip and ping(plc_ip):
            guardar_estado(estado="conectado", plc_ip=plc_ip, pi_ip=ip_pi,
                           equipos=equipos_en_cable(plc_ip, ip_pi))
        else:
            if plc_ip:
                log(f"PLC {plc_ip} dejo de contestar; busco de nuevo")
            guardar_estado(estado="buscando PLC", plc_ip=None, equipos=[])
            plc_ip, ip_pi, red = buscar(conf)
            if plc_ip:
                fijar_ip_pi(ip_pi, conf)
                escribir_plc_ip(plc_ip, puerto)
                guardar_estado(estado="conectado", plc_ip=plc_ip, pi_ip=ip_pi,
                               equipos=equipos_en_cable(plc_ip, ip_pi))
            elif es_plc(LOCAL, puerto):
                escribir_plc_ip(LOCAL, puerto)
                guardar_estado(estado="no hay PLC en el cable: usando PLC simulado", plc_ip=LOCAL, equipos=[])
            else:
                log("no encontre PLC; reintento en 15 s")
                guardar_estado(estado="no se encontro PLC", plc_ip=None, equipos=[])
        if una_vez:
            break
        time.sleep(5 if plc_ip else 15)


if __name__ == "__main__":
    main()
