#!/bin/bash
# Instala el servicio autoplc (detecta el PLC solo) y deja Node-RED como servicio.
# Uso (en la carpeta 07_scada_nodered):   sudo bash autoplc/instalar_autoplc.sh
set -e
if [ "$EUID" -ne 0 ]; then echo "Correlo con sudo: sudo bash $0"; exit 1; fi
USUARIO="${SUDO_USER:-raspberrypi}"
CASA=$(getent passwd "$USUARIO" | cut -d: -f6)
AQUI="$(cd "$(dirname "$0")" && pwd)"

echo "== 1/5 autoplc en /usr/local/bin =="
install -m 755 "$AQUI/autoplc.py" /usr/local/bin/autoplc.py
mkdir -p /etc/autoplc
if [ ! -f /etc/autoplc/autoplc.conf ]; then
  cat > /etc/autoplc/autoplc.conf <<'EOF'
# Configuracion de autoplc. Despues de cambiarla: sudo systemctl restart autoplc
# Puerto SLMP que pusiste en GX Works3
PUERTO=1025
# Redes donde buscar el PLC (los tres primeros numeros, separadas por coma).
# Si el profe les da 192.168.10.x, pon: REDES=192.168.10
REDES=192.168.3
# Ultimo numero que quieres para la Raspberry en esa red (vacio = 200)
IP_PI=
# IP fija extra del cable para entrar desde tu PC sin WiFi (no la borra autoplc)
IP_SERVICIO=192.168.60.2/24
EOF
fi
command -v arping >/dev/null || apt-get install -y iputils-arping || true

echo "== 2/5 servicio autoplc =="
cat > /etc/systemd/system/autoplc.service <<'EOF'
[Unit]
Description=autoplc: busca el PLC FX5U en el cable y conecta Node-RED
After=network.target NetworkManager.service

[Service]
ExecStart=/usr/bin/python3 -u /usr/local/bin/autoplc.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

echo "== 3/5 Node-RED lee la IP del PLC de /etc/autoplc/plc.env =="
mkdir -p /etc/systemd/system/nodered.service.d
cat > /etc/systemd/system/nodered.service.d/plc.conf <<'EOF'
[Service]
Environment="PLC_IP=127.0.0.1" "PLC_PORT=1025"
EnvironmentFile=-/etc/autoplc/plc.env
EOF

echo "== 4/5 flujo con IP automatica =="
if [ -f "$AQUI/../flujo_inyectora.json" ]; then
  [ -f "$CASA/.node-red/flows.json" ] && cp "$CASA/.node-red/flows.json" "$CASA/.node-red/flows_respaldo_$(date +%Y%m%d_%H%M).json"
  install -o "$USUARIO" -g "$USUARIO" -m 644 "$AQUI/../flujo_inyectora.json" "$CASA/.node-red/flows.json"
fi

echo "== 5/5 arrancar =="
pkill -u "$USUARIO" -f "node-red" || true
sleep 2
systemctl daemon-reload
systemctl enable --now nodered.service
systemctl enable --now autoplc.service
sleep 3
systemctl --no-pager --lines=0 status nodered autoplc | grep -E "Loaded|Active"
echo
echo "LISTO. Ver lo que hace:   journalctl -u autoplc -f"
echo "Estado de la red:         cat /run/autoplc/estado.json"
echo "Tablero:                  http://<IP-tailscale>:1880/dashboard"
