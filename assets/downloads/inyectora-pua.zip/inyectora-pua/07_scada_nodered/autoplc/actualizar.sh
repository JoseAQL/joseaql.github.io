#!/bin/bash
# Actualiza en la Raspberry el flujo de Node-RED y autoplc (pide la contraseña de sudo una vez).
# Uso: bash actualizar.sh   (en la carpeta donde estan flujo_inyectora.json y autoplc.py)
set -e
cd "$(dirname "$0")"
F=flujo_inyectora.json; [ -f "$F" ] || F=../flujo_inyectora.json
A=autoplc.py; [ -f "$A" ] || A=autoplc/autoplc.py
cp ~/.node-red/flows.json ~/.node-red/flows_respaldo_$(date +%Y%m%d_%H%M).json 2>/dev/null || true
cp "$F" ~/.node-red/flows.json
sudo install -m 755 "$A" /usr/local/bin/autoplc.py
sudo grep -q '^IP_SERVICIO' /etc/autoplc/autoplc.conf || echo 'IP_SERVICIO=192.168.60.2/24' | sudo tee -a /etc/autoplc/autoplc.conf >/dev/null
sudo systemctl restart nodered
sudo systemctl restart autoplc
echo "Esperando 25 s a que Node-RED se conecte..."
sleep 25
curl -s localhost:1880/api/estado | python3 -c "import json,sys;d=json.load(sys.stdin);print('>>> PLC EN LINEA' if d['conectado'] else '>>> Sin PLC: '+str(d['error']))"
