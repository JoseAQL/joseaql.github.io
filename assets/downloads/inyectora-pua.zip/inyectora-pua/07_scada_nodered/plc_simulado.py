"""PLC FX5U falso que responde SLMP 3E binario (comandos 0401 lectura y 1401 escritura, trama tipo Q)."""
import socket, struct, threading, time

D = {i: 0 for i in range(0, 300)}
M = {i: 0 for i in range(0, 300)}
CODES = {0xA8: ('D', D), 0x90: ('M', M)}
st = {'temp': 25.0, 'paso': 0, 't': 0.0}
D[101], D[110], D[111], D[120] = 160, 1, 1, 5
LOG = []

def sim():
    while True:
        time.sleep(0.1)
        if M[0]: st['on'] = True
        if M[1]: st['on'] = False
        if M[2]:
            for a in range(70, 78): M[a] = 0
            if st['paso'] == 9: st['paso'] = 0; D[121] = 0
        st['t'] += 0.1
        if st.get('on') and st['paso'] == 0: st['paso'] = 1
        if st['paso'] == 1:
            st['temp'] += (230 - st['temp']) * 0.03
            if st['temp'] >= 158: st['paso'], st['t'] = 2, 0
        elif 2 <= st['paso'] <= 8 and st['t'] > 0.5:
            st['paso'] += 1; st['t'] = 0
            if st['paso'] == 9:
                D[121] += 1
                if D[121] >= D[120]: M[77] = 1; st['on'] = False
                else: st['paso'] = 2 if st.get('on') else 0
        D[100] = int(st['temp']); D[140] = max(5, 95 - D[121] * 9)
        for i in range(10): M[100 + i] = 1 if i == st['paso'] else 0
        M[50] = M[51] = 1
        D[150] = 0b10100100; D[151] = 0b100000 | (1 if st['paso'] == 1 else 0)

def handle(c):
    while True:
        h = c.recv(9)
        if len(h) < 9: return
        ln = struct.unpack('<H', h[7:9])[0]
        body = b''
        while len(body) < ln: body += c.recv(ln - len(body))
        cmd, sub = struct.unpack('<HH', body[2:6])
        dev = int.from_bytes(body[6:9], 'little'); code = body[9]; n = struct.unpack('<H', body[10:12])[0]
        name, mem = CODES.get(code, ('?', {}))
        LOG.append((hex(cmd), sub, name, dev, n))
        data = b''
        if cmd == 0x0401:
            if sub == 0x0001:
                bits = [mem.get(dev + i, 0) & 1 for i in range(n)] + [0]
                data = bytes((bits[i] << 4) | bits[i + 1] for i in range(0, n, 2))
            else:
                if name == 'M':
                    for w in range(n):
                        v = sum((mem.get(dev + w * 16 + b, 0) & 1) << b for b in range(16)); data += struct.pack('<H', v)
                else:
                    for i in range(n): data += struct.pack('<H', mem.get(dev + i, 0) & 0xFFFF)
        elif cmd == 0x1401:
            payload = body[12:]
            if sub == 0x0001:
                for i in range(n):
                    b = payload[i // 2]; mem[dev + i] = (b >> 4) & 1 if i % 2 == 0 else b & 1
            else:
                if name == 'M':
                    for w in range(n):
                        v = struct.unpack('<H', payload[w*2:w*2+2])[0]
                        for b in range(16): mem[dev + w*16 + b] = (v >> b) & 1
                else:
                    for i in range(n): mem[dev + i] = struct.unpack('<H', payload[i*2:i*2+2])[0]
        resp = struct.pack('<HH', 0, 0)[:2] + data
        out = bytes([0xD0, 0x00, 0x00, 0xFF, 0xFF, 0x03, 0x00]) + struct.pack('<H', len(resp)) + resp
        c.sendall(out)

threading.Thread(target=sim, daemon=True).start()
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(('127.0.0.1', 1025)); s.listen(5)
def logger():
    while True:
        time.sleep(3)
        print('M0..2', M[0], M[1], M[2], 'D120', D[120], 'D121', D[121], 'paso', st['paso'], 'reqs', len(LOG), LOG[-3:], flush=True)
threading.Thread(target=logger, daemon=True).start()
while True:
    c, _ = s.accept(); threading.Thread(target=handle, args=(c,), daemon=True).start()
