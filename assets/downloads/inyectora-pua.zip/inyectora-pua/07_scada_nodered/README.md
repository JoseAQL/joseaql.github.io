# SCADA de la inyectora en Node-RED (Raspberry Pi 4B ↔ FX5U)

Node-RED en la Raspberry lee el FX5U cada 0.5 s por **SLMP (MC Protocol 3E, TCP, puerto 1025)** y muestra un tablero web en `http://<pi>:1880/dashboard`.

| Archivo | Qué es |
|---|---|
| `flujo_inyectora.json` | Flujo para el PLC real (cambiar la IP en el nodo "FX5U inyectora") |
| `flujo_prueba_casa.json` | El mismo flujo apuntando a `127.0.0.1:1025` para probar sin PLC |
| `plc_simulado.py` | PLC de mentiras que contesta SLMP 3E en `127.0.0.1:1025` |
| `setup_pi.sh` | `instalar` (Node-RED + nodos), `red <IP_PLC> <IP_PI>`, `estado` |
| `autoplc/` | Servicio que **encuentra solo al PLC** en el cable, fija la IP de la Raspberry y conecta Node-RED |
| `captura_prueba.png` | El tablero funcionando contra el PLC simulado |

## Instalar en la Raspberry

```bash
git clone --depth 1 https://github.com/joseantonioquirozluna/Pruebas-.git ~/Pruebas-
cd ~/Pruebas-/inyectora-pua/07_scada_nodered
bash setup_pi.sh instalar
python3 plc_simulado.py &          # solo para probar sin PLC
```

Luego en `http://<pi>:1880`: Menú → Import → `flujo_prueba_casa.json` (o `flujo_inyectora.json` con el PLC) → Deploy.

## GX Works3 (FX5U)

- Ethernet Port: IP, Communication Data Code **Binary**, permitir escritura SLMP en RUN.
- External Device Configuration: **SLMP Connection Module**, TCP, puerto **1025** (5000–5009 están reservados).
- Escribir parámetros y **reiniciar el PLC**.
- Escalera: `MOV K4X0 D150` y `MOV K4Y0 D151` (las X/Y son octales).

El flujo se genera con `codigo/scada/make_flow.py`.

## Conexion automatica (autoplc)

```bash
cd ~/inyectora && sudo bash autoplc/instalar_autoplc.sh
```

Con eso, al conectar el cable:
1. Escucha el cable 8 s (ARP) para ver en que red estan el PLC y el HMI.
2. Prueba esas redes + las de `/etc/autoplc/autoplc.conf` + 192.168.3.x; busca quien contesta SLMP en el puerto 1025.
3. Fija la IP de la Raspberry en esa red (sin gateway) y pasa la IP del PLC a Node-RED (`${PLC_IP}`).
4. Vigila con ping; si el PLC se va, vuelve a buscar. Sin PLC pero con `plc_simulado.py` corriendo, usa el simulador.

`journalctl -u autoplc -f` muestra lo que hace. El tablero muestra la red y los equipos vistos en el cable.
