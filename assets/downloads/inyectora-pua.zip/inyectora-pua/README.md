# Inyectora de plástico — púa triangular

Proyecto escolar de **Control Industrial Avanzado (UAA)**: una inyectora pequeña de plástico (PP/PS) con PLC, HMI e inyector neumático, que fabrica una púa triangular para abrir celulares (33 × 30 × 2.3 mm).

El molde es de aluminio (bloques de 3" × 3" × ½") con sistema de expulsión. La unidad de cierre es de **tornillo directo** y se arma con el metal que ya tengo (canal U, placas, ángulo).

| Vista | |
|---|---|
| ![Máquina cerrada](03_maquina_metal/imagenes/cerrada.png) | ![Prueba en madera](04_prueba_madera/imagenes/abierta.png) |
| Máquina de metal (versión actual) | Prueba de funcionamiento en madera |

## Carpetas

| Carpeta | Qué hay | Estado |
|---|---|---|
| [`01_pieza`](01_pieza) | Modelo 3D de la púa | Listo |
| [`02_molde`](02_molde) | Molde de aluminio con expulsión: STL, G-code (GRBL), SVG para Easel, visor 3D | Listo para maquinar |
| [`03_maquina_metal`](03_maquina_metal) | Unidad de cierre de tornillo directo: planos, despiece, cortes de mi material, DXF, STL, soporte LM12UU para imprimir, visor 3D | Diseño listo · faltan medidas (ver abajo) |
| [`04_prueba_madera`](04_prueba_madera) | La misma máquina con placas de aglomerado de 15 mm para probar cierre, apertura y expulsión. PDF con plantillas 1:1, SVG/DXF y G-code | Listo para cortar |
| [`05_llaveros`](05_llaveros) | Llaveros vectorizados para grabar y cortar en CNC | Listo |
| [`06_diagrama_flujo`](06_diagrama_flujo) | Diagrama de flujo del ciclo del PLC (Mermaid, PNG, SVG) con tabla de E/S | Listo |
| [`docs`](docs) | Estado, decisiones de diseño, dónde comprar, cómo cortar en CNC | — |
| [`codigo`](codigo) | Scripts de Python que generan todos los archivos | — |
| [`archivo`](archivo) | Versiones anteriores de la máquina (v1 a v4) y bocetos | Solo referencia |

**Los visores 3D** (`*.html`) se abren con doble clic en el navegador: se gira con el mouse, se abre y cierra el molde, y al tocar una pieza dice de dónde sale y qué tornillos lleva.

## Por dónde empezar

1. Lee [`docs/00_estado_y_pendientes.md`](docs/00_estado_y_pendientes.md).
2. Corta y arma la **prueba en madera** (`04_prueba_madera`) para revisar que todo cierre y corra suave.
3. Maquina el **molde** (`02_molde`).
4. Haz la **máquina de metal** (`03_maquina_metal`); el cuadro extra de la prueba en madera (WT) sirve de plantilla para barrenar las placas de acero.

## Datos principales

- Carrera de apertura: 25 mm · expulsión automática: 6.35 mm
- Guías: 4 ejes cromados de 12 mm con baleros LM12UU en soportes impresos (PETG)
- Cierre: varilla roscada ½"-13 con cople soldado a la placa móvil; rosca autobloqueante
- Fuerza de cierre aprox.: 118 kgf con reducción 4:1 · 148 kgf con 5:1 (motor NEMA 17)

## Versiones de la máquina

Las versiones anteriores nunca se borran: están en [`archivo`](archivo).

| Versión | Carpeta | Qué cambió |
|---|---|---|
| v1 | `archivo/maquina_v1_rodilleras` | Unidad de cierre de rodilleras (toggle) con motor NEMA 17 y tornillo T8 |
| v2 | `archivo/maquina_v2_canal_U` | Tornillo directo; placas fija y trasera de canal U con cejas, placa móvil de 6 mm |
| v3 | `archivo/maquina_v3_escuadras_bujes` | Vuelta al boceto 1: escuadras de ángulo abajo, trasera sin cejas, móvil de 2.5 mm, bujes de bronce |
| v4 | `archivo/maquina_v4_LM12UU_primer_soporte` | Ejes de 12 mm + LM12UU con soportes impresos, despiece completo y tornillería por unión |
| **v5 (actual)** | `03_maquina_metal` | Soporte LM12UU corregido (oreja al lado, tuercas M4 atrapadas) |
| madera v1 | `04_prueba_madera` | Prueba de funcionamiento con aglomerado de 15 mm, archivos para CNC |
