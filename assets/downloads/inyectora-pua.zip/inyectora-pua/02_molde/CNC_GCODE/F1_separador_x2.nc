( SEPARADOR (hacer 2) - cara superior )
( Material: solera aluminio 3/4 x 1/2 in cortada a 76.2 mm, acostada con la cara de 12.7 mm hacia arriba )
( Herramienta: fresa plana 1/8" (3.175 mm) carburo para aluminio )
( Cero X0 Y0: esquina inferior izquierda | Z0: cara superior del material )
( Solo marca 2 puntos: barrenar D5.5 atravesando (19.05 mm) )
G21 G90 G17 G94
G0 Z5.0
M3 S10000
G4 P3
G0 Z5.0
G0 X6.350 Y26.000
G0 Z0.5
G1 Z-0.500 F100
G0 Z5.0
G0 Z5.0
G0 X6.350 Y50.000
G0 Z0.5
G1 Z-0.500 F100
G0 Z5.0
G0 Z5.0
M5
G0 X0 Y0
M30
