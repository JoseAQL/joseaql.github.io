( MOLDE - placa B, cara trasera (la que toca la placa fija) )
( Material: placa B ya maquinada )
( Herramienta: fresa plana 1/8" (3.175 mm) carburo para aluminio )
( Cero X0 Y0: esquina inferior izquierda | Z0: cara superior del material )
( 4 puntos: broca 4.2 prof 8 + machuelo M5 )
G21 G90 G17 G94
G0 Z5.0
M3 S10000
G4 P3
G0 Z5.0
G0 X6.350 Y30.000
G0 Z0.5
G1 Z-0.600 F100
G0 Z5.0
G0 Z5.0
G0 X6.350 Y46.000
G0 Z0.5
G1 Z-0.600 F100
G0 Z5.0
G0 Z5.0
G0 X69.850 Y30.000
G0 Z0.5
G1 Z-0.600 F100
G0 Z5.0
G0 Z5.0
G0 X69.850 Y46.000
G0 Z0.5
G1 Z-0.600 F100
G0 Z5.0
G0 Z5.0
M5
G0 X0 Y0
M30
