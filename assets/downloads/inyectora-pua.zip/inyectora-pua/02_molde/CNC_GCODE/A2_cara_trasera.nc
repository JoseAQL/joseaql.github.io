( PLACA A - cara trasera (voltear A, cavidad hacia abajo; usar la misma esquina como cero) )
( Material: placa A ya maquinada )
( Herramienta: fresa plana 1/8" (3.175 mm) carburo para aluminio )
( Cero X0 Y0: esquina inferior izquierda | Z0: cara superior del material )
( Solo marca 4 puntos: barrenar D4.2 prof 10 y machuelo M5 )
( Patron simetrico: no importa si volteas izquierda-derecha )
G21 G90 G17 G94
G0 Z5.0
M3 S10000
G4 P3
G0 Z5.0
G0 X6.350 Y26.000
G0 Z0.5
G1 Z-0.500 F100
G0 Z5.0
G0 Z5.0
G0 X69.850 Y26.000
G0 Z0.5
G1 Z-0.500 F100
G0 Z5.0
G0 Z5.0
G0 X6.350 Y50.000
G0 Z0.5
G1 Z-0.500 F100
G0 Z5.0
G0 Z5.0
G0 X69.850 Y50.000
G0 Z0.5
G1 Z-0.500 F100
G0 Z5.0
G0 Z5.0
M5
G0 X0 Y0
M30
