# Molde de la púa

7 placas de aluminio: B (fija), A (cavidad), 2 separadores, porta-botadores, placa expulsora, placa base. Ver `LEEME_ensamble.txt`.

- `CNC_GCODE/`: G-code GRBL por cara (A1…F1). `M1` y `M2` agregan los barrenos para montar el molde en la máquina.
- `CNC_SVG_Easel/`: lo mismo para Easel.
- `CAD_STL/`: piezas y ensamble.
- `visor_molde_3D.html`: molde abriendo y expulsando.

Botadores: tornillos Allen M4 × 30 torneados a Ø3 (largo total 24.1 / 23.1 ×3 / 22.9). Retornos: Allen M6 × 30 de rosca parcial, largo 25.4.
