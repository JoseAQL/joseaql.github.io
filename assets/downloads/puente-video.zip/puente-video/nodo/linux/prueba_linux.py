"""Prueba del nodo Linux sin pantalla: la PC (pc/nodos.py) le manda video."""
import os
import subprocess
import sys
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, "..", "..", "pc"))
import numpy as np  # noqa: E402

import nodos  # noqa: E402

p = subprocess.Popen([sys.executable, os.path.join(AQUI, "nodo_linux.py"), "--id", "5", "--puerto", "5405",
                      "--sin-pantalla", "--ancho", "1280", "--alto", "720"])
try:
    time.sleep(3)
    img = np.zeros((1080, 1920, 3), np.uint8)
    d = nodos.Descubridor({"pantalla": lambda: img, "celular_sale": lambda: None, "celular_entra": lambda: None})
    n = d.agregar("127.0.0.1", 5405, 5)
    n.fuente = "Pantalla completa"
    time.sleep(4)
    print("nodo Linux:", n.estado, n.fps, "fps", n.ancho, "x", n.alto)
    assert n.fps >= 5 and (n.ancho, n.alto) == (1280, 720)
    print("Nodo Linux: OK")
finally:
    p.terminate()
