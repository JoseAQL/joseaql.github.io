#!/usr/bin/env python3
"""Nodo Puente Video para Linux: Raspberry Pi 4B, Orange Pi Zero 2W o cualquier PC.

Recibe video por Ethernet con el mismo protocolo que el nodo STM32 y lo muestra
a pantalla completa por HDMI. Aparece solo en la consola «Pantallas HDMI (nodos)»
del programa de la PC, y el celular puede mandarle directo escribiendo su IP.

    python3 nodo_linux.py --id 1                # pantalla completa
    python3 nodo_linux.py --id 2 --ventana      # en ventana, para probar

Protocolo (TCP 5000): 1 byte tipo | 4 bytes largo | datos
    tipo 1 = JPEG, 2 = texto, 3 = acuse (lo manda el nodo al mostrar cada cuadro)
Anuncio UDP broadcast al puerto 5001 cada segundo: PUENTE-NODO|id|ancho|alto|puerto
"""

import argparse
import io
import os
import socket
import struct
import threading
import time

TIPO_JPEG, TIPO_TEXTO, TIPO_ACUSE = 1, 2, 3
PUERTO_ANUNCIO = 5001
LARGO_MAXIMO = 16 * 1024 * 1024


def recibir_exacto(s, n):
    datos = bytearray(n)
    vista = memoryview(datos)
    leidos = 0
    while leidos < n:
        r = s.recv_into(vista[leidos:], n - leidos)
        if r == 0:
            raise ConnectionError("cerró la conexión")
        leidos += r
    return bytes(datos)


def mi_ip():
    """IP con la que salimos a la red (solo para mostrarla en pantalla)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.168.77.1", 9))
            return s.getsockname()[0]
    except OSError:
        return "sin IP"


class Red:
    """Servidor TCP de un solo cliente (el nuevo reemplaza al anterior) + anuncio UDP."""

    def __init__(self, id_nodo, ancho, alto, puerto):
        self.id, self.ancho, self.alto, self.puerto = id_nodo, ancho, alto, puerto
        self.cond = threading.Condition()
        self.cliente = None
        self.nombre = ""
        self.pendientes = []          # bytes JPEG completos, el más viejo primero (máx 2)
        self.identificar = False
        self.candado_escritura = threading.Lock()

    def iniciar(self):
        threading.Thread(target=self._aceptar, daemon=True).start()
        threading.Thread(target=self._anunciar, daemon=True).start()

    def _anunciar(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        texto = f"PUENTE-NODO|{self.id}|{self.ancho}|{self.alto}|{self.puerto}".encode()
        while True:
            try:
                s.sendto(texto, ("255.255.255.255", PUERTO_ANUNCIO))
            except OSError:
                pass  # todavía sin red
            time.sleep(1)

    def _aceptar(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", self.puerto))
        srv.listen(2)
        while True:
            c, _ = srv.accept()
            c.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            with self.cond:
                anterior, self.cliente = self.cliente, c
                self.pendientes.clear()
                self.nombre = ""
            if anterior is not None:
                try:
                    anterior.close()
                except OSError:
                    pass
            self.escribir(c, TIPO_TEXTO, f"HOLA|NODO {self.id} {self.ancho}x{self.alto}".encode())
            threading.Thread(target=self._recibir, args=(c,), daemon=True).start()

    def escribir(self, c, tipo, datos=b""):
        try:
            with self.candado_escritura:
                c.sendall(struct.pack("!BI", tipo, len(datos)) + datos)
        except OSError:
            pass

    def _recibir(self, c):
        try:
            while True:
                tipo, largo = struct.unpack("!BI", recibir_exacto(c, 5))
                if largo > LARGO_MAXIMO:
                    break
                datos = recibir_exacto(c, largo) if largo else b""
                if tipo == TIPO_JPEG:
                    with self.cond:
                        if self.cliente is not c:
                            break
                        if len(self.pendientes) >= 2:
                            # no debería pasar (máx 2 en camino): se tira el más viejo y se acusa
                            self.pendientes.pop(0)
                            self.escribir(c, TIPO_ACUSE)
                        self.pendientes.append(datos)
                        self.cond.notify_all()
                elif tipo == TIPO_TEXTO:
                    texto = datos.decode("utf-8", "replace")
                    if texto == "IDENTIFICAR":
                        self.identificar = True
                    elif texto.startswith("HOLA|"):
                        self.nombre = texto[5:]
        except (OSError, ConnectionError, struct.error):
            pass
        finally:
            with self.cond:
                if self.cliente is c:
                    self.cliente = None
                    self.pendientes.clear()
            try:
                c.close()
            except OSError:
                pass

    def tomar_cuadro(self, espera):
        with self.cond:
            if not self.pendientes:
                self.cond.wait(espera)
            if self.pendientes:
                return self.cliente, self.pendientes.pop(0)
        return None, None


def main():
    ap = argparse.ArgumentParser(description="Nodo Puente Video (Ethernet → HDMI) para Linux")
    ap.add_argument("--id", type=int, default=int(os.environ.get("NODO_ID", "1")), help="número del nodo")
    ap.add_argument("--puerto", type=int, default=5000)
    ap.add_argument("--ancho", type=int, default=0, help="ancho que se le pide a la PC (0 = el de la pantalla)")
    ap.add_argument("--alto", type=int, default=0)
    ap.add_argument("--maximo", type=int, default=1280,
                    help="lado largo máximo a pedir (1280 = 720p, buen balance en Pi 4 y Orange Pi)")
    ap.add_argument("--ventana", action="store_true", help="ventana en vez de pantalla completa")
    ap.add_argument("--sin-pantalla", action="store_true", help="solo red (para pruebas)")
    a = ap.parse_args()

    if a.sin_pantalla:
        os.environ["SDL_VIDEODRIVER"] = "dummy"
    os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
    import pygame  # se importa aquí para que SDL_VIDEODRIVER ya esté puesto

    pygame.display.init()
    pygame.font.init()
    info = pygame.display.Info()
    if a.ventana or a.sin_pantalla:
        pantalla = pygame.display.set_mode((960, 540))
    else:
        pantalla = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        pygame.mouse.set_visible(False)
    pygame.display.set_caption(f"Nodo Puente Video {a.id}")
    W, H = pantalla.get_size()

    # Tamaño que se le pide a quien manda: el de la pantalla, limitado para que
    # la Pi decodifique rápido (la PC escala y rellena de negro).
    ancho, alto = (a.ancho, a.alto) if a.ancho and a.alto else (info.current_w or W, info.current_h or H)
    if max(ancho, alto) > a.maximo:
        f = a.maximo / max(ancho, alto)
        ancho, alto = int(ancho * f) & ~1, int(alto * f) & ~1

    red = Red(a.id, ancho, alto, a.puerto)
    red.iniciar()
    print(f"[nodo {a.id}] pantalla {W}x{H}, pide {ancho}x{alto}, puerto {a.puerto}", flush=True)

    grande = pygame.font.Font(None, max(40, H // 2))
    chica = pygame.font.Font(None, max(20, H // 18))

    def identificacion():
        conectado = red.cliente is not None
        pantalla.fill((16, 24, 32))
        borde = (38, 198, 218) if conectado else (255, 171, 0)
        pygame.draw.rect(pantalla, borde, pantalla.get_rect(), max(6, H // 40))
        t = grande.render(str(a.id), True, (255, 255, 255))
        pantalla.blit(t, t.get_rect(center=(W // 2, H // 2 - H // 20)))
        estado = f"{mi_ip()}:{a.puerto}  ·  " + (f"conectado a {red.nombre or 'alguien'}" if conectado
                                                  else "esperando video")
        t = chica.render(estado, True, (200, 210, 220))
        pantalla.blit(t, t.get_rect(center=(W // 2, H - H // 8)))
        pygame.display.flip()

    identificacion()
    ultimo_cuadro = 0.0
    mostrando_id = True
    cuenta, t0 = 0, time.time()
    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT or (e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_q)):
                pygame.quit()
                return

        cliente, jpeg = red.tomar_cuadro(0.05)
        if jpeg is not None:
            try:
                img = pygame.image.load(io.BytesIO(jpeg), "cuadro.jpg")
                iw, ih = img.get_size()
                if (iw, ih) != (W, H):
                    f = min(W / iw, H / ih)
                    img = pygame.transform.scale(img, (max(1, int(iw * f)), max(1, int(ih * f))))
                pantalla.fill((0, 0, 0))
                pantalla.blit(img, img.get_rect(center=(W // 2, H // 2)))
                pygame.display.flip()
                ultimo_cuadro, mostrando_id = time.time(), False
                cuenta += 1
            except pygame.error:
                pass  # cuadro dañado: igual se acusa
            if cliente is not None:
                red.escribir(cliente, TIPO_ACUSE)

        if red.identificar:
            red.identificar = False
            identificacion()
            ultimo_cuadro, mostrando_id = time.time(), True
        elif not mostrando_id and time.time() - ultimo_cuadro > 3:
            identificacion()
            mostrando_id = True
        elif mostrando_id and time.time() - ultimo_cuadro > 2:
            identificacion()  # refresca IP y estado
            ultimo_cuadro = time.time()

        if time.time() - t0 >= 5:
            if cuenta:
                print(f"[nodo {a.id}] {cuenta / (time.time() - t0):.1f} fps", flush=True)
            cuenta, t0 = 0, time.time()


if __name__ == "__main__":
    main()
