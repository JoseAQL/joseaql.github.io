# Nodo para Raspberry Pi 4B y Orange Pi Zero 2W

Las dos placas corren Linux y ya traen HDMI, así que el nodo es un solo programa en Python (`nodo_linux.py`). Funciona igual que el nodo STM32: aparece solo en **Pantallas HDMI (nodos)…** del programa de la PC, entiende «Identificar» y el celular puede mandarle video directo escribiendo su IP.

| | Raspberry Pi 4B | Orange Pi Zero 2W |
|---|---|---|
| Ethernet | Puerto RJ45 integrado (Gigabit) | **No trae RJ45**: usa la placa de expansión de 24 pines con RJ45 o un adaptador USB‑Ethernet |
| HDMI | micro‑HDMI (2 salidas) | HDMI chico en la placa (revisa si tu cable es mini o micro) |
| Sistema | Raspberry Pi OS (Bookworm) | Debian/Ubuntu de Orange Pi |
| Resolución sugerida | 720p a ~20‑30 fps | 720p, algo menos fps (estimado) |

> ¿Quieres que la Pi también **mande** video, pase archivos y se controle desde el celular? Eso es la app completa: [`raspberry/RASPBERRY.md`](../../raspberry/RASPBERRY.md). Este nodo es solo para una pantalla que recibe.

## Instalación

1. Instala el sistema en la microSD (con o sin escritorio) y conecta la placa a la red: al switch, o directo a la PC con el programa de la PC abierto (le da IP sola).
2. Copia la carpeta `nodo/linux` a la placa (USB, `scp` o `git clone` del repo).
3. Corre, con el número de este nodo:
   ```
   sudo sh instalar.sh 1
   ```
   - **Con escritorio:** arranca solo al iniciar sesión.
   - **Sin escritorio (Lite):** queda como servicio y dibuja directo en el HDMI.
4. En la pantalla aparece el número grande, la IP y «esperando video». En la PC abre **Pantallas HDMI (nodos)…** y elige qué mandarle.

Para probar a mano: `python3 nodo_linux.py --id 1 --ventana`. Salir: Esc o Q.

## Opciones

- `--maximo 1920`: pide 1080p (más nítido, menos fps). Por defecto 1280 (720p).
- `--ancho 800 --alto 600`: fija el tamaño exacto que se le pide a la PC.
- `--puerto 5000`: cambia el puerto TCP.

## Estado

- **Probado aquí, sin pantalla:** la PC manda a 30 fps, el nodo contesta acuses y la identificación funciona.
- **Falta probar en una Pi 4B y una Orange Pi reales:** los fps verdaderos, y el modo sin escritorio (KMS/DRM). En la Orange Pi depende de la imagen del sistema; si sin escritorio no sale imagen, usa la imagen con escritorio.
