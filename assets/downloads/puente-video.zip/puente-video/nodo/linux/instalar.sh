#!/bin/sh
# Instala el nodo Puente Video en Raspberry Pi 4B, Orange Pi Zero 2W o cualquier
# Linux con Debian/Ubuntu/Raspberry Pi OS, y lo deja arrancando solo al prender.
#
#   sudo sh instalar.sh 3        # 3 = número de este nodo
#
# Con escritorio: arranca al iniciar sesión (autostart).
# Sin escritorio (Lite): servicio de systemd que dibuja directo en el HDMI (KMS/DRM).
set -e

ID="${1:-1}"
DESTINO=/opt/puente-nodo
USUARIO="${SUDO_USER:-$(id -un)}"
AQUI="$(cd "$(dirname "$0")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then
  echo "Corre con sudo: sudo sh instalar.sh $ID"
  exit 1
fi

echo "== Instalando dependencias"
apt-get update -qq
apt-get install -y -qq python3 python3-pygame

echo "== Copiando el programa a $DESTINO"
mkdir -p "$DESTINO"
cp "$AQUI/nodo_linux.py" "$DESTINO/"
chmod 755 "$DESTINO/nodo_linux.py"

# Para dibujar sin escritorio el usuario necesita estos grupos
usermod -aG video,render,input "$USUARIO" 2>/dev/null || usermod -aG video,input "$USUARIO"

if [ "$(systemctl get-default)" = "graphical.target" ]; then
  echo "== Hay escritorio: arranque automático al iniciar sesión"
  CASA=$(getent passwd "$USUARIO" | cut -d: -f6)
  mkdir -p "$CASA/.config/autostart"
  cat > "$CASA/.config/autostart/puente-nodo.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Nodo Puente Video
Exec=python3 $DESTINO/nodo_linux.py --id $ID
X-GNOME-Autostart-enabled=true
EOF
  chown -R "$USUARIO" "$CASA/.config/autostart"
  echo "Listo. Reinicia la placa o corre: python3 $DESTINO/nodo_linux.py --id $ID"
else
  echo "== Sin escritorio: servicio de systemd"
  cat > /etc/systemd/system/puente-nodo.service <<EOF
[Unit]
Description=Nodo Puente Video (Ethernet a HDMI)
After=network-online.target
Wants=network-online.target

[Service]
User=$USUARIO
Environment=SDL_VIDEODRIVER=kmsdrm
ExecStart=/usr/bin/python3 $DESTINO/nodo_linux.py --id $ID
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now puente-nodo.service
  echo "Listo. Ver estado: systemctl status puente-nodo   Ver registro: journalctl -u puente-nodo -f"
fi
