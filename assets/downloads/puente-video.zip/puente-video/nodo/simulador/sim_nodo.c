/*
 * sim_nodo.c — simulador del receptor en la PC (Linux, macOS o WSL).
 *
 * Usa EXACTAMENTE el mismo núcleo que el STM32 (puente_nodo.c); solo cambia
 * la red (sockets POSIX en vez de LwIP) y la "pantalla" (guarda archivos).
 *
 *   gcc -O2 -I../firmware/Core/Inc sim_nodo.c ../firmware/Core/Src/puente_nodo.c -o sim_nodo
 *   ./sim_nodo <id> <ancho> <alto> [puerto] [carpeta] [ms_por_cuadro]
 *
 * Guarda el último cuadro en <carpeta>/nodo<id>.jpg y la pantalla de
 * identificación en <carpeta>/nodo<id>_id.ppm.
 */
#include "puente_nodo.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#define CAPACIDAD (1024u * 1024u)

static uint8_t bufer0[CAPACIDAD], bufer1[CAPACIDAD];
static pn_nodo_t nodo;
static int id_nodo, ancho, alto;
static const char *carpeta = "/tmp";

static long ahora_ms(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000L + tv.tv_usec / 1000;
}

static int enviar_todo(int s, const void *d, size_t n)
{
    const uint8_t *p = d;
    while (n) {
        ssize_t r = send(s, p, n, MSG_NOSIGNAL);
        if (r <= 0) return -1;
        p += r;
        n -= (size_t)r;
    }
    return 0;
}

static int enviar_mensaje(int s, uint8_t tipo, const void *datos, uint32_t largo)
{
    uint8_t cab[PN_CABECERA];
    pn_armar_cabecera(cab, tipo, largo);
    if (enviar_todo(s, cab, sizeof cab)) return -1;
    return largo ? enviar_todo(s, datos, largo) : 0;
}

static void guardar_identificacion(uint8_t conectado)
{
    uint16_t *fb = malloc((size_t)ancho * alto * 2);
    if (!fb) return;
    pn_dibujar_identificacion(fb, ancho, alto, id_nodo, conectado);
    char ruta[512];
    snprintf(ruta, sizeof ruta, "%s/nodo%d_id.ppm", carpeta, id_nodo);
    FILE *f = fopen(ruta, "wb");
    if (f) {
        fprintf(f, "P6\n%d %d\n255\n", ancho, alto);
        for (int i = 0; i < ancho * alto; i++) {
            uint16_t c = fb[i];
            uint8_t rgb[3] = {(uint8_t)((c >> 8) & 0xF8), (uint8_t)((c >> 3) & 0xFC), (uint8_t)((c << 3) & 0xF8)};
            fwrite(rgb, 1, 3, f);
        }
        fclose(f);
        printf("[nodo %d] identificación guardada en %s\n", id_nodo, ruta);
    }
    free(fb);
}

int main(int argc, char **argv)
{
    if (argc < 4) {
        fprintf(stderr, "uso: %s <id> <ancho> <alto> [puerto] [carpeta] [ms_por_cuadro]\n", argv[0]);
        return 1;
    }
    signal(SIGPIPE, SIG_IGN);
    setvbuf(stdout, NULL, _IOLBF, 0);
    id_nodo = atoi(argv[1]);
    ancho = atoi(argv[2]);
    alto = atoi(argv[3]);
    int puerto = argc > 4 ? atoi(argv[4]) : (int)PN_PUERTO_TCP;
    if (argc > 5) carpeta = argv[5];
    int ms_cuadro = argc > 6 ? atoi(argv[6]) : 0;

    pn_iniciar(&nodo, bufer0, bufer1, CAPACIDAD);

    int escucha = socket(AF_INET, SOCK_STREAM, 0);
    int uno = 1;
    setsockopt(escucha, SOL_SOCKET, SO_REUSEADDR, &uno, sizeof uno);
    struct sockaddr_in dir = {0};
    dir.sin_family = AF_INET;
    dir.sin_port = htons((uint16_t)puerto);
    dir.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(escucha, (struct sockaddr *)&dir, sizeof dir) || listen(escucha, 2)) {
        perror("bind/listen");
        return 1;
    }

    int udp = socket(AF_INET, SOCK_DGRAM, 0);
    setsockopt(udp, SOL_SOCKET, SO_BROADCAST, &uno, sizeof uno);
    struct sockaddr_in anuncio = {0};
    anuncio.sin_family = AF_INET;
    anuncio.sin_port = htons(PN_PUERTO_ANUNCIO);
    anuncio.sin_addr.s_addr = htonl(INADDR_BROADCAST);

    printf("[nodo %d] %dx%d escuchando en el puerto %d\n", id_nodo, ancho, alto, puerto);
    guardar_identificacion(0);

    int cliente = -1;
    long ultimo_anuncio = 0, ultimo_reporte = ahora_ms();
    uint32_t mostrados = 0, mostrados_antes = 0;
    static uint8_t bloque[64 * 1024];

    for (;;) {
        long t = ahora_ms();
        if (t - ultimo_anuncio >= 1000) {
            char txt[96];
            int n = pn_texto_anuncio(txt, sizeof txt, id_nodo, ancho, alto, (unsigned)puerto);
            sendto(udp, txt, (size_t)n, 0, (struct sockaddr *)&anuncio, sizeof anuncio);
            ultimo_anuncio = t;
        }
        if (t - ultimo_reporte >= 2000) {
            if (cliente >= 0)
                printf("[nodo %d] %u fps, descartados %u\n", id_nodo,
                       (mostrados - mostrados_antes) * 1000u / (unsigned)(t - ultimo_reporte), nodo.descartados);
            mostrados_antes = mostrados;
            ultimo_reporte = t;
        }

        fd_set lectura;
        FD_ZERO(&lectura);
        FD_SET(escucha, &lectura);
        int maximo = escucha;
        if (cliente >= 0) {
            FD_SET(cliente, &lectura);
            if (cliente > maximo) maximo = cliente;
        }
        struct timeval espera = {0, 100000};
        if (select(maximo + 1, &lectura, NULL, NULL, &espera) < 0 && errno != EINTR) break;

        if (FD_ISSET(escucha, &lectura)) {
            int nuevo = accept(escucha, NULL, NULL);
            if (nuevo >= 0) {
                if (cliente >= 0) close(cliente); /* el nuevo reemplaza al anterior */
                cliente = nuevo;
                setsockopt(cliente, IPPROTO_TCP, TCP_NODELAY, &uno, sizeof uno);
                pn_reiniciar(&nodo);
                char hola[64];
                int n = pn_texto_hola(hola, sizeof hola, id_nodo, ancho, alto);
                enviar_mensaje(cliente, PN_TIPO_TEXTO, hola, (uint32_t)n);
                printf("[nodo %d] alguien se conectó\n", id_nodo);
            }
        }

        if (cliente >= 0 && FD_ISSET(cliente, &lectura)) {
            ssize_t r = recv(cliente, bloque, sizeof bloque, 0);
            if (r <= 0) {
                printf("[nodo %d] se desconectó\n", id_nodo);
                close(cliente);
                cliente = -1;
                pn_reiniciar(&nodo);
                continue;
            }
            pn_alimentar(&nodo, bloque, (uint32_t)r);
        }

        /* "pantalla": lo que en el STM32 hace el JPEG por hardware + LTDC */
        pn_cuadro_t *c;
        while ((c = pn_siguiente_cuadro(&nodo)) != NULL) {
            if (ms_cuadro > 0) usleep((useconds_t)ms_cuadro * 1000);
            char ruta[512];
            snprintf(ruta, sizeof ruta, "%s/nodo%d.jpg", carpeta, id_nodo);
            FILE *f = fopen(ruta, "wb");
            if (f) {
                fwrite(c->datos, 1, c->largo, f);
                fclose(f);
            }
            mostrados++;
            pn_cuadro_mostrado(&nodo, c);
        }
        if (nodo.identificar) {
            nodo.identificar = 0;
            guardar_identificacion(cliente >= 0);
        }
        uint32_t acuses = pn_tomar_acuses(&nodo);
        while (cliente >= 0 && acuses--) {
            if (enviar_mensaje(cliente, PN_TIPO_ACUSE, NULL, 0)) break;
        }
    }
    return 0;
}
