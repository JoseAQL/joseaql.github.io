"""Prueba de punta a punta: la PC (pc/nodos.py) manda video a dos nodos simulados.

    python prueba_nodos.py <ruta a sim_nodo>

La usa GitHub Actions; también sirve en tu PC con Linux o WSL.
"""
import os
import subprocess
import sys
import tempfile
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, "..", "..", "pc"))

import cv2  # noqa: E402
import numpy as np  # noqa: E402

import nodos  # noqa: E402

sim = sys.argv[1]
carpeta = tempfile.mkdtemp()
procesos = [subprocess.Popen([sim, "1", "800", "600", "5301", carpeta, "5"]),
            subprocess.Popen([sim, "2", "800", "480", "5302", carpeta, "5"])]
try:
    time.sleep(1)
    pantalla = np.zeros((1080, 1920, 3), np.uint8)
    pantalla[:, :960] = (255, 0, 0)
    pantalla[:, 960:] = (0, 0, 255)
    d = nodos.Descubridor({"pantalla": lambda: pantalla, "celular_sale": lambda: None,
                           "celular_entra": lambda: None})
    n1 = d.agregar("127.0.0.1", 5301, 1)
    n2 = d.agregar("127.0.0.1", 5302, 2)
    n1.fuente = "Pantalla ½ izquierda"
    n2.fuente = "Pantalla ½ derecha"
    time.sleep(3)
    print("nodo 1:", n1.estado, n1.fps, "fps", n1.ancho, "x", n1.alto)
    print("nodo 2:", n2.estado, n2.fps, "fps", n2.ancho, "x", n2.alto)
    assert n1.fps >= 10 and n2.fps >= 10, "muy pocos cuadros"
    assert (n2.ancho, n2.alto) == (800, 480), "no leyó el tamaño del nodo"
    a = cv2.imread(os.path.join(carpeta, "nodo1.jpg"))
    b = cv2.imread(os.path.join(carpeta, "nodo2.jpg"))
    assert a.shape == (600, 800, 3) and b.shape == (480, 800, 3)
    assert a[300, 400, 0] > 200 and a[300, 400, 2] < 60, "el nodo 1 debía ver la mitad azul"
    assert b[240, 400, 2] > 200 and b[240, 400, 0] < 60, "el nodo 2 debía ver la mitad roja"
    print("Pared de video: OK")
finally:
    for p in procesos:
        p.terminate()
