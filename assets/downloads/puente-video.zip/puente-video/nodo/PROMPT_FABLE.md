# Prompt para Fable — hardware del nodo Puente Video (Ethernet → HDMI)

> Este es el encargo que se le dio a Fable para la parte más difícil: el diseño electrónico. Se puede volver a usar tal cual para iterar.

---

Eres ingeniero de hardware. Diseña la placa del **nodo Puente Video**: un receptor que recibe video JPEG por Ethernet y lo saca por HDMI. Varios nodos van en un switch y cada uno muestra lo que le manda la PC o el celular (pared de video casera, estilo conciertos).

## Lo que ya existe (léelo antes de diseñar)
- `puente-video/nodo/firmware/Core/` — firmware para STM32CubeIDE, ya compila para Cortex‑M7:
  - `puente_nodo.c/.h`: protocolo (TCP 5000, cuadros JPEG con acuse, anuncio UDP 5001).
  - `puente_lwip.c`: LwIP raw, DHCP con IP de respaldo 192.168.77.(100+id).
  - `pantalla_stm32.c`: JPEG por hardware → DMA2D (YCbCr→RGB565) → LTDC, con doble búfer en SDRAM.
  - `nodo_placa.h`: **todo lo que depende de la placa** (resolución, mapa de SDRAM en 0xD0000000, DIP de ID en GPIOG0‑3, LED en PB0). Tu diseño manda: si cambias algo, corrige este archivo.
- `puente-video/README.md` y `nodo/README.md` — cómo encaja todo.

## Decisiones ya tomadas (respétalas o justifica por escrito si las cambias)
- MCU **STM32H743** (el F446 no tiene MAC Ethernet, LTDC ni JPEG por hardware). Encapsulado soldable a mano o con JLCPCB: LQFP176 de preferencia.
- PHY **LAN8742A** en RMII, RJ45 con magnéticos integrados.
- **SDRAM 16 bits de 32 MB** (IS42S16160J o equivalente disponible en JLCPCB/LCSC) en el FMC.
- LTDC RGB888 (24 líneas) → **TFP410** (DVI, compatible con HDMI sin audio) → conector HDMI tipo A, con protección/ESD y DDC (por ejemplo TPD12S016).
- Resolución objetivo **1024x600 @ 60 Hz** (pixel clock ≈ 51.2 MHz). Evalúa también 1280x720 @ 60 (74.25 MHz) y di si el ancho de banda de la SDRAM alcanza con doble búfer RGB565 + DMA2D + JPEG.
- Alimentación **USB‑C 5 V solo de entrada** (resistencias de 5.1 kΩ en CC1/CC2), presupuesto de corriente y regulación a 3.3 V (buck recomendado). VCAP del regulador interno del H7.
- Programación por **SWD** (conector Tag‑Connect o 2x5 de 1.27 mm) para el ST‑Link de STM32CubeIDE; botón de reset y BOOT0.
- **DIP switch de 4 posiciones** para el número de nodo, LED de estado, LED de link.

## Lo que tienes que entregar (archivos dentro de `puente-video/nodo/hardware/`)
1. `DISENO.md`:
   - Diagrama de bloques y árbol de alimentación con corrientes estimadas.
   - Lista de materiales (BOM) con número de parte y, si lo sabes, código LCSC; marca lo que es difícil de conseguir en México.
   - Reloj: HSE recomendado, PLL para 480 MHz núcleo, y el PLL3 para el pixel clock del LTDC (valores de M/N/P/Q/R).
   - Tiempos del LTDC para 1024x600 y 1280x720 (HSYNC/HBP/HFP/VSYNC/VBP/VFP y polaridades) y tiempos de la SDRAM elegida para CubeMX (TMRD, TXSR, TRAS, TRC, TWR, TRP, TRCD, CAS, refresh).
   - Configuración del MPU para SDRAM y para los descriptores de Ethernet en D2 (el problema clásico del H7 con LwIP).
   - Reglas de PCB: 4 capas recomendadas, apilado, pares diferenciales TMDS de 100 Ω, RMII a 50 Ω, largo igualado de SDRAM, colocación de desacoplos, zona de magnéticos del RJ45.
   - Lista de riesgos y cómo probarlos en orden (primero en una Nucleo‑H743ZI2 o una placa de desarrollo con LTDC antes de mandar a fabricar).
2. `pines.csv`: asignación completa de pines del STM32H743 (señal, pin, función alterna), **revisada contra conflictos** entre ETH RMII, FMC SDRAM y LTDC de 24 bits. Este es el punto más delicado: verifica cada función alterna.
3. `conexiones.md`: lista de conexiones componente a componente (como netlist en texto), lista para capturar el esquemático en KiCad.
4. Si cambias pines o memoria, corrige `firmware/Core/Inc/nodo_placa.h` y vuelve a correr `firmware/ci/compilar.sh` para confirmar que compila.

No inventes números de parte ni funciones alternas: si no estás seguro, márcalo como "VERIFICAR" con lo que habría que revisar en la hoja de datos. Todo en español.
