# Nodo Puente Video: receptor Ethernet → HDMI

Una cajita con STM32H743. Entra un cable Ethernet y sale HDMI. La conectas a un switch junto con otras, y desde la PC (o directo desde el celular) a cada pantalla le mandas algo distinto, como en los conciertos.

```
PC o celular ──► switch ──┬──► nodo 1 ──HDMI──► pantalla 1
                          ├──► nodo 2 ──HDMI──► pantalla 2
                          └──► nodo N ──HDMI──► pantalla N
```

## Qué hay en esta carpeta

| Carpeta | Qué es | Estado |
|---|---|---|
| `firmware/Core/` | Código para STM32CubeIDE: protocolo, red (LwIP), JPEG por hardware → DMA2D → LTDC con doble búfer | Compila para el H743 con el HAL y LwIP oficiales de ST (lo revisa GitHub Actions). **Falta probar en hardware.** |
| `firmware/ci/` | Script que revisa que el firmware compile | Listo |
| `firmware/proyecto/` | Proyecto completo con Makefile (`make PLACA=nodo` o `PLACA=nucleo`): arranque, relojes, MPU, SDRAM, LTDC, Ethernet + LwIP. Ver `PROYECTO.md` | Compila y enlaza; **falta probar en hardware** |
| `linux/` | **Nodo para Raspberry Pi 4B y Orange Pi Zero 2W** (Python + pygame, instalador que arranca solo). Ver [linux/LINUX.md](linux/LINUX.md) | Probado sin pantalla a 30 fps; falta en placa real |
| `pico/` | **Nodo económico** Raspberry Pi Pico 2 + módulo W5500 + placa DVI, 640x480. Ver [pico/PICO.md](pico/PICO.md) | Compila (.uf2 en Releases); JPEG probado en PC; falta hardware |
| `simulador/` | El mismo núcleo del nodo corriendo en la PC (Linux/WSL), más una prueba de pared de video | Probado: 2 nodos a 30 fps cada uno |
| `hardware/` | Diseño electrónico hecho por Fable: bloques, BOM, relojes, tiempos, pines del H743 revisados contra la base de datos de ST, netlist para KiCad, reglas de PCB y riesgos | En papel, falta capturarlo en KiCad |
| `PROMPT_FABLE.md` | El encargo que se le dio a Fable, para volver a usarlo | — |

## Cómo se usa (cuando exista la placa)

1. Pon el número del nodo con el DIP switch (1 a 15).
2. Conéctalo al switch. Si hay router, toma IP por DHCP; si no, se pone `192.168.77.(100 + número)`.
3. En la PC abre Puente Video → **Pantallas HDMI (nodos)…**. Los nodos aparecen solos. A cada uno elígele: cámara, video del celular, pantalla completa, media, tercio o cuarto de pantalla (pared de video) o patrón de prueba.
4. **Identificar todas** pone el número gigante en cada pantalla para saber cuál es cuál antes del evento.
5. Desde el celular: deja ese nodo en «Nada» en la PC y en la app escribe la IP del nodo. El celular ajusta el video al tamaño del nodo solo.

## Protocolo

El mismo de la app (TCP 5000, `tipo | largo | datos`, JPEG con acuse). Lo nuevo:

- El nodo es **servidor**, solo recibe video. Saluda con `HOLA|NODO <id> <ancho>x<alto>`.
- Cada segundo se anuncia por UDP broadcast al puerto 5001: `PUENTE-NODO|<id>|<ancho>|<alto>|<puerto>`.
- Entiende el texto `IDENTIFICAR`.
- El JPEG debe ser *baseline* y caber en la pantalla del nodo (la PC y el celular ya lo mandan así).

## Para llevarlo a STM32CubeIDE

1. Crea un proyecto para STM32H743IITx y configura en CubeMX lo que dice `hardware/DISENO.md`: relojes (PLL1 480 MHz, PLL3 pixel clock), ETH RMII + LwIP con DHCP (sin RTOS), FMC SDRAM banco 2, LTDC (800x600 por defecto), JPEG, DMA2D, GPIO del DIP y LED, MPU.
2. Copia `firmware/Core/Inc/*` y `firmware/Core/Src/*` a tu proyecto.
3. En `main.c`, dentro de los `USER CODE`: llama `puente_nodo_iniciar();` después de inicializar todo, y en el `while (1)`: `MX_LWIP_Process(); puente_nodo_proceso();`.
4. Falta agregar la secuencia de arranque de la SDRAM y `MPU_Config()`. Están descritas en `hardware/DISENO.md`.

## Etapas

| # | Etapa | Estado |
|---|---|---|
| 1 | Investigación y elección de chips (H743, LAN8742A, SDRAM, TFP410) | ✔ |
| 2 | Protocolo para nodos + núcleo en C + simulador | ✔ probado |
| 3 | Firmware CubeIDE (red, JPEG, pantalla) | ✔ compila; falta hardware |
| 4 | PC: consola de pantallas, pared de video, identificar | ✔ probado con simulador |
| 5 | Celular → nodo directo | ✔ (ajusta tamaño) |
| 6 | Diseño electrónico (Fable) | ✔ en papel |
| 7 | Prueba en Nucleo‑H743ZI2 (red + JPEG) y luego placa de desarrollo con LTDC | Pendiente |
| 8 | Esquemático y PCB en KiCad, modelo 3D | Pendiente (en tu PC) |
| 9 | Decodificar JPEG por franjas en RAM interna para más fps (riesgo 1 de Fable) | Pendiente |

## Lo que podría fallar (resumen de `hardware/DISENO.md`)

- **Ancho de banda de la SDRAM:** a 800x600 sobra; a 1024x600 o 720p habrá que decodificar por franjas.
- **No hay sincronía entre pantallas:** cada nodo muestra su cuadro cuando le llega, con unos pocos ms de diferencia. Para una pared de video casera no se nota; en conciertos usan genlock.
- **Pinout de TFP410, TPD12S016 y LAN8742A:** está marcado VERIFICAR; hay que revisarlo contra las hojas de datos antes de rutear.
- **Ethernet del H7 con LwIP:** necesita bien configurado el MPU y la memoria D2. Por eso conviene probar primero en la Nucleo.
