#!/bin/sh
# Revisa que el firmware del nodo compile para Cortex-M7 (STM32H743).
# Uso: compilar.sh <carpeta con arm-none-eabi-gcc/bin> <carpeta con los repos de ST>
set -e
GCC="$1/bin/arm-none-eabi-gcc"
ST="$2"
AQUI="$(cd "$(dirname "$0")" && pwd)"
CORE="$AQUI/../Core"
FLAGS="-mcpu=cortex-m7 -mthumb -mfpu=fpv5-d16 -mfloat-abi=hard -O2 -Wall -Wextra -Werror=implicit-function-declaration
 -DSTM32H743xx -DUSE_HAL_DRIVER
 -I$AQUI -I$CORE/Inc
 -I$ST/stm32h7xx-hal-driver/Inc -I$ST/cmsis-device-h7/Include -I$ST/cmsis-core/CMSIS/Core/Include
 -I$ST/stm32-mw-lwip/src/include -I$ST/stm32-mw-lwip/system"
SALIDA=$(mktemp -d)
for f in puente_nodo.c pantalla_stm32.c puente_lwip.c; do
  echo "== $f"
  $GCC $FLAGS -c "$CORE/Src/$f" -o "$SALIDA/${f%.c}.o"
done
"$1/bin/arm-none-eabi-size" "$SALIDA"/*.o
echo "Firmware del nodo: compila bien para STM32H743"
