/* main.h mínimo solo para revisar que el código compila en CI.
 * En tu proyecto real usa el main.h que genera CubeMX. */
#ifndef MAIN_H
#define MAIN_H
#include "stm32h7xx_hal.h"
#endif
