/*
 * puente_nodo.h — núcleo del receptor "Puente Video" (Ethernet → HDMI).
 *
 * Es C portable: no depende de HAL ni de LwIP, así se prueba en la PC con el
 * simulador y se usa tal cual en el STM32.
 *
 * Protocolo (igual que la app de PC y la de Android), sobre TCP puerto 5000:
 *   1 byte tipo | 4 bytes largo (big-endian) | datos
 *   tipo 1 = cuadro JPEG, 2 = texto UTF-8, 3 = acuse ("ya lo mostré")
 *
 * El nodo es SERVIDOR: el celular o la PC se conectan a él y le mandan JPEG.
 * Por cada JPEG el nodo contesta un acuse cuando ya lo mostró. Quien manda
 * nunca tiene más de 2 cuadros sin acuse, por eso bastan 2 búferes.
 *
 * Textos que entiende el nodo:
 *   "IDENTIFICAR"  muestra su número en grande (para ubicar cada pantalla)
 *   "HOLA|..."     saludo de quien manda (se ignora)
 * Textos que manda:
 *   "HOLA|NODO <id> <ancho>x<alto>"
 *
 * Anuncio por UDP (broadcast, puerto 5001, cada segundo):
 *   "PUENTE-NODO|<id>|<ancho>|<alto>|<puerto>"
 */
#ifndef PUENTE_NODO_H
#define PUENTE_NODO_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PN_PUERTO_TCP     5000u
#define PN_PUERTO_ANUNCIO 5001u
#define PN_TIPO_JPEG      1u
#define PN_TIPO_TEXTO     2u
#define PN_TIPO_ACUSE     3u
#define PN_CABECERA       5u
#define PN_TEXTO_MAX      128u

typedef struct {
    uint8_t *datos;
    uint32_t largo;
    uint32_t numero;      /* orden de llegada, para mostrar el más viejo primero */
    volatile uint8_t listo;
} pn_cuadro_t;

typedef struct {
    /* búferes de cuadros (en el STM32 viven en la SDRAM) */
    pn_cuadro_t cuadros[2];
    uint32_t capacidad;

    /* lectura del mensaje en curso */
    uint8_t cabecera[PN_CABECERA];
    uint32_t llenos_cabecera;
    uint8_t tipo;
    uint32_t largo;
    uint32_t pos;
    int8_t destino;        /* índice del búfer que se llena; -1 = descartar */
    char texto[PN_TEXTO_MAX];

    /* resultados para el bucle principal */
    uint32_t acuses_pendientes;  /* acuses por cuadros descartados o mostrados */
    uint8_t identificar;         /* se pidió mostrar el número */
    uint32_t contador;

    /* estadísticas */
    uint32_t recibidos;
    uint32_t descartados;
} pn_nodo_t;

void pn_iniciar(pn_nodo_t *n, uint8_t *bufer0, uint8_t *bufer1, uint32_t capacidad);

/* Llamar al aceptar una conexión nueva: olvida lo que venía a medias. */
void pn_reiniciar(pn_nodo_t *n);

/* Alimenta bytes recibidos por TCP (pueden venir en cualquier tamaño). */
void pn_alimentar(pn_nodo_t *n, const uint8_t *datos, uint32_t cantidad);

/* Cuadro completo más viejo listo para mostrar, o NULL. */
pn_cuadro_t *pn_siguiente_cuadro(pn_nodo_t *n);

/* Ya se mostró: libera el búfer y deja un acuse pendiente. */
void pn_cuadro_mostrado(pn_nodo_t *n, pn_cuadro_t *c);

/* Regresa cuántos acuses hay que mandar y pone el contador en cero. */
uint32_t pn_tomar_acuses(pn_nodo_t *n);

/* Arma la cabecera de 5 bytes. */
void pn_armar_cabecera(uint8_t salida[PN_CABECERA], uint8_t tipo, uint32_t largo);

/* Textos de saludo y anuncio. Regresan el largo escrito (sin el 0 final). */
int pn_texto_hola(char *salida, size_t cap, int id, int ancho, int alto);
int pn_texto_anuncio(char *salida, size_t cap, int id, int ancho, int alto, unsigned puerto);

/* Dibuja el número del nodo en grande sobre un búfer RGB565 (para "IDENTIFICAR"
 * y para la pantalla de espera). Fondo oscuro, marco y dígitos de 7 segmentos. */
void pn_dibujar_identificacion(uint16_t *fb, int ancho, int alto, int id, uint8_t conectado);

#ifdef __cplusplus
}
#endif
#endif
