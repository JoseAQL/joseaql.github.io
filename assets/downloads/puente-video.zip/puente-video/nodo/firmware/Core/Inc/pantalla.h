#ifndef PANTALLA_H
#define PANTALLA_H

#include <stdint.h>

void pantalla_iniciar(void);
/* Decodifica el JPEG y lo muestra. 0 = bien, -1 = cuadro inválido. */
int pantalla_mostrar_jpeg(const uint8_t *datos, uint32_t largo);
/* Muestra el número del nodo en grande. */
void pantalla_identificar(int id, int conectado);

/* Estadísticas para la consola de depuración. */
typedef struct {
    uint32_t mostrados;      /* cuadros decodificados y mostrados bien */
    uint32_t errores;        /* JPEG inválido, muy grande o que no terminó */
    uint32_t ultimo_ancho;   /* tamaño del último JPEG decodificado */
    uint32_t ultimo_alto;
    uint32_t ultimo_ms;      /* lo que tardó (decodificar + convertir + cambiar búfer) */
} pantalla_estadisticas_t;

const pantalla_estadisticas_t *pantalla_estadisticas(void);

#endif
