/*
 * puente_lwip.h — lo que puente_lwip.c ofrece al main.c del proyecto.
 *
 * Uso (sin RTOS):
 *     MX_LWIP_Init();          // red lista (LwIP + Ethernet)
 *     puente_nodo_iniciar();   // servidor TCP 5000, anuncio UDP 5001, pantalla de espera
 *     while (1) {
 *         MX_LWIP_Process();
 *         puente_nodo_proceso();
 *     }
 */
#ifndef PUENTE_LWIP_H
#define PUENTE_LWIP_H

#include "puente_nodo.h"

void puente_nodo_iniciar(void);
void puente_nodo_proceso(void);

/* Número de nodo (DIP o fijo). Es "weak": una placa puede poner el suyo. */
int nodo_leer_id(void);

/* Para la consola de depuración (solo lectura). */
const pn_nodo_t *puente_nodo_estado(void);
int puente_nodo_id(void);
int puente_nodo_hay_cliente(void);

#endif
