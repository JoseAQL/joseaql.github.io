/*
 * nodo_placa.h — todo lo que depende de la placa y la pantalla.
 *
 * Valores para la placa descrita en nodo/hardware/ (DISENO.md, pines.csv):
 * STM32H743IIT6 (LQFP176) + SDRAM de 32 MB en el banco 2 del FMC
 * (SDNE1 = PH6, SDCKE1 = PH7, SDNWE = PH5) + LTDC → TFP410 → HDMI.
 *
 * Revisión de hardware:
 *   - Base 0xD0000000 de la SDRAM: confirmada. Resolución: se cambió a
 *     800x600 (estándar VESA; 1024x600 no lo aceptan muchas teles).
 *   - DIP de ID: CAMBIADO de PG0-PG3 a PF6-PF9. PG0, PG1 y PG2 son las
 *     direcciones A10, A11 y A12 de la SDRAM en el FMC y no tienen otro pin.
 *   - LED de estado en PB0: confirmado (PB0 no se usa para el LTDC).
 */
#ifndef NODO_PLACA_H
#define NODO_PLACA_H

#include <stdint.h>

#ifdef NODO_PLACA_NUCLEO
/* ======================================================================
 * NUCLEO-H743ZI2 (prueba de red + JPEG, sin SDRAM ni LTDC).
 * Lo activa `make PLACA=nucleo` (define NODO_PLACA_NUCLEO).
 *
 * Se anuncia como 800x600 para que la PC le mande exactamente lo mismo que
 * a un nodo real. No hay pantalla: pantalla_nucleo.c decodifica con el JPEG
 * por hardware hacia un búfer YCbCr chico que se reutiliza y solo cuenta.
 * Los búferes de JPEG van en la AXI SRAM (512 KB), más chicos que en la SDRAM.
 * ====================================================================== */
#ifndef NODO_ANCHO
#define NODO_ANCHO 800
#endif
#ifndef NODO_ALTO
#define NODO_ALTO 600
#endif

#define NODO_JPEG_CAP      (192u * 1024u)          /* por búfer; 2 búferes */
#define NODO_TAM_YCBCR     (32u * 1024u)           /* trozo que se reutiliza */
extern uint8_t nodo_bufer_jpeg[2][NODO_JPEG_CAP];  /* en .axisram (pantalla_nucleo.c) */
#define NODO_JPEG0         ((uint32_t)nodo_bufer_jpeg[0])
#define NODO_JPEG1         ((uint32_t)nodo_bufer_jpeg[1])

/* Sin DIP: el número de nodo es fijo. */
#define NODO_ID_DEFECTO 1

/* LD1 (verde) de la Nucleo está en PB0, igual que el LED de estado del nodo. */
#define NODO_LED_PUERTO GPIOB
#define NODO_LED_PIN    GPIO_PIN_0

#else /* placa del nodo */

/* ---------------------------------------------------------------- pantalla
 * 800x600 @ 60 Hz (VESA, 40 MHz): lo acepta casi cualquier monitor o tele y
 * deja holgura de SDRAM para 30 fps. Para 1024x600 o 720p ver hardware/DISENO.md
 * (tiempos del LTDC y del PLL3) y cambia también la configuración en CubeMX.
 */
#ifndef NODO_ANCHO
#define NODO_ANCHO 800
#endif
#ifndef NODO_ALTO
#define NODO_ALTO 600
#endif

/* ---------------------------------------------------------------- memoria
 * Todo vive en la SDRAM externa. Mapa (para 800x600 caben de sobra; los tamaños se calculan solos):
 *   FB0, FB1      2 x 1.2 MB   cuadros RGB565 que lee el LTDC (doble búfer)
 *   YCBCR         1.8 MB       salida del decodificador JPEG (bloques MCU)
 *   JPEG0, JPEG1  2 x 1 MB     cuadros JPEG que llegan por la red
 * Configura el MPU para que esta región sea write-through o no cacheable,
 * o deja las limpiezas de caché que ya hace pantalla_stm32.c.
 */
#ifndef NODO_SDRAM_BASE
#define NODO_SDRAM_BASE 0xD0000000u   /* FMC SDRAM banco 2 */
#endif
#define NODO_TAM_FB      ((uint32_t)NODO_ANCHO * NODO_ALTO * 2u)
#define NODO_TAM_YCBCR   (((uint32_t)NODO_ANCHO + 16u) * ((uint32_t)NODO_ALTO + 16u) * 3u)
#define NODO_JPEG_CAP    (1024u * 1024u)

#define NODO_FB0     (NODO_SDRAM_BASE)
#define NODO_FB1     (NODO_FB0 + NODO_TAM_FB)
#define NODO_YCBCR   (NODO_FB1 + NODO_TAM_FB)
#define NODO_JPEG0   ((NODO_YCBCR + NODO_TAM_YCBCR + 31u) & ~31u)
#define NODO_JPEG1   (NODO_JPEG0 + NODO_JPEG_CAP)

/* ---------------------------------------------------------------- número de nodo
 * Por defecto se lee de un DIP switch de 4 posiciones (1..15; 0 = usar el
 * valor por defecto). Si tu placa no tiene DIP, borra NODO_ID_CON_DIP.
 */
#define NODO_ID_DEFECTO 1
#define NODO_ID_CON_DIP
#define NODO_ID_PUERTO  GPIOF
#define NODO_ID_PIN0    GPIO_PIN_6
#define NODO_ID_PIN1    GPIO_PIN_7
#define NODO_ID_PIN2    GPIO_PIN_8
#define NODO_ID_PIN3    GPIO_PIN_9   /* con pull-up: switch cerrado a GND = 1 */

/* LED de estado (parpadea lento: sin conexión; rápido: recibiendo video) */
#define NODO_LED_PUERTO GPIOB
#define NODO_LED_PIN    GPIO_PIN_0

#endif /* NODO_PLACA_NUCLEO */

/* ---------------------------------------------------------------- red (las dos placas)
 * Si en 8 s nadie da IP por DHCP, el nodo se pone 192.168.77.(100 + id),
 * la misma red que usa el programa de la PC con el cable directo.
 */
#define NODO_IP_RESPALDO_A 192
#define NODO_IP_RESPALDO_B 168
#define NODO_IP_RESPALDO_C 77
#define NODO_IP_RESPALDO_BASE 100
#define NODO_DHCP_ESPERA_MS 8000u

#endif
