/*
 * puente_nodo.c — núcleo portable del receptor Puente Video.
 * Ver puente_nodo.h para el protocolo.
 */
#include "puente_nodo.h"

#include <stdio.h>
#include <string.h>

#define DESTINO_DESCARTAR (-1)
#define DESTINO_TEXTO     (-2)

void pn_iniciar(pn_nodo_t *n, uint8_t *bufer0, uint8_t *bufer1, uint32_t capacidad)
{
    memset(n, 0, sizeof(*n));
    n->cuadros[0].datos = bufer0;
    n->cuadros[1].datos = bufer1;
    n->capacidad = capacidad;
    n->destino = DESTINO_DESCARTAR;
}

void pn_reiniciar(pn_nodo_t *n)
{
    n->llenos_cabecera = 0;
    n->pos = 0;
    n->largo = 0;
    n->destino = DESTINO_DESCARTAR;
    n->cuadros[0].listo = 0;
    n->cuadros[1].listo = 0;
    n->acuses_pendientes = 0;
}

static int8_t bufer_libre(pn_nodo_t *n)
{
    for (int8_t i = 0; i < 2; i++) {
        if (!n->cuadros[i].listo) return i;
    }
    return DESTINO_DESCARTAR;
}

static void completar(pn_nodo_t *n)
{
    if (n->tipo == PN_TIPO_JPEG) {
        if (n->destino >= 0) {
            pn_cuadro_t *c = &n->cuadros[n->destino];
            c->largo = n->largo;
            c->numero = ++n->contador;
            c->listo = 1;
            n->recibidos++;
        } else {
            /* No cupo: igual se acusa para que quien manda no se quede esperando. */
            n->descartados++;
            n->acuses_pendientes++;
        }
    } else if (n->tipo == PN_TIPO_TEXTO) {
        uint32_t fin = n->largo < PN_TEXTO_MAX - 1 ? n->largo : PN_TEXTO_MAX - 1;
        n->texto[fin] = '\0';
        if (strcmp(n->texto, "IDENTIFICAR") == 0) n->identificar = 1;
    }
    /* tipo 3 (acuse) y desconocidos: no hacen nada en el nodo */
    n->llenos_cabecera = 0;
    n->pos = 0;
    n->destino = DESTINO_DESCARTAR;
}

void pn_alimentar(pn_nodo_t *n, const uint8_t *datos, uint32_t cantidad)
{
    while (cantidad > 0) {
        if (n->llenos_cabecera < PN_CABECERA) {
            uint32_t faltan = PN_CABECERA - n->llenos_cabecera;
            uint32_t m = cantidad < faltan ? cantidad : faltan;
            memcpy(&n->cabecera[n->llenos_cabecera], datos, m);
            n->llenos_cabecera += m;
            datos += m;
            cantidad -= m;
            if (n->llenos_cabecera < PN_CABECERA) break;

            n->tipo = n->cabecera[0];
            n->largo = ((uint32_t)n->cabecera[1] << 24) | ((uint32_t)n->cabecera[2] << 16) |
                       ((uint32_t)n->cabecera[3] << 8) | (uint32_t)n->cabecera[4];
            n->pos = 0;
            if (n->tipo == PN_TIPO_JPEG && n->largo > 0 && n->largo <= n->capacidad) {
                n->destino = bufer_libre(n);
            } else if (n->tipo == PN_TIPO_TEXTO) {
                n->destino = DESTINO_TEXTO;
            } else {
                n->destino = DESTINO_DESCARTAR;
            }
            if (n->largo == 0) completar(n);
            continue;
        }

        uint32_t resto = n->largo - n->pos;
        uint32_t m = cantidad < resto ? cantidad : resto;
        if (n->destino >= 0) {
            memcpy(n->cuadros[n->destino].datos + n->pos, datos, m);
        } else if (n->destino == DESTINO_TEXTO && n->pos < PN_TEXTO_MAX - 1) {
            uint32_t cabe = PN_TEXTO_MAX - 1 - n->pos;
            memcpy(&n->texto[n->pos], datos, m < cabe ? m : cabe);
        }
        n->pos += m;
        datos += m;
        cantidad -= m;
        if (n->pos == n->largo) completar(n);
    }
}

pn_cuadro_t *pn_siguiente_cuadro(pn_nodo_t *n)
{
    pn_cuadro_t *mejor = NULL;
    for (int i = 0; i < 2; i++) {
        pn_cuadro_t *c = &n->cuadros[i];
        /* un búfer que todavía se está llenando no está "listo" */
        if (c->listo && (mejor == NULL || c->numero < mejor->numero)) mejor = c;
    }
    return mejor;
}

void pn_cuadro_mostrado(pn_nodo_t *n, pn_cuadro_t *c)
{
    if (c && c->listo) {
        c->listo = 0;
        n->acuses_pendientes++;
    }
}

uint32_t pn_tomar_acuses(pn_nodo_t *n)
{
    uint32_t a = n->acuses_pendientes;
    n->acuses_pendientes = 0;
    return a;
}

void pn_armar_cabecera(uint8_t salida[PN_CABECERA], uint8_t tipo, uint32_t largo)
{
    salida[0] = tipo;
    salida[1] = (uint8_t)(largo >> 24);
    salida[2] = (uint8_t)(largo >> 16);
    salida[3] = (uint8_t)(largo >> 8);
    salida[4] = (uint8_t)largo;
}

int pn_texto_hola(char *salida, size_t cap, int id, int ancho, int alto)
{
    return snprintf(salida, cap, "HOLA|NODO %d %dx%d", id, ancho, alto);
}

int pn_texto_anuncio(char *salida, size_t cap, int id, int ancho, int alto, unsigned puerto)
{
    return snprintf(salida, cap, "PUENTE-NODO|%d|%d|%d|%u", id, ancho, alto, puerto);
}

/* ------------------------------------------------------------ dibujo */

#define RGB565(r, g, b) (uint16_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3))

static void rect(uint16_t *fb, int ancho, int alto, int x, int y, int w, int h, uint16_t color)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > ancho) w = ancho - x;
    if (y + h > alto) h = alto - y;
    if (w <= 0 || h <= 0) return;
    for (int j = y; j < y + h; j++) {
        uint16_t *fila = fb + (size_t)j * ancho + x;
        for (int i = 0; i < w; i++) fila[i] = color;
    }
}

/* segmentos a b c d e f g para 0-9 */
static const uint8_t SEGMENTOS[10] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F
};

static void digito(uint16_t *fb, int ancho, int alto, int x, int y, int w, int h, int d, uint16_t color)
{
    int t = w / 5;
    int mitad = y + h / 2 - t / 2;
    uint8_t s = SEGMENTOS[d % 10];
    if (s & 0x01) rect(fb, ancho, alto, x, y, w, t, color);                         /* a */
    if (s & 0x02) rect(fb, ancho, alto, x + w - t, y, t, h / 2, color);             /* b */
    if (s & 0x04) rect(fb, ancho, alto, x + w - t, y + h / 2, t, h / 2, color);     /* c */
    if (s & 0x08) rect(fb, ancho, alto, x, y + h - t, w, t, color);                 /* d */
    if (s & 0x10) rect(fb, ancho, alto, x, y + h / 2, t, h / 2, color);             /* e */
    if (s & 0x20) rect(fb, ancho, alto, x, y, t, h / 2, color);                     /* f */
    if (s & 0x40) rect(fb, ancho, alto, x, mitad, w, t, color);                     /* g */
}

void pn_dibujar_identificacion(uint16_t *fb, int ancho, int alto, int id, uint8_t conectado)
{
    const uint16_t fondo = RGB565(16, 24, 32);
    const uint16_t marco = conectado ? RGB565(38, 198, 218) : RGB565(255, 171, 0);
    const uint16_t blanco = RGB565(255, 255, 255);

    rect(fb, ancho, alto, 0, 0, ancho, alto, fondo);
    int g = alto / 40 + 2;
    rect(fb, ancho, alto, 0, 0, ancho, g, marco);
    rect(fb, ancho, alto, 0, alto - g, ancho, g, marco);
    rect(fb, ancho, alto, 0, 0, g, alto, marco);
    rect(fb, ancho, alto, ancho - g, 0, g, alto, marco);

    if (id < 0) id = 0;
    if (id > 99) id = 99;
    int cifras = id >= 10 ? 2 : 1;
    int h = alto / 2;
    int w = h / 2;
    int espacio = w / 3;
    int total = cifras * w + (cifras - 1) * espacio;
    int x = (ancho - total) / 2;
    int y = (alto - h) / 2;
    if (cifras == 2) {
        digito(fb, ancho, alto, x, y, w, h, id / 10, blanco);
        x += w + espacio;
    }
    digito(fb, ancho, alto, x, y, w, h, id % 10, blanco);
}
