/*
 * puente_lwip.c — red del nodo con LwIP (API "raw", NO_SYS = 1, sin RTOS).
 *
 *   - Servidor TCP en el puerto 5000: recibe JPEG y contesta acuses.
 *   - Anuncio UDP cada segundo al puerto 5001 para que la PC lo encuentre.
 *   - IP por DHCP; si nadie la da en 8 s, usa 192.168.77.(100 + id).
 *
 * En main.c (CubeMX), dentro de USER CODE (ver puente_lwip.h):
 *     puente_nodo_iniciar();            // después de MX_LWIP_Init() y MX_LTDC_Init()
 *     while (1) {
 *         MX_LWIP_Process();
 *         puente_nodo_proceso();
 *     }
 */
#include "main.h"
#include "lwip/dhcp.h"
#include "lwip/ip_addr.h"
#include "lwip/netif.h"
#include "lwip/pbuf.h"
#include "lwip/tcp.h"
#include "lwip/udp.h"

#include "nodo_placa.h"
#include "pantalla.h"
#include "puente_lwip.h"
#include "puente_nodo.h"

#include <string.h>

static pn_nodo_t nodo;
static struct tcp_pcb *escucha;
static struct tcp_pcb *cliente;
static struct udp_pcb *anuncio;
static int id_nodo = NODO_ID_DEFECTO;
static uint32_t acuses_sin_salir;
static uint8_t hola_pendiente;
static uint8_t ip_respaldo;
static uint32_t t_arranque, t_anuncio, t_led, t_ultimo_cuadro;
static uint8_t mostrando_id = 1;

/* ------------------------------------------------------------------ id */

__attribute__((weak)) int nodo_leer_id(void)
{
#ifdef NODO_ID_CON_DIP
    /* pull-up: switch cerrado a GND = bit en 1 */
    int id = 0;
    if (HAL_GPIO_ReadPin(NODO_ID_PUERTO, NODO_ID_PIN0) == GPIO_PIN_RESET) id |= 1;
    if (HAL_GPIO_ReadPin(NODO_ID_PUERTO, NODO_ID_PIN1) == GPIO_PIN_RESET) id |= 2;
    if (HAL_GPIO_ReadPin(NODO_ID_PUERTO, NODO_ID_PIN2) == GPIO_PIN_RESET) id |= 4;
    if (HAL_GPIO_ReadPin(NODO_ID_PUERTO, NODO_ID_PIN3) == GPIO_PIN_RESET) id |= 8;
    return id ? id : NODO_ID_DEFECTO;
#else
    return NODO_ID_DEFECTO;
#endif
}

/* ------------------------------------------------------------------ TCP */

static int escribir(struct tcp_pcb *t, uint8_t tipo, const void *datos, uint16_t largo)
{
    uint8_t cab[PN_CABECERA];
    if (tcp_sndbuf(t) < (u16_t)(PN_CABECERA + largo)) return -1;
    pn_armar_cabecera(cab, tipo, largo);
    if (tcp_write(t, cab, PN_CABECERA, TCP_WRITE_FLAG_COPY | (largo ? TCP_WRITE_FLAG_MORE : 0)) != ERR_OK) return -1;
    if (largo && tcp_write(t, datos, largo, TCP_WRITE_FLAG_COPY) != ERR_OK) return -1;
    return 0;
}

/* Regresa ERR_ABRT si tuvo que abortar (hay que regresarlo desde el callback). */
static err_t soltar(struct tcp_pcb *t)
{
    if (t == NULL) return ERR_OK;
    tcp_arg(t, NULL);
    tcp_recv(t, NULL);
    tcp_err(t, NULL);
    if (tcp_close(t) != ERR_OK) {
        tcp_abort(t);
        return ERR_ABRT;
    }
    return ERR_OK;
}

static void al_error(void *arg, err_t err)
{
    (void)arg;
    (void)err;
    cliente = NULL; /* LwIP ya liberó el pcb */
    pn_reiniciar(&nodo);
}

static err_t al_recibir(void *arg, struct tcp_pcb *t, struct pbuf *p, err_t err)
{
    (void)arg;
    if (p == NULL || err != ERR_OK) {
        if (p) pbuf_free(p);
        if (t == cliente) cliente = NULL;
        pn_reiniciar(&nodo);
        return soltar(t);
    }
    for (struct pbuf *q = p; q != NULL; q = q->next) {
        pn_alimentar(&nodo, (const uint8_t *)q->payload, q->len);
    }
    tcp_recved(t, p->tot_len);
    pbuf_free(p);
    return ERR_OK;
}

static err_t al_aceptar(void *arg, struct tcp_pcb *nuevo, err_t err)
{
    (void)arg;
    if (err != ERR_OK || nuevo == NULL) return ERR_VAL;
    if (cliente != NULL) soltar(cliente); /* el nuevo reemplaza al anterior */
    cliente = nuevo;
    tcp_nagle_disable(nuevo);
    tcp_recv(nuevo, al_recibir);
    tcp_err(nuevo, al_error);
    pn_reiniciar(&nodo);
    acuses_sin_salir = 0;
    hola_pendiente = 1;
    return ERR_OK;
}

/* ------------------------------------------------------------------ público */

void puente_nodo_iniciar(void)
{
    id_nodo = nodo_leer_id();
    pn_iniciar(&nodo, (uint8_t *)NODO_JPEG0, (uint8_t *)NODO_JPEG1, NODO_JPEG_CAP);
    pantalla_iniciar();
    pantalla_identificar(id_nodo, 0);

    struct tcp_pcb *pcb = tcp_new_ip_type(IPADDR_TYPE_ANY);
    if (pcb != NULL && tcp_bind(pcb, IP_ANY_TYPE, PN_PUERTO_TCP) == ERR_OK) {
        escucha = tcp_listen(pcb);   /* si funciona, LwIP libera pcb y regresa otro */
        if (escucha != NULL) {
            tcp_accept(escucha, al_aceptar);
        } else {
            tcp_close(pcb);          /* si falla, pcb sigue siendo nuestro */
        }
    } else if (pcb != NULL) {
        tcp_close(pcb);
    }
    anuncio = udp_new();
    if (anuncio != NULL) ip_set_option(anuncio, SOF_BROADCAST);
    t_arranque = HAL_GetTick();
}

static void revisar_ip(void)
{
    struct netif *n = netif_default;
    if (n == NULL || ip_respaldo) return;
    if (dhcp_supplied_address(n)) return;
    if (HAL_GetTick() - t_arranque < NODO_DHCP_ESPERA_MS) return;
    ip4_addr_t ip, mascara, puerta;
    IP4_ADDR(&ip, NODO_IP_RESPALDO_A, NODO_IP_RESPALDO_B, NODO_IP_RESPALDO_C, NODO_IP_RESPALDO_BASE + id_nodo);
    IP4_ADDR(&mascara, 255, 255, 255, 0);
    IP4_ADDR(&puerta, 0, 0, 0, 0);
    dhcp_release_and_stop(n);
    netif_set_addr(n, &ip, &mascara, &puerta);
    ip_respaldo = 1;
}

static void anunciar(void)
{
    struct netif *n = netif_default;
    if (anuncio == NULL || n == NULL || !netif_is_up(n) || ip4_addr_isany_val(*netif_ip4_addr(n))) return;
    char txt[64];
    int largo = pn_texto_anuncio(txt, sizeof txt, id_nodo, NODO_ANCHO, NODO_ALTO, PN_PUERTO_TCP);
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, (u16_t)largo, PBUF_RAM);
    if (p == NULL) return;
    memcpy(p->payload, txt, (size_t)largo);
    udp_sendto(anuncio, p, IP_ADDR_BROADCAST, PN_PUERTO_ANUNCIO);
    pbuf_free(p);
}

void puente_nodo_proceso(void)
{
    uint32_t ahora = HAL_GetTick();

    /* 1. mostrar cuadros (el más viejo primero) */
    pn_cuadro_t *c;
    while ((c = pn_siguiente_cuadro(&nodo)) != NULL) {
        pantalla_mostrar_jpeg(c->datos, c->largo); /* si falla, igual se acusa */
        pn_cuadro_mostrado(&nodo, c);
        t_ultimo_cuadro = ahora;
        mostrando_id = 0;
    }

    /* 2. pantalla de identificación: a pedido, o si no llega video en 3 s */
    if (nodo.identificar) {
        nodo.identificar = 0;
        pantalla_identificar(id_nodo, cliente != NULL);
        t_ultimo_cuadro = ahora;
        mostrando_id = 1;
    } else if (!mostrando_id && ahora - t_ultimo_cuadro > 3000u) {
        pantalla_identificar(id_nodo, cliente != NULL);
        mostrando_id = 1;
    }

    /* 3. saludo y acuses */
    acuses_sin_salir += pn_tomar_acuses(&nodo);
    if (cliente != NULL) {
        if (hola_pendiente) {
            char hola[48];
            int largo = pn_texto_hola(hola, sizeof hola, id_nodo, NODO_ANCHO, NODO_ALTO);
            if (escribir(cliente, PN_TIPO_TEXTO, hola, (uint16_t)largo) == 0) hola_pendiente = 0;
        }
        while (acuses_sin_salir > 0 && escribir(cliente, PN_TIPO_ACUSE, NULL, 0) == 0) acuses_sin_salir--;
        tcp_output(cliente);
    } else {
        acuses_sin_salir = 0;
    }

    /* 4. IP de respaldo y anuncio */
    revisar_ip();
    if (ahora - t_anuncio >= 1000u) {
        t_anuncio = ahora;
        anunciar();
    }

    /* 5. LED: lento sin conexión, rápido con video */
    uint32_t periodo = cliente == NULL ? 500u : (mostrando_id ? 250u : 80u);
    if (ahora - t_led >= periodo) {
        t_led = ahora;
        HAL_GPIO_TogglePin(NODO_LED_PUERTO, NODO_LED_PIN);
    }
}

/* ------------------------------------------------------------------ consola */

const pn_nodo_t *puente_nodo_estado(void)
{
    return &nodo;
}

int puente_nodo_id(void)
{
    return id_nodo;
}

int puente_nodo_hay_cliente(void)
{
    return cliente != NULL;
}
