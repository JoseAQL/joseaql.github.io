/*
 * pantalla_stm32.c — JPEG por hardware → DMA2D (YCbCr a RGB565) → LTDC.
 *
 * Usa los periféricos que genera CubeMX: hjpeg, hdma2d y hltdc.
 * Doble búfer: se dibuja en el que NO se ve y se cambia en el retrazo
 * vertical, así no hay "tearing".
 *
 * Basado en el flujo de los ejemplos de ST para STM32H7
 * (JPEG_DecodingFromFLASH_Polling + DMA2D_CopyBuffer).
 * PENDIENTE DE PROBAR EN HARDWARE.
 */
#include "main.h"
#include "nodo_placa.h"
#include "pantalla.h"
#include "puente_nodo.h"

#include <string.h>

extern JPEG_HandleTypeDef hjpeg;
extern DMA2D_HandleTypeDef hdma2d;
extern LTDC_HandleTypeDef hltdc;

static uint8_t visible = 0;              /* 0 = FB0 en pantalla, 1 = FB1 */
static const uint8_t *entrada;
static uint32_t entrada_total;
static uint32_t entrada_usada;
static uint32_t salida_usada;
static volatile uint8_t jpeg_listo;
static volatile uint8_t jpeg_error;
static pantalla_estadisticas_t estadisticas;

static inline uint16_t *fb(uint8_t i)
{
    return (uint16_t *)(i ? NODO_FB1 : NODO_FB0);
}

static void limpiar_cache(const void *dir, uint32_t largo)
{
#if defined(__DCACHE_PRESENT) && (__DCACHE_PRESENT == 1U)
    uint32_t inicio = (uint32_t)dir & ~31u;
    uint32_t fin = ((uint32_t)dir + largo + 31u) & ~31u;
    SCB_CleanDCache_by_Addr((uint32_t *)inicio, (int32_t)(fin - inicio));
#else
    (void)dir;
    (void)largo;
#endif
}

/* Muestra el búfer trasero en el próximo retrazo vertical. */
static void intercambiar(void)
{
    uint8_t atras = (uint8_t)(1u - visible);
    HAL_LTDC_SetAddress_NoReload(&hltdc, (uint32_t)fb(atras), 0);
    hltdc.Instance->SRCR = LTDC_SRCR_VBR;
    uint32_t t0 = HAL_GetTick();
    while ((hltdc.Instance->SRCR & LTDC_SRCR_VBR) && (HAL_GetTick() - t0) < 40u) {
        /* espera al retrazo (máximo ~17 ms a 60 Hz) */
    }
    visible = atras;
}

void pantalla_iniciar(void)
{
    memset(fb(0), 0, NODO_TAM_FB);
    memset(fb(1), 0, NODO_TAM_FB);
    limpiar_cache(fb(0), NODO_TAM_FB);
    limpiar_cache(fb(1), NODO_TAM_FB);
    HAL_LTDC_SetAddress(&hltdc, (uint32_t)fb(0), 0);
    visible = 0;
}

void pantalla_identificar(int id, int conectado)
{
    uint8_t atras = (uint8_t)(1u - visible);
    pn_dibujar_identificacion(fb(atras), NODO_ANCHO, NODO_ALTO, id, (uint8_t)conectado);
    limpiar_cache(fb(atras), NODO_TAM_FB);
    intercambiar();
}

/* ------------------------------------------------ callbacks del HAL JPEG */

void HAL_JPEG_GetDataCallback(JPEG_HandleTypeDef *h, uint32_t consumidos)
{
    /* Le dimos todo el archivo de una vez; si pidió más es que ya terminó
     * o que consumió solo una parte: le damos lo que falte. */
    entrada_usada += consumidos;
    uint32_t resto = entrada_usada < entrada_total ? entrada_total - entrada_usada : 0u;
    HAL_JPEG_ConfigInputBuffer(h, (uint8_t *)(entrada + entrada_usada), resto);
}

void HAL_JPEG_DataReadyCallback(JPEG_HandleTypeDef *h, uint8_t *salida, uint32_t largo)
{
    (void)salida;
    salida_usada += largo;
    uint32_t resto = NODO_TAM_YCBCR > salida_usada ? NODO_TAM_YCBCR - salida_usada : 0u;
    HAL_JPEG_ConfigOutputBuffer(h, (uint8_t *)(NODO_YCBCR + salida_usada), resto);
}

void HAL_JPEG_DecodeCpltCallback(JPEG_HandleTypeDef *h)
{
    (void)h;
    jpeg_listo = 1;
}

void HAL_JPEG_ErrorCallback(JPEG_HandleTypeDef *h)
{
    (void)h;
    jpeg_error = 1;
}

/* ------------------------------------------------ YCbCr (MCU) → RGB565 */

static int convertir(const JPEG_ConfTypeDef *info, uint16_t *destino)
{
    uint32_t ancho = info->ImageWidth;
    uint32_t alto = info->ImageHeight;
    uint32_t css;
    uint32_t relleno;

    if (info->ColorSpace != JPEG_YCBCR_COLORSPACE) return -1;
    if (ancho > NODO_ANCHO || alto > NODO_ALTO) return -1; /* la PC manda al tamaño del nodo */

    if (info->ChromaSubsampling == JPEG_420_SUBSAMPLING) {
        css = DMA2D_CSS_420;
        relleno = ancho % 16u ? 16u - ancho % 16u : 0u;
    } else if (info->ChromaSubsampling == JPEG_422_SUBSAMPLING) {
        css = DMA2D_CSS_422;
        relleno = ancho % 16u ? 16u - ancho % 16u : 0u;
    } else {
        css = DMA2D_NO_CSS;
        relleno = ancho % 8u ? 8u - ancho % 8u : 0u;
    }

    /* centrado si el cuadro es más chico que la pantalla */
    uint32_t x0 = (NODO_ANCHO - ancho) / 2u;
    uint32_t y0 = (NODO_ALTO - alto) / 2u;
    uint16_t *inicio = destino + y0 * NODO_ANCHO + x0;

    hdma2d.Init.Mode = DMA2D_M2M_PFC;
    hdma2d.Init.ColorMode = DMA2D_OUTPUT_RGB565;
    hdma2d.Init.OutputOffset = NODO_ANCHO - ancho;
    hdma2d.Init.AlphaInverted = DMA2D_REGULAR_ALPHA;
    hdma2d.Init.RedBlueSwap = DMA2D_RB_REGULAR;
    hdma2d.LayerCfg[1].AlphaMode = DMA2D_REPLACE_ALPHA;
    hdma2d.LayerCfg[1].InputAlpha = 0xFF;
    hdma2d.LayerCfg[1].InputColorMode = DMA2D_INPUT_YCBCR;
    hdma2d.LayerCfg[1].ChromaSubSampling = css;
    hdma2d.LayerCfg[1].InputOffset = relleno;
    hdma2d.LayerCfg[1].RedBlueSwap = DMA2D_RB_REGULAR;
    hdma2d.LayerCfg[1].AlphaInverted = DMA2D_REGULAR_ALPHA;

    if (HAL_DMA2D_Init(&hdma2d) != HAL_OK) return -1;
    if (HAL_DMA2D_ConfigLayer(&hdma2d, 1) != HAL_OK) return -1;
    if (HAL_DMA2D_Start(&hdma2d, NODO_YCBCR, (uint32_t)inicio, ancho, alto) != HAL_OK) return -1;
    if (HAL_DMA2D_PollForTransfer(&hdma2d, 50) != HAL_OK) return -1;
    return 0;
}

static int mostrar(const uint8_t *datos, uint32_t largo)
{
    uint8_t atras = (uint8_t)(1u - visible);
    JPEG_ConfTypeDef info;

    entrada = datos;
    entrada_total = largo;
    entrada_usada = 0;
    salida_usada = 0;
    jpeg_listo = 0;
    jpeg_error = 0;

    if (HAL_JPEG_Decode(&hjpeg, (uint8_t *)datos, largo, (uint8_t *)NODO_YCBCR, NODO_TAM_YCBCR, 100) != HAL_OK) {
        HAL_JPEG_Abort(&hjpeg);
        return -1;
    }
    if (jpeg_error) return -1;
    if (HAL_JPEG_GetInfo(&hjpeg, &info) != HAL_OK) return -1;

    /* el decodificador escribió con la CPU: pasar a la SDRAM antes del DMA2D */
    limpiar_cache((const void *)NODO_YCBCR, salida_usada ? salida_usada : NODO_TAM_YCBCR);

    /* si el cuadro no llena la pantalla, borrar lo que quede de antes */
    if (info.ImageWidth != NODO_ANCHO || info.ImageHeight != NODO_ALTO) {
        memset(fb(atras), 0, NODO_TAM_FB);
        limpiar_cache(fb(atras), NODO_TAM_FB);
    }
    if (convertir(&info, fb(atras)) != 0) return -1;
    intercambiar();
    estadisticas.ultimo_ancho = info.ImageWidth;
    estadisticas.ultimo_alto = info.ImageHeight;
    return 0;
}

int pantalla_mostrar_jpeg(const uint8_t *datos, uint32_t largo)
{
    uint32_t t0 = HAL_GetTick();
    int r = mostrar(datos, largo);
    if (r == 0) {
        estadisticas.mostrados++;
        estadisticas.ultimo_ms = HAL_GetTick() - t0;
    } else {
        estadisticas.errores++;
    }
    return r;
}

const pantalla_estadisticas_t *pantalla_estadisticas(void)
{
    return &estadisticas;
}
