/*
 * main.c — nodo Puente Video (Ethernet → HDMI) sin RTOS.
 *
 * Orden de arranque:
 *   1. MPU (antes de las cachés: SDRAM, memoria de Ethernet en D2).
 *   2. I-caché, HAL, relojes.
 *   3. Placa: GPIO, consola, SDRAM + prueba, LTDC, DMA2D, JPEG (en la Nucleo
 *      solo LEDs, consola y JPEG).
 *   4. D-caché (después de probar la SDRAM sin caché).
 *   5. Red (LwIP + Ethernet + DHCP) y el núcleo del nodo (Core/Src).
 *   6. Bucle: red, nodo y tareas de la placa; estadísticas cada 5 s.
 */
#include "main.h"
#include "red.h"
#include "ethernetif.h"
#include "pantalla.h"
#include "puente_lwip.h"
#include "nodo_placa.h"

#include <stdio.h>
#include <stdlib.h>

#define ESTADISTICAS_CADA_MS 5000u

static void imprimir_estadisticas(uint32_t ahora)
{
    const pn_nodo_t *n = puente_nodo_estado();
    const pantalla_estadisticas_t *p = pantalla_estadisticas();
    printf("[%5lu s] enlace=%s ip=%s cliente=%s | llegaron=%lu descartados=%lu | "
           "mostrados=%lu errores=%lu ultimo=%lux%lu en %lu ms | tx_err=%lu\r\n",
           (unsigned long)(ahora / 1000u),
           red_enlace_arriba() ? "si" : "no", red_ip_texto(),
           puente_nodo_hay_cliente() ? "si" : "no",
           (unsigned long)n->recibidos, (unsigned long)n->descartados,
           (unsigned long)p->mostrados, (unsigned long)p->errores,
           (unsigned long)p->ultimo_ancho, (unsigned long)p->ultimo_alto,
           (unsigned long)p->ultimo_ms, (unsigned long)ethernetif_errores_tx());
    placa_imprimir_estado();
}

int main(void)
{
    placa_mpu();
    SCB_EnableICache();

    HAL_Init();
    placa_reloj();
    placa_iniciar();

    SCB_EnableDCache();

    printf("\r\n=== Puente Video: nodo %s, %dx%d, CPU %lu MHz ===\r\n", placa_nombre(),
           NODO_ANCHO, NODO_ALTO, (unsigned long)(HAL_RCC_GetSysClockFreq() / 1000000u));

    /* Semilla distinta por chip: LwIP usa rand() para el id de DHCP y los
     * puertos locales; si todos los nodos arrancan igual, chocan. */
    srand(HAL_GetUIDw0() ^ HAL_GetUIDw1() ^ HAL_GetUIDw2());

    MX_LWIP_Init();
    puente_nodo_iniciar();
    printf("Nodo %d listo: TCP %u, anuncio UDP %u\r\n", puente_nodo_id(),
           (unsigned)PN_PUERTO_TCP, (unsigned)PN_PUERTO_ANUNCIO);

    uint32_t t_estadisticas = HAL_GetTick();
    while (1) {
        MX_LWIP_Process();
        puente_nodo_proceso();

        uint32_t ahora = HAL_GetTick();
        placa_proceso(ahora);
        if (ahora - t_estadisticas >= ESTADISTICAS_CADA_MS) {
            t_estadisticas = ahora;
            imprimir_estadisticas(ahora);
        }
    }
}
