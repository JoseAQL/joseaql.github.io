/*
 * placa_comun.c — piezas iguales en las dos placas: regiones del MPU, códec
 * JPEG y el parpadeo de error fatal.
 */
#include "main.h"

JPEG_HandleTypeDef hjpeg;

void placa_mpu_region(uint32_t numero, uint32_t base, uint32_t tamano, uint32_t tex,
                      uint32_t cache, uint32_t buffer, uint32_t compartida,
                      uint32_t acceso, uint32_t subregiones_apagadas)
{
    MPU_Region_InitTypeDef r = {0};
    r.Enable = MPU_REGION_ENABLE;
    r.Number = (uint8_t)numero;
    r.BaseAddress = base;
    r.Size = (uint8_t)tamano;
    r.TypeExtField = (uint8_t)tex;
    r.IsCacheable = (uint8_t)cache;
    r.IsBufferable = (uint8_t)buffer;
    r.IsShareable = (uint8_t)compartida;
    r.AccessPermission = (uint8_t)acceso;
    r.SubRegionDisable = (uint8_t)subregiones_apagadas;
    r.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;   /* nada se ejecuta desde RAM */
    HAL_MPU_ConfigRegion(&r);
}

/* ------------------------------------------------------------ JPEG */

void HAL_JPEG_MspInit(JPEG_HandleTypeDef *h)
{
    (void)h;
    __HAL_RCC_JPGDECEN_CLK_ENABLE();
}

int placa_jpeg_iniciar(void)
{
    hjpeg.Instance = JPEG;
    return HAL_JPEG_Init(&hjpeg) == HAL_OK ? 0 : -1;
}

/* ------------------------------------------------------------ error fatal
 * No usa HAL_Delay: en una falla (HardFault) el SysTick puede no correr.
 */
static void espera_ms(uint32_t ms)
{
    /* ~4 ciclos por vuelta con la I-caché; no necesita ser exacto. */
    uint32_t vueltas = (SystemCoreClock / 4000u) * ms;
    for (volatile uint32_t i = 0; i < vueltas; i++) {
        __NOP();
    }
}

void placa_error(uint32_t codigo)
{
    __disable_irq();
    for (;;) {
        for (uint32_t i = 0; i < codigo; i++) {
            placa_led_error(1);
            espera_ms(150);
            placa_led_error(0);
            espera_ms(250);
        }
        espera_ms(1200);
    }
}
