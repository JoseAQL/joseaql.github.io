/*
 * red.c — arranque y bucle de LwIP sin RTOS (lo que CubeMX pone en lwip.c).
 *
 *   MX_LWIP_Init():    lwip_init, interfaz Ethernet, DHCP con nombre "nodo-<id>".
 *   MX_LWIP_Process(): paquetes recibidos, timers de LwIP y enlace cada 100 ms.
 *
 * La IP de respaldo (192.168.77.(100 + id) si no hay DHCP en 8 s) la pone
 * Core/Src/puente_lwip.c, no este archivo.
 */
#include "main.h"
#include "red.h"
#include "ethernetif.h"
#include "puente_lwip.h"

#include "lwip/dhcp.h"
#include "lwip/init.h"
#include "lwip/ip4_addr.h"
#include "lwip/netif.h"
#include "lwip/timeouts.h"
#include "netif/ethernet.h"

#include <stdio.h>

static struct netif gnetif;
static char nombre[16];
static char ip_txt[16];
static uint32_t t_enlace;

static void al_cambiar_estado(struct netif *n)
{
    if (netif_is_up(n) && !ip4_addr_isany_val(*netif_ip4_addr(n))) {
        printf("RED: IP %s (%s)\r\n", ip4addr_ntoa(netif_ip4_addr(n)),
               dhcp_supplied_address(n) ? "DHCP" : "fija");
    }
}

static void al_cambiar_enlace(struct netif *n)
{
    printf("RED: enlace %s\r\n", netif_is_link_up(n) ? "arriba" : "abajo");
}

void MX_LWIP_Init(void)
{
    lwip_init();

    netif_add_noaddr(&gnetif, NULL, ethernetif_init, ethernet_input);
    netif_set_default(&gnetif);

    snprintf(nombre, sizeof nombre, "nodo-%d", nodo_leer_id());
    netif_set_hostname(&gnetif, nombre);
    netif_set_status_callback(&gnetif, al_cambiar_estado);
    netif_set_link_callback(&gnetif, al_cambiar_enlace);

    /* Si el cable ya estaba puesto, ethernetif_init ya subió la interfaz. Si no,
     * DHCP espera solo y arranca cuando suba el enlace. */
    dhcp_start(&gnetif);
    t_enlace = HAL_GetTick();
}

void MX_LWIP_Process(void)
{
    ethernetif_input(&gnetif);
    sys_check_timeouts();

    uint32_t ahora = HAL_GetTick();
    if (ahora - t_enlace >= 100u) {
        t_enlace = ahora;
        ethernet_link_check_state(&gnetif);
    }
}

int red_enlace_arriba(void)
{
    return netif_is_link_up(&gnetif) ? 1 : 0;
}

const char *red_ip_texto(void)
{
    ip4addr_ntoa_r(netif_ip4_addr(&gnetif), ip_txt, sizeof ip_txt);
    return ip_txt;
}
