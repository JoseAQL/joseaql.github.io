/*
 * ethernetif.c — controlador de red de LwIP para el MAC Ethernet del STM32H7.
 *
 * Basado en Src/ethernetif.c del ejemplo LwIP_TCP_Echo_Server de ST
 * (STM32CubeH7, NUCLEO-H723ZG), adaptado a la API actual del HAL ETH
 * (HAL_ETH_ReadData + callbacks de RX, HAL_ETH_Transmit + HAL_ETH_ReleaseTxPacket)
 * y al mapa de memoria de este proyecto. Copyright (c) 2017 STMicroelectronics
 * para lo que viene de ese ejemplo (licencia en el repositorio STM32CubeH7).
 *
 * Recepción "cero copia":
 *   - Los búferes de recepción son pbufs propios (RxBuff_t) de un pool de
 *     LwIP que vive en SRAM3 de D2 (sección .Rx_PoolSection, 0x30040200).
 *   - El HAL pide búferes con HAL_ETH_RxAllocateCallback y avisa cada trozo
 *     recibido con HAL_ETH_RxLinkCallback; aquí se encadenan como pbufs.
 *   - Cuando LwIP libera el pbuf (pbuf_free_custom) el búfer vuelve al pool.
 *
 * Transmisión:
 *   - LwIP arma los paquetes en su montículo (SRAM2 de D2, sin caché).
 *   - Se manda con HAL_ETH_Transmit (bloqueante, máx. 20 ms) y luego se
 *     liberan los descriptores ya enviados con HAL_ETH_ReleaseTxPacket.
 *   - Si un paquete viniera de la DTCM (el DMA no la ve) o en más trozos que
 *     descriptores, se copia antes a un pbuf del montículo.
 *
 * Descriptores DMA: secciones .RxDecripSection / .TxDecripSection al inicio
 * de SRAM3 (0x30040000), memoria tipo dispositivo según el MPU.
 */
#include "main.h"
#include "ethernetif.h"
#include "lan8742.h"

#include "lwip/etharp.h"
#include "lwip/memp.h"
#include "lwip/netif.h"
#include "lwip/opt.h"
#include "lwip/pbuf.h"
#include "lwip/timeouts.h"
#include "netif/ethernet.h"

#include <stdio.h>
#include <string.h>

#define IFNAME0 'p'
#define IFNAME1 'v'

#define ETH_TX_TIEMPO_MS      20u
#define ETH_RX_BUFFER_SIZE    1536u   /* una trama completa por búfer (múltiplo de 32) */
#define ETH_RX_BUFFER_CNT     16u     /* entre ETH_RX_DESC_CNT y 2 x ETH_RX_DESC_CNT */

/* ------------------------------------------------------------------ memoria */

/* Montículo de LwIP (ver lwipopts.h): SRAM2 de D2, sin caché. */
unsigned char nodo_lwip_heap[NODO_LWIP_HEAP_TAM] __attribute__((section(".lwip_heap"), aligned(32)));

/* Descriptores DMA (memoria tipo dispositivo, región 4 del MPU). */
ETH_DMADescTypeDef DMARxDscrTab[ETH_RX_DESC_CNT] __attribute__((section(".RxDecripSection")));
ETH_DMADescTypeDef DMATxDscrTab[ETH_TX_DESC_CNT] __attribute__((section(".TxDecripSection")));

typedef struct {
    struct pbuf_custom pbuf_custom;
    uint8_t buff[(ETH_RX_BUFFER_SIZE + 31u) & ~31u] __attribute__((aligned(32)));
} RxBuff_t;

/* La sección se declara antes de que LWIP_MEMPOOL_DECLARE defina el arreglo,
 * así GCC la aplica a la definición. */
extern u8_t memp_memory_RX_POOL_base[] __attribute__((section(".Rx_PoolSection")));
LWIP_MEMPOOL_DECLARE(RX_POOL, ETH_RX_BUFFER_CNT, sizeof(RxBuff_t), "Pool RX de Ethernet")

/* ------------------------------------------------------------------ estado */

ETH_HandleTypeDef heth;
static ETH_TxPacketConfigTypeDef tx_config;
static uint8_t mac[6];
static volatile uint8_t rx_sin_bufer;   /* el pool se acabó: no leer hasta que se libere uno */
static uint32_t errores_tx;

static lan8742_Object_t phy;

static int32_t phy_io_iniciar(void);
static int32_t phy_io_terminar(void);
static int32_t phy_io_leer(uint32_t dir, uint32_t reg, uint32_t *valor);
static int32_t phy_io_escribir(uint32_t dir, uint32_t reg, uint32_t valor);
static int32_t phy_io_tick(void);

static lan8742_IOCtx_t phy_io = {
    phy_io_iniciar, phy_io_terminar, phy_io_escribir, phy_io_leer, phy_io_tick
};

static void pbuf_free_custom(struct pbuf *p);

/* ------------------------------------------------------------------ MAC
 * Dirección MAC "administrada localmente" (bit 1 del primer byte) sacada del
 * número de serie único del chip: cada nodo tiene la suya sin configurar nada.
 * Si todos los nodos tuvieran la misma MAC, el switch los confundiría.
 */
static void mac_desde_uid(uint8_t m[6])
{
    uint32_t a = HAL_GetUIDw0(), b = HAL_GetUIDw1(), c = HAL_GetUIDw2();
    uint32_t h = 2166136261u;                  /* FNV-1a sobre los 12 bytes */
    uint32_t palabras[3] = {a, b, c};
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            h ^= (palabras[i] >> (8 * j)) & 0xFFu;
            h *= 16777619u;
        }
    }
    m[0] = 0x02;                               /* local, unicast */
    m[1] = 0x50;                               /* "P" de Puente */
    m[2] = (uint8_t)(h >> 24);
    m[3] = (uint8_t)(h >> 16);
    m[4] = (uint8_t)(h >> 8);
    m[5] = (uint8_t)h;
}

/* ------------------------------------------------------------------ init */

static void low_level_init(struct netif *netif)
{
    mac_desde_uid(mac);

    placa_phy_reiniciar();

    heth.Instance = ETH;
    heth.Init.MACAddr = mac;
    heth.Init.MediaInterface = HAL_ETH_RMII_MODE;
    heth.Init.TxDesc = DMATxDscrTab;
    heth.Init.RxDesc = DMARxDscrTab;
    heth.Init.RxBuffLen = ETH_RX_BUFFER_SIZE;

    /* GPIO y relojes en HAL_ETH_MspInit (archivo de la placa). Si no llega
     * el reloj de 50 MHz del PHY, el reinicio del DMA no termina y falla. */
    if (HAL_ETH_Init(&heth) != HAL_OK) {
        printf("ETH: HAL_ETH_Init fallo (error 0x%08lx). Revisa REF_CLK de 50 MHz en PA1.\r\n",
               (unsigned long)heth.ErrorCode);
        placa_error(PLACA_ERR_ETH);
    }

    memset(&tx_config, 0, sizeof tx_config);
    tx_config.Attributes = ETH_TX_PACKETS_FEATURES_CSUM | ETH_TX_PACKETS_FEATURES_CRCPAD;
    tx_config.ChecksumCtrl = ETH_CHECKSUM_IPHDR_PAYLOAD_INSERT_PHDR_CALC;
    tx_config.CRCPadCtrl = ETH_CRC_PAD_INSERT;

    netif->hwaddr_len = ETH_HWADDR_LEN;
    memcpy(netif->hwaddr, mac, 6);
    netif->mtu = ETH_MAX_PAYLOAD;
    netif->flags |= NETIF_FLAG_BROADCAST | NETIF_FLAG_ETHARP;

    LWIP_MEMPOOL_INIT(RX_POOL);

    LAN8742_RegisterBusIO(&phy, &phy_io);
    if (LAN8742_Init(&phy) != LAN8742_STATUS_OK) {
        printf("ETH: no respondio el PHY LAN8742 por MDIO\r\n");
        netif_set_link_down(netif);
        netif_set_down(netif);
        return;
    }
    printf("ETH: PHY en la direccion %lu, MAC %02x:%02x:%02x:%02x:%02x:%02x\r\n",
           (unsigned long)phy.DevAddr, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

    ethernet_link_check_state(netif);
}

/* ------------------------------------------------------------------ TX */

static int dma_no_lo_ve(const void *p)
{
    uint32_t a = (uint32_t)p;
    return (a >= 0x20000000u && a < 0x20020000u)    /* DTCM */
        || (a < 0x00010000u);                         /* ITCM */
}

static int necesita_copia(struct pbuf *p)
{
    uint32_t n = 0;
    for (struct pbuf *q = p; q != NULL; q = q->next) {
        if (++n > ETH_TX_DESC_CNT || dma_no_lo_ve(q->payload)) return 1;
    }
    return 0;
}

static void limpiar_cache(const void *dir, uint32_t largo)
{
    /* El montículo de LwIP no tiene caché; esto solo cubre pbufs que apunten
     * a memoria con caché (AXI SRAM, SDRAM). */
    uint32_t a = (uint32_t)dir;
    if (a >= 0x30000000u && a < 0x30048000u) return;
    uint32_t inicio = a & ~31u;
    uint32_t fin = (a + largo + 31u) & ~31u;
    SCB_CleanDCache_by_Addr((uint32_t *)inicio, (int32_t)(fin - inicio));
}

static err_t low_level_output(struct netif *netif, struct pbuf *p)
{
    (void)netif;
    ETH_BufferTypeDef trozos[ETH_TX_DESC_CNT];
    struct pbuf *copia = NULL;
    uint32_t i = 0;

    if (heth.gState != HAL_ETH_STATE_STARTED) return ERR_IF;   /* sin enlace */

    /* Liberar lo que ya se mandó: si no, los descriptores se quedan ocupados. */
    HAL_ETH_ReleaseTxPacket(&heth);

    if (necesita_copia(p)) {
        copia = pbuf_clone(PBUF_RAW, PBUF_RAM, p);
        if (copia == NULL) {
            errores_tx++;
            return ERR_MEM;
        }
        p = copia;
    }

    memset(trozos, 0, sizeof trozos);
    for (struct pbuf *q = p; q != NULL; q = q->next, i++) {
        trozos[i].buffer = (uint8_t *)q->payload;
        trozos[i].len = q->len;
        trozos[i].next = q->next != NULL ? &trozos[i + 1u] : NULL;
        limpiar_cache(q->payload, q->len);
    }

    tx_config.Length = p->tot_len;
    tx_config.TxBuffer = trozos;
    tx_config.pData = p;

    /* El HAL guarda p y lo regresa en HAL_ETH_TxFreeCallback, donde se libera:
     * por eso se le suma una referencia (la copia ya trae la suya). */
    if (copia == NULL) pbuf_ref(p);

    heth.ErrorCode = HAL_ETH_ERROR_NONE;
    if (HAL_ETH_Transmit(&heth, &tx_config, ETH_TX_TIEMPO_MS) != HAL_OK) {
        errores_tx++;
        if (heth.ErrorCode & HAL_ETH_ERROR_BUSY) {
            /* No se tomó ningún descriptor: el HAL no va a liberar p. */
            pbuf_free(p);
            HAL_ETH_ReleaseTxPacket(&heth);
            return ERR_IF;
        }
        /* Tiempo agotado o error de DMA: el descriptor quedó registrado y
         * HAL_ETH_ReleaseTxPacket liberará p. */
    }
    HAL_ETH_ReleaseTxPacket(&heth);
    return ERR_OK;
}

void HAL_ETH_TxFreeCallback(uint32_t *buff)
{
    pbuf_free((struct pbuf *)buff);
}

uint32_t ethernetif_errores_tx(void)
{
    return errores_tx;
}

/* ------------------------------------------------------------------ RX */

void HAL_ETH_RxAllocateCallback(uint8_t **buff)
{
    struct pbuf_custom *p = LWIP_MEMPOOL_ALLOC(RX_POOL);
    if (p != NULL) {
        *buff = (uint8_t *)p + offsetof(RxBuff_t, buff);
        p->custom_free_function = pbuf_free_custom;
        /* Se arma el pbuf cada vez: LwIP o la app pudieron cambiarlo. */
        pbuf_alloced_custom(PBUF_RAW, 0, PBUF_REF, p, *buff, ETH_RX_BUFFER_SIZE);
    } else {
        rx_sin_bufer = 1;
        *buff = NULL;
    }
}

void HAL_ETH_RxLinkCallback(void **pStart, void **pEnd, uint8_t *buff, uint16_t Length)
{
    struct pbuf **inicio = (struct pbuf **)pStart;
    struct pbuf **fin = (struct pbuf **)pEnd;
    struct pbuf *p = (struct pbuf *)(void *)(buff - offsetof(RxBuff_t, buff));

    p->next = NULL;
    p->tot_len = 0;
    p->len = Length;

    if (*inicio == NULL) {
        *inicio = p;
    } else {
        (*fin)->next = p;
    }
    *fin = p;

    /* tot_len de cada pbuf = su largo más el de todos los que siguen */
    for (struct pbuf *q = *inicio; q != NULL; q = q->next) {
        q->tot_len = (u16_t)(q->tot_len + Length);
    }

    /* SRAM3 no tiene caché según el MPU; se invalida igual por si alguien
     * cambia la configuración (es inofensivo). */
    SCB_InvalidateDCache_by_Addr((uint32_t *)buff, Length);
}

static void pbuf_free_custom(struct pbuf *p)
{
    LWIP_MEMPOOL_FREE(RX_POOL, (struct pbuf_custom *)p);
    rx_sin_bufer = 0;
}

static struct pbuf *low_level_input(struct netif *netif)
{
    (void)netif;
    struct pbuf *p = NULL;
    if (!rx_sin_bufer) HAL_ETH_ReadData(&heth, (void **)&p);
    return p;
}

void ethernetif_input(struct netif *netif)
{
    struct pbuf *p;
    while ((p = low_level_input(netif)) != NULL) {
        if (netif->input(p, netif) != ERR_OK) pbuf_free(p);
    }
}

err_t ethernetif_init(struct netif *netif)
{
    LWIP_ASSERT("netif != NULL", netif != NULL);
    netif->name[0] = IFNAME0;
    netif->name[1] = IFNAME1;
    netif->output = etharp_output;
    netif->linkoutput = low_level_output;
    low_level_init(netif);
    return ERR_OK;
}

/* ------------------------------------------------------------------ enlace */

void ethernet_link_check_state(struct netif *netif)
{
    int32_t estado = LAN8742_GetLinkState(&phy);

    if (netif_is_link_up(netif) && estado <= LAN8742_STATUS_LINK_DOWN) {
        HAL_ETH_Stop(&heth);
        netif_set_down(netif);
        netif_set_link_down(netif);
        return;
    }
    if (netif_is_link_up(netif) || estado <= LAN8742_STATUS_LINK_DOWN) return;

    uint32_t duplex, velocidad;
    switch (estado) {
    case LAN8742_STATUS_100MBITS_FULLDUPLEX: duplex = ETH_FULLDUPLEX_MODE; velocidad = ETH_SPEED_100M; break;
    case LAN8742_STATUS_100MBITS_HALFDUPLEX: duplex = ETH_HALFDUPLEX_MODE; velocidad = ETH_SPEED_100M; break;
    case LAN8742_STATUS_10MBITS_FULLDUPLEX:  duplex = ETH_FULLDUPLEX_MODE; velocidad = ETH_SPEED_10M;  break;
    case LAN8742_STATUS_10MBITS_HALFDUPLEX:  duplex = ETH_HALFDUPLEX_MODE; velocidad = ETH_SPEED_10M;  break;
    default: return;   /* autonegociación sin terminar: se revisa en la próxima vuelta */
    }

    ETH_MACConfigTypeDef conf;
    HAL_ETH_GetMACConfig(&heth, &conf);
    conf.DuplexMode = duplex;
    conf.Speed = velocidad;
    HAL_ETH_SetMACConfig(&heth, &conf);
    HAL_ETH_Start(&heth);
    netif_set_up(netif);
    netif_set_link_up(netif);
    printf("ETH: enlace arriba, %s Mbit/s, %s duplex\r\n",
           velocidad == ETH_SPEED_100M ? "100" : "10",
           duplex == ETH_FULLDUPLEX_MODE ? "full" : "half");
}

/* ------------------------------------------------------------------ MDIO */

static int32_t phy_io_iniciar(void)
{
    HAL_ETH_SetMDIOClockRange(&heth);
    return 0;
}

static int32_t phy_io_terminar(void)
{
    return 0;
}

static int32_t phy_io_leer(uint32_t dir, uint32_t reg, uint32_t *valor)
{
    return HAL_ETH_ReadPHYRegister(&heth, dir, reg, valor) == HAL_OK ? 0 : -1;
}

static int32_t phy_io_escribir(uint32_t dir, uint32_t reg, uint32_t valor)
{
    return HAL_ETH_WritePHYRegister(&heth, dir, reg, valor) == HAL_OK ? 0 : -1;
}

static int32_t phy_io_tick(void)
{
    return (int32_t)HAL_GetTick();
}

/* ------------------------------------------------------------------ reloj de LwIP */

u32_t sys_now(void)
{
    return HAL_GetTick();
}
