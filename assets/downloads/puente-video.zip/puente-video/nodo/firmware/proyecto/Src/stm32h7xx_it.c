/*
 * stm32h7xx_it.c — interrupciones. El nodo trabaja por sondeo (Ethernet,
 * JPEG y DMA2D sin interrupciones), así que solo hace falta el SysTick y
 * atrapar las fallas.
 */
#include "main.h"

void SysTick_Handler(void)
{
    HAL_IncTick();
}

void NMI_Handler(void)
{
    placa_error(PLACA_ERR_FALLO);
}

void HardFault_Handler(void)
{
    placa_error(PLACA_ERR_FALLO);
}

void MemManage_Handler(void)
{
    placa_error(PLACA_ERR_FALLO);
}

void BusFault_Handler(void)
{
    placa_error(PLACA_ERR_FALLO);
}

void UsageFault_Handler(void)
{
    placa_error(PLACA_ERR_FALLO);
}

void SVC_Handler(void)
{
}

void DebugMon_Handler(void)
{
}

void PendSV_Handler(void)
{
}

void Error_Handler(void)
{
    placa_error(PLACA_ERR_OTRO);
}
