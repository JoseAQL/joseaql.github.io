/*
 * consola.c — printf por el puerto serie (115200 8N1) y las llamadas al
 * sistema mínimas que necesita newlib-nano.
 *
 * La placa elige el USART (USART1 en PB14/PB15 en el nodo; USART3 en PD8/PD9
 * en la Nucleo, que sale por el puerto COM virtual del ST-Link) y configura
 * sus pines en HAL_UART_MspInit.
 */
#include "main.h"

#include <errno.h>
#include <stdint.h>
#include <sys/stat.h>

static UART_HandleTypeDef huart;
static uint8_t lista;

void consola_iniciar(void *instancia_usart)
{
    huart.Instance = (USART_TypeDef *)instancia_usart;
    huart.Init.BaudRate = 115200;
    huart.Init.WordLength = UART_WORDLENGTH_8B;
    huart.Init.StopBits = UART_STOPBITS_1;
    huart.Init.Parity = UART_PARITY_NONE;
    huart.Init.Mode = UART_MODE_TX_RX;
    huart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart.Init.OverSampling = UART_OVERSAMPLING_16;
    huart.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    lista = HAL_UART_Init(&huart) == HAL_OK;
}

/* ------------------------------------------------------------ newlib */

int _write(int fd, const char *datos, int largo)
{
    (void)fd;
    if (largo <= 0) return 0;
    if (lista) HAL_UART_Transmit(&huart, (const uint8_t *)datos, (uint16_t)largo, 100);
    return largo;
}

int _read(int fd, char *datos, int largo)
{
    (void)fd;
    (void)datos;
    (void)largo;
    return 0;
}

int _close(int fd)
{
    (void)fd;
    return -1;
}

int _fstat(int fd, struct stat *st)
{
    (void)fd;
    st->st_mode = S_IFCHR;
    return 0;
}

int _isatty(int fd)
{
    (void)fd;
    return 1;
}

int _lseek(int fd, int pos, int desde)
{
    (void)fd;
    (void)pos;
    (void)desde;
    return 0;
}

int _getpid(void)
{
    return 1;
}

int _kill(int pid, int sig)
{
    (void)pid;
    (void)sig;
    errno = EINVAL;
    return -1;
}

void _exit(int codigo)
{
    (void)codigo;
    placa_error(PLACA_ERR_OTRO);
}

/* malloc: crece desde el final de .bss hacia la pila, sin pasar de
 * _Min_Stack_Size bytes antes del tope (ver el script del enlazador). */
void *_sbrk(ptrdiff_t incremento)
{
    extern uint8_t _end;
    extern uint8_t _estack;
    extern uint32_t _Min_Stack_Size;
    static uint8_t *tope = NULL;

    const uint8_t *limite = &_estack - (uint32_t)&_Min_Stack_Size;
    if (tope == NULL) tope = &_end;
    if (tope + incremento > limite) {
        errno = ENOMEM;
        return (void *)-1;
    }
    uint8_t *anterior = tope;
    tope += incremento;
    return anterior;
}
