/*
 * pantalla_nucleo.c — "pantalla" de la Nucleo: decodifica con el JPEG por
 * hardware pero no muestra nada (no hay SDRAM ni LTDC).
 *
 * Mismo API que Core/Src/pantalla_stm32.c (pantalla.h). La salida YCbCr va a
 * un trozo de 32 KB en la AXI SRAM que se reutiliza: sirve para comprobar que
 * el códec acepta los JPEG de la PC/celular, cuánto tarda, y que entregó
 * exactamente los bytes que corresponden al tamaño de la imagen.
 *
 * LED LD2 (amarillo): cambia con cada cuadro bien decodificado; parpadea
 * rápido 3 s cuando llega "IDENTIFICAR".
 */
#include "main.h"
#include "nodo_placa.h"
#include "pantalla.h"

#include <stdio.h>

#define LD2_PUERTO GPIOE
#define LD2_PIN    GPIO_PIN_1
#define JPEG_TIEMPO_MS 200u

extern JPEG_HandleTypeDef hjpeg;

/* Búferes de JPEG que usa puente_lwip.c (ver nodo_placa.h) y trozo YCbCr. */
uint8_t nodo_bufer_jpeg[2][NODO_JPEG_CAP] __attribute__((section(".axisram"), aligned(32)));
static uint8_t ycbcr[NODO_TAM_YCBCR] __attribute__((section(".axisram"), aligned(32)));

static const uint8_t *entrada;
static uint32_t entrada_total;
static uint32_t entrada_usada;
static uint32_t salida_total;
static volatile uint8_t jpeg_error;

static pantalla_estadisticas_t estadisticas;
static uint32_t incompletos;
static uint32_t t_error = 0x80000000u;
static uint32_t t_identificar_fin;

void pantalla_iniciar(void)
{
    printf("Pantalla: Nucleo sin LTDC; se decodifica y se cuenta\r\n");
}

void pantalla_identificar(int id, int conectado)
{
    printf("IDENTIFICAR: nodo %d (%s)\r\n", id, conectado ? "con cliente" : "sin cliente");
    t_identificar_fin = HAL_GetTick() + 3000u;
}

/* ------------------------------------------------ callbacks del HAL JPEG */

void HAL_JPEG_GetDataCallback(JPEG_HandleTypeDef *h, uint32_t consumidos)
{
    entrada_usada += consumidos;
    uint32_t resto = entrada_usada < entrada_total ? entrada_total - entrada_usada : 0u;
    HAL_JPEG_ConfigInputBuffer(h, (uint8_t *)(entrada + entrada_usada), resto);
}

void HAL_JPEG_DataReadyCallback(JPEG_HandleTypeDef *h, uint8_t *salida, uint32_t largo)
{
    (void)salida;
    salida_total += largo;
    HAL_JPEG_ConfigOutputBuffer(h, ycbcr, NODO_TAM_YCBCR);   /* se reutiliza el mismo trozo */
}

void HAL_JPEG_ErrorCallback(JPEG_HandleTypeDef *h)
{
    (void)h;
    jpeg_error = 1;
}

/* Bytes que debe entregar el códec: bloques MCU completos. */
static uint32_t bytes_esperados(const JPEG_ConfTypeDef *i)
{
    uint32_t w = i->ImageWidth, a = i->ImageHeight;
    if (i->ColorSpace == JPEG_GRAYSCALE_COLORSPACE) return ((w + 7u) / 8u) * ((a + 7u) / 8u) * 64u;
    if (i->ColorSpace == JPEG_CMYK_COLORSPACE) return ((w + 7u) / 8u) * ((a + 7u) / 8u) * 256u;
    if (i->ChromaSubsampling == JPEG_420_SUBSAMPLING) return ((w + 15u) / 16u) * ((a + 15u) / 16u) * 384u;
    if (i->ChromaSubsampling == JPEG_422_SUBSAMPLING) return ((w + 15u) / 16u) * ((a + 7u) / 8u) * 256u;
    return ((w + 7u) / 8u) * ((a + 7u) / 8u) * 192u;   /* 4:4:4 */
}

static int decodificar(const uint8_t *datos, uint32_t largo)
{
    JPEG_ConfTypeDef info;

    entrada = datos;
    entrada_total = largo;
    entrada_usada = 0;
    salida_total = 0;
    jpeg_error = 0;

    if (HAL_JPEG_Decode(&hjpeg, (uint8_t *)datos, largo, ycbcr, NODO_TAM_YCBCR, JPEG_TIEMPO_MS) != HAL_OK) {
        HAL_JPEG_Abort(&hjpeg);
        return -1;
    }
    if (jpeg_error) return -1;
    if (HAL_JPEG_GetInfo(&hjpeg, &info) != HAL_OK) return -1;
    /* Lo mismo que pide el nodo real: YCbCr y que quepa en la pantalla. */
    if (info.ColorSpace != JPEG_YCBCR_COLORSPACE) return -1;
    if (info.ImageWidth > NODO_ANCHO || info.ImageHeight > NODO_ALTO) return -1;
    if (salida_total != bytes_esperados(&info)) {
        incompletos++;
        return -1;
    }
    estadisticas.ultimo_ancho = info.ImageWidth;
    estadisticas.ultimo_alto = info.ImageHeight;
    return 0;
}

int pantalla_mostrar_jpeg(const uint8_t *datos, uint32_t largo)
{
    uint32_t t0 = HAL_GetTick();
    int r = decodificar(datos, largo);
    if (r == 0) {
        estadisticas.mostrados++;
        estadisticas.ultimo_ms = HAL_GetTick() - t0;
        HAL_GPIO_TogglePin(LD2_PUERTO, LD2_PIN);
    } else {
        estadisticas.errores++;
        t_error = HAL_GetTick();
    }
    return r;
}

const pantalla_estadisticas_t *pantalla_estadisticas(void)
{
    return &estadisticas;
}

/* ------------------------------------------------ para placa_nucleo.c */

void pantalla_nucleo_proceso(uint32_t ahora_ms)
{
    static uint32_t t_led;
    if ((int32_t)(t_identificar_fin - ahora_ms) > 0 && ahora_ms - t_led >= 60u) {
        t_led = ahora_ms;
        HAL_GPIO_TogglePin(LD2_PUERTO, LD2_PIN);
    }
}

uint32_t pantalla_nucleo_ultimo_error(void)
{
    return t_error;
}

uint32_t pantalla_nucleo_incompletos(void)
{
    return incompletos;
}
