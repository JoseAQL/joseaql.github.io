/*
 * placa_nucleo.c — prueba en la NUCLEO-H743ZI2 (STM32H743ZIT6): red + JPEG.
 *
 *   - Reloj: HSE de 8 MHz que entrega el ST-Link (modo bypass) → 400 MHz.
 *   - Ethernet RMII con el LAN8742A de la Nucleo: PA1 REF_CLK, PA2 MDIO,
 *     PC1 MDC, PA7 CRS_DV, PC4 RXD0, PC5 RXD1, PG11 TX_EN, PG13 TXD0, PB13 TXD1.
 *   - Sin SDRAM ni LTDC: pantalla_nucleo.c decodifica con el JPEG por
 *     hardware y solo cuenta.
 *   - LEDs: LD1 verde PB0 (estado, lo maneja puente_lwip.c), LD2 amarillo PE1
 *     (cambia con cada cuadro decodificado), LD3 rojo PB14 (sin enlace / error).
 *   - Consola: USART3 PD8/PD9 → puerto COM virtual del ST-Link, 115200 8N1.
 *   - Número de nodo fijo: 1.
 */
#include "main.h"
#include "nodo_placa.h"
#include "red.h"

#include <stdio.h>

#define LD2_PUERTO GPIOE
#define LD2_PIN    GPIO_PIN_1
#define LD3_PUERTO GPIOB
#define LD3_PIN    GPIO_PIN_14

/* pantalla_nucleo.c */
void pantalla_nucleo_proceso(uint32_t ahora_ms);
uint32_t pantalla_nucleo_ultimo_error(void);
uint32_t pantalla_nucleo_incompletos(void);

const char *placa_nombre(void)
{
    return "NUCLEO-H743ZI2 (prueba sin pantalla)";
}

void placa_led_error(int encendido)
{
    HAL_GPIO_WritePin(LD3_PUERTO, LD3_PIN, encendido ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/* ------------------------------------------------------------------ MPU
 * Igual que el nodo menos la región de la SDRAM (no hay). */
void placa_mpu(void)
{
    HAL_MPU_Disable();
    placa_mpu_region(MPU_REGION_NUMBER0, 0x00000000u, MPU_REGION_SIZE_4GB, MPU_TEX_LEVEL0,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_SHAREABLE,
                     MPU_REGION_NO_ACCESS, 0x87u);
    placa_mpu_region(MPU_REGION_NUMBER2, 0x30020000u, MPU_REGION_SIZE_128KB, MPU_TEX_LEVEL1,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_NOT_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    placa_mpu_region(MPU_REGION_NUMBER3, 0x30040000u, MPU_REGION_SIZE_32KB, MPU_TEX_LEVEL1,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_NOT_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    placa_mpu_region(MPU_REGION_NUMBER4, 0x30040000u, MPU_REGION_SIZE_512B, MPU_TEX_LEVEL0,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_BUFFERABLE, MPU_ACCESS_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/* ------------------------------------------------------------------ relojes: 400 MHz */

void placa_reloj(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
    __HAL_RCC_SYSCFG_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    while (!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState = RCC_HSE_BYPASS;               /* 8 MHz del MCO del ST-Link */
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLM = 4;                            /* 2 MHz */
    osc.PLL.PLLN = 400;                          /* VCO 800 MHz */
    osc.PLL.PLLP = 2;                            /* 400 MHz */
    osc.PLL.PLLQ = 8;
    osc.PLL.PLLR = 2;
    osc.PLL.PLLRGE = RCC_PLL1VCIRANGE_1;         /* 2-4 MHz */
    osc.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
    osc.PLL.PLLFRACN = 0;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) placa_error(PLACA_ERR_RELOJ);

    clk.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                    RCC_CLOCKTYPE_PCLK2 | RCC_CLOCKTYPE_D3PCLK1 | RCC_CLOCKTYPE_D1PCLK1;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.SYSCLKDivider = RCC_SYSCLK_DIV1;
    clk.AHBCLKDivider = RCC_HCLK_DIV2;
    clk.APB3CLKDivider = RCC_APB3_DIV2;
    clk.APB1CLKDivider = RCC_APB1_DIV2;
    clk.APB2CLKDivider = RCC_APB2_DIV2;
    clk.APB4CLKDivider = RCC_APB4_DIV2;
    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK) placa_error(PLACA_ERR_RELOJ);

    __HAL_RCC_CSI_ENABLE();
    HAL_EnableCompensationCell();

    __HAL_RCC_D2SRAM1_CLK_ENABLE();
    __HAL_RCC_D2SRAM2_CLK_ENABLE();
    __HAL_RCC_D2SRAM3_CLK_ENABLE();
}

/* ------------------------------------------------------------------ GPIO */

static void pines_af(GPIO_TypeDef *puerto, uint32_t pines, uint32_t af)
{
    GPIO_InitTypeDef g = {0};
    g.Pin = pines;
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    g.Alternate = af;
    HAL_GPIO_Init(puerto, &g);
}

static void gpio_iniciar(void)
{
    GPIO_InitTypeDef g = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOB, NODO_LED_PIN | LD3_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LD2_PUERTO, LD2_PIN, GPIO_PIN_RESET);
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin = NODO_LED_PIN | LD3_PIN;
    HAL_GPIO_Init(GPIOB, &g);
    g.Pin = LD2_PIN;
    HAL_GPIO_Init(LD2_PUERTO, &g);
}

/* ------------------------------------------------------------------ consola: USART3 PD8/PD9 */

void HAL_UART_MspInit(UART_HandleTypeDef *h)
{
    if (h->Instance != USART3) return;
    __HAL_RCC_USART3_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_8 | GPIO_PIN_9;
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOD, &g);
}

/* ------------------------------------------------------------------ Ethernet */

void HAL_ETH_MspInit(ETH_HandleTypeDef *h)
{
    (void)h;
    pines_af(GPIOA, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_7, GPIO_AF11_ETH);
    pines_af(GPIOB, GPIO_PIN_13, GPIO_AF11_ETH);
    pines_af(GPIOC, GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5, GPIO_AF11_ETH);
    pines_af(GPIOG, GPIO_PIN_11 | GPIO_PIN_13, GPIO_AF11_ETH);

    __HAL_RCC_ETH1MAC_CLK_ENABLE();
    __HAL_RCC_ETH1TX_CLK_ENABLE();
    __HAL_RCC_ETH1RX_CLK_ENABLE();
}

void placa_phy_reiniciar(void)
{
    /* En la Nucleo el nRST del PHY va al NRST del micro: no hay nada que hacer. */
}

/* ------------------------------------------------------------------ arranque */

void placa_iniciar(void)
{
    gpio_iniciar();
    consola_iniciar(USART3);
    printf("\r\nArranque: NUCLEO-H743ZI2\r\n");

    /* Saludo de LEDs: verde, amarillo, rojo. */
    HAL_GPIO_WritePin(GPIOB, NODO_LED_PIN, GPIO_PIN_SET);
    HAL_Delay(150);
    HAL_GPIO_WritePin(LD2_PUERTO, LD2_PIN, GPIO_PIN_SET);
    HAL_Delay(150);
    HAL_GPIO_WritePin(LD3_PUERTO, LD3_PIN, GPIO_PIN_SET);
    HAL_Delay(150);
    HAL_GPIO_WritePin(GPIOB, NODO_LED_PIN | LD3_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LD2_PUERTO, LD2_PIN, GPIO_PIN_RESET);

    if (placa_jpeg_iniciar() != 0) {
        printf("JPEG: no inicializo\r\n");
        placa_error(PLACA_ERR_VIDEO);
    }
}

void placa_proceso(uint32_t ahora_ms)
{
    pantalla_nucleo_proceso(ahora_ms);

    /* LD3: fijo = sin cable de red; destello de 200 ms = JPEG con error. */
    int rojo = !red_enlace_arriba() || (ahora_ms - pantalla_nucleo_ultimo_error() < 200u);
    HAL_GPIO_WritePin(LD3_PUERTO, LD3_PIN, rojo ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

void placa_imprimir_estado(void)
{
    printf("          JPEG con salida incompleta=%lu\r\n",
           (unsigned long)pantalla_nucleo_incompletos());
}
