/*
 * placa_nodo.c — placa propia del nodo (STM32H743IIT6, LQFP176).
 *
 * Todo sale de hardware/pines.csv y hardware/DISENO.md:
 *   - Relojes: HSE 25 MHz; PLL1 → 480 MHz (o 400 con CPU_MHZ=400);
 *     PLL2R 200 MHz → FMC → SDCLK 100 MHz; PLL3R → reloj de píxel del LTDC.
 *   - SDRAM 32 MB, 16 bits, banco 2 del FMC (0xD0000000), con la secuencia
 *     JEDEC (reloj, PALL, 8 auto-refrescos, registro de modo 0x0230) y
 *     refresco 761.
 *   - LTDC RGB888 hacia el TFP410, capa 0 en RGB565 (tiempos en placa_ltdc.h).
 *   - Ethernet RMII con el LAN8742A (REF_CLK de 50 MHz desde el PHY en PA1).
 *   - DIP de número de nodo en PF6-PF9 (pull-up), LED de estado PB0,
 *     LED auxiliar PB1, consola USART1 en PB14/PB15.
 *   - MPU según DISENO §7.
 *
 * NADA DE ESTO SE HA PROBADO EN HARDWARE (la placa no existe todavía).
 */
#include "main.h"
#include "nodo_placa.h"
#include "placa_ltdc.h"
#include "red.h"

#include <stdio.h>

#ifndef NODO_CPU_MHZ
#define NODO_CPU_MHZ 480
#endif

DMA2D_HandleTypeDef hdma2d;
LTDC_HandleTypeDef hltdc;
static SDRAM_HandleTypeDef hsdram;
static uint32_t ltdc_underruns;
static uint32_t ltdc_errores;

#define LED_AUX_PUERTO   GPIOB
#define LED_AUX_PIN      GPIO_PIN_1
#define ETH_NRST_PUERTO  GPIOD
#define ETH_NRST_PIN     GPIO_PIN_7
#define HDMI_EN_PIN      GPIO_PIN_3   /* PD3 */
#define TFP_PD_N_PIN     GPIO_PIN_4   /* PD4 */
#define TFP_MSEN_PIN     GPIO_PIN_5   /* PD5 */
#define HDMI_HPD_PIN     GPIO_PIN_11  /* PD11 */

const char *placa_nombre(void)
{
    return "STM32H743IIT6 (placa del nodo)";
}

void placa_led_error(int encendido)
{
    HAL_GPIO_WritePin(LED_AUX_PUERTO, LED_AUX_PIN, encendido ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(NODO_LED_PUERTO, NODO_LED_PIN, encendido ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/* ------------------------------------------------------------------ MPU (DISENO §7) */

void placa_mpu(void)
{
    HAL_MPU_Disable();
    /* 0: fondo sin acceso para 0x60000000-0xDFFFFFFF (evita lecturas especulativas al FMC) */
    placa_mpu_region(MPU_REGION_NUMBER0, 0x00000000u, MPU_REGION_SIZE_4GB, MPU_TEX_LEVEL0,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_SHAREABLE,
                     MPU_REGION_NO_ACCESS, 0x87u);
    /* 1: SDRAM, caché write-through */
    placa_mpu_region(MPU_REGION_NUMBER1, NODO_SDRAM_BASE, MPU_REGION_SIZE_32MB, MPU_TEX_LEVEL0,
                     MPU_ACCESS_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_NOT_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    /* 2: SRAM2 de D2 (montículo de LwIP), normal sin caché */
    placa_mpu_region(MPU_REGION_NUMBER2, 0x30020000u, MPU_REGION_SIZE_128KB, MPU_TEX_LEVEL1,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_NOT_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    /* 3: SRAM3 de D2 (búferes RX de Ethernet), normal sin caché */
    placa_mpu_region(MPU_REGION_NUMBER3, 0x30040000u, MPU_REGION_SIZE_32KB, MPU_TEX_LEVEL1,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_NOT_BUFFERABLE, MPU_ACCESS_NOT_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    /* 4: descriptores DMA de Ethernet, dispositivo compartido */
    placa_mpu_region(MPU_REGION_NUMBER4, 0x30040000u, MPU_REGION_SIZE_512B, MPU_TEX_LEVEL0,
                     MPU_ACCESS_NOT_CACHEABLE, MPU_ACCESS_BUFFERABLE, MPU_ACCESS_SHAREABLE,
                     MPU_REGION_FULL_ACCESS, 0x00u);
    HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/* ------------------------------------------------------------------ relojes (DISENO §4) */

void placa_reloj(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};
    RCC_PeriphCLKInitTypeDef per = {0};
    uint32_t latencia;

    HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
    __HAL_RCC_SYSCFG_CLK_ENABLE();
#if NODO_CPU_MHZ == 480
    /* 480 MHz necesita VOS0 (solo silicio revisión V). */
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    while (!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);
    osc.PLL.PLLN = 192;          /* 5 MHz x 192 = 960 MHz */
    osc.PLL.PLLQ = 20;
    latencia = FLASH_LATENCY_4;  /* AXI 240 MHz en VOS0 */
#elif NODO_CPU_MHZ == 400
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
    osc.PLL.PLLN = 160;          /* 5 MHz x 160 = 800 MHz */
    osc.PLL.PLLQ = 16;
    latencia = FLASH_LATENCY_2;  /* AXI 200 MHz en VOS1 */
#else
#error "NODO_CPU_MHZ debe ser 480 o 400"
#endif
    while (!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState = RCC_HSE_ON;                   /* cristal de 25 MHz */
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLM = 5;                            /* 5 MHz de referencia */
    osc.PLL.PLLP = 2;
    osc.PLL.PLLR = 2;
    osc.PLL.PLLRGE = RCC_PLL1VCIRANGE_2;         /* 4-8 MHz */
    osc.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
    osc.PLL.PLLFRACN = 0;
    if (HAL_RCC_OscConfig(&osc) != HAL_OK) placa_error(PLACA_ERR_RELOJ);

    clk.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 |
                    RCC_CLOCKTYPE_PCLK2 | RCC_CLOCKTYPE_D3PCLK1 | RCC_CLOCKTYPE_D1PCLK1;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.SYSCLKDivider = RCC_SYSCLK_DIV1;
    clk.AHBCLKDivider = RCC_HCLK_DIV2;
    clk.APB3CLKDivider = RCC_APB3_DIV2;
    clk.APB1CLKDivider = RCC_APB1_DIV2;
    clk.APB2CLKDivider = RCC_APB2_DIV2;
    clk.APB4CLKDivider = RCC_APB4_DIV2;
    if (HAL_RCC_ClockConfig(&clk, latencia) != HAL_OK) placa_error(PLACA_ERR_RELOJ);

    /* PLL2R = 25/5*80/2 = 200 MHz → FMC; PLL3R = 25/25*N/R → LTDC */
    per.PeriphClockSelection = RCC_PERIPHCLK_FMC | RCC_PERIPHCLK_LTDC;
    per.PLL2.PLL2M = 5;
    per.PLL2.PLL2N = 80;
    per.PLL2.PLL2P = 2;
    per.PLL2.PLL2Q = 2;
    per.PLL2.PLL2R = 2;
    per.PLL2.PLL2RGE = RCC_PLL2VCIRANGE_2;
    per.PLL2.PLL2VCOSEL = RCC_PLL2VCOWIDE;
    per.PLL2.PLL2FRACN = 0;
    per.FmcClockSelection = RCC_FMCCLKSOURCE_PLL2;
    per.PLL3.PLL3M = LTDC_PLL3M;
    per.PLL3.PLL3N = LTDC_PLL3N;
    per.PLL3.PLL3P = 2;
    per.PLL3.PLL3Q = 2;
    per.PLL3.PLL3R = LTDC_PLL3R;
    per.PLL3.PLL3RGE = RCC_PLL3VCIRANGE_0;       /* 1-2 MHz */
    per.PLL3.PLL3VCOSEL = RCC_PLL3VCOMEDIUM;     /* 150-420 MHz */
    per.PLL3.PLL3FRACN = 0;
    if (HAL_RCCEx_PeriphCLKConfig(&per) != HAL_OK) placa_error(PLACA_ERR_RELOJ);

    /* Celda de compensación de E/S: necesaria para FMC a 100 MHz con 3.3 V. */
    __HAL_RCC_CSI_ENABLE();
    HAL_EnableCompensationCell();

    /* SRAM de D2 (LwIP y Ethernet) con reloj. */
    __HAL_RCC_D2SRAM1_CLK_ENABLE();
    __HAL_RCC_D2SRAM2_CLK_ENABLE();
    __HAL_RCC_D2SRAM3_CLK_ENABLE();
}

/* ------------------------------------------------------------------ GPIO */

static void pines_af(GPIO_TypeDef *puerto, uint32_t pines, uint32_t af, uint32_t velocidad)
{
    GPIO_InitTypeDef g = {0};
    g.Pin = pines;
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = velocidad;
    g.Alternate = af;
    HAL_GPIO_Init(puerto, &g);
}

static void gpio_iniciar(void)
{
    GPIO_InitTypeDef g = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOI_CLK_ENABLE();

    /* LED de estado PB0 y auxiliar PB1 */
    HAL_GPIO_WritePin(GPIOB, NODO_LED_PIN | LED_AUX_PIN, GPIO_PIN_RESET);
    g.Pin = NODO_LED_PIN | LED_AUX_PIN;
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &g);

    /* DIP de número de nodo: entradas con pull-up (cerrado a GND = 1) */
    g.Pin = NODO_ID_PIN0 | NODO_ID_PIN1 | NODO_ID_PIN2 | NODO_ID_PIN3;
    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(NODO_ID_PUERTO, &g);

    /* Botón de usuario PC13 (a GND) */
    g.Pin = GPIO_PIN_13;
    HAL_GPIO_Init(GPIOC, &g);

    /* PD3 HDMI_EN y PD4 TFP_PD_N en alto: transmisor HDMI encendido */
    HAL_GPIO_WritePin(GPIOD, HDMI_EN_PIN | TFP_PD_N_PIN, GPIO_PIN_SET);
    g.Pin = HDMI_EN_PIN | TFP_PD_N_PIN;
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &g);

    /* PD7 ETH_NRST: drenaje abierto con pull-up externo, suelto (PHY corriendo) */
    HAL_GPIO_WritePin(ETH_NRST_PUERTO, ETH_NRST_PIN, GPIO_PIN_SET);
    g.Pin = ETH_NRST_PIN;
    g.Mode = GPIO_MODE_OUTPUT_OD;
    HAL_GPIO_Init(ETH_NRST_PUERTO, &g);

    /* PD5 TFP_MSEN (pull-up externo) y PD11 HDMI_HPD (pull-down interno) */
    g.Pin = TFP_MSEN_PIN;
    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &g);
    g.Pin = HDMI_HPD_PIN;
    g.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(GPIOD, &g);
}

/* ------------------------------------------------------------------ consola: USART1 PB14/PB15 */

void HAL_UART_MspInit(UART_HandleTypeDef *h)
{
    if (h->Instance != USART1) return;
    __HAL_RCC_USART1_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = GPIO_PIN_14 | GPIO_PIN_15;
    g.Mode = GPIO_MODE_AF_PP;
    g.Pull = GPIO_PULLUP;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Alternate = GPIO_AF4_USART1;
    HAL_GPIO_Init(GPIOB, &g);
}

/* ------------------------------------------------------------------ Ethernet RMII */

void HAL_ETH_MspInit(ETH_HandleTypeDef *h)
{
    (void)h;
    /* PA1 REF_CLK, PA7 CRS_DV, PC4 RXD0, PC5 RXD1, PB11 TX_EN, PB12 TXD0, PB13 TXD1 */
    pines_af(GPIOA, GPIO_PIN_1 | GPIO_PIN_7, GPIO_AF11_ETH, GPIO_SPEED_FREQ_VERY_HIGH);
    pines_af(GPIOC, GPIO_PIN_4 | GPIO_PIN_5, GPIO_AF11_ETH, GPIO_SPEED_FREQ_VERY_HIGH);
    pines_af(GPIOB, GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13, GPIO_AF11_ETH, GPIO_SPEED_FREQ_VERY_HIGH);
    /* PA2 MDIO, PC1 MDC (lentos; MDIO con pull-up externo de 1.5k) */
    pines_af(GPIOA, GPIO_PIN_2, GPIO_AF11_ETH, GPIO_SPEED_FREQ_LOW);
    pines_af(GPIOC, GPIO_PIN_1, GPIO_AF11_ETH, GPIO_SPEED_FREQ_LOW);

    __HAL_RCC_ETH1MAC_CLK_ENABLE();
    __HAL_RCC_ETH1TX_CLK_ENABLE();
    __HAL_RCC_ETH1RX_CLK_ENABLE();
}

void placa_phy_reiniciar(void)
{
    /* Pulso de reinicio al LAN8742A. Al soltarlo, el PHY lee sus straps
     * (modo, dirección 0, REF_CLK de salida) y arranca su PLL de 50 MHz. */
    HAL_GPIO_WritePin(ETH_NRST_PUERTO, ETH_NRST_PIN, GPIO_PIN_RESET);
    HAL_Delay(2);
    HAL_GPIO_WritePin(ETH_NRST_PUERTO, ETH_NRST_PIN, GPIO_PIN_SET);
    HAL_Delay(10);   /* margen para que salga REF_CLK (VERIFICAR en la hoja del LAN8742A) */
}

/* ------------------------------------------------------------------ SDRAM (DISENO §5.2) */

void HAL_SDRAM_MspInit(SDRAM_HandleTypeDef *h)
{
    (void)h;
    __HAL_RCC_FMC_CLK_ENABLE();
    const uint32_t v = GPIO_SPEED_FREQ_VERY_HIGH;
    /* D2 D3 D13 D14 D15 D0 D1 */
    pines_af(GPIOD, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 |
                    GPIO_PIN_14 | GPIO_PIN_15, GPIO_AF12_FMC, v);
    /* NBL0 NBL1 D4..D12 */
    pines_af(GPIOE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 |
                    GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 |
                    GPIO_PIN_15, GPIO_AF12_FMC, v);
    /* A0..A5 SDNRAS A6..A9 */
    pines_af(GPIOF, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 |
                    GPIO_PIN_5 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 |
                    GPIO_PIN_15, GPIO_AF12_FMC, v);
    /* A10 A11 A12 BA0 BA1 SDCLK SDNCAS */
    pines_af(GPIOG, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_4 | GPIO_PIN_5 |
                    GPIO_PIN_8 | GPIO_PIN_15, GPIO_AF12_FMC, v);
    /* SDNWE SDNE1 SDCKE1 */
    pines_af(GPIOH, GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7, GPIO_AF12_FMC, v);
}

static int sdram_comando(uint32_t modo, uint32_t refrescos, uint32_t registro)
{
    FMC_SDRAM_CommandTypeDef c = {0};
    c.CommandMode = modo;
    c.CommandTarget = FMC_SDRAM_CMD_TARGET_BANK2;
    c.AutoRefreshNumber = refrescos;
    c.ModeRegisterDefinition = registro;
    return HAL_SDRAM_SendCommand(&hsdram, &c, 0xFFFF) == HAL_OK ? 0 : -1;
}

static int sdram_iniciar(void)
{
    FMC_SDRAM_TimingTypeDef t = {0};

    hsdram.Instance = FMC_SDRAM_DEVICE;
    hsdram.Init.SDBank = FMC_SDRAM_BANK2;
    hsdram.Init.ColumnBitsNumber = FMC_SDRAM_COLUMN_BITS_NUM_9;
    hsdram.Init.RowBitsNumber = FMC_SDRAM_ROW_BITS_NUM_13;
    hsdram.Init.MemoryDataWidth = FMC_SDRAM_MEM_BUS_WIDTH_16;
    hsdram.Init.InternalBankNumber = FMC_SDRAM_INTERN_BANKS_NUM_4;
    hsdram.Init.CASLatency = FMC_SDRAM_CAS_LATENCY_3;
    hsdram.Init.WriteProtection = FMC_SDRAM_WRITE_PROTECTION_DISABLE;
    hsdram.Init.SDClockPeriod = FMC_SDRAM_CLOCK_PERIOD_2;   /* 200 MHz / 2 = 100 MHz */
    hsdram.Init.ReadBurst = FMC_SDRAM_RBURST_ENABLE;
    hsdram.Init.ReadPipeDelay = FMC_SDRAM_RPIPE_DELAY_0;    /* subir a 1 si la prueba falla */

    /* Ciclos a 100 MHz para IS42S16160J-7 / W9825G6KH-6 (VERIFICAR con la pieza) */
    t.LoadToActiveDelay = 2;      /* tMRD */
    t.ExitSelfRefreshDelay = 7;   /* tXSR 70 ns */
    t.SelfRefreshTime = 5;        /* tRAS 42 ns */
    t.RowCycleDelay = 7;          /* tRC 67.5 ns */
    t.WriteRecoveryTime = 3;      /* tWR (>= tRAS - tRCD y >= tRC - tRCD - tRP) */
    t.RPDelay = 2;                /* tRP 20 ns */
    t.RCDDelay = 2;               /* tRCD 20 ns */

    if (HAL_SDRAM_Init(&hsdram, &t) != HAL_OK) return -1;

    /* Secuencia JEDEC */
    if (sdram_comando(FMC_SDRAM_CMD_CLK_ENABLE, 1, 0) != 0) return -1;
    HAL_Delay(1);                                         /* >= 100 us con reloj estable */
    if (sdram_comando(FMC_SDRAM_CMD_PALL, 1, 0) != 0) return -1;
    if (sdram_comando(FMC_SDRAM_CMD_AUTOREFRESH_MODE, 8, 0) != 0) return -1;
    /* Registro de modo 0x0230: ráfaga 1, secuencial, CAS 3, escritura simple */
    if (sdram_comando(FMC_SDRAM_CMD_LOAD_MODE, 1, 0x0230) != 0) return -1;
    /* 8192 filas / 64 ms = 7.81 us → 7.81 x 100 MHz - 20 = 761 */
    if (HAL_SDRAM_ProgramRefreshRate(&hsdram, 761) != HAL_OK) return -1;
    return 0;
}

/* Prueba rápida con la D-caché apagada: datos, líneas de datos y de dirección.
 * Regresa 0 si todo bien; si no, la dirección (desplazamiento) que falló + 1. */
static uint32_t sdram_probar(void)
{
    volatile uint32_t *m = (volatile uint32_t *)NODO_SDRAM_BASE;
    volatile uint16_t *m16 = (volatile uint16_t *)NODO_SDRAM_BASE;

    /* líneas de datos D0-D15: un 1 que camina */
    for (uint32_t b = 0; b < 16; b++) {
        m16[0] = (uint16_t)(1u << b);
        m16[1] = 0;   /* otro valor en el bus para no leer lo que quedó */
        if (m16[0] != (uint16_t)(1u << b)) return 1;
    }

    /* 64 KB con un patrón que cambia en cada palabra */
    for (uint32_t i = 0; i < 16384u; i++) m[i] = (i * 0x9E3779B9u) ^ 0xA5A5A5A5u;
    for (uint32_t i = 0; i < 16384u; i++) {
        if (m[i] != ((i * 0x9E3779B9u) ^ 0xA5A5A5A5u)) return i * 4u + 1u;
    }

    /* líneas de dirección: 32 MB = 2^25 bytes; potencias de 2 desde 4 B */
    m[0] = 0x55AA55AAu;
    for (uint32_t k = 2; k < 25; k++) m[(1u << k) / 4u] = 0xC0DE0000u | k;
    if (m[0] != 0x55AA55AAu) return 1;
    for (uint32_t k = 2; k < 25; k++) {
        if (m[(1u << k) / 4u] != (0xC0DE0000u | k)) return (1u << k) + 1u;
    }
    return 0;
}

/* ------------------------------------------------------------------ LTDC (DISENO §5.1) */

void HAL_LTDC_MspInit(LTDC_HandleTypeDef *h)
{
    (void)h;
    __HAL_RCC_LTDC_CLK_ENABLE();
    const uint32_t a = GPIO_SPEED_FREQ_HIGH;
    pines_af(GPIOD, GPIO_PIN_6, GPIO_AF14_LTDC, a);                                        /* B2 */
    pines_af(GPIOE, GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6, GPIO_AF14_LTDC, a);              /* B0 G0 G1 */
    pines_af(GPIOF, GPIO_PIN_10, GPIO_AF14_LTDC, a);                                       /* DE */
    pines_af(GPIOG, GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_11 | GPIO_PIN_12, GPIO_AF14_LTDC, a);/* R7 CLK B3 B1 */
    pines_af(GPIOH, GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 |
                    GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15,
             GPIO_AF14_LTDC, a);                                                           /* R0-R6 G2-G4 */
    pines_af(GPIOI, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_4 | GPIO_PIN_5 |
                    GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_9 | GPIO_PIN_10,
             GPIO_AF14_LTDC, a);                                                           /* G5-G7 B4-B7 VSYNC HSYNC */
}

static int ltdc_iniciar(void)
{
    hltdc.Instance = LTDC;
    hltdc.Init.HSPolarity = LTDC_HSPOL;
    hltdc.Init.VSPolarity = LTDC_VSPOL;
    hltdc.Init.DEPolarity = LTDC_DEPOLARITY_AL;   /* DE activo en alto en el pin (VERIFICAR con osciloscopio) */
    hltdc.Init.PCPolarity = LTDC_PCPOLARITY_IPC;  /* si hay ruido en los píxeles: LTDC_PCPOLARITY_IIPC */
    hltdc.Init.HorizontalSync = LTDC_HSYNC - 1u;
    hltdc.Init.AccumulatedHBP = LTDC_HSYNC + LTDC_HBP - 1u;
    hltdc.Init.AccumulatedActiveW = LTDC_HSYNC + LTDC_HBP + NODO_ANCHO - 1u;
    hltdc.Init.TotalWidth = LTDC_HSYNC + LTDC_HBP + NODO_ANCHO + LTDC_HFP - 1u;
    hltdc.Init.VerticalSync = LTDC_VSYNC - 1u;
    hltdc.Init.AccumulatedVBP = LTDC_VSYNC + LTDC_VBP - 1u;
    hltdc.Init.AccumulatedActiveH = LTDC_VSYNC + LTDC_VBP + NODO_ALTO - 1u;
    hltdc.Init.TotalHeigh = LTDC_VSYNC + LTDC_VBP + NODO_ALTO + LTDC_VFP - 1u;
    hltdc.Init.Backcolor.Red = 0;
    hltdc.Init.Backcolor.Green = 0;
    hltdc.Init.Backcolor.Blue = 0;
    if (HAL_LTDC_Init(&hltdc) != HAL_OK) return -1;

    LTDC_LayerCfgTypeDef capa = {0};
    capa.WindowX0 = 0;
    capa.WindowX1 = NODO_ANCHO;
    capa.WindowY0 = 0;
    capa.WindowY1 = NODO_ALTO;
    capa.PixelFormat = LTDC_PIXEL_FORMAT_RGB565;
    capa.Alpha = 255;
    capa.Alpha0 = 0;
    capa.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
    capa.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
    capa.FBStartAdress = NODO_FB0;
    capa.ImageWidth = NODO_ANCHO;
    capa.ImageHeight = NODO_ALTO;
    if (HAL_LTDC_ConfigLayer(&hltdc, &capa, 0) != HAL_OK) return -1;
    return 0;
}

/* ------------------------------------------------------------------ DMA2D */

void HAL_DMA2D_MspInit(DMA2D_HandleTypeDef *h)
{
    (void)h;
    __HAL_RCC_DMA2D_CLK_ENABLE();
}

static int dma2d_iniciar(void)
{
    /* pantalla_stm32.c vuelve a configurar el DMA2D en cada cuadro. */
    hdma2d.Instance = DMA2D;
    hdma2d.Init.Mode = DMA2D_M2M_PFC;
    hdma2d.Init.ColorMode = DMA2D_OUTPUT_RGB565;
    hdma2d.Init.OutputOffset = 0;
    hdma2d.Init.AlphaInverted = DMA2D_REGULAR_ALPHA;
    hdma2d.Init.RedBlueSwap = DMA2D_RB_REGULAR;
    hdma2d.Init.BytesSwap = DMA2D_BYTES_REGULAR;
    hdma2d.Init.LineOffsetMode = DMA2D_LOM_PIXELS;
    return HAL_DMA2D_Init(&hdma2d) == HAL_OK ? 0 : -1;
}

/* ------------------------------------------------------------------ arranque */

void placa_iniciar(void)
{
    gpio_iniciar();
    consola_iniciar(USART1);
    printf("\r\nArranque: placa del nodo, SDRAM...\r\n");

    if (sdram_iniciar() != 0) {
        printf("SDRAM: no inicializo el FMC\r\n");
        placa_error(PLACA_ERR_SDRAM);
    }
    uint32_t falla = sdram_probar();
    if (falla != 0) {
        printf("SDRAM: la prueba fallo cerca de 0x%08lx\r\n",
               (unsigned long)(NODO_SDRAM_BASE + falla - 1u));
        placa_error(PLACA_ERR_SDRAM);
    }
    printf("SDRAM: 32 MB en 0x%08lx, prueba bien\r\n", (unsigned long)NODO_SDRAM_BASE);

    if (ltdc_iniciar() != 0 || dma2d_iniciar() != 0 || placa_jpeg_iniciar() != 0) {
        printf("Video: fallo LTDC, DMA2D o JPEG\r\n");
        placa_error(PLACA_ERR_VIDEO);
    }
    printf("LTDC: %dx%d, reloj de pixel %lu MHz\r\n", NODO_ANCHO, NODO_ALTO,
           (unsigned long)(LTDC_PLL3N / LTDC_PLL3R));
}

void placa_proceso(uint32_t ahora_ms)
{
    (void)ahora_ms;
    /* LED auxiliar encendido = sin cable de red */
    HAL_GPIO_WritePin(LED_AUX_PUERTO, LED_AUX_PIN, red_enlace_arriba() ? GPIO_PIN_RESET : GPIO_PIN_SET);

    /* FIFO underrun del LTDC = la SDRAM no alcanza (DISENO §6) */
    uint32_t isr = LTDC->ISR;
    if (isr & LTDC_ISR_FUIF) {
        ltdc_underruns++;
        LTDC->ICR = LTDC_ICR_CFUIF;
    }
    if (isr & LTDC_ISR_TERRIF) {
        ltdc_errores++;
        LTDC->ICR = LTDC_ICR_CTERRIF;
    }
}

void placa_imprimir_estado(void)
{
    printf("          LTDC underruns=%lu errores=%lu | monitor HPD=%d MSEN=%d\r\n",
           (unsigned long)ltdc_underruns, (unsigned long)ltdc_errores,
           HAL_GPIO_ReadPin(GPIOD, HDMI_HPD_PIN) == GPIO_PIN_SET,
           HAL_GPIO_ReadPin(GPIOD, TFP_MSEN_PIN) == GPIO_PIN_RESET);
}
