/*
 * placa_ltdc.h — tiempos del LTDC y del PLL3 (reloj de píxel) según la
 * resolución de nodo_placa.h (NODO_ANCHO x NODO_ALTO).
 *
 * Números de hardware/DISENO.md §4.4 y §5.1. Referencia del PLL3 = 1 MHz
 * (HSE 25 MHz / DIVM3 25); reloj de píxel = DIVN3 / DIVR3 MHz.
 * Los campos van como los pide LTDC_InitTypeDef (ya restado el 1):
 *   HorizontalSync = HSYNC-1, AccumulatedHBP = HSYNC+HBP-1,
 *   AccumulatedActiveW = HSYNC+HBP+ANCHO-1, TotalWidth = total-1 (igual en V).
 */
#ifndef PLACA_LTDC_H
#define PLACA_LTDC_H

#include "nodo_placa.h"

#if NODO_ANCHO == 800 && NODO_ALTO == 600
/* 800x600 @ 60 Hz VESA, 40.000 MHz. HSYNC 128, HBP 88, HFP 40; VSYNC 4, VBP 23, VFP 1; + / + */
#define LTDC_PLL3N   240u
#define LTDC_PLL3R   6u
#define LTDC_HSYNC   128u
#define LTDC_HBP     88u
#define LTDC_HFP     40u
#define LTDC_VSYNC   4u
#define LTDC_VBP     23u
#define LTDC_VFP     1u
#define LTDC_HSPOL   LTDC_HSPOLARITY_AH
#define LTDC_VSPOL   LTDC_VSPOLARITY_AH

#elif NODO_ANCHO == 1024 && NODO_ALTO == 600
/* 1024x600 @ 60 Hz, 51.2 MHz (combinación propia, NO estándar; DISENO §5.1). */
#define LTDC_PLL3N   256u
#define LTDC_PLL3R   5u
#define LTDC_HSYNC   136u
#define LTDC_HBP     160u
#define LTDC_HFP     24u
#define LTDC_VSYNC   6u
#define LTDC_VBP     26u
#define LTDC_VFP     3u
#define LTDC_HSPOL   LTDC_HSPOLARITY_AL
#define LTDC_VSPOL   LTDC_VSPOLARITY_AL

#elif NODO_ANCHO == 1024 && NODO_ALTO == 768
/* 1024x768 @ 60 Hz VESA, 65 MHz. HSYNC 136, HBP 160, HFP 24; VSYNC 6, VBP 29, VFP 3; - / - */
#define LTDC_PLL3N   260u
#define LTDC_PLL3R   4u
#define LTDC_HSYNC   136u
#define LTDC_HBP     160u
#define LTDC_HFP     24u
#define LTDC_VSYNC   6u
#define LTDC_VBP     29u
#define LTDC_VFP     3u
#define LTDC_HSPOL   LTDC_HSPOLARITY_AL
#define LTDC_VSPOL   LTDC_VSPOLARITY_AL

#elif NODO_ANCHO == 1280 && NODO_ALTO == 720
/* 1280x720 @ 30 Hz (CEA VIC 62), 74.25 MHz: el único 720p que cabe en la SDRAM
 * (DISENO §6). Con la referencia de 1 MHz: 297 / 4 = 74.25 MHz. */
#define LTDC_PLL3N   297u
#define LTDC_PLL3R   4u
#define LTDC_HSYNC   40u
#define LTDC_HBP     220u
#define LTDC_HFP     1760u
#define LTDC_VSYNC   5u
#define LTDC_VBP     20u
#define LTDC_VFP     5u
#define LTDC_HSPOL   LTDC_HSPOLARITY_AH
#define LTDC_VSPOL   LTDC_VSPOLARITY_AH

#else
#error "Resolucion sin tiempos de LTDC: agrega un caso en placa_ltdc.h (ver hardware/DISENO.md 5.1)"
#endif

#define LTDC_PLL3M   25u   /* HSE 25 MHz / 25 = 1 MHz */

#endif
