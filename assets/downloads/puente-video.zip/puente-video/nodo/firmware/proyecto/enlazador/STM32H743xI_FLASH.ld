/*
 * STM32H743xI_FLASH.ld — script del enlazador del nodo Puente Video.
 *
 * Sirve igual para el STM32H743IITx (LQFP176, placa del nodo) y para el
 * STM32H743ZITx (LQFP144, NUCLEO-H743ZI2): los dos tienen 2 MB de flash y
 * el mismo mapa de RAM.
 *
 * Dónde queda cada cosa:
 *
 *   FLASH     0x08000000  2 MB    vectores, código, constantes, valores de .data
 *   DTCM      0x20000000  128 KB  .data, .bss, montículo (malloc) y pila.
 *                                 Es la RAM más rápida, pero el DMA de Ethernet,
 *                                 el JPEG y el DMA2D NO la ven: ahí solo va lo
 *                                 que usa la CPU.
 *   AXI SRAM  0x24000000  512 KB  .axisram (NOLOAD): búferes grandes. En la
 *                                 Nucleo, los JPEG y el YCbCr; en el nodo queda
 *                                 libre para decodificar por franjas (DISENO §6).
 *   SRAM1 D2  0x30000000  128 KB  .ram_d2 (NOLOAD), libre por ahora.
 *   SRAM2 D2  0x30020000  128 KB  .lwip_heap (NOLOAD): montículo de LwIP. Ahí
 *                                 viven los paquetes que salen; el MPU la deja
 *                                 sin caché (región 2).
 *   SRAM3 D2  0x30040000  32 KB   descriptores DMA de Ethernet (los primeros
 *                                 512 B, memoria tipo dispositivo, región 4 del
 *                                 MPU) y, desde 0x30040200, los búferes de
 *                                 recepción de Ethernet (región 3, sin caché).
 *
 * Los números de región del MPU están en placa/<placa>/placa_*.c
 * (placa_mpu) y coinciden con hardware/DISENO.md §7.
 */

ENTRY(Reset_Handler)

/* La pila arriba de la DTCM. */
_estack = ORIGIN(DTCMRAM) + LENGTH(DTCMRAM);

/* Tamaños mínimos: el enlazador avisa si no caben. */
_Min_Heap_Size  = 0x2000;   /* 8 KB para malloc (newlib casi no lo usa) */
_Min_Stack_Size = 0x4000;   /* 16 KB de pila */

MEMORY
{
  FLASH      (rx)  : ORIGIN = 0x08000000, LENGTH = 2048K
  DTCMRAM    (xrw) : ORIGIN = 0x20000000, LENGTH = 128K
  RAM_D1     (xrw) : ORIGIN = 0x24000000, LENGTH = 512K
  RAM_D2_S1  (xrw) : ORIGIN = 0x30000000, LENGTH = 128K
  RAM_D2_S2  (xrw) : ORIGIN = 0x30020000, LENGTH = 128K
  RAM_D2_S3  (xrw) : ORIGIN = 0x30040000, LENGTH = 32K
  RAM_D3     (xrw) : ORIGIN = 0x38000000, LENGTH = 64K
  ITCMRAM    (xrw) : ORIGIN = 0x00000000, LENGTH = 64K
}

SECTIONS
{
  .isr_vector :
  {
    . = ALIGN(4);
    KEEP(*(.isr_vector))
    . = ALIGN(4);
  } >FLASH

  .text :
  {
    . = ALIGN(4);
    *(.text)
    *(.text*)
    *(.glue_7)
    *(.glue_7t)
    *(.eh_frame)
    KEEP (*(.init))
    KEEP (*(.fini))
    . = ALIGN(4);
    _etext = .;
  } >FLASH

  .rodata :
  {
    . = ALIGN(4);
    *(.rodata)
    *(.rodata*)
    . = ALIGN(4);
  } >FLASH

  .ARM.extab (READONLY) :
  {
    *(.ARM.extab* .gnu.linkonce.armextab.*)
  } >FLASH

  .ARM (READONLY) :
  {
    __exidx_start = .;
    *(.ARM.exidx*)
    __exidx_end = .;
  } >FLASH

  .preinit_array (READONLY) :
  {
    PROVIDE_HIDDEN (__preinit_array_start = .);
    KEEP (*(.preinit_array*))
    PROVIDE_HIDDEN (__preinit_array_end = .);
  } >FLASH

  .init_array (READONLY) :
  {
    PROVIDE_HIDDEN (__init_array_start = .);
    KEEP (*(SORT(.init_array.*)))
    KEEP (*(.init_array*))
    PROVIDE_HIDDEN (__init_array_end = .);
  } >FLASH

  .fini_array (READONLY) :
  {
    PROVIDE_HIDDEN (__fini_array_start = .);
    KEEP (*(SORT(.fini_array.*)))
    KEEP (*(.fini_array*))
    PROVIDE_HIDDEN (__fini_array_end = .);
  } >FLASH

  /* Valores iniciales de .data: el arranque los copia de la flash a la DTCM. */
  _sidata = LOADADDR(.data);

  .data :
  {
    . = ALIGN(4);
    _sdata = .;
    *(.data)
    *(.data*)
    *(.RamFunc)
    *(.RamFunc*)
    . = ALIGN(4);
    _edata = .;
  } >DTCMRAM AT> FLASH

  .bss :
  {
    . = ALIGN(4);
    _sbss = .;
    __bss_start__ = _sbss;
    *(.bss)
    *(.bss*)
    *(COMMON)
    . = ALIGN(4);
    _ebss = .;
    __bss_end__ = _ebss;
  } >DTCMRAM

  /* Montículo y pila: solo reserva espacio para que el enlazador revise que cabe. */
  ._user_heap_stack :
  {
    . = ALIGN(8);
    PROVIDE ( end = . );
    PROVIDE ( _end = . );
    . = . + _Min_Heap_Size;
    . = . + _Min_Stack_Size;
    . = ALIGN(8);
  } >DTCMRAM

  /* ---------------------------------------------------------------- AXI SRAM
   * NOLOAD: el arranque no la borra ni la copia. Quien la use la inicializa. */
  .axisram (NOLOAD) :
  {
    . = ALIGN(32);
    *(.axisram)
    *(.axisram*)
    . = ALIGN(32);
  } >RAM_D1

  /* ---------------------------------------------------------------- D2 */
  .ram_d2 (NOLOAD) :
  {
    . = ALIGN(32);
    *(.ram_d2)
    *(.ram_d2*)
  } >RAM_D2_S1

  .lwip_heap (NOLOAD) :
  {
    . = ALIGN(32);
    *(.lwip_heap)
  } >RAM_D2_S2

  /* Descriptores DMA de Ethernet: exactamente al inicio de SRAM3, que el MPU
   * marca como memoria de dispositivo (512 B). Se aceptan los dos nombres de
   * sección que usan las distintas versiones de CubeMX. */
  .eth_descriptores (NOLOAD) :
  {
    _eth_desc_inicio = .;
    KEEP(*(.RxDecripSection))
    KEEP(*(.RxDescripSection))
    . = ALIGN(32);
    KEEP(*(.TxDecripSection))
    KEEP(*(.TxDescripSection))
    _eth_desc_fin = .;
  } >RAM_D2_S3

  /* Búferes de recepción de Ethernet (pool de pbufs de cero copia). */
  .eth_rx_pool 0x30040200 (NOLOAD) :
  {
    *(.Rx_PoolSection)
  } >RAM_D2_S3

  /DISCARD/ :
  {
    libc.a ( * )
    libm.a ( * )
    libgcc.a ( * )
  }

  .ARM.attributes 0 : { *(.ARM.attributes) }
}

/* Revisiones: si algo de esto falla, el MPU ya no cubre lo que debe. */
ASSERT(_eth_desc_inicio == 0x30040000, "Los descriptores de Ethernet deben empezar en 0x30040000")
ASSERT(_eth_desc_fin <= 0x30040200, "Los descriptores de Ethernet no caben en los 512 B de la region 4 del MPU")
ASSERT(ADDR(.lwip_heap) == 0x30020000, "El monticulo de LwIP debe empezar en 0x30020000 (region 2 del MPU)")
