/*
 * main.h — encabezado común del proyecto (equivale al que genera CubeMX).
 * Lo incluyen los archivos de Core/Src (puente_lwip.c, pantalla_stm32.c).
 */
#ifndef MAIN_H
#define MAIN_H

#include "stm32h7xx_hal.h"
#include "placa.h"

/* Error sin salida: deja la placa parpadeando el código (ver placa.h). */
void Error_Handler(void);

#endif
