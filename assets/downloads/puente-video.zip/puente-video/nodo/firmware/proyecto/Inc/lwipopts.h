/*
 * lwipopts.h — opciones de LwIP para el nodo Puente Video.
 *
 * Sin RTOS (NO_SYS = 1), API "raw" (la que usa Core/Src/puente_lwip.c).
 * Basado en el lwipopts.h de los ejemplos LwIP_TCP_Echo_Server de ST para H7.
 *
 * Memoria (ver enlazador/STM32H743xI_FLASH.ld y placa_mpu()):
 *   - Montículo de LwIP: arreglo nodo_lwip_heap[] en la sección .lwip_heap,
 *     en SRAM2 de D2 (0x30020000) y sin caché. Ahí viven los paquetes que
 *     salen (tcp_write con TCP_WRITE_FLAG_COPY, pbuf_alloc(PBUF_RAM)) y el DMA
 *     de Ethernet los lee de ahí directamente.
 *   - Los paquetes que entran usan un pool propio en SRAM3 (ethernetif.c).
 *   - Los pools "memp" normales (pcbs, segmentos, PBUF_POOL) quedan en la
 *     DTCM: solo los toca la CPU.
 */
#ifndef LWIPOPTS_H
#define LWIPOPTS_H

/* ------------------------------------------------------------ sistema */
#define NO_SYS                      1
#define SYS_LIGHTWEIGHT_PROT        0
#define LWIP_NETCONN                0
#define LWIP_SOCKET                 0
#define LWIP_IPV4                   1
#define LWIP_IPV6                   0
#define LWIP_STATS                  0

/* ------------------------------------------------------------ memoria */
#define MEM_ALIGNMENT               4
#define MEM_SIZE                    (64 * 1024)
/* El montículo es un arreglo propio con sección fija (ethernetif.c). El +64
 * cubre las dos cabeceras "struct mem" que LwIP agrega al final. */
#define NODO_LWIP_HEAP_TAM          (MEM_SIZE + 64)
extern unsigned char nodo_lwip_heap[];
#define LWIP_RAM_HEAP_POINTER       nodo_lwip_heap

#define MEMP_NUM_PBUF               16
#define MEMP_NUM_UDP_PCB            4
#define MEMP_NUM_TCP_PCB            4
#define MEMP_NUM_TCP_PCB_LISTEN     2
#define MEMP_NUM_TCP_SEG            32
#define MEMP_NUM_ARP_QUEUE          8
/* PBUF_POOL casi no se usa (la recepción va por el pool de ethernetif.c),
 * pero LwIP revisa al compilar que quepa una ventana TCP completa. */
#define PBUF_POOL_SIZE              10
#define PBUF_POOL_BUFSIZE           1536
#define LWIP_SUPPORT_CUSTOM_PBUF    1

/* ------------------------------------------------------------ interfaz */
#define LWIP_ARP                    1
#define LWIP_ETHERNET               1
#define LWIP_NETIF_LINK_CALLBACK    1
#define LWIP_NETIF_STATUS_CALLBACK  1
#define LWIP_NETIF_HOSTNAME         1
#define ETHARP_SUPPORT_STATIC_ENTRIES 0

/* ------------------------------------------------------------ IP / ICMP / DHCP */
#define LWIP_ICMP                   1
#define LWIP_DHCP                   1
/* Sin la revisión ARP de la IP que da el DHCP: así la IP llega en ~1 s y no
 * en ~3 s (el nodo cae a la IP de respaldo si en 8 s no hay DHCP). */
#define LWIP_DHCP_DOES_ACD_CHECK    0
#define LWIP_AUTOIP                 0
#define LWIP_BROADCAST_PING         1
#define IP_SOF_BROADCAST            1   /* puente_lwip.c usa SOF_BROADCAST en el anuncio UDP */
#define IP_SOF_BROADCAST_RECV       0

/* ------------------------------------------------------------ UDP / TCP */
#define LWIP_UDP                    1
#define UDP_TTL                     255
#define LWIP_TCP                    1
#define TCP_TTL                     255
#define TCP_MSS                     1460
#define TCP_WND                     (8 * TCP_MSS)
#define TCP_SND_BUF                 (4 * TCP_MSS)
#define TCP_SND_QUEUELEN            (4 * TCP_SND_BUF / TCP_MSS)
#define TCP_QUEUE_OOSEQ             1
/* Pocos pbufs fuera de orden por conexión: si no, un cuadro con pérdidas
 * podría acaparar todos los búferes de recepción del DMA. */
#define TCP_OOSEQ_MAX_PBUFS         4
#define LWIP_TCP_KEEPALIVE          1

/* ------------------------------------------------------------ checksums
 * El MAC del H7 calcula y revisa los checksums de IP, UDP y TCP. El de ICMP
 * de salida se hace por software (el hardware no lo inserta en fragmentos). */
#define CHECKSUM_GEN_IP             0
#define CHECKSUM_GEN_UDP            0
#define CHECKSUM_GEN_TCP            0
#define CHECKSUM_GEN_ICMP           1
#define CHECKSUM_CHECK_IP           0
#define CHECKSUM_CHECK_UDP          0
#define CHECKSUM_CHECK_TCP          0
#define CHECKSUM_CHECK_ICMP         0

/* ------------------------------------------------------------ depuración
 * LWIP_DEBUG no se define (LwIP lo revisa con #ifdef). Las aserciones quedan
 * activas: arch/cc.h las imprime por la consola serie y sigue. */

#endif
