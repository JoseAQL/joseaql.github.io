/*
 * placa.h — lo que cada placa (placa/nodo, placa/nucleo) le da al resto.
 *
 * El Makefile compila solo una de las dos carpetas según PLACA=nodo|nucleo.
 */
#ifndef PLACA_H
#define PLACA_H

#include <stdint.h>

/* Códigos de error fatal: el LED de error parpadea N veces, pausa, repite. */
#define PLACA_ERR_RELOJ   2u   /* no arrancó el HSE o un PLL */
#define PLACA_ERR_SDRAM   3u   /* la prueba de la SDRAM falló */
#define PLACA_ERR_ETH     4u   /* HAL_ETH_Init falló (casi siempre: no llega REF_CLK de 50 MHz) */
#define PLACA_ERR_VIDEO   5u   /* LTDC, DMA2D o JPEG no inicializaron */
#define PLACA_ERR_FALLO   6u   /* HardFault / MemManage / BusFault / UsageFault */
#define PLACA_ERR_OTRO    7u   /* Error_Handler() desde otro lado */

/* 1. Antes de HAL_Init y de encender las cachés. */
void placa_mpu(void);
/* 2. Después de HAL_Init: reguladores, PLL y relojes de periféricos. */
void placa_reloj(void);
/* 3. GPIO, consola serie y periféricos de la placa (SDRAM, LTDC, DMA2D, JPEG).
 *    Se llama con la D-caché todavía apagada (la prueba de SDRAM lo necesita). */
void placa_iniciar(void);
/* Reinicio del PHY de Ethernet (si la placa lo controla). Lo llama ethernetif.c. */
void placa_phy_reiniciar(void);
/* Tareas periódicas propias de la placa (LED extra, contadores). */
void placa_proceso(uint32_t ahora_ms);
/* Línea extra para las estadísticas de la consola (puede no escribir nada). */
void placa_imprimir_estado(void);
/* Nombre para el saludo de la consola. */
const char *placa_nombre(void);
/* Error fatal: no regresa. */
void placa_error(uint32_t codigo) __attribute__((noreturn));

/* Consola serie (printf). La placa elige el USART y sus pines. */
void consola_iniciar(void *instancia_usart);

/* ---- Ayudas comunes (Src/placa_comun.c) que usan los archivos de placa ---- */

/* Una región del MPU. tex/cache/buffer/compartida como en la tabla de DISENO §7. */
void placa_mpu_region(uint32_t numero, uint32_t base, uint32_t tamano, uint32_t tex,
                      uint32_t cache, uint32_t buffer, uint32_t compartida,
                      uint32_t acceso, uint32_t subregiones_apagadas);
/* Inicia el códec JPEG (handle global hjpeg). 0 = bien. */
int placa_jpeg_iniciar(void);
/* La pone cada placa: enciende o apaga su LED de error. */
void placa_led_error(int encendido);

#endif
