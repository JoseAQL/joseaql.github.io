/*
 * red.h — arranque y bucle de LwIP sin RTOS (lo que en CubeMX es lwip.c).
 */
#ifndef RED_H
#define RED_H

#include <stdint.h>

/* lwip_init + interfaz Ethernet + DHCP. */
void MX_LWIP_Init(void);
/* Llamar en cada vuelta del while(1): recibe paquetes, timers de LwIP y
 * revisa el enlace cada 100 ms. */
void MX_LWIP_Process(void);

int red_enlace_arriba(void);
/* IP actual en texto ("0.0.0.0" si no hay). */
const char *red_ip_texto(void);

#endif
