/*
 * ethernetif.h — interfaz entre LwIP y el MAC Ethernet del STM32H7.
 */
#ifndef ETHERNETIF_H
#define ETHERNETIF_H

#include "lwip/err.h"
#include "lwip/netif.h"
#include "stm32h7xx_hal.h"

extern ETH_HandleTypeDef heth;

err_t ethernetif_init(struct netif *netif);
/* Pasa a LwIP todos los paquetes que ya llegaron. Llamar seguido. */
void ethernetif_input(struct netif *netif);
/* Lee el enlace del PHY por MDIO y sube o baja la interfaz. */
void ethernet_link_check_state(struct netif *netif);
/* Paquetes que no se pudieron mandar (cola de DMA llena, error, etc.). */
uint32_t ethernetif_errores_tx(void);

#endif
