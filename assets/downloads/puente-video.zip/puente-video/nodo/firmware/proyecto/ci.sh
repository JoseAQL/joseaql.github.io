#!/bin/sh
# Compila el proyecto completo del nodo para las dos placas (nodo y nucleo).
# Uso: ci.sh <carpeta del gcc (la que tiene bin/)> <carpeta con los repos de ST>
# Si falta algún repo de ST en <carpeta de ST>, lo baja de GitHub.
# Termina con error si algo no compila, no enlaza o si hay advertencias en
# nuestro código (Src/, placa/ y ../Core).
set -e
GCC_DIR="$1"
ST="$2"
if [ -z "$GCC_DIR" ] || [ -z "$ST" ]; then
  echo "Uso: $0 <gcc_dir> <st_dir>"; exit 2
fi
AQUI="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ST"
for r in stm32h7xx-hal-driver cmsis-device-h7 cmsis-core stm32-mw-lwip stm32-lan8742; do
  if [ ! -d "$ST/$r" ]; then
    echo "== bajando $r"
    git clone -q --depth 1 "https://github.com/STMicroelectronics/$r.git" "$ST/$r"
  fi
done

cd "$AQUI"
for placa in nodo nucleo; do
  echo "== PLACA=$placa"
  rm -rf "build/$placa"
  make PLACA="$placa" GCC_DIR="$GCC_DIR" ST="$ST" -j4 > "build-$placa.log" 2>&1 || { cat "build-$placa.log"; exit 1; }
  # cualquier "warning:" en el registro es de nuestro código (lo de terceros va con -w)
  if grep -n "warning:" "build-$placa.log"; then
    echo "Hay advertencias en el código propio ($placa)"; exit 1
  fi
  grep -v "^CC \|^AS " "build-$placa.log"
  rm -f "build-$placa.log"
done
echo "Proyecto del nodo: las dos placas compilan y enlazan"
