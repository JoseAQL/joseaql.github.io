# Proyecto completo del firmware del nodo (STM32H743)

Proyecto con Makefile que **compila y enlaza** el firmware completo: arranque, relojes, MPU, SDRAM, LTDC, DMA2D, JPEG, Ethernet + LwIP con DHCP y el código del nodo de `../Core`. Hay dos placas:

| Comando | Placa | Qué hace |
|---|---|---|
| `make PLACA=nodo` | La placa del nodo (STM32H743IIT6, `hardware/pines.csv`) | Todo: red, JPEG, SDRAM, HDMI por LTDC → TFP410 |
| `make PLACA=nucleo` | NUCLEO‑H743ZI2 | Red + JPEG por hardware, sin pantalla: cuenta cuadros, LEDs y consola serie |

Salida en `build/<placa>/`: `puente_nodo.elf`, `.hex`, `.bin` y `.map`.

> **Nada de esto se ha probado en hardware.** Compila y enlaza sin advertencias en nuestro código; eso es todo lo verificado. Ver la lista al final.

## Carpetas

| Archivo | Qué es |
|---|---|
| `Makefile` | Compila las dos placas. Usa `../Core/Src` e `../Core/Inc` directamente (no hay copias) |
| `ci.sh` | Compila las dos placas; baja de GitHub los repos de ST que falten. Lo usa GitHub Actions |
| `Src/main.c` | Arranque y bucle: `MX_LWIP_Process()`, `puente_nodo_proceso()`, estadísticas cada 5 s |
| `Src/red.c` | `MX_LWIP_Init()` / `MX_LWIP_Process()`: LwIP sin RTOS, DHCP con nombre `nodo-<id>`, enlace cada 100 ms |
| `Src/ethernetif.c` | Controlador de red para LwIP con la API actual del HAL ETH (recepción cero copia, `HAL_ETH_Transmit` + `HAL_ETH_ReleaseTxPacket`), PHY LAN8742, MAC sacada del número de serie del chip |
| `Src/consola.c` | `printf` por el puerto serie (115200 8N1) y llamadas al sistema de newlib |
| `Src/placa_comun.c` | Regiones del MPU, códec JPEG y parpadeo de error |
| `Src/stm32h7xx_it.c` | SysTick y fallas (todo lo demás va por sondeo, sin interrupciones) |
| `Inc/lwipopts.h` | Opciones de LwIP (NO_SYS, DHCP, montículo de 64 KB en D2, checksums por hardware) |
| `Inc/stm32h7xx_hal_conf.h` | Plantilla de ST con solo los módulos que se usan |
| `placa/nodo/` | Relojes, pines, SDRAM, LTDC, DMA2D, Ethernet y MPU de la placa propia; `placa_ltdc.h` con los tiempos por resolución |
| `placa/nucleo/` | Relojes, pines y LEDs de la Nucleo; `pantalla_nucleo.c` decodifica sin mostrar |
| `arranque/` | `startup_stm32h743xx.s` y `system_stm32h7xx.c` de ST (cmsis-device-h7 v1.10.8, licencia en `LICENCIA_ST.md`) |
| `enlazador/STM32H743xI_FLASH.ld` | Script del enlazador (sirve para IIT6 y ZIT6: 2 MB de flash) |

Cambios hechos en `../Core` para esto (el API de antes no cambió):

- `nodo_placa.h`: rama `NODO_PLACA_NUCLEO` (búferes en AXI SRAM, ID fijo 1, sin DIP).
- `puente_lwip.h` nuevo: declara `puente_nodo_iniciar/proceso` y tres funciones de solo lectura para la consola. `puente_lwip.c`: si `tcp_listen` fallaba se perdía el pcb; ya se cierra.
- `pantalla.h` / `pantalla_stm32.c`: contadores (`pantalla_estadisticas()`).

## Mapa de memoria y MPU

| Zona | Dirección | Qué hay | MPU |
|---|---|---|---|
| Flash | 0x08000000 | Código (~80 KB) | — |
| DTCM | 0x20000000 | `.data`, `.bss`, pila 16 KB, pools de LwIP (solo CPU) | — |
| AXI SRAM | 0x24000000 | Nucleo: 2 JPEG de 192 KB + YCbCr de 32 KB. Nodo: libre | por defecto |
| SRAM2 D2 | 0x30020000 | Montículo de LwIP (64 KB): paquetes que salen | región 2, sin caché |
| SRAM3 D2 | 0x30040000 | Descriptores DMA: RX 8 × 24 B en 0x30040000, TX 4 × 24 B en 0x300400C0 | región 4, dispositivo, **512 B** |
| SRAM3 D2 | 0x30040200 | 16 búferes de recepción de 1536 B (~25 KB) | región 3, sin caché |
| SDRAM | 0xD0000000 | FB0, FB1, YCbCr, JPEG0, JPEG1 (solo nodo) | región 1, write‑through |
| — | 0x60000000‑0xDFFFFFFF | Fondo sin acceso (evita lecturas especulativas) | región 0 |

Diferencia con `hardware/DISENO.md` §7: como hay 8 descriptores de recepción (no 4), los de transmisión quedan en 0x300400C0 y la región 4 mide 512 B. El script del enlazador tiene `ASSERT` que fallan si los descriptores no quedan en 0x30040000 o no caben.

## Compilar con make

Necesitas `arm-none-eabi-gcc` (probado con xPack 13.3.1) y estos repos de GitHub de STMicroelectronics en una misma carpeta: `stm32h7xx-hal-driver`, `cmsis-device-h7`, `cmsis-core`, `stm32-mw-lwip`, `stm32-lan8742`. `ci.sh` los baja solo:

```sh
./ci.sh /ruta/al/gcc /ruta/a/st          # baja lo que falte y compila las dos placas
make PLACA=nucleo GCC_DIR=/ruta/al/gcc ST=/ruta/a/st
make PLACA=nodo   GCC_DIR=/ruta/al/gcc ST=/ruta/a/st
make PLACA=nodo CPU_MHZ=400 ...           # arranque a 400 MHz (recomendado por DISENO §4.2 para la primera prueba)
make PLACA=nodo OPT="-O2 -DNODO_ANCHO=1024 -DNODO_ALTO=600" ...   # otra resolución (ver placa/nodo/placa_ltdc.h)
```

Si en lugar de los repos usas el paquete `STM32Cube_FW_H7` (el que baja CubeIDE), pasa las rutas una por una:
`HAL_DIR=.../Drivers/STM32H7xx_HAL_Driver CMSIS_DEV_DIR=.../Drivers/CMSIS/Device/ST/STM32H7xx CMSIS_CORE_DIR=.../Drivers/CMSIS LWIP_DIR=.../Middlewares/Third_Party/LwIP LAN8742_DIR=.../Drivers/BSP/Components/lan8742`. (No lo probé con el paquete; con los repos sí.)

## Importar en STM32CubeIDE

1. **File → Import → C/C++ → Existing Code as Makefile Project**. Carpeta: esta (`proyecto`). Toolchain: *MCU ARM GCC* (o *ARM Cross GCC*).
2. Clic derecho al proyecto → **Properties → C/C++ Build**: en *Build command* pon
   `make PLACA=nucleo ST=C:/ruta/a/st GCC_DIR=` (vacío = usa el gcc del PATH de CubeIDE). Para la placa del nodo, `PLACA=nodo`.
   En Windows `make` viene con CubeIDE; si no lo encuentra, agrega su carpeta `.../plugins/...make.../tools/bin` al PATH en *Environment*.
3. **Project → Build Project**.
4. Depurar: **Run → Debug Configurations → STM32 C/C++ Application** (o *GDB OpenOCD Debugging*). *C/C++ Application*: `build/nucleo/puente_nodo.elf`. En *Debugger*: ST‑LINK (ST‑LINK GDB server u OpenOCD), interfaz SWD. Si pide el chip: `STM32H743ZITx` (Nucleo) o `STM32H743IITx` (nodo). Como no es un proyecto de CubeMX, CubeIDE no conoce el .ioc: eso es normal.

Sin CubeIDE también se puede grabar:

```sh
STM32_Programmer_CLI -c port=SWD -w build/nucleo/puente_nodo.hex -v -rst
# o con OpenOCD
openocd -f interface/stlink.cfg -f target/stm32h7x.cfg -c "program build/nucleo/puente_nodo.elf verify reset exit"
```

O copia `puente_nodo.bin` a la unidad USB que aparece al conectar la Nucleo (el ST‑Link la graba solo).

## Prueba en la NUCLEO‑H743ZI2

1. Graba `build/nucleo/puente_nodo.hex`. Conecta el cable de red de la Nucleo al mismo switch/router que la PC (o directo a la PC).
2. Abre el puerto COM del ST‑Link (115200 8N1). Debe salir algo así:
   ```
   === Puente Video: nodo NUCLEO-H743ZI2 (prueba sin pantalla), 800x600, CPU 400 MHz ===
   ETH: PHY en la direccion 0, MAC 02:50:xx:xx:xx:xx
   ETH: enlace arriba, 100 Mbit/s, full duplex
   RED: IP 192.168.1.57 (DHCP)          ← o 192.168.77.101 (fija) si no hay DHCP en 8 s
   [   10 s] enlace=si ip=... cliente=no | llegaron=0 descartados=0 | mostrados=0 errores=0 ...
   ```
3. LEDs:

   | LED | Qué significa |
   |---|---|
   | Arranque | Verde, amarillo y rojo se encienden en orden una vez |
   | LD1 verde | Parpadeo lento (0.5 s): sin cliente. Medio (0.25 s): cliente conectado sin video. Rápido (80 ms): recibiendo video |
   | LD2 amarillo | Cambia con cada cuadro decodificado bien (con video se ve medio encendido). Parpadeo muy rápido 3 s = llegó `IDENTIFICAR` |
   | LD3 rojo | Fijo: sin cable de red / sin enlace. Destello corto: un JPEG falló |
   | LD3 rojo con N parpadeos y pausa, repetido | Error fatal: 2 reloj, 4 Ethernet (no hay 50 MHz de REF_CLK), 5 JPEG, 6 falla del procesador (HardFault), 7 otro |

4. En la PC abre Puente Video → **Pantallas HDMI (nodos)…**. La Nucleo debe aparecer sola como nodo 1 (800x600) por el anuncio UDP. Si no aparece (otra subred, firewall), usa **Agregar por IP** con la IP que dio la consola. Elige cámara o patrón de prueba.
5. En la consola, cada 5 s: `llegaron` y `mostrados` deben subir parejo; `ultimo=800x600 en N ms` es lo que tarda el JPEG por hardware. `errores` debe quedarse en 0. `descartados` sube si llegan cuadros más rápido de lo que se decodifican (normal) o si un JPEG pesa más de 192 KB (baja la calidad en la PC).
6. **Identificar** desde la PC: la consola imprime `IDENTIFICAR: nodo 1` y LD2 parpadea rápido.
7. Desde el celular: en la app escribe la IP de la Nucleo.

Qué comprueba esta prueba: arranque, relojes, MPU, Ethernet RMII + LwIP + DHCP, el protocolo con la PC y el celular, y que el códec JPEG del H743 acepta los cuadros y entrega todos los bytes YCbCr esperados. Qué no comprueba: SDRAM, DMA2D, LTDC, HDMI.

## Placa del nodo

Lo mismo, con la consola en USART1 (PB14 TX / PB15 RX, J5) y estos LEDs: PB0 de estado (mismos patrones que LD1), PB1 auxiliar (encendido = sin enlace; N parpadeos = error fatal, 3 = SDRAM). Al arrancar prueba la SDRAM (líneas de datos, 64 KB de patrón y líneas de dirección hasta 16 MB) e imprime el resultado. Cada 5 s imprime además los *underrun* del LTDC (si suben, la SDRAM no alcanza: DISENO §6) y si hay monitor (HPD, MSEN).

## Lo que NO está verificado en hardware

Todo lo que sigue solo se compiló; nada se ha corrido en un chip:

- **Arranque en general**: vectores, `SystemInit`, MPU, cachés, relojes. El VOS0 / 480 MHz necesita silicio revisión V; si el chip es revisión Y, usar `CPU_MHZ=400`.
- **Ethernet**: secuencia de `HAL_ETH_Init`, recepción cero copia, liberación de descriptores de transmisión, MPU de D2, sondeo del enlace. Es lo primero que hay que probar en la Nucleo. Síntoma típico de un error de MPU/caché: el ping funciona unos segundos y se corta.
- **Rendimiento**: cuántos fps aguanta la red con descriptores de 8 RX / 16 búferes y ventana TCP de 8 × 1460. No medido.
- **JPEG en la Nucleo**: la cuenta de bytes YCbCr esperados se hizo con las reglas de MCU del estándar; no se ha visto en un chip.
- **Placa del nodo, todo**: la placa no existe. En particular: tiempos de la SDRAM y registro de modo, `ReadPipeDelay`, polaridades del LTDC (`DEPolarity`, `PCPolarity`), reloj de píxel con referencia de 1 MHz, reinicio del LAN8742A por PD7 y la espera de 10 ms para el REF_CLK, AF de cada pin (vienen de `pines.csv`, que sí se revisó contra la base de datos de ST).
- **DMA2D con YCbCr en bloques MCU → RGB565** (`pantalla_stm32.c`): sigue el flujo de los ejemplos de ST, sin probar.
- **Importar en STM32CubeIDE y depurar**: los pasos de arriba son los normales para un proyecto Makefile; no los ejecuté.
- **Paquete STM32Cube_FW_H7** en lugar de los repos de GitHub: las rutas de arriba son las del paquete, no lo probé.
