# Plan de trabajo por etapas: terminar la parte electrónica del nodo

Documento de trabajo para José Antonio Quiroz Luna. Cubre las tres variantes de nodo que viven en esta
carpeta (`firmware/` + `hardware/` para el STM32H743, `pico/` para la Raspberry Pi Pico 2 y `linux/` para
la Raspberry Pi 4B / Orange Pi Zero 2W) y las ordena de modo que cada etapa se apoye en algo ya
comprobado y no en suposiciones.

La idea de fondo es simple: **hoy no hay un solo nodo que haya mostrado una imagen en una pantalla real**.
Todo lo que existe compila, pasa validaciones hechas por programa y está bien documentado, pero el
proyecto no ha tocado silicio. El plan está armado para cambiar eso lo más pronto posible y con el menor
gasto, porque cada prueba en hardware real invalida o confirma de golpe decenas de suposiciones que de
otra forma se seguirían arrastrando en papel.

---

## 1. Diagnóstico: en qué estado está realmente cada variante

### 1.1 Lo que sí está sólido (y es bastante)

El núcleo del protocolo (`firmware/Core/Src/puente_nodo.c`) es el mismo código en las tres variantes y en
el simulador. El simulador ya corrió de verdad: según `nodo/README.md`, dos nodos simulados a 30 fps cada
uno, y el lado de la PC (`pc/nodos.py`, consola de pantallas, pared de video, identificar) se probó contra
él. Eso significa que el protocolo, los acuses, el anuncio UDP y la consola de la PC no son el riesgo del
proyecto. El riesgo está, completo, del lado del hardware y de los periféricos.

También está sólido el trabajo de pines del H743: `hardware/pines.csv` tiene los 176 pines del LQFP176 y,
según la sección 0 de `hardware/DISENO.md`, se revisó con un script contra la base de datos abierta de
pines de ST (la misma que usa CubeMX), sin pines repetidos y con todas las funciones alternas existentes.
Quedan 40 pines libres. Ese es el trabajo más delicado del diseño y está hecho con método, no de memoria.

### 1.2 Variante STM32H743 (placa propia)

**Estado real: diseño completo en papel, firmware que enlaza, cero hardware.**

El firmware de `firmware/proyecto/` compila y enlaza para las dos placas (`make PLACA=nodo` y
`PLACA=nucleo`) y los binarios están en `build/nodo/` y `build/nucleo/`. Lo que dice `PROYECTO.md` sobre lo
no verificado es largo y honesto: arranque, vectores, MPU, cachés, relojes, la secuencia de
`HAL_ETH_Init`, la recepción cero copia, los tiempos de la SDRAM, el registro de modo, `ReadPipeDelay`,
las polaridades del LTDC y el DMA2D con bloques MCU → RGB565. Nada de eso ha corrido en un chip.

`hardware/DISENO.md` es un documento serio de 454 líneas, pero trae **35 marcas VERIFICAR** y
`hardware/conexiones.md` otras **24**. Casi todas son números de pin, códigos LCSC, tiempos de SDRAM y
anchos de pista escritos de memoria, sin la hoja de datos a la mano. El propio documento lo declara en su
sección 0, lo cual está bien, pero significa que **el esquemático todavía no se puede capturar con
confianza**: si se captura ahora, se capturan también esos errores.

Y hay tres hallazgos del diseño que ya cambian el alcance, no solo el detalle:

1. 1024x600 no es un modo estándar de HDMI; muchas teles y monitores lo rechazan.
2. 720p60 no cabe en una SDRAM de 16 bits con la arquitectura actual: solo el LTDC consume ~111 MB/s de
   los ~120-150 MB/s aprovechables.
3. En LQFP176 la SDRAM *tiene* que ser de 16 bits, porque los datos D16-D31 del FMC caen justo en los
   pines del LTDC de 24 bits. No hay forma de duplicar el ancho de banda sin pasar a BGA.

La consecuencia práctica, según la sección 6 de `DISENO.md`, es que **con el firmware actual esta placa
daría unos 12-15 fps a 1024x600**, y para llegar a 30 fps hace falta el cambio de decodificar por franjas
con el YCbCr en SRAM interna, que está descrito pero no escrito.

Las librerías de KiCad del H743 (`hardware/kicad/`) están en mejor forma de lo que uno esperaría: 3
símbolos propios, 5 huellas copiadas de las oficiales y 5 modelos STEP, con 121 comprobaciones
automáticas y 0 fallas en `validacion.txt`. Pero están en **formato de KiCad 8** y su propia sección 0 lo
dice sin adornos: nunca se abrieron en KiCad. Y aquí no hay esquemático ni PCB: solo la netlist en texto.

### 1.3 Variante Pico 2 + W5500 + DVI

**Estado real: la más cercana a funcionar, y la única que se puede probar sin soldar nada.**

El firmware compila sin advertencias y genera `pico/build/puente_nodo_pico.uf2`, que ya está en el
repositorio y en Releases. El dibujo (JPEG → RGB332 con tramado y la pantalla del número) se probó en la
PC con exactamente el mismo código C, comparando contra OpenCV. La cuenta de memoria está hecha al byte:
489 032 de 524 288 bytes de SRAM.

Lo que falta es todo lo eléctrico, y `PICO.md` lo lista honestamente: que la pantalla acepte la señal DVI
(orden de pares, polaridad, 60 Hz con el reloj de 126 MHz tomado del PLL de USB), que los colores caigan
en su lugar, que el W5500 aguante 25 MHz con cables dupont, el DHCP de la ioLibrary, los tiempos reales de
decodificación y que la pila de 2 KB del núcleo 1 alcance.

La ventaja decisiva es que **esta variante se arma en protoboard con cables dupont**, cuesta del orden de
$400 a $750 pesos y se graba arrastrando un archivo. No necesita KiCad, no necesita CubeIDE, no necesita
soldar paso de 0.5 mm y no necesita que nada esté fabricado.

La placa base (`pico/kicad/`) es un proyecto de KiCad completo: esquemático de una hoja, PCB de 80 × 70 mm
con todas las huellas colocadas y los 8 pares TMDS ya trazados, 18 comprobaciones automáticas y 0 fallas.
Tampoco se ha abierto nunca en KiCad, y su propia sección 7 pone como riesgo número 2 el pinout del módulo
W5500: si la serigrafía del módulo real está en espejo, el módulo recibe 3.3 V donde no debe.

### 1.4 Variante Linux (Raspberry Pi 4B / Orange Pi Zero 2W)

**Estado real: la única donde el software ya corrió de verdad, y la única que no requiere comprar nada
si ya tienes la Pi 4B.**

Son 250 líneas de Python con pygame más un instalador. `LINUX.md` dice que se probó sin pantalla: la PC
manda a 30 fps, el nodo contesta acuses y la identificación funciona. Lo que falta es correrlo en una placa
real con un monitor conectado, medir los fps verdaderos y comprobar el modo sin escritorio (KMS/DRM).

No hay diseño electrónico que hacer aquí: la Pi ya trae Ethernet y HDMI. Por eso esta variante no es
"la parte electrónica del proyecto", pero sí es el banco de pruebas más barato que existe para todo lo
demás.

### 1.5 Resumen en una tabla

| Variante | Software | Hardware | Lo que falta de verdad |
|---|---|---|---|
| Linux (Pi 4B) | Corrió a 30 fps sin pantalla | La Pi ya existe | Correrlo con monitor y medir fps |
| Pico 2 | Compila, dibujo probado en PC | Nada armado | Comprar ~$500, armar en protoboard, probar DVI y W5500 |
| STM32H743 | Compila y enlaza, nada corrido | No existe la placa | 59 marcas VERIFICAR, esquemático, PCB, 4 capas, ensamble |

---

## 2. Lo que se puede hacer sin tu PC y lo que obliga a tu PC

Esta separación es la que decide cómo gastar los créditos de IA y el espacio de disco, así que conviene
tenerla clara antes de empezar.

### 2.1 Se puede hacer en el contenedor, sin tocar tu laptop

- **Compilar los dos firmwares.** GitHub es alcanzable desde el contenedor (probado), así que `ci.sh` puede
  bajar el toolchain `arm-none-eabi-gcc` de xPack, el Pico SDK 2.3.1, la ioLibrary de WIZnet y los cinco
  repos de ST, y compilar. Tú solo bajas el `.uf2` o el `.hex` del resultado o de Releases. **Esto es
  importante: no necesitas WSL ni un compilador instalado en tu laptop para avanzar.**
- **Cambios de firmware y de configuración** (`placa_pico.h`, resoluciones, `PP_SPI_HZ`, modos del LTDC,
  decodificación por franjas), con la garantía de que siga compilando sin advertencias.
- **Regenerar y validar las librerías y la placa del Pico** con `kiutils` y los scripts de
  `herramientas/`: `validar.py` (121 comprobaciones) y `validar_carrier.py` (18 comprobaciones) corren aquí.
- **Revisar hojas de datos y cerrar las marcas VERIFICAR**, actualizando `DISENO.md` y `conexiones.md`.
- Documentación, cálculos de relojes y tiempos, listas de compras, cualquier cosa de texto.

### 2.2 Obliga a tener KiCad 10 abierto en tu laptop

**KiCad no se puede instalar en el contenedor.** Lo comprobé: no existe el paquete en apt y el repositorio
de Flathub está bloqueado por el proxy (responde 403). No hay `kicad-cli` disponible de ningún otro modo.
Por lo tanto, todo esto solo puedes hacerlo tú:

- Abrir los archivos y aceptar la conversión de formato (están en formato de KiCad 8; al guardarlos, KiCad
  10 los pasa a su formato y ya no abren en el 8).
- **ERC y DRC reales.** Las validaciones por programa de este repositorio son útiles, pero sus propios
  documentos lo dicen: no sustituyen al ERC ni al DRC de KiCad.
- Confirmar que los símbolos y huellas oficiales que usa el diseño siguen llamándose igual en las
  librerías de KiCad 10 (`Video:TFP410PAP`, `Interface_Ethernet:LAN8742A`, `MCU_ST_STM32H7:STM32H743IITx`,
  `Memory_RAM:MT48LC16M16A2P`, `Connector:HDMI_A`, etc.). Todo se validó contra las oficiales **8.0.8**;
  entre versiones a veces se renombran o se mueven de librería.
- Ver los modelos 3D. Las huellas oficiales apuntan a `${KICAD8_3DMODEL_DIR}`, que en KiCad 10 ya no
  existe con ese nombre.
- Rutear, rellenar planos, generar gerbers y taladros, subirlos a JLCPCB.

Dos trucos para que esto te cueste poco:

1. **`kicad-cli` viene con KiCad 10.** Desde PowerShell puedes correr `kicad-cli sch erc` y
   `kicad-cli pcb drc` con salida a un archivo de reporte, y pegarme el reporte. Eso es muchísimo más
   barato en créditos que describirme a mano lo que ves en pantalla.
2. **Cópiame las librerías oficiales de KiCad 10.** Las carpetas `symbols\` y `footprints\` de la
   instalación (del orden de 100-200 MB, sin los modelos 3D, que pesan cientos de MB y no hacen falta)
   se pueden comprimir y subir una sola vez. Con ellas, `validar.py` y `validar_carrier.py` pueden
   revisar el diseño contra las librerías de **tu** KiCad desde el contenedor, sin que tú abras nada.

### 2.3 Obliga a tener hardware en la mano

Grabar, medir con multímetro u osciloscopio, conectar una pantalla, soldar. Nada de esto se delega.

### 2.4 STM32CubeIDE: la buena noticia

**No necesitas STM32CubeIDE para este proyecto.** `firmware/proyecto/` es un proyecto con Makefile, no un
proyecto de CubeMX; no hay archivo `.ioc` que importar. `PROYECTO.md` ya documenta que se puede grabar con
`STM32_Programmer_CLI`, con OpenOCD, o **copiando `puente_nodo.bin` a la unidad USB que aparece al conectar
la Nucleo**, que es lo más simple que existe.

Esto importa por tu disco C:, que tiene menos de 17 GB libres. Las cifras de abajo son aproximadas y hay
que confirmarlas con el instalador de cada programa, pero el orden de magnitud manda:

| Herramienta | Espacio aproximado | ¿Hace falta? |
|---|---|---|
| KiCad 10 | 2 a 3 GB | **Sí, obligatorio** para esquemático, PCB, ERC, DRC y gerbers |
| STM32CubeProgrammer | menos de 1 GB | Útil para grabar y leer el chip; con la Nucleo puedes evitarlo al inicio |
| STM32CubeIDE + paquete STM32Cube_FW_H7 | 5 a 10 GB o más | **No**, al menos hasta que necesites depurar paso a paso |
| WSL + Ubuntu + toolchains | 3 a 6 GB | **No**, si compilas en el contenedor o en GitHub Actions |

Instala KiCad 10 **en el disco D:**, no en C:. El instalador de Windows permite cambiar la carpeta de
destino. Si algún día necesitas depurar con breakpoints y tienes que instalar CubeIDE, instálalo también
en D: y apunta su espacio de trabajo ahí. Y antes de instalar cualquier cosa, deja al menos 10 GB libres
en C: de todas formas: Windows necesita margen para actualizaciones y archivo de paginación.

---

## 3. Las etapas

Cada etapa dice qué se hace, por qué va en ese lugar, si necesita tu laptop, cuánto trabajo es más o menos
y cómo sabes que quedó bien. Las etapas 1 a 5 son la ruta corta (nodo Pico, barato y rápido); las 6 a 9 son
la ruta larga (nodo STM32H743, que es el proyecto bonito de ingeniería pero también el caro).

---

### Etapa 1 — Probar el nodo Linux en la Raspberry Pi 4B que ya tienes

**Qué se hace.** Grabar una microSD aparte (no la del proyecto del checador de huellas, para no tocar nada
de eso) con Raspberry Pi OS, copiar `nodo/linux/`, correr `sudo sh instalar.sh 1`, conectar la Pi a un
monitor por micro-HDMI y a la PC o a un switch por Ethernet. Desde `PuenteVideo.exe` abrir **Pantallas HDMI
(nodos)…** y comprobar que el nodo aparece solo, que el patrón de prueba se ve, que **Identificar**
funciona y que llega video. Medir los fps que reporta y probar también desde el celular escribiendo la IP
del nodo. Después repetir en el modo sin escritorio (la imagen Lite, que dibuja directo sobre KMS/DRM),
que es el que `LINUX.md` marca como no probado.

**Por qué va primero.** Porque es lo único que puedes probar hoy, sin comprar ni instalar nada, y porque
valida de un golpe la mitad del proyecto que aún no se ha visto en hardware: el anuncio UDP en una red
real, el protocolo con acuses sobre Ethernet de verdad, la consola de pantallas de la PC contra un nodo
que no es el simulador, el firewall de Windows y la salida HDMI. Si algo de eso está mal, lo quieres
descubrir ahora y no cuando tengas una placa de cuatro capas en la mano.

**¿Necesita tu PC?** Sí, pero **solo como fuente de video**: corres `PuenteVideo.exe` y nada más. No se
instala ninguna herramienta de ingeniería.

**Trabajo.** Una tarde, contando el grabado de la microSD.

**Criterio de terminado.** El nodo aparece solo en la consola de pantallas de la PC; el patrón de prueba,
la pantalla completa y un pedazo para pared de video se ven en el monitor; **Identificar** pone el número;
desde el celular también llega video; y tienes escrito en algún lado el número de fps real a 720p y a
1080p. El modo sin escritorio también da imagen (o quedó documentado que en tu imagen hay que usar la de
escritorio).

---

### Etapa 2 — Abrir en KiCad 10 todo lo que existe, sin diseñar nada todavía

**Qué se hace.** Instalar KiCad 10 en el disco D:. Luego, sin dibujar ni rutear nada:

1. Librerías del H743 (`hardware/kicad/`): seguir la opción A de la sección 6 de `LIBRERIAS.md` (proyecto
   nuevo dentro de esa misma carpeta, sin crear subcarpeta, para que `${KIPRJMOD}` apunte bien), abrir los
   3 símbolos propios, cambiar entre las 10 unidades de `STM32H743IITx_Nodo`, abrir las 5 huellas propias y
   ver el 3D con Alt+3.
2. Comprobar que los 20 símbolos y huellas **oficiales** de la tabla de la sección 2 de `LIBRERIAS.md`
   existen con ese mismo nombre en las librerías de KiCad 10.
3. Placa del Pico (`pico/kicad/puente_pico.kicad_pro`): abrir, aceptar la conversión de formato, correr
   **ERC**, correr **Actualizar PCB desde el esquemático (F8)** y **verificar que no proponga ningún cambio
   de redes ni de huellas**, rellenar los planos con **B** y correr **DRC**.
4. Copiarme las carpetas `symbols\` y `footprints\` de KiCad 10 comprimidas, y el reporte de `kicad-cli`.

**Por qué va aquí.** Porque es la suposición más grande que sostiene todo el trabajo de hardware hecho
hasta ahora, cuesta una sola tarde y no requiere comprar nada. Si los archivos no abren bien o si los
nombres de las librerías oficiales cambiaron en KiCad 10, hay que arreglar los generadores de
`herramientas/` **antes** de capturar un esquemático de 37 componentes o de rutear cuatro capas. Y si F8
propone cambios de redes, eso significa que KiCad interpreta el esquemático distinto a como lo interpretó
el validador, que es exactamente la clase de error que no se ve hasta que se fabrica.

**¿Necesita tu PC?** **Sí, obligatorio.** Es la etapa que no se puede delegar de ninguna forma.

**Trabajo.** Dos a tres horas, más la descarga e instalación de KiCad.

**Criterio de terminado.** Los 3 símbolos y las 5 huellas propias abren sin errores y el modelo 3D se ve
sentado sobre los pads. Ningún símbolo ni huella oficial de la tabla aparece como "no encontrado". El
proyecto `puente_pico` abre, el ERC sale con 0 errores (las advertencias de "el símbolo no coincide con el
de la librería" son esperadas y se ignoran o se resuelven con *Actualizar símbolos desde la librería*), F8
no cambia redes, y el DRC corre y te da una lista concreta de lo que falta por trazar. Si algo falla,
el criterio de terminado es tener la lista exacta de lo que falló, no haberlo arreglado.

---

### Etapa 3 — Armar y probar el nodo Pico 2 en protoboard

**Qué se hace.** Comprar las partes de la lista de `PICO.md`: Raspberry Pi Pico 2 normal, módulo W5500 de
10 pines, salida DVI (el **Pico DVI Sock** si lo consigues, que ya trae las 8 resistencias de 270 Ω, o un
conector HDMI hembra con las 8 resistencias a mano), DIP de 4 posiciones, cables dupont cortos y un
adaptador USB-serial de 3.3 V para ver la consola. Cablear tal cual la tabla de conexiones de `PICO.md`,
con los cables de SPI lo más cortos posible. Grabar `puente_nodo_pico.uf2` (el que ya está en Releases o
en `pico/build/`) con BOOTSEL. Comprobar la secuencia que describe la sección "Qué debe pasar": número con
marco ámbar, DHCP o IP de respaldo en 8 s, anuncio UDP cada segundo, marco cian al conectarse la PC,
video, regreso a la pantalla del número a los 3 s sin video, e `IDENTIFICAR`. Leer el reporte de la UART
cada 5 s y anotar `cuadros/s`, `decodificar`, `descartados`, `errores` y `dvi`.

**Por qué va aquí.** Es la primera vez que el proyecto va a sacar video de un microcontrolador, y se hace
con el riesgo más bajo posible: sin soldar nada fino, sin fabricar, y con un firmware que ya compila. Si el
DVI del HSTX no sale, o los colores están cruzados, o el W5500 no contesta, lo descubres con cables que
puedes mover, no con una placa hecha. Y va **después** de la etapa 2 porque el ERC/DRC de la etapa 2 te
dice si la placa base tiene algún error de redes que convenga arreglar antes de confiar en el cableado.

**¿Necesita tu PC?** Solo para grabar por USB, correr `PuenteVideo.exe` y ver la consola serie. No se
instala ninguna herramienta de ingeniería.

**Trabajo.** La compra y la espera del envío (de días a semanas, según de dónde venga), más una tarde de
cableado y una de pruebas.

**Criterio de terminado.** El monitor muestra la pantalla del número con el marco del color correcto, con
los colores en su lugar (rojo donde va rojo). El nodo aparece solo en la consola de pantallas de la PC como
640x480, el patrón de prueba se ve, **Identificar** funciona y llega video de la PC y del celular. En la
UART tienes medidos los cuadros por segundo reales y el tiempo de decodificación, con `errores` en 0. Si
`descartados` sube, está anotado por qué (JPEG de más de 80 KB) y con qué calidad deja de pasar.

---

### Etapa 4 — Ajustar el firmware del Pico con los números medidos

**Qué se hace.** Con los datos de la etapa 3 en la mano, tocar lo que haga falta y recompilar en el
contenedor o en GitHub Actions: bajar `PP_SPI_HZ` a 12.5 MHz si el W5500 falla con dupont; bajar la calidad
JPEG para nodos en `pc/nodos.py` si se descartan cuadros; probar `-DPP_RELOJ_KHZ=250000` si los fps no
alcanzan; corregir `carril_a_bit` o el par de reloj en `src/dvi_hstx.c` si el orden de pares o la polaridad
salieron mal; subir las funciones calientes de TJpgDec a RAM si la caché de flash es el cuello de botella.
Y, si los 4-8 fps estimados resultan insoportables, implementar el modo 320x240 con doble búfer que
`PICO.md` deja apuntado como idea. Al final, actualizar `PICO.md` sustituyendo cada estimación por el número
medido y tachando las casillas de "Lo que NO está verificado en hardware".

**Por qué va aquí.** Porque ahora sí hay con qué medir, y porque es trabajo que no toca tu laptop ni tu
disco: compila en el contenedor y tú solo arrastras el `.uf2` nuevo. Es la etapa más eficiente en créditos
de todo el plan, porque cada cambio se decide con un número real en vez de con una discusión.

**¿Necesita tu PC?** No para el trabajo. Sí para grabar el `.uf2` y volver a medir.

**Trabajo.** Una o dos sesiones, más iteraciones cortas de grabar y medir.

**Criterio de terminado.** `PICO.md` ya no contiene estimaciones donde pueda haber mediciones, la lista de
"no verificado en hardware" quedó vacía o con las casillas que faltan claramente marcadas, y el firmware
sigue compilando sin advertencias.

---

### Etapa 5 — Terminar y fabricar la placa base del Pico

**Qué se hace.** En KiCad 10, seguir el paso a paso de la sección 9 de `pico/kicad/CARRIER.md`: revisar la
colocación contra las piezas reales, **medir tu módulo W5500 y comparar su serigrafía pin por pin con la
tabla de la sección 3** (si está en espejo, hay que intercambiar las redes de J2), rellenar tierra con
**B**, trazar las redes que faltan con los anchos de la sección 6 (alimentación 0.6 mm, SPI 0.25 mm, el
resto 0.25 mm) cuidando el plano continuo abajo de las TMDS, correr DRC hasta 0 errores y 0 redes sin
conectar, revisar la vista 3D, generar gerbers y taladros con las opciones de la sección 9, y subir el zip
a JLCPCB. Luego soldar en el orden de la sección 11: HDMI primero, USB-C, pasivos, y al final lo pasante;
y **antes de enchufar la Pico y el módulo, meter 5 V por la bornera y medir**: 5 V en `+5V`, ~4.7 V en el
pin 39 del zócalo y en el pin 18 del HDMI, y que no haya corto entre 3V3 y GND.

**Por qué va aquí y no antes.** La propia sección 7.10 de `CARRIER.md` lo recomienda así: armar primero en
protoboard, confirmar que hay video y red, y hasta entonces mandar a hacer la placa. Fabricar antes de la
etapa 3 sería pagar por una placa que podría tener el pinout del W5500 en espejo o un orden de pares TMDS
equivocado.

**¿Necesita tu PC?** **Sí, obligatorio** para el ruteo, el DRC y los gerbers. Ojo con una trampa que el
propio documento señala: **una vez que empieces a trazar en KiCad ya no regeneres con `gen_carrier.py`**,
porque sobrescribe el `.kicad_sch` y el `.kicad_pcb` y se pierde todo el ruteo hecho a mano.

**Trabajo.** Dos o tres sesiones de ruteo y DRC, más la espera de fabricación (una a tres semanas con
JLCPCB a México) y una tarde de soldadura.

**Criterio de terminado.** DRC con 0 errores y 0 redes sin conectar; gerbers subidos y la vista previa de
JLCPCB se ve como esperas; y, con la placa en la mano, los tres voltajes medidos antes de enchufar nada, y
después el nodo funcionando igual que en protoboard pero sin cables.

---

### Etapa 6 — Cerrar las 59 marcas VERIFICAR del nodo H743

> **Estado: puntos 1 a 4 hechos** (noviembre de 2026). Son los cuatro que bloqueaban el esquemático.
> El registro completo está en la sección 11 de `hardware/DISENO.md`. Resumen de lo que salió:
>
> - Se corrigieron **cuatro errores reales**: `ExitSelfRefreshDelay` de la SDRAM (7 → 8 ciclos, por tXSR
>   de 72 ns y no 70), el pin RESERVED del TFP410 que estaba quedando al aire y debe ir a `GND`, el
>   *pull‑up* de MSEN (10 kΩ → 5 kΩ) y una resistencia de 500 Ω que falta en serie con XTAL2 del PHY.
> - Salió **un cambio de diseño**: los dos LED del RJ45 ya no los puede manejar el PHY, porque sus pines
>   son los straps nINTSEL y REGOFF y la hoja de datos pide no colgarles un LED. Pasan a dos GPIO del
>   H743 (quedan 40 libres).
> - Salió **un conflicto en el símbolo propio del TPD12S016**: D0 y D2 están al revés respecto a la tabla
>   de la hoja de datos. Ver el recuadro de la sección 3.1 de `hardware/kicad/LIBRERIAS.md`.
> - Se confirmó tal cual estaba: los pines TMDS del TPD12S016 (lo que bloqueaba el ruteo), los 22 números
>   de pin del LAN8742A, el orden rojo/verde/azul del TFP410, los straps, y la organización y el refresco
>   de la SDRAM.
>
> **Quedan los puntos 5 a 8** (DS12110, conectores, códigos LCSC y existencias, anchos de pista), que el
> propio plan deja para cuando ya se vaya a comprar.
>
> **Dos cosas no se pudieron cerrar aquí y te tocan a ti, con el PDF del TPD12S016 y del TFP410 abiertos
> (son cinco minutos en total):** el reparto D0/D2 de arriba, y la cota del pad térmico del TFP410PAP.
> Los dibujos de los PDF no se pueden leer como texto desde el contenedor.

**Qué se hace.** Bajar las hojas de datos y revisar, una por una, las marcas VERIFICAR de
`hardware/DISENO.md` (35) y `hardware/conexiones.md` (24), más las 12 de la sección 7 de
`hardware/kicad/LIBRERIAS.md`. Las que más importan, en orden:

1. **TPD12S016 (SLLSE96F)**: cuáles de los pines 15-18 y 20-23 son CLK± y D0±/D1±/D2±. El circuito no
   cambia (son diodos iguales), pero decide por dónde pasa cada par TMDS en la PCB.
2. **TFP410PAP**: tamaño real del pad térmico, para confirmar que la huella oficial de 8 × 8 mm con
   abertura de 4.4 × 4.4 mm corresponde a la pieza; y los straps EDGE, ISEL, DSEL, BSEL.
3. **LAN8742A**: los straps del modo *REF_CLK Out* (nINTSEL) y la dirección del PHY, contra el esquemático
   de la Nucleo-H743ZI2 (UM2407), que es el diseño de referencia que sigue este nodo.
4. **SDRAM**: los nanosegundos de tMRD, tXSR, tRAS, tRC, tWR, tRP y tRCD de la pieza exacta que vayas a
   comprar, no del genérico. Los de la tabla están escritos de memoria.
5. **DS12110 (STM32H743)**: consumo real en Run a VOS0, frecuencia máxima de SDCLK y de LTDC_CLK, y
   latencia de flash.
6. **Conectores**: que el HDMI que compres tenga la huella del Amphenol 10029449, que el USB-C sea el
   TYPE-C-31-M-12 de HRO, que el RJ45 sea el HR911105A y la polaridad de sus LED en los pines 9-12.
7. **Códigos LCSC de todo el BOM** y existencias del H743IIT6 y del TFP410, que según el riesgo 10 del
   diseño se agotan seguido.
8. **Anchos de pista**, con la calculadora de impedancia de JLCPCB para el apilado exacto que vayas a
   pedir, no con los valores aproximados del documento.

Al cerrar cada punto, corregir el documento en el repositorio para que la marca VERIFICAR desaparezca o se
convierta en un dato con su fuente.

**Por qué va aquí.** Porque es lo que separa un documento de diseño de un esquemático que se puede
capturar, y porque si se hace *después* de capturar el esquemático, hay que capturarlo dos veces. Va
después de la ruta del Pico porque no urge: la ruta del Pico ya te da nodos funcionando mientras esto
avanza. Y va antes de las etapas 7 a 9 porque las condiciona por completo.

**¿Necesita tu PC?** No. Esto se puede hacer en el contenedor con las hojas de datos, o tú leyendo los PDF.
Es, eso sí, la etapa **más cara en créditos** de todo el plan, así que conviene partirla: primero los
puntos 1 a 4, que son los que bloquean el esquemático; los demás después, cuando ya vayas a comprar.

**Trabajo.** Varias sesiones. Es la etapa larga y aburrida del proyecto, y es inevitable.

**Criterio de terminado.** En `DISENO.md` y `conexiones.md` no queda ninguna marca VERIFICAR sin resolver o
sin una nota que diga quién la decide y cuándo. Cada número que antes estaba "de memoria" tiene ahora al
lado la hoja de datos y la tabla de donde salió.

---

### Etapa 7 — Nucleo-H743ZI2: red, JPEG y decodificación por franjas

**Qué se hace.** Comprar una NUCLEO-H743ZI2 y grabar `build/nucleo/puente_nodo.hex` (o copiar el `.bin` a
la unidad USB de la placa, que es lo más simple). Seguir la prueba que ya está escrita en la sección
"Prueba en la NUCLEO-H743ZI2" de `firmware/proyecto/PROYECTO.md`: consola a 115200, DHCP o IP fija, los
patrones de los tres LED, el nodo apareciendo solo en la consola de pantallas de la PC como 800x600, las
estadísticas cada 5 s, **Identificar**, y el celular mandando directo. Dejarlo **una hora recibiendo video
sin que se cuelgue**, que es lo que exige el paso 1 de la sección 9.2 de `DISENO.md`. Después, el paso 2 de
esa misma sección: decodificar JPEG a la SRAM AXI, convertir con DMA2D y comparar una suma de verificación
contra la calculada en la PC. **Aquí mismo se escribe y se prueba la decodificación por franjas** de la
sección 6 de `DISENO.md`, usando `HAL_JPEG_DataReadyCallback`, que es el cambio sin el cual la placa propia
no pasará de 12-15 fps.

**Por qué va aquí.** Porque es el paso que cierra el riesgo número 6 del diseño (el problema clásico del
H7 con LwIP: MPU, descriptores en D2 y caché), y ese riesgo es la razón número uno por la que una placa
propia se queda muda a los pocos segundos. Hacerlo en una placa de 1 000 pesos que ya funciona, en vez de
en una placa de cuatro capas recién soldada, es la diferencia entre depurar una cosa y depurar veinte a la
vez. También valida el códec JPEG por hardware y el protocolo en silicio real.

**¿Necesita tu PC?** Sí, para grabar y para ver la consola, pero **no necesitas STM32CubeIDE**: basta
arrastrar el `.bin` a la unidad USB de la Nucleo, o usar `STM32_Programmer_CLI`. Si más adelante quieres
breakpoints, ahí sí instalas CubeIDE, en el disco D:.

**Trabajo.** Una tarde para la prueba de red; varias sesiones para la decodificación por franjas.

**Criterio de terminado.** Una hora de video sin colgarse, con `llegaron` y `mostrados` subiendo parejo y
`errores` en 0. DHCP funcionando y el nodo apareciendo solo en la consola de la PC. El tiempo de
decodificación por hardware medido en milisegundos. Y la decodificación por franjas compilando y dando la
misma suma de verificación que la PC, con el consumo de ancho de banda recalculado con números medidos en
vez de estimados.

---

### Etapa 8 — Capturar el esquemático y la PCB del nodo H743 en KiCad 10

**Qué se hace.** Con `conexiones.md` ya corregido (etapa 6) y las librerías ya probadas (etapa 2):
capturar el esquemático completo hoja por hoja, aprovechando que el símbolo `STM32H743IITx_Nodo` viene
repartido en 10 unidades justo para eso. Asignar las huellas (recordando que U3, J1, J2, J3 y los botones
llevan la huella de `puente_nodo`, no la que trae el símbolo oficial). Correr ERC hasta 0 errores. Hacer
una **revisión cruzada del esquemático contra `pines.csv` y las hojas de datos** antes de rutear, que es el
control del riesgo número 3. Luego la PCB: 4 capas con el apilado de la sección 8.1, impedancia controlada
pedida a JLCPCB, TMDS primero (TFP410 a menos de 30 mm del conector, sin vías, sobre GND continuo), después
RMII, SDRAM y LTDC con las reglas de las secciones 8.3 a 8.6, zona de magnéticos del RJ45 despejada en
todas las capas, desacoplos de la sección 8.7 con los 100 nF por cada uno de los 14 pines VDD y los dos
2.2 µF de VCAP a menos de 3 mm. DRC, vista 3D, gerbers, y a JLCPCB con ensamble (el LQFP176 y el pad
térmico del TFP410 no son para soldar en la mesa de la casa).

**Por qué va al final.** Porque es la etapa que cuesta dinero de verdad y la que no se puede corregir
después, y porque depende de las tres anteriores: de que KiCad abra las librerías (etapa 2), de que los
pines de los integrados estén confirmados (etapa 6) y de que el firmware de red y JPEG ya funcione en
silicio (etapa 7).

**¿Necesita tu PC?** **Sí, obligatorio y en su totalidad.** Es la etapa con más horas de laptop del
proyecto.

**Trabajo.** Es la etapa grande: varias semanas de ratos libres. El esquemático solo son unas 10 hojas, y
el ruteo de cuatro capas con SDRAM, RMII, 28 señales de LTDC y 4 pares TMDS en un LQFP176 no es un trabajo
de una tarde.

**Criterio de terminado.** ERC con 0 errores, DRC con 0 errores y 0 redes sin conectar, la revisión cruzada
del esquemático firmada contra `pines.csv` y las hojas de datos, los gerbers subidos, la vista previa de
JLCPCB correcta y el pedido de ensamble confirmado con todas las piezas en existencia.

---

### Etapa 9 — Pruebas de la primera placa H743, en orden

**Qué se hace.** Exactamente la lista "Con la primera placa" de la sección 9.2 de `DISENO.md`, sin
saltarse pasos y pasando cada uno antes de seguir: voltajes y ausencia de cortos; SWD reconociendo el chip
y VCAP cerca de 1.2 V; LED parpadeando con el HSI; HSE y PLL medidos en MCO1 (PA8), primero a 400 MHz y
luego a 480; UART y DIP; **prueba de memoria de los 32 MB, 100 pasadas, a 80 MHz y luego a 100 MHz, con
cachés apagadas y encendidas**; barras de color a 800x600 (el modo más tolerante) antes de intentar
1024x600 o 720p; Ethernet con enlace, DHCP y ping sostenido; la cadena completa contando *underrun* del
LTDC; una prueba de varias horas con la caja cerrada midiendo temperaturas; y al final varios nodos en un
switch con números de DIP distintos.

**Por qué va así.** Porque este orden está pensado para que cada falla tenga una sola causa posible. Si
enciendes todo de golpe y no hay imagen, no sabes si es el buck, el reloj, la SDRAM, la polaridad de DE o
el monitor.

**¿Necesita tu PC?** Sí, para grabar y ver la consola. Y aquí sí conviene tener el osciloscopio a mano, al
menos para los dos puntos que el diseño marca explícitamente: la polaridad de DE (debe estar en alto
durante los píxeles visibles) y el reloj de píxel.

**Trabajo.** Varias sesiones, repartidas según lo que vaya fallando.

**Criterio de terminado.** Los 10 pasos de la lista pasados y anotados. En particular: la prueba de memoria
sin un solo error a la frecuencia que vayas a usar, barras de color estables, el contador de *underrun* del
LTDC quieto a la resolución elegida, y varios nodos distintos conviviendo en un switch.

---

## 4. Riesgos concretos que ya se conocen

Estos no son hipótesis: salen de los documentos del propio proyecto o de las restricciones del equipo con
el que trabajas.

### 4.1 La W5500-EVB-Pico2 no sirve para este nodo

La placa de WIZnet que integra Pico 2 y W5500 en una sola tarjeta tiene el W5500 en **GPIO16 a GPIO21**
(MISO 16, CS 17, SCK 18, MOSI 19, RST 20, INT 21). El periférico HSTX del RP2350, que es el que genera el
DVI, **solo existe en GPIO12 a GPIO19**. Se pisan. Esa placa no puede sacar video y no hay forma de
arreglarlo por software. Hay que usar una **Pico 2 normal con un módulo W5500 aparte**. Si alguien te la
recomienda porque "ya trae Ethernet", esta es la razón para decir no.

### 4.2 El DVI del Pico sale en RGB332, con tramado, y es lento

El framebuffer de 640x480 a 8 bits ocupa 307 200 de los 524 288 bytes de SRAM, y es lo único que cabe junto
con los dos búferes de JPEG. Consecuencias que hay que aceptar de antemano, no descubrir después:

- **Solo 256 colores.** Se aplica tramado ordenado 4x4 para que los degradados no se vean en escalones,
  pero el texto pequeño queda granulado.
- **El blanco no es blanco.** El codificador del HSTX rellena con ceros los bits que faltan, así que el
  blanco sale como (224, 224, 192): gris amarillento. No es una falla, es el formato.
- **4 a 8 cuadros por segundo** estimados, porque el JPEG se decodifica por software en el Cortex-M33.
- **No hay doble búfer**, así que se ve la imagen llenarse de arriba abajo en cada cuadro.
- **Los JPEG de más de 80 KB se descartan** (se acusan para no trabar a la PC, pero no se muestran). Una
  captura de pantalla con mucho texto puede pasarse. El remedio es bajar la calidad en `pc/nodos.py`.

Sirve muy bien para letreros, presentaciones, el patrón de prueba y video tranquilo. No sirve para video
rápido a pantalla completa. Para eso están el nodo de Raspberry Pi y, si algún día existe, el del H743.

### 4.3 El disco C: lleno

Menos de 17 GB libres y Windows 10 Pro encima. STM32CubeIDE con su paquete de firmware se come la mitad de
eso sin pestañear, y **no lo necesitas** (sección 2.4). KiCad 10 sí lo necesitas, así que instálalo en D:.
Compila los firmwares en el contenedor o en GitHub Actions en vez de instalar WSL y toolchains. Y cuando
descargues librerías de KiCad o paquetes de modelos 3D, que vayan también a D:. Si en algún momento tienes
que instalar CubeIDE, antes de hacerlo libera espacio de verdad: la carpeta de descargas, los puntos de
restauración viejos y los instaladores que ya usaste.

### 4.4 Los demás riesgos del diseño H743, en orden de gravedad

| # | Riesgo | Por qué importa | Cómo lo controlas en este plan |
|---|---|---|---|
| 1 | El ancho de banda de la SDRAM no alcanza | A 1024x600@60 con 30 fps harían falta 176 MB/s de los ~120-150 aprovechables | Decodificación por franjas en la etapa 7, y empezar con 800x600 en la etapa 9 |
| 2 | 1024x600 no es modo estándar | Muchas teles y monitores contestan "sin señal" | Barras de color primero a 800x600; tener listos 720p30 y 720p50; leer el EDID |
| 3 | Pines de TFP410, TPD12S016 y LAN8742A escritos de memoria | Sin imagen o colores cambiados, y ya fabricado | Etapa 6 completa antes de capturar el esquemático (etapa 8) |
| 4 | Polaridad de reloj y de DE entre LTDC y TFP410 | Píxeles con ruido o imagen corrida | La placa deja el strap EDGE seleccionable; `PCPolarity` configurable; osciloscopio en la etapa 9 |
| 5 | Integridad de señal de la SDRAM a 100 MHz en 4 capas | Errores de memoria intermitentes, de los que no se repiten en la mesa | Prueba de memoria larga, plan B a 80 MHz, `ReadPipeDelay`, resistencia en SDCLK |
| 6 | Ethernet del H7: MPU, descriptores, caché | El nodo contesta al ping unos segundos y se queda mudo | Se cierra en la Nucleo, etapa 7, antes de fabricar |
| 9 | Chip de revisión Y (máximo 400 MHz) | No arranca a 480 MHz | Compilar con `CPU_MHZ=400` y leer la revisión con `HAL_GetREVID()` |
| 10 | Abasto del TFP410 y del H743IIT6 | Se agotan seguido; el diseño se queda en el cajón | Revisar existencias en la etapa 6 y comprar antes de mandar la placa |
| 11 | Soldar el LQFP176 y el pad del TFP410 | Cortos y pines al aire | Ensamble en JLCPCB, no a mano |

### 4.5 Riesgos propios de la placa base del Pico

El más grande es el **pinout del módulo W5500**: la tabla de `CARRIER.md` se supuso, no se verificó, y si tu
módulo tiene las columnas al revés le estarías metiendo 3.3 V donde no va. Hay que comparar la serigrafía
antes de fabricar. Después: el tamaño del módulo (se supuso ~55 × 28 mm y el barreno H3 queda debajo, así
que hay que atornillar la placa antes de enchufarlo), que el HDMI que compres tenga la huella del Amphenol
10029449 y no la de un clon con las patas en otro lugar, los ~4.7 V en el pin 18 del HDMI cuando la norma
pide 4.8 en la fuente, y que **no hay protección ESD en las TMDS**. Para uso en escritorio pasa; si el nodo
va a quedar instalado, vale la pena agregarla.

Un riesgo de proceso, no eléctrico, que ya mordió a otros: **`gen_carrier.py` sobrescribe el esquemático y
la PCB**. En el momento en que empieces a trazar en KiCad, ese script se vuelve una granada. Lo mismo con
los generadores de las librerías del H743.

---

## 5. Por cuál variante empezar, y por qué

**Empieza por el nodo Pico 2 (etapas 3 a 5), usando el nodo Linux de la etapa 1 como prueba previa.**

Las razones, en orden de peso:

**Te da un nodo funcionando en semanas, no en meses.** Hoy el proyecto tiene mucha ingeniería acumulada y
cero imagen en una pantalla. El nodo Pico cuesta del orden de $500 pesos, se arma con cables dupont, se
graba arrastrando un archivo y no necesita que nada esté fabricado. Es el único camino que convierte el
proyecto en algo que se puede enseñar funcionando sin un gasto grande.

**El riesgo que cierra es el que más vale.** Cuando el nodo Pico muestre video, habrás comprobado en
hardware real el protocolo con acuses, el anuncio UDP, el descubrimiento desde la PC, la identificación y
la ruta del celular. Eso es código **compartido** con el nodo STM32 (`puente_nodo.c` es literalmente el
mismo archivo). Cada hora invertida ahí también desriesga la placa grande.

**El nodo STM32 todavía no está listo para capturarse.** No porque esté mal pensado, sino porque sus
propios documentos declaran 59 marcas VERIFICAR, y la sección 6 del diseño dice que la resolución objetivo
no llega a 30 fps sin un cambio de firmware que aún no existe. Capturar un esquemático de cuatro capas
sobre datos marcados como "de memoria" es la forma más cara de equivocarse en este proyecto. Primero la
etapa 6 y la etapa 7.

**El nodo Linux no compite, complementa.** Si ya tienes la Raspberry Pi 4B, úsala para la etapa 1: es gratis,
es una tarde y valida el lado de la PC contra un nodo real. No tiene diseño electrónico que hacer, así que
no es "la parte electrónica del proyecto", pero sí es el banco de pruebas que te deja saber si un problema
está en el nodo nuevo o en la PC.

**Y en cuanto al orden de las herramientas**: la etapa 2 (abrir todo en KiCad 10) va temprano aunque no
produzca nada visible, porque es barata y porque es la única suposición pendiente que podría obligar a
rehacer trabajo ya hecho. Una tarde ahí puede ahorrar semanas más adelante.

Dicho sin rodeos: el nodo H743 es el proyecto de ingeniería que vale la pena presentar, y el plan lo lleva
hasta el final. Pero llega mucho mejor si antes ya hay un nodo barato funcionando en una pantalla y un
firmware de red probado en una Nucleo.
