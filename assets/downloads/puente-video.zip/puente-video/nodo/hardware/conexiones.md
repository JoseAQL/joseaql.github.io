# Nodo Puente Video — lista de conexiones (netlist en texto)

Para capturar el esquemático en KiCad. Formato: `componente.pin → red`.

**Reglas de este archivo**

- Los pines de **U1 (STM32H743IIT6)** están verificados contra la base de datos de pines de ST; el detalle completo, con número de pin físico, está en `pines.csv`. Si hay diferencia, manda `pines.csv`.
- Para **los demás integrados los pines se dan por NOMBRE**, tal como aparecen en la hoja de datos. Los números de pin que aparecen entre paréntesis son de memoria y llevan **VERIFICAR**: tomar el número real del símbolo de KiCad y de la hoja de datos, no de aquí.
- Valores de resistencias y capacitores marcados con VERIFICAR: confirmar con la hoja de datos.

Símbolos sugeridos en KiCad: `MCU_ST_STM32H7:STM32H743IITx`, `Interface_Ethernet:LAN8742A`, `Memory_RAM:IS42S16160J-xTL` (o equivalente SDRAM TSOP‑54), TFP410PAP y TPD12S016 (VERIFICAR si están en la librería; si no, crearlos desde la hoja de datos).

## Redes de alimentación

| Red | Descripción |
|---|---|
| `VBUS` | 5 V directo del USB‑C, antes del fusible |
| `+5V` | 5 V después del fusible |
| `+3V3` | Salida del buck |
| `VDDA` | 3.3 V filtrado para la parte analógica del MCU |
| `ETH_VDDA` | 3.3 V filtrado para el PHY y las tomas centrales |
| `ETH_VDDCR` | 1.2 V del regulador interno del PHY |
| `TFP_PVDD`, `TFP_TVDD` | 3.3 V filtrados para el PLL y la salida del TFP410 |
| `HDMI_5V` | 5 V limitados hacia el monitor |
| `VCAP1`, `VCAP2` | Salida del regulador interno del MCU (solo capacitores) |
| `GND` | Tierra |
| `CHASIS` | Blindajes de RJ45, HDMI y USB |

## 1. Entrada USB‑C y 5 V (J1, F1, D1, D4)

J1 = USB‑C hembra de 16 pines (los nombres A/B son los estándar del conector).

- J1.A4, J1.B4, J1.A9, J1.B9 (VBUS) → `VBUS`
- J1.A1, J1.B1, J1.A12, J1.B12 (GND) → `GND`
- J1.A5 (CC1) → R1 5.1 kΩ → `GND`
- J1.B5 (CC2) → R2 5.1 kΩ → `GND` (una resistencia por cada CC; **no** unir CC1 con CC2)
- J1.A8, J1.B8 (SBU1, SBU2) → sin conectar
- J1.A6 y J1.B6 (D+) → `USB_CONN_DP`; J1.A7 y J1.B7 (D−) → `USB_CONN_DM` (opcional, ver sección 10; si no se usa, sin conectar)
- J1 carcasa → `CHASIS`
- F1 (polifusible 1.5 A): `VBUS` → `+5V`
- D1 (TVS 5 V): cátodo → `+5V`, ánodo → `GND`
- C1 10 µF y C2 100 nF: `+5V` → `GND` (no pasar de 10 µF en total del lado de `VBUS`)
- `CHASIS` → R3 1 MΩ en paralelo con C3 1 nF/2 kV → `GND`

## 2. Buck de 3.3 V (U6 TLV62569DBVR, L1)

Pines por nombre (VERIFICAR numeración del SOT‑23‑5):

- U6.VIN → `+5V`; C4 10 µF pegado entre VIN y GND
- U6.EN → `+5V` (por R4 100 kΩ)
- U6.GND → `GND`
- U6.SW → L1 2.2 µH → `+3V3`
- U6.FB → nodo del divisor: R5 453 kΩ a `+3V3`, R6 100 kΩ a `GND` (referencia de 0.6 V → 3.32 V; VERIFICAR valores y si la hoja de datos pide capacitor de adelanto)
- C5 22 µF y C6 22 µF: `+3V3` → `GND`, junto a L1
- D4 LED azul: `+3V3` → R7 1 kΩ → D4 → `GND`

## 3. MCU (U1 STM32H743IIT6)

### 3.1 Alimentación, reset, arranque, relojes

- U1.VDD (pines 15, 23, 36, 49, 62, 72, 82, 91, 103, 127, 136, 149, 159, 172) → `+3V3`, cada uno con 100 nF a `GND`. Además 2 × 10 µF.
- U1.VSS (pines 14, 22, 48, 61, 71, 90, 102, 113, 126, 135, 148, 158) → `GND`
- U1.VDD33_USB (114) → `+3V3`, 100 nF + 1 µF
- U1.VBAT (6) → `+3V3`, 100 nF
- U1.PDR_ON (171) → `+3V3`
- U1.VDDA (39) → `VDDA`; `+3V3` → FB2 → `VDDA`; 1 µF + 100 nF a `GND`
- U1.VREF+ (38) → `VDDA`; 1 µF + 100 nF a `GND`
- U1.VSSA (37) → `GND`
- U1.VCAP (81) → `VCAP1` → C 2.2 µF → `GND`
- U1.VCAP (125) → `VCAP2` → C 2.2 µF → `GND`
- U1.NRST (31) → `NRST`; C 100 nF a `GND`; SW1 a `GND`; J4.10
- U1.BOOT0 (166) → `BOOT0`; R 10 kΩ a `GND`; SW2 a `+3V3` (opcional: R 100 Ω en serie con SW2)
- U1.PH0 (29) → Y1.1 y C 12 pF a `GND`
- U1.PH1 (30) → Y1.3 y C 12 pF a `GND` (dejar huella de resistencia serie de 0 Ω en PH1)
- Y1.2, Y1.4 → `GND`
- Capacitores de carga: C = 2 × (CL − C parásita); con CL de 10 pF y 3‑4 pF parásitos salen de 12 pF. VERIFICAR con el cristal comprado.

### 3.2 SWD, depuración, interfaz

J4 = 2x5 paso 1.27 mm, pinout ARM Cortex Debug de 10 pines:

- J4.1 (VTref) → `+3V3`
- J4.2 (SWDIO) → U1.PA13 (124)
- J4.3, J4.5, J4.9 → `GND`
- J4.4 (SWCLK) → U1.PA14 (137)
- J4.6 (SWO) → U1.PB3 (161)
- J4.7 (KEY), J4.8 (NC) → sin conectar
- J4.10 (nRESET) → `NRST`

Si se usa Tag‑Connect TC2030‑NL (6 contactos): 1 = `+3V3`, 2 = SWDIO, 3 = `NRST`, 4 = SWCLK, 5 = `GND`, 6 = SWO (VERIFICAR con la hoja de Tag‑Connect).

- J5.1 → `GND`; J5.2 → U1.PB14 (`DBG_TX`); J5.3 → U1.PB15 (`DBG_RX`)
- U1.PB0 (56) → R 1 kΩ → D2 LED verde → `GND` (`LED_ESTADO`)
- U1.PB1 (57) → R 1 kΩ → D3 LED rojo → `GND` (`LED_AUX`, opcional)
- U1.PF6 (24) → SW3.1; U1.PF7 (25) → SW3.2; U1.PF8 (26) → SW3.3; U1.PF9 (27) → SW3.4; el otro lado de los cuatro interruptores → `GND`. Sin resistencias externas (*pull‑up* interno). Interruptor cerrado = bit en 1; PF6 es el bit menos significativo.
- U1.PC13 (8) → SW4 → `GND` (opcional)
- U1.PA8 (119) → TP1 (opcional)

## 4. SDRAM (U2 IS42S16160J, TSOP‑54)

Números de pin del TSOP‑54 estándar JEDEC para SDRAM x16 (de memoria, **VERIFICAR** con el símbolo):

| Señal de U2 | Pin de U2 | Red | Pin de U1 |
|---|---|---|---|
| DQ0‑DQ7 | 2, 4, 5, 7, 8, 10, 11, 13 | `SD_D0`‑`SD_D7` | PD14, PD15, PD0, PD1, PE7, PE8, PE9, PE10 |
| DQ8‑DQ15 | 42, 44, 45, 47, 48, 50, 51, 53 | `SD_D8`‑`SD_D15` | PE11, PE12, PE13, PE14, PE15, PD8, PD9, PD10 |
| A0‑A3 | 23, 24, 25, 26 | `SD_A0`‑`SD_A3` | PF0, PF1, PF2, PF3 |
| A4‑A9 | 29, 30, 31, 32, 33, 34 | `SD_A4`‑`SD_A9` | PF4, PF5, PF12, PF13, PF14, PF15 |
| A10/AP | 22 | `SD_A10` | PG0 |
| A11 | 35 | `SD_A11` | PG1 |
| A12 | 36 | `SD_A12` | PG2 |
| BA0, BA1 | 20, 21 | `SD_BA0`, `SD_BA1` | PG4, PG5 |
| LDQM | 15 | `SD_NBL0` | PE0 |
| UDQM | 39 | `SD_NBL1` | PE1 |
| CLK | 38 | `SD_CLK_R` | PG8 por R 22 Ω (resistencia junto a U1) |
| CKE | 37 | `SD_CKE1` | PH7 (R 10 kΩ a `GND` opcional) |
| /CS | 19 | `SD_NE1` | PH6 |
| /RAS | 18 | `SD_NRAS` | PF11 |
| /CAS | 17 | `SD_NCAS` | PG15 |
| /WE | 16 | `SD_NWE` | PH5 |
| VDD | 1, 14, 27 | `+3V3` | — |
| VDDQ | 3, 9, 43, 49 | `+3V3` | — |
| VSS | 28, 41, 54 | `GND` | — |
| VSSQ | 6, 12, 46, 52 | `GND` | — |
| NC | 40 | sin conectar | — |

Desacoplo: 100 nF por cada pin VDD y VDDQ (7) más 10 µF.

## 5. Ethernet (U3 LAN8742A, Y2, J2)

Pines de U3 por nombre; el número entre paréntesis corresponde al QFN‑24 (de memoria, **VERIFICAR**).

### 5.1 RMII y gestión

| Pin de U3 | Red | Va a |
|---|---|---|
| TXD0 (17) | `RMII_TXD0` | U1.PB12 (huella de R serie 0 Ω junto a U1) |
| TXD1 (18) | `RMII_TXD1` | U1.PB13 (ídem) |
| TXEN (16) | `RMII_TX_EN` | U1.PB11 (ídem) |
| RXD0/MODE0 (8) | R 33 Ω → `RMII_RXD0` | U1.PC4 |
| RXD1/MODE1 (7) | R 33 Ω → `RMII_RXD1` | U1.PC5 |
| CRS_DV/MODE2 (11) | R 33 Ω → `RMII_CRS_DV` | U1.PA7 |
| nINT/REFCLKO (14) | R 33 Ω → `RMII_REF_CLK` | U1.PA1 (salida de 50 MHz del PHY) |
| MDIO (12) | `RMII_MDIO` | U1.PA2; R 1.5 kΩ a `+3V3` |
| MDC (13) | `RMII_MDC` | U1.PC1 |
| nRST (15) | `ETH_NRST` | U1.PD7; R 10 kΩ a `+3V3`; C 100 nF a `GND` |
| RXER/PHYAD0 (10) | — | sin conectar (*pull‑down* interno → dirección 0); dejar punto de prueba |

Las resistencias de 33 Ω van pegadas a U3.

### 5.2 Straps (se leen al salir de reset)

- **MODE[2:0]** (en RXD0, RXD1, CRS_DV): sin resistencias externas → 111 por los *pull‑up* internos = todas las velocidades con autonegociación.
- **LED2/nINTSEL (2) = 0 → modo REF_CLK Out**. Confirmado en la hoja de datos (DS00001989A, tablas 2‑2 y 3‑6): «When nINTSEL is pulled low to VSS, REFCLKO is selected for operation on the nINT/REFCLKO pin», y la tabla 3‑6 dice «nINTSEL = 0 | REF_CLK Out Mode». En ese modo el PHY genera los 50 MHz con su cristal de 25 MHz y **nINT deja de existir** como señal. El strap tiene *pull‑up* interno, así que para dejarlo en bajo hace falta una R externa a `GND`: **R 10 kΩ de U3.LED2 a `GND`**.
- **LED1/REGOFF (3) = 0 → regulador interno de 1.2 V encendido**. Confirmado: «When REGOFF is floating or pulled low, the internal regulator is enabled (default)». Este strap tiene *pull‑down* interno, así que basta dejarlo flotando; se deja igual una **R 10 kΩ a `GND`** por claridad y como punto de prueba.
- ⚠️ **Cambio de diseño que sale de esta verificación: los dos LED del RJ45 ya no los maneja el PHY.** La hoja de datos lo dice en las dos secciones: con REGOFF en bajo, «it is recommended not to connect an LED to this pin» (LED1), y con nINTSEL en bajo, «it is not recommended to connect an LED to this pin» (LED2). Un LED en serie con 330 Ω al mismo pin que un strap cambia el nivel que se enclava al salir de reset, y es justo la combinación que este nodo necesita en los dos pines. Opciones, en orden de preferencia:
  1. **Dejar los LED del RJ45 al MCU.** `ETH_LED_LINK` y `ETH_LED_VEL` se manejan desde dos GPIO libres del H743 (quedan 40 pines sin usar) y el firmware los enciende con lo que ya sabe del PHY por MDIO. Es la opción limpia y no cuesta nada en la placa.
  2. Dejar los LED del RJ45 sin conectar en la primera placa (huellas sí, sin uso) y decidir después.
- **Otra nota de la hoja de datos**: si algún día hay que subir LED1 o LED2 a nivel alto, «they must be tied to VDD2A, NOT VDDIO». En este diseño los dos van a `GND`, así que no aplica, pero conviene que no se pierda el dato.

### 5.3 Alimentación, cristal y polarización

- U3.VDDIO (9) → `+3V3`, 100 nF
- `+3V3` → FB3 → `ETH_VDDA`; 10 µF + 100 nF
- U3.VDD1A (19), U3.VDD2A (1) → `ETH_VDDA`, 100 nF cada uno
- U3.VDDCR (6) → `ETH_VDDCR` → 1 µF + 470 pF a `GND` (no alimenta nada más)
- U3.RBIAS (24) → R 12.1 kΩ 1 % → `GND`
- U3.XTAL1/CLKIN (5) → Y2.1 y C 12 pF a `GND`
- U3.XTAL2 (4) → Y2.3 y C 12 pF a `GND`
- ⚠️ **Dato de la hoja de datos que afecta la compra del cristal.** El LAN8742A admite dos cristales distintos y **no son intercambiables en la placa**: el de 300 µW (tabla 5‑16) pide CL ≈ 20 pF, ESR ≤ 50 Ω y **no lleva resistencia en serie**; el de 100 µW (tabla 5‑17) pide CL de 8 a 12 pF, ESR ≤ 80 Ω y **sí lleva una resistencia en serie con XTAL2, de 500 Ω ±1 %**. Los 12 pF de arriba corresponden al cristal de 100 µW, así que **hay que agregar R 500 Ω 1 % en serie entre U3.XTAL2 (4) y Y2.3** (el capacitor de 12 pF queda del lado del cristal). Si en su lugar se compra un cristal de 20 pF / 300 µW, esa resistencia se omite y los capacitores suben. Las dos tablas piden ±50 ppm en total (tolerancia, deriva térmica y envejecimiento juntos), que es el límite de IEEE 802.3u.
- Y2.2, Y2.4 → `GND`
- U3 pad expuesto (VSS) → `GND` con vías

### 5.4 Lado de línea y RJ45 (J2 HR911105A)

Pines de J2 de memoria, **VERIFICAR** con la hoja de datos de HanRun (sobre todo la polaridad de los LED):

| Pin de U3 | Red | Pin de J2 |
|---|---|---|
| TXP (21) | `ETH_TXP` | 1 (TD+) |
| TXN (20) | `ETH_TXN` | 2 (TD−) |
| RXP (23) | `ETH_RXP` | 3 (RD+) |
| RXN (22) | `ETH_RXN` | 6 (RD−) |
| — | `ETH_VDDA` | 4 (toma central TX) y 5 (toma central RX), con 100 nF a `GND` cada una |
| — | sin conectar | 7 |
| — | `CHASIS` | 8 y carcasa |
| **GPIO libre del MCU** por R 330 Ω | `ETH_LED_LINK` | LED verde, ánodo (9 o 10); cátodo → `GND` |
| **GPIO libre del MCU** por R 330 Ω | `ETH_LED_VEL` | LED amarillo, ánodo (11 o 12); cátodo → `GND` |

Los LED **ya no salen de U3.LED1/LED2**: esos dos pines son los straps REGOFF y nINTSEL de este diseño y la hoja de datos pide no colgarles un LED (ver 5.2). Se manejan desde dos GPIO del H743; falta asignar cuáles en `pines.csv`.

- R 49.9 Ω 1 % de cada una de `ETH_TXP`, `ETH_TXN`, `ETH_RXP`, `ETH_RXN` a `ETH_VDDA` (4 resistencias junto a U3).

## 6. Transmisor DVI (U4 TFP410PAP)

Pines por nombre. **VERIFICAR todos los números de pin con la hoja de datos del TFP410**; aquí no se dan números a propósito.

### 6.1 Video de entrada (LTDC)

**Confirmado** en la hoja de datos del TFP410 (SLDS145D, sección 6.3.1 y tabla 6‑3): en modo de 24 bits, DATA[23:16] = rojo (D23 = R[7], el bit más significativo), DATA[15:8] = verde, DATA[7:0] = azul. La suposición original era correcta.

| Pin de U4 | Red | Pin de U1 |
|---|---|---|
| DATA23‑DATA16 | `LCD_R7`‑`LCD_R0` | PG6, PH12, PH11, PH10, PH9, PH8, PH3, PH2 |
| DATA15‑DATA8 | `LCD_G7`‑`LCD_G0` | PI2, PI1, PI0, PH15, PH14, PH13, PE6, PE5 |
| DATA7‑DATA0 | `LCD_B7`‑`LCD_B0` | PI7, PI6, PI5, PI4, PG11, PD6, PG12, PE4 |
| IDCK+ | `LCD_CLK_R` | PG7 por R 22 Ω (resistencia junto a U1) |
| IDCK− (56) | `GND` | Confirmado: para reloj de una sola terminal la hoja de datos dice literalmente «the IDCK− input (pin 56) should be tied to GND». Sin resistencia. IDCK+ es el pin 57. |
| DE | `LCD_DE` | PF10 |
| HSYNC | `LCD_HSYNC` | PI10 |
| VSYNC | `LCD_VSYNC` | PI9 |

Atención al orden del azul: `LCD_B3` = PG11, `LCD_B2` = PD6, `LCD_B1` = PG12, `LCD_B0` = PE4 (no van en orden de número de pin).

### 6.2 Configuración por straps (sin I2C)

Números de pin confirmados contra la tabla 4‑1 de SLDS145D.

| Pin de U4 | Conexión | Efecto |
|---|---|---|
| ISEL/RST (13) | R 10 kΩ a `GND` | I2C desactivado; se configura por pines. Confirmado: «If ISEL is low, then I2C is disabled and the chip configuration is specified by the configuration pins (BSEL, DSEL, EDGE, VREF) and state pins (PD, DKEN)». |
| BSEL/SCL (15) | R 10 kΩ a `+3V3` | Bus de 24 bits, un flanco. Confirmado: BSEL alto = 24 bits, un flanco; bajo = 12 bits, dos flancos. Las R de 5 kΩ que pide la hoja de datos en BSEL/DSEL son solo «when I2C is enabled», así que aquí 10 kΩ está bien. |
| DSEL/SDA (14) | R 10 kΩ a `GND` | **Corrección del motivo**: DSEL **no** elige terminal sencilla contra diferencial. Con VREF atado a DVDD (modo de nivel alto, que es el de esta placa) la tabla 6‑1 marca DSEL como *don't care*. La R a `GND` queda como nivel definido, no porque haga falta. Lo que decide el reloj de una sola terminal es atar IDCK− (56) a `GND`. |
| EDGE/HTPLG (9) | Dos huellas: R 10 kΩ a `+3V3` (**montada**) y R 10 kΩ a `GND` (sin montar) | Confirmado: con I2C apagado, EDGE alto captura en flanco de subida de IDCK+ y bajo en flanco de bajada. Las dos huellas se quedan: es el strap con más probabilidad de tener que invertirse en la primera prueba. |
| DKEN (35) | `GND` | Sin ajuste de retardo. Confirmado: con I2C apagado, DKEN bajo desactiva el *de‑skew*. |
| CTL1/A1/DK1 (8), CTL2/A2/DK2 (7), CTL3/A3/DK3 (6) | `GND` | Tienen *pull‑down* débil interno, así que `GND` coincide con el valor por omisión. |
| VREF (3) | `+3V3` | Confirmado: «For high-swing 3.3V input signal levels, VREF should be tied to VDD». Sin divisor. (El modo de nivel bajo pediría 0.55 a 0.9 V con un divisor, y no es el caso.) |
| PD (10) | `TFP_PD_N` → U1.PD4; R 10 kΩ a `+3V3` | Encendido por defecto. Confirmado por la descripción del pin: alto = operación normal, bajo = apagado. ⚠️ El bit PD del registro `CTL_1_MODE` está documentado al revés (0 = power‑down); no usar el registro como referencia del pin. |
| MSEN/PO1 (11) | `TFP_MSEN` → U1.PD5; **R 5 kΩ a `+3V3`** | ⚠️ **Corrección de valor**: la hoja de datos no lo deja a gusto del diseñador, dice «An external 5kΩ pullup resistor connected to VDD is required on this pin» porque la salida es de colector abierto. Cambiado de 10 kΩ a **5.1 kΩ** (valor comercial más cercano, y ya está en el BOM). |
| TFADJ (19) | R 510 Ω 1 % a `TFP_TVDD` | **Confirmado**: el valor normal es 510 Ω ±1 % y el rango recomendado es 505 a 515 Ω, para una excursión TMDS de 400 a 600 mV. El 1 % no es opcional. |
| **RESERVED (34)** | **`GND`** | ⚠️ **Falta que había**: la hoja de datos dice «must be tied to GND for normal operation». Antes caía en el renglón de «pines NC, sin conectar», que lo habría dejado al aire. |
| Pines NC de verdad | sin conectar | Todos menos el 34. |
| Entradas de datos sin usar | `GND` o `+3V3` | Regla general de la hoja de datos: «All unused data inputs should be tied to GND or VDD». Aquí se usan las 24, así que no aplica, pero queda anotado para la variante de 12 bits. |

Pines de datos, por si sirve al capturar: DATA[23:12] son los pines 36 a 47 y DATA[11:0] son los pines 50 a 55 y 58 a 63. El orden exacto dentro de cada rango **se toma del símbolo de KiCad**, no de aquí: la extracción de texto de la figura no es confiable.

### 6.3 Salida TMDS

| Pin de U4 | Red |
|---|---|
| TX2+ / TX2− | `TMDS_D2_P` / `TMDS_D2_N` |
| TX1+ / TX1− | `TMDS_D1_P` / `TMDS_D1_N` |
| TX0+ / TX0− | `TMDS_D0_P` / `TMDS_D0_N` |
| TXC+ / TXC− | `TMDS_CK_P` / `TMDS_CK_N` |

Acoplamiento directo (en DC), sin capacitores ni resistencias en serie.

### 6.4 Alimentación

- U4.DVDD (todos) → `+3V3`, 100 nF por pin
- `+3V3` → FB4 → `TFP_PVDD` → U4.PVDD; 10 µF + 100 nF
- `+3V3` → FB5 → `TFP_TVDD` → U4.TVDD (todos); 10 µF + 100 nF por pin
- U4.DGND, PGND, TGND y pad térmico → `GND`

## 7. Protección HDMI (U5 TPD12S016) y conector (J3)

Nombres y números confirmados contra la tabla «Pin Functions» de SLLSE96F (revisión de octubre de 2015), columna del encapsulado **PW (TSSOP‑24)**, que es el que lleva el `TPD12S016PWR` del BOM:

| # | Nombre | | # | Nombre |
|---|---|---|---|---|
| 1 | CEC_A | | 13 | 5V_OUT |
| 2 | SCL_A | | 14 | GND |
| 3 | SDA_A | | 15 | CLK+ |
| 4 | HPD_A | | 16 | CLK− |
| 5 | LS_OE | | 17 | D2 (par) |
| 6 | GND | | 18 | D2 (par) |
| 7 | CEC_B | | 19 | GND |
| 8 | SCL_B | | 20 | D1 (par) |
| 9 | SDA_B | | 21 | D1 (par) |
| 10 | HPD_B | | 22 | D0 (par) |
| 11 | VCC5V | | 23 | D0 (par) |
| 12 | CT_HPD | | 24 | VCCA |

Esto resuelve el punto que importaba para rutear: **el reloj TMDS va en 15/16, D2 en 17/18, D1 en 20/21 y D0 en 22/23**, con `GND` en el 19 partiendo el bloque. El orden sigue el del conector HDMI, así que los pares quedan en el mismo orden físico que en J3 y las pistas no se cruzan.

⚠️ **Lo único que queda abierto del TPD12S016**: cuál pin de cada par de datos es el + y cuál el −. La extracción de texto del diagrama de pines sale revuelta y no da para afirmarlo. El circuito **no cambia** (son diodos iguales en los dos lados), así que no bloquea el esquemático; sí hay que confirmarlo contra el símbolo de KiCad al capturar, para no invertir un par en la PCB. Nota aparte: la numeración del encapsulado **RKT (QFN)** del mismo integrado es distinta. No mezclar las dos tablas.

Tensiones de alimentación confirmadas: VCCA de 1.1 a 3.6 V (máximo absoluto 4.0 V), VCC5V de 4.5 a 5.5 V, y 5V_OUT con límite de corriente de 55 mA. No existen pines `I2C_VCC` ni `V_5V`: los 3.3 V internos los genera un LDO dentro del integrado.

| Pin de U5 | Conexión |
|---|---|
| VCCA | `+3V3`, 100 nF |
| VCC5V | `+5V`, 100 nF + 1 µF |
| 5V_OUT | `HDMI_5V`, 100 nF → J3.18 |
| CT_HPD (12) y LS_OE (5) | `HDMI_EN` → U1.PD3; R 10 kΩ a `+3V3` (habilitado por defecto). Confirmado que unirlos es lo correcto: los dos son activos en alto referidos a VCCA y la tabla 1 de la hoja de datos marca la combinación LS_OE = alto con CT_HPD = bajo como **«Not a Valid State»**. Atados al mismo nodo esa combinación no puede ocurrir. |
| SCL_A (2) | `DDC_SCL_3V3` → U1.PB8. **Sin resistencia externa**: el integrado ya trae *pull‑up* interno de 10 kΩ a VCCA. Se dejan las huellas de 10 kΩ sin montar por si hiciera falta acelerar el flanco. |
| SDA_A (3) | `DDC_SDA_3V3` → U1.PB9. Igual que SCL_A: *pull‑up* interno de 10 kΩ a VCCA, huella sin montar. |
| SCL_B (8) | `HDMI_SCL` → J3.15. **Confirmado**: el *pull‑up* del lado del conector está dentro del integrado, y es de **1.75 kΩ a 5V_OUT**, que es el valor que pide HDMI. Nada externo. |
| SDA_B (9) | `HDMI_SDA` → J3.16 (ídem, 1.75 kΩ internos) |
| HPD_B (10) | `HDMI_HPD_CONN` → J3.19. Trae *pull‑down* interno de 11 kΩ típicos y filtro antirrebote; nada externo. |
| HPD_A (4) | `HDMI_HPD` → U1.PD11 (salida referida a VCCA) |
| CEC_A (1) | **sin conectar**, y sin resistencia. Resuelto: el integrado trae *pull‑up* interno de 10 kΩ a VCCA en CEC_A y de 27 kΩ al riel interno de 3.3 V en CEC_B. La hoja de datos dice que el sistema funciona sin *pull‑up* externos en DDC, CEC ni HPD. |
| CEC_B (7) | J3.13 |
| CLK (15, 16), D2 (17, 18), D1 (20, 21), D0 (22, 23) | Cada pin se conecta **sobre** su pista TMDS (protección en paralelo, de paso). El integrado tiene un solo juego de pines TMDS, no uno de entrada y otro de salida: la pista entra y sale por el mismo pin. |
| GND (6, 14, 19) | `GND` |
| VCCA (24) | ver arriba |

J3 = HDMI tipo A (numeración estándar del conector):

| Pin de J3 | Señal | Red |
|---|---|---|
| 1 | TMDS Data2+ | `TMDS_D2_P` |
| 2 | Blindaje Data2 | `GND` |
| 3 | TMDS Data2− | `TMDS_D2_N` |
| 4 | TMDS Data1+ | `TMDS_D1_P` |
| 5 | Blindaje Data1 | `GND` |
| 6 | TMDS Data1− | `TMDS_D1_N` |
| 7 | TMDS Data0+ | `TMDS_D0_P` |
| 8 | Blindaje Data0 | `GND` |
| 9 | TMDS Data0− | `TMDS_D0_N` |
| 10 | TMDS Clock+ | `TMDS_CK_P` |
| 11 | Blindaje Clock | `GND` |
| 12 | TMDS Clock− | `TMDS_CK_N` |
| 13 | CEC | U5.CEC_B |
| 14 | Reservado | sin conectar |
| 15 | SCL | `HDMI_SCL` |
| 16 | SDA | `HDMI_SDA` |
| 17 | Tierra DDC/CEC | `GND` |
| 18 | +5 V | `HDMI_5V` |
| 19 | Detección de conexión (HPD) | `HDMI_HPD_CONN` |
| Carcasa | Blindaje | `CHASIS` |

## 8. Resumen de señales entre bloques

| Bloque | Señales | Pines de U1 |
|---|---|---|
| RMII (9) | REF_CLK, MDIO, MDC, CRS_DV, RXD0, RXD1, TX_EN, TXD0, TXD1 | PA1, PA2, PC1, PA7, PC4, PC5, PB11, PB12, PB13 |
| SDRAM (39) | D0‑15, A0‑12, BA0‑1, NBL0‑1, SDCLK, SDCKE1, SDNE1, SDNRAS, SDNCAS, SDNWE | Puertos D, E, F, G y PH5‑PH7 |
| LTDC (28) | R0‑7, G0‑7, B0‑7, CLK, HSYNC, VSYNC, DE | PH2, PH3, PH8‑PH15, PI0‑PI2, PI4‑PI7, PI9, PI10, PE4‑PE6, PD6, PG6, PG7, PG11, PG12, PF10 |
| HDMI auxiliar | DDC SCL/SDA, HPD, habilitación, PD del TFP410, MSEN | PB8, PB9, PD11, PD3, PD4, PD5 |
| Interfaz | LED, DIP, botón, UART, SWD | PB0, PB1, PF6‑PF9, PC13, PB14, PB15, PA13, PA14, PB3 |

## 9. Lista de revisión antes de mandar a fabricar

1. Importar la asignación en CubeMX (STM32H743IITx) pin por pin desde `pines.csv` y confirmar que no marca ningún conflicto.
2. ~~Revisar contra hoja de datos el orden rojo/verde/azul y los straps del TFP410, los nombres de pines del TPD12S016 y los straps de LED del LAN8742A.~~ **Hecho** (noviembre de 2026, etapa 6 puntos 1 a 3 del `PLAN.md`). Quedan pendientes de este punto, porque no están en el texto de las hojas de datos: la polaridad + / − dentro de cada par de datos del TPD12S016, los pines y la polaridad de los LED del RJ45 HR911105A, y la huella del conector HDMI contra la pieza que se compre.
3. ERC y DRC de KiCad sin errores; un capacitor de 100 nF por cada pin de alimentación.
4. VCAP1 y VCAP2 solo con sus capacitores de 2.2 µF.
5. CC1 y CC2 con resistencias separadas.
6. Las resistencias de 33 Ω y 22 Ω quedaron junto al emisor de cada señal.
7. Existencias y códigos LCSC confirmados.

## 10. Opcional: USB para grabar por DFU

El firmware no usa USB. Conectar D+ y D− permite grabar el nodo con STM32CubeProgrammer sin ST‑Link (mantener BOOT0 presionado al conectar).

- `USB_CONN_DP` → U9 (USBLC6‑2SC6) → `USB_DP` → U1.PA12 (123)
- `USB_CONN_DM` → U9 → `USB_DM` → U1.PA11 (122)
- U9.VBUS → `+5V`; U9.GND → `GND`
- U1.PA9 (120) queda libre y reservado para detección de VBUS.

VERIFICAR en la nota AN2606 que el cargador de arranque del H743 acepta DFU con el cristal de 25 MHz.
