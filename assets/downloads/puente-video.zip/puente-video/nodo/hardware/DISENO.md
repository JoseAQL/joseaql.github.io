# Nodo Puente Video — diseño de hardware (rev. A, sin fabricar)

Receptor Ethernet → HDMI: recibe cuadros JPEG por TCP, los decodifica con el códec JPEG del STM32H743 y los saca por LTDC → TFP410 → HDMI.

Archivos de esta carpeta:

| Archivo | Contenido |
|---|---|
| `DISENO.md` | Este documento: bloques, alimentación, BOM, relojes, tiempos, MPU, reglas de PCB, riesgos |
| `pines.csv` | Los 176 pines del STM32H743IIT6 con señal, función alterna, red y destino |
| `conexiones.md` | Netlist en texto, componente por componente, para capturar en KiCad |

## 0. Cómo leer este documento (qué está verificado y qué no)

- **Verificado contra datos de ST**: la asignación de pines y cada función alterna de `pines.csv` se revisó con un script contra la base de datos abierta de ST (`STM32_open_pin_data`: `mcu/STM32H743IITx.xml` y `mcu/IP/GPIO-STM32H747_gpio_v1_0_Modes.xml`, la misma que usa CubeMX). No hay ningún pin repetido y todas las señales existen en ese pin con ese AF. Los números de pin físico del LQFP176 salen del mismo archivo.
- **Verificado compilando**: el cambio en `nodo_placa.h` (DIP de PG0‑3 a PF6‑9) compila con `firmware/ci/compilar.sh`.
- **De memoria, sin hoja de datos a la mano**: todo lo que lleva la palabra **VERIFICAR**. Incluye los números de pin de los demás integrados (TFP410, TPD12S016, LAN8742A, conectores), los códigos LCSC, los tiempos exactos de la SDRAM, los anchos de pista y los consumos. Nada de eso se probó en hardware.
- **Las cifras de ancho de banda de la SDRAM son estimaciones** hechas con aritmética, no mediciones.

### Cambios respecto a lo que traía el firmware

| Qué | Antes | Ahora | Por qué |
|---|---|---|---|
| DIP de número de nodo | PG0‑PG3 | **PF6‑PF9** | PG0, PG1 y PG2 son A10, A11 y A12 de la SDRAM en el FMC y no tienen pin alterno |
| SDRAM | banco 2, 0xD0000000 | igual | SDNE1 = PH6, SDCKE1 = PH7, SDNWE = PH5 |
| LED de estado | PB0 | igual | PB0 queda libre porque LTDC_R3 va en PH9 |
| Resolución | 1024x600 | igual, **con advertencia** | ver sección 5.1: no es un modo estándar de HDMI |

### Los tres hallazgos importantes

1. **1024x600 no es un modo estándar.** Lo aceptan las pantallas HDMI de 7" hechas para Raspberry Pi; muchas teles y monitores lo rechazan ("sin señal" o "modo no soportado"). Para una pared de video con teles, el modo seguro es 1280x720 (CEA) y, en monitores de PC, 800x600 o 1024x768 (VESA).
2. **1280x720 a 60 Hz no cabe con la arquitectura actual** (todo en una SDRAM de 16 bits): solo el LTDC ya consume ~111 MB/s de los ~200 MB/s teóricos del bus. Sí hay salida: 720p a 30 Hz o 50 Hz y sacar el búfer intermedio YCbCr de la SDRAM (sección 6).
3. **En LQFP176 la SDRAM tiene que ser de 16 bits.** Los datos D16‑D31 del FMC caen en PH8‑PH15 y PI0‑PI10, que son justo los pines que usa el LTDC de 24 bits. No se puede duplicar el ancho de banda con una SDRAM de 32 bits sin pasar a un encapsulado BGA.

## 1. Diagrama de bloques

```
                          +3V3 (buck)                    +5V
                              |                           |
 RJ45 con      MDI   +-----------+  RMII (9)  +---------------------+  RGB888 + CLK/HS/VS/DE (28)  +---------+ TMDS (4 pares) +-----------+      +--------+
 magneticos <------->| LAN8742A  |<---------->|                     |---------------------------->| TFP410  |--------------->| TPD12S016 |----->| HDMI A |
 (J2)                | (U3)      | 50 MHz --> |    STM32H743IIT6    |                              | (U4)    |                | (U5)      |      | (J3)   |
                     +-----------+            |    LQFP176 (U1)     |<-- I2C1 (DDC, opcional) ---------------------------->|  ESD, DDC, |      +--------+
                      Y2 25 MHz               |                     |<-- HPD ------------------------------------------- --|  5V, HPD   |
                                              |  JPEG -> DMA2D ->   |                                                       +-----------+
 USB-C (J1) --> fusible --> +5V --> buck U6 ->|  LTDC               |  FMC SDRAM 16 bits (39)   +--------------------+
   solo 5 V     (CC1/CC2 5.1k)       +3V3     |                     |<------------------------->| SDRAM 32 MB (U2)   |
   D+/D- opcional para DFU                    +---------------------+                           +--------------------+
                                               |    |     |      |
                                          Y1 25 MHz SWD  DIP x4  LED estado, LED aux, UART de depuracion, RESET, BOOT0
```

## 2. Árbol de alimentación

```
USB-C VBUS (5 V) -- F1 polifusible 1.5 A -- D1 TVS 5 V --+-- +5V
                                                          |
                                                          +-- U5 TPD12S016 (VCC5V) --> 5V_OUT --> HDMI pin 18 (max 55 mA)
                                                          |
                                                          +-- U6 buck 5 V -> 3.3 V (2 A) --> +3V3
                                                                  |
                                                                  +-- U1 VDD x14, VBAT, VDD33_USB, PDR_ON
                                                                  |     +-- regulador interno (LDO) -> VCAP1/VCAP2 (2.2 uF c/u) -> nucleo ~1.2-1.35 V
                                                                  +-- FB2 ferrita -> VDDA / VREF+ (U1)
                                                                  +-- U2 SDRAM (VDD x3, VDDQ x4)
                                                                  +-- U3 LAN8742A (VDDIO; FB3 -> VDD1A/VDD2A; LDO interno -> VDDCR 1.2 V)
                                                                  |     +-- tomas centrales del transformador del RJ45
                                                                  +-- U4 TFP410 (DVDD; FB4 -> PVDD; FB5 -> TVDD)
                                                                  +-- U5 TPD12S016 (VCCA), LED, pull-ups
```

Presupuesto de corriente. La fila del MCU ya sale de la hoja de datos (DS12110 Rev 11, enero de 2026); las demás siguen estimadas.

| Carga en 3.3 V | Típico | Máximo | Nota |
|---|---|---|---|
| STM32H743 a 480 MHz, con ETH, LTDC, JPEG, DMA2D, FMC | **220 mA** | **546 mA** | **Dato de hoja de datos**, no estimación: DS12110 Rev 11, sección 7.3.6 (revisión V del silicio), tabla 121, renglón «código desde flash, caché encendida, todos los periféricos habilitados»: 220 mA típicos a 25 °C, 342 mA máximos a 25 °C, 436 mA a 85 °C y **546 mA a 105 °C**. El típico resultó mejor que los 250 mA estimados, pero el máximo es 100 mA peor que los 450 que decía este documento, porque hay que tomarlo a 105 °C (ver la nota de temperatura más abajo). Condición de la prueba: CoreMark, todos los pines como entradas analógicas. Con la caché apagada baja a 168 mA típicos. |
| SDRAM 256 Mbit | 60 mA | 150 mA | Depende de la actividad |
| LAN8742A + transformador (100BASE‑TX) | 90 mA | 140 mA | Incluye la corriente de las tomas centrales |
| TFP410 | 130 mA | 250 mA | Sube con el reloj de píxel. VERIFICAR |
| LED, pull‑ups, TPD12S016 | 15 mA | 30 mA | |
| **Total 3.3 V** | **~515 mA** | **~1.1 A** | El buck de 2 A sigue sobrado, con el máximo actualizado |

| En 5 V (entrada USB‑C) | Típico | Máximo |
|---|---|---|
| Buck (3.3 V × I / 0.9 / 5 V) | 0.40 A | 0.75 A |
| HDMI +5V al monitor | 10 mA | 55 mA |
| **Total 5 V** | **~0.45 A** | **~0.8 A** |

Consecuencias:

- Con resistencias de 5.1 kΩ en CC1 y CC2 el nodo solo puede contar con la corriente por defecto de la fuente. Un puerto USB 2.0 de PC (500 mA) queda justo; **usar cargador de 5 V y al menos 1 A, o un puerto USB‑C**.
- El H743 con LDO interno a 480 MHz disipa cerca de 1 W en el peor caso. Dejar plano de tierra amplio bajo el chip.
- **480 MHz solo existe en la revisión V del silicio.** Confirmado indirectamente en DS12110 Rev 11: la hoja de datos trae **dos secciones de características eléctricas separadas**, una para la revisión Y (sección 6) y otra para la revisión V (sección 7), y los 480 MHz **solo aparecen en la de la revisión V**. La tabla de PLL de la revisión Y (tabla 40) ni siquiera tiene renglón de VOS0: su máximo es 400 MHz. Sigue siendo necesario leer el marcado del chip al comprarlo.
- ⚠️ **A 480 MHz la temperatura de unión máxima baja a 105 °C**, no 125 (DS12110 tabla 112, nota 5, y tabla 113). A 400 MHz con VOS1 son 125 °C. Para un nodo que va atornillado detrás de una pantalla, posiblemente en una caja sin ventilación y en una pared de video donde las pantallas calientan entre sí, esos 20 °C de margen valen más que la diferencia entre 400 y 480 MHz, que en este proyecto no se nota porque el trabajo pesado lo hacen el JPEG por hardware y el DMA2D. **Es otro argumento para la recomendación que ya estaba en la sección 4.2: arrancar a 400 MHz.**
- Inconsistencia de la propia hoja de datos, para que no sorprenda: las tablas 112 y 113 ponen los 480 MHz en VOS0, pero la información de pedido describe la opción «A = Advanced mission profile (VOS1, 480 MHz)». No cambia nada del diseño; si al configurar relojes CubeMX dice VOS1 en lugar de VOS0 a 480 MHz, no es un error de configuración.

## 3. Lista de materiales (BOM)

Los códigos LCSC están escritos de memoria: **confirmar cada uno en lcsc.com antes de ordenar**. Donde no lo sé con certeza dice VERIFICAR en lugar de inventar un código.

"México": ✔ = se consigue en tiendas locales; ✘ = hay que pedirlo a LCSC/JLCPCB, Mouser o DigiKey (ambos envían a México).

| Ref | Componente | Número de parte | Encapsulado | LCSC | México |
|---|---|---|---|---|---|
| U1 | MCU | STM32H743IIT6 | LQFP176 24x24, paso 0.5 | VERIFICAR | ✘ |
| U2 | SDRAM 256 Mbit, 16 bits | **W9825G6KH‑6 (opción preferida: es la que tiene hoja de datos ya revisada)**. Equivalente: IS42S16160J‑6TLI | TSOP‑II 54 | W9825G6KH‑6: **C62246 confirmado** (es el código con el que LCSC publica la hoja de datos de esta pieza); ISSI: VERIFICAR | ✘ |
| U3 | PHY Ethernet RMII | LAN8742A‑CZ‑TR | QFN‑24 4x4 | VERIFICAR | ✘ |
| U4 | Transmisor DVI/TMDS | TFP410PAP | HTQFP‑64 con pad térmico | VERIFICAR | ✘ |
| U5 | Protección HDMI (ESD, DDC, 5 V, HPD) | TPD12S016PWR | TSSOP‑24 | VERIFICAR | ✘ |
| U6 | Buck 5 V → 3.3 V, 2 A | TLV62569DBVR (alternativa: SY8089A1AAC) | SOT‑23‑5 | VERIFICAR | ✘ |
| U9 | ESD de USB (solo si se monta D+/D−) | USBLC6‑2SC6 | SOT‑23‑6 | C7519 (VERIFICAR) | ✘ |
| J1 | USB‑C hembra de 16 pines | Tipo TYPE‑C‑31‑M‑12 | SMD | C165948 (VERIFICAR) | ✘/✔ |
| J2 | RJ45 con magnéticos y 2 LED | HanRun HR911105A | THT | C12074 (VERIFICAR) | ✘/✔ |
| J3 | HDMI tipo A hembra | Genérico de 19 pines SMD (VERIFICAR huella contra la pieza elegida) | SMD | VERIFICAR | ✘ |
| J4 | SWD | Tira 2x5 paso 1.27 mm (ARM Cortex Debug) o huella Tag‑Connect TC2030‑NL | SMD | VERIFICAR | ✘/✔ |
| J5 | UART de depuración | Tira 1x3 paso 2.54 mm | THT | — | ✔ |
| Y1 | Cristal HSE 25 MHz | 3225, 4 pads, CL 10‑12 pF, ±20 ppm | SMD 3225 | C9006 (VERIFICAR) | ✘ |
| Y2 | Cristal PHY 25 MHz | Igual que Y1, ±50 ppm o mejor | SMD 3225 | Igual | ✘ |
| L1 | Inductor del buck | 2.2 µH, Isat ≥ 3 A, DCR < 50 mΩ | 4x4 mm | VERIFICAR | ✘ |
| FB1‑FB5 | Ferritas | 600 Ω a 100 MHz, ≥ 500 mA | 0603 | VERIFICAR | ✘/✔ |
| F1 | Polifusible | 1.5 A de retención, 6 V | 1206 | VERIFICAR | ✔ |
| D1 | TVS 5 V | SMF5.0A o similar | SOD‑123FL | VERIFICAR | ✔ |
| D2, D3, D4 | LED verde (estado), rojo (aux), azul (3V3) | Genéricos | 0603 | — | ✔ |
| SW1, SW2, SW4 | Botones RESET, BOOT0, usuario | Táctil SMD 3x4 o 6x6 | SMD | — | ✔ |
| SW3 | DIP de 4 posiciones | Paso 2.54 mm (o 1.27 mm SMD) | THT/SMD | — | ✔ |
| C (VCAP) | 2 × 2.2 µF X7R/X5R, ESR < 100 mΩ | 0603, ≥ 6.3 V | 0603 | — | ✔ |
| C | 100 nF X7R (aprox. 45 piezas) | 0402 | 0402 | C1525 (VERIFICAR) | ✔ |
| C | 10 µF X5R (aprox. 10), 22 µF X5R (2), 1 µF (6), 470 pF (1), 1 nF/2 kV (1) | 0603/0805/1206 | — | — | ✔ |
| C | Carga de cristales: 4 × 12 pF C0G (ajustar a la CL del cristal) | 0402 | — | — | ✔ |
| R | 5.1 kΩ (**3**), 10 kΩ, 1.5 kΩ, 1 kΩ, 12.1 kΩ 1 %, **500 Ω 1 %**, 49.9 Ω 1 % (4), 33 Ω (4), 22 Ω (2), 510 Ω 1 %, 453 kΩ 1 %, 100 kΩ 1 %, 330 Ω (2), 1 MΩ | 0402 | 0402 | 5.1 k: C25905, 10 k: C25744 (VERIFICAR) | ✔ |

Cambios en resistencias que salieron de revisar las hojas de datos (etapa 6, ver sección 11):

- **5.1 kΩ sube de 2 a 3 piezas**: el pin MSEN del TFP410 pide «an external 5kΩ pullup resistor», no 10 kΩ como decía `conexiones.md`.
- **Se agrega 500 Ω 1 %**: va en serie con XTAL2 del LAN8742A y la pide la hoja de datos cuando el cristal es de 100 µW y 8‑12 pF, que es el que corresponde a los capacitores de 12 pF del diseño.
- **12.1 kΩ 1 % confirmado**: la hoja de datos dice textualmente «This pin requires connection of a 12.1 kΩ (1%) resistor to ground» para RBIAS. El 1 % no es opcional.
- **510 Ω 1 % confirmado** para TFADJ del TFP410, con rango admitido de 505 a 515 Ω.

Lo difícil en México: **U1 a U6, Y1/Y2 y J3**. Lo práctico es pedir la placa ensamblada a JLCPCB con esas piezas (varias serán "extended" o habrá que pre‑ordenarlas) y soldar a mano los conectores THT. El TFP410 y el LQFP176 se pueden soldar a mano con flux y malla, pero el pad térmico del TFP410 necesita horno o aire caliente.

## 4. Relojes

### 4.1 Fuentes

- **HSE = cristal de 25 MHz** en PH0/PH1 (Y1). Con 25 MHz todos los PLL quedan con divisores enteros.
- **PHY**: cristal propio de 25 MHz (Y2). El LAN8742A se configura en modo *REF_CLK Out* (strap nINTSEL en bajo) y entrega los 50 MHz del RMII por su pin nINT/REFCLKO hacia PA1. Es el mismo esquema de la Nucleo‑H743ZI2. En este modo el PHY no tiene pin de interrupción: el enlace se consulta por MDIO.
- LSE no se usa.

### 4.2 PLL1 — núcleo a 480 MHz

| Parámetro | Valor |
|---|---|
| Fuente | HSE 25 MHz |
| DIVM1 | 5 → referencia de 5 MHz (rango de entrada 4‑8 MHz) |
| DIVN1 | 192 → VCO de 960 MHz (VCO ancho) |
| DIVP1 | 2 → **SYSCLK = 480 MHz** |
| DIVQ1 | 20 → 48 MHz (libre; sirve para USB si algún día se usa) |
| DIVR1 | 2 (sin uso) |
| D1CPRE / HPRE | /1 y /2 → CPU 480 MHz, **HCLK = 240 MHz** |
| D1PPRE, D2PPRE1, D2PPRE2, D3PPRE | /2 → APB a 120 MHz |
| Regulador | LDO, escala de voltaje **VOS0** (VOS1 + `SYSCFG` ODEN; CubeMX lo hace al elegir 480 MHz) |
| Latencia de flash | 4 ciclos de espera. **No se puede confirmar en DS12110**: la sección 7.3.6 remite explícitamente al manual de referencia, a la tabla «Number of wait states according to CPU clock (frcc_c_ck) frequency and VCORE range». Hay que leerla en RM0433, o dejar que CubeMX la calcule, que es lo que hace de todos modos. Dato relacionado que sí trae la hoja de datos (tabla 112): `HCLK` máximo es 240 MHz en VOS0, 200 en VOS1, 150 en VOS2 y 100 en VOS3, y `PCLK` 120 / 100 / 75 / 50 MHz. Los 240 y 120 MHz de este diseño están justo en el límite de VOS0. |

Alternativa conservadora, válida en cualquier revisión del chip: DIVN1 = 160 → **400 MHz**, HCLK 200 MHz, VOS1. Con ella el reloj de la SDRAM sale directo de HCLK/2 = 100 MHz sin usar PLL2. Para este proyecto la diferencia de velocidad no se nota, porque el trabajo pesado lo hacen el JPEG por hardware y el DMA2D. **Recomiendo arrancar a 400 MHz y subir a 480 al final.**

### 4.3 PLL2 — reloj del FMC (SDRAM a 100 MHz)

El reloj SDCLK es el reloj de núcleo del FMC entre 2 o entre 3. Con HCLK = 240 MHz daría 120 MHz (demasiado) u 80 MHz. Para tener 100 MHz:

| Parámetro | Valor |
|---|---|
| DIVM2 | 5 → 5 MHz |
| DIVN2 | 80 → VCO de 400 MHz |
| DIVR2 | 2 → **200 MHz** → selector de reloj del FMC = PLL2R |
| SDCLK | 200 / 2 = **100 MHz** (`SDClockPeriod = 2`) |

Plan B para la primera prueba: reloj del FMC = HCLK (240 MHz) con `SDClockPeriod = 3` → 80 MHz.

**Límite confirmado (DS12110 Rev 11, sección 7.3.17, preámbulo de las tablas 167 a 170): `FMC_SDCLK` máximo = 110 MHz** con 2.7 V < VDD < 3.6 V y 20 pF de carga. (Con VDD de 1.8 a 1.9 V baja a 100 MHz, y de 1.62 a 1.8 V a 100 MHz con 15 pF. Aquí se trabaja a 3.3 V, así que manda el 110.) Dos consecuencias:

- Los **100 MHz del diseño caben**, pero con solo **10 % de margen**, y el límite está dado para 20 pF: hay que cuidar de verdad la capacitancia de las pistas del bus de la SDRAM y mantenerlo corto, que es lo que ya pide la sección 8.
- Los **120 MHz que saldrían de HCLK/2 están fuera de especificación**, no solo «apretados». Este documento ya los descartaba por intuición; ahora hay número. Queda otra razón para que el reloj del FMC venga de PLL2R a 200 MHz y no de HCLK.

### 4.4 PLL3 — reloj de píxel del LTDC (salida R)

Referencia de 1 MHz (DIVM3 = 25, rango de entrada 1‑2 MHz, VCO medio de 150‑420 MHz). Así salen frecuencias exactas:

| Modo | Reloj de píxel | DIVM3 | DIVN3 | DIVR3 | VCO | DIVP3 / DIVQ3 |
|---|---|---|---|---|---|---|
| 1024x600 @ 60 (CVT) | 49.00 MHz | 25 | 245 | 5 | 245 MHz | 2 / 2 (sin uso) |
| 1024x600 @ 60 (objetivo del encargo) | 51.20 MHz | 25 | 256 | 5 | 256 MHz | 2 / 2 |
| 1280x720 @ 60, 50 o 30 (CEA) | 74.25 MHz | 25 | 297 | 4 | 297 MHz | 2 / 2 |
| 800x600 @ 60 (VESA) | 40.00 MHz | 25 | 240 | 6 | 240 MHz | 2 / 2 |
| 1024x768 @ 60 (VESA) | 65.00 MHz | 25 | 260 | 4 | 260 MHz | 2 / 2 |

Si la imagen tiembla por la referencia baja de 1 MHz, la variante con referencia de 5 MHz y VCO ancho para 720p es DIVM3 = 5, DIVN3 = 59, FRACN3 = 3277, DIVR3 = 4 (5 × (59 + 3277/8192) / 4 = 74.25 MHz); para 51.25 MHz, DIVM3 = 5, DIVN3 = 41, DIVR3 = 4.

**Límite confirmado (DS12110 Rev 11, tabla 190, «LTDC characteristics»): `LTDC_CLK` máximo = 150 MHz** con 2.7 V < VDD < 3.6 V y 20 pF de carga (133 MHz sin carga especificada en ese renglón, y 90 MHz si se admite VDD desde 1.62 V). La intuición de este documento era correcta: el límite está **muy por encima** de los 74.25 MHz de 720p y del doble de los 51.2 MHz del modo objetivo. El reloj de píxel no es una restricción de este diseño por ningún lado, ni en el MCU (150 MHz) ni en el TFP410 (165 MHz). Condiciones de la medición: `OSPEEDR = 11`, compensación de E/S activada, VOS1.

Nota de paso: el preámbulo de esa sección dice 30 pF y el renglón de 150 MHz dice 20 pF; es una inconsistencia de la hoja de datos, no un error de lectura. Como el margen es de más del doble, no cambia nada aquí.

## 5. Tiempos

### 5.1 LTDC

Advertencia: **1024x600 no está en las tablas CEA ni VESA DMT.** Los dos juegos de tiempos de abajo son los habituales para pantallas pequeñas; un monitor estándar puede rechazarlos. Si el destino son teles, usar 720p.

| Parámetro | 1024x600 CVT | 1024x600 a 51.2 MHz | 720p60 (CEA 4) | 720p50 (CEA 19) | 720p30 (CEA 62) |
|---|---|---|---|---|---|
| Reloj de píxel | 49.00 MHz | 51.20 MHz | 74.25 MHz | 74.25 MHz | 74.25 MHz |
| HSYNC | 104 | 136 | 40 | 40 | 40 |
| HBP | 144 | 160 | 220 | 220 | 220 |
| Activo H | 1024 | 1024 | 1280 | 1280 | 1280 |
| HFP | 40 | 24 | 110 | 440 | 1760 |
| Total H | 1312 | 1344 | 1650 | 1980 | 3300 |
| VSYNC | 10 | 6 | 5 | 5 | 5 |
| VBP | 11 | 26 | 20 | 20 | 20 |
| Activo V | 600 | 600 | 720 | 720 | 720 |
| VFP | 3 | 3 | 5 | 5 | 5 |
| Total V | 624 | 635 | 750 | 750 | 750 |
| Refresco | 59.85 Hz | 59.99 Hz | 60.00 Hz | 50.00 Hz | 30.00 Hz |
| Polaridad HSYNC / VSYNC | − / + | − / − | + / + | + / + | + / + |
| Lectura del LTDC en RGB565 | 73.5 MB/s | 73.7 MB/s | 110.6 MB/s | 92.2 MB/s | 55.3 MB/s |

Origen de los números: la columna CVT es la salida de `cvt 1024 600 60` (de memoria, VERIFICAR); la columna de 51.2 MHz usa los tiempos horizontales de VESA 1024x768@60 con el vertical ajustado a 635 líneas (es una combinación propia, no un estándar); las de 720p son CEA‑861.

Valores para CubeMX / `LTDC_InitTypeDef` (ya restado el 1):

| Campo | 1024x600 CVT | 1024x600 a 51.2 | 720p60 | 720p50 | 720p30 |
|---|---|---|---|---|---|
| `HorizontalSync` | 103 | 135 | 39 | 39 | 39 |
| `AccumulatedHBP` | 247 | 295 | 259 | 259 | 259 |
| `AccumulatedActiveW` | 1271 | 1319 | 1539 | 1539 | 1539 |
| `TotalWidth` | 1311 | 1343 | 1649 | 1979 | 3299 |
| `VerticalSync` | 9 | 5 | 4 | 4 | 4 |
| `AccumulatedVBP` | 20 | 31 | 24 | 24 | 24 |
| `AccumulatedActiveH` | 620 | 631 | 744 | 744 | 744 |
| `TotalHeigh` | 623 | 634 | 749 | 749 | 749 |
| `HSPolarity` | `AL` | `AL` | `AH` | `AH` | `AH` |
| `VSPolarity` | `AH` | `AL` | `AH` | `AH` | `AH` |

Para todos los modos:

- `DEPolarity = LTDC_DEPOLARITY_AL`. En los ejemplos de ST ese valor produce un DE activo en alto en el pin, que es lo que espera el TFP410. Es contraintuitivo: **VERIFICAR con osciloscopio** (DE debe estar en alto durante los píxeles visibles).
- `PCPolarity`: el TFP410 se configura para capturar en el flanco de subida (strap EDGE = 1), así que el LTDC debe cambiar los datos en el flanco de bajada. Probar `LTDC_PCPOLARITY_IPC` primero y, si hay píxeles con ruido, `LTDC_PCPOLARITY_IIPC`. La placa deja además el strap EDGE seleccionable con dos resistencias (una montada).
- Capa 1: `LTDC_PIXEL_FORMAT_RGB565`, ventana completa, `FBStartAdress = 0xD0000000`, alfa constante 255.
- Activar la interrupción de errores del LTDC y contar los *FIFO underrun*: es el indicador directo de que la SDRAM no alcanza.

Otros modos estándar por si el monitor no acepta 1024x600: 800x600@60 VESA (40 MHz; HFP 40, HSYNC 128, HBP 88; VFP 1, VSYNC 4, VBP 23; + / +; lectura de 57.9 MB/s) y 1024x768@60 VESA (65 MHz; HFP 24, HSYNC 136, HBP 160; VFP 3, VSYNC 6, VBP 29; − / −; 94.4 MB/s). Cualquier cambio de resolución implica cambiar `NODO_ANCHO` / `NODO_ALTO`.

### 5.2 SDRAM (IS42S16160J‑6/‑7 o W9825G6KH‑6) a 100 MHz

Organización: 4 bancos × 13 bits de fila × 9 bits de columna × 16 bits = 32 MB.

Números tomados de la hoja de datos del **Winbond W9825G6KH, revisión A04 del 20 de marzo de 2017**, sección 9.5 (tabla de características de CA), columna del grado **‑6**. Es la pieza con código LCSC confirmado (C62246) y la que conviene comprar. Ya no son cifras de memoria.

| Campo en CubeMX | Parámetro | W9825G6KH‑6 (hoja de datos) | Ciclos a 100 MHz | Ciclos a 80 MHz |
|---|---|---|---|---|
| `LoadToActiveDelay` | tMRD (en la hoja: **tRSC**) | 2 tCK | 2 | 2 |
| `ExitSelfRefreshDelay` | tXSR | **72 ns** | **8** ← corregido | 6 |
| `SelfRefreshTime` | tRAS | 42 ns mínimo (100 µs máximo) | 5 | 4 |
| `RowCycleDelay` | tRC | **60 ns** | **6** | 5 |
| `WriteRecoveryTime` | tWR | 2 tCK | **3** | **3** |
| `RPDelay` | tRP | **15 ns** | 2 | 2 |
| `RCDDelay` | tRCD | **15 ns** | 2 | 2 |
| `CASLatency` | CL | 3 hasta 166 MHz; 2 hasta 133 MHz | 3 (cabe 2) | 3 (cabe 2) |

Notas:

- **Error que traía la tabla anterior: `ExitSelfRefreshDelay` estaba en 7 ciclos.** Venía de suponer tXSR = 70 ns; el valor real del ‑6 es **72 ns**, y 72 / 10 = 7.2, que al techo son **8 ciclos**. Con 7 el controlador sacaría a la memoria del auto‑refresco antes de tiempo. Es un fallo silencioso y difícil de diagnosticar, porque solo aparece al salir de modos de bajo consumo, no en el arranque ni en la prueba de memoria. A 80 MHz (12.5 ns) sí daban 6 ciclos, así que ahí el número ya estaba bien.
- `RowCycleDelay` baja de 7 a 6 ciclos con el tRC real de 60 ns. 7 también funciona (solo es más lento), así que no es un fallo, pero 6 es el valor correcto.
- `WriteRecoveryTime` va en 3 y no en 2 porque el manual de referencia pide tWR ≥ tRAS − tRCD y tWR ≥ tRC − tRCD − tRP. La hoja de datos de la memoria pide solo 2 tCK; manda el valor mayor.
- La hoja de datos **no usa los nombres tMRD ni tDPL**: el retardo de carga del registro de modo se llama **tRSC** (2 tCK) y la recuperación de escritura **tWR** (2 tCK). Son los mismos parámetros con otro nombre.
- **El grado importa.** El ‑6 da los números de arriba; el ‑75 (más lento y más barato) sube a tRC 65 ns, tRAS 45 ns, tRCD 20 ns, tRP 20 ns y tXSR 75 ns, lo que a 100 MHz deja tRCD y tRP en 2 ciclos todavía, tRC en 7 y tXSR en 8. El ‑6I/‑6J/‑6L sube tRCD y tRP a 18 ns (siguen siendo 2 ciclos a 100 MHz) y tXSR se queda en 72. **Si se compra algo que no sea ‑6, revisar esta tabla otra vez.** Para el IS42S16160J de ISSI, que es la segunda opción del BOM, no pude leer la hoja de datos (el sitio de ISSI bloquea la descarga automática): si se acaba comprando esa pieza, hay que repetir esta tabla con su PDF.
- Organización confirmada en la hoja de datos: «4,194,304 Words × 4 Banks × 16 Bits», con la matriz de celdas en 8192 × 512 × 16, es decir **13 bits de fila y 9 bits de columna**, que es lo que ya decía este documento.
- Refresco confirmado: **8192 ciclos cada 64 ms** de 0 a 70 °C. Ojo con el grado: el ‑6J (rango de −40 a 105 °C) baja a 8192 ciclos cada **16 ms**, o sea cuatro veces más seguido, y el auto‑refresco interno no está soportado arriba de 85 °C.
- Consumos del ‑6, por si sirven para el presupuesto de corriente: 60 mA operando un banco, 80 mA en ráfaga, 75 mA en auto‑refresco, 25 mA en reposo con CKE alto y 2 mA máximo en auto‑refresco.
- Oportunidad que sale de esto: a 100 MHz **cabe CAS latency 2** (el ‑6 admite CL2 hasta 133 MHz, con tCK mínimo de 7.5 ns). Bajar de CL3 a CL2 ahorra un ciclo en cada lectura, que es justo lo que más se nota con el LTDC leyendo el *framebuffer* de corrido. Vale la pena probarlo **después** de que la prueba de memoria pase con CL3, cambiando el registro de modo de 0x0230 a 0x0220.
- Resto de la configuración: banco 2 (`FMC_SDRAM_BANK2`), 9 bits de columna, 13 de fila, 16 bits de datos, 4 bancos internos, `SDClockPeriod = 2`, `ReadBurst = ENABLE`, `ReadPipeDelay = 0` (subir a 1 si la prueba de memoria falla), protección de escritura desactivada.
- En el banco 2, tRP y tRC se toman del registro del banco 1; el HAL lo hace solo.
- Refresco: 8192 filas cada 64 ms → 7.81 µs por fila. Contador = 7.81 µs × f − 20: **761 a 100 MHz**, 605 a 80 MHz.
- Secuencia de arranque (no la genera CubeMX; hay que escribirla): habilitar reloj → esperar 1 ms → PALL → 8 auto‑refrescos → cargar registro de modo → programar el refresco. Registro de modo = **0x0230** (ráfaga de 1, secuencial, CAS 3, escritura simple). Los comandos se mandan con `FMC_SDRAM_CMD_TARGET_BANK2`.

## 6. Ancho de banda de la SDRAM: ¿alcanza?

Techo teórico de una SDRAM de 16 bits a 100 MHz: 200 MB/s. En la práctica, entre refrescos, cambios de fila, arbitraje del bus AXI y cambios de lectura a escritura, lo aprovechable ronda el 60‑75 %: **entre 120 y 150 MB/s (estimado, sin medir)**.

Tráfico por cuadro de video con el firmware actual (JPEG 4:2:0, todo en SDRAM):

| Concepto | 1024x600 | 1280x720 |
|---|---|---|
| JPEG de entrada (se escribe al recibir y se lee al decodificar) | ~0.3 MB | ~0.4 MB |
| YCbCr que escribe el decodificador | 0.93 MB | 1.38 MB |
| YCbCr que lee el DMA2D | 0.93 MB | 1.38 MB |
| RGB565 que escribe el DMA2D | 1.23 MB | 1.84 MB |
| **Total por cuadro** | **~3.4 MB** | **~5.0 MB** |

| Caso | LTDC | Video | Total | Veredicto |
|---|---|---|---|---|
| 1024x600 a 60 Hz, video a 15 fps | 74 | 51 | 125 MB/s | En el límite |
| 1024x600 a 60 Hz, video a 30 fps | 74 | 102 | 176 MB/s | **No alcanza** (habrá *underrun* del LTDC o el video bajará solo de velocidad) |
| 720p60, video a 15 fps | 111 | 75 | 186 MB/s | **No alcanza** |
| 720p60, video a 30 fps | 111 | 150 | 261 MB/s | **Imposible** |

El protocolo con acuses ayuda: si el nodo va lento, quien manda baja los cuadros por segundo. Pero el LTDC no puede esperar; si no recibe sus píxeles a tiempo la imagen parpadea o se corre.

**Cambio de firmware recomendado (no lo hice; no estaba en el encargo): sacar el YCbCr de la SDRAM.** Decodificar por franjas (por ejemplo 16 o 32 líneas) hacia un búfer en la SRAM interna AXI (512 KB en 0x24000000) y convertir cada franja con el DMA2D conforme sale. El HAL del JPEG ya trabaja por trozos con `HAL_JPEG_DataReadyCallback`. Con eso la SDRAM solo ve el JPEG de entrada y la escritura RGB565:

| Caso (YCbCr en RAM interna) | LTDC | Video | Total | Veredicto |
|---|---|---|---|---|
| 1024x600 a 60 Hz, 30 fps | 74 | 46 | 120 MB/s | Alcanza, justo |
| 720p60, 30 fps | 111 | 67 | 178 MB/s | No alcanza |
| 720p60, 15 fps | 111 | 34 | 145 MB/s | En el límite; no lo recomiendo |
| 720p50, 25 fps | 92 | 56 | 148 MB/s | En el límite |
| **720p30, 30 fps** | 55 | 67 | 122 MB/s | **Alcanza, justo** |
| 800x600 a 60 Hz, 30 fps | 58 | 38 | 96 MB/s | Holgado |

Conclusión:

- **1024x600@60 con doble búfer RGB565 funciona en el hardware, pero a 30 fps exige el cambio de firmware.** Con el firmware actual hay que esperar unos 12‑15 fps.
- **1280x720@60 no cabe** en una SDRAM de 16 bits con esta arquitectura. El hardware (TFP410, reloj de 74.25 MHz, pines) sí lo soporta; el límite es la memoria.
- **La vía realista a 720p es 720p30 (CEA VIC 62) o 720p50 (VIC 19)**, mismo reloj de 74.25 MHz y menos lecturas por segundo. La mayoría de las teles aceptan 720p50; 720p30 es menos universal. Hay que probarlo con la tele real.
- Lo que no ayuda: una SDRAM más grande (el problema es velocidad, no capacidad). Lo que sí ayudaría y no se puede en LQFP176: bus de 32 bits.

## 7. MPU

Llamar a `MPU_Config()` antes de `HAL_Init()` y antes de habilitar las cachés. Números de región mayores tienen prioridad.

| Región | Base | Tamaño | Permisos | TEX / C / B / S | Para qué |
|---|---|---|---|---|---|
| 0 | 0x00000000 | 4 GB, `SubRegionDisable = 0x87` | Sin acceso, XN | 0 / 0 / 0 / 1 | Fondo: impide lecturas especulativas del Cortex‑M7 hacia zonas sin memoria (el FMC sin inicializar, por ejemplo). Es el patrón de los ejemplos de ST |
| 1 | 0xD0000000 | 32 MB | Acceso total, XN | 0 / 1 / 0 / 0 | SDRAM: con caché de lectura y escritura directa (*write‑through*) |
| 2 | 0x30020000 | 128 KB | Acceso total, XN | 1 / 0 / 0 / 0 | SRAM2 (D2): *heap* de LwIP, sin caché |
| 3 | 0x30040000 | 32 KB | Acceso total, XN | 1 / 0 / 0 / 0 | SRAM3 (D2): búferes de recepción de Ethernet, sin caché |
| 4 | 0x30040000 | 256 B (1 KB si los descriptores no caben) | Acceso total, XN | 0 / 0 / 1 / 1 | Descriptores DMA de Ethernet: memoria tipo dispositivo |

### 7.1 SDRAM

- En los búferes de imagen escriben el DMA2D y la CPU, y leen el LTDC y el DMA2D. Con *write‑through* lo que escribe la CPU llega de inmediato a la SDRAM, así que nunca queda una línea de caché sucia que más tarde pise lo que escribió el DMA2D.
- Las llamadas a `SCB_CleanDCache_by_Addr` de `pantalla_stm32.c` siguen siendo correctas y con esta configuración no cuestan casi nada.
- Regla para el futuro: si la CPU llega a **leer** algo que escribió el DMA2D (el framebuffer, por ejemplo), antes hay que invalidar con `SCB_InvalidateDCache_by_Addr`. El firmware actual no lo hace nunca, así que hoy no aplica.
- Si aparecen errores raros de imagen, la prueba de descarte es poner la región como no cacheable (TEX 1, C 0, B 0).

### 7.2 Ethernet (el problema clásico del H7 con LwIP)

El DMA del MAC no puede acceder a la DTCM (0x20000000) y no sabe nada de la caché de la CPU. Reglas:

1. **Descriptores** en SRAM3. En el *linker script*: `.RxDecripSection` en 0x30040000 y `.TxDecripSection` en 0x30040060 (son los nombres y direcciones que usa el código generado por CubeMX; VERIFICAR con la versión instalada).
2. **Búferes de recepción** (`.Rx_PoolSection` o `.RxArraySection`, según la versión de CubeMX) en 0x30040200, dentro de la región 3. Con 12 búferes de 1536 bytes ocupan unos 18 KB.
3. **Heap de LwIP en SRAM2**: en CubeMX, `LWIP_RAM_HEAP_POINTER = 0x30020000` y `MEM_SIZE` de 32 KB o más. Es obligatorio aquí porque `puente_lwip.c` usa `tcp_write` con `TCP_WRITE_FLAG_COPY` y `pbuf_alloc(PBUF_RAM)`: los datos que salen viven en el *heap* y el DMA los lee directamente.
4. Habilitar los relojes de las SRAM de D2 (`__HAL_RCC_D2SRAM1_CLK_ENABLE()`, `…SRAM2…`, `…SRAM3…`) antes de usarlas. VERIFICAR si el arranque generado ya lo hace.
5. Agregar las secciones al *linker script* con `NOLOAD` y revisar el archivo `.map`: los descriptores deben quedar exactamente en 0x30040000.
6. Síntomas de que algo de esto falta: el nodo responde al *ping* unos segundos y se queda mudo, o recibe pero nunca transmite.

Los cuadros JPEG se copian de los *pbuf* a la SDRAM con la CPU (`pn_alimentar`), así que no hay DMA de Ethernet hacia la SDRAM y no hace falta nada más.

### 7.3 Otros ajustes de CubeMX que dependen de la placa

- GPIO: velocidad *Very High* en FMC y RMII, *High* en LTDC. Habilitar la celda de compensación de E/S (`HAL_EnableCompensationCell()` con el reloj CSI encendido), necesaria para ir a 100 MHz con 3.3 V.
- PHY: dirección 0 (strap PHYAD0 en bajo), controlador LAN8742 de CubeMX, modo RMII.
- Los pines del LTDC, el FMC y el RMII deben quedar en CubeMX **exactamente** como en `pines.csv`: CubeMX propone por defecto pines que aquí chocan (por ejemplo PG11/PG13 para el RMII o PA3/PA4/PA6 para el LTDC).
- DIP: PF6‑PF9 como entradas con *pull‑up*. LED: PB0 como salida.

## 8. Reglas de PCB

### 8.1 Apilado (4 capas, 1.6 mm)

| Capa | Uso |
|---|---|
| L1 (arriba) | Componentes y señales rápidas: TMDS, RMII, la mayor parte de SDRAM y LTDC |
| L2 | **GND sólido**, sin cortes bajo las señales rápidas |
| L3 | +3V3 como plano, con islas para +5V y VDDA; algunas señales lentas |
| L4 (abajo) | Señales restantes y desacoplos bajo el MCU, rellenado con GND |

Recomiendo un apilado de JLCPCB con dieléctrico delgado entre L1 y L2 (del tipo JLC04161H‑3313, alrededor de 0.1 mm): las pistas de impedancia controlada salen delgadas y caben entre los pines de 0.5 mm. Con el apilado 7628 (alrededor de 0.2 mm) una pista de 50 Ω mide cerca de 0.35 mm y no pasa.

**Los anchos siguientes son aproximados y de memoria: calcularlos con la calculadora de impedancia de JLCPCB para el apilado exacto y pedir el servicio de impedancia controlada. VERIFICAR.**

| Tipo | Objetivo | Geometría aproximada con prepreg de ~0.1 mm |
|---|---|---|
| TMDS (4 pares) | 100 Ω diferencial ±10 % | pista ~0.13 mm, separación ~0.20 mm |
| MDI del Ethernet (TX±, RX±) | 100 Ω diferencial | igual |
| RMII, SDRAM, LTDC | 50 Ω (tolerante) | pista ~0.15‑0.17 mm |
| USB D+/D− (si se monta) | 90 Ω diferencial | calcular |

### 8.2 TMDS (TFP410 → TPD12S016 → HDMI)

- TFP410 a menos de 30 mm del conector, con el TPD12S016 pegado al conector y las pistas pasando en línea recta por sus pines.
- Todo en L1 sobre GND continuo, sin vías y sin ramales.
- Dentro de cada par, diferencia de largo menor de 0.5 mm; entre pares, menor de 5 mm. A 74.25 MHz de píxel son 742.5 Mbit/s por par: hay margen, pero conviene hacerlo bien.
- Separación entre pares de al menos 3 veces el ancho de pista. Vías de GND alrededor del conector.
- Las señales del LTDC no deben correr paralelas a los pares TMDS.
- La resistencia de TFADJ pegada al TFP410.
- Pad térmico del TFP410 a GND con 9 vías o más.

### 8.3 RMII (MCU ↔ LAN8742A)

- Largo total menor de 50 mm y parecido entre señales (±10 mm es suficiente a 50 MHz).
- Resistencias serie de 33 Ω junto al emisor: en REFCLKO, RXD0, RXD1 y CRS_DV del lado del PHY. En TXD0, TXD1 y TX_EN dejar huellas de 0402 del lado del MCU, montadas con 0 Ω o 22 Ω.
- REF_CLK lejos de los cristales y de las pistas MDI.
- Cristal del PHY a menos de 5 mm de sus pines, con anillo de GND.

### 8.4 Zona de magnéticos (RJ45)

- Bajo el conector con magnéticos integrados **no va ningún plano ni pista en ninguna capa**, salvo los pares MDI que entran.
- Pares TX± y RX±: 100 Ω, menos de 40 mm, cuatro resistencias de 49.9 Ω junto al PHY.
- Blindaje del RJ45 a una isla de chasis, unida a GND por 1 nF / 2 kV en paralelo con 1 MΩ.
- RBIAS (12.1 kΩ, 1 %) pegada al PHY y lejos de señales que conmutan.

### 8.5 SDRAM

- SDRAM a menos de 25 mm del MCU, del lado donde quede más corto el conjunto de datos y direcciones. Los pines del FMC están repartidos por los cuatro lados del LQFP176, así que habrá vías; es normal.
- Largo máximo de cualquier señal: 50 mm. Igualar todo en ±5 mm (a 100 MHz equivale a unos 30 ps, de sobra). El reloj, igual o un poco más largo que el grupo.
- SDCLK: resistencia serie de 22 Ω junto al pin PG8, pista sin vías si se puede y separada de las demás.
- Sin terminaciones en datos ni direcciones (una sola carga).
- Un capacitor de 100 nF por cada pin de alimentación de la SDRAM (7) más 10 µF.

### 8.6 LTDC (MCU → TFP410)

- 28 señales a 50‑75 MHz. Largo menor de 60 mm, igualado en ±10 mm respecto al reloj.
- Resistencia serie de 22 Ω en LCD_CLK junto a PG7. En los datos no hace falta; si hay problemas de emisiones, bajar la velocidad de los GPIO a *Medium*.
- Colocar el TFP410 de modo que los buses rojo (PH8‑PH12, pines 85‑89) y verde (PH13‑PI2, pines 128‑133) lleguen sin cruzarse. Los pines del LTDC están en los cuatro lados; planear la orientación de U1 antes de rutear.

### 8.7 Desacoplos y alimentación

- MCU: 100 nF en **cada** pin VDD (14) lo más cerca posible, de preferencia por abajo con vía directa a los planos; 2 × 10 µF de volumen.
- **VCAP1 (pin 81) y VCAP2 (pin 125): 2.2 µF cada uno**, de baja ESR, a menos de 3 mm del pin y con retorno corto a GND. No conectarlos a 3.3 V ni entre sí con pistas largas.
- VDDA/VREF+: ferrita, 1 µF y 100 nF junto a los pines 38 y 39; VSSA al plano de GND junto al chip.
- Buck: lazo de entrada (capacitor de entrada, integrado, GND) mínimo; inductor pegado; la realimentación se toma del capacitor de salida y se lleva lejos del inductor. Colocarlo lejos del PHY y del TFP410.
- PVDD y TVDD del TFP410 y VDD1A/VDD2A del PHY: cada uno con su ferrita y sus capacitores de 100 nF y 10 µF.
- Cristales: pistas cortas, anillo de GND, nada ruteado debajo en L1.
- Puntos de prueba: +5V, +3V3, VCAP1, GND (varios), LCD_CLK, SD_CLK, RMII_REF_CLK, NRST, TP_MCO.

## 9. Riesgos y orden de pruebas

### 9.1 Riesgos, de mayor a menor

| # | Riesgo | Efecto | Cómo se reduce |
|---|---|---|---|
| 1 | El ancho de banda de la SDRAM no alcanza (sección 6) | Parpadeo o pocos cuadros por segundo | Decodificar por franjas con YCbCr en RAM interna; empezar con 800x600 o con 720p30 |
| 2 | El monitor o la tele no acepta 1024x600 | "Sin señal" | Probar con la pantalla real; tener listos los modos 720p y 800x600; leer el EDID por I2C1 |
| 3 | Pinout o straps del TFP410, del TPD12S016 o del conector HDMI mal capturados (este documento los da de memoria) | Sin imagen o colores cambiados | Revisar `conexiones.md` contra las hojas de datos antes de rutear; revisión cruzada del esquemático |
| 4 | Polaridad de reloj y de DE entre LTDC y TFP410 | Píxeles con ruido, imagen corrida | Strap EDGE con dos huellas; `PCPolarity` configurable; osciloscopio |
| 5 | Integridad de señal de la SDRAM a 100 MHz en 4 capas con LQFP176 | Errores de memoria intermitentes | Prueba de memoria larga; plan B a 80 MHz; `ReadPipeDelay`; resistencia en SDCLK |
| 6 | Ethernet del H7: MPU, descriptores y caché | La red se cuelga | Resolverlo primero en la Nucleo (paso 1) |
| 7 | Straps del LAN8742A (modo REF_CLK Out, regulador, dirección) | Sin 50 MHz, sin enlace | Seguir el esquema de la Nucleo‑H743ZI2 (UM2407); punto de prueba en REF_CLK |
| 8 | Alimentación: caída de VBUS con cable largo, arranque del buck, calor | Reinicios | Medir el rizado y la caída con carga; cargador de 1 A o más |
| 9 | Chip de revisión Y (máximo 400 MHz) | No arranca a 480 MHz | Arrancar a 400 MHz; leer la revisión con `HAL_GetREVID()` |
| 10 | Abasto: TFP410 y H743IIT6 se agotan seguido | Retraso | Revisar existencias antes de cerrar el diseño; comprar antes de mandar la placa |
| 11 | Soldadura del LQFP176 y del pad del TFP410 | Cortos, pines al aire | Ensamble en JLCPCB; inspección con lupa |

### 9.2 Orden de pruebas

**Antes de fabricar (placas de desarrollo):**

1. **Nucleo‑H743ZI2 — red.** Proyecto CubeMX con ETH RMII, LwIP sin RTOS y el MPU de la sección 7.2. Usar `puente_nodo.c` y `puente_lwip.c` con una `pantalla` falsa que solo cuente cuadros y mida tamaños. Debe aguantar una hora recibiendo video de la PC sin colgarse. Esto cierra el riesgo 6 y valida el protocolo en hardware real. (La Nucleo usa PG11/PG13/PB13 para la transmisión del RMII; en la placa propia son PB11/PB12/PB13.)
2. **Nucleo‑H743ZI2 — JPEG y DMA2D sin pantalla.** Decodificar JPEG pequeños (por ejemplo 320x240) a la SRAM AXI, convertir con DMA2D y comparar una suma de verificación contra la calculada en la PC. Aquí mismo se desarrolla y se prueba la decodificación por franjas.
3. **Placa con LTDC y SDRAM** (STM32H743I‑EVAL, STM32H750B‑DK, STM32H745I‑DISCO o una placa china con H743IIT6 y SDRAM; VERIFICAR cuál se consigue). Sirve para medir el punto crítico: LTDC leyendo de SDRAM mientras el DMA2D escribe, contando los *FIFO underrun*. Aunque la pantalla de esas placas sea pequeña, se puede programar el LTDC con los tiempos de 1024x600 solo para medir la carga del bus.
4. **TFP410**: no hay módulos baratos y no conviene cablear 28 señales de 50 MHz con jumpers. Se prueba en la propia placa. Para bajar el riesgo: revisar el esquemático contra la hoja de datos y contra un diseño de referencia de TI.

**Con la primera placa (en este orden; cada paso se pasa antes de seguir):**

1. Sin integrados caros montados, si es posible: 5 V, 3.3 V, rizado, ausencia de cortos. Consumo en vacío.
2. SWD: el ST‑Link reconoce el chip. Medir VCAP (alrededor de 1.2 V). Parpadear el LED en PB0 con el HSI.
3. HSE y PLL: sacar el reloj por MCO1 (PA8) y medirlo. Primero 400 MHz, después 480.
4. UART de depuración y lectura del DIP (PF6‑PF9).
5. SDRAM: prueba de memoria de los 32 MB (patrón de direcciones y patrón pseudoaleatorio), 100 pasadas, a 80 MHz y luego a 100 MHz, con las cachés apagadas y encendidas.
6. LTDC y TFP410: barras de color a 800x600@60 (el modo más tolerante). Revisar colores (rojo, verde y azul en su lugar), bordes y estabilidad. Luego 1024x600 y 720p con la pantalla de destino. Leer el EDID.
7. Ethernet: enlace, DHCP, *ping* sostenido, anuncio UDP visible en la PC.
8. Cadena completa con cuadros fijos y luego con video. Medir cuadros por segundo y contar *underrun*.
9. Prueba larga (varias horas) con la caja cerrada: temperatura del MCU, del TFP410 y del buck.
10. Varios nodos en un switch con números de DIP distintos.

## 10. Pendientes que no resuelve este documento

- Capturar el esquemático y la PCB en KiCad (aquí solo está la netlist en texto).
- Confirmar lo que todavía lleva VERIFICAR: DS12110 y RM0433 (consumos, frecuencia máxima de SDCLK y de LTDC_CLK, latencia de flash), UM2407 (esquemático de la Nucleo‑H743ZI2), hoja de datos del HR911105A y la del conector HDMI que se compre. **Las hojas del TFP410, del TPD12S016, del LAN8742A y de la SDRAM ya se revisaron**: ver la sección 11.
- Cambio de firmware de la sección 6 (decodificación por franjas) y la secuencia de arranque de la SDRAM, que tampoco está en el firmware actual.
- Audio: el TFP410 es DVI, no lleva audio. Si algún día hace falta, hay que cambiar de transmisor.

---

## 11. Revisión de hojas de datos (etapa 6 del `nodo/PLAN.md`, puntos 1 a 4)

Hecha en noviembre de 2026, leyendo los PDF completos. Aquí queda el registro de qué se confirmó, qué
estaba mal y qué sigue abierto, para no tener que volver a leer lo mismo. Documentos usados:

| Pieza | Documento | De dónde se bajó |
|---|---|---|
| TPD12S016 | SLLSE96F, revisado en octubre de 2015 | `ti.com/lit/ds/symlink/tpd12s016.pdf` |
| TFP410 | SLDS145D, revisión D de febrero de 2024 | `ti.com/lit/ds/symlink/tfp410.pdf` |
| LAN8742A | DS00001989A (2013‑2015) | espejo de Mouser; `microchip.com` rechaza la descarga automática |
| W9825G6KH | revisión A04 del 20 de marzo de 2017 | espejo de Mouser; `winbond.com` rechaza la descarga automática |
| PowerPAD | SLMA002H, julio de 2018 | `ti.com/lit/an/slma002j/slma002j.pdf` |
| STM32H743 | DS12110 **Rev 11, enero de 2026** | `st.com/resource/en/datasheet/stm32h743ii.pdf` |

### 11.1 Lo que estaba mal y ya se corrigió

Cuatro cosas, en orden de gravedad:

1. **`ExitSelfRefreshDelay` de la SDRAM estaba en 7 ciclos y debe ser 8** (sección 5.2). tXSR del
   W9825G6KH‑6 son 72 ns, no 70. Es el hallazgo que más valía la pena: habría fallado solo al salir de
   un modo de bajo consumo, no en el arranque ni en la prueba de memoria, que es la clase de falla que
   cuesta semanas encontrar.
2. **El pin RESERVED del TFP410 (34) tiene que ir a `GND`** y estaba cayendo en el renglón de «pines NC,
   sin conectar». La hoja de datos dice «must be tied to GND for normal operation». Es un error que no se
   arregla con firmware una vez fabricada la placa.
3. **Los dos LED del RJ45 no los puede manejar el PHY.** Ver 11.2.
4. **MSEN del TFP410 pide 5 kΩ, no 10 kΩ**, porque es una salida de colector abierto. Y falta una
   **R de 500 Ω 1 % en serie con XTAL2** del LAN8742A, que la hoja de datos exige para el cristal de
   100 µW que corresponde a los capacitores de 12 pF del diseño.

### 11.2 El cambio de diseño: los LED del RJ45

Este nodo necesita el LAN8742A en modo *REF_CLK Out* (que el PHY genere los 50 MHz con su propio cristal,
para no poner un oscilador de 50 MHz en la placa) y con el regulador interno de 1.2 V encendido. Los dos
straps que eligen eso, nINTSEL y REGOFF, están compartidos con los pines LED2 y LED1, y los niveles que
hacen falta son los dos en bajo. Confirmado que esos son los niveles correctos, con la cita textual en
`conexiones.md`. El problema es que la hoja de datos, en las dos secciones, recomienda **no colgar un LED**
a un pin cuyo strap quedó en bajo: el LED con su resistencia en serie altera el nivel que se enclava al
salir de reset.

El diseño anterior sacaba el LED de link y el de velocidad justo de esos dos pines. La solución adoptada es
**manejar los dos LED del RJ45 desde dos GPIO del H743** (quedan 40 pines libres) y que el firmware los
encienda con lo que ya sabe del PHY por MDIO. No cuesta nada en la placa, y de hecho da más control: el
firmware puede usarlos para avisar del estado del nodo, no nada más del enlace. **Pendiente concreto: elegir
los dos pines y anotarlos en `pines.csv`.**

### 11.3 Lo que se confirmó tal como estaba

Vale anotarlo, porque son las partes del diseño que ya no hay que volver a mirar:

- **Pines TMDS del TPD12S016 (lo que bloqueaba el ruteo)**: reloj en 15/16, D2 en 17/18, D1 en 20/21,
  D0 en 22/23, con `GND` en el 19. Siguen el orden del conector HDMI, así que los pares no se cruzan.
- **Los 22 números de pin del LAN8742A** que `conexiones.md` daba «de memoria» están **todos bien**.
- **Orden rojo/verde/azul del TFP410**: DATA[23:16] rojo, DATA[15:8] verde, DATA[7:0] azul. La suposición
  era correcta, así que el mapa de los 24 pines del LTDC no se mueve.
- **IDCK− a `GND`** para reloj de una sola terminal, textual en la hoja de datos.
- **VREF a `+3V3`**, **TFADJ 510 Ω 1 %** (rango 505‑515), **RBIAS 12.1 kΩ 1 %**, **ISEL bajo**, **BSEL alto**,
  **DKEN bajo**: todo confirmado.
- **Los *pull‑up* de DDC ya están dentro del TPD12S016**: 10 kΩ a VCCA del lado del MCU y 1.75 kΩ a 5 V del
  lado del conector. Las resistencias externas de 10 kΩ se quitan (huellas sin montar). CEC_A se deja al
  aire, también tiene *pull‑up* interno.
- **Unir CT_HPD y LS_OE al mismo nodo es lo correcto**: la combinación LS_OE alto con CT_HPD bajo está
  marcada como estado no válido, y atados nunca puede darse.
- **Organización y refresco de la SDRAM**: 13 bits de fila, 9 de columna, 8192 ciclos cada 64 ms.
- **El reloj de píxel nunca fue un problema** (punto 5): `LTDC_CLK` llega a 150 MHz, el doble y medio de lo que pide el modo objetivo.
- **La configuración de relojes de la sección 4.3 era la correcta**: los 100 MHz de SDCLK caben en el límite de 110 MHz y los 120 MHz que saldrían de HCLK/2 no. El documento ya los descartaba por intuición; ahora hay número.

### 11.5 Punto 5 de la etapa 6 (DS12110), hecho aparte

Se hizo en la misma sesión, después de los puntos 1 a 4. Lo que salió:

- **`FMC_SDCLK` máximo = 110 MHz** a 3.3 V con 20 pF (sección 7.3.17). Los 100 MHz del diseño caben con 10 % de margen; los 120 MHz de HCLK/2 están **fuera de especificación**. Ver la sección 4.3.
- **`LTDC_CLK` máximo = 150 MHz** a 3.3 V (tabla 190). No es restricción por ningún lado. Ver la sección 4.4.
- **Consumo real del MCU**: 220 mA típicos y 546 mA máximos a 105 °C en modo Run a 480 MHz con todo encendido (tabla 121). El típico salió mejor de lo estimado, el máximo 100 mA peor. Presupuesto de la sección 2 actualizado; el buck de 2 A sigue sobrado.
- ⚠️ **A 480 MHz la temperatura de unión máxima baja de 125 a 105 °C** (tabla 112, nota 5). Para un nodo metido en una caja detrás de una pantalla, en una pared donde las pantallas se calientan entre sí, esos 20 °C pesan más que la diferencia de velocidad, que aquí no se nota. **Refuerza la recomendación de arrancar y quedarse en 400 MHz.**
- **Los 480 MHz solo existen en la revisión V del silicio**: confirmado porque la hoja de datos tiene secciones eléctricas separadas para las revisiones Y y V, y los 480 MHz aparecen solo en la de la V.
- **La latencia de flash no está en DS12110**, está en RM0433. Es el único dato del punto 5 que no se pudo cerrar, y de todas formas lo calcula CubeMX.

### 11.4 Lo que sigue abierto

| Qué | Por qué no se cerró | Quién lo cierra y cuándo |
|---|---|---|
| Tamaño del pad térmico del TFP410PAP | El dibujo mecánico del PDF (plano 4226442/A de TI) no se puede extraer como texto, y la nota de aplicación de PowerPAD no trae tabla por encapsulado. Lo que sí dice SLMA002H: para encapsulados TQFP el cobre máximo es «el tamaño del cuerpo menos 2.0 mm», o sea **8 × 8 mm para un cuerpo de 10 × 10 mm**, que es exactamente lo que usa la huella oficial de KiCad. Eso da confianza en la huella; falta el número de la abertura de la máscara (4.4 × 4.4 mm en la huella de KiCad). | José Antonio, abriendo la hoja de datos del TFP410 en la sección 10 (dibujo mecánico) y mirando la cota del pad expuesto. Dos minutos con el PDF abierto. |
| Polaridad + / − dentro de cada par de datos del TPD12S016 | El diagrama de pines sale revuelto en la extracción de texto | José Antonio, al capturar el esquemático: se toma del símbolo de KiCad y se compara con la figura de la página 4. El circuito no cambia. |
| Pines y polaridad de los LED del HR911105A | HanRun no publica la hoja de datos en un sitio alcanzable | Al comprar el conector, con la hoja del vendedor; o midiendo con un multímetro en modo diodo. Ya no bloquea nada, porque los LED ahora salen del MCU. |
| Huella del conector HDMI | Depende de la pieza que se compre | Al comprar |
| IS42S16160J de ISSI | El sitio de ISSI bloquea la descarga automática | Solo hace falta si se compra esa pieza en lugar de la Winbond. La tabla de tiempos de la sección 5.2 habría que rehacerla. |
| Puntos 5 a 8 de la etapa 6 (DS12110, códigos LCSC, anchos de pista, existencias) | No se intentaron todavía; el plan dice que van después, cuando ya se vaya a comprar | Siguiente sesión |
