# Nodo Puente Video — librerías de KiCad 8

Librería de proyecto `puente_nodo` para capturar el esquemático y la PCB del nodo (ver `../DISENO.md`, `../pines.csv` y `../conexiones.md`).

**Resultado corto:** casi todo el nodo se arma con las librerías oficiales de KiCad 8. Solo hicieron falta **3 símbolos propios** y **5 huellas con modelo 3D propio** (las huellas son copia exacta de las oficiales; lo único que les faltaba era el modelo 3D).

## 0. Qué está verificado y qué no

- **Verificado por programa** (`herramientas/validar.py`, 121 comprobaciones, 0 fallas; salida completa en `validacion.txt`): cada archivo se lee sin errores con dos analizadores distintos (uno propio y `kiutils`), el número de pines de cada símbolo coincide con los pads de su huella, y el paso y tamaño de pads coinciden con las medidas de la tabla de la sección 4.
- **No verificado: abrir los archivos en KiCad.** En el ambiente donde se generaron no había KiCad instalado ni forma de instalarlo. Los archivos usan solo construcciones que aparecen en las librerías oficiales 8.0.8, pero **la primera prueba real es abrirlos en KiCad 8** (paso 6 de la sección 6). VERIFICAR.
- **De dónde salieron las librerías oficiales:** el espejo de GitHub (`github.com/KiCad/kicad-symbols` y `kicad-footprints`) está congelado en octubre de 2020, en formato de KiCad 5 (`.lib`), y GitLab estaba bloqueado. Se usaron los paquetes fuente `kicad-symbols_8.0.8` y `kicad-footprints_8.0.8` del archivo de Ubuntu, que son las librerías oficiales sin cambios. De `kicad-packages3d_8.0.7` solo se revisó la lista de archivos (pesa 410 MB), para saber qué modelos 3D existen.
- **VERIFICAR** marca todo lo que no se pudo confirmar con una hoja de datos. La lista completa está en la sección 7.

## 1. Archivos

| Archivo | Contenido |
|---|---|
| `puente_nodo.kicad_sym` | 3 símbolos propios |
| `puente_nodo.pretty/` | 5 huellas (copias de las oficiales, con modelo 3D propio) |
| `puente_nodo.3dshapes/` | 5 modelos STEP hechos con CadQuery |
| `sym-lib-table`, `fp-lib-table` | Tablas de librerías del proyecto (rutas con `${KIPRJMOD}`) |
| `previews/*.png` | Vista de cada huella propia con números de pad y medidas; `previews/3d_*.png` es el modelo 3D |
| `validacion.txt` | Salida de la última validación |
| `herramientas/` | Programas que generan y validan todo (sección 8) |
| `LICENCIA-KiCad.md` | Licencia de las librerías de KiCad (CC‑BY‑SA 4.0 con excepción), obligatoria por las huellas copiadas |

## 2. Tabla de partes

"Oficial" = existe en las librerías que instala KiCad 8; no hay que agregar nada. El modelo 3D oficial se llama igual que la huella y vive en `${KICAD8_3DMODEL_DIR}`.

| Ref | Parte | Símbolo | Huella | Modelo 3D | Origen | Medidas usadas |
|---|---|---|---|---|---|---|
| U1 | STM32H743IIT6 | `MCU_ST_STM32H7:STM32H743IITx` (una sola unidad) o `puente_nodo:STM32H743IITx_Nodo` (10 unidades) | `Package_QFP:LQFP-176_24x24mm_P0.5mm` | Oficial | Oficial; símbolo en unidades propio | LQFP176, cuerpo 24 × 24 mm, paso 0.5 mm |
| U2 | IS42S16160J‑6TLI / ‑7TLI | `puente_nodo:IS42S16160J-xTL` (o `Memory_RAM:MT48LC16M16A2P`, mismo pinout) | `Package_SO:TSOP-II-54_22.2x10.16mm_P0.8mm` | Oficial | Símbolo propio, huella oficial | TSOP‑II 54, cuerpo 22.2 × 10.16 mm, paso 0.8 mm. VERIFICAR con la hoja de ISSI |
| U3 | LAN8742A‑CZ | `Interface_Ethernet:LAN8742A` | `puente_nodo:VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias` | **Propio** | Símbolo oficial; huella copiada (el modelo 3D oficial de esta variante no existe) | QFN‑24, 4 × 4 mm, paso 0.5 mm, pad expuesto 2.5 × 2.5 mm (dibujo de Microchip C04‑00143 citado en la huella) |
| U4 | TFP410PAP | `Video:TFP410PAP` | `Package_QFP:HTQFP-64-1EP_10x10mm_P0.5mm_EP8x8mm_Mask4.4x4.4mm_ThermalVias` | Oficial | Oficial | HTQFP‑64, cuerpo 10 × 10 mm, paso 0.5 mm; cobre del pad 8 × 8 mm con abertura de máscara de 4.4 × 4.4 mm. VERIFICAR el tamaño del pad térmico |
| U5 | TPD12S016PWR | `puente_nodo:TPD12S016PW` | `Package_SO:TSSOP-24_4.4x7.8mm_P0.65mm` | Oficial | **Símbolo propio** (no existe oficial), huella oficial | TSSOP‑24, cuerpo 4.4 × 7.8 mm (6.4 mm entre puntas), paso 0.65 mm, JEDEC MO‑153 AD |
| U6 | TLV62569DBVR | `Regulator_Switching:TLV62569DBV` | `Package_TO_SOT_SMD:SOT-23-5` | Oficial | Oficial | SOT‑23‑5. Pines del símbolo: 1 EN, 2 GND, 3 SW, 4 VIN, 5 FB |
| U9 | USBLC6‑2SC6 (opcional) | `Power_Protection:USBLC6-2SC6` | `Package_TO_SOT_SMD:SOT-23-6` | Oficial | Oficial | SOT‑23‑6 |
| J1 | USB‑C 16 pines, TYPE‑C‑31‑M‑12 | `Connector:USB_C_Receptacle_USB2.0_16P` | `puente_nodo:USB_C_Receptacle_HRO_TYPE-C-31-M-12` | **Propio** | Símbolo oficial; huella copiada | Ver sección 4 |
| J2 | RJ45 HanRun HR911105A | `Connector:RJ45_Hanrun_HR911105A_Horizontal` | `puente_nodo:RJ45_Hanrun_HR911105A_Horizontal` | **Propio** | Símbolo oficial; huella copiada | Ver sección 4 |
| J3 | HDMI tipo A | `Connector:HDMI_A` | `puente_nodo:HDMI_A_Amphenol_10029449-x01xLF_Horizontal` | **Propio** | Símbolo oficial; huella copiada | Ver sección 4. VERIFICAR que el conector que se compre sea Amphenol 10029449 o un clon con la misma huella |
| J4 | SWD 2x5, paso 1.27 mm | `Connector:Conn_ARM_JTAG_SWD_10` | `Connector_PinHeader_1.27mm:PinHeader_2x05_P1.27mm_Vertical_SMD` | Oficial | Oficial | Tira 2x5 de paso 1.27 mm. VERIFICAR contra el conector que se compre (los que traen guía de plástico necesitan más espacio) |
| J4 (alterno) | Tag‑Connect TC2030‑NL | `Connector:Conn_ARM_SWD_TagConnect_TC2030-NL` | `Connector:Tag-Connect_TC2030-IDC-NL_2x03_P1.27mm_Vertical` | No lleva (son solo pads) | Oficial | — |
| J5 | UART 1x3 | `Connector_Generic:Conn_01x03` | `Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical` | Oficial | Oficial | Paso 2.54 mm |
| Y1, Y2 | Cristal 25 MHz 3225 | `Device:Crystal_GND24` | `Crystal:Crystal_SMD_3225-4Pin_3.2x2.5mm` | Oficial | Oficial | 3.2 × 2.5 mm, 4 pads; 1 y 3 = cristal, 2 y 4 = GND. VERIFICAR con el cristal comprado |
| L1 | Inductor 2.2 µH | `Device:L` | `Inductor_SMD:L_Changjiang_FNR4030S` (propuesta) | Oficial | Oficial | 4 × 4 × 3 mm. VERIFICAR: en el BOM no hay número de parte; elegir la huella del inductor que se compre |
| F1 | Polifusible 1206 | `Device:Polyfuse` | `Fuse:Fuse_1206_3216Metric` | Oficial | Oficial | 1206 |
| D1 | TVS SMF5.0A | `Diode:SMF5V0A` | `Diode_SMD:D_SMF` | Oficial | Oficial | SMF (SOD‑123FL) |
| SW1, SW2, SW4 | Botón táctil SMD | `Switch:SW_Push` | `puente_nodo:SW_Push_1P1T_XKB_TS-1187A` (propuesta) | **Propio** | Símbolo oficial; huella copiada | Ver sección 4. VERIFICAR: el BOM dice "3x4 o 6x6" sin parte; el TS‑1187A mide 5.1 × 5.1 mm |
| SW3 | DIP de 4 posiciones | `Switch:SW_DIP_x04` | THT: `Button_Switch_THT:SW_DIP_SPSTx04_Slide_9.78x12.34mm_W7.62mm_P2.54mm`; SMD: `Button_Switch_SMD:SW_DIP_SPSTx04_Slide_Omron_A6S-410x_W8.9mm_P2.54mm` | Oficial | Oficial | Paso 2.54 mm, entre filas 7.62 mm (THT) |
| FB1‑FB5 | Ferrita 0603 | `Device:FerriteBead_Small` | `Inductor_SMD:L_0603_1608Metric` | Oficial | Oficial | 0603 |
| D2‑D4 | LED 0603 | `Device:LED` | `LED_SMD:LED_0603_1608Metric` | Oficial | Oficial | 0603 |
| R, C | Pasivos | `Device:R`, `Device:C` | `Resistor_SMD:R_0402_1005Metric`, `Capacitor_SMD:C_0402_1005Metric`, `C_0603_1608Metric`, etc. | Oficial | Oficial | Según el BOM |
| — | Redes de alimentación | `power:+5V`, `power:+3V3`, `power:GND`, etc. | — | — | Oficial | — |

## 3. Símbolos propios (`puente_nodo.kicad_sym`)

### 3.1 `TPD12S016PW` (nuevo)

No existe en la librería oficial. Los pines 1‑14, 19 y 24 están tomados de la tabla *Pin Functions* (encapsulado PW) de la hoja de datos de TI SLLSE96F:

| Pin | Nombre | Tipo en el símbolo | | Pin | Nombre | Tipo en el símbolo |
|---|---|---|---|---|---|---|
| 1 | CEC_A | bidireccional | | 13 | 5V_OUT | salida de alimentación |
| 2 | SCL_A | bidireccional | | 14 | GND | alimentación |
| 3 | SDA_A | bidireccional | | 15 | CLK− **(VERIFICAR)** | pasivo |
| 4 | HPD_A | salida | | 16 | CLK+ **(VERIFICAR)** | pasivo |
| 5 | LS_OE | entrada | | 17 | D0− **(VERIFICAR)** | pasivo |
| 6 | GND | alimentación | | 18 | D0+ **(VERIFICAR)** | pasivo |
| 7 | CEC_B | bidireccional | | 19 | GND | alimentación |
| 8 | SCL_B | bidireccional | | 20 | D1− **(VERIFICAR)** | pasivo |
| 9 | SDA_B | bidireccional | | 21 | D1+ **(VERIFICAR)** | pasivo |
| 10 | HPD_B | entrada | | 22 | D2− **(VERIFICAR)** | pasivo |
| 11 | VCC5V | alimentación | | 23 | D2+ **(VERIFICAR)** | pasivo |
| 12 | CT_HPD | entrada | | 24 | VCCA | alimentación |

> ### ⚠️ Hallazgo de la revisión de hojas de datos (noviembre de 2026): **D0 y D2 están al revés en este símbolo**
>
> Al leer la tabla *Pin Functions* completa de SLLSE96F (columna PW) salió este reparto:
>
> | Pines | Hoja de datos | Este símbolo |
> |---|---|---|
> | 15, 16 | CLK | CLK ✔ |
> | 17, 18 | **D2** | D0 ✘ |
> | 20, 21 | D1 | D1 ✔ |
> | 22, 23 | **D0** | D2 ✘ |
>
> El símbolo se armó suponiendo que los pares bajaban D2 → D1 → D0 desde el pin 23; la hoja de datos los
> pone subiendo, D2 → D1 → D0 desde el pin 17, que es el mismo orden en que aparecen en el conector HDMI
> (pines 1‑3 = Data2, 4‑6 = Data1, 7‑9 = Data0). Con el orden de la hoja de datos los pares del
> TPD12S016 quedan alineados con los de J3 y las pistas **no se cruzan**; con el del símbolo, D0 y D2 se
> cruzan de un extremo al otro del integrado. Eléctricamente da igual (los ocho pines son diodos
> idénticos), pero es una diferencia de ruteo grande en un par TMDS, donde cruzarse cuesta vías y
> descuadra la longitud del par.
>
> **No se corrigió el símbolo todavía, a propósito.** La tabla *Pin Functions* se leyó como texto extraído
> del PDF, y el dibujo de pines de la página 4 no se pudo leer. Cambiar el símbolo con una fuente y dejar
> la otra sin resolver es cambiar un 50 % por otro 50 %. **Esto es lo que hay que confirmar en el PDF
> abierto, y es de las cosas más valiosas que se pueden hacer en dos minutos en este proyecto**: mirar el
> diagrama de pines de la página 4 de SLLSE96F y anotar los ocho nombres tal como salen. Con eso se
> corrige el símbolo (o se confirma) y queda cerrado el pendiente 2 de la sección 7.
>
> La **polaridad + / − dentro de cada par** sigue abierta por separado y esa sí no cambia nada: los dos
> pines del par son el mismo diodo. Se decide al rutear.

### 3.2 `IS42S16160J-xTL`

Mismo pinout que el símbolo oficial `Memory_RAM:MT48LC16M16A2P` (TSOP‑II‑54 JEDEC para SDRAM de 16 bits); la validación los compara pin por pin. Solo cambian los nombres a los de ISSI: `LDQM`, `UDQM`, `A10/AP`. Coincide también con la tabla de la sección 4 de `conexiones.md`. VERIFICAR contra la hoja de datos de ISSI (se escribió sin ella; la referencia es el símbolo de Micron).

### 3.3 `STM32H743IITx_Nodo`

El símbolo oficial tiene los 176 pines en un solo bloque. Este los reparte en 10 unidades para que quepan en hojas separadas:

| Unidad | Contenido | Pines |
|---|---|---|
| 1 (A) | Alimentación y sistema: VDD ×14, VSS ×12, VDDA, VSSA, VREF+, VBAT, VDD33_USB, VCAP ×2, PDR_ON, NRST, BOOT0 | 36 |
| 2 a 9 (B‑I) | Puertos A, B, C, D, E, F, G, H (16 pines cada uno) | 128 |
| 10 (J) | Puerto I (PI0‑PI11) | 12 |

Los números y nombres de pin se copian por programa del símbolo oficial y se comparan contra `../pines.csv` (176 de 176 iguales). Diferencias con el oficial: no trae las funciones alternas de cada pin (el oficial sí, en "Pin alternates"), y todos los VSS son entradas de alimentación visibles, uno por número de pin, sin pines apilados ocultos. Si prefieres el oficial, es igual de válido.

## 4. Huellas propias (`puente_nodo.pretty`)

Las cinco son **copia de la huella oficial de KiCad 8.0.8**, con los pads, la serigrafía, F.Fab, el courtyard y la marca de pin 1 sin tocar. Se copiaron porque la huella oficial apunta a un modelo 3D que no viene en `kicad-packages3D` 8.0.7 (en el visor 3D el conector aparecería vacío). Los únicos cambios son la línea `(model ...)` y una nota en la descripción. No se dibujó ninguna huella desde cero: no hizo falta, y una huella oficial ya revisada es más confiable que una hecha de memoria.

Medidas tomadas de los pads por `validar.py` (todas coinciden con lo esperado):

| Huella | Medidas comprobadas | Origen de la huella |
|---|---|---|
| `VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias` | 24 terminales, 6 por lado, paso 0.5 mm, pad de 0.25 mm de ancho, 4.75 mm entre extremos exteriores de pads, pad expuesto 2.5 × 2.5 mm con 9 vías de 0.2 mm, cuerpo 4 × 4 mm | `Package_DFN_QFN` |
| `USB_C_Receptacle_HRO_TYPE-C-31-M-12` | Señales (A5‑A8, B5‑B8): paso 0.5 mm, pad 0.3 × 1.45 mm. VBUS/GND: pads de 0.6 mm centrados en ±2.45 y ±3.25 mm (A1/B12, A4/B9, A9/B4 y A12/B1 comparten pad). Patas de la concha a 8.64 mm, ranuras de 0.6 mm. Cuerpo 8.94 × 7.3 mm | `Connector_USB` |
| `HDMI_A_Amphenol_10029449-x01xLF_Horizontal` | 19 contactos en una fila, paso 0.5 mm, pad 0.3 × 1.9 mm, 9.0 mm del pin 1 al 19, 4 patas de concha con barreno de 1.3 mm, cuerpo 15 × 9 mm. La huella dibuja el borde de la placa ("PCB Edge") a 3.5 mm del origen | `Connector_Video` |
| `RJ45_Hanrun_HR911105A_Horizontal` | Pines 1‑8 en dos filas alternadas: 1.27 mm en x (la huella oficial tiene 1.26 y 1.28 por redondeo), 2.54 mm entre filas, barreno 0.89 mm. Postes de plástico a 11.43 mm con barreno de 3.25 mm. Patas del blindaje a 15.49 mm. LED: pines 9‑10 y 11‑12, a 2.54 mm. Cuerpo 16.04 × 21.3 mm | `Connector_RJ` |
| `SW_Push_1P1T_XKB_TS-1187A` | 4 pads de 1.0 × 0.75 mm, centros a 6.0 mm en x y 3.75 mm en y, cuerpo 5.1 × 5.1 mm | `Button_Switch_SMD` |

Revisa las imágenes de `previews/` contra el dibujo del fabricante de la pieza que compres.

## 5. Modelos 3D (`puente_nodo.3dshapes`)

Hechos con CadQuery (`herramientas/gen_3d.py`). Son **cuerpos sencillos**: la planta se toma del contorno F.Fab y de los pads de la huella, así que quedan alineados con ella. Sirven para ver la placa armada y revisar choques a grandes rasgos. **No sirven para diseñar una caja ajustada**: las alturas están escritas de memoria.

| Modelo | Tamaño del modelo (con patas) | Altura sobre la placa | Simplificaciones |
|---|---|---|---|
| `RJ45_Hanrun_HR911105A_Horizontal.step` | 16.04 × 21.30 mm | 13.4 mm **VERIFICAR** | Caja con la boca del RJ45 y ranura del seguro; sin LED ni pestañas |
| `USB_C_Receptacle_HRO_TYPE-C-31-M-12.step` | 8.94 × 8.32 mm | 3.26 mm **VERIFICAR** | Concha hueca con lengüeta |
| `HDMI_A_Amphenol_10029449-x01xLF_Horizontal.step` | 16.00 × 10.20 mm | 6.1 mm **VERIFICAR** | Concha rectangular redondeada (el conector real tiene las esquinas inferiores en chaflán); el largo real también hay que VERIFICARLO |
| `SW_Push_1P1T_XKB_TS-1187A.step` | 6.50 × 5.10 mm | 1.5 mm **VERIFICAR** (depende del sufijo de la pieza) | Cuerpo y actuador de 3 mm |
| `VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias.step` | 4.00 × 4.00 mm | 0.9 mm | Cuerpo, terminales y pad expuesto |

La huella los busca en `${KIPRJMOD}/puente_nodo.3dshapes/`, es decir, junto al archivo `.kicad_pro`.

## 6. Cómo agregar las librerías a un proyecto de KiCad 8

Las rutas usan `${KIPRJMOD}`, que es la carpeta donde está el archivo `.kicad_pro`. Por eso **el proyecto debe vivir en esta misma carpeta `kicad/`**.

### Opción A: proyecto nuevo (la más simple)

1. Abre KiCad 8 y elige **Archivo > Nuevo proyecto**.
2. Navega a esta carpeta (`nodo/hardware/kicad/`), escribe el nombre (por ejemplo `nodo`) y **desmarca "Crear una carpeta nueva para el proyecto"**. Así `nodo.kicad_pro` queda junto a `sym-lib-table` y `fp-lib-table`.
3. Cierra y vuelve a abrir el proyecto. KiCad lee solo las dos tablas que ya están en la carpeta.
4. Comprueba: **Preferencias > Administrar librerías de símbolos**, pestaña **Librerías específicas del proyecto**: debe aparecer `puente_nodo` con ruta `${KIPRJMOD}/puente_nodo.kicad_sym`. Lo mismo en **Preferencias > Administrar librerías de huellas**, con `${KIPRJMOD}/puente_nodo.pretty`.

### Opción B: a mano, o en un proyecto que ya existe

1. Copia junto a tu `.kicad_pro`: `puente_nodo.kicad_sym`, `puente_nodo.pretty/` y `puente_nodo.3dshapes/`.
2. **Preferencias > Administrar librerías de símbolos** > pestaña **Librerías específicas del proyecto** > botón **+** (agregar fila vacía). Apodo: `puente_nodo`. Ruta: `${KIPRJMOD}/puente_nodo.kicad_sym`. Formato: KiCad. Aceptar.
3. **Preferencias > Administrar librerías de huellas** > pestaña **Librerías específicas del proyecto** > botón **+**. Apodo: `puente_nodo`. Ruta: `${KIPRJMOD}/puente_nodo.pretty`. Formato: KiCad. Aceptar.
4. El apodo tiene que ser exactamente `puente_nodo`: los símbolos y esta tabla hacen referencia a las huellas con ese nombre.

### Comprobación en KiCad (pendiente, ver sección 0)

5. Las librerías oficiales deben estar en la pestaña **Librerías globales** (KiCad las configura en la primera ejecución). Si usas KiCad 9 o más nuevo, funciona igual, pero las huellas oficiales apuntan a `${KICAD9_3DMODEL_DIR}` y las copiadas aquí conservan su geometría de la versión 8.0.8.
6. Prueba mínima: en el editor de símbolos abre `puente_nodo` y revisa los tres símbolos (en `STM32H743IITx_Nodo` cambia de unidad con la lista desplegable). En el editor de huellas abre cada una de las cinco y presiona **Alt+3** para ver el modelo 3D: debe aparecer sentado sobre los pads, con la boca del conector hacia el borde de la placa.
7. Al asignar huellas, U3, J1, J2, J3 y los botones llevan la huella de `puente_nodo` en vez de la que trae el símbolo oficial por defecto. Cámbiala en el campo *Footprint* del símbolo o con **Herramientas > Asignar huellas**.

## 7. Lista de pendientes VERIFICAR

1. **Abrir todo en KiCad 8** (símbolos, huellas, modelos 3D). No se pudo probar aquí.
2. **TPD12S016, pines 17‑18 y 22‑23: hay conflicto, no solo duda.** La tabla *Pin Functions* de la hoja de datos pone **D2 en 17/18 y D0 en 22/23**; este símbolo los tiene al revés. Ver el recuadro de la sección 3.1. **Es el pendiente número uno de esta lista**: se cierra mirando el diagrama de pines de la página 4 del PDF. (CLK en 15/16 ya está confirmado; la polaridad + / − dentro de cada par no cambia el circuito.)
3. **TFP410PAP, pad térmico**: confirmar en el dibujo mecánico del PDF (sección 10, plano 4226442/A de TI) que la huella oficial de 8 × 8 mm con abertura de 4.4 × 4.4 mm corresponde al pad expuesto real. Avance de la revisión de noviembre de 2026: la nota de aplicación SLMA002H de TI dice que para encapsulados TQFP el cobre máximo es «el tamaño del cuerpo menos 2.0 mm», o sea **8 × 8 mm exactos para este cuerpo de 10 × 10 mm**, lo que coincide con la huella oficial. Falta nada más la cota del pad expuesto, para la abertura de máscara de 4.4 × 4.4. Se puede ver de pasada al abrir el PDF para el pendiente 2.
4. **J3 HDMI**: el BOM dice "genérico de 19 pines". La huella es la del Amphenol 10029449; comprar esa pieza o comparar el dibujo del clon contra `previews/HDMI_A_Amphenol_10029449-x01xLF_Horizontal.png`, sobre todo las 4 patas de la concha y la distancia al borde de la placa.
5. **J1 USB‑C**: confirmar que se compra el TYPE‑C‑31‑M‑12 de HRO o uno con el mismo dibujo. Los conectores de 16 pines de otras marcas cambian la posición de las patas.
6. **J2 HR911105A**: polaridad de los LED (cuál de 9/10 y de 11/12 es el ánodo). El símbolo oficial deja esos pines sin nombre; hay que mirar el dibujo del símbolo y la hoja de HanRun. También confirmar los números 1‑8 contra la hoja.
7. **SW1, SW2, SW4**: la huella propuesta es del XKB TS‑1187A (5.1 × 5.1 mm); el BOM no fija la pieza.
8. **L1**: la huella `L_Changjiang_FNR4030S` es una propuesta de 4 × 4 mm; elegir según el inductor que se compre.
9. **J4**: el conector SMD de 2x5 de paso 1.27 mm con guía (tipo Samtec FTSH con carcasa) ocupa más que la tira sola.
10. **Alturas de los 5 modelos 3D** (sección 5) y el largo real del conector HDMI.
11. **IS42S16160J**: pinout comparado contra el símbolo de Micron, no contra la hoja de ISSI.
12. **Y1, Y2**: que en el cristal comprado los pads 1 y 3 sean el cristal y 2 y 4 la tapa/tierra.

## 8. Datos nuevos para `conexiones.md` (ese archivo no se modificó)

Al revisar los símbolos oficiales salieron varios números que en `conexiones.md` estaban "de memoria":

- **LAN8742A**: los 24 números de pin de la sección 5 coinciden con el símbolo oficial `Interface_Ethernet:LAN8742A`. El pad expuesto (VSS) es el pin 25.
- **SDRAM**: la tabla de la sección 4 coincide con el símbolo oficial de Micron.
- **TLV62569DBV**: 1 EN, 2 GND, 3 SW, 4 VIN, 5 FB.
- **TFP410PAP** (números del símbolo oficial `Video:TFP410PAP`, que en `conexiones.md` no estaban): DE 2, VREF 3, HSYNC 4, VSYNC 5, CTL3 6, CTL2 7, CTL1 8, EDGE/HTPLG 9, PD 10, MSEN 11, ISEL/RST 13, DSEL/SDA 14, BSEL/SCL 15, TFADJ 19, TXC− 21, TXC+ 22, TX0− 24, TX0+ 25, TX1− 27, TX1+ 28, TX2− 30, TX2+ 31, DKEN 35, DATA23‑DATA12 = 36‑47, DATA11‑DATA6 = 50‑55, IDCK− 56, IDCK+ 57, DATA5‑DATA0 = 58‑63. DVDD 1, 12, 33; PVDD 18; TVDD 23, 29; DGND 16, 48, 64; PGND 17; TGND 20, 26, 32; RESERVED 34; NC 49; pad térmico 65.
- **HR911105A** (símbolo oficial): 1 TD+, 2 TD−, 3 RD+, 4 toma central TX, 5 toma central RX, 6 RD−, 7 NC, 8 sin nombre (la sección 5.4 lo manda a `CHASIS`; VERIFICAR en la hoja de HanRun), 9‑12 LED, SH blindaje.
- **TPD12S016**: **confirmado en el PDF** (sección 7.3 de SLLSE96F, noviembre de 2026). Los *pull‑up* internos existen y son 10 kΩ a VCCA en SCL_A, SDA_A y CEC_A, 1.75 kΩ a 5V_OUT en SCL_B y SDA_B, más un *pull‑down* de 11 kΩ típicos en HPD_B y 27 kΩ en CEC_B al riel interno de 3.3 V. La hoja de datos dice que el sistema funciona sin nada externo en DDC, CEC ni HPD. `conexiones.md` ya se corrigió: las resistencias de 10 kΩ de SCL_A y SDA_A quedan como huellas sin montar, y CEC_A sin conectar.
- **TFP410PAP**: los números de pin de este símbolo oficial se compararon uno por uno contra la tabla 4‑1 de SLDS145D en noviembre de 2026 y **coinciden todos**, incluidos los que más importan para los straps (VREF 3, EDGE 9, PD 10, MSEN 11, ISEL 13, DSEL 14, BSEL 15, TFADJ 19, RESERVED 34, DKEN 35, IDCK− 56, IDCK+ 57). El símbolo oficial es confiable para capturar.
- **Conector SWD**: en el símbolo oficial el pin 9 se llama `GNDDetect`; `conexiones.md` lo manda a GND, que es lo usual.

## 9. Cómo regenerar y validar

Requisitos: Python 3, `pip install cadquery matplotlib kiutils`, y una copia de las librerías oficiales de KiCad 8 (carpeta con los `.kicad_sym` y las `.pretty`; en una instalación normal de Linux es `/usr/share/kicad/symbols` y `/usr/share/kicad/footprints`, que habría que juntar o pasar con enlaces en una sola carpeta).

```
cd herramientas
python3 gen_simbolos.py /ruta/a/librerias_oficiales   # escribe puente_nodo.kicad_sym
python3 gen_huellas.py  /ruta/a/librerias_oficiales   # escribe puente_nodo.pretty/
python3 gen_3d.py                                     # escribe puente_nodo.3dshapes/
python3 validar.py      /ruta/a/librerias_oficiales   # escribe validacion.txt y previews/
```

`validar.py` termina con código 1 si algo falla. Comprueba, entre otras cosas:

- Símbolos propios: sin números de pin repetidos, tipos eléctricos válidos, pines en rejilla, y el conjunto de números de pin igual al conjunto de pads de la huella asignada.
- 23 pares símbolo–huella de la tabla de la sección 2 (oficiales incluidos): mismos números de pin y de pad.
- Huellas propias: pads idénticos a los oficiales, capas presentes, pads dentro del courtyard, paso y tamaño contra la tabla de la sección 4, el archivo STEP existe y cabe en el courtyard.

## 10. Licencia

Las huellas de `puente_nodo.pretty` y los pines del símbolo `STM32H743IITx_Nodo` vienen de las librerías oficiales de KiCad, con licencia CC‑BY‑SA 4.0 y una excepción que permite usarlas en cualquier diseño sin obligaciones. Al redistribuir la librería (como en este repositorio) hay que conservar la atribución y la licencia: por eso está `LICENCIA-KiCad.md` y cada huella dice de dónde se copió.
