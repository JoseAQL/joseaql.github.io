#!/usr/bin/env python3
"""Genera puente_nodo.pretty a partir de las huellas oficiales de KiCad 8.0.8.

Solo se copian las huellas oficiales cuyo modelo 3D NO existe en kicad-packages3D 8.0.7.
La geometria (pads, serigrafia, fab, courtyard) se conserva tal cual; solo cambian la
descripcion y la referencia (model ...), que apunta a puente_nodo.3dshapes/*.step.

Uso: python3 gen_huellas.py [carpeta_con_librerias_oficiales_kicad8]
"""
import os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
OFICIAL = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/herramientas/kicad8'
SALIDA = os.path.join(AQUI, '..', 'puente_nodo.pretty')

# nombre de la huella -> libreria oficial de origen
HUELLAS = {
    'RJ45_Hanrun_HR911105A_Horizontal': 'Connector_RJ',
    'USB_C_Receptacle_HRO_TYPE-C-31-M-12': 'Connector_USB',
    'HDMI_A_Amphenol_10029449-x01xLF_Horizontal': 'Connector_Video',
    'SW_Push_1P1T_XKB_TS-1187A': 'Button_Switch_SMD',
    'VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias': 'Package_DFN_QFN',
}
MODELO = re.compile(r'\(model "[^"]*"')
DESCR = re.compile(r'\(descr "((?:[^"\\]|\\.)*)"\)')

if __name__ == '__main__':
    os.makedirs(SALIDA, exist_ok=True)
    for nombre, lib in HUELLAS.items():
        txt = open(os.path.join(OFICIAL, lib + '.pretty', nombre + '.kicad_mod')).read()
        assert len(MODELO.findall(txt)) == 1 and len(DESCR.findall(txt)) == 1, nombre
        txt = MODELO.sub(f'(model "${{KIPRJMOD}}/puente_nodo.3dshapes/{nombre}.step"', txt)
        nota = f' [Copia de {lib}:{nombre} de KiCad 8.0.8 (CC-BY-SA 4.0); modelo 3D propio en puente_nodo.3dshapes]'
        txt = DESCR.sub(lambda m: '(descr "' + m.group(1) + nota + '")', txt)
        with open(os.path.join(SALIDA, nombre + '.kicad_mod'), 'w') as f:
            f.write(txt)
        print('escrito', nombre + '.kicad_mod')
