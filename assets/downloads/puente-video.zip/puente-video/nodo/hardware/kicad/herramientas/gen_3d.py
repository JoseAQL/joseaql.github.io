#!/usr/bin/env python3
"""Genera los modelos STEP de puente_nodo.3dshapes con CadQuery.

Cuerpos sencillos. La planta (X, Y) sale del contorno F.Fab y de los pads de la propia
huella, asi que el modelo queda alineado con ella por construccion. Las ALTURAS son las
de la tabla ALTURAS de abajo: estan escritas de memoria y hay que VERIFICARLAS contra el
dibujo del fabricante antes de disenar una caja con ellas.

Convencion: X del modelo = X de la huella; Y del modelo = -Y de la huella; Z = 0 en la
cara superior de la placa. Unidades: mm.
"""
import os, sys
import cadquery as cq
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from kicad_sexp import parse, fp_pads, layer_pts, bbox

PRETTY = os.path.join(AQUI, '..', 'puente_nodo.pretty')
SALIDA = os.path.join(AQUI, '..', 'puente_nodo.3dshapes')

# Alturas sobre la placa en mm (VERIFICAR: de memoria, sin dibujo del fabricante a la mano)
ALTURAS = {
    'RJ45_Hanrun_HR911105A_Horizontal': 13.4,
    'USB_C_Receptacle_HRO_TYPE-C-31-M-12': 3.26,
    'HDMI_A_Amphenol_10029449-x01xLF_Horizontal': 6.1,
    'SW_Push_1P1T_XKB_TS-1187A': 1.5,
    'VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias': 0.9,
}
METAL = cq.Color(0.78, 0.78, 0.80)
NEGRO = cq.Color(0.12, 0.12, 0.12)
ORO = cq.Color(0.85, 0.70, 0.25)
PLASTICO = cq.Color(0.20, 0.20, 0.22)


def caja(x0, y0, x1, y1, z0, z1):
    """Caja dada en coordenadas de HUELLA (Y hacia abajo)."""
    return (cq.Workplane('XY').box(x1 - x0, y1 - y0, z1 - z0, centered=False)
            .translate((x0, -y1, z0)))


def cil(x, y, d, z0, z1):
    return cq.Workplane('XY').circle(d / 2).extrude(z1 - z0).translate((x, -y, z0))


def leer(nombre):
    fp = parse(open(os.path.join(PRETTY, nombre + '.kicad_mod')).read())
    return fp_pads(fp), bbox(layer_pts(fp, 'F.Fab'))


def rj45(n):
    pads, (x0, y0, x1, y1) = leer(n)
    h = ALTURAS[n]
    cx = (x0 + x1) / 2
    cuerpo = caja(x0, y0, x1, y1, 0, h)
    # boca del RJ45 (11.7 x 8 mm aprox.) en la cara frontal (+Y de la huella)
    cuerpo = cuerpo.cut(caja(cx - 5.85, y1 - 14.0, cx + 5.85, y1 + 0.1, 3.0, 11.0))
    cuerpo = cuerpo.cut(caja(cx - 3.0, y1 - 14.0, cx + 3.0, y1 + 0.1, 1.5, 3.01))   # ranura del seguro (abajo)
    pines = None
    for p in pads:
        if p['type'] == 'np_thru_hole':
            c = cil(p['x'], p['y'], 3.0, -2.5, 0)
        elif p['num'] == 'SH':
            c = caja(p['x'] - 0.15, p['y'] - 0.7, p['x'] + 0.15, p['y'] + 0.7, -3.2, 0)
        else:
            c = cil(p['x'], p['y'], 0.5, -3.2, 0)
        pines = c if pines is None else pines.union(c)
    a = cq.Assembly(name=n)
    a.add(cuerpo, name='blindaje', color=METAL)
    a.add(pines, name='pines', color=ORO)
    return a


def concha(n, pared, lengua):
    """Conector de borde con concha metalica hueca abierta hacia +Y de la huella."""
    pads, (x0, y0, x1, y1) = leer(n)
    h = ALTURAS[n]
    r = min(h / 2 - 0.01, 1.2)
    w, largo = x1 - x0, y1 - y0
    perfil = lambda ww, hh, rr: cq.Workplane('XZ').rect(ww, hh).extrude(-largo).edges('|Y').fillet(rr)
    ext = perfil(w, h, r)
    hueco = perfil(w - 2 * pared, h - 2 * pared, max(r - pared, 0.05)).translate((0, -0.6, 0))   # fondo cerrado atras, boca abierta al frente
    cuerpo = ext.cut(hueco).translate(((x0 + x1) / 2, -y1, h / 2))
    lw, lh = lengua
    leng = caja((x0 + x1) / 2 - lw / 2, y0 + 0.6, (x0 + x1) / 2 + lw / 2, y1 - 1.0, h / 2 - lh / 2, h / 2 + lh / 2)
    patas = None
    for p in pads:
        if p['type'] == 'thru_hole':
            c = caja(p['x'] - 0.15, p['y'] - 0.4, p['x'] + 0.15, p['y'] + 0.4, -1.2, 0.3)
        elif p['type'] == 'smd':
            c = caja(p['x'] - p['w'] / 2 + 0.03, max(p['y'] - p['h'] / 2 + 0.1, y0 - 1.2), p['x'] + p['w'] / 2 - 0.03, y0 + 0.2, 0, 0.15)
        else:
            c = cil(p['x'], p['y'], p['w'] - 0.1, -0.8, 0.2)
        patas = c if patas is None else patas.union(c)
    a = cq.Assembly(name=n)
    a.add(cuerpo, name='concha', color=METAL)
    a.add(leng, name='lengua', color=NEGRO)
    a.add(patas, name='terminales', color=ORO)
    return a


def boton(n):
    pads, (x0, y0, x1, y1) = leer(n)
    h = ALTURAS[n]
    m = (y1 - y0) / 2                       # cuerpo cuadrado de 5.1 mm centrado
    cuerpo = caja(-m, y0, m, y1, 0, h - 0.4)
    act = cil(0, 0, 3.0, h - 0.4, h)
    patas = None
    for p in pads:
        xa, xb = sorted((p['x'] + (0.25 if p['x'] > 0 else -0.25), m if p['x'] > 0 else -m))
        c = caja(xa, p['y'] - 0.3, xb, p['y'] + 0.3, 0, 0.2)
        patas = c if patas is None else patas.union(c)
    a = cq.Assembly(name=n)
    a.add(cuerpo, name='cuerpo', color=METAL)
    a.add(act, name='actuador', color=NEGRO)
    a.add(patas, name='terminales', color=ORO)
    return a


def qfn(n):
    pads, (x0, y0, x1, y1) = leer(n)
    h = ALTURAS[n]
    cuerpo = caja(x0, y0, x1, y1, 0.02, h)
    cuerpo = cuerpo.cut(cil(x0 + 0.6, y0 + 0.6, 0.4, h - 0.05, h + 0.1))    # marca de pin 1
    term = None
    for p in pads:
        if p['type'] != 'smd' or p['num'] == '' or 'F.Cu' not in p['layers']:
            continue
        if p['w'] > 2:                                                       # pad expuesto
            c = caja(-p['w'] / 2, -p['h'] / 2, p['w'] / 2, p['h'] / 2, 0, 0.02)
        else:                                                                # terminal de 0.25 x 0.4 bajo el cuerpo
            xa, xb = max(p['x'] - p['w'] / 2, x0), min(p['x'] + p['w'] / 2, x1)
            ya, yb = max(p['y'] - p['h'] / 2, y0), min(p['y'] + p['h'] / 2, y1)
            if p['w'] > p['h']:
                xa, xb = (x0, x0 + 0.4) if p['x'] < 0 else (x1 - 0.4, x1)
            else:
                ya, yb = (y0, y0 + 0.4) if p['y'] < 0 else (y1 - 0.4, y1)
            c = caja(xa, ya, xb, yb, 0, 0.2)
        term = c if term is None else term.union(c)
    a = cq.Assembly(name=n)
    a.add(cuerpo, name='cuerpo', color=PLASTICO)
    a.add(term, name='terminales', color=METAL)
    return a


MODELOS = {
    'RJ45_Hanrun_HR911105A_Horizontal': rj45,
    'USB_C_Receptacle_HRO_TYPE-C-31-M-12': lambda n: concha(n, 0.3, (6.7, 0.7)),
    'HDMI_A_Amphenol_10029449-x01xLF_Horizontal': lambda n: concha(n, 0.4, (11.0, 1.2)),
    'SW_Push_1P1T_XKB_TS-1187A': boton,
    'VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias': qfn,
}

if __name__ == '__main__':
    os.makedirs(SALIDA, exist_ok=True)
    for n, f in MODELOS.items():
        ruta = os.path.join(SALIDA, n + '.step')
        f(n).export(ruta)
        print('escrito', os.path.basename(ruta), os.path.getsize(ruta), 'bytes')
