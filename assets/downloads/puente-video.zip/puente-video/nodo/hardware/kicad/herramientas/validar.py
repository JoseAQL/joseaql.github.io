#!/usr/bin/env python3
"""Valida la libreria puente_nodo y dibuja las vistas previas.

Uso: python3 validar.py [carpeta_con_librerias_oficiales_kicad8]
Sale con codigo 1 si alguna comprobacion falla. Escribe previews/*.png y validacion.txt.
"""
import csv, math, os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from kicad_sexp import parse, kids, kid, prop, sym_pins, fp_pads, layer_pts, bbox
from gen_huellas import HUELLAS

OFICIAL = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/herramientas/kicad8'
RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
PINES_CSV = os.path.join(RAIZ, '..', 'pines.csv')
LOG, FALLOS = [], []


def ok(cond, msg):
    LOG.append(('  OK    ' if cond else '  FALLA ') + msg)
    if not cond:
        FALLOS.append(msg)


def titulo(t):
    LOG.append('\n== ' + t)


_cache = {}
def sim_oficial(ref):
    lib, n = ref.split(':')
    if lib not in _cache:
        _cache[lib] = {s[1]: s for s in kids(parse(open(os.path.join(OFICIAL, lib + '.kicad_sym')).read()), 'symbol')}
    s = _cache[lib][n]
    e = kid(s, 'extends')
    return _cache[lib][e[1]] if e else s


def huella(ref):
    lib, n = ref.split(':')
    base = os.path.join(RAIZ, 'puente_nodo.pretty') if lib == 'puente_nodo' else os.path.join(OFICIAL, lib + '.pretty')
    return parse(open(os.path.join(base, n + '.kicad_mod')).read())


def nums_pads(fp):
    return {p['num'] for p in fp_pads(fp) if p['num'] != ''}


# ------------------------------------------------------------------ 1. simbolos propios
titulo('1. Simbolos de puente_nodo.kicad_sym')
lib = parse(open(os.path.join(RAIZ, 'puente_nodo.kicad_sym')).read())
ok(lib[0] == 'kicad_symbol_lib' and kid(lib, 'version')[1] == '20231120', 'cabecera kicad_symbol_lib version 20231120 (KiCad 8)')
propios = {s[1]: s for s in kids(lib, 'symbol')}
TIPOS = {'input', 'output', 'bidirectional', 'tri_state', 'passive', 'free', 'unspecified', 'power_in', 'power_out',
         'open_collector', 'open_emitter', 'no_connect'}
for n, s in propios.items():
    pins = sym_pins(s)
    nums = [p[0] for p in pins]
    fpref = prop(s, 'Footprint')
    pads = nums_pads(huella(fpref))
    ok(len(nums) == len(set(nums)), f'{n}: {len(nums)} pines, sin numeros repetidos')
    ok(all(p[2] in TIPOS for p in pins), f'{n}: tipos electricos validos')
    ok(set(nums) == pads, f'{n}: {len(set(nums))} pines == {len(pads)} pads de {fpref}'
       + ('' if set(nums) == pads else f' (sin pad {sorted(set(nums) - pads)}, sin pin {sorted(pads - set(nums))})'))
    pos = [(kid(p, 'at')[1], kid(p, 'at')[2], sub[1]) for sub in kids(s, 'symbol') for p in kids(sub, 'pin')]
    ok(len(pos) == len(set(pos)), f'{n}: ningun pin encimado en la misma posicion')
    ok(all(abs(float(v) / 1.27 - round(float(v) / 1.27)) < 1e-6 for x, y, _ in pos for v in (x, y)), f'{n}: pines en rejilla de 1.27 mm')

# TPD12S016: contra la tabla "Pin Functions" (PW) de la hoja de datos TI SLLSE96F
TABLA_TI = {'1': 'CEC_A', '2': 'SCL_A', '3': 'SDA_A', '4': 'HPD_A', '5': 'LS_OE', '6': 'GND', '7': 'CEC_B', '8': 'SCL_B',
            '9': 'SDA_B', '10': 'HPD_B', '11': 'VCC5V', '12': 'CT_HPD', '13': '5V_OUT', '14': 'GND', '19': 'GND', '24': 'VCCA'}
d = {p[0]: p[1] for p in sym_pins(propios['TPD12S016PW'])}
ok(all(d[k] == v for k, v in TABLA_TI.items()), 'TPD12S016PW: pines 1-14, 19 y 24 iguales a la tabla de la hoja de datos')
ok({d[k][:3] for k in ('15', '16')} == {'CLK'} and all(d[k][0] == 'D' for k in ('17', '18', '20', '21', '22', '23')),
   'TPD12S016PW: 15-16 son CLK y 17, 18, 20-23 son D (la hoja de datos solo da los grupos; reparto individual = VERIFICAR)')

# SDRAM: contra el simbolo oficial de Micron (misma numeracion JEDEC)
alias = {'DQML': 'LDQM', 'DQMH': 'UDQM', 'A10': 'A10/AP'}
ofi = {p[0]: alias.get(p[1], p[1]) for p in sym_pins(sim_oficial('Memory_RAM:MT48LC16M16A2P'))}
mio = {p[0]: p[1] for p in sym_pins(propios['IS42S16160J-xTL'])}
ok(ofi == mio, 'IS42S16160J-xTL: 54 pines iguales (numero y nombre) a Memory_RAM:MT48LC16M16A2P'
   + ('' if ofi == mio else f' dif={[(k, ofi.get(k), mio.get(k)) for k in sorted(set(ofi) | set(mio)) if ofi.get(k) != mio.get(k)]}'))

# STM32: contra el simbolo oficial y contra pines.csv
ofi = {p[0]: p[1] for p in sym_pins(sim_oficial('MCU_ST_STM32H7:STM32H743IITx'))}
mio = {p[0]: p[1] for p in sym_pins(propios['STM32H743IITx_Nodo'])}
ok(ofi == mio and len(mio) == 176, 'STM32H743IITx_Nodo: 176 pines iguales (numero y nombre) al simbolo oficial STM32H743IITx')
filas = list(csv.DictReader(open(PINES_CSV)))
ok(len(filas) == 176 and all(mio[f['pin_lqfp176']] == f['pin'] for f in filas), 'STM32H743IITx_Nodo: 176 pines iguales a ../pines.csv')
uds = {}
for p in sym_pins(propios['STM32H743IITx_Nodo']):
    uds.setdefault(p[3], []).append(p[1])
ok(len(uds) == 10 and all(len({re.match(r'P([A-K])', x).group(1) for x in v}) == 1 for u, v in uds.items() if u > 1),
   'STM32H743IITx_Nodo: 10 unidades; unidades 2-10 con un solo puerto cada una: ' + ', '.join(f'{u}={len(v)}' for u, v in sorted(uds.items())))

# ------------------------------------------------------------------ 2. pares oficiales
titulo('2. Pares simbolo oficial <-> huella (numeros de pin contra numeros de pad)')
PARES = [
    ('U1', 'MCU_ST_STM32H7:STM32H743IITx', 'Package_QFP:LQFP-176_24x24mm_P0.5mm'),
    ('U2', 'Memory_RAM:MT48LC16M16A2P', 'Package_SO:TSOP-II-54_22.2x10.16mm_P0.8mm'),
    ('U3', 'Interface_Ethernet:LAN8742A', 'puente_nodo:VQFN-24-1EP_4x4mm_P0.5mm_EP2.5x2.5mm_ThermalVias'),
    ('U4', 'Video:TFP410PAP', 'Package_QFP:HTQFP-64-1EP_10x10mm_P0.5mm_EP8x8mm_Mask4.4x4.4mm_ThermalVias'),
    ('U6', 'Regulator_Switching:TLV62569DBV', 'Package_TO_SOT_SMD:SOT-23-5'),
    ('U9', 'Power_Protection:USBLC6-2SC6', 'Package_TO_SOT_SMD:SOT-23-6'),
    ('J1', 'Connector:USB_C_Receptacle_USB2.0_16P', 'puente_nodo:USB_C_Receptacle_HRO_TYPE-C-31-M-12'),
    ('J2', 'Connector:RJ45_Hanrun_HR911105A_Horizontal', 'puente_nodo:RJ45_Hanrun_HR911105A_Horizontal'),
    ('J3', 'Connector:HDMI_A', 'puente_nodo:HDMI_A_Amphenol_10029449-x01xLF_Horizontal'),
    ('J4', 'Connector:Conn_ARM_JTAG_SWD_10', 'Connector_PinHeader_1.27mm:PinHeader_2x05_P1.27mm_Vertical_SMD'),
    ('J4 alt', 'Connector:Conn_ARM_SWD_TagConnect_TC2030-NL', 'Connector:Tag-Connect_TC2030-IDC-NL_2x03_P1.27mm_Vertical'),
    ('J5', 'Connector_Generic:Conn_01x03', 'Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical'),
    ('Y1, Y2', 'Device:Crystal_GND24', 'Crystal:Crystal_SMD_3225-4Pin_3.2x2.5mm'),
    ('L1', 'Device:L', 'Inductor_SMD:L_Changjiang_FNR4030S'),
    ('F1', 'Device:Polyfuse', 'Fuse:Fuse_1206_3216Metric'),
    ('D1', 'Diode:SMF5V0A', 'Diode_SMD:D_SMF'),
    ('SW1, SW2, SW4', 'Switch:SW_Push', 'puente_nodo:SW_Push_1P1T_XKB_TS-1187A'),
    ('SW3', 'Switch:SW_DIP_x04', 'Button_Switch_THT:SW_DIP_SPSTx04_Slide_9.78x12.34mm_W7.62mm_P2.54mm'),
    ('SW3 alt', 'Switch:SW_DIP_x04', 'Button_Switch_SMD:SW_DIP_SPSTx04_Slide_Omron_A6S-410x_W8.9mm_P2.54mm'),
    ('FB1-FB5', 'Device:FerriteBead_Small', 'Inductor_SMD:L_0603_1608Metric'),
    ('D2-D4', 'Device:LED', 'LED_SMD:LED_0603_1608Metric'),
    ('R', 'Device:R', 'Resistor_SMD:R_0402_1005Metric'),
    ('C', 'Device:C', 'Capacitor_SMD:C_0402_1005Metric'),
]
for ref, s, f in PARES:
    pins = {p[0] for p in sym_pins(sim_oficial(s))}
    pads = nums_pads(huella(f))
    ok(pins == pads, f'{ref}: {s} ({len(pins)} pines) <-> {f} ({len(pads)} pads)'
       + ('' if pins == pads else f' sin pad {sorted(pins - pads)} sin pin {sorted(pads - pins)}'))

# ------------------------------------------------------------------ 3. huellas propias
titulo('3. Huellas de puente_nodo.pretty')


def cerca(a, b, tol=0.021):
    return abs(a - b) <= tol


def paso(vals):
    v = sorted(set(round(x, 4) for x in vals))
    return sorted({round(b - a, 3) for a, b in zip(v, v[1:])})


MEDIDAS = {}
def medir(n, pads):
    P = lambda *nums: [p for p in pads if p['num'] in nums]
    m = []
    if n.startswith('VQFN'):
        izq = [p for p in pads if p['type'] == 'smd' and p['num'] not in ('', '25') and p['x'] < -1.5]
        ep = [p for p in pads if p['num'] == '25' and p['type'] == 'smd' and 'F.Cu' in p['layers']][0]
        m += [('paso de terminales', paso(p['y'] for p in izq), [0.5]),
              ('ancho de pad', sorted({p['h'] for p in izq}), [0.25]),
              ('extremo exterior de pad a extremo exterior', round(2 * max(-p['x'] + p['w'] / 2 for p in izq), 3), 4.75),
              ('pad expuesto', (ep['w'], ep['h']), (2.5, 2.5)),
              ('terminales por lado', len(izq), 6)]
    elif n.startswith('USB_C'):
        sen = P('A5', 'A6', 'A7', 'A8', 'B5', 'B6', 'B7', 'B8')
        pot = P('A1', 'A4', 'A9', 'A12', 'B1', 'B4', 'B9', 'B12')
        sh = P('S1')
        m += [('paso de pads de senal (A5-A8 con B5-B8)', paso(p['x'] for p in sen), [0.5]),
              ('ancho de pads de senal', sorted({p['w'] for p in sen}), [0.3]),
              ('ancho de pads VBUS/GND', sorted({p['w'] for p in pot}), [0.6]),
              ('centros de VBUS/GND (x)', sorted({abs(p['x']) for p in pot}), [2.45, 3.25]),
              ('separacion de patas de la concha (x)', round(max(p['x'] for p in sh) - min(p['x'] for p in sh), 3), 8.64),
              ('pads A y B encimados (A1=B12, A4=B9, A9=B4, A12=B1)',
               all(P(a)[0]['x'] == P(b)[0]['x'] for a, b in (('A1', 'B12'), ('A4', 'B9'), ('A9', 'B4'), ('A12', 'B1'))), True)]
    elif n.startswith('HDMI'):
        sen = [p for p in pads if p['num'].isdigit()]
        sh = P('SH')
        m += [('contactos', len(sen), 19), ('paso', paso(p['x'] for p in sen), [0.5]),
              ('ancho de pad', sorted({p['w'] for p in sen}), [0.3]),
              ('pin 1 a pin 19', round(abs(P('1')[0]['x'] - P('19')[0]['x']), 3), 9.0),
              ('patas de concha', len(sh), 4), ('barreno de patas', sorted({float(p['drill'][0]) for p in sh}), [1.3])]
    elif n.startswith('RJ45'):
        s8 = [p for p in pads if p['num'] in list('12345678')]
        post = [p for p in pads if p['type'] == 'np_thru_hole']
        sh = P('SH')
        m += [('paso de pines 1-8 en x (minimo, maximo; nominal 1.27)', (min(paso(p['x'] for p in s8)), max(paso(p['x'] for p in s8))), (1.27, 1.27)),
              ('separacion entre filas', round(max(p['y'] for p in s8) - min(p['y'] for p in s8), 3), 2.54),
              ('barreno de pines 1-8', sorted({float(p['drill'][0]) for p in s8}), [0.89]),
              ('postes de plastico: separacion / barreno', (round(abs(post[0]['x'] - post[1]['x']), 3), float(post[0]['drill'][0])), (11.43, 3.25)),
              ('patas del blindaje: separacion', round(abs(sh[0]['x'] - sh[1]['x']), 3), 15.49),
              ('LED: separacion dentro de cada par', paso(p['x'] for p in P('9', '10')) + paso(p['x'] for p in P('11', '12')), [2.54, 2.54])]
    elif n.startswith('SW_Push'):
        m += [('pads', len(pads), 4), ('tamano de pad', sorted({(p['w'], p['h']) for p in pads}), [(1.0, 0.75)]),
              ('centros en x', round(max(p['x'] for p in pads) - min(p['x'] for p in pads), 3), 6.0),
              ('centros en y', round(max(p['y'] for p in pads) - min(p['y'] for p in pads), 3), 3.75)]
    return m


def igual(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return a == b
    if isinstance(a, (int, float)):
        return cerca(a, b)
    return len(a) == len(b) and all(igual(x, y) for x, y in zip(a, b))


try:
    import cadquery as cq
except ImportError:
    cq = None
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def vista3d(n, step):
    """Dibuja el STEP (teselado) en previews/3d_<nombre>.png para revisarlo a ojo."""
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection
    forma = cq.importers.importStep(step)
    fig = plt.figure(figsize=(11, 5), dpi=100)
    for i, (elev, azim, tit) in enumerate(((28, -60, 'vista desde el frente (boca / lado +Y de la huella)'), (28, 120, 'vista desde atras'))):
        ax = fig.add_subplot(1, 2, i + 1, projection='3d')
        todos = []
        for solido in forma.solids().vals():
            v, t = solido.tessellate(0.05, 0.3)
            pts = [(p.x, p.y, p.z) for p in v]
            tris = [[pts[a], pts[b], pts[c]] for a, b, c in t]
            todos += pts
            ax.add_collection3d(Poly3DCollection(tris, fc='#b9c4d0', ec='#404850', lw=0.15, alpha=1.0))
        xs, ys, zs = zip(*todos)
        r = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)) / 2
        cx, cy_, cz = (max(xs) + min(xs)) / 2, (max(ys) + min(ys)) / 2, (max(zs) + min(zs)) / 2
        ax.set_xlim(cx - r, cx + r); ax.set_ylim(cy_ - r, cy_ + r); ax.set_zlim(cz - r, cz + r)
        ax.set_box_aspect((1, 1, 1)); ax.view_init(elev=elev, azim=azim)
        ax.set_xlabel('X'); ax.set_ylabel('Y modelo = -Y huella'); ax.set_zlabel('Z'); ax.set_title(tit, fontsize=8)
    fig.suptitle(f'{n}.step  ({max(xs) - min(xs):.2f} x {max(ys) - min(ys):.2f} x {max(zs) - min(zs):.2f} mm con patas)', fontsize=9)
    fig.savefig(os.path.join(RAIZ, 'previews', '3d_' + n + '.png'), bbox_inches='tight'); plt.close(fig)

os.makedirs(os.path.join(RAIZ, 'previews'), exist_ok=True)
for n, libof in HUELLAS.items():
    ruta = os.path.join(RAIZ, 'puente_nodo.pretty', n + '.kicad_mod')
    fp = parse(open(ruta).read())
    pads = fp_pads(fp)
    LOG.append(f' {n}')
    ok(fp[0] == 'footprint' and fp[1] == n and kid(fp, 'version')[1] == '20240108', '  formato KiCad 8 (version 20240108), nombre igual al archivo')
    ok(pads == fp_pads(huella(f'{libof}:{n}')), f'  {len(pads)} pads identicos a los de {libof}:{n} (KiCad 8.0.8)')
    capas = {L: bbox(layer_pts(fp, L)) for L in ('F.SilkS', 'F.Fab', 'F.CrtYd')}
    ok(all(capas.values()), '  tiene serigrafia, F.Fab y F.CrtYd')
    cy = capas['F.CrtYd']
    cobre = [p for p in pads if p['num'] != '']
    ok(all(cy[0] <= p['x'] - min(p['w'], p['h']) / 2 and p['x'] + min(p['w'], p['h']) / 2 <= cy[2] and
           cy[1] <= p['y'] - min(p['w'], p['h']) / 2 and p['y'] + min(p['w'], p['h']) / 2 <= cy[3] for p in cobre), '  todos los pads dentro del courtyard')
    p1 = [p for p in pads if p['num'] in ('1', 'A1')]
    ok(bool(p1), f'  pad 1 presente en ({p1[0]["x"]}, {p1[0]["y"]}), forma {p1[0]["shape"]}')
    MEDIDAS[n] = medir(n, pads)
    for que, medido, esperado in MEDIDAS[n]:
        ok(igual(medido, esperado), f'  {que}: medido {medido}, esperado {esperado}')
    mod = kid(fp, 'model')[1]
    step = mod.replace('${KIPRJMOD}', RAIZ)
    ok(mod.startswith('${KIPRJMOD}/puente_nodo.3dshapes/') and os.path.isfile(step), f'  modelo 3D existe: {mod}')
    if cq and os.path.isfile(step):
        bb = cq.importers.importStep(step).val().BoundingBox()
        fb = capas['F.Fab']
        # el modelo usa Y invertida; el cuerpo (z >= 0.3) debe caber en F.Fab con 0.2 mm de margen
        ok(bb.xmin >= cy[0] - 0.01 and bb.xmax <= cy[2] + 0.01 and -bb.ymax >= cy[1] - 0.01 and -bb.ymin <= cy[3] + 0.01,
           f'  STEP dentro del courtyard: x {bb.xmin:.2f}..{bb.xmax:.2f}, y(huella) {-bb.ymax:.2f}..{-bb.ymin:.2f}, z {bb.zmin:.2f}..{bb.zmax:.2f}')
        ok(0 <= (bb.xmax - bb.xmin) - (fb[2] - fb[0]) <= 1.01 and bb.zmax > 0.5,
           f'  STEP: ancho con patas {bb.xmax - bb.xmin:.2f} mm contra F.Fab {fb[2] - fb[0]:.2f} mm; altura {bb.zmax:.2f} mm (VERIFICAR altura)')
        vista3d(n, step)

# ------------------------------------------------------------------ 4. tablas de librerias
titulo('4. sym-lib-table y fp-lib-table')
for arch, raiz, uri in (('sym-lib-table', 'sym_lib_table', '${KIPRJMOD}/puente_nodo.kicad_sym'), ('fp-lib-table', 'fp_lib_table', '${KIPRJMOD}/puente_nodo.pretty')):
    r = os.path.join(RAIZ, arch)
    if not os.path.isfile(r):
        ok(False, f'{arch} no existe'); continue
    t = parse(open(r).read())
    libs = [(kid(l, 'name')[1], kid(l, 'type')[1], kid(l, 'uri')[1]) for l in kids(t, 'lib')]
    ok(t[0] == raiz and libs == [('puente_nodo', 'KiCad', uri)], f'{arch}: {libs}')
    ok(os.path.exists(uri.replace('${KIPRJMOD}', RAIZ)), f'{arch}: la ruta existe')

# ------------------------------------------------------------------ 5. vistas previas
titulo('5. Vistas previas')
from matplotlib.patches import Rectangle, Circle, FancyBboxPatch, Ellipse

COL = {'F.SilkS': '#0a8f8f', 'F.Fab': '#8a8a8a', 'F.CrtYd': '#d43fd4', 'Dwgs.User': '#b0b0b0'}


def dibujar(n):
    fp = parse(open(os.path.join(RAIZ, 'puente_nodo.pretty', n + '.kicad_mod')).read())
    pads = fp_pads(fp)
    cy = bbox(layer_pts(fp, 'F.CrtYd'))
    w, h = cy[2] - cy[0], cy[3] - cy[1]
    esc = 12 / max(w, h)
    fig, ax = plt.subplots(figsize=(max(w * esc, 6) + 1, max(h * esc, 5) + 1.4), dpi=110)
    for g in fp:
        if not isinstance(g, list) or not kid(g, 'layer') or kid(g, 'layer')[1] not in COL:
            continue
        c = COL[kid(g, 'layer')[1]]
        lw = 1.0 if kid(g, 'layer')[1] != 'F.SilkS' else 1.6
        f = lambda k: (float(kid(g, k)[1]), float(kid(g, k)[2]))
        if g[0] == 'fp_line':
            (a, b), (c2, d) = f('start'), f('end'); ax.plot([a, c2], [b, d], color=c, lw=lw)
        elif g[0] == 'fp_rect':
            (a, b), (c2, d) = f('start'), f('end'); ax.plot([a, c2, c2, a, a], [b, b, d, d, b], color=c, lw=lw)
        elif g[0] == 'fp_circle':
            (a, b), (c2, d) = f('center'), f('end'); ax.add_patch(Circle((a, b), math.hypot(c2 - a, d - b), fill=False, ec=c, lw=lw))
        elif g[0] == 'fp_arc':
            pts = [f('start'), f('mid'), f('end')]; ax.plot([p[0] for p in pts], [p[1] for p in pts], color=c, lw=lw)
        elif g[0] == 'fp_poly':
            pts = [(float(x[1]), float(x[2])) for x in kids(kid(g, 'pts'), 'xy')]; pts.append(pts[0])
            ax.plot([p[0] for p in pts], [p[1] for p in pts], color=c, lw=lw)
    vistos = set()
    for p in pads:
        if p['layers'] == ['F.Paste']:
            continue
        tht = p['type'] in ('thru_hole', 'np_thru_hole')
        color = '#c8a03c' if p['type'] == 'thru_hole' else ('#ffffff' if p['type'] == 'np_thru_hole' else ('#3c6fc8' if 'B.Cu' in p['layers'] else '#c83c3c'))
        if p['shape'] in ('circle', 'oval'):
            ax.add_patch(Ellipse((p['x'], p['y']), p['w'], p['h'], fc=color, ec='k', lw=0.4, alpha=0.85, zorder=3 if tht else 2))
        else:
            ax.add_patch(Rectangle((p['x'] - p['w'] / 2, p['y'] - p['h'] / 2), p['w'], p['h'], fc=color, ec='k', lw=0.4,
                                   alpha=0.35 if p['w'] > 2 and p['h'] > 2 else 0.85, zorder=2))
        if p['drill']:
            dr = [float(x) for x in p['drill'] if x != 'oval']
            ax.add_patch(Ellipse((p['x'], p['y']), dr[0], dr[-1], fc='#202020', ec='none', zorder=4))
        clave = (p['num'], round(p['x'], 2), round(p['y'], 2))
        if p['num'] and clave not in vistos and not (p['num'] == '25' and p['type'] == 'thru_hole'):
            vistos.add(clave)
            chico = min(p['w'], p['h']) < 0.7
            dy = 0
            if chico:        # numero fuera del pad, hacia afuera del cuerpo
                dy = -(p['h'] / 2 + 0.25) if p['y'] < 0 else (p['h'] / 2 + 0.25)
                if p['w'] > p['h']:
                    dy = 0
            dx = (-(p['w'] / 2 + 0.3) if p['x'] < 0 else (p['w'] / 2 + 0.3)) if (chico and p['w'] > p['h']) else 0
            if n.startswith('USB_C') and p['num'][0] == 'B':
                dy = p['h'] / 2 + 0.25      # fila B: etiqueta del otro lado para que no se encime con la A
            ax.text(p['x'] + dx, p['y'] + dy, p['num'], ha='center', va='center', fontsize=6.5 if chico else 8,
                    rotation=90 if (chico and p['h'] > p['w'] and len(p['num']) > 1) else 0, zorder=6,
                    color='k' if (chico or not tht) else 'w', fontweight='bold')
    ax.plot([-0.4, 0.4], [0, 0], color='g', lw=0.8, zorder=7); ax.plot([0, 0], [-0.4, 0.4], color='g', lw=0.8, zorder=7)
    ax.set_xlim(cy[0] - 0.8, cy[2] + 0.8); ax.set_ylim(cy[3] + 0.8, cy[1] - 0.8)      # Y hacia abajo, como en KiCad
    ax.set_aspect('equal'); ax.grid(True, lw=0.3, alpha=0.5); ax.set_xlabel('mm'); ax.set_ylabel('mm')
    med = '\n'.join(f'{q}: {m}' for q, m, _ in MEDIDAS[n])
    ax.set_title(f'puente_nodo:{n}\n{med}', fontsize=8, loc='left')
    fig.text(0.01, 0.005, 'rojo = pad SMD F.Cu, dorado = pad con barreno, negro = barreno (sin anillo dorado = sin cobre), cian = serigrafia, gris = F.Fab, magenta = courtyard, cruz verde = origen',
             fontsize=6.5)
    out = os.path.join(RAIZ, 'previews', n + '.png')
    fig.savefig(out, bbox_inches='tight'); plt.close(fig)
    return out


for n in HUELLAS:
    o = dibujar(n)
    ok(os.path.getsize(o) > 5000, f'previews/{os.path.basename(o)}')

LOG.append(f'\nRESULTADO: {len([l for l in LOG if l.startswith("  OK")])} comprobaciones correctas, {len(FALLOS)} fallas')
txt = '\n'.join(LOG) + '\n'
open(os.path.join(RAIZ, 'validacion.txt'), 'w').write(txt)
print(txt)
sys.exit(1 if FALLOS else 0)
