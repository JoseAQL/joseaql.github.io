"""Parser minimo de s-expresiones de KiCad."""
import re
TOK = re.compile(r'"(?:\\.|[^"\\])*"|\(|\)|[^\s()"]+')
class S(str):
    """atomo entre comillas"""
def parse(text):
    stack=[[]]
    for m in TOK.finditer(text):
        t=m.group(0)
        if t=='(':
            l=[]; stack[-1].append(l); stack.append(l)
        elif t==')':
            stack.pop()
        elif t[0]=='"':
            stack[-1].append(S(t[1:-1].replace('\\"','"').replace('\\\\','\\')))
        else:
            stack[-1].append(t)
    assert len(stack)==1, "parentesis desbalanceados"
    return stack[0][0]
def kids(n,name):
    return [c for c in n if isinstance(c,list) and c and c[0]==name]
def kid(n,name):
    k=kids(n,name); return k[0] if k else None
def prop(n,key):
    for p in kids(n,'property'):
        if p[1]==key: return p[2]
def sym_pins(sym):
    """lista (numero,nombre,tipo,unidad) de un simbolo, recorriendo sub-simbolos"""
    out=[]
    for sub in kids(sym,'symbol'):
        m=re.match(r'.*_(\d+)_(\d+)$',sub[1]); unit=int(m.group(1)) if m else 0
        for p in kids(sub,'pin'):
            out.append((kid(p,'number')[1],kid(p,'name')[1],p[1],unit))
    return out
def fp_pads(fp):
    out=[]
    for p in kids(fp,'pad'):
        at=kid(p,'at'); sz=kid(p,'size'); dr=kid(p,'drill')
        out.append(dict(num=p[1],type=p[2],shape=p[3],x=float(at[1]),y=float(at[2]),
            rot=float(at[3]) if len(at)>3 else 0.0,w=float(sz[1]),h=float(sz[2]),
            drill=dr[1:] if dr else None, layers=kid(p,'layers')[1:]))
    return out


def layer_pts(fp,layer):
    pts=[]
    for g in fp:
        if not isinstance(g,list): continue
        l=kid(g,'layer')
        if not l or l[1]!=layer: continue
        if g[0] in('fp_line','fp_rect'):
            for k in('start','end'):
                a=kid(g,k); pts.append((float(a[1]),float(a[2])))
        elif g[0]=='fp_poly':
            for xy in kids(kid(g,'pts'),'xy'): pts.append((float(xy[1]),float(xy[2])))
        elif g[0]=='fp_circle':
            c=kid(g,'center'); e=kid(g,'end'); r=((float(e[1])-float(c[1]))**2+(float(e[2])-float(c[2]))**2)**.5
            pts+= [(float(c[1])-r,float(c[2])-r),(float(c[1])+r,float(c[2])+r)]
        elif g[0]=='fp_arc':
            for k in('start','mid','end'):
                a=kid(g,k); pts.append((float(a[1]),float(a[2])))
    return pts
def bbox(pts):
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    return (min(xs),min(ys),max(xs),max(ys)) if pts else None
