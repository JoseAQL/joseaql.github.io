#!/usr/bin/env python3
"""Genera puente_nodo.kicad_sym (formato KiCad 8, version 20231120).

Simbolos:
  TPD12S016PW        - nuevo (no existe en la libreria oficial 8.0.8)
  IS42S16160J-xTL    - nombres de ISSI; numeracion JEDEC igual a Memory_RAM:MT48LC16M16A2P
  STM32H743IITx_Nodo - 10 unidades; pines copiados de MCU_ST_STM32H7:STM32H743IITx

Uso: python3 gen_simbolos.py [carpeta_con_librerias_oficiales_kicad8]
"""
import os, re, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from kicad_sexp import parse, kids, kid, sym_pins

OFICIAL = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/herramientas/kicad8'
SALIDA = os.path.join(AQUI, '..', 'puente_nodo.kicad_sym')
P = 2.54          # rejilla de pines
LP = 5.08         # largo de pin
F = '(effects (font (size 1.27 1.27)))'


def q(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'


def prop(k, v, x, y, hide=False, just=''):
    e = '(effects (font (size 1.27 1.27))' + (f' (justify {just})' if just else '') + (' (hide yes)' if hide else '') + ')'
    return f'\t\t(property {q(k)} {q(v)} (at {x:g} {y:g} 0) {e})'


def pin(num, name, tipo, x, y, ang):
    return (f'\t\t\t(pin {tipo} line (at {x:g} {y:g} {ang}) (length {LP:g}) '
            f'(name {q(name)} {F}) (number {q(num)} {F}))')


def unidad(nombre, u, izq, der, ancho_min=0):
    """izq/der: listas de (num, nombre, tipo) o None para dejar un hueco."""
    n = max(len(izq), len(der))
    li = max([len(p[1]) for p in izq if p] + [1])
    ld = max([len(p[1]) for p in der if p] + [1])
    medio = max((li + ld) * 1.27 * 0.9 + 5.08, ancho_min) / 2
    medio = P * max(2, int(medio / P + 0.999))          # multiplo de 2.54
    alto = (n + 1) * P
    y0 = P * int(n / 2)                                 # primer pin (arriba)
    arriba, abajo = y0 + P, y0 - n * P
    out = [f'\t\t(symbol {q(f"{nombre}_{u}_1")}',
           f'\t\t\t(rectangle (start {-medio:g} {arriba:g}) (end {medio:g} {abajo:g}) '
           '(stroke (width 0.254) (type default)) (fill (type background)))']
    for i, p in enumerate(izq):
        if p:
            out.append(pin(p[0], p[1], p[2], -medio - LP, y0 - i * P, 0))
    for i, p in enumerate(der):
        if p:
            out.append(pin(p[0], p[1], p[2], medio + LP, y0 - i * P, 180))
    out.append('\t\t)')
    return '\n'.join(out), medio, arriba, abajo


def simbolo(nombre, ref, huella, hoja, descr, claves, filtros, unidades):
    cuerpos = []
    medio = arriba = abajo = 0
    for i, (izq, der) in enumerate(unidades, 1):
        txt, m, a, b = unidad(nombre, i, izq, der)
        cuerpos.append(txt)
        if i == 1:
            medio, arriba, abajo = m, a, b
    cab = [f'\t(symbol {q(nombre)}',
           '\t\t(exclude_from_sim no)', '\t\t(in_bom yes)', '\t\t(on_board yes)',
           prop('Reference', ref, -medio, arriba + 1.27, just='left'),
           prop('Value', nombre, -medio, abajo - 1.27, just='left'),
           prop('Footprint', huella, 0, abajo - 3.81, hide=True),
           prop('Datasheet', hoja, 0, abajo - 6.35, hide=True),
           prop('Description', descr, 0, 0, hide=True),
           prop('ki_keywords', claves, 0, 0, hide=True),
           prop('ki_fp_filters', filtros, 0, 0, hide=True)]
    return '\n'.join(cab + cuerpos + ['\t)'])


# ---------------------------------------------------------------- TPD12S016
# Fuente: tabla "Pin Functions" de la hoja de datos de TI SLLSE96F (encapsulado PW).
# La tabla agrupa "CLK+, CLK-" = 15, 16 y "D-, D+" = 17, 18, 20-23 sin decir cual es
# cual: el reparto individual de 15-18 y 20-23 esta marcado VERIFICAR en LIBRERIAS.md.
# Los ocho canales son diodos ESD identicos, asi que un intercambio no cambia el circuito.
B, I, O, W, PO, PA = 'bidirectional', 'input', 'output', 'power_in', 'power_out', 'passive'
TPD = simbolo(
    'TPD12S016PW', 'U', 'Package_SO:TSSOP-24_4.4x7.8mm_P0.65mm',
    'https://www.ti.com/lit/ds/symlink/tpd12s016.pdf',
    'Proteccion HDMI: ESD de 12 canales, cambio de nivel DDC/CEC/HPD e interruptor limitado de 5 V, TSSOP-24. '
    'VERIFICAR el reparto de pines 15-18 y 20-23 (CLK/D0/D1/D2, + y -) contra la hoja de datos.',
    'HDMI ESD DDC CEC HPD level shifter load switch', 'TSSOP*4.4x7.8mm*P0.65mm*',
    [([('24', 'VCCA', W), ('11', 'VCC5V', W), None,
       ('12', 'CT_HPD', I), ('5', 'LS_OE', I), None,
       ('2', 'SCL_A', B), ('3', 'SDA_A', B), ('1', 'CEC_A', B), ('4', 'HPD_A', O), None,
       ('6', 'GND', W), ('14', 'GND', W), ('19', 'GND', W)],
      [('13', '5V_OUT', PO), None,
       ('8', 'SCL_B', B), ('9', 'SDA_B', B), ('7', 'CEC_B', B), ('10', 'HPD_B', I), None,
       ('23', 'D2+', PA), ('22', 'D2-', PA), ('21', 'D1+', PA), ('20', 'D1-', PA),
       ('18', 'D0+', PA), ('17', 'D0-', PA), ('16', 'CLK+', PA), ('15', 'CLK-', PA)])])

# ---------------------------------------------------------------- SDRAM
# Numeracion JEDEC del TSOP-II-54 para SDRAM x16; es la misma del simbolo oficial
# Memory_RAM:MT48LC16M16A2P (validar.py la compara pin por pin).
dq = [2, 4, 5, 7, 8, 10, 11, 13, 42, 44, 45, 47, 48, 50, 51, 53]
ad = [23, 24, 25, 26, 29, 30, 31, 32, 33, 34, 22, 35, 36]
izq = [(str(n), f'A{i}' if i != 10 else 'A10/AP', I) for i, n in enumerate(ad)]
izq += [None, ('20', 'BA0', I), ('21', 'BA1', I), None,
        ('38', 'CLK', I), ('37', 'CKE', I), ('19', '~{CS}', I), ('18', '~{RAS}', I),
        ('17', '~{CAS}', I), ('16', '~{WE}', I), ('15', 'LDQM', I), ('39', 'UDQM', I),
        None, ('40', 'NC', 'no_connect')]
der = [(str(n), f'DQ{i}', B) for i, n in enumerate(dq)]
der += [None] + [(n, 'VDD', W) for n in ('1', '14', '27')] + [(n, 'VDDQ', W) for n in ('3', '9', '43', '49')]
der += [(n, 'VSS', W) for n in ('28', '41', '54')] + [(n, 'VSSQ', W) for n in ('6', '12', '46', '52')]
SDRAM = simbolo(
    'IS42S16160J-xTL', 'U', 'Package_SO:TSOP-II-54_22.2x10.16mm_P0.8mm',
    'https://www.issi.com/WW/pdf/42-45S83200J-16160J.pdf',
    'SDRAM 256 Mbit (16M x 16), 3.3 V, TSOP-II-54. Mismo pinout JEDEC que MT48LC16M16A2 y W9825G6KH.',
    'SDRAM 256Mbit 16Mx16 ISSI', 'TSOP*II*22.2x10.16mm*P0.8mm*', [(izq, der)])

# ---------------------------------------------------------------- STM32H743IITx
t = parse(open(os.path.join(OFICIAL, 'MCU_ST_STM32H7.kicad_sym')).read())
ofi = [s for s in kids(t, 'symbol') if s[1] == 'STM32H743IITx'][0]
pines = sorted(sym_pins(ofi), key=lambda p: int(p[0]))      # (num, nombre, tipo, unidad)
puertos = {}
otros = []
for num, nom, tipo, _ in pines:
    m = re.match(r'P([A-K])(\d+)', nom)
    if m:
        puertos.setdefault(m.group(1), []).append((int(m.group(2)), num, nom, tipo))
    else:
        otros.append((num, nom, tipo))


def de(nombre, tipo=None):
    return [(n, a, tipo or t_) for n, a, t_ in otros if a == nombre]


izq = de('VDD', W) + [None] + de('VBAT', W) + de('VDD33_USB', W) + de('VDDA', W) + de('VREF+') \
    + [None] + de('PDR_ON') + de('NRST') + de('BOOT0')
der = de('VCAP', PO) + [None] + de('VSS', W) + [None] + de('VSSA', W)
usados = {p[0] for p in izq + der if p}
assert usados == {p[0] for p in otros}, 'pines de sistema sin colocar'
uds = [(izq, der)]
for letra in sorted(puertos):
    ps = sorted(puertos[letra])
    uds.append(([(n, a, t_) for i, n, a, t_ in ps if i < 8], [(n, a, t_) for i, n, a, t_ in ps if i >= 8]))
MCU = simbolo(
    'STM32H743IITx_Nodo', 'U', 'Package_QFP:LQFP-176_24x24mm_P0.5mm',
    'https://www.st.com/resource/en/datasheet/stm32h743ii.pdf',
    'STM32H743IIT6 LQFP176 en 10 unidades (1 = alimentacion y sistema, 2-10 = puertos A-I). '
    'Pines copiados del simbolo oficial MCU_ST_STM32H7:STM32H743IITx de KiCad 8.0.8.',
    'Arm Cortex-M7 STM32H7 STM32H743', 'LQFP*24x24mm*P0.5mm*', uds)

with open(SALIDA, 'w') as f:
    f.write('(kicad_symbol_lib\n\t(version 20231120)\n\t(generator "puente_nodo_gen_simbolos")\n'
            '\t(generator_version "8.0")\n' + '\n'.join([SDRAM, MCU, TPD]) + '\n)\n')
print('escrito', os.path.normpath(SALIDA))
