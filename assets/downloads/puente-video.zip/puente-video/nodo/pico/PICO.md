# Nodo económico: Raspberry Pi Pico 2 + W5500 + DVI

La versión barata del nodo Ethernet → HDMI. En vez del STM32H743 con SDRAM usa un **Raspberry Pi Pico 2 (RP2350)**, un **módulo W5500** para la red y la salida **DVI por HSTX** del RP2350 (sale a cualquier pantalla HDMI). Habla exactamente el mismo protocolo que el nodo STM32 y el simulador, así que la PC (y el celular) lo ven como un nodo más.

```
PC / celular ──Ethernet──► W5500 ──SPI──► Pico 2 ──HSTX (DVI)──► pantalla HDMI
                                         núcleo 0: red + protocolo
                                         núcleo 1: JPEG + video
```

> **Estado:** compila (cero advertencias en nuestro código) y genera `puente_nodo_pico.uf2`. El dibujo (JPEG → RGB332 y pantalla del número) se probó en la PC con el mismo código. **Nada se ha probado todavía en una Pico 2 real.** Abajo está la lista de lo que falta revisar.

## Qué hay en esta carpeta

| Archivo | Qué hace |
|---|---|
| `src/main.c` | Arranque, relojes, reparto entre núcleos, bucle principal (red, protocolo, acuses, anuncio, LED, reporte por UART) |
| `src/dvi_hstx.c` | Salida DVI 640x480 a 60 Hz con el HSTX + 2 canales de DMA (adaptado de `pico-examples/hstx/dvi_out_hstx_encoder`, BSD‑3) |
| `src/red_w5500.c` | W5500 por SPI1 con la ioLibrary de WIZnet: DHCP, IP de respaldo, servidor TCP 5000, anuncio UDP |
| `src/pantalla_332.c` | JPEG con TJpgDec directo al framebuffer RGB332 (con tramado) y pantalla del número. C portable |
| `src/placa_pico.h` | Pines y constantes (tamaño de búferes, tiempos, IP de respaldo) |
| `../firmware/Core/Src/puente_nodo.c` | **El mismo** núcleo del protocolo del STM32 y del simulador (se usa por ruta relativa, no se copia) |
| `tjpgd/` | TJpgDec R0.03 de ChaN (sin cambios) + nuestra configuración `tjpgdcnf.h`. Licencia en `tjpgd/LICENCIA-TJPGD.txt` |
| `prueba_pc/` | Prueba en la PC del dibujo: decodifica JPEG como los manda la PC y los compara con OpenCV |
| `ci.sh` | Baja lo que falte y compila (para GitHub Actions o tu PC con Linux/WSL) |

## Lista de partes

Precios **aproximados** en pesos mexicanos (noviembre 2026, tiendas en línea tipo Mercado Libre / AliExpress / distribuidores de Raspberry Pi). Revísalos antes de comprar.

| Parte | Cuál | Precio aprox. |
|---|---|---|
| Microcontrolador | **Raspberry Pi Pico 2** (RP2350, la normal; la Pico 2 W también sirve) | $120 – $180 |
| Red | **Módulo W5500** (el azul de 10 pines "W5500 Ethernet module", con conector RJ45 y regulador) | $90 – $160 |
| Video | **DVI Sock para Pico** (diseño abierto de Luke Wren; también lo vende Adafruit) **o** conector HDMI hembra + 8 resistencias de 270 Ω | $50 – $200 |
| Número del nodo | DIP switch de 4 posiciones | $10 – $20 |
| Varios | Cables dupont cortos, protoboard o placa perforada, cable USB para la Pico, cable HDMI | $60 – $120 |
| Alimentación | Cargador USB de 5 V, 1 A o más | $60 – $100 |
| **Total** | | **≈ $400 – $750** |

### No uses la W5500‑EVB‑Pico2 tal cual

La placa de WIZnet **W5500‑EVB‑Pico2** (Pico 2 con W5500 integrado) tiene el W5500 en **GPIO16‑21** (MISO 16, CS 17, SCK 18, MOSI 19, RST 20, INT 21). Esos pines **chocan con el HSTX** (solo existe en GPIO12‑19), así que no puede sacar video. Usa una Pico 2 normal con un módulo W5500 aparte, conectado como dice la tabla.

## Conexiones

Todo a 3.3 V. Usa cables cortos para el SPI (menos de 10 cm si puedes).

| Pico 2 (pin físico) | GPIO | Va a | Notas |
|---|---|---|---|
| 1 | GP0 | Adaptador USB‑serial RX | UART0 TX, mensajes a 115200 (opcional) |
| 2 | GP1 | Adaptador USB‑serial TX | UART0 RX (opcional) |
| 4 | GP2 | DIP 1 → GND | número del nodo, bit 0 (valor 1) |
| 5 | GP3 | DIP 2 → GND | bit 1 (valor 2) |
| 6 | GP4 | DIP 3 → GND | bit 2 (valor 4) |
| 7 | GP5 | DIP 4 → GND | bit 3 (valor 8) |
| 9 | GP6 | W5500 **INT** | entrada; hoy no se usa (se lee por sondeo) |
| 10 | GP7 | W5500 **RST** | |
| 11 | GP8 | W5500 **MISO** (SO) | SPI1 RX |
| 12 | GP9 | W5500 **CS** (SCS) | se maneja como GPIO |
| 14 | GP10 | W5500 **SCK** (SCLK) | SPI1 SCK, 25 MHz |
| 15 | GP11 | W5500 **MOSI** (SI) | SPI1 TX |
| 16 | GP12 | HDMI **D0+** | azul |
| 17 | GP13 | HDMI **D0−** | |
| 19 | GP14 | HDMI **CK+** | reloj |
| 20 | GP15 | HDMI **CK−** | |
| 21 | GP16 | HDMI **D2+** | rojo |
| 22 | GP17 | HDMI **D2−** | |
| 24 | GP18 | HDMI **D1+** | verde |
| 25 | GP19 | HDMI **D1−** | |
| — | GP25 | LED de la placa | estado |
| 36 | 3V3(OUT) | W5500 **3.3V** | el módulo gasta ~130 mA; el regulador de la Pico 2 aguanta |
| 38 | GND | W5500 **GND**, DIP común, HDMI GND | |
| 40 | VBUS | HDMI pin 18 (+5 V) | algunas pantallas lo necesitan para detectar la fuente |

El orden GP12‑GP19 es el del ejemplo oficial `dvi_out_hstx_encoder` y del **Pico DVI Sock**: si usas el Sock, ya queda bien con solo soldarlo. Si armas tu propio conector HDMI, pon una resistencia de ~270 Ω en serie en cada uno de los 8 cables, como recomienda el ejemplo. (VERIFICAR con el esquemático de tu adaptador si ya las trae.)

> La **Pimoroni Pico DV Demo Base** usa otro orden de pares (es para la RP2040 con PIO). Con ella habría que cambiar `carril_a_bit` y el par de reloj en `src/dvi_hstx.c`. No está verificado.

Número del nodo: DIP cerrado = 1. Todos abiertos = nodo **1** (el valor por defecto). Va de 1 a 15. Se lee solo al arrancar.

## Cómo compilar

En Linux o WSL, con `cmake`, `ninja`, `git` y el compilador `arm-none-eabi-gcc` (13.x):

```sh
sh puente-video/nodo/pico/ci.sh <carpeta del gcc> <carpeta para herramientas>
# p. ej.  sh ci.sh ~/herramientas/gcc ~/herramientas
```

La primera vez baja Pico SDK 2.3.1 (sin submódulos: no se usa USB ni Wi‑Fi), la ioLibrary de WIZnet (commit fijo) y compila `picotool` 2.3.1 (el SDK lo necesita para hacer el `.uf2`). El resultado queda en `pico/build/puente_nodo_pico.uf2`.

Para que vaya más rápido el JPEG se puede subir el reloj: agrega `-DPP_RELOJ_KHZ=250000` al `cmake` (sube el voltaje a 1.20 V). **No probado**; el video no cambia porque su reloj sale del PLL de USB.

## Cómo grabarlo

1. Desconecta la Pico 2.
2. Mantén apretado el botón **BOOTSEL** y conéctala por USB a la PC.
3. Aparece una unidad llamada **RP2350**. Suelta el botón.
4. Arrastra `puente_nodo_pico.uf2` a esa unidad. La Pico se reinicia sola y arranca el nodo.

Para ver los mensajes conecta un adaptador USB‑serial de 3.3 V a GP0/GP1 y GND (115200 8N1). El USB de la Pico no saca mensajes (se apagó a propósito para no necesitar TinyUSB).

## Qué debe pasar

1. Al prender, la pantalla muestra el **número del nodo** en grande con **marco ámbar** (no hay nadie conectado).
2. El W5500 pide IP por DHCP. Si en **8 s** nadie contesta, se pone `192.168.77.(100 + número)`. La IP aparece abajo del número.
3. Cada segundo se anuncia por UDP: `PUENTE-NODO|<id>|640|480|5000`.
4. Cuando la PC se conecta, el marco cambia a **cian** y luego aparece el video.
5. Si deja de llegar video **3 s**, vuelve a la pantalla del número.
6. `IDENTIFICAR` muestra el número **3 s** aunque esté llegando video (esos cuadros se acusan sin mostrarse para no frenar a la PC).

LED de la placa:

| Parpadeo | Significa |
|---|---|
| Muy rápido (60 ms) | El W5500 no contesta: revisa SPI, RST y 3.3 V |
| Lento (1 s) | Sin cable de red |
| Medio (0.5 s) | Con red, esperando a la PC |
| 250 ms | Conectado, mostrando el número |
| Rápido (80 ms) | Conectado y mostrando video |

Por la UART sale cada 5 s algo como:
```
[nodo 3] 192.168.77.103 (respaldo)  5 cuadros/s  decodificar 160 ms  descartados 0  errores 0  dvi 1520
```
(`dvi` cuenta cuadros de video enviados a la pantalla: si no sube, el HSTX no está corriendo).

## Cómo probarlo con la PC

1. Conecta el nodo y la PC al mismo switch (o directo con un cable; el nodo tomará la IP de respaldo y la PC debe estar en `192.168.77.x`, p. ej. con `dhcp_simple.py` o IP fija `192.168.77.1`).
2. Abre Puente Video → **Pantallas HDMI (nodos)…**. El nodo aparece solo como **640x480**.
3. Elige **Patrón de prueba**: deben verse las barras de colores y el número. Luego prueba **Pantalla completa**.
4. Prueba **Identificar** / **Identificar todas**.
5. Desde el celular: deja el nodo en «Nada» en la PC y escribe la IP del nodo en la app.

## Memoria (SRAM de 520 KB)

| Qué | Bytes |
|---|---|
| Framebuffer 640x480 RGB332 | 307 200 |
| 2 búferes de JPEG de 80 KB | 163 840 |
| TJpgDec (área de trabajo, compartida con la pantalla del número) | 10 240 |
| Todo lo demás (SDK, red, DHCP, protocolo, tablas) | ~5 700 |
| Heap mínimo | 2 048 |
| **Usado en la SRAM principal** | **489 032 de 524 288 (quedan ~34 KB para el heap)** |
| Pilas: núcleo 0 en SCRATCH_Y, núcleo 1 + interrupción del DVI en SCRATCH_X | 2 x 4 KB aparte |

Flash: ~45 KB de programa.

### Por qué 640x480 en RGB332 y no 320x240

- 640x480 a 8 bits son 300 KB: **sí cabe** junto con 2 búferes de JPEG grandes. El HSTX tiene codificador TMDS que acepta RGB332 directo, así que no hace falta convertir nada por línea (el ejemplo oficial lo hace así).
- La PC manda el JPEG ya del tamaño que el nodo anuncia (640x480), así se aprovecha toda la resolución.
- RGB332 son solo 256 colores; para que los degradados no se vean en escalones se aplica **tramado ordenado 4x4** al decodificar. En la prueba de la PC la imagen queda bien; el texto pequeño se ve un poco granulado.
- 320x240 duplicado sería ~4 veces más rápido de decodificar y permitiría doble búfer, pero con la mitad de resolución y con más trabajo en la interrupción. Queda como idea para después (ver abajo).

### Relojes

- Sistema: 150 MHz (lo nominal del RP2350).
- HSTX: 126 MHz desde el **PLL de USB** (1512 MHz / 6 / 2). Con 5 ciclos por pixel da 25.2 MHz exactos → 640x480 a **60 Hz**. El ejemplo oficial dice 125 MHz, pero con el SDK 2.x el HSTX arranca a 150 MHz (eso daría ~71 Hz, fuera de norma), por eso aquí se configura aparte.
- SPI del W5500: 25 MHz (150 / 6).

## Rendimiento esperado (estimado, no medido)

Seamos honestos: esto es mucho más modesto que el STM32H743 con JPEG por hardware.

- **Decodificar un JPEG de 640x480 por software** en el Cortex‑M33 a 150 MHz: estimamos **120 – 250 ms** (en la PC tarda ~2 ms; el M33 es unas 60‑100 veces más lento). Eso da **≈ 4 – 8 cuadros por segundo**. Con 250 MHz podría subir ~1.6 veces.
- **Red:** el W5500 por SPI a 25 MHz mueve unos 2.5 MB/s reales; un JPEG de 50 KB tarda ~20 ms y se recibe **mientras** el otro núcleo decodifica el anterior. La red no es el cuello de botella.
- **Retardo:** ~1 a 2 cuadros (200 – 500 ms) entre la PC y la pantalla.
- **Se ve la imagen "llenarse" de arriba abajo** en cada cuadro: hay un solo framebuffer (no cabe un segundo de 300 KB) y la decodificación tarda varios refrescos de pantalla.
- **JPEG de más de 80 KB se descartan** (se acusan para no trabar a la PC, pero no se muestran). La PC manda a los nodos con calidad 75: video y patrón de prueba quedan en 15 – 60 KB; una captura de pantalla con mucho texto puede pasar de 80 KB. Si en la UART ves `descartados` subiendo, baja la calidad para nodos en `pc/nodos.py` (`self.calidad`) a 50 – 60.
- Colores: el codificador del HSTX llena con ceros los bits que faltan, así que el blanco sale como (224, 224, 192): un poco gris‑amarillento.

Sirve bien para: letreros, presentaciones, el patrón de prueba, video tranquilo. No sirve para video rápido a pantalla completa (para eso está el nodo STM32 o el de Raspberry Pi).

## Lo que NO está verificado en hardware

- [ ] Que la pantalla tome la señal DVI (orden de pares, polaridad, 60 Hz con el reloj de 126 MHz desde el PLL de USB).
- [ ] Que los colores salgan en su lugar (rojo en bits 7:5, verde 4:2, azul 1:0; deducido de la configuración del expansor TMDS del ejemplo).
- [ ] Que el W5500 funcione a 25 MHz con cables dupont (si falla, baja `PP_SPI_HZ` en `placa_pico.h` a 12.5 MHz).
- [ ] DHCP de la ioLibrary, IP de respaldo, anuncio por broadcast y reemplazo de cliente con dos sockets.
- [ ] Tiempos reales de decodificación y cuadros por segundo.
- [ ] Que la pila de 2 KB del núcleo 1 alcance para TJpgDec + la interrupción del DVI.
- [ ] Que la interrupción del DVI no se atrase con el núcleo 1 ocupado decodificando desde la flash (la interrupción vive en SCRATCH_X, en RAM).
- [ ] El modo con reloj subido (`PP_RELOJ_KHZ`).
- [ ] La conexión del celular directo al nodo.

## Ideas para después

- Modo 320x240 con doble búfer (RGB332, 2 x 75 KB) duplicando pixeles en la interrupción: más cuadros por segundo y sin "llenado".
- Pasar las funciones calientes de TJpgDec a RAM (quedan ~34 KB libres) para no depender de la caché de la flash.
- Usar el pin INT del W5500 en vez de sondear.
- Pico 2 con PSRAM (p. ej. Pimoroni Pico Plus 2) para búferes de JPEG más grandes.
