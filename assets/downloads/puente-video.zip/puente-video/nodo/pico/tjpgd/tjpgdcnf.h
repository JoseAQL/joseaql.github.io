/*
 * tjpgdcnf.h — configuración de TJpgDec R0.03 para el nodo con Pico 2.
 *
 * Este archivo es NUESTRO (los de ChaN son tjpgd.c y tjpgd.h, sin cambios).
 * Opciones elegidas para el Cortex-M33 del RP2350:
 *   - salida RGB888: así el tramado (dithering) a RGB332 sale mejor
 *   - escala activada: si llega un JPEG más grande que 640x480 se reduce
 *     a 1/2, 1/4 o 1/8 en vez de tirarlo
 *   - tabla de saturación y decodificación Huffman por tabla (lo más rápido;
 *     pide ~9.7 KB de área de trabajo)
 */
#define JD_SZBUF     512
#define JD_FORMAT    0
#define JD_USE_SCALE 1
#define JD_TBLCLIP   1
#define JD_FASTDECODE 2
