#!/bin/sh
# Compila el firmware del nodo económico (Raspberry Pi Pico 2) → puente_nodo_pico.uf2
#
# Uso: ci.sh <carpeta del gcc (la que tiene bin/)> <carpeta de herramientas>
#
# En <carpeta de herramientas> baja lo que falte (versiones fijas, para que
# siempre compile igual):
#   pico-sdk          2.3.1 (sin submódulos: no se usa USB ni Wi-Fi)
#   picotool          2.3.1 (solo para hacer el .uf2; se compila sin USB)
#   ioLibrary_Driver  de WIZnet, commit fijo
# Necesita además cmake (3.13+), ninja, git y un compilador de C/C++ de la PC.
#
# Termina con error si algo no compila o si hay advertencias en NUESTRO
# código (src/ y ../firmware/Core/Src/puente_nodo.c); lo de terceros va con -w.
set -e
GCC_DIR="$1"
HERR="$2"
if [ -z "$GCC_DIR" ] || [ -z "$HERR" ]; then
  echo "Uso: $0 <gcc_dir> <carpeta_herramientas>"; exit 2
fi
AQUI="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HERR"
HERR="$(cd "$HERR" && pwd)"
GCC_DIR="$(cd "$GCC_DIR" && pwd)"

SDK_VERSION=2.3.1
PICOTOOL_VERSION=2.3.1
IOLIB_COMMIT=e1791974e76d0b00cbac9e349ed92477b8d41386

if [ ! -f "$HERR/pico-sdk/pico_sdk_init.cmake" ]; then
  echo "== bajando pico-sdk $SDK_VERSION"
  git -c advice.detachedHead=false clone -q --depth 1 --branch "$SDK_VERSION" https://github.com/raspberrypi/pico-sdk.git "$HERR/pico-sdk"
fi

if [ ! -f "$HERR/ioLibrary_Driver/Ethernet/socket.c" ]; then
  echo "== bajando ioLibrary_Driver ($IOLIB_COMMIT)"
  rm -rf "$HERR/ioLibrary_Driver"
  git init -q "$HERR/ioLibrary_Driver"
  git -C "$HERR/ioLibrary_Driver" fetch -q --depth 1 https://github.com/Wiznet/ioLibrary_Driver.git "$IOLIB_COMMIT"
  git -C "$HERR/ioLibrary_Driver" -c advice.detachedHead=false checkout -q FETCH_HEAD
fi

PICOTOOL_DIR="$HERR/picotool-install/picotool"
if [ ! -f "$PICOTOOL_DIR/picotoolConfig.cmake" ]; then
  echo "== compilando picotool $PICOTOOL_VERSION (para hacer el .uf2)"
  if [ ! -d "$HERR/picotool" ]; then
    git -c advice.detachedHead=false clone -q --depth 1 --branch "$PICOTOOL_VERSION" https://github.com/raspberrypi/picotool.git "$HERR/picotool"
  fi
  cmake -G Ninja -S "$HERR/picotool" -B "$HERR/picotool/build" \
    -DPICO_SDK_PATH="$HERR/pico-sdk" \
    -DCMAKE_INSTALL_PREFIX="$HERR/picotool-install" -DPICOTOOL_FLAT_INSTALL=1 > "$HERR/picotool.log" 2>&1 \
    || { cat "$HERR/picotool.log"; exit 1; }
  ninja -C "$HERR/picotool/build" install >> "$HERR/picotool.log" 2>&1 || { cat "$HERR/picotool.log"; exit 1; }
fi

echo "== compilando el firmware del nodo Pico 2"
cd "$AQUI"
rm -rf build
PATH="$GCC_DIR/bin:$PATH" cmake -G Ninja -S . -B build \
  -DPICO_SDK_PATH="$HERR/pico-sdk" \
  -DIOLIBRARY_PATH="$HERR/ioLibrary_Driver" \
  -Dpicotool_DIR="$PICOTOOL_DIR" \
  -DPICO_TOOLCHAIN_PATH="$GCC_DIR" > build-config.log 2>&1 || { cat build-config.log; exit 1; }
PATH="$GCC_DIR/bin:$PATH" ninja -C build > build.log 2>&1 || { cat build.log; exit 1; }
if grep -n "warning:" build.log; then
  echo "Hay advertencias al compilar"; exit 1
fi
rm -f build.log build-config.log
test -f build/puente_nodo_pico.uf2

echo "== memoria"
"$GCC_DIR/bin/arm-none-eabi-size" build/puente_nodo_pico.elf
# RAM: todo lo que va de 0x20000000 a 0x20080000 (512 KB; aparte 2 x 4 KB de scratch)
"$GCC_DIR/bin/arm-none-eabi-size" -A build/puente_nodo_pico.elf | awk '
  $3 >= 536870912 && $3 < 537395200 { ram += $2 }
  END { printf "SRAM principal usada: %d de 524288 bytes (%d KB libres para el heap)\n", ram, (524288 - ram) / 1024 }'

echo "== prueba del dibujo en la PC (mismo código que el núcleo 1)"
sh "$AQUI/prueba_pc/prueba_pc.sh" "$AQUI/build/prueba_pc"

echo "Listo: $AQUI/build/puente_nodo_pico.uf2"
