# Placa base del nodo económico (Pico 2 + W5500 + HDMI)

Proyecto de KiCad de una placa de 2 capas, **80 × 70 mm**, donde se enchufan la **Raspberry Pi Pico 2** y el **módulo W5500** en tiras hembra, con el conector **HDMI** soldado en la orilla. Sustituye al cableado con dupont de `../PICO.md` y usa exactamente los mismos pines (`../src/placa_pico.h`), así que el firmware no cambia.

> **Estado: sin fabricar y sin abrir en KiCad.** Los archivos se generaron y revisaron por programa (sección 8), pero en el ambiente donde se hicieron no había KiCad. La primera prueba real es abrirlos (sección 9). Todo lo que dice **VERIFICAR** hay que revisarlo antes de mandar a fabricar; la lista completa está en la sección 7.

## 1. Archivos

| Archivo | Qué es |
|---|---|
| `puente_pico.kicad_pro` | Proyecto (reglas de diseño y clases de red `TMDS` y `Potencia`) |
| `puente_pico.kicad_sch` | Esquemático completo, una hoja A3. Formato de KiCad 8 |
| `puente_pico.kicad_pcb` | Placa: contorno, todas las huellas colocadas con sus redes, **pares TMDS ya trazados**, lo demás sin trazar |
| `puente_pico.kicad_sym`, `sym-lib-table` | Librería del proyecto con los 2 símbolos propios (Pico 2 y módulo W5500). Las huellas son todas oficiales, no hay librería de huellas propia |
| `NETLIST.txt` | Lista de redes sacada del esquemático |
| `validacion.txt` | Salida de la última validación |
| `previews/*.png` | Dibujos rápidos de la placa y del esquemático (hechos por el validador, **no** son la vista de KiCad) |
| `herramientas/` | `gen_carrier.py` (genera todo), `validar_carrier.py` (lo revisa), `sx.py` |

Las huellas y símbolos copiados dentro del proyecto vienen de las librerías oficiales de KiCad 8.0.8 (licencia CC‑BY‑SA 4.0 con excepción para usarlas en diseños; ver `../../hardware/kicad/LICENCIA-KiCad.md`).

## 2. Diagrama de bloques

```
                    USB de la Pico (5 V) ──► VBUS ──┐
 J5 USB-C ─┐                                        │ (diodo dentro de la Pico)
 J4 bornera┴─► +5V ──D1──────────────────────────► VSYS ──► regulador de la Pico ──► +3V3
                 │                                                                     │
                 └──D3──┬──F1 (200 mA)──► +5 V del HDMI (pin 18)                       │
          VBUS ──D2─────┘                                                              │
                                                                                       ▼
 Red ──RJ45──► [J2 módulo W5500] ◄──SPI1 GP8-11, RST GP7, INT GP6──► [A1 Pico 2] ── 3V3 al módulo
                                                                        │
                    SW1 DIP x4 ── GP2-5 (a GND)                         ├─ GP12-19 (HSTX) ─ R1-R8 270 Ω ─► [J1 HDMI]
                    J3 UART ───── GP0/GP1                               ├─ GP20/21 ─ R14/R15 (no montar) ─ DDC
                    SW2 reset ─── RUN                                   └─ GP22 ◄─ R16/R17 ─ HPD
```

## 3. Decisiones de diseño (y por qué)

- **Pico 2 en zócalo** con la huella oficial `Module:RaspberryPi_Pico_Common_THT`. El USB de la Pico queda hacia la orilla izquierda. El símbolo es propio porque la librería de KiCad 8.0.8 no trae uno de la Pico. A la copia de la huella se le quitaron las zonas "sin cobre" de la antena (solo importan con una Pico 2 **W**; si usas la W, no pongas cobre bajo la antena o vuelve a cargar la huella de la librería).
- **Módulo W5500 de 10 pines (2×5)**, el que ya recomienda `PICO.md`: es el más fácil de conseguir (Mercado Libre, AliExpress), trae RJ45 con transformador y regulador. Se alimenta por su pin **3.3V** desde el 3V3 de la Pico (gasta ~130 mA); su pin **5V** queda sin conectar para no tener dos reguladores peleando. Pinout que se supuso, visto desde arriba con el módulo enchufado — **VERIFICAR con la serigrafía de tu módulo antes de fabricar**:

  | Columna interior (pads pares de J2) | Columna de la orilla (pads impares de J2) |
  |---|---|
  | 5V (sin conectar) | 3.3V |
  | GND | MISO |
  | RST | MOSI |
  | INT | SCS |
  | NC | SCLK |

  La placa lleva esos nombres en la serigrafía junto a cada pin para compararlos a ojo. Si tu módulo tiene las columnas al revés, cambia la tabla `W5500` y las redes de `J2` en `gen_carrier.py` y regenera (o intercambia las redes en KiCad). No se usó el "W5500 Lite / USR‑ES1" (2 tiras de 6 pines) porque su pinout cambia entre clones.
- **HDMI en la placa** con 8 resistencias de **270 Ω** en serie (una por línea TMDS), igual que el Pico DVI Sock y que el comentario del ejemplo oficial `dvi_out_hstx_encoder`. El orden de pares es el de `PICO.md`: GP12/13 = D0±, GP14/15 = CK±, GP16/17 = D2±, GP18/19 = D1±. Con la Pico acostada y el HDMI a la derecha, ese orden cae **sin ningún cruce** hacia los pines del conector.
- **+5 V del HDMI (pin 18)**: sale de un OR de dos diodos Schottky (D2 desde VBUS, D3 desde los 5 V externos) y un polifusible F1. Así hay 5 V en el HDMI con cualquiera de las dos fuentes, la pantalla no puede meterle corriente a la placa y un corto en el cable no tumba a la Pico. Quedan ~4.7 V en el pin (la norma pide 4.8 V mínimo en la fuente): suele funcionar, pero es **VERIFICAR** con tu pantalla; si no detecta señal, puentea D2/D3 con una gota de soldadura como prueba.
- **DDC (SDA/SCL)**: el firmware saca 640×480 fijo y no lee el EDID, así que **R12–R15 no se montan** (marcadas DNP) y las líneas quedan al aire del lado de la Pico. Se dejaron las huellas (R14/R15 de 100 Ω hacia GP20/GP21 = I2C0, R12/R13 de 2.2 kΩ a los 5 V del HDMI) por si un día se quiere leer el EDID. Antes de montarlas **VERIFICAR**: el bus DDC es de 5 V y aquí no hay conversor de nivel (Adafruit sí pone uno en su PiCowBell HSTX); los GPIO del RP2350 toleran 5 V solo con la Pico encendida.
- **HPD**: divisor R16/R17 (10 k/20 k) que baja los 5 V a 3.3 V hacia **GP22**. El firmware hoy no lo lee; no estorba.
- **CEC y UTILITY**: sin conectar.
- **Protección ESD en TMDS**: no se puso. Los arreglos de diodos para HDMI vienen en encapsulados de paso 0.4–0.5 mm sin patas, difíciles de soldar a mano. Las resistencias de 270 Ω limitan algo la corriente. Para uso en escritorio es aceptable; si el nodo va a quedar instalado, considera agregarla.
- **Alimentación**: tres formas, todas a 5 V. (a) el USB de la Pico; (b) la bornera J4; (c) el USB‑C J5 (solo corriente, con sus dos resistencias de 5.1 kΩ). J4 y J5 entran a VSYS por el Schottky D1, que es el esquema que recomienda la hoja de datos de la Pico: se puede tener el USB de la Pico conectado a la PC y la fuente externa al mismo tiempo. D1 también protege si conectas la bornera al revés. **J4 y J5 están en paralelo: no conectes los dos a la vez.**
- **Extras**: botón de reset (RUN a GND; útil porque el DIP se lee solo al arrancar), LED de encendido en 3V3, conector UART de 3 pines (GND, TX, RX), 4 barrenos M3 a 4 mm de cada esquina.

### Alternativa: adaptador DVI en vez del conector soldado

Si no quieres soldar el HDMI de paso 0.5 mm, hay dos caminos sin esta placa: el **DVI Sock para Pico** (se suelda en la punta de la Pico, ya trae las 270 Ω) o un **breakout DVI/HDMI** con cables cortos como dice `PICO.md`. Para usarlos con esta placa habría que no montar J1 ni R1–R8 y sacar las señales de los pads de R1–R8 (lado de la Pico); el Sock no cabe con la Pico en zócalo. No está previsto un conector para eso: si lo quieres, es un cambio de diseño.

## 4. Lista de partes (BOM)

Precios **aproximados** en pesos (noviembre 2026), para darse una idea. Los pasivos SMD se venden en tiras; el precio es por lo que usa la placa.

| Ref | Parte | Huella | Cant. | Aprox. MXN | Dónde |
|---|---|---|---|---|---|
| A1 | Raspberry Pi Pico 2 (con pines soldados) | zócalo | 1 | 120–180 | 330ohms, Mercado Libre, distribuidores Raspberry Pi |
| — | Tira hembra 1×20, paso 2.54 | (zócalo de A1) | 2 | 20–30 | AG Electrónica, Steren, Mercado Libre |
| J2 | Tira hembra 2×5, paso 2.54 | PinSocket 2×05 | 1 | 10–15 | igual |
| — | Módulo W5500 de 10 pines | (se enchufa en J2) | 1 | 90–160 | Mercado Libre, AliExpress |
| J1 | Conector HDMI tipo A hembra, SMD de 19 pines en una fila, 4 patas pasantes (Amphenol 10029449‑111RLF o clon de la misma huella) | `HDMI_A_Amphenol_10029449` | 1 | 15–60 | LCSC, Mouser, DigiKey, AliExpress |
| R1–R8 | 270 Ω 0603 1 % | 0603 | 8 | 5 | LCSC, AG Electrónica, AliExpress |
| R9, R10 | 5.1 kΩ 0603 | 0603 | 2 | 2 | igual |
| R11 | 1 kΩ 0603 | 0603 | 1 | 1 | igual |
| R16 / R17 | 10 kΩ / 20 kΩ 0603 | 0603 | 1 / 1 | 2 | igual |
| R12, R13 / R14, R15 | 2.2 kΩ / 100 Ω 0603 — **no montar** | 0603 | 2 / 2 | — | — |
| D1–D3 | Schottky B5819W (1 A, 40 V) | SOD‑123 | 3 | 6–10 | LCSC, AliExpress, AG Electrónica |
| F1 | Polifusible 1206, 200 mA de sostenimiento | 1206 | 1 | 5–10 | LCSC, Mouser |
| D4 | LED verde 0805 | 0805 | 1 | 1–2 | cualquiera |
| C1, C2 | 10 µF 0805, 10 V o más | 0805 | 2 | 4 | cualquiera |
| C3 | 100 nF 0603 | 0603 | 1 | 1 | cualquiera |
| SW1 | DIP switch de 4 posiciones, pasante | DIP‑8 de 7.62 mm | 1 | 10–20 | Steren, AG Electrónica |
| SW2 | Botón táctil 6×6 mm pasante | SW_PUSH_6mm | 1 | 3–5 | cualquiera |
| J3 | Tira macho 1×3 | PinHeader 1×03 | 1 | 2 | cualquiera |
| J4 | Bornera de 2 tornillos, paso 5.08 | Phoenix MKDS‑1,5‑2‑5.08 | 1 | 8–15 | Steren, AG Electrónica |
| J5 | USB‑C de 6 pines, solo corriente (GCT USB4125 o clon de la misma huella) — opcional si usas la bornera | `USB_C_Receptacle_GCT_USB4125` | 1 | 5–25 | LCSC, AliExpress |
| H1–H4 | Barreno M3 | — | 4 | — | separadores y tornillos M3: 20–40 |
| — | PCB 80 × 70 mm, 2 capas, 5 piezas | — | — | 40–80 + envío (150–400) | JLCPCB |

Total aproximado sin envío, sin fuente ni cables: **≈ $450 – $750** (la Pico y el módulo W5500 son más de la mitad).

## 5. Tabla de conexiones

Es la misma de `PICO.md`; la lista completa por pin está en `NETLIST.txt`.

| Pico 2 (pin) | GPIO | Red | Va a |
|---|---|---|---|
| 1 / 2 | GP0 / GP1 | `UART_TX` / `UART_RX` | J3 pin 2 / pin 3 (pin 1 = GND) |
| 4, 5, 6, 7 | GP2–GP5 | `ID0`–`ID3` | SW1 posiciones 1–4, el otro lado a GND |
| 9 | GP6 | `W5500_INT` | J2 pad 8 (INT) |
| 10 | GP7 | `W5500_RST` | J2 pad 6 (RST) |
| 11 | GP8 | `W5500_MISO` | J2 pad 3 (MISO) |
| 12 | GP9 | `W5500_CS` | J2 pad 7 (SCS) |
| 14 | GP10 | `W5500_SCK` | J2 pad 9 (SCLK) |
| 15 | GP11 | `W5500_MOSI` | J2 pad 5 (MOSI) |
| 16 / 17 | GP12 / GP13 | `HSTX_D0_P/N` → R5 / R6 → `TMDS_D0_P/N` | J1 pines 7 / 9 |
| 19 / 20 | GP14 / GP15 | `HSTX_CK_P/N` → R7 / R8 → `TMDS_CK_P/N` | J1 pines 10 / 12 |
| 21 / 22 | GP16 / GP17 | `HSTX_D2_P/N` → R1 / R2 → `TMDS_D2_P/N` | J1 pines 1 / 3 |
| 24 / 25 | GP18 / GP19 | `HSTX_D1_P/N` → R3 / R4 → `TMDS_D1_P/N` | J1 pines 4 / 6 |
| 26 / 27 | GP20 / GP21 | `GP20_SDA` / `GP21_SCL` | R14 / R15 (no montadas) → J1 pines 16 / 15 |
| 29 | GP22 | `GP22_HPD` | divisor R16/R17 desde J1 pin 19 |
| 30 | RUN | `RUN` | SW2 a GND |
| 36 | 3V3(OUT) | `+3V3` | J2 pad 1 (3.3V del módulo), C2, C3, LED |
| 39 | VSYS | `VSYS` | cátodo de D1 (5 V de J4/J5), C1 |
| 40 | VBUS | `VBUS` | ánodo de D2 (hacia el +5 V del HDMI) |
| 3, 8, 13, 18, 23, 28, 33, 38 | GND / AGND | `GND` | plano de tierra; J1 pines 2, 5, 8, 11, 17 y carcasa |
| 31, 32, 34, 35, 37 | GP26–28, ADC_VREF, 3V3_EN | — | sin conectar |

J1 pines 13 (CEC) y 14 (UTILITY) sin conectar; pin 18 = `HDMI_5V`.

## 6. Reglas de trazado

**Lo que ya viene trazado** (capa de arriba, pista de 0.2 mm): las 8 líneas TMDS, de la Pico a su resistencia y de ahí al HDMI, sin vías y sin cruces, más 5 tramos cortos con vía a tierra para los blindajes del HDMI (pines 2, 5, 8, 11, 17). Largo total por línea: 21 a 36 mm. Diferencia dentro de cada par: **≈ 4.1 mm** (unos 28 ps; un bit de 640×480 dura casi 4000 ps, así que no hace falta compensar). Puedes borrarlas y volver a trazarlas si prefieres ángulos de 45°.

**Sobre los 100 Ω diferenciales, siendo realistas.** En una placa de 2 capas de 1.6 mm no se llega a 100 Ω con pistas finas: una pista de 0.2 mm sobre plano a 1.5 mm de distancia anda por 130–150 Ω y el par por 150 Ω o más; para bajar a 100 Ω harían falta pistas de ~0.8–1 mm que no caben entre los pines del HDMI. Aquí **no importa** por tres razones: el reloj de pixel es de 25.2 MHz (252 Mbit/s por línea), los tramos miden 2–4 cm (mucho menos que la longitud de onda de los flancos) y las 270 Ω en serie ya dominan la impedancia de la fuente. Es lo mismo que hacen el DVI Sock y los adaptadores de Adafruit. Lo que sí importa:

1. **Plano de tierra continuo en la capa de abajo** bajo todo el recorrido TMDS (entre el extremo de la Pico y el HDMI). No pases por ahí pistas en la capa de abajo. Si de plano tienes que cruzar (HPD, DDC, +5 V del HDMI), hazlo **por fuera**: rodea por abajo del conector o cruza pegado a la orilla, con un tramo corto.
2. No pongas vías en las líneas TMDS ni las alargues. No hace falta serpentear.
3. Cada par junto, y los pares alejados de las pistas del SPI y del reloj `W5500_SCK`.
4. Cose los planos de tierra de arriba y abajo con vías cerca del HDMI y de las resistencias.

**Lo demás** (lo trazas tú):

| Red | Ancho | Notas |
|---|---|---|
| `+5V`, `VBUS`, `VSYS`, `+3V3`, `HDMI_5V`, `HDMI_5V_F` | 0.6 mm (clase `Potencia`) | `+3V3` hacia J2 lleva ~130 mA; C2 y C3 pegados a J2 pad 1 |
| SPI (`W5500_*`) | 0.25 mm | lo más corto y directo posible, juntas, sobre plano de tierra; corre a 25 MHz |
| `ID*`, `UART_*`, `RUN`, HPD, DDC, LED | 0.25 mm | sin cuidado especial; pueden ir por abajo del módulo W5500 |
| `GND` | plano en las dos capas | ya están dibujadas las dos zonas; se rellenan con **B** |

Reglas del proyecto (caben en la capacidad estándar de JLCPCB): separación mínima 0.15 mm (0.2 mm por defecto), pista mínima 0.15 mm, vía 0.6/0.3 mm, cobre a 0.3 mm del borde.

## 7. Qué hay que VERIFICAR

1. **Que el proyecto abra en KiCad 10** sin errores (no se pudo probar) y que el ERC y el DRC salgan como dice la sección 9.
2. **Pinout y orientación del módulo W5500** contra su serigrafía (sección 3). Es el riesgo más grande: si está en espejo, el módulo recibe 3.3 V donde no es.
3. **Tamaño del módulo W5500** (se supuso ≈ 55 × 28 mm, con el conector 2×5 centrado en el extremo contrario al RJ45). Está dibujado con línea punteada en la capa `Dwgs.User`. Mide el tuyo: el RJ45 debe quedar hacia la orilla izquierda sin chocar con nada. El barreno H3 queda **debajo** del módulo: atornilla la placa antes de enchufarlo.
4. **Conector HDMI**: que el que compres tenga la huella del Amphenol 10029449 (19 pads en una fila a 0.5 mm, 4 patas de carcasa). Hay muchos clones parecidos con las patas en otro lugar. Lo mismo con el USB‑C de 6 pines y la bornera.
5. **Resistencias de 270 Ω**: valor tomado del ejemplo oficial y del DVI Sock; no se probó en esta placa.
6. **+5 V del HDMI a ~4.7 V** y HPD: probar con tu pantalla.
7. **DDC** (R12–R15): no montar hasta confirmar niveles de voltaje.
8. **Altura**: la Pico y el módulo en zócalos de 8.5 mm; revisa que el RJ45 del módulo no pegue con el cable USB de la Pico.
9. Modelos 3D: las huellas apuntan a `${KICAD8_3DMODEL_DIR}`; en KiCad 10 puede que no aparezcan en la vista 3D hasta actualizar las huellas desde la librería (no afecta la fabricación).
10. El firmware tampoco se ha probado en una Pico 2 real (ver `PICO.md`). **Recomendación: arma primero el circuito en protoboard con cables**, confirma que hay video y red, y hasta entonces manda a hacer la placa.

## 8. Qué se validó por programa

`herramientas/validar_carrier.py` lee los tres archivos (con un analizador propio y otra vez con `kiutils`) y revisa, sin usar las tablas del generador:

- la lista de redes se saca del esquemático **por geometría** (posición de pines, cables y etiquetas) y se compara **pad por pad** con la PCB: 150 pads, 37 componentes, 45 redes, todo igual; cada huella apunta a su símbolo;
- revisión tipo ERC: ningún pin al aire sin marca de "no conectado", ninguna red de un solo pin, toda entrada de alimentación tiene fuente o `PWR_FLAG`, no hay dos salidas juntas, no hay cortos entre redes con nombre distinto, todo en la rejilla de 1.27 mm;
- placa: ninguna zona de cortesía encimada, todo dentro del contorno (salvo los conectores de orilla, a propósito), separación mínima de las pistas trazadas a cobre de otra red = 0.225 mm, ninguna pista con un extremo al aire, largos de los pares.

Resultado: **18 comprobaciones, 0 fallas** (`validacion.txt`). Esto **no** sustituye al ERC y DRC de KiCad.

Para regenerar: `python3 herramientas/gen_carrier.py && python3 herramientas/validar_carrier.py`. **Ojo: regenerar sobrescribe el `.kicad_sch` y el `.kicad_pcb`**, incluido lo que hayas trazado a mano. Una vez que empieces a trazar en KiCad, ya no regeneres; edita en KiCad.

## 9. Paso a paso en KiCad 10

1. **Abrir.** Abre `puente_pico.kicad_pro`. KiCad avisará que los archivos son de una versión anterior; acepta. Al guardar los pasa a su formato (ya no abrirán en KiCad 8).
2. **Esquemático.** Abre el editor de esquemáticos. Si pregunta por la tabla de librerías del proyecto, deja la que viene (`puente_pico`). Corre **Inspeccionar → Verificador de reglas eléctricas (ERC)**. Lo esperado: 0 errores. Pueden salir advertencias de "el símbolo no coincide con el de la librería" (los símbolos copiados son de la 8.0.8); se quitan con **Herramientas → Actualizar símbolos desde la librería** o se ignoran.
3. **Pasar a la placa.** **Herramientas → Actualizar PCB desde el esquemático** (F8). No debe agregar ni quitar huellas ni cambiar redes; si propone cambios de redes, **detente** y revisa (sería señal de que KiCad interpreta algo distinto al validador).
4. **Editor de placas.** Revisa la colocación contra tus piezas reales (sección 7, puntos 2–4). Mueve lo que haga falta, menos R1–R8 y J1 si quieres conservar el trazado TMDS.
5. **Rellenar tierra.** Tecla **B**. Revisa que el plano de abajo quede entero bajo las TMDS.
6. **Trazar** lo que falta (tecla **X**), con los anchos de la sección 6. Las clases de red ya asignan el ancho solas. Vuelve a rellenar con **B** al final.
7. **DRC.** **Inspeccionar → Verificador de reglas de diseño**, con "Probar pistas contra zonas rellenas" activado. Corrige hasta tener 0 errores y 0 redes sin conectar. Es normal una advertencia de que la zona de cortesía de J1, J4 y J5 sale del borde.
8. **Vista 3D** (Alt+3) para una última revisión de alturas y choques.
9. **Gerbers para JLCPCB.** **Archivo → Salidas de fabricación → Gerbers**: capas `F.Cu`, `B.Cu`, `F.Paste`, `B.Paste`, `F.Silkscreen`, `B.Silkscreen`, `F.Mask`, `B.Mask`, `Edge.Cuts`; formato de coordenadas 4.6 en mm; activa "Usar extensiones de nombre Protel". Carpeta de salida `gerbers/`. Luego **Generar archivos de taladrado**: Excellon, mm, origen absoluto, PTH y NPTH en un archivo o separados (JLCPCB acepta ambos), y genera también el mapa de taladros.
10. Comprime la carpeta `gerbers/` en un `.zip` y súbelo a jlcpcb.com. Opciones: 2 capas, 80 × 70 mm, FR‑4 de 1.6 mm, cobre de 1 oz, acabado HASL (con plomo es más fácil de soldar a mano), color al gusto. Revisa la vista previa del sitio antes de pagar.
11. **Soldar** en este orden: HDMI (con flux, primero los 19 pines, luego la carcasa), USB‑C, pasivos SMD y diodos (ojo con la raya del cátodo), y al final lo pasante: zócalos, DIP, botón, bornera. Antes de enchufar la Pico y el módulo, mete 5 V por la bornera y mide: 5 V en `+5V`, ~4.7 V en VSYS (pin 39 del zócalo) y en el pin 18 del HDMI, y que no haya corto entre 3V3 y GND.
