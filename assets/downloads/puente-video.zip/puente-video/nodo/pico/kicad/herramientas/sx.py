"""S-expresiones de KiCad: leer y escribir (conserva las cadenas tal cual)."""
import re
TOK = re.compile(r'"(?:\\.|[^"\\])*"|\(|\)|[^\s()"]+')


class S(str):
    """atomo entre comillas (contenido crudo, con sus escapes)"""


def parse(text):
    stack = [[]]
    for m in TOK.finditer(text):
        t = m.group(0)
        if t == '(':
            l = []
            stack[-1].append(l)
            stack.append(l)
        elif t == ')':
            stack.pop()
        elif t[0] == '"':
            stack[-1].append(S(t[1:-1]))
        else:
            stack[-1].append(t)
    assert len(stack) == 1, 'parentesis desbalanceados'
    return stack[0][0]


def q(s):
    """cadena nueva -> atomo entre comillas (escapa)"""
    return S(str(s).replace('\\', '\\\\').replace('"', '\\"'))


def num(v):
    if isinstance(v, str):
        return v
    s = ('%.4f' % v).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def atom(a):
    if isinstance(a, S):
        return '"' + a + '"'
    if isinstance(a, (int, float)):
        return num(a)
    return a


def dump(n, ind=0):
    if not isinstance(n, list):
        return atom(n)
    if all(not isinstance(c, list) for c in n):
        return '(' + ' '.join(atom(c) for c in n) + ')'
    flat = '(' + ' '.join(dump(c) for c in n) + ')'
    if len(flat) < 100 and flat.count('(') < 6:
        return flat
    out = []
    i = 0
    head = []
    while i < len(n) and not isinstance(n[i], list):
        head.append(atom(n[i]))
        i += 1
    out.append('(' + ' '.join(head))
    for c in n[i:]:
        out.append('\t' * (ind + 1) + dump(c, ind + 1))
    return '\n'.join(out) + '\n' + '\t' * ind + ')'


def kids(n, name):
    return [c for c in n if isinstance(c, list) and c and c[0] == name]


def kid(n, name):
    k = kids(n, name)
    return k[0] if k else None


def prop(n, key):
    for p in kids(n, 'property'):
        if p[1] == key:
            return p[2]
