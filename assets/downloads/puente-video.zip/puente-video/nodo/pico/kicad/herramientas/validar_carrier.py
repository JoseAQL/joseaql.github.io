#!/usr/bin/env python3
"""Valida el proyecto puente_pico (esquematico, PCB y proyecto) sin KiCad.

Uso: python3 validar_carrier.py
Lee los archivos generados (no las tablas de gen_carrier.py), saca la lista de redes del
esquematico por geometria (pines, cables, etiquetas), la compara pad por pad con la PCB,
hace una revision tipo ERC y una revision de separaciones de las pistas ya trazadas.
Escribe ../NETLIST.txt, ../validacion.txt y ../previews/*.png. Sale con 1 si algo falla.
"""
import json, math, os, sys
import numpy as np
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from sx import parse, kids, kid, prop

RAIZ = os.path.normpath(os.path.join(AQUI, '..'))
P = lambda n: os.path.join(RAIZ, n)
LOG, FALLOS, AVISOS = [], [], []


def ok(c, msg):
    LOG.append(('  OK    ' if c else '  FALLA ') + msg)
    if not c:
        FALLOS.append(msg)


def aviso(msg):
    LOG.append('  AVISO ' + msg)
    AVISOS.append(msg)


def titulo(t):
    LOG.append('\n== ' + t)


def k(x, y):
    return (round(float(x), 2), round(float(y), 2))


# ------------------------------------------------------------------ 1. lectura
titulo('1. Lectura de archivos')
sch = parse(open(P('puente_pico.kicad_sch'), encoding='utf-8').read())
pcb = parse(open(P('puente_pico.kicad_pcb'), encoding='utf-8').read())
lib = parse(open(P('puente_pico.kicad_sym'), encoding='utf-8').read())
pro = json.load(open(P('puente_pico.kicad_pro'), encoding='utf-8'))
ok(sch[0] == 'kicad_sch' and kid(sch, 'version')[1] == '20231120', 'esquematico: cabecera kicad_sch version 20231120 (KiCad 8)')
ok(pcb[0] == 'kicad_pcb' and kid(pcb, 'version')[1] == '20240108', 'PCB: cabecera kicad_pcb version 20240108 (KiCad 8)')
ok(lib[0] == 'kicad_symbol_lib' and len(kids(lib, 'symbol')) == 2, 'puente_pico.kicad_sym: 2 simbolos propios')
ok(pro['meta']['filename'] == 'puente_pico.kicad_pro', 'proyecto: JSON valido')
try:
    from kiutils.board import Board
    from kiutils.schematic import Schematic
    from kiutils.symbol import SymbolLib
    kb = Board.from_file(P('puente_pico.kicad_pcb'))
    ks = Schematic.from_file(P('puente_pico.kicad_sch'))
    kl = SymbolLib.from_file(P('puente_pico.kicad_sym'))
    ok(True, f'kiutils (segundo analizador) lee todo: {len(kb.footprints)} huellas, {len(kb.nets)} redes, '
             f'{len(kb.traceItems)} pistas/vias, {len(ks.schematicSymbols)} simbolos, {len(kl.symbols)} simbolos de libreria')
except ImportError:
    kb = ks = None
    aviso('kiutils no esta instalado: solo se uso el analizador propio')
uu = []


def junta_uuid(n, fuera_lib=True):
    for c in n:
        if isinstance(c, list):
            if c and c[0] == 'lib_symbols':
                continue
            if c and c[0] == 'uuid':
                uu.append(c[1])
            else:
                junta_uuid(c)


for doc in (sch, pcb):
    uu.clear()
    junta_uuid(doc)
    ok(len(uu) == len(set(uu)), f'{doc[0]}: {len(uu)} uuid, ninguno repetido')

# ------------------------------------------------------------------ 2. red del esquematico por geometria
titulo('2. Lista de redes sacada del esquematico (por geometria)')
libs = {s[1]: s for s in kids(kid(sch, 'lib_symbols'), 'symbol')}


def pines_lib(s):
    out = []
    for sub in kids(s, 'symbol'):
        for p in kids(sub, 'pin'):
            a = kid(p, 'at')
            out.append((str(kid(p, 'number')[1]), str(kid(p, 'name')[1]), p[1], float(a[1]), float(a[2])))
    return out


padre = {}


def find(a):
    while padre.setdefault(a, a) != a:
        padre[a] = padre[padre[a]]
        a = padre[a]
    return a


def une(a, b):
    padre[find(a)] = find(b)


pines = []        # (ref, num, nombre, tipo, punto)
nombres = {}      # punto -> nombre de red
nc = set()
simbolos = {}
for s in kids(sch, 'symbol'):
    lid = str(kid(s, 'lib_id')[1])
    L = libs[lid]
    at = kid(s, 'at')
    sx_, sy_, a = float(at[1]), float(at[2]), math.radians(float(at[3]) if len(at) > 3 else 0)
    mir = kid(s, 'mirror')
    ref = str(prop(s, 'Reference'))
    es_power = kid(L, 'power') is not None
    if not ref.startswith('#'):
        ok(ref not in simbolos, f'{ref}: referencia unica') if ref in simbolos else None
        simbolos[ref] = dict(lib=lid, valor=str(prop(s, 'Value')), fp=str(prop(s, 'Footprint')), uuid=str(kid(s, 'uuid')[1]),
                             dnp=kid(s, 'dnp')[1] == 'yes', pins={})
    for num, nom, tipo, px, py in pines_lib(L):
        if mir:
            px, py = (px, -py) if mir[1] == 'x' else (-px, py)
        xr = px * math.cos(a) - py * math.sin(a)
        yr = px * math.sin(a) + py * math.cos(a)
        pt = k(sx_ + xr, sy_ - yr)
        find(pt)
        if es_power:
            if lid != 'power:PWR_FLAG':
                nombres.setdefault(pt, set()).add(str(prop(s, 'Value')))
            pines.append((ref, num, nom, tipo, pt))
        else:
            pines.append((ref, num, nom, tipo, pt))
            simbolos[ref]['pins'][num] = (nom, tipo, pt)
for g in kids(sch, 'global_label') + kids(sch, 'label'):
    at = kid(g, 'at')
    pt = k(at[1], at[2])
    find(pt)
    nombres.setdefault(pt, set()).add(str(g[1]))
for n in kids(sch, 'no_connect'):
    at = kid(n, 'at')
    nc.add(k(at[1], at[2]))
cables = []
for w in kids(sch, 'wire'):
    xy = kids(kid(w, 'pts'), 'xy')
    a_, b_ = k(xy[0][1], xy[0][2]), k(xy[1][1], xy[1][2])
    une(a_, b_)
    cables.append((a_, b_))
for a_, b_ in cables:                 # puntos que caen a media linea de un cable
    for pt in list(padre):
        if pt in (a_, b_):
            continue
        cruz = (b_[0] - a_[0]) * (pt[1] - a_[1]) - (b_[1] - a_[1]) * (pt[0] - a_[0])
        if abs(cruz) < 1e-6 and min(a_[0], b_[0]) - 1e-6 <= pt[0] <= max(a_[0], b_[0]) + 1e-6 \
                and min(a_[1], b_[1]) - 1e-6 <= pt[1] <= max(a_[1], b_[1]) + 1e-6:
            une(pt, a_)
            aviso(f'el punto {pt} cae a media linea del cable {a_}-{b_} (se cuenta como conectado)')
# unir grupos por nombre (etiquetas globales y simbolos de alimentacion)
por_nombre = {}
for pt, ns in nombres.items():
    for n in ns:
        por_nombre.setdefault(n, []).append(pt)
for n, pts in por_nombre.items():
    for pt in pts[1:]:
        une(pt, pts[0])
grupo_nombre = {}
for pt, ns in nombres.items():
    grupo_nombre.setdefault(find(pt), set()).update(ns)
ok(all(len(v) == 1 for v in grupo_nombre.values()),
   'ningun grupo de cables tiene dos nombres de red (no hay cortos entre redes)'
   + ''.join(f' {sorted(v)}' for v in grupo_nombre.values() if len(v) > 1))
fuera = [pt for pt in padre if abs(pt[0] / 1.27 - round(pt[0] / 1.27)) > 0.01 or abs(pt[1] / 1.27 - round(pt[1] / 1.27)) > 0.01]
ok(not fuera, f'todos los puntos de conexion estan en la rejilla de 1.27 mm ({len(padre)} puntos)')

red_sch = {}      # (ref, num) -> red o None
redes = {}        # red -> lista (ref, num, nombre, tipo)
sueltos = []
for ref, num, nom, tipo, pt in pines:
    g = find(pt)
    n = grupo_nombre.get(g)
    if n is None:
        cuantos = sum(1 for p2 in pines if find(p2[4]) == g)
        if pt in nc and cuantos == 1:
            red_sch[(ref, num)] = None
        else:
            sueltos.append(f'{ref}.{num}')
            red_sch[(ref, num)] = '?'
        continue
    n = sorted(n)[0]
    ok(pt not in nc, f'{ref}.{num}: no tiene marca de no-conectado y red a la vez') if pt in nc else None
    red_sch[(ref, num)] = n
    redes.setdefault(n, []).append((ref, num, nom, tipo))
ok(not sueltos, 'ningun pin queda al aire sin marca de no-conectado' + (': ' + ', '.join(sueltos) if sueltos else ''))
comp = [r for r in simbolos]
LOG.append(f'  ..    {len(comp)} componentes, {len(redes)} redes, {sum(1 for v in red_sch.values() if v is None)} pines marcados no-conectado')

# ------------------------------------------------------------------ 3. ERC
titulo('3. Revision tipo ERC')
for n, ps in sorted(redes.items()):
    reales = [p for p in ps if not p[0].startswith('#')]
    tipos = [p[3] for p in ps]
    if len(reales) < 2:
        ok(False, f'red {n}: solo {len(reales)} pin de componente')
    if 'power_in' in tipos and 'power_out' not in tipos:
        ok(False, f'red {n}: hay entradas de alimentacion y nadie la alimenta (falta PWR_FLAG)')
    sal = [p for p in ps if p[3] in ('power_out', 'output')]
    if len(sal) > 1:
        ok(False, f'red {n}: {len(sal)} salidas juntas: ' + ', '.join(f'{p[0]}.{p[1]}' for p in sal))
    if any(p[3] == 'no_connect' for p in ps):
        ok(False, f'red {n}: tiene un pin de tipo no-conectar')
ok(True, f'{len(redes)} redes revisadas: >= 2 pines, entradas de alimentacion con fuente, sin dos salidas juntas')
dnp = sorted(r for r, s in simbolos.items() if s['dnp'])
LOG.append('  ..    marcados DNP (no montar): ' + ', '.join(dnp))

# ------------------------------------------------------------------ 4. PCB contra esquematico
titulo('4. PCB contra esquematico (pad por pad)')
netname = {n[1]: str(n[2]) for n in kids(pcb, 'net')}
hu = {}
for f in kids(pcb, 'footprint'):
    ref = str(prop(f, 'Reference'))
    at = kid(f, 'at')
    fx, fy, fr = float(at[1]), float(at[2]), float(at[3]) if len(at) > 3 else 0.0
    r = math.radians(fr)
    pads = []
    for p in kids(f, 'pad'):
        pa = kid(p, 'at')
        lx, ly = float(pa[1]), float(pa[2])
        ang = float(pa[3]) if len(pa) > 3 else 0.0
        sz = kid(p, 'size')
        nt = kid(p, 'net')
        capas = [str(c) for c in kid(p, 'layers')[1:]]
        pads.append(dict(num=str(p[1]), tipo=p[2], forma=p[3], x=fx + lx * math.cos(r) + ly * math.sin(r),
                         y=fy - lx * math.sin(r) + ly * math.cos(r), w=float(sz[1]), h=float(sz[2]), ang=ang,
                         red=str(nt[2]) if nt else None, capas=capas))
        if nt:
            ok(netname.get(nt[1]) == str(nt[2]), f'{ref}.{p[1]}: numero y nombre de red coinciden') if netname.get(nt[1]) != str(nt[2]) else None
    cy = []
    for g in f:
        if isinstance(g, list) and g[0] in ('fp_line', 'fp_rect') and kid(g, 'layer') and kid(g, 'layer')[1] == 'F.CrtYd':
            for kk in ('start', 'end'):
                q_ = kid(g, kk)
                lx, ly = float(q_[1]), float(q_[2])
                cy.append((fx + lx * math.cos(r) + ly * math.sin(r), fy - lx * math.sin(r) + ly * math.cos(r)))
        if isinstance(g, list) and g[0] == 'fp_circle' and kid(g, 'layer')[1] == 'F.CrtYd':
            c_, e_ = kid(g, 'center'), kid(g, 'end')
            rad = math.dist((float(c_[1]), float(c_[2])), (float(e_[1]), float(e_[2])))
            cy += [(fx - rad, fy - rad), (fx + rad, fy + rad)]
    hu[ref] = dict(fp=str(f[1]), pads=pads, path=str(kid(f, 'path')[1]) if kid(f, 'path') else '', x=fx, y=fy, rot=fr,
                   cy=(min(p[0] for p in cy), min(p[1] for p in cy), max(p[0] for p in cy), max(p[1] for p in cy)) if cy else None)
ok(set(hu) == set(simbolos), f'mismas referencias en esquematico y PCB ({len(hu)})'
   + ('' if set(hu) == set(simbolos) else f' difieren: {sorted(set(hu) ^ set(simbolos))}'))
mal = []
npads = 0
for ref, s in sorted(simbolos.items()):
    h = hu.get(ref)
    if not h:
        continue
    if h['fp'] != s['fp']:
        mal.append(f'{ref}: huella {h["fp"]} != {s["fp"]}')
    if h['path'] != '/' + s['uuid']:
        mal.append(f'{ref}: el path de la huella no apunta al simbolo')
    nums_pad = {p['num'] for p in h['pads'] if p['num'] != ''}
    if nums_pad != set(s['pins']):
        mal.append(f'{ref}: pines {sorted(set(s["pins"]))} != pads {sorted(nums_pad)}')
    for p in h['pads']:
        if p['num'] == '':
            continue
        npads += 1
        if red_sch.get((ref, p['num']), 'x') != p['red']:
            mal.append(f'{ref}.{p["num"]}: esquematico={red_sch.get((ref, p["num"]))} PCB={p["red"]}')
ok(not mal, f'{npads} pads: red, huella, numeracion y enlace al simbolo iguales en esquematico y PCB' + ''.join('\n          ' + m for m in mal))
usadas = {p['red'] for h in hu.values() for p in h['pads'] if p['red']}
ok(usadas == set(redes) and set(netname.values()) - {''} == set(redes), f'las {len(redes)} redes del esquematico son las mismas declaradas y usadas en la PCB')

# ------------------------------------------------------------------ 5. geometria de la placa
titulo('5. Geometria de la placa')
borde = kid([g for g in kids(pcb, 'gr_rect') if kid(g, 'layer')[1] == 'Edge.Cuts'][0], 'start'), \
    kid([g for g in kids(pcb, 'gr_rect') if kid(g, 'layer')[1] == 'Edge.Cuts'][0], 'end')
bx1, by1, bx2, by2 = float(borde[0][1]), float(borde[0][2]), float(borde[1][1]), float(borde[1][2])
LOG.append(f'  ..    contorno {bx2 - bx1:g} x {by2 - by1:g} mm')
PERMITE_SALIR = {'J1': 'HDMI', 'J5': 'USB-C', 'J4': 'bornera'}
for ref, h in sorted(hu.items()):
    c = h['cy']
    if not c:
        continue
    dentro = c[0] >= bx1 - 0.01 and c[1] >= by1 - 0.01 and c[2] <= bx2 + 0.01 and c[3] <= by2 + 0.01
    if not dentro and ref in PERMITE_SALIR:
        LOG.append(f'  ..    {ref} ({PERMITE_SALIR[ref]}): su zona de cortesia sale del borde a proposito (conector de orilla)')
    else:
        ok(dentro, f'{ref}: zona de cortesia dentro de la placa') if not dentro else None
    for p in h['pads']:
        ok(bx1 + 0.3 <= p['x'] - 0.3 and p['x'] + 0.3 <= bx2 - 0.3 and by1 + 0.3 <= p['y'] - 0.3 and p['y'] + 0.3 <= by2 - 0.3,
           f'{ref}.{p["num"]}: pad dentro de la placa') if not (bx1 + 0.6 <= p['x'] <= bx2 - 0.6 and by1 + 0.6 <= p['y'] <= by2 - 0.6) else None
choques = []
refs = sorted(hu)
for i, a_ in enumerate(refs):
    for b_ in refs[i + 1:]:
        A, B = hu[a_]['cy'], hu[b_]['cy']
        if A and B and A[0] < B[2] - 0.01 and B[0] < A[2] - 0.01 and A[1] < B[3] - 0.01 and B[1] < A[3] - 0.01:
            choques.append(f'{a_}/{b_}')
ok(not choques, 'ninguna zona de cortesia se encima con otra' + (': ' + ', '.join(choques) if choques else ''))

# pistas y vias
segs = []
for s in kids(pcb, 'segment'):
    a_, b_ = kid(s, 'start'), kid(s, 'end')
    segs.append(dict(a=(float(a_[1]), float(a_[2])), b=(float(b_[1]), float(b_[2])), w=float(kid(s, 'width')[1]),
                     capa=str(kid(s, 'layer')[1]), red=str(kid(s, 'net')[2])))
vias = [dict(x=float(kid(v, 'at')[1]), y=float(kid(v, 'at')[2]), d=float(kid(v, 'size')[1]), red=str(kid(v, 'net')[2])) for v in kids(pcb, 'via')]


def muestras(s, paso=0.02):
    n = max(2, int(math.dist(s['a'], s['b']) / paso) + 1)
    t = np.linspace(0, 1, n)[:, None]
    return np.array(s['a']) + t * (np.array(s['b']) - np.array(s['a']))


def dist_pad(pts, p):
    d = pts - np.array([p['x'], p['y']])
    if p['forma'] == 'circle':
        return np.hypot(d[:, 0], d[:, 1]) - p['w'] / 2
    r = math.radians(p['ang'])
    lx = d[:, 0] * math.cos(r) - d[:, 1] * math.sin(r)
    ly = d[:, 0] * math.sin(r) + d[:, 1] * math.cos(r)
    qx, qy = np.abs(lx) - p['w'] / 2, np.abs(ly) - p['h'] / 2
    return np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0)


todos_pads = [(ref, p) for ref, h in hu.items() for p in h['pads']]
minimo = (9e9, '')
MS = [muestras(s) for s in segs]
for i, s in enumerate(segs):
    pts = MS[i]
    for ref, p in todos_pads:
        if p['red'] == s['red'] or not any(c in (s['capa'], '*.Cu') for c in p['capas']):
            continue
        d = float(dist_pad(pts, p).min()) - s['w'] / 2
        if d < minimo[0]:
            minimo = (d, f'pista {s["red"]} / pad {ref}.{p["num"]}')
    for j in range(i + 1, len(segs)):
        t = segs[j]
        if t['red'] == s['red'] or t['capa'] != s['capa']:
            continue
        q_ = MS[j]
        d = float(np.sqrt(((pts[:, None, :] - q_[None, ::3, :]) ** 2).sum(-1)).min()) - s['w'] / 2 - t['w'] / 2
        if d < minimo[0]:
            minimo = (d, f'pista {s["red"]} / pista {t["red"]}')
    for v in vias:
        if v['red'] == s['red']:
            continue
        d = float(np.hypot(pts[:, 0] - v['x'], pts[:, 1] - v['y']).min()) - s['w'] / 2 - v['d'] / 2
        if d < minimo[0]:
            minimo = (d, f'pista {s["red"]} / via {v["red"]}')
    lo = float(min((pts[:, 0] - bx1).min(), (bx2 - pts[:, 0]).min(), (pts[:, 1] - by1).min(), (by2 - pts[:, 1]).min()))
    ok(lo >= 0.5, f'pista {s["red"]} a mas de 0.5 mm del borde') if lo < 0.5 else None
for v in vias:
    pt = np.array([[v['x'], v['y']]])
    for ref, p in todos_pads:
        if p['red'] == v['red']:
            continue
        d = float(dist_pad(pt, p)[0]) - v['d'] / 2
        if d < minimo[0]:
            minimo = (d, f'via {v["red"]} / pad {ref}.{p["num"]}')
SEP = 0.15
ok(minimo[0] >= SEP - 1e-6, f'{len(segs)} tramos de pista y {len(vias)} vias: separacion minima a cobre de otra red = {minimo[0]:.3f} mm '
                            f'({minimo[1]}); regla de la clase TMDS = {SEP} mm')
# cada pista empieza y acaba en un pad/via/pista de su red
cabos = []
for s in segs:
    for e in (s['a'], s['b']):
        toca = any(p['red'] == s['red'] and float(dist_pad(np.array([e]), p)[0]) <= 0 for _, p in todos_pads) \
            or any(v['red'] == s['red'] and math.dist(e, (v['x'], v['y'])) < 0.01 for v in vias) \
            or sum(1 for t in segs if t['red'] == s['red'] and (math.dist(e, t['a']) < 0.001 or math.dist(e, t['b']) < 0.001)) >= 2
        if not toca:
            cabos.append(f'{s["red"]}@{e}')
ok(not cabos, 'ninguna pista queda con un extremo al aire' + (': ' + ', '.join(cabos) if cabos else ''))
# largos de los pares
LOG.append('  ..    largo trazado por linea TMDS (Pico -> R + R -> HDMI) y diferencia dentro del par:')
largo = {}
for s in segs:
    largo[s['red']] = largo.get(s['red'], 0) + math.dist(s['a'], s['b'])
desfase = 0
for par in ('D2', 'D1', 'D0', 'CK'):
    lp = largo['HSTX_' + par + '_P'] + largo['TMDS_' + par + '_P']
    ln = largo['HSTX_' + par + '_N'] + largo['TMDS_' + par + '_N']
    desfase = max(desfase, abs(lp - ln))
    LOG.append(f'          {par}: + {lp:.2f} mm, - {ln:.2f} mm, diferencia {abs(lp - ln):.2f} mm')
ok(desfase < 6.0, f'diferencia maxima dentro de un par = {desfase:.2f} mm (~{desfase * 6.7:.0f} ps; un bit a 252 Mbit/s dura 3970 ps)')
LOG.append('  ..    sin trazar (lo traza el usuario): todas las demas redes; los planos GND estan sin rellenar (tecla B)')

# ------------------------------------------------------------------ 6. NETLIST.txt
with open(P('NETLIST.txt'), 'w', encoding='utf-8') as f:
    f.write('Lista de redes de puente_pico (sacada del esquematico por validar_carrier.py)\n')
    f.write(f'{len(simbolos)} componentes, {len(redes)} redes\n\n== Componentes\n')
    for ref in sorted(simbolos, key=lambda r: (r.rstrip('0123456789'), int(''.join(c for c in r if c.isdigit()) or 0))):
        s = simbolos[ref]
        f.write(f'{ref:5} {s["valor"]:28} {s["fp"]}{"   [DNP: no montar]" if s["dnp"] else ""}\n')
    f.write('\n== Redes (componente.pin(nombre del pin))\n')
    for n in sorted(redes):
        ps = [p for p in redes[n] if not p[0].startswith('#')]
        f.write(f'{n:12} ' + '  '.join(f'{p[0]}.{p[1]}' + (f'({p[2]})' if p[2] not in ('~', p[1]) else '') for p in sorted(ps)) + '\n')
    f.write('\n== Pines marcados no-conectado\n')
    f.write('  '.join(f'{r}.{n}({simbolos[r]["pins"][n][0]})' for (r, n), v in sorted(red_sch.items()) if v is None) + '\n')

# ------------------------------------------------------------------ 7. vistas previas
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle, Circle
    os.makedirs(P('previews'), exist_ok=True)
    fig, ax = plt.subplots(figsize=(16, 14))
    ax.add_patch(Rectangle((bx1, by1), bx2 - bx1, by2 - by1, fill=False, ec='k', lw=2))
    for g in kids(pcb, 'gr_rect'):
        if kid(g, 'layer')[1] == 'Dwgs.User':
            a_, b_ = kid(g, 'start'), kid(g, 'end')
            ax.add_patch(Rectangle((float(a_[1]), float(a_[2])), float(b_[1]) - float(a_[1]), float(b_[2]) - float(a_[2]), fill=False, ec='gray', ls='--'))
    for g in kids(pcb, 'gr_text'):
        a_ = kid(g, 'at')
        ef = kid(g, 'effects')
        j = kid(ef, 'justify')
        ax.text(float(a_[1]), float(a_[2]), str(g[1]), fontsize=5, color='teal', ha=j[1] if j else 'center', va='center')
    for ref, h in hu.items():
        c = h['cy']
        if c:
            ax.add_patch(Rectangle((c[0], c[1]), c[2] - c[0], c[3] - c[1], fill=False, ec='m', lw=0.5))
            ax.text((c[0] + c[2]) / 2, c[1] - 0.3, ref, fontsize=6, ha='center', color='b')
        for p in h['pads']:
            col = 'goldenrod' if p['red'] == 'GND' else ('r' if p['red'] else 'lightgray')
            if p['forma'] == 'circle' or p['tipo'] != 'smd':
                ax.add_patch(Circle((p['x'], p['y']), p['w'] / 2, color=col))
            else:
                w, hh = (p['w'], p['h']) if p['ang'] % 180 == 0 else (p['h'], p['w'])
                ax.add_patch(Rectangle((p['x'] - w / 2, p['y'] - hh / 2), w, hh, color=col))
    for s in segs:
        ax.plot([s['a'][0], s['b'][0]], [s['a'][1], s['b'][1]], color='g', lw=1.2)
    for v in vias:
        ax.add_patch(Circle((v['x'], v['y']), v['d'] / 2, color='k'))
    ax.set_xlim(bx1 - 3, bx2 + 5)
    ax.set_ylim(by2 + 3, by1 - 3)
    ax.set_aspect('equal')
    fig.savefig(P('previews/pcb.png'), dpi=110, bbox_inches='tight')
    ax.set_xlim(bx1 + 38, bx2 + 2)
    ax.set_ylim(by1 + 38, by1 + 13)
    fig.savefig(P('previews/pcb_tmds.png'), dpi=200, bbox_inches='tight')
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(22, 15))
    for a_, b_ in cables:
        ax.plot([a_[0], b_[0]], [a_[1], b_[1]], color='g', lw=1)
    for ref, num, nom, tipo, pt in pines:
        if not ref.startswith('#'):
            ax.plot(*pt, 'r.', ms=3)
            ax.text(pt[0], pt[1], num, fontsize=4, color='gray')
    for s in kids(sch, 'symbol'):
        a_ = kid(s, 'at')
        r_ = str(prop(s, 'Reference'))
        if r_.startswith('#'):
            ax.text(float(a_[1]), float(a_[2]), str(prop(s, 'Value')), fontsize=5, color='purple', ha='center')
        else:
            ax.text(float(a_[1]), float(a_[2]), r_ + '\n' + str(prop(s, 'Value')), fontsize=6, color='b', ha='center')
    for g in kids(sch, 'global_label'):
        a_ = kid(g, 'at')
        d = int(float(a_[3]))
        ax.text(float(a_[1]), float(a_[2]), ' ' + str(g[1]) + ' ', fontsize=5, rotation=90 if d in (90, 270) else 0,
                ha={0: 'left', 180: 'right'}.get(d, 'center'), va={90: 'bottom', 270: 'top'}.get(d, 'center'))
    for n in nc:
        ax.plot(*n, 'kx', ms=4)
    for t in kids(sch, 'text'):
        a_ = kid(t, 'at')
        ax.text(float(a_[1]), float(a_[2]), str(t[1]).replace('\\n', '\n'), fontsize=7, color='teal')
    ax.set_xlim(0, 420)
    ax.set_ylim(297, 0)
    ax.set_aspect('equal')
    fig.savefig(P('previews/esquematico.png'), dpi=90, bbox_inches='tight')
    LOG.append('\n  ..    vistas previas en previews/ (dibujo propio, NO es la vista de KiCad)')
except ImportError:
    aviso('matplotlib no esta instalado: no se dibujaron las vistas previas')

res = f'\nRESULTADO: {sum(1 for l in LOG if l.startswith("  OK"))} comprobaciones OK, {len(FALLOS)} fallas, {len(AVISOS)} avisos'
LOG.append(res)
open(P('validacion.txt'), 'w', encoding='utf-8').write('\n'.join(LOG).lstrip('\n') + '\n')
print('\n'.join(LOG))
sys.exit(1 if FALLOS else 0)
