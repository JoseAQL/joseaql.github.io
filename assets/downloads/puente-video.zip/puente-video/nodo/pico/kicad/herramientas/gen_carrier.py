#!/usr/bin/env python3
"""Genera el proyecto KiCad de la placa base (carrier) del nodo economico Puente Video.

Uso: python3 gen_carrier.py [carpeta_librerias_oficiales_kicad8]
Escribe ../puente_pico.kicad_pro, .kicad_sch, .kicad_pcb, puente_pico.kicad_sym y sym-lib-table.
Todo sale de las tablas de este archivo: si cambias un pin o una posicion, vuelve a
correrlo y luego corre validar_carrier.py.
"""
import json, math, os, sys, uuid
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
from sx import S, parse, q, dump, kids, kid, prop

OFICIAL = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/herramientas/kicad8'
SAL = os.path.normpath(os.path.join(AQUI, '..'))
PROY = 'puente_pico'
NS = uuid.UUID('6f1d2c0a-7b1e-4f0e-9c55-70756e746531')


def U(*k):
    return q(str(uuid.uuid5(NS, '/'.join(str(x) for x in k))))


ROOT = str(uuid.uuid5(NS, 'root'))

# ============================================================ simbolos propios
PICO = {1: 'GP0', 2: 'GP1', 3: 'GND', 4: 'GP2', 5: 'GP3', 6: 'GP4', 7: 'GP5', 8: 'GND', 9: 'GP6', 10: 'GP7',
        11: 'GP8', 12: 'GP9', 13: 'GND', 14: 'GP10', 15: 'GP11', 16: 'GP12', 17: 'GP13', 18: 'GND', 19: 'GP14',
        20: 'GP15', 21: 'GP16', 22: 'GP17', 23: 'GND', 24: 'GP18', 25: 'GP19', 26: 'GP20', 27: 'GP21', 28: 'GND',
        29: 'GP22', 30: 'RUN', 31: 'GP26_ADC0', 32: 'GP27_ADC1', 33: 'AGND', 34: 'GP28_ADC2', 35: 'ADC_VREF',
        36: '3V3', 37: '3V3_EN', 38: 'GND', 39: 'VSYS', 40: 'VBUS'}


def tipo_pico(n):
    if n.startswith('GP'):
        return 'bidirectional'
    return {'GND': 'power_in', 'AGND': 'power_in', 'RUN': 'input', 'ADC_VREF': 'passive', '3V3': 'power_out',
            '3V3_EN': 'input', 'VSYS': 'power_in', 'VBUS': 'power_out'}[n]


# Modulo W5500 de 10 pines (2x5). VERIFICAR contra la serigrafia del modulo.
W5500 = {1: ('3V3', 'power_in'), 3: ('MISO', 'output'), 5: ('MOSI', 'input'), 7: ('SCS', 'input'),
         9: ('SCLK', 'input'), 2: ('5V', 'passive'), 4: ('GND', 'power_in'), 6: ('RST', 'input'),
         8: ('INT', 'output'), 10: ('NC', 'no_connect')}

FNT = '(effects (font (size 1.27 1.27)))'
OCU = '(effects (font (size 1.27 1.27)) (hide yes))'


def sim_texto(nombre, ref, huella, descr, medio, alto_sup, alto_inf, pines):
    """pines: lista (numero, nombre, tipo, x, y, angulo)"""
    t = [f'(symbol "{nombre}" (exclude_from_sim no) (in_bom yes) (on_board yes)',
         f'(property "Reference" "{ref}" (at {-medio} {alto_sup + 1.27} 0) (effects (font (size 1.27 1.27)) (justify left)))',
         f'(property "Value" "{nombre}" (at 0 {alto_sup + 1.27} 0) (effects (font (size 1.27 1.27)) (justify left)))',
         f'(property "Footprint" "{huella}" (at 0 0 0) {OCU})',
         f'(property "Datasheet" "" (at 0 0 0) {OCU})',
         f'(property "Description" "{descr}" (at 0 0 0) {OCU})',
         f'(symbol "{nombre}_0_1" (rectangle (start {-medio} {alto_sup}) (end {medio} {alto_inf}) '
         '(stroke (width 0.254) (type default)) (fill (type background))))',
         f'(symbol "{nombre}_1_1"']
    for n, nom, tp, x, y, a in pines:
        t.append(f'(pin {tp} line (at {x} {y} {a}) (length 2.54) (name "{nom}" {FNT}) (number "{n}" {FNT}))')
    t.append('))')
    return parse('\n'.join(t))


def sim_pico():
    pines = []
    for n in range(1, 21):
        pines.append((n, PICO[n], tipo_pico(PICO[n]), -17.78, 25.4 - (n - 1) * 2.54, 0))
    for n in range(21, 41):
        pines.append((n, PICO[n], tipo_pico(PICO[n]), 17.78, 25.4 - (40 - n) * 2.54, 180))
    return sim_texto('RaspberryPi_Pico2', 'A', 'Module:RaspberryPi_Pico_Common_THT',
                     'Raspberry Pi Pico 2 (RP2350) enchufada en dos tiras hembra de 1x20', 15.24, 27.94, -25.4, pines)


def sim_w5500():
    pines = []
    for i, n in enumerate((1, 3, 5, 7, 9)):
        pines.append((n, W5500[n][0], W5500[n][1], -12.7, 5.08 - i * 2.54, 0))
    for i, n in enumerate((2, 4, 6, 8, 10)):
        pines.append((n, W5500[n][0], W5500[n][1], 12.7, 5.08 - i * 2.54, 180))
    return sim_texto('Modulo_W5500_2x5', 'J', 'Connector_PinSocket_2.54mm:PinSocket_2x05_P2.54mm_Vertical',
                     'Modulo W5500 de 10 pines (2x5, paso 2.54) con RJ45. Pinout: VERIFICAR con la serigrafia',
                     10.16, 7.62, -7.62, pines)


PROPIOS = {'RaspberryPi_Pico2': sim_pico(), 'Modulo_W5500_2x5': sim_w5500()}

# ============================================================ librerias oficiales
_cache = {}


def simbolo(lib_id):
    """definicion (aplanada si usa extends) lista para lib_symbols"""
    lib, n = lib_id.split(':')
    if lib == PROY:
        s = PROPIOS[n]
    else:
        if lib not in _cache:
            _cache[lib] = {s[1]: s for s in kids(parse(open(os.path.join(OFICIAL, lib + '.kicad_sym'), encoding='utf-8').read()), 'symbol')}
        s = _cache[lib][n]
        assert kid(s, 'extends') is None, lib_id + ' usa extends'
    s = parse(dump(s))  # copia
    s[1] = S(lib_id)
    return s


def pines_sim(s):
    out = []
    for sub in kids(s, 'symbol'):
        for p in kids(sub, 'pin'):
            a = kid(p, 'at')
            out.append(dict(num=str(kid(p, 'number')[1]), name=str(kid(p, 'name')[1]), tipo=p[1],
                            x=float(a[1]), y=float(a[2]), ang=float(a[3])))
    return out


def huella(fp_id):
    lib, n = fp_id.split(':')
    return parse(open(os.path.join(OFICIAL, lib + '.pretty', n + '.kicad_mod'), encoding='utf-8').read())


# ============================================================ la placa: medidas (mm, origen = esquina superior izquierda)
ANCHO, ALTO = 80.0, 70.0
OX, OY = 100.0, 60.0            # donde cae esa esquina en la hoja de KiCad
X0, YB = 3.0, 34.28             # pin 1 de la Pico (fila de abajo); USB hacia la izquierda
YT = YB - 17.78                 # fila de arriba (pines 21-40)
YC = (YB + YT) / 2
XH, YH = ANCHO - 3.5, YC + 2.0  # HDMI: su linea "PCB Edge" cae en el borde derecho; pares TMDS centrados con la Pico
XR = 57.0                       # columna de resistencias de 270 ohm
PASO_R = 1.7
J2X, J2Y = 53.5, 47.92          # pin 1 del zocalo del W5500
MOD = (1.0, 39.0, 56.0, 67.0)   # contorno aproximado del modulo W5500 (VERIFICAR)

R0603 = 'Resistor_SMD:R_0603_1608Metric_Pad0.98x0.95mm_HandSolder'
SOD = 'Diode_SMD:D_SOD-123'
PWR = ('GND', '+3V3', '+5V', 'VBUS')

TMDS = ['D2_P', 'D2_N', 'D1_P', 'D1_N', 'D0_P', 'D0_N', 'CK_P', 'CK_N']   # de arriba a abajo en la placa
PIN_PICO = {'D0_P': 16, 'D0_N': 17, 'CK_P': 19, 'CK_N': 20, 'D2_P': 21, 'D2_N': 22, 'D1_P': 24, 'D1_N': 25}
PIN_HDMI = {'D2_P': 1, 'D2_N': 3, 'D1_P': 4, 'D1_N': 6, 'D0_P': 7, 'D0_N': 9, 'CK_P': 10, 'CK_N': 12}

RED_PICO = {1: 'UART_TX', 2: 'UART_RX', 4: 'ID0', 5: 'ID1', 6: 'ID2', 7: 'ID3', 9: 'W5500_INT', 10: 'W5500_RST',
            11: 'W5500_MISO', 12: 'W5500_CS', 14: 'W5500_SCK', 15: 'W5500_MOSI', 26: 'GP20_SDA', 27: 'GP21_SCL',
            29: 'GP22_HPD', 30: 'RUN', 31: None, 32: None, 33: 'GND', 34: None, 35: None, 36: '+3V3', 37: None,
            39: 'VSYS', 40: 'VBUS'}
for _n, _nom in PICO.items():
    if _nom == 'GND':
        RED_PICO[_n] = 'GND'
for _k, _p in PIN_PICO.items():
    RED_PICO[_p] = 'HSTX_' + _k
RED_HDMI = {2: 'GND', 5: 'GND', 8: 'GND', 11: 'GND', 17: 'GND', 'SH': 'GND', 13: None, 14: None,
            15: 'HDMI_SCL', 16: 'HDMI_SDA', 18: 'HDMI_5V', 19: 'HDMI_HPD'}
for _k, _p in PIN_HDMI.items():
    RED_HDMI[_p] = 'TMDS_' + _k

PARTES = []


def parte(ref, sim, valor, fp, sch, pcb, redes, dnp=False, nota=''):
    PARTES.append(dict(ref=ref, sim=sim, valor=valor, fp=fp, sch=sch, pcb=pcb,
                       redes={str(k): v for k, v in redes.items()}, dnp=dnp, nota=nota))


parte('A1', PROY + ':RaspberryPi_Pico2', 'Raspberry Pi Pico 2', 'Module:RaspberryPi_Pico_Common_THT',
      (127.0, 101.6), (X0, YB, 90), RED_PICO)
parte('J1', 'Connector:HDMI_A', 'HDMI tipo A', 'Connector_Video:HDMI_A_Amphenol_10029449-x01xLF_Horizontal',
      (281.94, 111.76), (XH, YH, 90), RED_HDMI)
parte('J2', PROY + ':Modulo_W5500_2x5', 'Modulo W5500 (2x5)', 'Connector_PinSocket_2.54mm:PinSocket_2x05_P2.54mm_Vertical',
      (127.0, 180.34), (J2X, J2Y, 0),
      {1: '+3V3', 3: 'W5500_MISO', 5: 'W5500_MOSI', 7: 'W5500_CS', 9: 'W5500_SCK',
       2: None, 4: 'GND', 6: 'W5500_RST', 8: 'W5500_INT', 10: None})
for i, k in enumerate(TMDS):
    parte(f'R{i + 1}', 'Device:R', '270', R0603, (195.58 + i * 7.62, 50.8), (XR, YC + (i - 3.5) * PASO_R, 0),
          {1: 'HSTX_' + k, 2: 'TMDS_' + k})
parte('R9', 'Device:R', '5.1k', R0603, (259.08, 228.6), (13.5, 9.2, 0), {1: 'CC1', 2: 'GND'})
parte('R10', 'Device:R', '5.1k', R0603, (269.24, 228.6), (18.5, 9.2, 0), {1: 'CC2', 2: 'GND'})
parte('R11', 'Device:R', '1k', R0603, (289.56, 228.6), (61.0, 13.0, 0), {1: '+3V3', 2: 'LED_A'})
parte('R12', 'Device:R', '2.2k', R0603, (312.42, 50.8), (72.0, 39.2, 0), {1: 'HDMI_5V', 2: 'HDMI_SDA'}, dnp=True)
parte('R13', 'Device:R', '2.2k', R0603, (320.04, 50.8), (72.0, 41.2, 0), {1: 'HDMI_5V', 2: 'HDMI_SCL'}, dnp=True)
parte('R14', 'Device:R', '100', R0603, (327.66, 50.8), (39.6, 12.6, 0), {1: 'GP20_SDA', 2: 'HDMI_SDA'}, dnp=True)
parte('R15', 'Device:R', '100', R0603, (335.28, 50.8), (36.0, 12.6, 0), {1: 'GP21_SCL', 2: 'HDMI_SCL'}, dnp=True)
parte('R16', 'Device:R', '10k', R0603, (342.9, 50.8), (32.1, 12.6, 0), {1: 'HDMI_HPD', 2: 'GP22_HPD'})
parte('R17', 'Device:R', '20k', R0603, (350.52, 50.8), (28.5, 12.6, 0), {1: 'GP22_HPD', 2: 'GND'})
parte('D1', 'Device:D_Schottky', 'B5819W', SOD, (289.56, 172.72), (8.5, 11.8, 0), {1: 'VSYS', 2: '+5V'})
parte('D2', 'Device:D_Schottky', 'B5819W', SOD, (289.56, 182.88), (60.0, 39.0, 0), {1: 'HDMI_5V_F', 2: 'VBUS'})
parte('D3', 'Device:D_Schottky', 'B5819W', SOD, (289.56, 193.04), (60.0, 42.0, 0), {1: 'HDMI_5V_F', 2: '+5V'})
parte('F1', 'Device:Polyfuse', '200 mA', 'Fuse:Fuse_1206_3216Metric_Pad1.42x1.75mm_HandSolder',
      (325.12, 182.88), (66.5, 40.5, 0), {1: 'HDMI_5V_F', 2: 'HDMI_5V'})
parte('D4', 'Device:LED', 'LED verde', 'LED_SMD:LED_0805_2012Metric_Pad1.15x1.40mm_HandSolder',
      (309.88, 228.6), (66.0, 13.0, 0), {1: 'GND', 2: 'LED_A'})
parte('C1', 'Device:C', '10uF', 'Capacitor_SMD:C_0805_2012Metric_Pad1.18x1.45mm_HandSolder',
      (340.36, 226.06), (14.0, 12.0, 0), {1: 'VSYS', 2: 'GND'})
parte('C2', 'Device:C', '10uF', 'Capacitor_SMD:C_0805_2012Metric_Pad1.18x1.45mm_HandSolder',
      (353.06, 226.06), (59.8, 48.5, 90), {1: '+3V3', 2: 'GND'})
parte('C3', 'Device:C', '100nF', 'Capacitor_SMD:C_0603_1608Metric_Pad1.08x0.95mm_HandSolder',
      (365.76, 226.06), (59.8, 53.5, 90), {1: '+3V3', 2: 'GND'})
parte('J3', 'Connector_Generic:Conn_01x03', 'UART (GND TX RX)', 'Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical',
      (50.8, 104.14), (62.0, 62.0, 90), {1: 'GND', 2: 'UART_TX', 3: 'UART_RX'})
parte('J4', 'Connector:Screw_Terminal_01x02', '5 V (bornera)',
      'TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal',
      (213.36, 172.72), (33.0, 4.8, 180), {1: '+5V', 2: 'GND'})
parte('J5', 'Connector:USB_C_Receptacle_PowerOnly_6P', 'USB-C 5 V',
      'Connector_USB:USB_C_Receptacle_GCT_USB4125-xx-x_6P_TopMnt_Horizontal',
      (220.98, 218.44), (16.0, 3.4, 180), {'A9': '+5V', 'B9': '+5V', 'A12': 'GND', 'B12': 'GND', 'S1': 'GND', 'A5': 'CC1', 'B5': 'CC2'})
parte('SW1', 'Switch:SW_DIP_x04', 'ID nodo (1 2 4 8)',
      'Button_Switch_THT:SW_DIP_SPSTx04_Slide_9.78x12.34mm_W7.62mm_P2.54mm',
      (45.72, 68.58), (63.0, 47.0, 0), {1: 'ID0', 2: 'ID1', 3: 'ID2', 4: 'ID3', 5: 'GND', 6: 'GND', 7: 'GND', 8: 'GND'})
parte('SW2', 'Switch:SW_Push', 'RESET (RUN)', 'Button_Switch_THT:SW_PUSH_6mm',
      (45.72, 134.62), (42.0, 4.5, 0), {1: 'RUN', 2: 'GND'})
for i, (x, y) in enumerate(((4, 4), (ANCHO - 4, 4), (4, ALTO - 4), (ANCHO - 4, ALTO - 4))):
    parte(f'H{i + 1}', 'Mechanical:MountingHole', 'M3', 'MountingHole:MountingHole_3.2mm_M3',
          (345.44 + i * 10.16, 254.0), (x, y, 0), {})

FLAGS = [('GND', 345.44), ('+5V', 358.14), ('VSYS', 370.84), ('HDMI_5V', 383.54)]
FLAG_Y = 172.72

TEXTOS = [
    (25.4, 22.86, 3.0, 'Puente Video - nodo economico: placa base para Pico 2 + modulo W5500 + HDMI (DVI por HSTX)'),
    (25.4, 27.94, 1.6, 'Generado por herramientas/gen_carrier.py. Ver CARRIER.md. Lo marcado VERIFICAR hay que revisarlo antes de fabricar.'),
    (88.9, 66.04, 2.0, 'A1: Raspberry Pi Pico 2 en zocalo'),
    (25.4, 55.88, 2.0, 'Numero de nodo (cerrado = 1)'),
    (25.4, 93.98, 2.0, 'UART0 115200 (3.3 V)'),
    (25.4, 127.0, 2.0, 'Reset'),
    (88.9, 165.1, 2.0, 'J2: modulo W5500 de 10 pines (VERIFICAR pinout con la serigrafia)\\nEl pin 5V del modulo queda sin conectar: se alimenta por 3V3 de la Pico'),
    (187.96, 17.78, 2.0, 'TMDS: 270 ohm en serie por linea (igual que el Pico DVI Sock)'),
    (304.8, 17.78, 2.0, 'DDC y HPD (opcionales; el firmware no los usa)\\nR12-R15 NO se montan (DNP). VERIFICAR antes de montarlas'),
    (203.2, 157.48, 2.0, 'Alimentacion: USB de la Pico, o 5 V externos por J4 / J5 (nunca J4 y J5 a la vez)'),
    (279.4, 162.56, 1.6, 'D1: 5 V externos -> VSYS.  D2/D3: OR de diodos -> F1 -> +5 V del HDMI'),
    (279.4, 213.36, 2.0, 'LED de encendido y desacoplos'),
    (340.36, 154.94, 1.6, 'PWR_FLAG (solo para el ERC)'),
    (340.36, 246.38, 1.6, 'Barrenos M3'),
]


# ============================================================ esquematico
def rot(x, y, a):
    r = math.radians(a)
    return x * math.cos(r) - y * math.sin(r), x * math.sin(r) + y * math.cos(r)


def r2(v):
    return round(v, 4)


class Sch:
    def __init__(self):
        self.items = []
        self.libs = {}
        self.npwr = 0
        self.n = 0

    def uid(self, *k):
        self.n += 1
        return U('sch', self.n, *k)

    def lib(self, lib_id):
        if lib_id not in self.libs:
            self.libs[lib_id] = simbolo(lib_id)
        return self.libs[lib_id]

    def propiedad(self, k, v, x, y, ang=0, oculto=False, just=None):
        ef = ['effects', ['font', ['size', 1.27, 1.27]]]
        if just:
            ef.append(['justify', just])
        if oculto:
            ef.append(['hide', 'yes'])
        return ['property', q(k), q(v), ['at', r2(x), r2(y), ang], ef]

    def wire(self, x1, y1, x2, y2):
        self.items.append(['wire', ['pts', ['xy', r2(x1), r2(y1)], ['xy', r2(x2), r2(y2)]],
                           ['stroke', ['width', 0], ['type', 'default']], ['uuid', self.uid('w')]])

    def etiqueta(self, red, x, y, d):
        """d = direccion hacia afuera en grados (0 der, 90 arriba, 180 izq, 270 abajo)"""
        just = 'left' if d in (0, 90) else 'right'
        self.items.append(['global_label', q(red), ['shape', 'passive'], ['at', r2(x), r2(y), d],
                           ['effects', ['font', ['size', 1.27, 1.27]], ['justify', just]], ['uuid', self.uid('l')],
                           ['property', q('Intersheetrefs'), q('${INTERSHEET_REFS}'), ['at', 0, 0, 0],
                            ['effects', ['font', ['size', 1.27, 1.27]], ['hide', 'yes']]]])

    def power(self, red, x, y, d):
        lib_id = 'power:' + red
        self.lib(lib_id)
        abajo = red == 'GND'
        # el unico pin esta en (0,0): girar el simbolo no mueve la conexion
        a = {270: 0, 0: 90, 90: 180, 180: 270}[d] if abajo else {90: 0, 180: 90, 270: 180, 0: 270}[d]
        self.npwr += 1
        ref = '#PWR%02d' % self.npwr
        dx, dy = math.cos(math.radians(d)), -math.sin(math.radians(d))
        u = self.uid('p')
        self.items.append(['symbol', ['lib_id', q(lib_id)], ['at', r2(x), r2(y), a], ['unit', 1],
                           ['exclude_from_sim', 'no'], ['in_bom', 'yes'], ['on_board', 'yes'], ['dnp', 'no'], ['uuid', u],
                           self.propiedad('Reference', ref, x, y, oculto=True),
                           self.propiedad('Value', red, x + dx * 5.08, y + dy * 5.08 + (0 if d in (0, 180) else 0)),
                           self.propiedad('Footprint', '', x, y, oculto=True),
                           self.propiedad('Datasheet', '', x, y, oculto=True),
                           self.propiedad('Description', 'Simbolo de alimentacion', x, y, oculto=True),
                           ['pin', q('1'), ['uuid', self.uid('pp')]],
                           ['instances', ['project', q(PROY), ['path', q('/' + ROOT), ['reference', q(ref)], ['unit', 1]]]]])

    def flag(self, red, x, y):
        self.lib('power:PWR_FLAG')
        self.npwr += 1
        ref = '#FLG%02d' % self.npwr
        self.items.append(['symbol', ['lib_id', q('power:PWR_FLAG')], ['at', r2(x), r2(y), 0], ['unit', 1],
                           ['exclude_from_sim', 'no'], ['in_bom', 'yes'], ['on_board', 'yes'], ['dnp', 'no'], ['uuid', self.uid('f')],
                           self.propiedad('Reference', ref, x, y, oculto=True),
                           self.propiedad('Value', 'PWR_FLAG', x, y - 5.08),
                           self.propiedad('Footprint', '', x, y, oculto=True),
                           self.propiedad('Datasheet', '', x, y, oculto=True),
                           self.propiedad('Description', 'Bandera de alimentacion para el ERC', x, y, oculto=True),
                           ['pin', q('1'), ['uuid', self.uid('fp')]],
                           ['instances', ['project', q(PROY), ['path', q('/' + ROOT), ['reference', q(ref)], ['unit', 1]]]]])
        self.wire(x, y, x, y + 5.08)
        self.red(red, x, y + 5.08, 270)

    def red(self, red, x, y, d):
        if red in PWR:
            self.power(red, x, y, d)
        else:
            self.etiqueta(red, x, y, d)

    def componente(self, p):
        s = self.lib(p['sim'])
        x, y = p['sch']
        pins = pines_sim(s)
        nums = {pp['num'] for pp in pins}
        assert nums == set(p['redes']) or not nums, f"{p['ref']}: pines {sorted(nums ^ set(p['redes']))}"
        ys = [y - pp['y'] for pp in pins] or [y]
        xs = [x + pp['x'] for pp in pins] or [x]
        arriba = min(ys) - 5.08
        if len(pins) == 2 and pins[0]['x'] == pins[1]['x']:      # vertical de 2 pines
            pr = self.propiedad('Reference', p['ref'], x + 2.54, y - 1.27, just='left')
            pv = self.propiedad('Value', p['valor'], x + 2.54, y + 1.27, just='left')
        elif len(pins) <= 2:
            pr = self.propiedad('Reference', p['ref'], x, y - 5.08)
            pv = self.propiedad('Value', p['valor'], x, y + (3.81 if pins else 5.08))
        else:
            pr = self.propiedad('Reference', p['ref'], min(xs), arriba - 2.54, just='left')
            pv = self.propiedad('Value', p['valor'], min(xs), arriba, just='left')
        u = U('sym', p['ref'])
        p['uuid'] = u
        inbom = kid(s, 'in_bom')[1]
        inst = ['symbol', ['lib_id', q(p['sim'])], ['at', r2(x), r2(y), 0], ['unit', 1],
                ['exclude_from_sim', kid(s, 'exclude_from_sim')[1]], ['in_bom', inbom], ['on_board', 'yes'],
                ['dnp', 'yes' if p['dnp'] else 'no'], ['uuid', u], pr, pv,
                self.propiedad('Footprint', p['fp'], x, y, oculto=True),
                self.propiedad('Datasheet', '', x, y, oculto=True),
                self.propiedad('Description', str(prop(s, 'Description') or ''), x, y, oculto=True)]
        for n in sorted(nums):
            inst.append(['pin', q(n), ['uuid', U('pin', p['ref'], n)]])
        inst.append(['instances', ['project', q(PROY), ['path', q('/' + ROOT), ['reference', q(p['ref'])], ['unit', 1]]]])
        self.items.append(inst)
        hechos = {}
        for pp in pins:
            px, py = x + pp['x'], y - pp['y']
            red = p['redes'][pp['num']]
            k = (r2(px), r2(py))
            if k in hechos:
                assert hechos[k] == red, f"{p['ref']}: pines apilados con redes distintas"
                continue
            hechos[k] = red
            if red is None:
                self.items.append(['no_connect', ['at', r2(px), r2(py)], ['uuid', self.uid('nc')]])
                continue
            d = int(pp['ang'] + 180) % 360
            L = 2.54
            ex, ey = px + L * math.cos(math.radians(d)), py - L * math.sin(math.radians(d))
            self.wire(px, py, ex, ey)
            self.red(red, ex, ey, d)

    def texto(self, x, y, tam, t):
        self.items.append(['text', S(t), ['exclude_from_sim', 'no'], ['at', x, y, 0],
                           ['effects', ['font', ['size', tam, tam]], ['justify', 'left', 'bottom']], ['uuid', self.uid('t')]])

    def escribir(self, ruta):
        doc = ['kicad_sch', ['version', '20231120'], ['generator', q('eeschema')], ['generator_version', q('8.0')],
               ['uuid', q(ROOT)], ['paper', q('A3')],
               ['title_block', ['title', q('Puente Video - placa base nodo Pico 2')], ['date', q('2026-11-13')],
                ['rev', q('A')], ['comment', 1, q('Pico 2 + modulo W5500 + HDMI (DVI por HSTX). Sin probar: VERIFICAR')]],
               ['lib_symbols'] + [self.libs[k] for k in sorted(self.libs)]] + self.items + \
              [['sheet_instances', ['path', q('/'), ['page', q('1')]]]]
        open(ruta, 'w', encoding='utf-8').write(dump(doc) + '\n')


# ============================================================ PCB
def a_placa(fx, fy, fr, lx, ly):
    """coordenada local de huella -> coordenada de placa (KiCad: angulo positivo = antihorario en pantalla)"""
    r = math.radians(fr)
    return fx + lx * math.cos(r) + ly * math.sin(r), fy - lx * math.sin(r) + ly * math.cos(r)


CAPAS = [(0, 'F.Cu', 'signal'), (31, 'B.Cu', 'signal'), (32, 'B.Adhes', 'user', 'B.Adhesive'), (33, 'F.Adhes', 'user', 'F.Adhesive'),
         (34, 'B.Paste', 'user'), (35, 'F.Paste', 'user'), (36, 'B.SilkS', 'user', 'B.Silkscreen'), (37, 'F.SilkS', 'user', 'F.Silkscreen'),
         (38, 'B.Mask', 'user'), (39, 'F.Mask', 'user'), (40, 'Dwgs.User', 'user', 'User.Drawings'), (41, 'Cmts.User', 'user', 'User.Comments'),
         (42, 'Eco1.User', 'user', 'User.Eco1'), (43, 'Eco2.User', 'user', 'User.Eco2'), (44, 'Edge.Cuts', 'user'), (45, 'Margin', 'user'),
         (46, 'B.CrtYd', 'user', 'B.Courtyard'), (47, 'F.CrtYd', 'user', 'F.Courtyard'), (48, 'B.Fab', 'user'), (49, 'F.Fab', 'user')]

ANCHO_TMDS = 0.2
VIA = (0.6, 0.3)


class Pcb:
    def __init__(self, redes):
        self.redes = {n: i + 1 for i, n in enumerate(sorted(redes))}
        self.fps, self.extra = [], []
        self.pads = {}      # (ref, num) -> lista de (x, y)
        self.n = 0

    def uid(self, *k):
        self.n += 1
        return U('pcb', self.n, *k)

    def net(self, red):
        return ['net', self.redes[red], q(red)]

    def huella(self, p):
        fp = huella(p['fp'])
        fx, fy, fr = p['pcb']
        fx += OX
        fy += OY
        s = simbolo(p['sim'])
        info = {pp['num']: pp for pp in pines_sim(s)}
        out = ['footprint', q(p['fp']), ['layer', q('F.Cu')], ['uuid', U('fp', p['ref'])], ['at', r2(fx), r2(fy)] + ([fr] if fr else [])]
        cnt = [0]

        def reuuid(n):
            for i, c in enumerate(n):
                if isinstance(c, list):
                    if c and c[0] == 'uuid':
                        cnt[0] += 1
                        n[i] = ['uuid', U('fpi', p['ref'], cnt[0])]
                    else:
                        reuuid(c)

        def gira(at):
            a = (float(at[3]) if len(at) > 3 else 0.0) + fr
            a %= 360
            del at[3:]
            if a:
                at.append(r2(a))

        puesto_path = False
        for c in fp[2:]:
            if not isinstance(c, list) or c[0] in ('version', 'generator', 'generator_version', 'layer', 'zone', 'group'):
                continue
            c = parse(dump(c))
            if c[0] == 'property':
                if c[1] == 'Reference':
                    c[2] = q(p['ref'])
                elif c[1] == 'Value':
                    c[2] = q(p['valor'])
                elif c[1] == 'Footprint':
                    c[2] = q(p['fp'])
                gira(kid(c, 'at'))
            elif c[0] == 'fp_text':
                gira(kid(c, 'at'))
            elif c[0] == 'attr':
                if not puesto_path:
                    out += [['path', q('/' + p['uuid'])], ['sheetfile', q(PROY + '.kicad_sch')]]
                    puesto_path = True
                if p['dnp']:
                    c.append('dnp')
            elif c[0] == 'pad':
                at = kid(c, 'at')
                lx, ly = float(at[1]), float(at[2])
                gira(at)
                num = str(c[1])
                self.pads.setdefault((p['ref'], num), []).append(a_placa(fx, fy, fr, lx, ly))
                if num != '':
                    assert num in p['redes'], f"{p['ref']}: pad {num} sin pin en el simbolo"
                    red = p['redes'][num]
                    if red is not None:
                        c.append(self.net(red))
                    c.append(['pinfunction', q(info[num]['name'])])
                    c.append(['pintype', q(info[num]['tipo'])])
            out.append(c)
        assert puesto_path, p['ref']
        reuuid(out[4:])
        self.fps.append(out)

    def pad(self, ref, num, i=0):
        return self.pads[(ref, str(num))][i]

    def pista(self, red, pts, ancho, capa='F.Cu'):
        for a, b in zip(pts, pts[1:]):
            self.extra.append(['segment', ['start', r2(a[0]), r2(a[1])], ['end', r2(b[0]), r2(b[1])], ['width', ancho],
                               ['layer', q(capa)], self.net(red), ['uuid', self.uid('s')]])

    def via(self, red, x, y):
        self.extra.append(['via', ['at', r2(x), r2(y)], ['size', VIA[0]], ['drill', VIA[1]], ['layers', q('F.Cu'), q('B.Cu')],
                           self.net(red), ['uuid', self.uid('v')]])

    def texto(self, t, x, y, capa='F.SilkS', tam=0.8, just=None, ang=0):
        ef = ['effects', ['font', ['size', tam, tam], ['thickness', r2(tam * 0.15)]]]
        if just:
            ef.append(['justify', just])
        self.extra.append(['gr_text', S(t), ['at', r2(x + OX), r2(y + OY)] + ([ang] if ang else []), ['layer', q(capa)],
                           ['uuid', self.uid('t')], ef])

    def rect(self, x1, y1, x2, y2, capa, ancho=0.1):
        self.extra.append(['gr_rect', ['start', r2(x1 + OX), r2(y1 + OY)], ['end', r2(x2 + OX), r2(y2 + OY)],
                           ['stroke', ['width', ancho], ['type', 'default']], ['fill', 'none'], ['layer', q(capa)],
                           ['uuid', self.uid('r')]])

    def zona(self, red, capa):
        m = 0.0
        pts = [(OX + m, OY + m), (OX + ANCHO - m, OY + m), (OX + ANCHO - m, OY + ALTO - m), (OX + m, OY + ALTO - m)]
        self.extra.append(['zone', self.net(red)[0:2], ['net_name', q(red)], ['layer', q(capa)], ['uuid', self.uid('z')],
                           ['name', q('GND_' + capa)], ['hatch', 'edge', 0.5], ['connect_pads', ['clearance', 0.3]],
                           ['min_thickness', 0.25], ['filled_areas_thickness', 'no'],
                           ['fill', ['thermal_gap', 0.4], ['thermal_bridge_width', 0.5]],
                           ['polygon', ['pts'] + [['xy', r2(x), r2(y)] for x, y in pts]]])

    def rutear_tmds(self):
        """8 lineas TMDS en F.Cu: Pico -> R (L con chaflan) y R -> HDMI (recta + tramo de entrada)."""
        largos = {}
        for i, k in enumerate(TMDS):
            px, py = self.pad('A1', PIN_PICO[k])
            r1 = self.pad(f'R{i + 1}', 1)
            r2_ = self.pad(f'R{i + 1}', 2)
            hx, hy = self.pad('J1', PIN_HDMI[k])
            sg = 1 if r1[1] > py else -1
            a = [(px, py), (px, r1[1] - sg * 1.0), (px + 1.0, r1[1]), r1]
            b = [r2_, (hx - 1.9, hy), (hx, hy)]
            self.pista('HSTX_' + k, a, ANCHO_TMDS)
            self.pista('TMDS_' + k, b, ANCHO_TMDS)
            largos[k] = (sum(math.dist(u, v) for u, v in zip(a, a[1:])), sum(math.dist(u, v) for u, v in zip(b, b[1:])))
        for n in (2, 5, 8, 11, 17):      # blindajes y tierra del HDMI: tramo corto bajo el conector y via al plano
            hx, hy = self.pad('J1', n)
            self.pista('GND', [(hx, hy), (hx + 1.7, hy)], 0.25)
            self.via('GND', hx + 1.7, hy)
        return largos

    def escribir(self, ruta):
        doc = ['kicad_pcb', ['version', '20240108'], ['generator', q('pcbnew')], ['generator_version', q('8.0')],
               ['general', ['thickness', 1.6], ['legacy_teardrops', 'no']], ['paper', q('A4')],
               ['title_block', ['title', q('Puente Video - placa base nodo Pico 2')], ['date', q('2026-11-13')], ['rev', q('A')]],
               ['layers'] + [[c[0], q(c[1]), c[2]] + ([q(c[3])] if len(c) > 3 else []) for c in CAPAS],
               ['setup', ['pad_to_mask_clearance', 0], ['allow_soldermask_bridges_in_footprints', 'no']],
               ['net', 0, q('')]] + [['net', i, q(n)] for n, i in sorted(self.redes.items(), key=lambda t: t[1])] + \
              self.fps + self.extra
        open(ruta, 'w', encoding='utf-8').write(dump(doc) + '\n')


# ============================================================ proyecto
def proyecto(ruta):
    def clase(nombre, ancho, sep, dpw=0.2, dpg=0.2):
        return {'bus_width': 12, 'clearance': sep, 'diff_pair_gap': dpg, 'diff_pair_via_gap': 0.25, 'diff_pair_width': dpw,
                'line_style': 0, 'microvia_diameter': 0.3, 'microvia_drill': 0.1, 'name': nombre,
                'pcb_color': 'rgba(0, 0, 0, 0.000)', 'schematic_color': 'rgba(0, 0, 0, 0.000)',
                'track_width': ancho, 'via_diameter': 0.6, 'via_drill': 0.3, 'wire_width': 6}
    pro = {
        'board': {'3dviewports': [], 'design_settings': {
            'defaults': {}, 'diff_pair_dimensions': [{'gap': 0.0, 'via_gap': 0.0, 'width': 0.0}, {'gap': 0.2, 'via_gap': 0.25, 'width': 0.2}],
            'drc_exclusions': [], 'rule_severities': {},
            'rules': {'min_clearance': 0.15, 'min_copper_edge_clearance': 0.3, 'min_hole_clearance': 0.25,
                      'min_hole_to_hole': 0.5, 'min_through_hole_diameter': 0.3, 'min_track_width': 0.15,
                      'min_via_annular_width': 0.13, 'min_via_diameter': 0.6, 'min_text_height': 0.8,
                      'min_text_thickness': 0.08, 'min_silk_clearance': 0.0},
            'track_widths': [0.0, 0.2, 0.25, 0.4, 0.6, 1.0],
            'via_dimensions': [{'diameter': 0.0, 'drill': 0.0}, {'diameter': 0.6, 'drill': 0.3}, {'diameter': 0.8, 'drill': 0.4}],
            'zones_allow_external_fillets': False}, 'layer_presets': [], 'viewports': []},
        'boards': [], 'cvpcb': {'equivalence_files': []},
        'libraries': {'pinned_footprint_libs': [], 'pinned_symbol_libs': []},
        'meta': {'filename': PROY + '.kicad_pro', 'version': 1},
        'net_settings': {
            'classes': [clase('Default', 0.25, 0.2), clase('TMDS', 0.2, 0.15), clase('Potencia', 0.6, 0.2)],
            'meta': {'version': 3}, 'net_colors': None, 'netclass_assignments': None,
            'netclass_patterns': [{'netclass': 'TMDS', 'pattern': 'TMDS_*'}, {'netclass': 'TMDS', 'pattern': 'HSTX_*'}] +
                                 [{'netclass': 'Potencia', 'pattern': n} for n in ('+5V', 'VBUS', 'VSYS', '+3V3', 'HDMI_5V', 'HDMI_5V_F')]},
        'pcbnew': {'last_paths': {}, 'page_layout_descr_file': ''},
        'schematic': {'legacy_lib_dir': '', 'legacy_lib_list': []},
        'sheets': [[ROOT, 'Root']], 'text_variables': {}}
    json.dump(pro, open(ruta, 'w', encoding='utf-8'), indent=2)


def main():
    # --- libreria de simbolos propia (para que "Actualizar simbolos" funcione) y tabla
    lib = ['kicad_symbol_lib', ['version', '20231120'], ['generator', q('gen_carrier')], ['generator_version', q('8.0')]] + \
          [PROPIOS[k] for k in sorted(PROPIOS)]
    open(os.path.join(SAL, PROY + '.kicad_sym'), 'w', encoding='utf-8').write(dump(lib) + '\n')
    open(os.path.join(SAL, 'sym-lib-table'), 'w', encoding='utf-8').write(
        '(sym_lib_table\n  (version 7)\n  (lib (name "puente_pico")(type "KiCad")(uri "${KIPRJMOD}/puente_pico.kicad_sym")'
        '(options "")(descr "Placa base nodo Pico: Pico 2 y modulo W5500"))\n)\n')
    # --- esquematico
    sch = Sch()
    for p in PARTES:
        sch.componente(p)
    for red, x in FLAGS:
        sch.flag(red, x, FLAG_Y)
    for x, y, tam, t in TEXTOS:
        sch.texto(x, y, tam, t)
    sch.escribir(os.path.join(SAL, PROY + '.kicad_sch'))
    # --- PCB
    redes = {r for p in PARTES for r in p['redes'].values() if r}
    pcb = Pcb(redes)
    for p in PARTES:
        pcb.huella(p)
    largos = pcb.rutear_tmds()
    pcb.rect(0, 0, ANCHO, ALTO, 'Edge.Cuts')
    pcb.rect(*MOD, 'Dwgs.User', 0.15)
    pcb.texto('Modulo W5500 (aprox. 55 x 28 mm, RJ45 a la izquierda) - VERIFICAR', 4, 41.5, 'Dwgs.User', 1.0, 'left')
    for i, n in enumerate((1, 3, 5, 7, 9)):
        pcb.texto(W5500[n][0], J2X + 1.5, J2Y + i * 2.54, tam=0.8, just='left')
    for i, n in enumerate((2, 4, 6, 8, 10)):
        pcb.texto(W5500[n][0], J2X - 4.0, J2Y + i * 2.54, tam=0.8, just='right')
    pcb.texto('W5500', J2X - 1.27, J2Y - 2.6, tam=1.0)
    pcb.texto('Puente Video - nodo Pico 2  rev A', 25, 68.3, tam=1.0)
    pcb.texto('ID 1 2 4 8', 66.8, 58.3, tam=0.9)
    pcb.texto('ON = 1', 75.0, 50.8, tam=0.8, ang=90)
    pcb.texto('GND TX RX', 64.5, 65.0, tam=0.9)
    pcb.texto('UART', 64.5, 59.4, tam=0.8)
    pcb.texto('+5V', 33.0, 11.0, tam=0.7)
    pcb.texto('GND', 27.9, 11.0, tam=0.7)
    pcb.texto('5V USB-C', 16.0, 8.4 - 0.2, tam=0.7)
    pcb.texto('RESET', 45.2, 1.9, tam=0.9)
    pcb.texto('HDMI', 66.5, 17.0, tam=1.0)
    pcb.texto('PWR', 66.0, 11.2, tam=0.8)
    pcb.zona('GND', 'F.Cu')
    pcb.zona('GND', 'B.Cu')
    pcb.escribir(os.path.join(SAL, PROY + '.kicad_pcb'))
    proyecto(os.path.join(SAL, PROY + '.kicad_pro'))
    print('partes', len(PARTES), 'redes', len(redes))
    for k, (a, b) in largos.items():
        print(f'  {k}: Pico->R {a:.2f} mm, R->HDMI {b:.2f} mm, total {a + b:.2f} mm')


if __name__ == '__main__':
    main()
