/*
 * placa_pico.h — pines y constantes del nodo económico (Raspberry Pi Pico 2).
 *
 * Ver PICO.md para la tabla de conexiones completa.
 *
 *   GPIO 0/1    UART0 TX/RX (mensajes de depuración a 115200)
 *   GPIO 2..5   número de nodo (DIP a GND, con pull-up interno)
 *   GPIO 6      W5500 INT (se configura como entrada; hoy no se usa)
 *   GPIO 7      W5500 RST
 *   GPIO 8..11  SPI1: MISO(RX), CS, SCK, MOSI(TX) hacia el W5500
 *   GPIO 12..19 HSTX → DVI/HDMI (mismo orden que el "Pico DVI Sock")
 *   GPIO 25     LED de la placa
 */
#ifndef PLACA_PICO_H
#define PLACA_PICO_H

/* ---- pantalla: 640x480 a 60 Hz, 1 byte por pixel (RGB332) */
#define PP_ANCHO 640
#define PP_ALTO  480

/* ---- búferes de JPEG: 2 x 80 KB en SRAM.
 * Un 640x480 de la PC a calidad 75 pesa 30-70 KB (más si es texto fino).
 * Si un cuadro no cabe, el núcleo lo descarta y lo acusa igual (no se traba). */
#define PP_JPEG_CAP (80u * 1024u)

/* ---- W5500 en SPI1 */
#define PP_SPI        spi1
#define PP_SPI_HZ     (25u * 1000u * 1000u) /* 150 MHz / 6; con cables cortos */
#define PP_PIN_MISO   8
#define PP_PIN_CS     9
#define PP_PIN_SCK    10
#define PP_PIN_MOSI   11
#define PP_PIN_RST    7
#define PP_PIN_INT    6

/* ---- número de nodo: GPIO2 = bit 0 ... GPIO5 = bit 3 (switch cerrado = 1) */
#define PP_PIN_ID0     2
#define PP_ID_DEFECTO  1

/* ---- LED */
#define PP_PIN_LED 25

/* ---- red */
#define PP_DHCP_ESPERA_MS 8000u     /* luego usa 192.168.77.(100 + id) */
#define PP_IP_RESPALDO_A  192
#define PP_IP_RESPALDO_B  168
#define PP_IP_RESPALDO_C  77
#define PP_IP_RESPALDO_BASE 100

/* ---- tiempos de pantalla */
#define PP_SIN_VIDEO_MS   3000u     /* sin cuadros este tiempo → pantalla de número */
#define PP_IDENTIFICAR_MS 3000u     /* cuánto se queda el número tras "IDENTIFICAR" */

/* ---- reloj del sistema (kHz). 150 MHz es lo nominal del RP2350.
 * Se puede subir (p. ej. -DPP_RELOJ_KHZ=250000) para decodificar más rápido;
 * el DVI no cambia porque su reloj sale del PLL de USB. NO PROBADO. */
#ifndef PP_RELOJ_KHZ
#define PP_RELOJ_KHZ 150000u
#endif

#endif
