/*
 * dvi_hstx.c — salida DVI/HDMI 640x480 a 60 Hz con el HSTX del RP2350.
 *
 * Adaptado del ejemplo oficial pico-examples/hstx/dvi_out_hstx_encoder
 * (Copyright (c) 2024 Raspberry Pi (Trading) Ltd., licencia BSD-3-Clause).
 * Cambios contra el ejemplo:
 *   - el framebuffer RGB332 está en SRAM (en el ejemplo es una foto en flash)
 *   - canales de DMA pedidos al SDK en vez de fijos en 0 y 1
 *   - el reloj del HSTX lo deja en 126 MHz quien llama (ver main.c), así el
 *     pixel sale a 25.2 MHz exactos (60 Hz). El ejemplo asume 125 MHz, pero
 *     con el SDK 2.x el HSTX arranca a 150 MHz (75 Hz, fuera de norma).
 *   - todo esto corre en el núcleo 1: su interrupción no le quita tiempo al
 *     núcleo 0 (red).
 *
 * Mapeo de pines (igual que el ejemplo y el "Pico DVI Sock"):
 *   GP12 D0+  GP13 D0-   (azul)
 *   GP14 CK+  GP15 CK-
 *   GP16 D2+  GP17 D2-   (rojo)
 *   GP18 D1+  GP19 D1-   (verde)
 */
#include "dvi_hstx.h"

#include "hardware/dma.h"
#include "hardware/gpio.h"
#include "hardware/irq.h"
#include "hardware/structs/bus_ctrl.h"
#include "hardware/structs/hstx_ctrl.h"
#include "hardware/structs/hstx_fifo.h"

/* ---------------------------------------------------------- constantes DVI */

#define TMDS_CTRL_00 0x354u
#define TMDS_CTRL_01 0x0abu
#define TMDS_CTRL_10 0x154u
#define TMDS_CTRL_11 0x2abu

#define SYNC_V0_H0 (TMDS_CTRL_00 | (TMDS_CTRL_00 << 10) | (TMDS_CTRL_00 << 20))
#define SYNC_V0_H1 (TMDS_CTRL_01 | (TMDS_CTRL_00 << 10) | (TMDS_CTRL_00 << 20))
#define SYNC_V1_H0 (TMDS_CTRL_10 | (TMDS_CTRL_00 << 10) | (TMDS_CTRL_00 << 20))
#define SYNC_V1_H1 (TMDS_CTRL_11 | (TMDS_CTRL_00 << 10) | (TMDS_CTRL_00 << 20))

#define MODO_H_FRENTE   16u
#define MODO_H_SYNC     96u
#define MODO_H_ATRAS    48u
#define MODO_H_ACTIVO   640u

#define MODO_V_FRENTE   10u
#define MODO_V_SYNC     2u
#define MODO_V_ATRAS    33u
#define MODO_V_ACTIVO   480u

#define MODO_V_TOTAL (MODO_V_FRENTE + MODO_V_SYNC + MODO_V_ATRAS + MODO_V_ACTIVO)

#define HSTX_CMD_RAW_REPEAT (0x1u << 12)
#define HSTX_CMD_TMDS       (0x2u << 12)
#define HSTX_CMD_NOP        (0xfu << 12)

/* Listas de comandos del HSTX (rellenas con NOP para que el DMA no rebote
 * demasiado rápido entre canales, igual que en el ejemplo). */
static uint32_t linea_vblank_sin_vsync[] = {
    HSTX_CMD_RAW_REPEAT | MODO_H_FRENTE,
    SYNC_V1_H1,
    HSTX_CMD_RAW_REPEAT | MODO_H_SYNC,
    SYNC_V1_H0,
    HSTX_CMD_RAW_REPEAT | (MODO_H_ATRAS + MODO_H_ACTIVO),
    SYNC_V1_H1,
    HSTX_CMD_NOP,
};

static uint32_t linea_vblank_con_vsync[] = {
    HSTX_CMD_RAW_REPEAT | MODO_H_FRENTE,
    SYNC_V0_H1,
    HSTX_CMD_RAW_REPEAT | MODO_H_SYNC,
    SYNC_V0_H0,
    HSTX_CMD_RAW_REPEAT | (MODO_H_ATRAS + MODO_H_ACTIVO),
    SYNC_V0_H1,
    HSTX_CMD_NOP,
};

static uint32_t linea_activa[] = {
    HSTX_CMD_RAW_REPEAT | MODO_H_FRENTE,
    SYNC_V1_H1,
    HSTX_CMD_NOP,
    HSTX_CMD_RAW_REPEAT | MODO_H_SYNC,
    SYNC_V1_H0,
    HSTX_CMD_NOP,
    HSTX_CMD_RAW_REPEAT | MODO_H_ATRAS,
    SYNC_V1_H1,
    HSTX_CMD_TMDS | MODO_H_ACTIVO,
};

#define CUENTA(a) (sizeof(a) / sizeof((a)[0]))

/* ---------------------------------------------------------------- DMA */

static const uint8_t *framebuffer;
static uint dma_ping, dma_pong;
static bool toca_pong = false;
/* Se dejan listos un ping y un pong al arrancar; la primera interrupción es
 * para la tercera línea (índice 2). */
static uint linea_v = 2;
static bool comandos_puestos = false;
static volatile uint32_t cuadros;

static void __scratch_x("dvi") al_terminar_dma(void)
{
    uint canal = toca_pong ? dma_pong : dma_ping;
    dma_channel_hw_t *ch = &dma_hw->ch[canal];
    dma_hw->intr = 1u << canal;
    toca_pong = !toca_pong;

    if (linea_v >= MODO_V_FRENTE && linea_v < MODO_V_FRENTE + MODO_V_SYNC) {
        ch->read_addr = (uintptr_t)linea_vblank_con_vsync;
        ch->transfer_count = CUENTA(linea_vblank_con_vsync);
    } else if (linea_v < MODO_V_FRENTE + MODO_V_SYNC + MODO_V_ATRAS) {
        ch->read_addr = (uintptr_t)linea_vblank_sin_vsync;
        ch->transfer_count = CUENTA(linea_vblank_sin_vsync);
    } else if (!comandos_puestos) {
        ch->read_addr = (uintptr_t)linea_activa;
        ch->transfer_count = CUENTA(linea_activa);
        comandos_puestos = true;
    } else {
        ch->read_addr = (uintptr_t)&framebuffer[(linea_v - (MODO_V_TOTAL - MODO_V_ACTIVO)) * MODO_H_ACTIVO];
        ch->transfer_count = MODO_H_ACTIVO / sizeof(uint32_t);
        comandos_puestos = false;
    }

    if (!comandos_puestos) {
        linea_v++;
        if (linea_v == MODO_V_TOTAL) {
            linea_v = 0;
            cuadros++;
        }
    }
}

uint32_t dvi_cuadros(void)
{
    return cuadros;
}

void dvi_iniciar(const uint8_t *fb)
{
    framebuffer = fb;

    /* Codificador TMDS para RGB332: rojo = bits 7:5, verde = 4:2, azul = 1:0 */
    hstx_ctrl_hw->expand_tmds =
        2u << HSTX_CTRL_EXPAND_TMDS_L2_NBITS_LSB |
        0u << HSTX_CTRL_EXPAND_TMDS_L2_ROT_LSB |
        2u << HSTX_CTRL_EXPAND_TMDS_L1_NBITS_LSB |
        29u << HSTX_CTRL_EXPAND_TMDS_L1_ROT_LSB |
        1u << HSTX_CTRL_EXPAND_TMDS_L0_NBITS_LSB |
        26u << HSTX_CTRL_EXPAND_TMDS_L0_ROT_LSB;

    /* 4 pixeles de 8 bits por palabra; los comandos RAW son palabra completa */
    hstx_ctrl_hw->expand_shift =
        4u << HSTX_CTRL_EXPAND_SHIFT_ENC_N_SHIFTS_LSB |
        8u << HSTX_CTRL_EXPAND_SHIFT_ENC_SHIFT_LSB |
        1u << HSTX_CTRL_EXPAND_SHIFT_RAW_N_SHIFTS_LSB |
        0u << HSTX_CTRL_EXPAND_SHIFT_RAW_SHIFT_LSB;

    /* Reloj de salida = clk_hstx / 5, 2 bits por ciclo: 126 MHz → 252 Mbit/s */
    hstx_ctrl_hw->csr = 0;
    hstx_ctrl_hw->csr =
        HSTX_CTRL_CSR_EXPAND_EN_BITS |
        5u << HSTX_CTRL_CSR_CLKDIV_LSB |
        5u << HSTX_CTRL_CSR_N_SHIFTS_LSB |
        2u << HSTX_CTRL_CSR_SHIFT_LSB |
        HSTX_CTRL_CSR_EN_BITS;

    /* Salidas HSTX 0..7 = GPIO 12..19. Par de reloj en GP14/15. */
    hstx_ctrl_hw->bit[2] = HSTX_CTRL_BIT0_CLK_BITS;
    hstx_ctrl_hw->bit[3] = HSTX_CTRL_BIT0_CLK_BITS | HSTX_CTRL_BIT0_INV_BITS;
    static const int carril_a_bit[3] = {0, 6, 4}; /* D0 → GP12, D1 → GP18, D2 → GP16 */
    for (uint carril = 0; carril < 3; ++carril) {
        int bit = carril_a_bit[carril];
        uint32_t sel = (carril * 10u) << HSTX_CTRL_BIT0_SEL_P_LSB |
                       (carril * 10u + 1u) << HSTX_CTRL_BIT0_SEL_N_LSB;
        hstx_ctrl_hw->bit[bit] = sel;
        hstx_ctrl_hw->bit[bit + 1] = sel | HSTX_CTRL_BIT0_INV_BITS;
    }
    for (uint pin = 12; pin <= 19; ++pin) gpio_set_function(pin, GPIO_FUNC_HSTX);

    /* Dos canales que se encadenan entre sí: mientras uno manda una línea,
     * la interrupción recarga el otro. */
    dma_ping = (uint)dma_claim_unused_channel(true);
    dma_pong = (uint)dma_claim_unused_channel(true);

    dma_channel_config c = dma_channel_get_default_config(dma_ping);
    channel_config_set_chain_to(&c, dma_pong);
    channel_config_set_dreq(&c, DREQ_HSTX);
    dma_channel_configure(dma_ping, &c, &hstx_fifo_hw->fifo, linea_vblank_sin_vsync,
                          CUENTA(linea_vblank_sin_vsync), false);
    c = dma_channel_get_default_config(dma_pong);
    channel_config_set_chain_to(&c, dma_ping);
    channel_config_set_dreq(&c, DREQ_HSTX);
    dma_channel_configure(dma_pong, &c, &hstx_fifo_hw->fifo, linea_vblank_sin_vsync,
                          CUENTA(linea_vblank_sin_vsync), false);

    /* La interrupción se habilita en el núcleo que llama (el 1). */
    dma_hw->ints0 = (1u << dma_ping) | (1u << dma_pong);
    dma_hw->inte0 = (1u << dma_ping) | (1u << dma_pong);
    irq_set_exclusive_handler(DMA_IRQ_0, al_terminar_dma);
    irq_set_enabled(DMA_IRQ_0, true);

    /* El DMA tiene prioridad en el bus para que la imagen no tiemble */
    bus_ctrl_hw->priority = BUSCTRL_BUS_PRIORITY_DMA_W_BITS | BUSCTRL_BUS_PRIORITY_DMA_R_BITS;

    dma_channel_start(dma_ping);
}
