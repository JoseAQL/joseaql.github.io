/*
 * red_w5500.h — red del nodo con un W5500 por SPI (ioLibrary de WIZnet).
 *
 * El W5500 hace TCP/IP por hardware; aquí solo se mueve por SPI lo que
 * llega y lo que sale. Sockets del chip:
 *   0 y 1  TCP servidor en el puerto 5000 (uno escucha mientras el otro está
 *          conectado, así un cliente nuevo puede reemplazar al anterior)
 *   2      UDP para el anuncio (broadcast al 5001)
 *   3      DHCP
 */
#ifndef RED_W5500_H
#define RED_W5500_H

#include <stdint.h>

#define RED_NADA          0
#define RED_CLIENTE_NUEVO 1
#define RED_CLIENTE_SE_FUE 2

/* Reinicia el W5500, pone la MAC (sale del id único del Pico) y arranca DHCP.
 * Regresa 0 si el chip contestó, -1 si no (revisa cables). */
int red_iniciar(int id_nodo);

/* Llamar seguido. Atiende DHCP, la IP de respaldo y las conexiones.
 * Regresa RED_CLIENTE_NUEVO / RED_CLIENTE_SE_FUE cuando pasa algo. */
int red_proceso(uint32_t ahora_ms);

/* IP actual (0.0.0.0 si todavía no hay). Regresa 1 si ya hay IP. */
int red_ip(uint8_t ip[4]);
int red_ip_es_respaldo(void);
int red_hay_enlace(void);

int red_hay_cliente(void);

/* Lee lo que haya llegado del cliente (sin esperar). Regresa bytes leídos. */
uint32_t red_leer(uint8_t *destino, uint32_t cap);

/* Manda todo o nada, sin esperar. 0 = enviado, -1 = ocupado (reintentar). */
int red_escribir(const uint8_t *datos, uint16_t largo);

/* Broadcast UDP a 255.255.255.255:puerto. */
void red_anunciar(const char *texto, uint16_t largo, uint16_t puerto);

#endif
