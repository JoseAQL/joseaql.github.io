/*
 * pantalla_332.c — JPEG (TJpgDec) e identificación sobre un framebuffer RGB332.
 * Ver pantalla_332.h.
 */
#include "pantalla_332.h"

#include "puente_nodo.h"
#include "tjpgd.h"

#include <string.h>

static uint8_t *fb;
static int fb_ancho, fb_alto;

/* Área de trabajo de TJpgDec. La pantalla de identificación se dibuja primero
 * chiquita (1/8) en RGB565 y luego se amplía; como nunca se hacen las dos cosas
 * a la vez, comparten la misma memoria. */
#define TRABAJO_BYTES (10u * 1024u)
#define ID_ESCALA 8
static union {
    uint8_t trabajo[TRABAJO_BYTES];
    uint16_t chico[TRABAJO_BYTES / 2];
} memoria;

/* Lo que va decodificando el JPEG en curso */
typedef struct {
    const uint8_t *datos;
    uint32_t largo;
    uint32_t pos;
    int x0, y0;           /* esquina donde cae la imagen (centrada) */
} entrada_t;

/* Recuerda dónde quedó la imagen anterior: si la nueva es de otro tamaño hay
 * que borrar lo que sobra. */
static int ultimo_x0 = -1, ultimo_y0 = -1, ultimo_w = -1, ultimo_h = -1;

/* Matriz de Bayer 4x4 (0..15) para el tramado ordenado */
static const uint8_t BAYER[16] = {
    0, 8, 2, 10,
    12, 4, 14, 6,
    3, 11, 1, 9,
    15, 7, 13, 5,
};

void p332_iniciar(uint8_t *framebuffer, int ancho, int alto)
{
    fb = framebuffer;
    fb_ancho = ancho;
    fb_alto = alto;
    memset(fb, 0, (size_t)ancho * (size_t)alto);
    ultimo_x0 = ultimo_y0 = ultimo_w = ultimo_h = -1;
}

/* ------------------------------------------------------------------ JPEG */

static size_t leer(JDEC *jd, uint8_t *destino, size_t n)
{
    entrada_t *e = (entrada_t *)jd->device;
    uint32_t resto = e->largo - e->pos;
    if (n > resto) n = resto;
    if (destino != NULL) memcpy(destino, e->datos + e->pos, n);
    e->pos += (uint32_t)n;
    return n;
}

static inline uint8_t a332(uint32_t r, uint32_t g, uint32_t b, uint32_t umbral)
{
    /* umbral 0..15: suma un escalón parcial antes de truncar */
    r = (r + umbral * 2u) >> 5;
    g = (g + umbral * 2u) >> 5;
    b = (b + umbral * 4u) >> 6;
    if (r > 7u) r = 7u;
    if (g > 7u) g = 7u;
    if (b > 3u) b = 3u;
    return (uint8_t)((r << 5) | (g << 2) | b);
}

static int escribir(JDEC *jd, void *bitmap, JRECT *rect)
{
    const entrada_t *e = (const entrada_t *)jd->device;
    const uint8_t *rgb = (const uint8_t *)bitmap;
    int w = rect->right - rect->left + 1;
    int x_ini = e->x0 + rect->left;
    for (int j = rect->top; j <= rect->bottom; j++) {
        int y = e->y0 + j;
        if (y >= 0 && y < fb_alto) {
            uint8_t *fila = fb + (size_t)y * (size_t)fb_ancho;
            const uint8_t *bayer = &BAYER[(y & 3) << 2];
            for (int i = 0; i < w; i++) {
                int x = x_ini + i;
                if (x >= 0 && x < fb_ancho) {
                    const uint8_t *p = rgb + i * 3;
                    fila[x] = a332(p[0], p[1], p[2], bayer[x & 3]);
                }
            }
        }
        rgb += w * 3;
    }
    return 1;
}

static void borrar_alrededor(int x0, int y0, int w, int h)
{
    for (int y = 0; y < fb_alto; y++) {
        uint8_t *fila = fb + (size_t)y * (size_t)fb_ancho;
        if (y < y0 || y >= y0 + h) {
            memset(fila, 0, (size_t)fb_ancho);
        } else {
            if (x0 > 0) memset(fila, 0, (size_t)x0);
            if (x0 + w < fb_ancho) memset(fila + x0 + w, 0, (size_t)(fb_ancho - x0 - w));
        }
    }
}

int p332_jpeg(const uint8_t *jpeg, uint32_t largo)
{
    static JDEC jd;
    entrada_t e = {jpeg, largo, 0, 0, 0};

    if (jd_prepare(&jd, leer, memoria.trabajo, sizeof memoria.trabajo, &e) != JDR_OK) return P332_ERR_JPEG;

    uint8_t escala = 0;
    while (escala < 3 && ((jd.width >> escala) > fb_ancho || (jd.height >> escala) > fb_alto)) escala++;
    int w = jd.width >> escala;
    int h = jd.height >> escala;
    if (w > fb_ancho || h > fb_alto || w == 0 || h == 0) return P332_ERR_TAMANO;

    e.x0 = (fb_ancho - w) / 2;
    e.y0 = (fb_alto - h) / 2;
    if (e.x0 != ultimo_x0 || e.y0 != ultimo_y0 || w != ultimo_w || h != ultimo_h) {
        borrar_alrededor(e.x0, e.y0, w, h);
        ultimo_x0 = e.x0;
        ultimo_y0 = e.y0;
        ultimo_w = w;
        ultimo_h = h;
    }
    return jd_decomp(&jd, escribir, escala) == JDR_OK ? P332_OK : P332_ERR_JPEG;
}

/* ------------------------------------------------------------ identificación */

static inline uint8_t de565(uint16_t c)
{
    return (uint8_t)(((c >> 13) << 5) | (((c >> 8) & 7u) << 2) | ((c >> 3) & 3u));
}

/* Cifras de 3x5 pixeles (bit 14 = arriba a la izquierda); índice 10 = punto */
static const uint16_t CIFRAS[11] = {
    0x7B6F, 0x2C97, 0x73E7, 0x73CF, 0x5BC9, 0x79CF, 0x79EF, 0x7249, 0x7BEF, 0x7BCF, 0x0002,
};

static void rect332(int x, int y, int w, int h, uint8_t color)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > fb_ancho) w = fb_ancho - x;
    if (y + h > fb_alto) h = fb_alto - y;
    if (w <= 0 || h <= 0) return;
    for (int j = y; j < y + h; j++) memset(fb + (size_t)j * (size_t)fb_ancho + x, color, (size_t)w);
}

static void texto_ip(const uint8_t ip[4], int y, int tam, uint8_t color)
{
    char txt[16];
    int n = 0;
    for (int k = 0; k < 4; k++) {
        int v = ip[k];
        if (v >= 100) txt[n++] = (char)('0' + v / 100);
        if (v >= 10) txt[n++] = (char)('0' + (v / 10) % 10);
        txt[n++] = (char)('0' + v % 10);
        if (k < 3) txt[n++] = '.';
    }
    int paso = 4 * tam;
    int x = (fb_ancho - n * paso + tam) / 2;
    for (int i = 0; i < n; i++, x += paso) {
        uint16_t bits = CIFRAS[txt[i] == '.' ? 10 : txt[i] - '0'];
        for (int fila = 0; fila < 5; fila++) {
            for (int col = 0; col < 3; col++) {
                if (bits & (1u << (14 - fila * 3 - col))) rect332(x + col * tam, y + fila * tam, tam, tam, color);
            }
        }
    }
}

void p332_identificacion(int id, int conectado, const uint8_t ip[4])
{
    int cw = fb_ancho / ID_ESCALA;
    int ch = fb_alto / ID_ESCALA;
    if ((size_t)cw * (size_t)ch > sizeof memoria.chico / sizeof memoria.chico[0]) return;

    /* el dibujo de siempre (el mismo del STM32 y del simulador), en chiquito */
    pn_dibujar_identificacion(memoria.chico, cw, ch, id, (uint8_t)conectado);
    for (int y = 0; y < fb_alto; y++) {
        const uint16_t *origen = memoria.chico + (size_t)(y / ID_ESCALA) * (size_t)cw;
        uint8_t *fila = fb + (size_t)y * (size_t)fb_ancho;
        for (int x = 0; x < fb_ancho; x++) fila[x] = de565(origen[x / ID_ESCALA]);
    }
    if (ip != NULL && (ip[0] | ip[1] | ip[2] | ip[3]) != 0) {
        int tam = fb_alto / 120;
        if (tam < 1) tam = 1;
        texto_ip(ip, fb_alto - fb_alto / 8 - 5 * tam, tam, 0xFF);
    }
    /* la siguiente imagen JPEG debe borrar todo lo de alrededor */
    ultimo_x0 = ultimo_y0 = ultimo_w = ultimo_h = -1;
}
