/*
 * red_w5500.c — W5500 por SPI1 con la ioLibrary de WIZnet. Ver red_w5500.h.
 */
#include "red_w5500.h"

#include "placa_pico.h"
#include "puente_nodo.h"

#include "hardware/gpio.h"
#include "hardware/spi.h"
#include "pico/stdlib.h"
#include "pico/unique_id.h"

#include "dhcp.h"
#include "socket.h"
#include "wizchip_conf.h"

#include <stdio.h>
#include <string.h>

#define S_TCP_A   0
#define S_TCP_B   1
#define S_ANUNCIO 2
#define S_DHCP    3

#define PUERTO_LOCAL_ANUNCIO 6001u  /* origen del anuncio (no importa cuál) */
#define DHCP_BUFER 548u              /* RIP_MSG_SIZE de dhcp.c */

static uint8_t dhcp_bufer[DHCP_BUFER];
static int id;
static int dhcp_activo;
static int tiene_ip;
static int respaldo;
static uint32_t t_inicio, t_segundo;
static int activo = -1;       /* socket con cliente, o -1 */
static int anuncio_abierto;

/* ------------------------------------------------------------- SPI */

static void cs_si(void) { gpio_put(PP_PIN_CS, 0); }
static void cs_no(void) { gpio_put(PP_PIN_CS, 1); }

static uint8_t leer_byte(void)
{
    uint8_t b;
    spi_read_blocking(PP_SPI, 0xFF, &b, 1);
    return b;
}

static void escribir_byte(uint8_t b)
{
    spi_write_blocking(PP_SPI, &b, 1);
}

static void leer_rafaga(uint8_t *buf, uint16_t n)
{
    spi_read_blocking(PP_SPI, 0xFF, buf, n);
}

static void escribir_rafaga(uint8_t *buf, uint16_t n)
{
    spi_write_blocking(PP_SPI, buf, n);
}

/* ------------------------------------------------------------- arranque */

static void mac_del_pico(uint8_t mac[6])
{
    pico_unique_board_id_t uid;
    pico_get_unique_board_id(&uid);
    /* FNV-1a de los 8 bytes, para repartir bien los bits en 5 bytes */
    uint32_t h1 = 2166136261u, h2 = 2166136261u ^ 0x5A5A5A5Au;
    for (int i = 0; i < PICO_UNIQUE_BOARD_ID_SIZE_BYTES; i++) {
        h1 = (h1 ^ uid.id[i]) * 16777619u;
        h2 = (h2 ^ uid.id[PICO_UNIQUE_BOARD_ID_SIZE_BYTES - 1 - i]) * 16777619u;
    }
    mac[0] = 0x02;  /* administrada localmente, unicast */
    mac[1] = (uint8_t)(h1 >> 24);
    mac[2] = (uint8_t)(h1 >> 16);
    mac[3] = (uint8_t)(h1 >> 8);
    mac[4] = (uint8_t)h1;
    mac[5] = (uint8_t)(h2 >> 24);
}

int red_iniciar(int id_nodo)
{
    id = id_nodo;

    spi_init(PP_SPI, PP_SPI_HZ);
    spi_set_format(PP_SPI, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);
    gpio_set_function(PP_PIN_MISO, GPIO_FUNC_SPI);
    gpio_set_function(PP_PIN_SCK, GPIO_FUNC_SPI);
    gpio_set_function(PP_PIN_MOSI, GPIO_FUNC_SPI);
    gpio_init(PP_PIN_CS);
    gpio_set_dir(PP_PIN_CS, GPIO_OUT);
    gpio_put(PP_PIN_CS, 1);
    gpio_init(PP_PIN_INT);
    gpio_set_dir(PP_PIN_INT, GPIO_IN);
    gpio_pull_up(PP_PIN_INT);

    /* reinicio por hardware: >= 500 us en bajo, luego esperar el PLL */
    gpio_init(PP_PIN_RST);
    gpio_set_dir(PP_PIN_RST, GPIO_OUT);
    gpio_put(PP_PIN_RST, 0);
    sleep_ms(2);
    gpio_put(PP_PIN_RST, 1);
    sleep_ms(60);

    reg_wizchip_cs_cbfunc(cs_si, cs_no);
    reg_wizchip_spi_cbfunc(leer_byte, escribir_byte);
    reg_wizchip_spiburst_cbfunc(leer_rafaga, escribir_rafaga);

    uint8_t version = getVERSIONR();
    printf("[red] SPI a %u Hz, W5500 versión 0x%02x\n", (unsigned)spi_get_baudrate(PP_SPI), version);
    if (version != 0x04) return -1;

    /* memoria del chip (KB por socket, suman 16 cada una) */
    uint8_t tx[8] = {2, 2, 2, 2, 2, 2, 2, 2};
    uint8_t rx[8] = {8, 4, 1, 2, 1, 0, 0, 0};
    if (wizchip_init(tx, rx) != 0) return -1;

    wiz_NetInfo info;
    memset(&info, 0, sizeof info);
    mac_del_pico(info.mac);
    info.dhcp = NETINFO_DHCP;
    wizchip_setnetinfo(&info);
    printf("[red] MAC %02x:%02x:%02x:%02x:%02x:%02x\n", info.mac[0], info.mac[1], info.mac[2],
           info.mac[3], info.mac[4], info.mac[5]);

    DHCP_init(S_DHCP, dhcp_bufer);
    dhcp_activo = 1;
    t_inicio = t_segundo = to_ms_since_boot(get_absolute_time());
    return 0;
}

/* ------------------------------------------------------------- IP */

static void poner_respaldo(void)
{
    wiz_NetInfo info;
    wizchip_getnetinfo(&info);
    const uint8_t ip[4] = {PP_IP_RESPALDO_A, PP_IP_RESPALDO_B, PP_IP_RESPALDO_C,
                           (uint8_t)(PP_IP_RESPALDO_BASE + id)};
    const uint8_t mascara[4] = {255, 255, 255, 0};
    memcpy(info.ip, ip, 4);
    memcpy(info.sn, mascara, 4);
    memset(info.gw, 0, 4);
    memset(info.dns, 0, 4);
    info.dhcp = NETINFO_STATIC;
    wizchip_setnetinfo(&info);
    respaldo = 1;
    tiene_ip = 1;
    printf("[red] nadie dio IP por DHCP: uso %u.%u.%u.%u\n", ip[0], ip[1], ip[2], ip[3]);
}

static void revisar_ip(uint32_t ahora)
{
    if (ahora - t_segundo >= 1000u) {
        t_segundo += 1000u;
        DHCP_time_handler();
    }
    if (!dhcp_activo) return;

    uint8_t r = DHCP_run();
    if (r == DHCP_IP_ASSIGN || r == DHCP_IP_CHANGED || r == DHCP_IP_LEASED) {
        if (!tiene_ip || r == DHCP_IP_CHANGED) {
            uint8_t ip[4];
            getSIPR(ip);
            printf("[red] IP por DHCP: %u.%u.%u.%u\n", ip[0], ip[1], ip[2], ip[3]);
        }
        tiene_ip = 1;
    } else if (!tiene_ip && ahora - t_inicio >= PP_DHCP_ESPERA_MS) {
        DHCP_stop();
        dhcp_activo = 0;
        poner_respaldo();
    }
}

int red_ip(uint8_t ip[4])
{
    if (!tiene_ip) {
        memset(ip, 0, 4);
        return 0;
    }
    getSIPR(ip);
    return 1;
}

int red_ip_es_respaldo(void)
{
    return respaldo;
}

int red_hay_enlace(void)
{
    return wizphy_getphylink() == PHY_LINK_ON;
}

/* ------------------------------------------------------------- TCP */

static int escuchando(int sn)
{
    uint8_t st = getSn_SR((uint8_t)sn);
    return st == SOCK_LISTEN || st == SOCK_INIT || st == SOCK_SYNRECV;
}

static void abrir_escucha(int sn)
{
    if (socket((uint8_t)sn, Sn_MR_TCP, PN_PUERTO_TCP, SF_TCP_NODELAY | SF_IO_NONBLOCK) != sn) return;
    setSn_KPALVTR((uint8_t)sn, 2);  /* keep-alive cada 10 s: detecta un cliente que se fue sin avisar */
    listen((uint8_t)sn);
}

static int revisar_tcp(void)
{
    int evento = RED_NADA;
    for (int sn = S_TCP_A; sn <= S_TCP_B; sn++) {
        int otro = sn == S_TCP_A ? S_TCP_B : S_TCP_A;
        switch (getSn_SR((uint8_t)sn)) {
        case SOCK_ESTABLISHED:
            if (sn != activo) {
                /* el nuevo reemplaza al anterior */
                if (activo >= 0) disconnect((uint8_t)activo);
                activo = sn;
                setSn_IR((uint8_t)sn, Sn_IR_CON);
                evento = RED_CLIENTE_NUEVO;
            }
            break;
        case SOCK_CLOSE_WAIT:
            if (sn == activo) {
                activo = -1;
                if (evento == RED_NADA) evento = RED_CLIENTE_SE_FUE;
            }
            disconnect((uint8_t)sn);
            break;
        case SOCK_CLOSED:
            if (sn == activo) {
                activo = -1;
                if (evento == RED_NADA) evento = RED_CLIENTE_SE_FUE;
            }
            if (!escuchando(otro)) abrir_escucha(sn);
            break;
        case SOCK_INIT:
            listen((uint8_t)sn);
            break;
        default:
            break;
        }
    }
    return evento;
}

int red_hay_cliente(void)
{
    return activo >= 0;
}

uint32_t red_leer(uint8_t *destino, uint32_t cap)
{
    if (activo < 0) return 0;
    uint16_t hay = getSn_RX_RSR((uint8_t)activo);
    if (hay == 0) return 0;
    uint16_t n = (uint16_t)(hay < cap ? hay : cap);
    int32_t r = recv((uint8_t)activo, destino, n);
    return r > 0 ? (uint32_t)r : 0u;
}

int red_escribir(const uint8_t *datos, uint16_t largo)
{
    if (activo < 0) return -1;
    int32_t r = send((uint8_t)activo, (uint8_t *)datos, largo);
    return r == (int32_t)largo ? 0 : -1;
}

/* ------------------------------------------------------------- UDP */

void red_anunciar(const char *texto, uint16_t largo, uint16_t puerto)
{
    if (!tiene_ip) return;
    if (!anuncio_abierto || getSn_SR(S_ANUNCIO) != SOCK_UDP) {
        /* SF_BROAD_BLOCK: no recibir los anuncios de los demás nodos */
        anuncio_abierto = socket(S_ANUNCIO, Sn_MR_UDP, PUERTO_LOCAL_ANUNCIO, SF_IO_NONBLOCK | SF_BROAD_BLOCK) == S_ANUNCIO;
        if (!anuncio_abierto) return;
    }
    uint8_t todos[4] = {255, 255, 255, 255};
    sendto_W5x00(S_ANUNCIO, (uint8_t *)texto, largo, todos, puerto);
}

/* ------------------------------------------------------------- todo junto */

int red_proceso(uint32_t ahora_ms)
{
    revisar_ip(ahora_ms);
    if (!tiene_ip) return RED_NADA;
    return revisar_tcp();
}
