/*
 * dvi_hstx.h — salida DVI/HDMI 640x480 a 60 Hz por el HSTX (GPIO 12..19).
 */
#ifndef DVI_HSTX_H
#define DVI_HSTX_H

#include <stdint.h>

/* Arranca la salida mostrando fb (640x480 bytes RGB332, en SRAM).
 * Llamarla desde el núcleo que atenderá la interrupción (el 1).
 * clk_hstx ya debe estar en 126 MHz. */
void dvi_iniciar(const uint8_t *fb);

/* Cuadros de video enviados desde el arranque (sirve para ver que vive). */
uint32_t dvi_cuadros(void);

#endif
