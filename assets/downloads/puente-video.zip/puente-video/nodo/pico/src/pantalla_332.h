/*
 * pantalla_332.h — dibujo en un framebuffer de 8 bits por pixel (RGB332).
 *
 * Es C portable (no usa nada del Pico) para poder probarlo en la PC con
 * prueba_pc/. En el Pico solo lo llama el núcleo 1.
 *
 * Formato de cada byte: RRRGGGBB (rojo en los bits altos), que es lo que
 * espera el codificador TMDS del HSTX tal como lo configura dvi_hstx.c.
 */
#ifndef PANTALLA_332_H
#define PANTALLA_332_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Resultados de p332_jpeg */
#define P332_OK          0
#define P332_ERR_JPEG   -1   /* no es JPEG baseline o viene dañado */
#define P332_ERR_TAMANO -2   /* ni a 1/8 cabe en la pantalla */

/* fb debe tener ancho*alto bytes. */
void p332_iniciar(uint8_t *fb, int ancho, int alto);

/* Decodifica un JPEG baseline directo al framebuffer, con tramado ordenado
 * (dithering) para que el RGB332 no se vea en escalones. Si es más chico que
 * la pantalla lo centra; si es más grande lo reduce a 1/2, 1/4 o 1/8. */
int p332_jpeg(const uint8_t *jpeg, uint32_t largo);

/* Pantalla de identificación: la de pn_dibujar_identificacion (número en
 * grande, marco cian si hay conexión, ámbar si no) y debajo la IP.
 * ip puede ser NULL o 0.0.0.0 si todavía no hay. */
void p332_identificacion(int id, int conectado, const uint8_t ip[4]);

#ifdef __cplusplus
}
#endif
#endif
