/*
 * main.c — nodo económico de Puente Video: Raspberry Pi Pico 2 (RP2350).
 *
 * Ethernet (W5500) → JPEG por software (TJpgDec) → DVI/HDMI 640x480 (HSTX).
 *
 * Reparto del trabajo:
 *   núcleo 0  red (W5500 por SPI), protocolo (puente_nodo.c, el mismo del
 *             STM32 y del simulador), acuses, anuncio UDP, LED
 *   núcleo 1  interrupción del DVI + decodificar JPEG + dibujar el número
 * Mientras el núcleo 1 decodifica un cuadro, el núcleo 0 ya está recibiendo
 * el siguiente en el otro búfer (por eso el protocolo usa 2).
 *
 * Memoria (SRAM de 520 KB):
 *   framebuffer 640x480 RGB332     300 KB
 *   2 búferes de JPEG de 80 KB     160 KB
 *   TJpgDec, pilas, SDK, red       ~25 KB
 */
#include "dvi_hstx.h"
#include "pantalla_332.h"
#include "placa_pico.h"
#include "puente_nodo.h"
#include "red_w5500.h"

#include "hardware/clocks.h"
#include "hardware/gpio.h"
#include "hardware/pll.h"
#include "hardware/vreg.h"
#include "pico/binary_info.h"
#include "pico/multicore.h"
#include "pico/stdlib.h"

#include <stdio.h>
#include <string.h>

/* Datos que muestra "picotool info -a" sobre el .uf2 */
bi_decl(bi_program_description("Puente Video: nodo Ethernet (W5500) a HDMI 640x480 (HSTX)"));
bi_decl(bi_3pins_with_func(PP_PIN_MISO, PP_PIN_MOSI, PP_PIN_SCK, GPIO_FUNC_SPI));
bi_decl(bi_1pin_with_name(PP_PIN_CS, "W5500 CS"));
bi_decl(bi_1pin_with_name(PP_PIN_RST, "W5500 RST"));
bi_decl(bi_1pin_with_name(PP_PIN_INT, "W5500 INT"));
bi_decl(bi_pin_mask_with_names(0xFu << PP_PIN_ID0, "ID bit0|ID bit1|ID bit2|ID bit3"));
bi_decl(bi_pin_mask_with_names(0xFFu << 12, "DVI D0+|DVI D0-|DVI CK+|DVI CK-|DVI D2+|DVI D2-|DVI D1+|DVI D1-"));
bi_decl(bi_1pin_with_name(PP_PIN_LED, "LED"));

static uint8_t framebuffer[PP_ANCHO * PP_ALTO] __attribute__((aligned(4)));
static uint8_t jpeg0[PP_JPEG_CAP] __attribute__((aligned(4)));
static uint8_t jpeg1[PP_JPEG_CAP] __attribute__((aligned(4)));
static pn_nodo_t nodo;
static int id_nodo;

/* ------------------------------------------------- órdenes al núcleo 1
 * El núcleo 0 llena "orden" y empuja el tipo por la FIFO entre núcleos; el
 * núcleo 1 contesta con el resultado por la otra FIFO. Solo hay una orden a
 * la vez, así nunca se pisan. */
#define ORDEN_JPEG 1u
#define ORDEN_ID   2u

static struct {
    const uint8_t *datos;
    uint32_t largo;
    int id;
    int conectado;
    uint8_t ip[4];
    volatile uint32_t us_ultimo_jpeg;
} orden;

static void nucleo1(void)
{
    dvi_iniciar(framebuffer);
    for (;;) {
        uint32_t tipo = multicore_fifo_pop_blocking();
        int32_t r = 0;
        if (tipo == ORDEN_JPEG) {
            uint64_t t0 = time_us_64();
            r = p332_jpeg(orden.datos, orden.largo);
            orden.us_ultimo_jpeg = (uint32_t)(time_us_64() - t0);
        } else if (tipo == ORDEN_ID) {
            p332_identificacion(orden.id, orden.conectado, orden.ip);
        }
        multicore_fifo_push_blocking((uint32_t)r);
    }
}

static int ocupado;              /* el núcleo 1 trae una orden */
static pn_cuadro_t *en_curso;    /* cuadro que está decodificando */
static uint32_t mostrados, errores_jpeg;

static void mandar_orden(uint32_t tipo)
{
    ocupado = 1;
    multicore_fifo_push_blocking(tipo);
}

/* Regresa 1 si el núcleo 1 terminó (y deja r con su resultado). */
static int revisar_nucleo1(int32_t *r)
{
    if (!ocupado || !multicore_fifo_rvalid()) return 0;
    *r = (int32_t)multicore_fifo_pop_blocking();
    ocupado = 0;
    return 1;
}

/* Antes de pn_reiniciar: que nadie esté leyendo un búfer que se va a reusar. */
static void esperar_nucleo1(void)
{
    if (ocupado) {
        (void)multicore_fifo_pop_blocking();
        ocupado = 0;
    }
    en_curso = NULL;
}

/* ------------------------------------------------- arranque */

static void configurar_relojes(void)
{
#if PP_RELOJ_KHZ != 150000u
    /* subir el reloj pide un poco más de voltaje (NO PROBADO) */
    if (PP_RELOJ_KHZ > 200000u) {
        vreg_set_voltage(VREG_VOLTAGE_1_20);
        sleep_ms(2);
    }
    set_sys_clock_khz(PP_RELOJ_KHZ, true);
#endif
    /* El USB no se usa: su PLL se pone en 126 MHz para el HSTX
     * (12 MHz x 126 = 1512 MHz / 6 / 2). 126 / 5 = 25.2 MHz de pixel. */
    clock_stop(clk_usb);
    clock_stop(clk_adc);
    pll_init(pll_usb, 1, 1512u * MHZ, 6, 2);
    clock_configure(clk_hstx, 0, CLOCKS_CLK_HSTX_CTRL_AUXSRC_VALUE_CLKSRC_PLL_USB, 126u * MHZ, 126u * MHZ);
}

static int leer_id(void)
{
    int id = 0;
    for (int b = 0; b < 4; b++) {
        uint pin = (uint)(PP_PIN_ID0 + b);
        gpio_init(pin);
        gpio_set_dir(pin, GPIO_IN);
        gpio_pull_up(pin);
    }
    sleep_us(200);
    for (int b = 0; b < 4; b++) {
        if (!gpio_get((uint)(PP_PIN_ID0 + b))) id |= 1 << b; /* switch cerrado a GND = 1 */
    }
    return id ? id : PP_ID_DEFECTO;
}

static uint32_t ahora_ms(void)
{
    return to_ms_since_boot(get_absolute_time());
}

/* ------------------------------------------------- envío */

static int mandar_mensaje(uint8_t tipo, const void *datos, uint16_t largo)
{
    uint8_t buf[PN_CABECERA + 64];
    if (largo > sizeof buf - PN_CABECERA) return 0;  /* no pasa: textos cortos */
    pn_armar_cabecera(buf, tipo, largo);
    if (largo) memcpy(buf + PN_CABECERA, datos, largo);
    return red_escribir(buf, (uint16_t)(PN_CABECERA + largo)) == 0;
}

static uint32_t mandar_acuses(uint32_t cuantos)
{
    uint8_t buf[PN_CABECERA * 8];
    uint32_t n = cuantos < 8u ? cuantos : 8u;
    for (uint32_t i = 0; i < n; i++) pn_armar_cabecera(buf + i * PN_CABECERA, PN_TIPO_ACUSE, 0);
    return red_escribir(buf, (uint16_t)(n * PN_CABECERA)) == 0 ? n : 0u;
}

/* ------------------------------------------------- principal */

int main(void)
{
    configurar_relojes();
    stdio_init_all();   /* UART0 en GPIO0/1 a 115200 */

    gpio_init(PP_PIN_LED);
    gpio_set_dir(PP_PIN_LED, GPIO_OUT);

    id_nodo = leer_id();
    printf("\n[nodo %d] Puente Video, nodo económico Pico 2 (%dx%d RGB332)\n", id_nodo, PP_ANCHO, PP_ALTO);
    printf("[nodo %d] reloj %lu kHz, HSTX %lu kHz\n", id_nodo, (unsigned long)(clock_get_hz(clk_sys) / 1000u),
           (unsigned long)(clock_get_hz(clk_hstx) / 1000u));

    /* primera pantalla antes de arrancar el núcleo 1 (todavía es solo nuestra) */
    p332_iniciar(framebuffer, PP_ANCHO, PP_ALTO);
    p332_identificacion(id_nodo, 0, NULL);
    multicore_launch_core1(nucleo1);

    pn_iniciar(&nodo, jpeg0, jpeg1, PP_JPEG_CAP);
    int red_ok = red_iniciar(id_nodo) == 0;
    if (!red_ok) printf("[nodo %d] el W5500 no contesta: revisa SPI, RST y 3.3 V\n", id_nodo);

    static uint8_t bloque[2048];
    uint32_t t_anuncio = 0, t_led = 0, t_reporte = ahora_ms(), t_reintento = ahora_ms();
    uint32_t t_ultimo_cuadro = ahora_ms(), t_id_hasta = 0;
    uint32_t acuses_sin_salir = 0, mostrados_antes = 0;
    int hola_pendiente = 0, quiere_id = 0, mostrando_id = 1, id_conectado = 0;
    uint8_t id_ip[4] = {0, 0, 0, 0};

    for (;;) {
        uint32_t ahora = ahora_ms();
        int32_t r;

        /* 0. sin W5500 no hay nada que hacer: reintentar cada 3 s */
        if (!red_ok) {
            if (ahora - t_reintento >= 3000u) {
                t_reintento = ahora;
                red_ok = red_iniciar(id_nodo) == 0;
            }
            if (ahora - t_led >= 60u) {
                t_led = ahora;
                gpio_xor_mask(1u << PP_PIN_LED);
            }
            continue;
        }

        /* 1. red: conexiones nuevas o que se fueron */
        int ev = red_proceso(ahora);
        if (ev != RED_NADA) {
            esperar_nucleo1();
            pn_reiniciar(&nodo);
            acuses_sin_salir = 0;
            hola_pendiente = ev == RED_CLIENTE_NUEVO;
            printf("[nodo %d] %s\n", id_nodo, ev == RED_CLIENTE_NUEVO ? "alguien se conectó" : "se desconectó");
        }

        /* 2. lo que llegó, al núcleo del protocolo (hasta 16 KB por vuelta) */
        for (int i = 0; i < 8; i++) {
            uint32_t n = red_leer(bloque, sizeof bloque);
            if (n == 0) break;
            pn_alimentar(&nodo, bloque, n);
        }

        /* 3. ¿terminó el núcleo 1? */
        if (revisar_nucleo1(&r) && en_curso != NULL) {
            pn_cuadro_mostrado(&nodo, en_curso);   /* si falló igual se acusa */
            en_curso = NULL;
            if (r == P332_OK) mostrados++; else errores_jpeg++;
        }

        /* 4. ¿hay que mostrar el número? */
        uint8_t ip[4];
        red_ip(ip);
        int conectado = red_hay_cliente();
        if (nodo.identificar) {
            nodo.identificar = 0;
            quiere_id = 1;
            t_id_hasta = ahora + PP_IDENTIFICAR_MS;
        } else if (!mostrando_id && ahora - t_ultimo_cuadro > PP_SIN_VIDEO_MS) {
            quiere_id = 1;
        } else if (mostrando_id && (conectado != id_conectado || memcmp(ip, id_ip, 4) != 0)) {
            quiere_id = 1;  /* cambió el color del marco o ya hay IP */
        }

        /* 5. darle trabajo al núcleo 1 */
        if (!ocupado) {
            pn_cuadro_t *c;
            if (quiere_id) {
                quiere_id = 0;
                mostrando_id = 1;
                id_conectado = conectado;
                memcpy(id_ip, ip, 4);
                orden.id = id_nodo;
                orden.conectado = conectado;
                memcpy(orden.ip, ip, 4);
                mandar_orden(ORDEN_ID);
            } else if ((c = pn_siguiente_cuadro(&nodo)) != NULL) {
                t_ultimo_cuadro = ahora;
                if ((int32_t)(t_id_hasta - ahora) > 0) {
                    pn_cuadro_mostrado(&nodo, c);  /* mientras se ve el número, se acusa sin mostrar */
                } else {
                    mostrando_id = 0;
                    en_curso = c;
                    orden.datos = c->datos;
                    orden.largo = c->largo;
                    mandar_orden(ORDEN_JPEG);
                }
            }
        }

        /* 6. saludo y acuses */
        acuses_sin_salir += pn_tomar_acuses(&nodo);
        if (conectado) {
            if (hola_pendiente) {
                char hola[48];
                int largo = pn_texto_hola(hola, sizeof hola, id_nodo, PP_ANCHO, PP_ALTO);
                if (mandar_mensaje(PN_TIPO_TEXTO, hola, (uint16_t)largo)) hola_pendiente = 0;
            } else if (acuses_sin_salir > 0) {
                acuses_sin_salir -= mandar_acuses(acuses_sin_salir);
            }
        } else {
            acuses_sin_salir = 0;
        }

        /* 7. anuncio cada segundo */
        if (ahora - t_anuncio >= 1000u) {
            t_anuncio = ahora;
            char txt[64];
            int largo = pn_texto_anuncio(txt, sizeof txt, id_nodo, PP_ANCHO, PP_ALTO, PN_PUERTO_TCP);
            red_anunciar(txt, (uint16_t)largo, PN_PUERTO_ANUNCIO);
        }

        /* 8. LED: lento sin cable, medio esperando, rápido con video */
        if (ahora - t_led >= 80u) {
            uint32_t periodo = !red_hay_enlace() ? 1000u : (!conectado ? 500u : (mostrando_id ? 250u : 80u));
            if (ahora - t_led >= periodo) {
                t_led = ahora;
                gpio_xor_mask(1u << PP_PIN_LED);
            }
        }

        /* 9. reporte por la UART cada 5 s */
        if (ahora - t_reporte >= 5000u) {
            uint32_t dt = ahora - t_reporte;
            printf("[nodo %d] %u.%u.%u.%u%s  %lu cuadros/s  decodificar %lu ms  descartados %lu  errores %lu  dvi %lu\n",
                   id_nodo, ip[0], ip[1], ip[2], ip[3], red_ip_es_respaldo() ? " (respaldo)" : "",
                   (unsigned long)((mostrados - mostrados_antes) * 1000u / dt),
                   (unsigned long)(orden.us_ultimo_jpeg / 1000u), (unsigned long)nodo.descartados,
                   (unsigned long)errores_jpeg, (unsigned long)dvi_cuadros());
            mostrados_antes = mostrados;
            t_reporte = ahora;
        }
    }
}
