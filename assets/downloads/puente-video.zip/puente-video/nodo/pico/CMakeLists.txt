# Nodo económico de Puente Video para Raspberry Pi Pico 2 (RP2350).
#
#   cmake -G Ninja -S . -B build \
#         -DPICO_SDK_PATH=/ruta/pico-sdk \
#         -DIOLIBRARY_PATH=/ruta/ioLibrary_Driver \
#         -Dpicotool_DIR=/ruta/picotool-install/picotool   (opcional)
#   ninja -C build            →  build/puente_nodo_pico.uf2
#
# O simplemente: ./ci.sh <carpeta del gcc> <carpeta de herramientas>
cmake_minimum_required(VERSION 3.13)

set(PICO_BOARD pico2 CACHE STRING "Placa")
set(PICO_PLATFORM rp2350 CACHE STRING "Plataforma")

include(pico_sdk_import.cmake)

project(puente_nodo_pico C CXX ASM)
set(CMAKE_C_STANDARD 11)

pico_sdk_init()

if(NOT IOLIBRARY_PATH)
    set(IOLIBRARY_PATH $ENV{IOLIBRARY_PATH})
endif()
if(NOT EXISTS "${IOLIBRARY_PATH}/Ethernet/socket.c")
    message(FATAL_ERROR "Falta la ioLibrary de WIZnet: pasa -DIOLIBRARY_PATH=... "
                        "(git clone https://github.com/Wiznet/ioLibrary_Driver)")
endif()

set(NUCLEO_PUENTE ${CMAKE_CURRENT_LIST_DIR}/../firmware/Core)

# --- nuestro código: con todas las advertencias, y cualquiera es error
set(FUENTES_PROPIAS
    src/main.c
    src/dvi_hstx.c
    src/red_w5500.c
    src/pantalla_332.c
    ${NUCLEO_PUENTE}/Src/puente_nodo.c   # el mismo del STM32 y del simulador
)
set_source_files_properties(${FUENTES_PROPIAS} PROPERTIES
    COMPILE_OPTIONS "-Wall;-Wextra;-Wshadow;-Wundef;-Werror")

# --- código de terceros: sin advertencias (no es nuestro)
set(FUENTES_TERCEROS
    tjpgd/tjpgd.c
    ${IOLIBRARY_PATH}/Ethernet/socket.c
    ${IOLIBRARY_PATH}/Ethernet/wizchip_conf.c
    ${IOLIBRARY_PATH}/Ethernet/W5500/w5500.c
    ${IOLIBRARY_PATH}/Internet/DHCP/dhcp.c
)
set_source_files_properties(${FUENTES_TERCEROS} PROPERTIES COMPILE_OPTIONS "-w")

add_executable(puente_nodo_pico ${FUENTES_PROPIAS} ${FUENTES_TERCEROS})

target_include_directories(puente_nodo_pico PRIVATE
    src
    tjpgd
    ${NUCLEO_PUENTE}/Inc
    ${IOLIBRARY_PATH}/Ethernet
    ${IOLIBRARY_PATH}/Ethernet/W5500
    ${IOLIBRARY_PATH}/Internet/DHCP
)

# Reloj del sistema en kHz (150000 = nominal). Subirlo acelera el JPEG; NO PROBADO.
set(PP_RELOJ_KHZ 150000 CACHE STRING "Reloj del sistema en kHz")

target_compile_definitions(puente_nodo_pico PRIVATE
    PP_RELOJ_KHZ=${PP_RELOJ_KHZ}u
    _WIZCHIP_=W5500
    WIZCHIP_PREFIXED_EXPORTS=1     # socket()/close()/send() → wizchip_*, sin chocar con la libc
    PICO_STDIO_UART=1
    PICO_DEFAULT_UART_BAUD_RATE=115200
)

target_link_libraries(puente_nodo_pico
    pico_stdlib
    pico_multicore
    pico_unique_id
    hardware_dma
    hardware_spi
    hardware_pll
    hardware_clocks
    hardware_vreg
)

# Logs por UART0 (GPIO0/1); sin USB, así no hace falta TinyUSB
pico_enable_stdio_uart(puente_nodo_pico 1)
pico_enable_stdio_usb(puente_nodo_pico 0)

pico_set_program_name(puente_nodo_pico "Puente Video nodo Pico 2")
pico_add_extra_outputs(puente_nodo_pico)   # .uf2, .bin, .hex, .map, .dis
