"""Genera JPEG de prueba como los manda la PC, los pasa por prueba_jpeg y mide
qué tan parecido queda el framebuffer RGB332 a la imagen original (PSNR)."""
import subprocess
import sys

import cv2
import numpy as np

carpeta = sys.argv[1]
prog = f"{carpeta}/prueba_jpeg"


def lienzo(w, h):
    y, x = np.mgrid[0:h, 0:w]
    img = np.zeros((h, w, 3), np.uint8)
    img[..., 0] = (x * 255 // max(w - 1, 1)).astype(np.uint8)
    img[..., 1] = (y * 255 // max(h - 1, 1)).astype(np.uint8)
    img[..., 2] = ((x + y) * 255 // max(w + h - 2, 1)).astype(np.uint8)
    cv2.circle(img, (w // 2, h // 2), min(w, h) // 4, (255, 255, 255), -1)
    cv2.putText(img, "Puente Video", (w // 10, h // 5), cv2.FONT_HERSHEY_SIMPLEX, w / 500, (0, 0, 0), 2)
    return img


malo = False
for w, h, calidad in ((640, 480, 75), (640, 480, 50), (320, 240, 75), (1280, 960, 75), (500, 300, 90)):
    img = lienzo(w, h)
    ok, jpg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, calidad])
    ruta = f"{carpeta}/prueba_{w}x{h}_q{calidad}"
    open(ruta + ".jpg", "wb").write(jpg.tobytes())
    r = subprocess.run([prog, ruta + ".jpg", ruta + ".ppm", f"{carpeta}/identificacion.ppm"],
                       capture_output=True, text=True)
    print(f"{w}x{h} q{calidad}: {r.stdout.strip()}")
    if r.returncode != 0:
        malo = True
        continue
    sale = cv2.imread(ruta + ".ppm")
    # referencia: lo que debería verse (escalado y centrado como hace el nodo)
    esc = 1
    while w // esc > 640 or h // esc > 480:
        esc *= 2
    ref = cv2.resize(cv2.imdecode(jpg, cv2.IMREAD_COLOR), (w // esc, h // esc), interpolation=cv2.INTER_AREA)
    x0, y0 = (640 - w // esc) // 2, (480 - h // esc) // 2
    ref_lienzo = np.zeros((480, 640, 3), np.uint8)
    ref_lienzo[y0:y0 + h // esc, x0:x0 + w // esc] = ref
    # lo comparamos borroso: el tramado mete ruido fino a propósito
    a = cv2.GaussianBlur(sale, (5, 5), 0).astype(float)
    b = cv2.GaussianBlur(ref_lienzo, (5, 5), 0).astype(float)
    mse = ((a - b) ** 2).mean()
    psnr = 10 * np.log10(255 ** 2 / mse) if mse else 99
    print(f"   PSNR (suavizado) contra OpenCV: {psnr:.1f} dB")
    # el RGB332 del HSTX llega a 224 (rojo, verde) y 192 (azul), no a 255: por
    # eso aun bien hecho queda alrededor de 22 dB contra el original
    if psnr < 20:
        malo = True
sys.exit(1 if malo else 0)
