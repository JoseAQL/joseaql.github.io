#!/bin/sh
# Compila la prueba del dibujo (pantalla_332.c + TJpgDec + puente_nodo.c) para
# la PC con advertencias como error y, si hay python3 con OpenCV, genera un
# JPEG de 640x480 como lo manda la PC, lo decodifica y lo compara con OpenCV.
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"
SALIDA="${1:-/tmp/prueba_pico}"
mkdir -p "$SALIDA"
CORE="$AQUI/../../firmware/Core"
cc -O2 -std=c11 -Wall -Wextra -Wshadow -Werror -I"$AQUI/../src" -I"$AQUI/../tjpgd" -I"$CORE/Inc" \
  -c "$AQUI/prueba_jpeg.c" -o "$SALIDA/prueba_jpeg.o"
cc -O2 -std=c11 -Wall -Wextra -Wshadow -Werror -I"$AQUI/../src" -I"$AQUI/../tjpgd" -I"$CORE/Inc" \
  -c "$AQUI/../src/pantalla_332.c" -o "$SALIDA/pantalla_332.o"
cc -O2 -std=c11 -Wall -Wextra -Wshadow -Werror -I"$CORE/Inc" \
  -c "$CORE/Src/puente_nodo.c" -o "$SALIDA/puente_nodo.o"
cc -O2 -w -I"$AQUI/../tjpgd" -c "$AQUI/../tjpgd/tjpgd.c" -o "$SALIDA/tjpgd.o"
cc -o "$SALIDA/prueba_jpeg" "$SALIDA/prueba_jpeg.o" "$SALIDA/pantalla_332.o" "$SALIDA/puente_nodo.o" "$SALIDA/tjpgd.o"
echo "prueba_jpeg compilada en $SALIDA"
if python3 -c "import cv2" 2>/dev/null; then
  python3 -I "$AQUI/comparar.py" "$SALIDA"
else
  echo "(sin python3 + OpenCV: no se corre la comparación)"
fi
