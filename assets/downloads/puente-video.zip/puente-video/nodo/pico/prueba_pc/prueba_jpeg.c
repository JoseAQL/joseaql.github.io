/*
 * prueba_jpeg.c — prueba en la PC del dibujo del nodo Pico (pantalla_332.c).
 *
 * Decodifica un JPEG con el mismo código que corre en el núcleo 1 del Pico y
 * guarda el framebuffer RGB332 como PPM. También guarda la pantalla de
 * identificación. Mide cuánto tarda (en la PC, NO es el tiempo del Pico).
 *
 *   ./prueba_pc.sh             (compila y, si hay python3 con OpenCV, prueba)
 *   ./prueba_jpeg foto.jpg salida.ppm id.ppm
 */
#include "pantalla_332.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ANCHO 640
#define ALTO 480

static uint8_t fb[ANCHO * ALTO];

static int guardar(const char *ruta)
{
    FILE *f = fopen(ruta, "wb");
    if (!f) return -1;
    fprintf(f, "P6\n%d %d\n255\n", ANCHO, ALTO);
    for (int i = 0; i < ANCHO * ALTO; i++) {
        uint8_t c = fb[i];
        /* igual que el HSTX: los bits que faltan van en cero */
        uint8_t rgb[3] = {(uint8_t)(c & 0xE0), (uint8_t)((c << 3) & 0xE0), (uint8_t)((c << 6) & 0xC0)};
        fwrite(rgb, 1, 3, f);
    }
    fclose(f);
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 4) {
        fprintf(stderr, "uso: %s entrada.jpg salida.ppm identificacion.ppm\n", argv[0]);
        return 2;
    }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror(argv[1]); return 1; }
    static uint8_t jpeg[512 * 1024];
    size_t n = fread(jpeg, 1, sizeof jpeg, f);
    fclose(f);

    p332_iniciar(fb, ANCHO, ALTO);
    clock_t t0 = clock();
    int r = 0;
    for (int i = 0; i < 20; i++) r = p332_jpeg(jpeg, (uint32_t)n);
    double ms = (double)(clock() - t0) * 1000.0 / CLOCKS_PER_SEC / 20.0;
    printf("p332_jpeg = %d, %zu bytes, %.2f ms por cuadro en esta PC\n", r, n, ms);
    if (r != P332_OK || guardar(argv[2])) return 1;

    const uint8_t ip[4] = {192, 168, 77, 101};
    p332_identificacion(7, 1, ip);
    return guardar(argv[3]) ? 1 : 0;
}
