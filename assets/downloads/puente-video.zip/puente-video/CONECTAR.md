# Tutorial: conectar el celular a la PC por cable Ethernet

## Lo que necesitas
- PC con Windows 10/11 y puerto Ethernet.
- Celular (Samsung S20 FE, Poco, etc.) con adaptador USB‑C a Ethernet.
- Un cable Ethernet normal entre el adaptador y la PC.

## 1. Instala el programa de la PC (una sola vez)
1. Entra a **github.com/joseantonioquirozluna/Pruebas- → Releases → Puente Video** y descarga **PuenteVideo-Windows.zip** (mejor que el .exe suelto si tu disco C: está casi lleno).
2. Clic derecho sobre el zip → **Extraer en…** y elige una carpeta en el disco con espacio (por ejemplo `D:\Documentos\1UAA\1Semestres\NOVENO SEMESTRE\eternet`).
3. Dentro de la carpeta `PuenteVideo` abre **PuenteVideo.exe**. Si Windows dice «Windows protegió tu PC»: **Más información → Ejecutar de todas formas**.
4. Si Windows pregunta por el firewall, marca **redes privadas y públicas** y permite.

## 2. Deja que el celular reparta las IP (lo más fácil y lo que mejor funciona)

Alguien tiene que repartir las direcciones en el cable. El celular lo hace solo
y sin pedir permisos de administrador, así que es el camino corto.

1. En el celular: **Ajustes → Punto de acceso móvil → Compartir vía Ethernet: encendido**.
   (En la app también está el botón **Red**, que te lleva directo ahí.)
2. En la PC, deja el adaptador del cable en automático. Si antes le pusiste una
   IP fija, quítasela con un `cmd` **como administrador**:

   ```
   netsh interface ip set address name="Ethernet" source=dhcp
   ```

   Cambia `Ethernet` por el nombre que tenga tu adaptador del cable.
3. Conecta el cable y espera unos 10 segundos. Comprueba con:

   ```
   netsh interface ip show config name="Ethernet"
   ```

   Debe decir **DHCP habilitado: Sí** y una dirección tipo `10.148.137.101`.

> **Importante**: con este método **no presiones «Configurar»** en la app de la
> PC y deja **sin palomita** la casilla «Darle IP al celular (DHCP)». Si no, los
> dos lados quieren mandar y ninguno recibe IP.

## 3. Conecta el celular
1. Instala **PuenteVideo.apk** (de la misma página de Releases). Permite «instalar apps de origen desconocido».
2. Conecta el adaptador al celular. En Xiaomi/Poco activa **OTG** (Ajustes → Ajustes adicionales). En Samsung no hace falta.
3. Abre Puente Video en la PC y luego en el celular.
4. **No tienes que escribir ninguna IP.** La PC avisa dónde está y el celular se
   conecta solo. Mientras busca dice «Buscando la PC…».
5. Android pregunta si quieres **compartir tu pantalla** → acepta.
6. En la PC aparece tu pantalla del celular. Lo que elijas en **Fuente** (Pantalla 1, Cámara…) aparece en el celular.

Si después de unos segundos no se conecta solo, en la app de la PC viene escrita
la IP que hay que teclear en el celular.

## Otra forma: que la PC reparta (necesita administrador)
Sirve si prefieres que el celular use el internet de la PC.

1. Apaga **Compartir vía Ethernet** en el celular.
2. `ncpa.cpl` → clic derecho en **Wi‑Fi** → **Propiedades** → **Uso compartido** →
   marca la casilla y elige el adaptador del cable → **Aceptar** → **Sí**.
3. El adaptador del cable pasa a `192.168.137.1` y Windows le da IP al celular.
4. En la app de la PC, deja **sin palomita** la casilla de DHCP y **no presiones Configurar**.

## Botones del celular
- **Envío: pantalla / cámara / nada**: qué mandas a la PC (la cámara arranca apagada).
- **Cámara trasera/frontal** y **480p/720p/1080p**: solo cuando mandas la cámara o para el tamaño de la pantalla compartida.
- Toca el video para esconder los controles (pantalla completa).

## Si la PC dice «No pude abrir el puerto 67» (el celular dice «Sin cable Ethernet»)
Otro servicio de Windows ya usa el puerto del DHCP (pasa con Hyper‑V, WSL, Docker o la Zona con cobertura móvil). Usa la **Conexión compartida de Windows**, que hace lo mismo:
1. Win + R → escribe `ncpa.cpl` → Enter.
2. Clic derecho en **Wi‑Fi** (la conexión que tiene internet) → **Propiedades** → pestaña **Uso compartido**.
3. Marca **«Permitir que los usuarios de otras redes se conecten a través de la conexión a Internet de este equipo»** y en la lista elige el adaptador del cable (por ejemplo **Ethernet 5**) → **Aceptar**.
4. Windows le pone a ese adaptador la IP **192.168.137.1** y reparte IP al celular (y de paso le da internet).
5. En Puente Video **quita la palomita «Darle IP al celular (DHCP)»**.
6. En el celular desconecta y conecta el adaptador: debe decir «mi IP 192.168.137.xx · PC 192.168.137.1». La app pone sola esa IP; toca **Conectar**.

## Si algo falla
| Síntoma | Qué hacer |
|---|---|
| El celular dice «sin IP» | Revisa que la PC diga «DHCP: Activo»; desconecta y conecta el adaptador; en Poco activa OTG |
| Conecta pero no llega video a la PC | Presiona **Configurar** otra vez (crea las reglas del firewall) |
| La PC se quedó sin internet | Elegiste el adaptador del módem: presiona **Regresar a automático** y elige el otro |
| El .exe falla al abrir con «Failed to extract» | Disco C: lleno: usa **PuenteVideo-Windows.zip** extraído en el disco D: |
