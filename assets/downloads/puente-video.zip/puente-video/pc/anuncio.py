"""La PC avisa dónde está, para que el celular se conecte solo.

Cada segundo manda por todos los adaptadores un mensaje corto:

    PUENTE-PC|<ip>|<puerto>|<nombre de la PC>

El celular lo escucha en el puerto 5003 y se conecta sin que nadie escriba
una IP a mano. Como el mensaje sale por cada adaptador con su propia IP,
sirve igual si el cable lo reparte la PC o si lo reparte el celular.
"""

import socket
import struct
import threading
import time

import psutil

PUERTO_AVISO = 5003
NOMBRE = "PUENTE-PC"


def _broadcast_de(ip, mascara):
    """Dirección de difusión de esa red (p. ej. 10.148.137.255)."""
    try:
        a = struct.unpack("!I", socket.inet_aton(ip))[0]
        m = struct.unpack("!I", socket.inet_aton(mascara))[0]
        return socket.inet_ntoa(struct.pack("!I", (a & m) | (~m & 0xFFFFFFFF)))
    except OSError:
        return None


def redes_locales():
    """[(nombre del adaptador, ip, difusión)] de lo que está conectado."""
    salida = []
    estados = psutil.net_if_stats()
    for nombre, direcciones in psutil.net_if_addrs().items():
        estado = estados.get(nombre)
        if estado is not None and not estado.isup:
            continue
        for d in direcciones:
            if d.family != socket.AF_INET:
                continue
            if d.address.startswith("127."):
                continue
            salida.append((nombre, d.address, _broadcast_de(d.address, d.netmask or "255.255.255.0")))
    return salida


def indices_ipv6():
    """[(número de interfaz, nombre)] de los adaptadores que sirven para IPv6."""
    salida = []
    try:
        for indice, nombre in socket.if_nameindex():
            if nombre.lower() in ("lo", "loopback"):
                continue
            salida.append((indice, nombre))
    except (OSError, AttributeError):
        pass
    return salida


def _es_inalambrico(nombre):
    n = nombre.lower()
    return "wi-fi" in n or "wifi" in n or "wlan" in n or "inalámbr" in n or "inalambr" in n


def _es_virtual(nombre):
    n = nombre.lower()
    return any(p in n for p in ("tailscale", "zerotier", "vmware", "virtualbox", "hyper-v",
                                "loopback", "bluetooth", "vethernet", "tap", "tun"))


def ip_recomendada():
    """La IP que conviene teclear en el celular, si alguien la tiene que teclear.

    Primero un adaptador de cable de verdad; si no hay, el Wi-Fi.
    """
    cables, otras = [], []
    for nombre, ip, _ in redes_locales():
        if _es_virtual(nombre):
            continue
        (otras if _es_inalambrico(nombre) else cables).append(ip)
    if cables:
        return cables[0]
    return otras[0] if otras else ""


class Anunciante:
    """Grita «aquí estoy» por todos los adaptadores, una vez por segundo."""

    def __init__(self, puerto_tcp, puerto_aviso=PUERTO_AVISO):
        self.puerto_tcp = puerto_tcp
        self.puerto_aviso = puerto_aviso
        self.activo = False
        self.ultimo_error = ""
        self._hilo = None
        self._sin_ipv6 = False

    def iniciar(self):
        if self.activo:
            return
        self.activo = True
        self._hilo = threading.Thread(target=self._bucle, daemon=True)
        self._hilo.start()

    def detener(self):
        self.activo = False

    def _bucle(self):
        try:
            nombre_pc = socket.gethostname()
        except OSError:
            nombre_pc = "PC"
        while self.activo:
            for _, ip, difusion in redes_locales():
                mensaje = f"{NOMBRE}|{ip}|{self.puerto_tcp}|{nombre_pc}".encode()
                for destino in filter(None, (difusion, "255.255.255.255")):
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                        s.settimeout(0.3)
                        s.bind((ip, 0))  # sale por ese adaptador
                        s.sendto(mensaje, (destino, self.puerto_aviso))
                        s.close()
                    except OSError as e:
                        self.ultimo_error = str(e)
            self._gritar_ipv6(nombre_pc)
            time.sleep(1)

    def _gritar_ipv6(self, nombre_pc):
        """Avisa también por IPv6, a «todos los nodos» del cable (ff02::1).

        Esto es lo que salva el cable directo: las direcciones fe80:: existen
        en cuanto hay cable, sin que nadie reparta IP ni haya DHCP. El celular
        ve de qué dirección vino el mensaje y se conecta a esa.
        """
        if not socket.has_ipv6 or self._sin_ipv6:
            return
        try:
            socket.socket(socket.AF_INET6, socket.SOCK_DGRAM).close()
        except OSError:
            self._sin_ipv6 = True  # esta máquina no tiene IPv6: no insistir
            return
        for indice, nombre in indices_ipv6():
            try:
                s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
                s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_IF, indice)
                s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_HOPS, 1)
                s.settimeout(0.3)
                mensaje = f"{NOMBRE}|::|{self.puerto_tcp}|{nombre_pc}".encode()
                s.sendto(mensaje, ("ff02::1", self.puerto_aviso, 0, indice))
                s.close()
            except OSError as e:
                self.ultimo_error = str(e)
