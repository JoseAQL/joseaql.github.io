"""El código QR que el celular lee para conectarse de un jalón.

El QR lleva una sola línea:

    puentevideo://<ip>:<puerto>

Se usa la librería `qrcode`, que es puro Python y pesa poco. Si no está
instalada, el programa sigue funcionando y solo enseña la dirección escrita.
"""

import numpy as np

try:
    import qrcode
    from qrcode.constants import ERROR_CORRECT_M
except ImportError:
    qrcode = None


def texto_de_conexion(ip, puerto):
    return f"puentevideo://{ip}:{puerto}"


def hay_qr():
    return qrcode is not None


def imagen_qr(texto, lado=260):
    """Imagen en escala de grises (numpy) lista para enseñar, o None.

    Corrección de errores M: aguanta que la pantalla tenga reflejos o que el
    celular lo lea medio chueco.
    """
    if qrcode is None:
        return None
    q = qrcode.QRCode(version=None, error_correction=ERROR_CORRECT_M,
                      box_size=1, border=3)
    q.add_data(texto)
    q.make(fit=True)
    chico = np.array(q.make_image(fill_color="black", back_color="white").convert("L"))
    escala = max(1, lado // chico.shape[0])
    return np.kron(chico, np.ones((escala, escala), dtype=np.uint8))
