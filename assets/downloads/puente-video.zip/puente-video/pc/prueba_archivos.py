"""Prueba de la transferencia de archivos, sin red y sin ventana.

Se corre con `python prueba_archivos.py` y no necesita celular: arma los dos
extremos con un par de sockets local, así que prueba el protocolo completo
(oferta, acuse, trozos, fin, suma) sin depender del cable.

Lo que revisa, en orden de importancia:

  1. que un archivo llegue **idéntico** (la suma del que llegó contra la del
     que salió), que es lo único que de verdad importa;
  2. que un nombre con «../» no escriba fuera de la carpeta de recibidos;
  3. que no se sobreescriba un archivo que ya estaba;
  4. que un corte a la mitad deje un `.parcial` y que al reconectar **reanude
     desde ese byte** y no desde cero;
  5. que una suma que no cuadra se detecte y el archivo malo se descarte.

El punto 4 es el que cuesta probar: con sockets locales un archivo de 8 MB
termina antes de que a uno le alcance el tiempo de cortarlo, así que el corte
no se hace con un `sleep` (que a veces alcanza y a veces no) sino desde el
propio avisador de avance, en cuanto pasa de 1 MB. Así la prueba corta siempre
en el mismo punto y no falla un día de cada cinco por ser más rápida la máquina.
"""

import os
import shutil
import socket
import struct
import sys
import tempfile
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import archivos as A  # noqa: E402

fallos = 0


def check(nombre, ok, extra=""):
    global fallos
    print(("OK    " if ok else "FALLA ") + nombre + (f"  — {extra}" if extra else ""))
    if not ok:
        fallos += 1


def esperar(cond, limite=30):
    t0 = time.time()
    while time.time() - t0 < limite:
        if cond():
            return True
        time.sleep(0.03)
    return False


def enlace_doble(dir_izq, dir_der, al_cambiar_der=None):
    a, b = socket.socketpair()
    izq = A.Enlace(a, dir_izq)
    der = A.Enlace(b, dir_der, al_cambiar=al_cambiar_der)
    izq.iniciar()
    der.iniciar()
    return izq, der


def main():
    base = tempfile.mkdtemp(prefix="prueba_archivos_")
    try:
        correr(base)
    finally:
        shutil.rmtree(base, ignore_errors=True)
    print()
    if fallos:
        print(f"{fallos} FALLAS")
        return 1
    print("TODO BIEN")
    return 0


def correr(base):
    org = os.path.join(base, "origen")
    da, db = os.path.join(base, "a"), os.path.join(base, "b")
    for d in (org, da, db):
        os.makedirs(d)

    def crear(nombre, n):
        ruta = os.path.join(org, nombre)
        with open(ruta, "wb") as f:
            f.write(os.urandom(n))
        return ruta

    # ---------------------------------------------- 1. ida, y contenido igual
    ea, eb = enlace_doble(da, db)
    ruta = crear("video de prueba.mp4", 5 * 1024 * 1024)
    suma = A.suma_del_archivo(ruta)
    ea.mandar([ruta])
    llego = esperar(lambda: any(c.estado == "lista" for c in eb.lista()))
    destino = os.path.join(db, "video de prueba.mp4")
    check("llega un archivo de 5 MB", llego and os.path.exists(destino))
    check("el contenido es idéntico",
          os.path.exists(destino) and A.suma_del_archivo(destino) == suma)
    check("el que manda ve que quedó lista",
          esperar(lambda: any(c.estado == "lista" and c.saliendo for c in ea.lista())))

    # ------------------------------------------- 2. nombre que intenta escapar
    chico = crear("normal.txt", 100)
    ident = 99
    ea._escribir(A.TIPO_OFERTA, A.SEPARADOR.join(
        [str(ident), "../../ESCAPE.txt", "100", A.suma_del_archivo(chico)]).encode("utf-8"))
    esperar(lambda: any(c.id == ident for c in eb.lista()))
    with open(chico, "rb") as f:
        ea._escribir(A.TIPO_TROZO, struct.pack("!I", ident) + f.read())
    ea._escribir(A.TIPO_FIN, str(ident).encode("utf-8"))
    esperar(lambda: any(c.id == ident and c.terminada for c in eb.lista()))
    afuera = os.path.abspath(os.path.join(db, "..", "ESCAPE.txt"))
    check("un nombre con ../ no escribe fuera de la carpeta",
          not os.path.exists(afuera) and os.path.exists(os.path.join(db, "ESCAPE.txt")))

    # ----------------------------------------- 3. no pisa lo que ya estaba ahí
    ea.mandar([ruta])
    esperar(lambda: sum(1 for c in eb.lista()
                        if c.nombre == "video de prueba.mp4" and c.estado == "lista") == 2)
    check("el segundo con el mismo nombre se renombra",
          os.path.exists(os.path.join(db, "video de prueba (2).mp4")))
    ea.cerrar()
    eb.cerrar()

    # ------------------------------------------- 4. corte y reanudación real
    dc = os.path.join(base, "c")
    os.makedirs(dc)
    grande = crear("grande.bin", 8 * 1024 * 1024)
    suma_g = A.suma_del_archivo(grande)
    corte = {"hecho": False}
    receptor = {}

    def al_cambiar():
        if corte["hecho"]:
            return
        for c in receptor["e"].lista():
            if not c.saliendo and 1024 * 1024 < c.hechos < c.tamano:
                corte["hecho"] = True
                # En otro hilo: cerrar desde el avisador sería cerrarse encima.
                threading.Thread(target=receptor["e"].cerrar, daemon=True).start()
                return

    ea, eb = enlace_doble(da, dc, al_cambiar_der=al_cambiar)
    receptor["e"] = eb
    ea.mandar([grande])
    check("alcanza a cortarse a la mitad", esperar(lambda: corte["hecho"], 20))
    time.sleep(0.5)
    ea.cerrar()
    parciales = [f for f in os.listdir(dc) if f.endswith(".parcial")]
    cortado = os.path.getsize(os.path.join(dc, parciales[0])) if parciales else 0
    check("queda un .parcial con parte del archivo",
          len(parciales) == 1 and 0 < cortado < 8 * 1024 * 1024,
          f"{cortado} bytes")

    ea, eb = enlace_doble(da, dc)
    ea.mandar([grande])
    esperar(lambda: any(c.estado == "lista" for c in eb.lista()))
    final = os.path.join(dc, "grande.bin")
    salida = [c for c in ea.lista() if c.saliendo]
    check("termina después de reconectar", os.path.exists(final))
    check("el archivo reanudado es idéntico",
          os.path.exists(final) and A.suma_del_archivo(final) == suma_g)
    check("reanudó desde el byte exacto donde se cortó, no desde cero",
          bool(salida) and salida[0].desde == cortado,
          f"reanudó en {salida[0].desde if salida else '?'}, se cortó en {cortado}")
    check("ya no queda ningún .parcial",
          not any(f.endswith(".parcial") for f in os.listdir(dc)))
    ea.cerrar()
    eb.cerrar()

    # ------------------------------------------------ 5. suma que no cuadra
    dd = os.path.join(base, "d")
    os.makedirs(dd)
    ea, eb = enlace_doble(da, dd)
    ident = 500
    ea._escribir(A.TIPO_OFERTA, A.SEPARADOR.join(
        [str(ident), "malo.bin", "10", "0" * 64]).encode("utf-8"))
    esperar(lambda: any(c.id == ident for c in eb.lista()))
    ea._escribir(A.TIPO_TROZO, struct.pack("!I", ident) + b"0123456789")
    ea._escribir(A.TIPO_FIN, str(ident).encode("utf-8"))
    esperar(lambda: any(c.id == ident and c.terminada for c in eb.lista()))
    cop = [c for c in eb.lista() if c.id == ident][0]
    check("detecta que la suma no cuadra", cop.estado == "falló", cop.detalle)
    check("descarta el archivo malo y su .parcial",
          not os.path.exists(os.path.join(dd, "malo.bin"))
          and not any(f.endswith(".parcial") for f in os.listdir(dd)))
    ea.cerrar()
    eb.cerrar()


if __name__ == "__main__":
    sys.exit(main())
