"""Mandar y recibir archivos entre la PC y el celular por el mismo cable.

Va en un socket aparte, en el puerto 5005, y no en el del video. La razón no
es el orden: es que TCP entrega en orden, así que un archivo de 2 GB metido en
el socket del video dejaría al video esperando detrás de él y la imagen se
congelaría hasta que terminara la copia. Con dos sockets cada cosa avanza a su
ritmo y el sistema operativo reparte el ancho de banda.

El formato de los mensajes es el mismo del video, para reusar lo que ya está
probado:

    1 byte  tipo
    4 bytes largo (big-endian)
    N bytes datos

Los tipos empiezan en 10 para no pisar los del video (1 a 3):

    10 OFERTA   id|nombre|tamaño|sha256   «tengo este archivo, ¿lo quieres?»
    11 TROZO    id(4 bytes) + bytes       un pedazo, en orden
    12 FIN      id                        «ya está, revisa»
    13 ACEPTA   id|desde                  «sí, mándalo desde el byte <desde>»
    14 RECHAZA  id|motivo                 «no», con razón para enseñarla
    15 LISTO    id|ok|detalle             «llegó bien» o «llegó mal»

Dos cosas que no son adorno:

**La suma SHA-256 va en la oferta, antes de los datos.** Un archivo de Word o
un video que llega con un byte cambiado no avisa: abre mal o se ve mal mucho
después, cuando ya nadie se acuerda de cómo llegó. Comparar la suma al final
cuesta un recorrido del archivo y convierte un error silencioso en un mensaje.

**Se puede reanudar.** Lo que va llegando se escribe en un archivo `.parcial`.
Si el cable se desconecta a la mitad de un video, al reintentar el receptor
dice «mándalo desde el byte tal» y no se repiten los dos minutos que ya
pasaron. Es la diferencia entre que un corte sea un estorbo o un castigo.
"""

import hashlib
import os
import socket
import struct
import threading
import time

PUERTO_ARCHIVOS = 5005

TIPO_OFERTA = 10
TIPO_TROZO = 11
TIPO_FIN = 12
TIPO_ACEPTA = 13
TIPO_RECHAZA = 14
TIPO_LISTO = 15

TROZO = 256 * 1024                  # 256 kB: suficiente para llenar el cable
LARGO_MAXIMO = 16 * 1024 * 1024     # el mismo tope del video
SEPARADOR = "|"


# ------------------------------------------------------------------ utilería
def recibir_exacto(sock, n):
    """n bytes o excepción. recv() puede devolver menos de lo pedido."""
    datos = bytearray(n)
    vista = memoryview(datos)
    leidos = 0
    while leidos < n:
        r = sock.recv_into(vista[leidos:], n - leidos)
        if r == 0:
            raise ConnectionError("la otra punta cerró la conexión")
        leidos += r
    return bytes(datos)


def mensaje(tipo, datos):
    return struct.pack("!BI", tipo, len(datos)) + datos


def suma_del_archivo(ruta, avance=None):
    """SHA-256 de un archivo, leyéndolo por pedazos para no cargarlo en memoria."""
    h = hashlib.sha256()
    leido = 0
    with open(ruta, "rb") as f:
        while True:
            pedazo = f.read(1024 * 1024)
            if not pedazo:
                break
            h.update(pedazo)
            leido += len(pedazo)
            if avance is not None:
                avance(leido)
    return h.hexdigest()


def nombre_seguro(nombre):
    """Deja solo el nombre del archivo, sin ruta.

    La otra punta manda un nombre y aquí se usa para crear un archivo, así que
    hay que quitarle cualquier intento de salirse de la carpeta: separadores de
    las dos plataformas, «..», y los nombres que Windows no acepta. Sin esto,
    un nombre como «..\\..\\Windows\\System32\\algo.dll» escribiría fuera de la
    carpeta de recibidos.
    """
    nombre = nombre.replace("\\", "/").split("/")[-1]
    nombre = nombre.replace("\x00", "")
    nombre = "".join(c for c in nombre if c.isprintable() and c not in '<>:"|?*')
    nombre = nombre.strip(" .")
    if nombre in ("", ".", ".."):
        nombre = "archivo"
    reservados = {"CON", "PRN", "AUX", "NUL"}
    reservados |= {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    if nombre.split(".")[0].upper() in reservados:
        nombre = "_" + nombre
    return nombre[:200]


def ruta_libre(carpeta, nombre):
    """La misma carpeta con un nombre que no exista: «foto.jpg», «foto (2).jpg»…"""
    base, extension = os.path.splitext(nombre)
    candidata = os.path.join(carpeta, nombre)
    n = 2
    while os.path.exists(candidata):
        candidata = os.path.join(carpeta, f"{base} ({n}){extension}")
        n += 1
    return candidata


def carpeta_recibidos_por_omision():
    """Donde se guarda lo que llega: la carpeta Descargas del usuario.

    Es la misma carpeta que el celular dice («Lo que llega va a Descargas»),
    así que el usuario encuentra los archivos donde espera. Si no se puede
    averiguar Descargas, se cae a Documentos y, al final, a la carpeta personal.
    """
    inicio = os.path.expanduser("~")
    for nombre in ("Downloads", "Descargas"):
        candidata = os.path.join(inicio, nombre)
        if os.path.isdir(candidata):
            return candidata
    for nombre in ("Documents", "Documentos"):
        candidata = os.path.join(inicio, nombre)
        if os.path.isdir(candidata):
            return candidata
    return inicio


def tamano_legible(n):
    for unidad in ("B", "kB", "MB", "GB"):
        if n < 1024 or unidad == "GB":
            return f"{n:.0f} {unidad}" if unidad == "B" else f"{n:.1f} {unidad}"
        n /= 1024.0
    return f"{n:.1f} GB"


# -------------------------------------------------------------- una copia
class Copia:
    """El estado de un archivo que va o viene, para enseñarlo en la lista."""

    def __init__(self, ident, nombre, tamano, saliendo):
        self.id = ident
        self.nombre = nombre
        self.tamano = tamano
        self.saliendo = saliendo        # True si va de aquí para allá
        self.hechos = 0
        self.desde = 0          # byte en el que arrancó: > 0 si se reanudó
        self.estado = "esperando"
        self.detalle = ""
        self.t0 = time.time()
        self.t_fin = None

    @property
    def terminada(self):
        return self.estado in ("lista", "falló", "rechazada")

    @property
    def porcentaje(self):
        return 100.0 if self.tamano == 0 else min(100.0, 100.0 * self.hechos / self.tamano)

    def velocidad(self):
        """Bytes por segundo del promedio de esta copia, o 0 si acaba de empezar."""
        pasado = (self.t_fin or time.time()) - self.t0
        return self.hechos / pasado if pasado > 0.3 else 0.0

    def resumen(self):
        linea = f"{'↑' if self.saliendo else '↓'} {self.nombre} · {tamano_legible(self.tamano)}"
        if self.estado == "copiando":
            v = self.velocidad()
            linea += f" · {self.porcentaje:.0f} %"
            if v > 0:
                linea += f" · {tamano_legible(v)}/s"
                faltan = self.tamano - self.hechos
                if faltan > 0:
                    linea += f" · faltan {faltan / v:.0f} s"
        else:
            linea += f" · {self.estado}"
            if self.detalle:
                linea += f" ({self.detalle})"
            if self.desde and self.estado == "lista":
                # Vale decirlo al final y no solo mientras va: explica por qué
                # un archivo grande terminó tan rápido.
                linea += f" · se reanudó desde {tamano_legible(self.desde)}"
        return linea


# ----------------------------------------------------------------- el enlace
class Enlace:
    """Un socket de archivos ya conectado. Manda y recibe por el mismo.

    Vive en su propio hilo de lectura. `mandar()` encola y devuelve en seguida,
    así que se puede llamar desde la ventana sin congelarla.
    """

    def __init__(self, sock, carpeta_recibidos, al_cambiar=None, registro=None):
        self.sock = sock
        self.carpeta = carpeta_recibidos
        self.al_cambiar = al_cambiar or (lambda: None)
        self.registro = registro or (lambda t: None)
        self.copias = []                    # lo que se enseña, más nuevo al final
        self.candado = threading.Lock()
        self.candado_escritura = threading.Lock()
        self.cola = []                      # rutas por mandar
        self.hay_cola = threading.Condition()
        self.vivo = True
        self.siguiente_id = 1
        self._respuesta = {}                # id -> (tipo, datos) de ACEPTA/RECHAZA
        self._espera = threading.Condition()
        # Lo que se está recibiendo ahora: id -> (archivo abierto, ruta parcial,
        # ruta final, hash, copia)
        self._entrando = {}

    # -------------------------------------------------------------- arranque
    def iniciar(self):
        threading.Thread(target=self._bucle_lectura, daemon=True).start()
        threading.Thread(target=self._bucle_envio, daemon=True).start()

    def cerrar(self):
        self.vivo = False
        with self.hay_cola:
            self.hay_cola.notify_all()
        with self._espera:
            self._espera.notify_all()
        try:
            self.sock.close()
        except OSError:
            pass
        # Lo que estaba a medias se deja en .parcial a propósito: así se puede
        # reanudar cuando se vuelva a conectar.
        with self.candado:
            for ident, (f, _, _, _, copia) in list(self._entrando.items()):
                try:
                    f.close()
                except OSError:
                    pass
                if not copia.terminada:
                    copia.estado = "cortada"
                    copia.detalle = "se puede reanudar"
            self._entrando.clear()
            for c in self.copias:
                if c.estado in ("copiando", "esperando"):
                    c.estado = "cortada"
                    c.detalle = "se puede reanudar"
        self.al_cambiar()

    def _escribir(self, tipo, datos):
        with self.candado_escritura:
            self.sock.sendall(mensaje(tipo, datos))

    # ------------------------------------------------------------------ salir
    def mandar(self, rutas):
        """Encola archivos para mandar. No bloquea."""
        nuevas = []
        for ruta in rutas:
            if os.path.isdir(ruta):
                self.registro(f"«{os.path.basename(ruta)}» es una carpeta; por ahora solo archivos.")
                continue
            if not os.path.isfile(ruta):
                continue
            nuevas.append(ruta)
        if not nuevas:
            return
        with self.hay_cola:
            self.cola.extend(nuevas)
            self.hay_cola.notify_all()

    def _bucle_envio(self):
        while self.vivo:
            with self.hay_cola:
                while self.vivo and not self.cola:
                    self.hay_cola.wait(0.5)
                if not self.vivo:
                    return
                ruta = self.cola.pop(0)
            try:
                self._mandar_uno(ruta)
            except (OSError, ConnectionError) as e:
                self.registro(f"Se cortó al mandar «{os.path.basename(ruta)}»: {e}")
                return

    def _mandar_uno(self, ruta):
        tamano = os.path.getsize(ruta)
        nombre = os.path.basename(ruta)
        with self.candado:
            ident = self.siguiente_id
            self.siguiente_id += 1
            copia = Copia(ident, nombre, tamano, saliendo=True)
            copia.estado = "sumando"
            self.copias.append(copia)
        self.al_cambiar()

        # La suma va antes de los datos, así que hay que leer el archivo dos
        # veces. En un disco local eso es mucho más barato que descubrir al
        # final que llegó mal y repetir la copia completa por el cable.
        suma = suma_del_archivo(ruta)
        copia.estado = "esperando"
        self.al_cambiar()

        self._escribir(TIPO_OFERTA, SEPARADOR.join(
            [str(ident), nombre, str(tamano), suma]).encode("utf-8"))

        tipo, datos = self._esperar_respuesta(ident)
        if tipo != TIPO_ACEPTA:
            copia.estado = "rechazada"
            copia.detalle = datos
            copia.t_fin = time.time()
            self.al_cambiar()
            return
        desde = int(datos or 0)
        copia.hechos = desde
        copia.desde = desde
        copia.t0 = time.time()
        copia.estado = "copiando"
        if desde:
            copia.detalle = f"reanudada desde {tamano_legible(desde)}"
        self.al_cambiar()

        cabeza = struct.pack("!I", ident)
        with open(ruta, "rb") as f:
            f.seek(desde)
            while self.vivo:
                pedazo = f.read(TROZO)
                if not pedazo:
                    break
                self._escribir(TIPO_TROZO, cabeza + pedazo)
                copia.hechos += len(pedazo)
                self.al_cambiar()
        if not self.vivo:
            return
        self._escribir(TIPO_FIN, str(ident).encode("utf-8"))

        tipo, datos = self._esperar_respuesta(ident)
        copia.t_fin = time.time()
        if tipo == TIPO_LISTO and datos.startswith("ok"):
            copia.estado = "lista"
            copia.detalle = ""
        else:
            copia.estado = "falló"
            copia.detalle = datos
        self.al_cambiar()

    def _esperar_respuesta(self, ident, espera=120.0):
        limite = time.time() + espera
        with self._espera:
            while self.vivo and ident not in self._respuesta:
                if not self._espera.wait(min(1.0, max(0.05, limite - time.time()))):
                    if time.time() >= limite:
                        return TIPO_RECHAZA, "no contestó"
            if not self.vivo:
                return TIPO_RECHAZA, "se cerró la conexión"
            return self._respuesta.pop(ident)

    # ----------------------------------------------------------------- entrar
    def _bucle_lectura(self):
        try:
            while self.vivo:
                tipo, largo = struct.unpack("!BI", recibir_exacto(self.sock, 5))
                if largo > LARGO_MAXIMO:
                    raise ConnectionError("mensaje inválido")
                datos = recibir_exacto(self.sock, largo)
                self._atender(tipo, datos)
        except (OSError, ConnectionError, struct.error):
            pass
        finally:
            self.cerrar()

    def _atender(self, tipo, datos):
        if tipo == TIPO_OFERTA:
            self._llega_oferta(datos.decode("utf-8", "replace"))
        elif tipo == TIPO_TROZO:
            self._llega_trozo(datos)
        elif tipo == TIPO_FIN:
            self._llega_fin(datos.decode("utf-8", "replace"))
        elif tipo in (TIPO_ACEPTA, TIPO_RECHAZA, TIPO_LISTO):
            # Respuestas a algo que estamos mandando.
            partes = datos.decode("utf-8", "replace").split(SEPARADOR, 1)
            try:
                ident = int(partes[0])
            except (ValueError, IndexError):
                return
            resto = partes[1] if len(partes) > 1 else ""
            with self._espera:
                self._respuesta[ident] = (tipo, resto)
                self._espera.notify_all()

    def _llega_oferta(self, texto):
        partes = texto.split(SEPARADOR)
        if len(partes) < 4:
            return
        try:
            ident = int(partes[0])
            tamano = int(partes[2])
        except ValueError:
            return
        nombre = nombre_seguro(partes[1])
        suma = partes[3].strip().lower()

        try:
            os.makedirs(self.carpeta, exist_ok=True)
        except OSError as e:
            self._escribir(TIPO_RECHAZA, f"{ident}{SEPARADOR}no pude crear la carpeta: {e}".encode("utf-8"))
            return

        # ¿Hay un .parcial de este mismo archivo? El nombre del parcial lleva la
        # suma, así que solo se reanuda si de verdad es el mismo contenido: si el
        # archivo cambió del otro lado, la suma cambia y empieza de cero.
        parcial = os.path.join(self.carpeta, f".{suma[:16]}.parcial")
        desde = 0
        if os.path.exists(parcial):
            desde = min(os.path.getsize(parcial), tamano)

        libre = self._espacio_libre()
        if libre is not None and libre < (tamano - desde) + 8 * 1024 * 1024:
            self._escribir(TIPO_RECHAZA, (
                f"{ident}{SEPARADOR}no cabe: faltan "
                f"{tamano_legible(tamano - desde - libre)}").encode("utf-8"))
            return

        copia = Copia(ident, nombre, tamano, saliendo=False)
        copia.hechos = desde
        copia.desde = desde
        copia.estado = "copiando"
        if desde:
            copia.detalle = f"reanudada desde {tamano_legible(desde)}"
        try:
            f = open(parcial, "r+b" if desde else "wb")
            if desde:
                f.seek(desde)
                f.truncate(desde)
        except OSError as e:
            self._escribir(TIPO_RECHAZA, f"{ident}{SEPARADOR}no pude escribir: {e}".encode("utf-8"))
            return

        with self.candado:
            self.copias.append(copia)
            self._entrando[ident] = (f, parcial, nombre, suma, copia)
        self.al_cambiar()
        self._escribir(TIPO_ACEPTA, f"{ident}{SEPARADOR}{desde}".encode("utf-8"))

    def _llega_trozo(self, datos):
        if len(datos) < 4:
            return
        ident = struct.unpack("!I", datos[:4])[0]
        with self.candado:
            entrada = self._entrando.get(ident)
        if entrada is None:
            return
        f, _, _, _, copia = entrada
        pedazo = datos[4:]
        try:
            f.write(pedazo)
        except OSError as e:
            self._fallar_entrada(ident, f"no pude escribir: {e}")
            return
        copia.hechos += len(pedazo)
        self.al_cambiar()

    def _llega_fin(self, texto):
        try:
            ident = int(texto.split(SEPARADOR)[0])
        except (ValueError, IndexError):
            return
        with self.candado:
            entrada = self._entrando.pop(ident, None)
        if entrada is None:
            return
        f, parcial, nombre, suma, copia = entrada
        try:
            f.close()
        except OSError:
            pass
        copia.estado = "revisando"
        self.al_cambiar()

        real = suma_del_archivo(parcial)
        copia.t_fin = time.time()
        if suma and real != suma:
            # El .parcial se borra: si la suma no cuadra, reanudar sobre él
            # arrastraría el error para siempre.
            copia.estado = "falló"
            copia.detalle = "la suma no cuadra; se descartó"
            try:
                os.remove(parcial)
            except OSError:
                pass
            self.al_cambiar()
            self._escribir(TIPO_LISTO, f"{ident}{SEPARADOR}mal{SEPARADOR}suma distinta".encode("utf-8"))
            return

        destino = ruta_libre(self.carpeta, nombre)
        try:
            os.replace(parcial, destino)
        except OSError as e:
            copia.estado = "falló"
            copia.detalle = str(e)
            self.al_cambiar()
            self._escribir(TIPO_LISTO, f"{ident}{SEPARADOR}mal{SEPARADOR}{e}".encode("utf-8"))
            return

        copia.estado = "lista"
        copia.detalle = os.path.basename(destino)
        self.al_cambiar()
        self.registro(f"Llegó «{os.path.basename(destino)}» ({tamano_legible(copia.tamano)}).")
        self._escribir(TIPO_LISTO, f"{ident}{SEPARADOR}ok".encode("utf-8"))

    def _fallar_entrada(self, ident, motivo):
        with self.candado:
            entrada = self._entrando.pop(ident, None)
        if entrada is None:
            return
        f, _, _, _, copia = entrada
        try:
            f.close()
        except OSError:
            pass
        copia.estado = "falló"
        copia.detalle = motivo
        copia.t_fin = time.time()
        self.al_cambiar()
        try:
            self._escribir(TIPO_LISTO, f"{ident}{SEPARADOR}mal{SEPARADOR}{motivo}".encode("utf-8"))
        except OSError:
            pass

    def _espacio_libre(self):
        try:
            return os.statvfs(self.carpeta).f_bavail * os.statvfs(self.carpeta).f_frsize
        except (OSError, AttributeError):
            pass
        try:
            import shutil
            return shutil.disk_usage(self.carpeta).free
        except (OSError, ValueError):
            return None

    # ------------------------------------------------------------------ lista
    def lista(self):
        """Copia de la lista, para que la ventana la lea sin candados."""
        with self.candado:
            return list(self.copias)

    def limpiar_terminadas(self):
        with self.candado:
            self.copias = [c for c in self.copias if not c.terminada]
        self.al_cambiar()


# --------------------------------------------------------------- el servidor
class ServidorArchivos:
    """Escucha en el puerto 5005 y atiende a un celular a la vez."""

    def __init__(self, carpeta_recibidos, al_cambiar=None, registro=None):
        self.carpeta = carpeta_recibidos
        self.al_cambiar = al_cambiar or (lambda: None)
        self.registro = registro or (lambda t: None)
        self.enlace = None
        self.error = ""
        self.vivo = True
        self.puerto = PUERTO_ARCHIVOS

    def iniciar(self):
        threading.Thread(target=self._aceptar, daemon=True).start()

    def detener(self):
        self.vivo = False
        if self.enlace is not None:
            self.enlace.cerrar()

    def conectado(self):
        return self.enlace is not None and self.enlace.vivo

    def mandar(self, rutas):
        if self.conectado():
            self.enlace.mandar(rutas)
            return True
        return False

    def _abrir_escucha(self):
        # Doble pila, igual que el video: hace falta para las direcciones
        # fe80:: del cable, que existen aunque nadie reparta IP.
        if socket.has_ipv6:
            try:
                srv = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
                srv.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                srv.bind(("::", PUERTO_ARCHIVOS))
                return srv
            except OSError:
                try:
                    srv.close()
                except (OSError, UnboundLocalError):
                    pass
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", PUERTO_ARCHIVOS))
        return srv

    def _aceptar(self):
        try:
            srv = self._abrir_escucha()
        except OSError as e:
            self.error = (f"No pude abrir el puerto {PUERTO_ARCHIVOS} para archivos: {e}. "
                          f"¿Ya hay otro Puente Video abierto?")
            self.al_cambiar()
            return
        srv.listen(2)
        while self.vivo:
            try:
                c, _ = srv.accept()
            except OSError:
                return
            c.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            anterior = self.enlace
            enlace = Enlace(c, self.carpeta, self.al_cambiar, self.registro)
            self.enlace = enlace
            if anterior is not None:
                anterior.cerrar()
            enlace.iniciar()
            self.al_cambiar()
