"""Puente Video (PC) — video en vivo PC <-> celular por cable Ethernet.

La PC es el servidor (puerto 5000). El celular se conecta y por el mismo
socket viajan los dos videos como cuadros JPEG:

    1 byte tipo (1 = JPEG, 2 = texto, 3 = acuse) | 4 bytes largo (big-endian) | datos

Quien recibe un JPEG contesta con un acuse (tipo 3) al decodificarlo. Nunca
hay más de 2 cuadros en camino, así la latencia no crece si un lado va lento.
"""

import ipaddress
import ctypes
import os
import socket
import struct
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import cv2
import numpy as np
import psutil
from PIL import Image, ImageTk

try:
    import mss
except ImportError:  # sin mss no hay opción de mandar la pantalla
    mss = None

from dhcp_simple import ServidorDHCP
from anuncio import Anunciante, ip_recomendada
from archivos import ServidorArchivos, carpeta_recibidos_por_omision, tamano_legible
from control_remoto import ControlRemoto
import monitor_virtual
from arreglo_red import abrir_firewall, dejar_en_automatico, pareja_de_ips, revisar
from codigo_qr import imagen_qr, texto_de_conexion
from nodos import FUENTES, Descubridor, PantallaCompartida
from pantalla_pc import CapturaPantalla, avisar_escalado, cuantas_pantallas
from usb_cable import (TunelUSB, adaptadores_de_anclaje, buscar_adb, comandos_no_gastar_datos,
                       descargar_adb)

PUERTO = 5000
IP_CABLE = "192.168.77.1"
MASCARA = "255.255.255.0"
TIPO_JPEG = 1
TIPO_TEXTO = 2
TIPO_ACUSE = 3
TIPO_CONTROL = 4   # el celular mueve el cursor de la PC
MAX_EN_CAMINO = 2
LARGO_MAXIMO = 16 * 1024 * 1024
NOMBRE_REGLA = "Puente Video"
ES_WINDOWS = sys.platform == "win32"

RESOLUCIONES = {"480p": 480, "720p": 720, "1080p": 1080}


def recibir_exacto(sock, n):
    datos = bytearray(n)
    vista = memoryview(datos)
    leidos = 0
    while leidos < n:
        r = sock.recv_into(vista[leidos:], n - leidos)
        if r == 0:
            raise ConnectionError("el celular cerró la conexión")
        leidos += r
    return bytes(datos)


def mensaje(tipo, datos):
    return struct.pack("!BI", tipo, len(datos)) + datos


# --------------------------------------------------------------------------
class Servidor:
    """Acepta un celular a la vez. Si se conecta otro, reemplaza al anterior."""

    def __init__(self):
        self.cond = threading.Condition()
        self.cliente = None
        self.direccion = None
        self.nombre_cel = ""
        self.pendiente = None
        self.en_camino = 0
        self.candado_escritura = threading.Lock()
        self.ultimo_cuadro = None      # imagen BGR del celular
        self.version_cuadro = 0
        self.recibidos = 0
        self.enviados = 0
        self.error = ""
        self.control = None     # lo pone la ventana; None = nadie controla nada

    def iniciar(self):
        threading.Thread(target=self._aceptar, daemon=True).start()

    def _aceptar(self):
        # Doble pila: escuchar en IPv6 con V6ONLY apagado atiende también IPv4.
        # Hace falta para las direcciones fe80:: del cable, que existen siempre
        # aunque nadie reparta IP.
        srv = None
        if socket.has_ipv6:
            try:
                srv = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
                srv.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                srv.bind(("::", PUERTO))
            except OSError:
                if srv is not None:
                    srv.close()
                srv = None
        if srv is None:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                srv.bind(("0.0.0.0", PUERTO))
            except OSError as e:
                self.error = f"No pude abrir el puerto {PUERTO}: {e}. ¿Ya hay otro Puente Video abierto?"
                return
        srv.listen(2)
        while True:
            c, direccion = srv.accept()
            c.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            c.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 256 * 1024)
            with self.cond:
                anterior = self.cliente
                self.cliente = c
                self.direccion = direccion[0]
                self.nombre_cel = ""
                self.pendiente = None
                self.en_camino = 0
                self.cond.notify_all()
            if anterior is not None:
                try:
                    anterior.close()
                except OSError:
                    pass
            threading.Thread(target=self._recibir, args=(c,), daemon=True).start()
            threading.Thread(target=self._enviar, args=(c,), daemon=True).start()

    def _soltar(self, c):
        with self.cond:
            if self.cliente is c:
                self.cliente = None
                self.direccion = None
                self.nombre_cel = ""
                self.pendiente = None
                # El permiso de mover el cursor muere con la conexión que lo
                # recibió. Si no, el siguiente celular que se conecte heredaría
                # un permiso que su dueño nunca dio, y basta con que alguien
                # desconecte el cable y conecte otro teléfono.
                if self.control is not None:
                    self.control.apagar()
            self.cond.notify_all()
        try:
            c.close()
        except OSError:
            pass

    def _recibir(self, c):
        try:
            while True:
                tipo, largo = struct.unpack("!BI", recibir_exacto(c, 5))
                if largo > LARGO_MAXIMO:
                    raise ConnectionError("mensaje inválido")
                datos = recibir_exacto(c, largo)
                if tipo == TIPO_JPEG:
                    img = cv2.imdecode(np.frombuffer(datos, np.uint8), cv2.IMREAD_COLOR)
                    if img is not None:
                        self.ultimo_cuadro = img
                        self.version_cuadro += 1
                        self.recibidos += 1
                    self._escribir(c, TIPO_ACUSE, b"")
                elif tipo == TIPO_ACUSE:
                    with self.cond:
                        if self.cliente is c and self.en_camino > 0:
                            self.en_camino -= 1
                elif tipo == TIPO_CONTROL:
                    # El celular tocó su pantalla. Si el control está apagado
                    # esto no hace nada: lo decide el dueño de la PC, no el
                    # celular, por eso se revisa aquí y no del otro lado.
                    if self.control is not None:
                        self.control.atender(datos.decode("utf-8", "replace"))
                elif tipo == TIPO_TEXTO:
                    texto = datos.decode("utf-8", "replace")
                    if texto.startswith("HOLA|"):
                        self.nombre_cel = texto[5:]
        except (OSError, ConnectionError, struct.error):
            pass
        finally:
            self._soltar(c)

    def _escribir(self, c, tipo, datos):
        with self.candado_escritura:
            c.sendall(mensaje(tipo, datos))

    def _enviar(self, c):
        try:
            self._escribir(c, TIPO_TEXTO, ("HOLA|" + socket.gethostname()).encode("utf-8"))
            while True:
                with self.cond:
                    while self.cliente is c and self.pendiente is None:
                        self.cond.wait(1.0)
                    if self.cliente is not c:
                        return
                    datos = self.pendiente
                    self.en_camino += 1
                self._escribir(c, TIPO_JPEG, datos)
                self.enviados += 1
                with self.cond:
                    if self.pendiente is datos:
                        self.pendiente = None
        except OSError:
            self._soltar(c)

    def listo(self):
        with self.cond:
            return self.cliente is not None and self.pendiente is None and self.en_camino < MAX_EN_CAMINO

    def enviar(self, jpeg):
        with self.cond:
            if self.cliente is not None:
                self.pendiente = jpeg
                self.cond.notify_all()

    def desconectar(self):
        with self.cond:
            c = self.cliente
        if c is not None:
            self._soltar(c)


# --------------------------------------------------------------------------
class Captura:
    """Toma la cámara o la pantalla de la PC y la manda al celular."""

    def __init__(self, servidor):
        self.servidor = servidor
        self.fuente = "Nada"
        self.alto = 720
        self.calidad = 70
        self.vista_previa = None
        self.error = ""

    def iniciar(self):
        threading.Thread(target=self._bucle, daemon=True).start()

    def _bucle(self):
        cap = None
        actual = None
        pantalla = None
        ultima_pantalla = None
        while True:
            fuente = self.fuente
            if fuente != actual:
                if cap is not None:
                    cap.release()
                    cap = None
                actual = fuente
                self.error = ""
                if fuente.startswith("Cámara"):
                    indice = int(fuente.split()[1])
                    cap = cv2.VideoCapture(indice, cv2.CAP_DSHOW) if ES_WINDOWS else cv2.VideoCapture(indice)
                    # MJPG: casi todas las webcams USB solo dan 30 fps en HD así
                    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920 if self.alto > 720 else 1280)
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080 if self.alto > 720 else 720)
                    cap.set(cv2.CAP_PROP_FPS, 30)
                    if not cap.isOpened():
                        self.error = f"No encontré la {fuente.lower()}"
                elif fuente.startswith("Pantalla"):
                    if pantalla is not None:
                        pantalla.cerrar()
                    partes = fuente.split()
                    pantalla = CapturaPantalla(int(partes[1]) if len(partes) > 1 else 1)

            inicio = time.perf_counter()
            cuadro = None
            if fuente.startswith("Cámara") and cap is not None and cap.isOpened():
                ok, cuadro = cap.read()
                if not ok:
                    cuadro = None
                    self.error = "La cámara no entrega imagen (¿la usa otro programa?)"
            elif fuente.startswith("Pantalla") and pantalla is not None:
                # "Pantalla 2" = segundo monitor (puede ser uno virtual: tablet como 2º monitor)
                cuadro = pantalla.leer()
                if cuadro is False:  # la pantalla no cambió: se reusa el anterior
                    cuadro = ultima_pantalla
                elif cuadro is None:
                    self.error = f"No pude capturar la pantalla: {pantalla.error}"
                else:
                    ultima_pantalla = cuadro
                    self.error = ""

            if cuadro is None:
                self.vista_previa = None
                time.sleep(0.2 if fuente == "Nada" else 0.5)
                continue

            h, w = cuadro.shape[:2]
            if h > self.alto:
                cuadro = cv2.resize(cuadro, (int(w * self.alto / h), self.alto), interpolation=cv2.INTER_AREA)
            self.vista_previa = cuadro

            if self.servidor.listo():
                ok, jpeg = cv2.imencode(".jpg", cuadro, [cv2.IMWRITE_JPEG_QUALITY, int(self.calidad)])
                if ok:
                    self.servidor.enviar(jpeg.tobytes())

            # máximo ~30 cuadros por segundo
            resto = 1 / 30 - (time.perf_counter() - inicio)
            if resto > 0:
                time.sleep(resto)


# --------------------------------------------------------------------------
def adaptadores():
    nombres = []
    for nombre, direcciones in psutil.net_if_addrs().items():
        if "loopback" in nombre.lower() or nombre.lower() == "lo":
            continue
        ips = [d.address for d in direcciones if d.family == socket.AF_INET]
        nombres.append((nombre, ips))
    return nombres


def ips_de_la_pc():
    return [(n, ip) for n, ips in adaptadores() for ip in ips if not ip.startswith("169.254")]


def tiene_ip_cable():
    return any(ip == IP_CABLE for _, ip in ips_de_la_pc())


def ejecutar_como_admin(lineas):
    """Corre comandos de netsh con permiso de administrador (sale la ventana de Windows)."""
    if not ES_WINDOWS:
        return False
    comando = " & ".join(lineas)
    r = ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", "/c " + comando, None, 0)
    return r > 32


def existe_regla_firewall():
    if not ES_WINDOWS:
        return True
    try:
        r = subprocess.run(["netsh", "advfirewall", "firewall", "show", "rule", f"name={NOMBRE_REGLA}"],
                           capture_output=True, creationflags=0x08000000, timeout=5)
        return r.returncode == 0
    except Exception:  # noqa: BLE001
        return True


# --------------------------------------------------------------------------
class VentanaNodos:
    """Consola de pantallas: a cada nodo se le elige qué mostrar."""

    def __init__(self, raiz, descubridor):
        self.d = descubridor
        self.ventana = tk.Toplevel(raiz)
        self.ventana.title("Pantallas HDMI — nodos Puente Video")
        self.ventana.geometry("760x420")
        self.ventana.configure(bg="#102027")
        self.filas = {}

        arriba = tk.Frame(self.ventana, bg="#102027")
        arriba.pack(fill="x", padx=10, pady=8)
        ttk.Label(arriba, text="Los nodos aparecen solos al conectarlos al switch. "
                               "Para usar uno desde el celular, déjalo en «Nada».",
                  wraplength=700).pack(anchor="w")
        fila = tk.Frame(arriba, bg="#102027")
        fila.pack(fill="x", pady=(6, 0))
        ttk.Label(fila, text="Agregar por IP:").pack(side="left")
        self.var_ip = tk.StringVar()
        ttk.Entry(fila, textvariable=self.var_ip, width=16).pack(side="left", padx=4)
        tk.Button(fila, text="Agregar", command=self.agregar, bg="#37474F", fg="white",
                  relief="flat").pack(side="left")
        tk.Button(fila, text="Identificar todas", command=self.identificar_todas, bg="#1E88E5",
                  fg="white", relief="flat").pack(side="left", padx=10)
        tk.Button(fila, text="Todas en «Nada»", command=self.todas_nada, bg="#37474F", fg="white",
                  relief="flat").pack(side="left")

        self.tabla = tk.Frame(self.ventana, bg="#102027")
        self.tabla.pack(fill="both", expand=True, padx=10, pady=4)
        self.lbl_vacio = ttk.Label(self.tabla, text="Buscando nodos en la red…")
        self.lbl_vacio.pack(anchor="w")
        self.refrescar()

    def existe(self):
        try:
            return bool(self.ventana.winfo_exists())
        except tk.TclError:
            return False

    def agregar(self):
        ip = self.var_ip.get().strip()
        if ip:
            self.d.agregar(ip)
            self.var_ip.set("")

    def identificar_todas(self):
        for n in self.d.ordenados():
            if n.fuente == "Nada":
                n.fuente = "Patrón de prueba"
                if self._clave(n) in self.filas:
                    self.filas[self._clave(n)]["var"].set(n.fuente)
            n.identificar()

    def todas_nada(self):
        for n in self.d.ordenados():
            n.fuente = "Nada"
            if self._clave(n) in self.filas:
                self.filas[self._clave(n)]["var"].set("Nada")

    def _fila(self, nodo):
        f = tk.Frame(self.tabla, bg="#1C313A")
        f.pack(fill="x", pady=3)
        lbl = ttk.Label(f, text="", width=46, background="#1C313A")
        lbl.pack(side="left", padx=6, pady=6)
        var = tk.StringVar(value=nodo.fuente)
        cb = ttk.Combobox(f, textvariable=var, values=FUENTES, state="readonly", width=20)
        cb.pack(side="left", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda e, n=nodo, v=var: setattr(n, "fuente", v.get()))
        tk.Button(f, text="Identificar", command=nodo.identificar, bg="#37474F", fg="white",
                  relief="flat").pack(side="left", padx=4)
        self.filas[self._clave(nodo)] = {"marco": f, "lbl": lbl, "var": var}

    @staticmethod
    def _clave(nodo):
        return f"{nodo.ip}:{nodo.puerto}"

    def refrescar(self):
        if not self.existe():
            return
        nodos = self.d.ordenados()
        if nodos:
            self.lbl_vacio.pack_forget()
        elif self.d.error:
            self.lbl_vacio.configure(text=self.d.error)
        for n in nodos:
            if self._clave(n) not in self.filas:
                self._fila(n)
            vivo = time.time() - n.visto < 4
            texto = f"Nodo {n.id or '?'} · {n.ip}" + (f":{n.puerto}" if n.puerto != 5000 else "") + f" · {n.ancho}x{n.alto}"
            if n.fuente != "Nada":
                texto += f"\n{n.estado}, {n.fps} fps"
            elif not vivo:
                texto += "\nsin anuncio (¿apagado?)"
            else:
                texto += "\nlibre (el celular puede usarlo)"
            self.filas[self._clave(n)]["lbl"].configure(text=texto)
        self.ventana.after(1000, self.refrescar)


class VentanaMonitor:
    """Segundo monitor: elegir qué pantalla va al celular y poder usarla.

    La parte de *mandar* una pantalla cualquiera ya existía; lo que esta
    ventana agrega es lo que faltaba alrededor:

    * decir con claridad si hoy se puede extender o solo copiar, que depende
      de cuántas pantallas conoce Windows y no de este programa;
    * explicar las tres formas de conseguir esa segunda pantalla, ordenadas
      por riesgo y **sin instalar nada solo** (ver `monitor_virtual.py`);
    * encender el control remoto, que es lo que de verdad convierte una
      imagen en un monitor: sin poder tocarlo, para usar lo que hay en esa
      pantalla habría que volver al ratón de la PC.
    """

    def __init__(self, raiz, app):
        self.app = app
        self.ventana = tk.Toplevel(raiz)
        self.ventana.title("Segundo monitor — Puente Video")
        self.ventana.geometry("640x620")
        self.ventana.configure(bg="#102027")

        arriba = tk.Frame(self.ventana, bg="#102027")
        arriba.pack(fill="x", padx=12, pady=10)
        self.lbl_estado = ttk.Label(arriba, text="", wraplength=600, justify="left")
        self.lbl_estado.pack(anchor="w")

        self.marco_pantallas = ttk.LabelFrame(self.ventana, text="Qué pantalla le mando", padding=8)
        self.marco_pantallas.pack(fill="x", padx=12, pady=(0, 8))

        marco_control = ttk.LabelFrame(self.ventana, text="Usarlo como monitor", padding=8)
        marco_control.pack(fill="x", padx=12, pady=(0, 8))
        self.var_control = tk.BooleanVar(value=False)
        ttk.Checkbutton(marco_control,
                        text="Dejar que el celular mueva el cursor y haga clic",
                        variable=self.var_control,
                        command=self.aplicar_control).pack(anchor="w")
        ttk.Label(marco_control, wraplength=580, justify="left", text=(
            "Toca para mover y dar clic, mantén apretado para clic derecho, arrastra "
            "con dos dedos para la rueda. Arranca apagado a propósito: esto deja que "
            "el celular use tu PC, y eso lo decides tú, no la conexión.")).pack(anchor="w", pady=(4, 0))

        marco_como = ttk.LabelFrame(self.ventana, text="Cómo conseguir una segunda pantalla", padding=8)
        marco_como.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        for paso in monitor_virtual.pasos_para_conseguir_pantalla():
            caja = tk.Frame(marco_como, bg="#15323C", highlightthickness=0)
            caja.pack(fill="x", pady=4)
            ttk.Label(caja, text=paso["titulo"], font=("", 9, "bold"),
                      wraplength=560, justify="left").pack(anchor="w", padx=8, pady=(6, 2))
            ttk.Label(caja, text=paso["cuerpo"], wraplength=560,
                      justify="left").pack(anchor="w", padx=8, pady=(0, 6))
            if paso["accion"]:
                tk.Button(caja, text="Instalarlo ahora", command=self.instalar_virtual,
                          bg="#00838F", fg="white", relief="flat").pack(anchor="w", padx=8, pady=(0, 8))

        self.refrescar()

    def existe(self):
        try:
            return bool(tk.Toplevel.winfo_exists(self.ventana))
        except tk.TclError:
            return False

    def refrescar(self):
        if not self.existe():
            return
        datos = monitor_virtual.revisar()
        texto = datos["consejo"]
        if datos["cuantas"]:
            texto += "\n\nPantallas que ve Windows:"
            for m in datos["pantallas"]:
                cual = "principal" if m["principal"] else f"en ({m['x']}, {m['y']})"
                texto += f"\n  Pantalla {m['numero']} · {m['ancho']}×{m['alto']} · {cual}"
        self.lbl_estado.configure(text=texto)

        # Los botones de pantalla se vuelven a dibujar porque la lista cambia
        # sola cuando se conecta o se crea un monitor, y el usuario no debería
        # tener que cerrar y abrir la ventana para enterarse.
        for hijo in self.marco_pantallas.winfo_children():
            hijo.destroy()
        if not datos["pantallas"]:
            ttk.Label(self.marco_pantallas,
                      text="No pude leer las pantallas.").pack(anchor="w")
        for m in datos["pantallas"]:
            etiqueta = f"Pantalla {m['numero']} — {m['ancho']}×{m['alto']}"
            if m["principal"]:
                etiqueta += " (la principal)"
            ttk.Radiobutton(self.marco_pantallas, text=etiqueta,
                            variable=self.app.var_fuente,
                            value=f"Pantalla {m['numero']}",
                            command=self.elegir_pantalla).pack(anchor="w")
        self.ventana.after(2000, self.refrescar)

    def elegir_pantalla(self):
        self.app.aplicar_envio()
        self.aplicar_control()

    def aplicar_control(self):
        """Apunta el control al monitor que se está mandando, y lo enciende o apaga.

        Apuntarlo importa: el control convierte la proporción del dedo a un
        punto de **ese** monitor. Si se cambia de pantalla y no se vuelve a
        apuntar, los toques siguen cayendo en la pantalla anterior.
        """
        control = self.app.control
        fuente = self.app.var_fuente.get()
        elegido = None
        if fuente.startswith("Pantalla"):
            try:
                numero = int(fuente.split()[1])
            except (IndexError, ValueError):
                numero = None
            for m in monitor_virtual.pantallas():
                if m["numero"] == numero:
                    elegido = m
        control.apuntar_a(elegido)
        control.encendido = bool(self.var_control.get()) and elegido is not None
        if self.var_control.get() and elegido is None:
            messagebox.showinfo(
                "Segundo monitor",
                "Para que el celular mueva el cursor hay que estarle mandando una "
                "pantalla, no la cámara.", parent=self.ventana)
            self.var_control.set(False)

    def instalar_virtual(self):
        datos = monitor_virtual.revisar()
        if not datos["winget"]:
            messagebox.showinfo(
                "Segundo monitor",
                "No encontré winget en esta PC, así que no puedo lanzarlo por ti.\n\n"
                "Puedes instalarlo desde la Microsoft Store («Instalador de aplicaciones») "
                "y volver, o seguir las instrucciones del proyecto a mano.",
                parent=self.ventana)
            return
        seguir = messagebox.askyesno(
            "Instalar el controlador de pantalla virtual",
            "Se va a correr este comando, y Windows te va a pedir permiso de "
            f"administrador:\n\n{datos['comando']}\n\n"
            "Antes de aceptar, léelo con calma: es un controlador de pantalla. "
            "Si algo sale mal, el síntoma es que la pantalla se queda en negro, y "
            "se arregla entrando en modo seguro y desinstalándolo desde el "
            "Administrador de dispositivos.\n\n"
            "Si esta es tu única computadora, el adaptador HDMI falso de la primera "
            "opción hace lo mismo sin tocar Windows.\n\n¿Lo corro?",
            parent=self.ventana)
        if not seguir:
            return
        try:
            # En una ventana visible a propósito: así se ve lo que pasa y, si
            # falla, el error queda a la vista en lugar de perderse.
            subprocess.Popen(["cmd", "/k", datos["comando"]])
        except OSError as e:
            messagebox.showerror("Segundo monitor", str(e), parent=self.ventana)
            return
        messagebox.showinfo(
            "Segundo monitor",
            "Se abrió una ventana con la instalación. Cuando termine, reinicia la PC "
            "y vuelve aquí: la pantalla nueva debe aparecer sola en la lista.\n\n"
            "Después, en la configuración de pantalla de Windows, ponla en «Extender».",
            parent=self.ventana)


def _es_tunel_usb(direccion):
    """True si el celular llegó por el túnel de adb (se ve como la propia PC)."""
    try:
        crudo = ipaddress.ip_address((direccion or "").strip())
    except ValueError:
        return False
    ip = _como_ipv4(str(crudo))
    return crudo.is_loopback or (ip is not None and ip.is_loopback)


def _como_ipv4(texto):
    """La dirección como IPv4, o None si no se puede.

    Hace falta porque la PC escucha en doble pila, así que un celular que llega
    por IPv4 aparece como `::ffff:10.148.137.212`: un IPv6 que envuelve un
    IPv4. Comparar eso contra un IPv4 de frente da siempre «redes distintas»,
    porque los primeros bytes de un IPv6 son ceros y no los octetos. Es un
    aviso falso de los peores: aparece justo cuando **sí** hay conexión, así
    que manda a desconectar el cable a quien ya está conectado.
    """
    try:
        dir_ip = ipaddress.ip_address(texto.strip())
    except ValueError:
        return None
    if dir_ip.version == 6:
        dir_ip = getattr(dir_ip, "ipv4_mapped", None)
    return dir_ip


class VentanaArchivos:
    """Panel de archivos: la lista de lo que va y viene, y de dónde sacarlos.

    A propósito **no** es un explorador del celular. Para navegar todo el
    almacenamiento del teléfono desde la PC, Android pide el permiso
    `MANAGE_EXTERNAL_STORAGE`, que Google casi no aprueba y que obligaría a
    repartir la app a mano para siempre. Mandar y recibir, en cambio, no pide
    ningún permiso: para mandar se usa el selector del sistema y para recibir
    la carpeta de la propia app. Así que el panel es una lista de
    transferencias con un botón de mandar, que es el 95 % de lo que uno quiere
    y no cuesta la tienda.
    """

    def __init__(self, raiz, servidor_archivos, al_anotar):
        self.sa = servidor_archivos
        self.anotar = al_anotar
        self.ventana = tk.Toplevel(raiz)
        self.ventana.title("Archivos — Puente Video")
        self.ventana.geometry("680x460")
        self.ventana.configure(bg="#102027")

        arriba = tk.Frame(self.ventana, bg="#102027")
        arriba.pack(fill="x", padx=10, pady=8)
        self.lbl_estado = ttk.Label(arriba, text="", wraplength=640, justify="left")
        self.lbl_estado.pack(anchor="w")

        fila = tk.Frame(arriba, bg="#102027")
        fila.pack(fill="x", pady=(8, 0))
        tk.Button(fila, text="Mandar archivos al celular…", command=self.elegir,
                  bg="#00838F", fg="white", relief="flat").pack(side="left")
        tk.Button(fila, text="Abrir la carpeta de recibidos", command=self.abrir_carpeta,
                  bg="#37474F", fg="white", relief="flat").pack(side="left", padx=6)
        tk.Button(fila, text="Quitar las terminadas", command=self.limpiar,
                  bg="#37474F", fg="white", relief="flat").pack(side="left")

        self.zona = tk.Label(self.ventana, text="…o arrastra archivos aquí",
                             bg="#15323C", fg="#80DEEA", relief="flat", height=3)
        self.zona.pack(fill="x", padx=10, pady=(6, 0))
        self._preparar_arrastre()

        self.lista = tk.Listbox(self.ventana, bg="#15323C", fg="#E0F7FA",
                                selectbackground="#00838F", relief="flat",
                                highlightthickness=0, activestyle="none")
        self.lista.pack(fill="both", expand=True, padx=10, pady=10)

        self.refrescar()

    def existe(self):
        try:
            return bool(tk.Toplevel.winfo_exists(self.ventana))
        except tk.TclError:
            return False

    def _preparar_arrastre(self):
        """Arrastrar y soltar, si el Tcl de esta máquina lo trae.

        tkdnd no viene con Python, así que el arrastre es un extra: si no está,
        el botón de «Mandar archivos» hace lo mismo y el texto de la zona lo
        dice en lugar de prometer algo que no funciona.
        """
        try:
            self.ventana.tk.call("package", "require", "tkdnd")
            self.ventana.tk.call("tkdnd::drop_target", "register", self.zona, ("DND_Files",))
            self.zona.bind("<<Drop>>", self._al_soltar)
        except tk.TclError:
            self.zona.configure(text="Usa el botón «Mandar archivos al celular…»",
                                fg="#90A4AE")

    def _al_soltar(self, evento):
        # Tcl entrega la lista como una cadena con llaves alrededor de los
        # nombres que llevan espacios; splitlist la deshace bien.
        try:
            rutas = list(self.ventana.tk.splitlist(evento.data))
        except tk.TclError:
            return
        self._mandar(rutas)

    def elegir(self):
        rutas = filedialog.askopenfilenames(
            title="Archivos para mandar al celular",
            parent=self.ventana)
        if rutas:
            self._mandar(list(rutas))

    def _mandar(self, rutas):
        if not self.sa.conectado():
            messagebox.showinfo(
                "Archivos",
                "Todavía no hay celular conectado para archivos.\n\n"
                "Abre Puente Video en el celular y espera a que diga «Conectado». "
                "Los archivos van por el mismo cable, en el puerto "
                f"{self.sa.puerto}.",
                parent=self.ventana)
            return
        self.sa.mandar(rutas)
        self.refrescar()

    def abrir_carpeta(self):
        carpeta = self.sa.carpeta
        try:
            os.makedirs(carpeta, exist_ok=True)
        except OSError as e:
            messagebox.showerror("Archivos", str(e), parent=self.ventana)
            return
        try:
            if ES_WINDOWS:
                os.startfile(carpeta)  # noqa: S606
            else:
                subprocess.Popen(["xdg-open", carpeta])
        except OSError as e:
            messagebox.showinfo("Archivos", f"La carpeta es:\n{carpeta}\n\n({e})",
                                parent=self.ventana)

    def limpiar(self):
        if self.sa.enlace is not None:
            self.sa.enlace.limpiar_terminadas()
        self.refrescar()

    def refrescar(self):
        if not self.existe():
            return
        if self.sa.error:
            texto = self.sa.error
        elif self.sa.conectado():
            texto = ("Celular conectado para archivos. Arrastra archivos aquí o usa el botón; "
                     "del celular también se pueden mandar.")
        else:
            texto = (f"Esperando al celular en el puerto {self.sa.puerto}. "
                     f"Se conecta solo en cuanto la app encuentre a la PC.")
        texto += f"\nLo que llega se guarda en: {self.sa.carpeta}"
        self.lbl_estado.configure(text=texto)

        copias = self.sa.enlace.lista() if self.sa.enlace is not None else []
        # Se vuelve a dibujar la lista completa, pero conservando qué renglón
        # estaba seleccionado: son pocas líneas y así no hay que llevar cuenta
        # de qué cambió.
        seleccion = self.lista.curselection()
        self.lista.delete(0, "end")
        for c in reversed(copias):
            self.lista.insert("end", c.resumen())
        if seleccion and seleccion[0] < self.lista.size():
            self.lista.selection_set(seleccion[0])
        self.ventana.after(400, self.refrescar)


# --------------------------------------------------------------------------
class App:
    def __init__(self):
        self.servidor = Servidor()
        self.captura = Captura(self.servidor)
        self.dhcp = ServidorDHCP(IP_CABLE, MASCARA, registro=self.anotar)
        self.archivos = ServidorArchivos(carpeta_recibidos_por_omision(),
                                         registro=self.anotar)
        self.ventana_archivos = None
        self.control = ControlRemoto()
        self.tunel = TunelUSB(registro=self.anotar)
        self.servidor.control = self.control
        self.ventana_monitor = None
        self.registro = []
        self.version_dibujada = -1
        self.foto_video = None
        self.foto_previa = None
        self.ultima_previa = 0
        self.pantalla_completa = False
        self.t_fps = time.time()
        self.cuenta_rec = 0
        self.cuenta_env = 0
        self.fps_rec = 0
        self.fps_env = 0

        self.raiz = tk.Tk()
        self.raiz.title("Puente Video — PC ⇄ Celular")
        self.raiz.geometry("1220x740")
        self.raiz.minsize(900, 560)
        self.raiz.configure(bg="#102027")
        self.raiz.protocol("WM_DELETE_WINDOW", self.cerrar)
        icono = os.path.join(getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__))), "icono.ico")
        if ES_WINDOWS and os.path.exists(icono):
            try:
                self.raiz.iconbitmap(icono)
            except tk.TclError:
                pass
        self.raiz.bind("<F11>", lambda e: self.alternar_pantalla_completa())
        self.raiz.bind("<Escape>", lambda e: self.salir_pantalla_completa())

        estilo = ttk.Style()
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass
        estilo.configure("TLabelframe", background="#102027", foreground="#B2EBF2")
        estilo.configure("TLabelframe.Label", background="#102027", foreground="#80DEEA",
                         font=("Segoe UI", 10, "bold"))
        estilo.configure("TLabel", background="#102027", foreground="#ECEFF1")
        estilo.configure("TCheckbutton", background="#102027", foreground="#ECEFF1")

        self.pantalla = PantallaCompartida()
        self.descubridor = Descubridor({
            "pantalla": self.pantalla.obtener,
            "celular_sale": lambda: self.captura.vista_previa,
            "celular_entra": lambda: self.servidor.ultimo_cuadro,
        })
        self.ventana_nodos = None

        self.anunciante = Anunciante(PUERTO)
        self.ventana_qr = None
        # al arrancar, abre el firewall en silencio; si no hay permisos, ni modo
        threading.Thread(target=abrir_firewall, daemon=True).start()

        self._construir()
        self.servidor.iniciar()
        self.archivos.iniciar()
        self.captura.iniciar()
        self.anunciante.iniciar()
        if self.var_dhcp.get():
            self.dhcp.iniciar()
        self.raiz.after(30, self.refrescar_video)
        self.raiz.after(500, self.refrescar_estado)

    # ---------------------------------------------------------------- interfaz
    def _construir(self):
        self.marco_video = tk.Frame(self.raiz, bg="black")
        self.marco_video.pack(side="left", fill="both", expand=True)
        self.marco_video.pack_propagate(False)  # el video no debe empujar al panel
        self.etiqueta_video = tk.Label(
            self.marco_video, bg="black", fg="#78909C", font=("Segoe UI", 13),
            text="Aquí aparece la cámara del celular.\n\n"
                 "1. Conecta el cable Ethernet entre el celular y la PC.\n"
                 "2. La primera vez, en «Cable Ethernet» presiona «Configurar».\n"
                 "3. En el celular abre Puente Video y toca «Conectar».\n\n"
                 "Doble clic o F11: pantalla completa")
        self.etiqueta_video.pack(fill="both", expand=True)
        self.etiqueta_video.bind("<Double-Button-1>", lambda e: self.alternar_pantalla_completa())

        # El panel de la derecha va dentro de un área con barra de desplazamiento:
        # así todo (incluido «Archivos» y «Arreglar la conexión») se alcanza
        # aunque la ventana sea más baja que el contenido.
        self.contenedor = tk.Frame(self.raiz, bg="#102027", width=340)
        self.contenedor.pack(side="right", fill="y", padx=8, pady=8)
        self.contenedor.pack_propagate(False)
        self.canvas_lat = tk.Canvas(self.contenedor, bg="#102027", highlightthickness=0, width=322)
        barra = tk.Scrollbar(self.contenedor, orient="vertical", command=self.canvas_lat.yview)
        self.canvas_lat.configure(yscrollcommand=barra.set)
        barra.pack(side="right", fill="y")
        self.canvas_lat.pack(side="left", fill="both", expand=True)
        self.lateral = tk.Frame(self.canvas_lat, bg="#102027")
        ventana_lat = self.canvas_lat.create_window((0, 0), window=self.lateral, anchor="nw")

        def ajustar_lateral(_e=None):
            self.canvas_lat.configure(scrollregion=self.canvas_lat.bbox("all"))
            self.canvas_lat.itemconfigure(ventana_lat, width=self.canvas_lat.winfo_width())

        self.lateral.bind("<Configure>", ajustar_lateral)
        self.canvas_lat.bind("<Configure>", ajustar_lateral)

        def rueda_lateral(e):
            self.canvas_lat.yview_scroll(int(-e.delta / 120), "units")

        self.canvas_lat.bind("<Enter>", lambda e: self.raiz.bind_all("<MouseWheel>", rueda_lateral))
        self.canvas_lat.bind("<Leave>", lambda e: self.raiz.unbind_all("<MouseWheel>"))

        # Conexión
        m = ttk.LabelFrame(self.lateral, text="Conexión", padding=8)
        m.pack(fill="x", pady=(0, 8))
        self.lbl_estado = ttk.Label(m, text="", wraplength=285, justify="left")
        self.lbl_estado.pack(anchor="w")
        fila = tk.Frame(m, bg="#102027")
        fila.pack(anchor="w", pady=(6, 0))
        tk.Button(fila, text="Desconectar celular", command=self.servidor.desconectar,
                  bg="#37474F", fg="white", relief="flat").pack(side="left")
        tk.Button(fila, text="Ver código QR", command=self.mostrar_qr,
                  bg="#7E57C2", fg="white", relief="flat").pack(side="left", padx=(6, 0))

        # Lo que mando
        m = ttk.LabelFrame(self.lateral, text="Lo que mando al celular", padding=8)
        m.pack(fill="x", pady=(0, 8))
        fuentes = ["Nada", "Cámara 0", "Cámara 1", "Cámara 2", "Cámara 3"]
        fuentes += [f"Pantalla {i}" for i in range(1, cuantas_pantallas() + 1)]
        self.var_fuente = tk.StringVar(value="Pantalla 1")
        fila = tk.Frame(m, bg="#102027")
        fila.pack(fill="x")
        ttk.Label(fila, text="Fuente:").pack(side="left")
        cb = ttk.Combobox(fila, textvariable=self.var_fuente, values=fuentes, state="readonly", width=12)
        cb.pack(side="left", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda e: self.aplicar_envio())
        self.var_res = tk.StringVar(value="720p")
        cb = ttk.Combobox(fila, textvariable=self.var_res, values=list(RESOLUCIONES), state="readonly", width=6)
        cb.pack(side="left", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda e: self.aplicar_envio())

        fila = tk.Frame(m, bg="#102027")
        fila.pack(fill="x", pady=(6, 0))
        ttk.Label(fila, text="Calidad:").pack(side="left")
        self.var_calidad = tk.IntVar(value=70)
        tk.Scale(fila, from_=30, to=95, orient="horizontal", variable=self.var_calidad, showvalue=True,
                 bg="#102027", fg="white", highlightthickness=0, troughcolor="#37474F",
                 command=lambda v: setattr(self.captura, "calidad", self.var_calidad.get())).pack(side="left", fill="x", expand=True)

        caja = tk.Frame(m, bg="black", width=310, height=175)
        caja.pack(pady=(6, 0))
        caja.pack_propagate(False)
        self.etiqueta_previa = tk.Label(caja, bg="black", fg="#78909C", text="(sin video)")
        self.etiqueta_previa.pack(fill="both", expand=True)
        self.lbl_error_envio = ttk.Label(m, text="", foreground="#FFAB91", wraplength=285)
        self.lbl_error_envio.pack(anchor="w")

        # Cable Ethernet
        m = ttk.LabelFrame(self.lateral, text="Cable Ethernet", padding=8)
        m.pack(fill="x", pady=(0, 8))
        lista = adaptadores()
        nombres = [n for n, _ in lista]

        def puntos(item):
            # Preferir el adaptador del cable directo: Ethernet sin IP o con 169.254.x
            # (no el que va al router, que ya tiene IP de la casa).
            nombre, ips = item
            n = nombre.lower()
            p = 0
            if "ethernet" in n and "vethernet" not in n:
                p += 2
            # Linux (Raspberry Pi y demás): eth0, end0, enp1s0, enx… (USB)
            if n.startswith(("eth", "end", "enp", "enx", "usb")):
                p += 2
            if n.startswith(("lo", "ifb", "docker", "veth", "br-", "virbr", "tun", "tap")):
                p -= 5
            if any(x in n for x in ("wi-fi", "wifi", "wlan", "bluetooth", "vmware", "virtual", "vpn")):
                p -= 5
            if IP_CABLE in ips:
                p += 10
            elif not ips or all(ip.startswith("169.254") for ip in ips):
                p += 3
            return p

        anclaje = set(adaptadores_de_anclaje())

        def puntos_con_usb(item):
            # El celular en anclaje USB es justo el adaptador que se busca.
            return puntos(item) + (8 if item[0] in anclaje else 0)

        sugerido = max(lista, key=puntos_con_usb)[0] if lista else ""
        self.var_adaptador = tk.StringVar(value=sugerido)
        fila = tk.Frame(m, bg="#102027")
        fila.pack(fill="x")
        ttk.Label(fila, text="Adaptador:").pack(side="left")
        ttk.Combobox(fila, textvariable=self.var_adaptador, values=nombres, state="readonly",
                     width=24).pack(side="left", padx=4)
        tk.Button(m, text="Arreglar la conexión", command=self.arreglar_conexion,
                  bg="#43A047", fg="white", relief="flat",
                  font=("Segoe UI", 10, "bold")).pack(fill="x", pady=(8, 2))
        ttk.Label(m, text="Déjale al celular repartir las IP. Esto quita cualquier IP fija "
                          "que estorbe y abre el firewall.",
                  wraplength=285, justify="left", foreground="#90A4AE").pack(anchor="w")
        fila = tk.Frame(m, bg="#102027")
        fila.pack(fill="x", pady=(6, 0))
        tk.Button(fila, text=f"Configurar ({IP_CABLE})", command=self.configurar_cable,
                  bg="#37474F", fg="white", relief="flat").pack(side="left")
        tk.Button(fila, text="Automático", command=self.regresar_automatico,
                  bg="#37474F", fg="white", relief="flat").pack(side="left", padx=6)
        self.var_dhcp = tk.BooleanVar(value=False)
        ttk.Checkbutton(m, text="Darle IP al celular (DHCP)", variable=self.var_dhcp,
                        command=self.alternar_dhcp).pack(anchor="w", pady=(6, 0))
        self.lbl_cable = ttk.Label(m, text="", wraplength=285, justify="left")
        self.lbl_cable.pack(anchor="w")

        # Cable USB: el cable original del celular, sin adaptador Ethernet
        m = ttk.LabelFrame(self.lateral, text="Cable USB del celular", padding=8)
        m.pack(fill="x", pady=(0, 8))
        ttk.Label(m, text="Sin adaptador Ethernet: con el cable de carga. Dos formas:",
                  wraplength=285, justify="left").pack(anchor="w")
        self.boton_usb = tk.Button(m, text="1. Conectar por USB (depuración USB)", command=self.conectar_usb,
                                   bg="#43A047", fg="white", relief="flat", font=("Segoe UI", 10, "bold"))
        self.boton_usb.pack(fill="x", pady=(6, 2))
        ttk.Label(m, text="En el celular: Opciones de desarrollador › Depuración USB. "
                          "La primera vez acepta el aviso en el celular. No usa IPs ni datos.",
                  wraplength=285, justify="left", foreground="#90A4AE").pack(anchor="w")
        self.lbl_usb = ttk.Label(m, text="", wraplength=285, justify="left")
        self.lbl_usb.pack(anchor="w", pady=(2, 0))
        tk.Button(m, text="2. Anclaje USB: que no gaste mis datos", command=self.no_gastar_datos,
                  bg="#37474F", fg="white", relief="flat").pack(fill="x", pady=(8, 2))
        ttk.Label(m, text="En el celular: Ajustes › Compartir conexión › Anclaje USB. "
                          "Funciona como el cable Ethernet. Este botón hace que Windows "
                          "salga a internet por tu Wi‑Fi y no por los datos del celular.",
                  wraplength=285, justify="left", foreground="#90A4AE").pack(anchor="w")

        # Extras
        fila = tk.Frame(self.lateral, bg="#102027")
        fila.pack(fill="x")
        tk.Button(fila, text="Pantalla completa (F11)", command=self.alternar_pantalla_completa,
                  bg="#37474F", fg="white", relief="flat").pack(side="left")
        tk.Button(fila, text="Guardar foto", command=self.guardar_foto,
                  bg="#37474F", fg="white", relief="flat").pack(side="left", padx=6)
        tk.Button(self.lateral, text="Pantallas HDMI (nodos)…", command=self.abrir_nodos,
                  bg="#00838F", fg="white", relief="flat").pack(fill="x", pady=(8, 0))
        tk.Button(self.lateral, text="Archivos (mandar y recibir)…", command=self.abrir_archivos,
                  bg="#00838F", fg="white", relief="flat").pack(fill="x", pady=(6, 0))
        tk.Button(self.lateral, text="Segundo monitor…", command=self.abrir_monitor,
                  bg="#00838F", fg="white", relief="flat").pack(fill="x", pady=(6, 0))

        self.aplicar_envio()

    def mostrar_qr(self):
        """Ventana con el QR grande, para que el celular lo lea y conecte."""
        if getattr(self, "ventana_qr", None) is not None and tk.Toplevel.winfo_exists(self.ventana_qr):
            self.ventana_qr.lift()
            return
        ip = ip_recomendada()
        if not ip:
            messagebox.showinfo("Código QR", "Todavía no tengo ninguna dirección de red.")
            return
        v = tk.Toplevel(self.raiz, bg="#102027")
        self.ventana_qr = v
        v.title("Conectar el celular")
        v.resizable(False, False)
        tk.Label(v, text="Apunta la cámara del celular aquí", bg="#102027", fg="white",
                 font=("Segoe UI", 13, "bold")).pack(padx=24, pady=(20, 4))
        tk.Label(v, text="En la app, toca «Escanear código»", bg="#102027",
                 fg="#90A4AE", font=("Segoe UI", 10)).pack(pady=(0, 14))
        imagen = imagen_qr(texto_de_conexion(ip, PUERTO), 320)
        if imagen is not None:
            foto = ImageTk.PhotoImage(Image.fromarray(imagen))
            etiqueta = tk.Label(v, image=foto, bg="white", bd=0)
            etiqueta.imagen = foto  # que no se lo lleve el recolector
            etiqueta.pack(padx=24)
        else:
            tk.Label(v, text="(instala «qrcode» para ver el código)", bg="#102027",
                     fg="#FFAB91").pack(padx=24, pady=20)
        tk.Label(v, text=f"{ip}:{PUERTO}", bg="#102027", fg="#26C6DA",
                 font=("Consolas", 18, "bold")).pack(pady=(14, 4))
        tk.Label(v, text="o escribe esa dirección en el celular", bg="#102027",
                 fg="#78909C", font=("Segoe UI", 9)).pack(pady=(0, 20))

    def arreglar_conexion(self):
        """Deja el adaptador del cable en automático y abre el firewall."""
        info = revisar()
        nombre = info.get("adaptador")
        if not nombre:
            messagebox.showinfo("Arreglar la conexión", info.get("aviso", "No encontré el cable."))
            return
        abrir_firewall()
        ok, detalle = dejar_en_automatico(nombre)
        if ok:
            messagebox.showinfo("Arreglar la conexión",
                                f"Listo. «{nombre}» quedó en automático.\n\n"
                                "Desconecta y vuelve a conectar el cable al celular.")
        else:
            messagebox.showwarning("Arreglar la conexión",
                                   f"No pude cambiar «{nombre}»: {detalle}\n\n"
                                   "Abre Puente Video como administrador e inténtalo otra vez.")

    def abrir_monitor(self):
        if self.ventana_monitor is not None and self.ventana_monitor.existe():
            self.ventana_monitor.ventana.lift()
            return
        self.ventana_monitor = VentanaMonitor(self.raiz, self)

    def abrir_archivos(self):
        if self.ventana_archivos is not None and self.ventana_archivos.existe():
            self.ventana_archivos.ventana.lift()
            return
        self.ventana_archivos = VentanaArchivos(self.raiz, self.archivos, self.anotar)

    def abrir_nodos(self):
        if self.ventana_nodos is not None and self.ventana_nodos.existe():
            self.ventana_nodos.ventana.lift()
            return
        self.ventana_nodos = VentanaNodos(self.raiz, self.descubridor)

    def anotar(self, texto):
        self.registro.append(time.strftime("%H:%M:%S ") + texto)
        self.registro = self.registro[-4:]

    def aplicar_envio(self):
        alto = RESOLUCIONES.get(self.var_res.get(), 720)
        cambio_res = alto != self.captura.alto
        self.captura.alto = alto
        self.captura.calidad = self.var_calidad.get()
        fuente = self.var_fuente.get()
        if self.captura.fuente != fuente:
            self.captura.fuente = fuente
        elif cambio_res and fuente.startswith("Cámara"):
            # reabrir la cámara para pedirle la nueva resolución
            self.captura.fuente = "Nada"
            self.raiz.after(400, lambda: setattr(self.captura, "fuente", fuente))

    def alternar_dhcp(self):
        if self.var_dhcp.get():
            self.dhcp.iniciar()
        else:
            self.dhcp.detener()

    def configurar_cable(self):
        nombre = self.var_adaptador.get()
        if not nombre:
            return
        ips = dict(adaptadores()).get(nombre, [])
        otras = [ip for ip in ips if ip != IP_CABLE and not ip.startswith("169.254")]
        if otras and not messagebox.askyesno(
                "Puente Video",
                f"«{nombre}» ya tiene la IP {', '.join(otras)}.\n"
                "Si es la conexión a tu router o módem te vas a quedar sin internet por ese cable.\n\n"
                "¿Seguro que es el puerto donde está conectado el celular?"):
            return
        programa = sys.executable
        lineas = [
            f'netsh interface ipv4 set address name="{nombre}" source=static address={IP_CABLE} mask={MASCARA}',
            f'netsh advfirewall firewall delete rule name="{NOMBRE_REGLA}"',
            f'netsh advfirewall firewall add rule name="{NOMBRE_REGLA}" dir=in action=allow '
            f'program="{programa}" enable=yes profile=any',
            # Reglas por puerto: siguen sirviendo aunque muevas o renombres el .exe
            f'netsh advfirewall firewall add rule name="{NOMBRE_REGLA}" dir=in action=allow '
            f'protocol=UDP localport=67 enable=yes profile=any',
            f'netsh advfirewall firewall add rule name="{NOMBRE_REGLA}" dir=in action=allow '
            f'protocol=TCP localport={PUERTO} enable=yes profile=any',
        ]
        if ejecutar_como_admin(lineas):
            self.anotar(f"Configurando «{nombre}» con {IP_CABLE}…")
        else:
            self.anotar("Windows no dio permiso de administrador")

    def regresar_automatico(self):
        nombre = self.var_adaptador.get()
        if nombre and ejecutar_como_admin([f'netsh interface ipv4 set address name="{nombre}" source=dhcp']):
            self.anotar(f"«{nombre}» regresa a IP automática")

    def guardar_foto(self):
        cuadro = self.servidor.ultimo_cuadro
        if cuadro is None:
            self.anotar("Todavía no llega video del celular")
            return
        carpeta = os.path.join(os.path.expanduser("~"), "Pictures", "Puente Video")
        os.makedirs(carpeta, exist_ok=True)
        ruta = os.path.join(carpeta, time.strftime("celular_%Y%m%d_%H%M%S.jpg"))
        cv2.imencode(".jpg", cuadro, [cv2.IMWRITE_JPEG_QUALITY, 95])[1].tofile(ruta)
        self.anotar(f"Foto guardada en {ruta}")

    def alternar_pantalla_completa(self):
        self.pantalla_completa = not self.pantalla_completa
        self.raiz.attributes("-fullscreen", self.pantalla_completa)
        if self.pantalla_completa:
            self.lateral.pack_forget()
        else:
            self.lateral.pack(side="right", fill="y", padx=8, pady=8)

    def salir_pantalla_completa(self):
        if self.pantalla_completa:
            self.alternar_pantalla_completa()

    # ------------------------------------------------------------- refrescos
    def refrescar_video(self):
        version = self.servidor.version_cuadro
        cuadro = self.servidor.ultimo_cuadro
        tam_marco = (self.marco_video.winfo_width(), self.marco_video.winfo_height())
        if cuadro is not None and (version != self.version_dibujada or tam_marco != getattr(self, "tam_dibujado", None)):
            self.version_dibujada = version
            self.tam_dibujado = tam_marco
            ancho = max(self.marco_video.winfo_width() - 4, 50)
            alto = max(self.marco_video.winfo_height() - 4, 50)
            h, w = cuadro.shape[:2]
            escala = min(ancho / w, alto / h)
            tam = (max(1, int(w * escala)), max(1, int(h * escala)))
            img = cv2.resize(cuadro, tam, interpolation=cv2.INTER_LINEAR if escala > 1 else cv2.INTER_AREA)
            self.foto_video = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)))
            self.etiqueta_video.configure(image=self.foto_video, text="")
        elif cuadro is None and self.foto_video is not None and self.servidor.cliente is None:
            pass  # se queda el último cuadro en pantalla

        ahora = time.time()
        if ahora - self.ultima_previa > 0.1:
            self.ultima_previa = ahora
            previa = self.captura.vista_previa
            if previa is not None:
                h, w = previa.shape[:2]
                escala = min(310 / w, 175 / h)
                img = cv2.resize(previa, (max(1, int(w * escala)), max(1, int(h * escala))),
                                 interpolation=cv2.INTER_AREA)
                self.foto_previa = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)))
                self.etiqueta_previa.configure(image=self.foto_previa, text="")
            else:
                if self.foto_previa is not None:
                    self.foto_previa = None
                    self.etiqueta_previa.configure(image="", text="(sin video)")
        self.raiz.after(15, self.refrescar_video)

    def _texto_de_las_ips(self):
        """Las dos IP del cable, dichas una por renglón y con nombre.

        La pregunta que hay que contestar en la ventana no es «qué IP tengo»
        sino «cuál es cuál». Cuando el celular comparte internet por Ethernet,
        él es el que reparte, así que la puerta de enlace del adaptador del
        cable es su IP: la PC puede decir las dos sin preguntarle nada y antes
        de que la app se conecte.
        """
        p = pareja_de_ips()
        s = self.servidor
        # Si el celular ya está conectado, su IP real manda sobre la deducida.
        ip_celular = s.direccion if s.cliente is not None else p["ip_celular"]

        if s.cliente is not None and _es_tunel_usb(s.direccion):
            # Por adb el celular llega como 127.0.0.1: no hay IPs que comparar.
            return "Por el cable USB (depuración USB): no usa IPs ni red."

        lineas = []
        if p["adaptador"]:
            lineas.append(f"Cable: «{p['adaptador']}»")
        if p["ip_pc"]:
            lineas.append(f"  IP de esta PC ........ {p['ip_pc']}")
        else:
            lineas.append("  IP de esta PC ........ todavía ninguna")
        if ip_celular:
            quien = "confirmada" if s.cliente is not None else "reparte las IP"
            lineas.append(f"  IP del celular ....... {ip_celular}  ({quien})")
        elif p["quien"] == "pc":
            lineas.append("  IP del celular ....... la reparte esta PC; aparece al conectarse")
        else:
            lineas.append("  IP del celular ....... todavía no se sabe")

        # Avisar si las dos IP no están en la misma red: es la falla más común
        # y la más difícil de ver a ojo.
        if p["ip_pc"] and ip_celular:
            a, b = _como_ipv4(p["ip_pc"]), _como_ipv4(ip_celular)
            if a is not None and b is not None and a.packed[:3] != b.packed[:3]:
                lineas.append("  ⚠ Las dos IP están en redes distintas: así no se van a ver. "
                              "Desconecta y vuelve a conectar el cable.")

        otras = [ip for _, ip in ips_de_la_pc() if ip != p["ip_pc"]]
        if otras:
            lineas.append("  Otras IP de la PC (no son del cable): " + ", ".join(otras))
        return "\n".join(lineas)

    def refrescar_estado(self):
        ahora = time.time()
        if ahora - self.t_fps >= 1:
            s = self.servidor
            self.fps_rec = round((s.recibidos - self.cuenta_rec) / (ahora - self.t_fps))
            self.fps_env = round((s.enviados - self.cuenta_env) / (ahora - self.t_fps))
            self.cuenta_rec, self.cuenta_env, self.t_fps = s.recibidos, s.enviados, ahora

        s = self.servidor
        if s.error:
            texto = s.error
        elif s.cliente is not None:
            texto = (f"Conectado: {s.nombre_cel or 'celular'} ({s.direccion})\n"
                     f"Recibo {self.fps_rec} fps · Envío {self.fps_env} fps")
        else:
            texto = f"Esperando al celular en el puerto {PUERTO}…"
            recomendada = ip_recomendada()
            if recomendada:
                texto += (f"\nLa app del celular debe encontrarme sola. Si no, escribe esta IP "
                          f"a mano: {recomendada}")
        texto += "\n" + self._texto_de_las_ips()
        self.lbl_estado.configure(text=texto)
        self.lbl_error_envio.configure(text=self.captura.error)

        ics = any(ip == "192.168.137.1" for _, ip in ips_de_la_pc())
        if tiene_ip_cable():
            cable = f"✔ El cable tiene la IP {IP_CABLE}. En el celular usa esa IP."
        elif ics:
            cable = ("✔ Conexión compartida de Windows activa: la PC es 192.168.137.1 y Windows le da IP al celular. "
                     "Quita la palomita de DHCP de abajo.")
        else:
            cable = ("✖ Ningún adaptador tiene la IP del cable. Conecta el cable y presiona "
                     "«Configurar» (si el cable está desconectado, Windows no muestra la IP).")
        if self.var_dhcp.get():
            cable += f"\nDHCP: {self.dhcp.estado}"
            if self.dhcp.estado.startswith("Activo") and s.cliente is None:
                cable += "\nSi el celular no agarra IP, desconecta y vuelve a conectar su adaptador."
        if self.registro:
            cable += "\n" + "\n".join(self.registro)
        self.lbl_cable.configure(text=cable)
        self.lbl_usb.configure(text=("USB: " + self.tunel.estado) if self.tunel.activo else "")
        self.raiz.after(500, self.refrescar_estado)

    # ------------------------------------------------------------ cable USB
    def conectar_usb(self):
        if self.tunel.activo:
            self.tunel.detener()
            self.boton_usb.configure(text="1. Conectar por USB (depuración USB)")
            return
        adb = buscar_adb()
        if adb is not None:
            self._arrancar_tunel(adb)
            return
        if not messagebox.askyesno(
                "Cable USB",
                "Para conectar por USB hace falta adb, la herramienta oficial de Google "
                "para hablar con el celular por el cable (unos 7 MB).\n\n¿La bajo ahora?"):
            return
        self.lbl_usb.configure(text="Bajando adb…")

        def bajar():
            try:
                ruta = descargar_adb(lambda t: self.raiz.after(0, lambda: self.lbl_usb.configure(text=t)))
            except Exception as e:  # noqa: BLE001
                self.raiz.after(0, lambda: messagebox.showerror("Cable USB", f"No pude bajar adb: {e}"))
                return
            self.raiz.after(0, lambda: self._arrancar_tunel(ruta))

        threading.Thread(target=bajar, daemon=True).start()

    def _arrancar_tunel(self, adb):
        self.tunel.iniciar(adb)
        self.boton_usb.configure(text="Dejar de usar el USB")

    def no_gastar_datos(self):
        nombres = adaptadores_de_anclaje()
        if not nombres:
            messagebox.showinfo("Anclaje USB", "No veo ningún celular en anclaje USB. "
                                "Conecta el cable y enciende «Anclaje USB» en el celular.")
            return
        if not ES_WINDOWS:
            messagebox.showinfo("Anclaje USB", "En Linux basta con apagar los datos móviles del celular.")
            return
        if ejecutar_como_admin(comandos_no_gastar_datos(nombres)):
            self.anotar("Anclaje USB al final para internet: " + ", ".join(nombres))

    def cerrar(self):
        self.tunel.detener()
        self.control.apagar()
        self.archivos.detener()
        self.dhcp.detener()
        self.servidor.desconectar()
        self.raiz.destroy()
        os._exit(0)

    def correr(self):
        if ES_WINDOWS and not existe_regla_firewall():
            self.anotar("Tip: presiona «Configurar» para abrir el firewall")
        self.raiz.mainloop()


if __name__ == "__main__":
    # por monitor: sin esto, Windows miente sobre el tamaño de la pantalla
    # cuando el escalado no es 100 % y la captura falla con «BitBlt»
    avisar_escalado()
    App().correr()
