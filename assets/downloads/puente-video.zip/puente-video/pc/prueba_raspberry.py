"""Prueba de la app de PC corriendo en Linux, como en una Raspberry Pi.

Necesita una pantalla X11 (una real o Xvfb) y xdotool para leer dónde quedó el ratón. Revisa tres cosas:

1. El control: un toque del «celular» mueve de verdad el ratón de X11.
2. El video de ida y vuelta: un celular simulado se conecta al puerto 5000,
   le manda cuadros a la app (y recibe acuses) y recibe la pantalla de la app.
3. Que la app arranca en Linux sin errores.

    xvfb-run -s "-screen 0 1366x768x24" python3 prueba_raspberry.py
"""

import os
import shutil
import socket
import struct
import subprocess
import sys
import time

import cv2
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

fallas = 0


def revisar(nombre, ok, detalle=""):
    global fallas
    print(("OK    " if ok else "FALLA ") + nombre + (f"  ({detalle})" if detalle else ""), flush=True)
    if not ok:
        fallas += 1


def recibir_exacto(s, n):
    datos = b""
    while len(datos) < n:
        r = s.recv(n - len(datos))
        if not r:
            raise ConnectionError("cerró")
        datos += r
    return datos


def leer(s):
    tipo, largo = struct.unpack("!BI", recibir_exacto(s, 5))
    return tipo, recibir_exacto(s, largo) if largo else b""


def mandar(s, tipo, datos=b""):
    s.sendall(struct.pack("!BI", tipo, len(datos)) + datos)


if not os.environ.get("DISPLAY") or shutil.which("xdotool") is None:
    print("SALTADA: hace falta DISPLAY (X11 o Xvfb) y xdotool")
    sys.exit(0)

# ---------------------------------------------------------------- 1. control
from control_remoto import ControlRemoto, a_pixel  # noqa: E402
import monitor_virtual  # noqa: E402

monitores = monitor_virtual.pantallas()
revisar("hay al menos una pantalla", len(monitores) >= 1, str(monitores))
m = monitores[0]
c = ControlRemoto()
revisar("apagado no hace nada", c.atender("mover|0.5|0.5") is False)
c.encendido = True
c.apuntar_a(m)
revisar("mover al centro", c.atender("mover|0.5|0.5"), c.error)
pos = subprocess.run(["xdotool", "getmouselocation", "--shell"], capture_output=True, text=True).stdout
x = int([l for l in pos.splitlines() if l.startswith("X=")][0][2:])
y = int([l for l in pos.splitlines() if l.startswith("Y=")][0][2:])
esperado = a_pixel(0.5, 0.5, m)
revisar("el ratón quedó donde tocó el dedo", (x, y) == esperado, f"{(x, y)} vs {esperado}")
c.atender("mover|1|1")
pos = subprocess.run(["xdotool", "getmouselocation", "--shell"], capture_output=True, text=True).stdout
x = int([l for l in pos.splitlines() if l.startswith("X=")][0][2:])
revisar("la esquina se alcanza sin salirse", x == m["x"] + m["ancho"] - 1, str(x))
revisar("clic abajo", c.atender("clic|0.2|0.2|izq|abajo"), c.error)
revisar("clic arriba", c.atender("clic|0.2|0.2|izq|arriba"), c.error)
revisar("rueda", c.atender("rueda|0.5|0.5|-2"), c.error)
revisar("mensaje basura no truena", c.atender("mover|x|y") is False)

# ------------------------------------------------- 2. la app y el video de ida y vuelta
casa = os.path.join(os.environ.get("TMPDIR", "/tmp"), "casa_prueba_pi")
os.makedirs(casa, exist_ok=True)
entorno = dict(os.environ, HOME=casa)
app = subprocess.Popen([sys.executable, os.path.join(AQUI, "puente_video.py")], env=entorno,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
try:
    s = None
    for _ in range(40):
        try:
            s = socket.create_connection(("127.0.0.1", 5000), timeout=1)
            break
        except OSError:
            time.sleep(0.25)
    revisar("la app abre el puerto 5000", s is not None)
    if s is not None:
        s.settimeout(10)
        mandar(s, 2, "HOLA|Celular de prueba".encode())
        img = np.full((360, 640, 3), (40, 120, 200), np.uint8)
        jpeg = cv2.imencode(".jpg", img)[1].tobytes()

        recibidos, acuses, hola = 0, 0, ""
        mandados = 0
        fin = time.time() + 10
        while time.time() < fin and (recibidos < 3 or acuses < 3):
            if mandados - acuses < 2:
                mandar(s, 1, jpeg)
                mandados += 1
            tipo, datos = leer(s)
            if tipo == 1:
                cuadro = cv2.imdecode(np.frombuffer(datos, np.uint8), cv2.IMREAD_COLOR)
                if cuadro is not None:
                    recibidos += 1
                mandar(s, 3)  # acuse, como hace el celular
            elif tipo == 3:
                acuses += 1
            elif tipo == 2:
                hola = datos.decode("utf-8", "replace")
        revisar("la app saluda con su nombre", hola.startswith("HOLA|"), hola)
        revisar("la app manda su pantalla al celular", recibidos >= 3, f"{recibidos} cuadros")
        revisar("la app recibe el video del celular", acuses >= 3, f"{acuses} acuses")
        s.close()
    revisar("la app sigue viva", app.poll() is None)
finally:
    app.terminate()
    try:
        salida = app.communicate(timeout=5)[0].decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        app.kill()
        salida = ""
    revisar("sin errores de Python en la app", "Traceback" not in salida, salida[-400:])

print()
print("TODO BIEN" if fallas == 0 else f"{fallas} FALLAS")
sys.exit(1 if fallas else 0)
