"""Que tocar el celular mueva el cursor de la PC.

Esto es lo que separa «el celular enseña una pantalla» de «el celular **es**
una pantalla». Sin esto, aunque Windows crea que hay un segundo monitor y el
celular lo esté mostrando, para usar lo que hay ahí habría que regresar al
teclado y al ratón de la PC, que es justo lo que uno no quiere cuando pone el
teléfono a un lado como pantalla extra.

Cómo viaja: el celular manda la posición del dedo **en proporción** (0 a 1)
sobre la imagen que está viendo, no en píxeles. Así no importa el tamaño del
celular, ni su resolución, ni si está en horizontal: el mismo mensaje vale
para cualquier teléfono. La PC convierte esa proporción a un punto del monitor
que está mandando, y de ahí a la coordenada que entiende Windows.

Esa conversión es la única parte con enjundia, porque Windows no cuenta las
coordenadas del ratón por monitor sino sobre el **escritorio virtual**: el
rectángulo que abarca todos los monitores juntos, que puede empezar en números
negativos si el segundo monitor está a la izquierda del principal. Un monitor
secundario mal convertido deja el cursor en el monitor equivocado, que es un
error que se ve rarísimo y cuesta entender.

Seguridad: esto deja que el celular mueva el cursor y haga clic en la PC. Va
**apagado** mientras nadie lo encienda, y se apaga solo al desconectar. No se
enciende por el hecho de que haya una conexión.
"""

import ctypes
import sys
from ctypes import wintypes

ES_WINDOWS = sys.platform == "win32"

# Índices de GetSystemMetrics para el escritorio virtual.
SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79

ENTRADA_RATON = 0
MOVER = 0x0001
IZQ_ABAJO = 0x0002
IZQ_ARRIBA = 0x0004
DER_ABAJO = 0x0008
DER_ARRIBA = 0x0010
RUEDA = 0x0800
ABSOLUTO = 0x8000
ESCRITORIO_VIRTUAL = 0x4000


class _Raton(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG))]


class _Union(ctypes.Union):
    _fields_ = [("mi", _Raton)]


class _Entrada(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _Union)]


def escritorio_virtual():
    """(x, y, ancho, alto) del rectángulo que abarca todos los monitores."""
    if not ES_WINDOWS:
        return 0, 0, 1920, 1080
    g = ctypes.windll.user32.GetSystemMetrics
    return (g(SM_XVIRTUALSCREEN), g(SM_YVIRTUALSCREEN),
            max(1, g(SM_CXVIRTUALSCREEN)), max(1, g(SM_CYVIRTUALSCREEN)))


def a_coordenada_de_windows(prop_x, prop_y, monitor, virtual=None):
    """Convierte una proporción sobre un monitor a la coordenada del ratón.

    `prop_x` y `prop_y` van de 0 a 1 sobre el monitor que se está mandando.
    `monitor` es un diccionario con `x`, `y`, `ancho`, `alto` tal como los da
    `monitor_virtual.pantallas()`.

    Windows quiere, para un movimiento absoluto con la bandera de escritorio
    virtual, un número de 0 a 65535 sobre **todo** el escritorio virtual. Por
    eso hay dos pasos y no uno: primero de la proporción al píxel del
    escritorio, y luego del píxel a esa escala. Saltarse el primero es el error
    que manda el cursor al monitor equivocado.

    Se devuelve siempre dentro del rango, porque un dedo que se sale un píxel
    del borde no es motivo para mandar una coordenada inválida.
    """
    if virtual is None:
        virtual = escritorio_virtual()
    vx, vy, vancho, valto = virtual

    prop_x = min(1.0, max(0.0, float(prop_x)))
    prop_y = min(1.0, max(0.0, float(prop_y)))

    # Paso 1: el píxel del escritorio virtual donde cae el dedo.
    px = monitor["x"] + prop_x * monitor["ancho"]
    py = monitor["y"] + prop_y * monitor["alto"]

    # Paso 2: ese píxel en la escala de 0 a 65535 que pide Windows.
    # El -1 del divisor hace que el borde derecho caiga exacto en 65535 y no
    # un paso antes; sin él, la última columna de píxeles no es alcanzable.
    ax = (px - vx) * 65535 / max(1, vancho - 1)
    ay = (py - vy) * 65535 / max(1, valto - 1)
    return int(round(min(65535, max(0, ax)))), int(round(min(65535, max(0, ay))))


def a_pixel(prop_x, prop_y, monitor):
    """La proporción del dedo convertida a píxel del escritorio, para Linux.

    En Linux (X11) el ratón se mueve en píxeles sobre todo el escritorio, que
    empieza en 0,0; no hace falta la escala de 0 a 65535 de Windows. Se recorta
    al último píxel del monitor para que el borde siempre sea alcanzable.
    """
    prop_x = min(1.0, max(0.0, float(prop_x)))
    prop_y = min(1.0, max(0.0, float(prop_y)))
    px = monitor["x"] + min(monitor["ancho"] - 1, int(prop_x * monitor["ancho"]))
    py = monitor["y"] + min(monitor["alto"] - 1, int(prop_y * monitor["alto"]))
    return px, py


class ControlRemoto:
    """Recibe los toques del celular y los convierte en ratón de Windows."""

    def __init__(self):
        self.encendido = False
        self.monitor = None       # el monitor que se está mandando
        self.error = ""
        self.ultimo = ""          # para enseñar qué fue lo último que llegó

    def apuntar_a(self, monitor):
        self.monitor = monitor

    def apagar(self):
        self.encendido = False

    def _mandar(self, banderas, x=0, y=0, dato=0):
        if not ES_WINDOWS:
            return False
        e = _Entrada()
        e.type = ENTRADA_RATON
        e.mi = _Raton(x, y, dato, banderas, 0, None)
        enviados = ctypes.windll.user32.SendInput(1, ctypes.byref(e), ctypes.sizeof(e))
        return enviados == 1

    def atender(self, texto):
        """Un mensaje del celular. Devuelve True si se hizo algo.

        Formato, separado por barras, para que se pueda leer en un registro
        sin descifrar nada:

            mover|0.5|0.5             el dedo está a la mitad
            clic|0.5|0.5|izq|abajo    puso el dedo
            clic|0.5|0.5|izq|arriba   lo levantó
            clic|0.5|0.5|der|abajo    mantuvo apretado (clic derecho)
            rueda|0.5|0.5|-3          arrastró dos dedos
        """
        if not self.encendido or self.monitor is None:
            return False
        partes = texto.strip().split("|")
        if len(partes) < 3:
            return False
        try:
            px, py = float(partes[1]), float(partes[2])
        except ValueError:
            return False
        orden = partes[0]
        self.ultimo = texto
        if not ES_WINDOWS:
            return self._atender_linux(orden, partes, px, py)
        x, y = a_coordenada_de_windows(px, py, self.monitor)

        if orden == "mover":
            return self._mandar(MOVER | ABSOLUTO | ESCRITORIO_VIRTUAL, x, y)

        if orden == "clic" and len(partes) >= 5:
            boton, accion = partes[3], partes[4]
            # Siempre se mueve antes de apretar: si no, Windows hace el clic
            # donde estaba el cursor, no donde está el dedo.
            self._mandar(MOVER | ABSOLUTO | ESCRITORIO_VIRTUAL, x, y)
            if boton == "der":
                bandera = DER_ABAJO if accion == "abajo" else DER_ARRIBA
            else:
                bandera = IZQ_ABAJO if accion == "abajo" else IZQ_ARRIBA
            return self._mandar(bandera | ABSOLUTO | ESCRITORIO_VIRTUAL, x, y)

        if orden == "rueda" and len(partes) >= 4:
            try:
                pasos = int(float(partes[3]))
            except ValueError:
                return False
            self._mandar(MOVER | ABSOLUTO | ESCRITORIO_VIRTUAL, x, y)
            # 120 es un «paso» de rueda para Windows.
            return self._mandar(RUEDA | ABSOLUTO | ESCRITORIO_VIRTUAL, x, y, pasos * 120)

        return False

    # ------------------------------------------------------------ Linux (X11)
    # Se usa XTest directo por ctypes (libX11 + libXtst), como hace xdotool por
    # dentro, pero sin lanzar un proceso por cada movimiento del dedo: con un
    # proceso por mensaje el cursor se arrastra detrás del dedo. En Raspberry Pi
    # OS hace falta la sesión X11, no Wayland: en Wayland ninguna app puede
    # mover el ratón de otra.
    def _x11(self):
        if getattr(self, "_xd", None) is not None:
            return self._xd
        try:
            import ctypes.util
            x11 = ctypes.CDLL(ctypes.util.find_library("X11") or "libX11.so.6")
            xtst = ctypes.CDLL(ctypes.util.find_library("Xtst") or "libXtst.so.6")
        except OSError:
            self.error = "Faltan libX11/libXtst: sudo apt install libxtst6"
            return None
        x11.XOpenDisplay.restype = ctypes.c_void_p
        x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
        x11.XFlush.argtypes = [ctypes.c_void_p]
        xtst.XTestFakeMotionEvent.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int,
                                              ctypes.c_int, ctypes.c_ulong]
        xtst.XTestFakeButtonEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int,
                                              ctypes.c_ulong]
        pantalla = ctypes.c_void_p(x11.XOpenDisplay(None))
        if not pantalla.value:
            self.error = ("No pude abrir la pantalla X11. En Raspberry Pi OS cambia a X11: "
                          "sudo raspi-config › Advanced Options › Wayland › X11")
            return None
        self._xd = (x11, xtst, pantalla)
        return self._xd

    def _mover_x11(self, x, y):
        xd = self._x11()
        if xd is None:
            return False
        x11, xtst, d = xd
        xtst.XTestFakeMotionEvent(d, -1, int(x), int(y), 0)
        x11.XFlush(d)
        return True

    def _boton_x11(self, boton, apretar):
        xd = self._x11()
        if xd is None:
            return False
        x11, xtst, d = xd
        xtst.XTestFakeButtonEvent(d, boton, 1 if apretar else 0, 0)
        x11.XFlush(d)
        return True

    def _atender_linux(self, orden, partes, prop_x, prop_y):
        x, y = a_pixel(prop_x, prop_y, self.monitor)
        if orden == "mover":
            return self._mover_x11(x, y)
        if orden == "clic" and len(partes) >= 5:
            # Siempre se mueve antes de apretar, igual que en Windows.
            if not self._mover_x11(x, y):
                return False
            boton = 3 if partes[3] == "der" else 1
            return self._boton_x11(boton, partes[4] == "abajo")
        if orden == "rueda" and len(partes) >= 4:
            try:
                pasos = int(float(partes[3]))
            except ValueError:
                return False
            if pasos == 0 or not self._mover_x11(x, y):
                return False
            # En X11 la rueda son los botones 4 (arriba) y 5 (abajo).
            boton = 4 if pasos > 0 else 5
            for _ in range(min(abs(pasos), 20)):
                self._boton_x11(boton, True)
                self._boton_x11(boton, False)
            return True
        return False
