"""Captura de la pantalla de la PC, con varios métodos de respaldo.

El método de siempre (mss) falla en algunas laptops con el error
«Windows graphics function failed: BitBlt». Casi siempre es por el escalado
de pantalla o porque el contexto de dibujo se queda viejo cuando Windows
cambia de monitor. Aquí se intenta, en este orden:

    1. dxcam  — Desktop Duplication, la misma que usa Windows para grabar.
    2. mss    — el de siempre, recreándolo si falla.
    3. Pillow — ImageGrab, lento pero casi siempre funciona.

Si uno falla se pasa al siguiente y se recuerda cuál sirvió.
"""

import ctypes
import sys

import numpy as np

ES_WINDOWS = sys.platform == "win32"

try:
    import mss
except ImportError:
    mss = None

try:
    import dxcam
except ImportError:
    dxcam = None

try:
    from PIL import ImageGrab
except ImportError:
    ImageGrab = None


def avisar_escalado():
    """Le dice a Windows que la app entiende el escalado de pantalla.

    Sin esto, Windows miente sobre el tamaño del monitor cuando el escalado
    no es 100 %, y la captura falla o sale recortada.
    """
    if not ES_WINDOWS:
        return
    try:
        # 2 = por monitor; es el modo bueno
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:  # noqa: BLE001  Windows viejo
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:  # noqa: BLE001
            pass


def cuantas_pantallas():
    """Cuántos monitores hay. Si no se puede saber, contesta 1."""
    if mss is not None:
        try:
            with mss.mss() as sct:
                return max(1, len(sct.monitors) - 1)
        except Exception:  # noqa: BLE001
            pass
    if ES_WINDOWS:
        try:
            return max(1, ctypes.windll.user32.GetSystemMetrics(80))  # SM_CMONITORS
        except Exception:  # noqa: BLE001
            pass
    return 1


class CapturaPantalla:
    """Entrega cuadros BGR de un monitor, sin importar qué método funcione."""

    def __init__(self, numero=1):
        self.numero = max(1, int(numero))
        self.metodo = ""
        self.error = ""
        self._mss = None
        self._dxcam = None
        self._fallos_mss = 0

    # -- limpieza -----------------------------------------------------------
    def cerrar(self):
        if self._mss is not None:
            try:
                self._mss.close()
            except Exception:  # noqa: BLE001
                pass
            self._mss = None
        if self._dxcam is not None:
            try:
                self._dxcam.release()
            except Exception:  # noqa: BLE001
                pass
            self._dxcam = None

    # -- cada método --------------------------------------------------------
    def _por_dxcam(self):
        if dxcam is None or not ES_WINDOWS:
            return None
        if self._dxcam is None:
            # dxcam numera los monitores desde 0; aquí desde 1
            self._dxcam = dxcam.create(output_idx=self.numero - 1, output_color="BGR")
            if self._dxcam is None:
                return None
        cuadro = self._dxcam.grab()
        if cuadro is None:
            # dxcam devuelve None si la pantalla no ha cambiado: se reusa el anterior
            return False
        return np.ascontiguousarray(cuadro)

    def _por_mss(self):
        if mss is None:
            return None
        if self._mss is None:
            self._mss = mss.mss()
        monitores = self._mss.monitors
        numero = self.numero if self.numero < len(monitores) else 1
        bruto = np.asarray(self._mss.grab(monitores[numero]))
        # mss entrega BGRA; a cv2 le sirve BGR y lo quiere contiguo
        return np.ascontiguousarray(bruto[:, :, :3])

    def _por_pillow(self):
        if ImageGrab is None:
            return None
        # sin all_screens toma solo el monitor principal, que es lo que se
        # quiere para «Pantalla 1»; para los demás hace falta todo el escritorio
        imagen = ImageGrab.grab(all_screens=self.numero > 1)
        bruto = np.asarray(imagen)  # RGB
        return bruto[:, :, ::-1].copy()

    # -- lo que usa la app --------------------------------------------------
    def leer(self):
        """Devuelve un cuadro BGR, o None si ningún método funcionó.

        Devuelve False cuando no hay nada nuevo que mandar (la pantalla no
        cambió); quien llama debe reusar el cuadro anterior.
        """
        intentos = (
            ("Desktop Duplication", self._por_dxcam),
            ("mss", self._por_mss),
            ("Pillow", self._por_pillow),
        )
        # si ya sabemos cuál sirve, se intenta ese primero
        if self.metodo:
            intentos = tuple(sorted(intentos, key=lambda p: p[0] != self.metodo))

        ultimo = ""
        for nombre, metodo in intentos:
            try:
                cuadro = metodo()
            except Exception as e:  # noqa: BLE001
                ultimo = f"{nombre}: {e}"
                if nombre == "mss":
                    # el contexto se quedó viejo; se tira y se crea otro
                    self._fallos_mss += 1
                    if self._mss is not None:
                        try:
                            self._mss.close()
                        except Exception:  # noqa: BLE001
                            pass
                        self._mss = None
                elif nombre == "Desktop Duplication":
                    self._dxcam = None
                continue
            if cuadro is False:
                return False
            if cuadro is None:
                continue
            if getattr(cuadro, "size", 0) == 0:
                ultimo = f"{nombre}: cuadro vacío"
                continue
            if self.metodo != nombre:
                self.metodo = nombre
            self.error = ""
            return cuadro

        self.error = ultimo or "ningún método de captura disponible"
        return None
