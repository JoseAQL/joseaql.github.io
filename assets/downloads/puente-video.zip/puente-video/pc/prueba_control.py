"""Prueba de la conversión de toque del celular a cursor de Windows.

Corre sin Windows y sin celular: lo único que se prueba son las cuentas, que
es donde está el error difícil. Windows no cuenta las coordenadas del ratón
por monitor sino sobre el **escritorio virtual**, el rectángulo que abarca
todos los monitores juntos, y ese rectángulo empieza en números negativos
cuando el segundo monitor está a la izquierda del principal.

Ese es el caso que se prueba aquí a propósito, porque es el que una cuenta
floja pasa por alto: con un solo monitor en (0,0) casi cualquier fórmula sale
bien, y el error solo aparece el día que alguien pone el celular del lado
izquierdo. El síntoma es que el cursor se va al monitor equivocado, que se ve
rarísimo y cuesta mucho relacionar con una resta.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import control_remoto as C  # noqa: E402

fallos = 0


def check(nombre, ok, extra=""):
    global fallos
    print(("OK    " if ok else "FALLA ") + nombre + (f"  — {extra}" if extra else ""))
    if not ok:
        fallos += 1


def volver_a_pixel(ax, ay, virtual):
    """De la escala 0‑65535 de Windows de regreso al píxel, para poder revisar."""
    vx, vy, vancho, valto = virtual
    return vx + ax * (vancho - 1) / 65535, vy + ay * (valto - 1) / 65535


def correr():
    # Un monitor principal de 1920x1080 en el origen, y el celular puesto
    # como pantalla vertical a su IZQUIERDA.
    principal = {"x": 0, "y": 0, "ancho": 1920, "alto": 1080}
    celular = {"x": -1080, "y": 0, "ancho": 1080, "alto": 2400}
    virtual = (-1080, 0, 1080 + 1920, 2400)

    casos = [
        ("el centro del monitor principal", principal, 0.5, 0.5, 960, 540),
        ("la esquina de arriba del principal", principal, 0.0, 0.0, 0, 0),
        ("la esquina de abajo del principal", principal, 1.0, 1.0, 1920, 1080),
        ("el centro del celular", celular, 0.5, 0.5, -540, 1200),
        ("la esquina de arriba del celular", celular, 0.0, 0.0, -1080, 0),
        ("la esquina de abajo del celular", celular, 1.0, 1.0, 0, 2400),
    ]
    for nombre, monitor, px, py, esperado_x, esperado_y in casos:
        ax, ay = C.a_coordenada_de_windows(px, py, monitor, virtual)
        rx, ry = volver_a_pixel(ax, ay, virtual)
        ok = abs(rx - esperado_x) < 2 and abs(ry - esperado_y) < 2
        check(f"un dedo en {nombre}", ok,
              f"cae en ({rx:.0f}, {ry:.0f}), se esperaba ({esperado_x}, {esperado_y})")

    # El dedo que se sale del borde no debe mandar una coordenada inválida.
    for px, py in ((-0.3, 0.5), (1.4, 0.5), (0.5, -2.0), (0.5, 9.9)):
        ax, ay = C.a_coordenada_de_windows(px, py, celular, virtual)
        check(f"un dedo fuera del borde ({px}, {py}) se recorta",
              0 <= ax <= 65535 and 0 <= ay <= 65535, f"dio ({ax}, {ay})")

    # El control no hace nada mientras esté apagado, aunque lleguen mensajes.
    c = C.ControlRemoto()
    c.apuntar_a(celular)
    check("apagado, un mensaje no hace nada", c.atender("mover|0.5|0.5") is False)
    check("arranca apagado", c.encendido is False)

    # Mensajes mal formados no deben tronar.
    c.encendido = True
    for malo in ("", "mover", "mover|a|b", "clic|0.5|0.5", "loquesea|1|2", "rueda|0.5|0.5|x"):
        try:
            c.atender(malo)
            check(f"un mensaje roto ({malo!r}) no truena", True)
        except Exception as e:  # noqa: BLE001
            check(f"un mensaje roto ({malo!r}) no truena", False, str(e))


def main():
    correr()
    print()
    if fallos:
        print(f"{fallos} FALLAS")
        return 1
    print("TODO BIEN")
    return 0


if __name__ == "__main__":
    sys.exit(main())
