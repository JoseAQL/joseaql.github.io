"""Conectar el celular con su cable USB original, sin cable Ethernet.

Hay dos caminos, y el programa usa el que haya:

1. **ADB** (depuración USB), como lo hace scrcpy. La PC le pide a adb un túnel
   «al revés» (`adb reverse`): en el celular, conectarse a 127.0.0.1:5000 llega
   al puerto 5000 de la PC por el cable USB. No hay IPs, ni red, ni firewall de
   por medio, y no se gastan datos. Lo único que pide es activar la depuración
   USB una vez y aceptar el aviso de «¿Permitir depuración USB?».

2. **Anclaje USB** (USB tethering). El celular se vuelve una tarjeta de red
   para la PC y le reparte IP, igual que con el cable Ethernet. No pide nada
   de depuración, pero Windows puede usar el internet del celular por ese
   cable y gastar datos móviles; por eso hay una función para que Windows lo
   deje como última opción para internet.

adb no viene con Windows. Si no está, se baja de Google (platform-tools) a la
carpeta del usuario, solo cuando el usuario lo pide con el botón.
"""

import io
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

ES_WINDOWS = sys.platform == "win32"
SIN_VENTANA = 0x08000000 if ES_WINDOWS else 0

PUERTOS_TUNEL = (5000, 5005)        # video y control; archivos
PAQUETE_APP = "com.puentevideo.app"
ACTIVIDAD_APP = PAQUETE_APP + "/.MainActivity"

URL_PLATFORM_TOOLS = {
    "win32": "https://dl.google.com/android/repository/platform-tools-latest-windows.zip",
    "linux": "https://dl.google.com/android/repository/platform-tools-latest-linux.zip",
    "darwin": "https://dl.google.com/android/repository/platform-tools-latest-darwin.zip",
}


def carpeta_propia():
    """Donde el programa guarda adb si lo baja: en la carpeta del usuario."""
    if ES_WINDOWS:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        return os.path.join(base, "PuenteVideo")
    return os.path.join(os.path.expanduser("~"), ".local", "share", "puente-video")


def buscar_adb():
    """La ruta de adb, o None. Busca en el PATH, junto al programa y en la carpeta propia."""
    nombre = "adb.exe" if ES_WINDOWS else "adb"
    candidatas = []
    en_path = shutil.which("adb")
    if en_path:
        candidatas.append(en_path)
    junto = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
    candidatas.append(os.path.join(junto, "platform-tools", nombre))
    candidatas.append(os.path.join(carpeta_propia(), "platform-tools", nombre))
    for c in candidatas:
        if c and os.path.isfile(c):
            return c
    return None


def descargar_adb(avance=None):
    """Baja platform-tools de Google y devuelve la ruta de adb.

    Lanza una excepción con un mensaje claro si no se puede (sin internet, o
    una plataforma sin paquete, como la Raspberry Pi, donde va por apt).
    """
    plataforma = "win32" if ES_WINDOWS else sys.platform
    if plataforma.startswith("linux"):
        import platform
        if platform.machine().lower() not in ("x86_64", "amd64"):
            raise RuntimeError("En esta placa instala adb con: sudo apt install adb")
        plataforma = "linux"
    url = URL_PLATFORM_TOOLS.get(plataforma)
    if url is None:
        raise RuntimeError("No hay adb para este sistema")
    destino = carpeta_propia()
    os.makedirs(destino, exist_ok=True)
    if avance:
        avance("Bajando adb de Google…")
    with urllib.request.urlopen(url, timeout=60) as r:
        datos = r.read()
    if avance:
        avance("Descomprimiendo…")
    with zipfile.ZipFile(io.BytesIO(datos)) as z:
        z.extractall(destino)
    adb = os.path.join(destino, "platform-tools", "adb.exe" if ES_WINDOWS else "adb")
    if not ES_WINDOWS and os.path.isfile(adb):
        os.chmod(adb, 0o755)
    if not os.path.isfile(adb):
        raise RuntimeError("El paquete de Google no trajo adb")
    return adb


def correr(adb, *argumentos, espera=10):
    """Corre adb y devuelve (ok, texto)."""
    try:
        r = subprocess.run([adb, *argumentos], capture_output=True, timeout=espera,
                           creationflags=SIN_VENTANA)
    except (OSError, subprocess.SubprocessError) as e:
        return False, str(e)
    texto = (r.stdout + r.stderr).decode("utf-8", "replace").strip()
    return r.returncode == 0, texto


def leer_dispositivos(texto):
    """Interpreta la salida de `adb devices`: lista de (serie, estado).

    Los estados que importan: «device» (listo), «unauthorized» (falta aceptar
    el aviso en el celular) y «offline».
    """
    salida = []
    for linea in texto.splitlines():
        linea = linea.strip()
        if not linea or linea.startswith(("List of devices", "*", "adb ")):
            continue
        partes = linea.split()
        if len(partes) >= 2:
            salida.append((partes[0], partes[1]))
    return salida


def explicar_estado(estado):
    return {
        "device": "listo",
        "unauthorized": "acepta «¿Permitir depuración USB?» en el celular",
        "offline": "desconectado; quita y pon el cable",
        "no permissions": "Linux sin permiso para el USB; instala android-udev-rules",
    }.get(estado, estado)


class TunelUSB:
    """Vigila el cable USB y deja el túnel de adb puesto mientras haya celular.

    Corre en su propio hilo: cada 2 s revisa `adb devices`. Cuando aparece un
    celular listo, pone `adb reverse` para los puertos de la app y abre la app
    en el celular para que se conecte sola a 127.0.0.1.
    """

    def __init__(self, registro=None):
        self.registro = registro or (lambda texto: None)
        self.adb = None
        self.activo = False
        self.estado = "apagado"
        self.serie = None
        self._puesto = set()     # series con el túnel ya puesto
        self._en_curso = None    # serie a la que se le está poniendo ahorita
        self._hilo = None

    def iniciar(self, adb):
        self.adb = adb
        if self.activo:
            return
        self.activo = True
        self.estado = "buscando el celular por USB…"
        self._hilo = threading.Thread(target=self._vigilar, daemon=True)
        self._hilo.start()

    def _quitar(self, serie):
        for puerto in PUERTOS_TUNEL:
            correr(self.adb, "-s", serie, "reverse", "--remove", f"tcp:{puerto}", espera=5)

    def detener(self):
        self.activo = False
        if self.adb:
            # También la que se estaba poniendo: si no, apagar justo al conectar
            # deja un túnel puesto que nadie quita.
            series = set(self._puesto)
            if self._en_curso:
                series.add(self._en_curso)
            for serie in series:
                self._quitar(serie)
        self._puesto.clear()
        self.serie = None
        self.estado = "apagado"

    def poner_tunel(self, serie):
        """Pone los túneles para una serie. Devuelve (ok, mensaje)."""
        self._en_curso = serie
        for puerto in PUERTOS_TUNEL:
            ok, texto = correr(self.adb, "-s", serie, "reverse", f"tcp:{puerto}", f"tcp:{puerto}")
            if not ok:
                return False, texto or f"no pude poner el túnel del puerto {puerto}"
        # Abre la app y le dice a dónde conectarse. Si no está instalada, no
        # pasa nada grave: el túnel queda puesto y se conecta a mano.
        correr(self.adb, "-s", serie, "shell", "am", "start", "-n", ACTIVIDAD_APP,
               "--es", "conectar", "127.0.0.1", espera=8)
        return True, "túnel listo"

    def _vigilar(self):
        while self.activo:
            ok, texto = correr(self.adb, "devices", espera=8)
            if not ok:
                self.estado = "adb no responde: " + texto[:80]
                time.sleep(2)
                continue
            dispositivos = leer_dispositivos(texto)
            listos = [s for s, e in dispositivos if e == "device"]
            if not dispositivos:
                self.estado = "conecta el celular con su cable USB (con depuración USB activa)"
                self._puesto.clear()
                self.serie = None
            elif not listos:
                self.estado = explicar_estado(dispositivos[0][1])
            else:
                serie = listos[0]
                if serie not in self._puesto:
                    ok, mensaje = self.poner_tunel(serie)
                    self._en_curso = None
                    if not self.activo:
                        # Lo apagaron mientras se ponía: se quita lo que alcanzó a quedar.
                        self._quitar(serie)
                        return
                    if ok:
                        self._puesto.add(serie)
                        self.registro(f"USB: túnel listo con {serie}")
                    else:
                        self.estado = "no pude poner el túnel: " + mensaje[:80]
                        time.sleep(2)
                        continue
                self.serie = serie
                self.estado = f"listo por USB ({serie})"
            # Los que ya no están dejan de contar, para volver a poner el túnel si regresan.
            self._puesto &= set(listos)
            time.sleep(2)


# ---------------------------------------------------------- anclaje USB
def adaptadores_de_anclaje():
    """Nombres de las tarjetas de red que son un celular en anclaje USB.

    En Windows el nombre es genérico («Ethernet 3»), así que se busca por la
    descripción del controlador (Remote NDIS, que es como Android se presenta).
    En Linux son usb0, rndis0 o enx… según el sistema.
    """
    if ES_WINDOWS:
        comando = ("Get-NetAdapter | Where-Object { $_.InterfaceDescription -match "
                   "'NDIS|Android|USB Ethernet' } | Select-Object -ExpandProperty Name")
        try:
            r = subprocess.run(["powershell", "-NoProfile", "-Command", comando],
                               capture_output=True, timeout=6, creationflags=SIN_VENTANA)
            return [l.strip() for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
        except (OSError, subprocess.SubprocessError):
            return []
    try:
        return [n for n in os.listdir("/sys/class/net") if n.startswith(("usb", "rndis"))]
    except OSError:
        return []


def comandos_no_gastar_datos(nombres):
    """Comandos de netsh que dejan el anclaje USB como última opción para internet.

    Con métrica alta Windows sigue usando el cable para hablar con el celular,
    pero sale a internet por el Wi‑Fi o el Ethernet de la casa si los hay. Si
    la PC no tiene otra salida a internet, la usará igual: para cortarla del
    todo hay que apagar los datos móviles en el celular.
    """
    salida = []
    for nombre in nombres:
        salida.append(f'netsh interface ipv4 set interface "{nombre}" metric=9000')
        salida.append(f'netsh interface ipv6 set interface "{nombre}" metric=9000')
    return salida
