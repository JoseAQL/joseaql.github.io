"""Servidor DHCP mínimo para el cable directo PC <-> celular.

Con un cable Ethernet directo no hay router que reparta direcciones, y Android
no deja poner IP fija en Ethernet. Este servidor le da al celular una IP de la
red 192.168.77.0/24. No anuncia puerta de enlace ni DNS, así el celular sigue
usando su WiFi o datos para internet.
"""

import socket
import struct
import threading
import time

MAGIA = b"\x63\x82\x53\x63"
DISCOVER, OFFER, REQUEST, DECLINE, ACK, NAK, RELEASE, INFORM = 1, 2, 3, 4, 5, 6, 7, 8
DURACION = 24 * 3600


def leer_opciones(datos):
    opciones = {}
    i = 240
    while i < len(datos):
        codigo = datos[i]
        if codigo == 0:
            i += 1
            continue
        if codigo == 255 or i + 1 >= len(datos):
            break
        largo = datos[i + 1]
        opciones[codigo] = datos[i + 2:i + 2 + largo]
        i += 2 + largo
    return opciones


def quien_usa_puerto(puerto, protocolo="udp"):
    """Nombre del programa (y servicios de Windows) que tiene abierto el puerto, si se puede saber."""
    try:
        import psutil
        for c in psutil.net_connections(kind=protocolo):
            if c.laddr and c.laddr.port == puerto and c.pid:
                nombre = psutil.Process(c.pid).name()
                servicios = ""
                try:
                    import subprocess
                    salida = subprocess.run(["tasklist", "/svc", "/fi", f"PID eq {c.pid}", "/fo", "csv", "/nh"],
                                            capture_output=True, text=True, timeout=5,
                                            creationflags=0x08000000).stdout
                    partes = salida.strip().split('","')
                    if len(partes) >= 3:
                        servicios = partes[2].strip('"')
                except Exception:  # noqa: BLE001
                    pass
                return f"{nombre} (PID {c.pid}{', ' + servicios if servicios and servicios != 'N/D' else ''})"
    except Exception:  # noqa: BLE001
        pass
    return None


def ip_presente(ip):
    try:
        import psutil
    except ImportError:
        return True
    return any(d.address == ip for direcciones in psutil.net_if_addrs().values() for d in direcciones)


class ServidorDHCP:
    def __init__(self, ip_servidor="192.168.77.1", mascara="255.255.255.0",
                 primera=10, ultima=60, registro=None):
        self.ip = ip_servidor
        self.mascara = mascara
        base = ip_servidor.rsplit(".", 1)[0]
        self.libres = [f"{base}.{n}" for n in range(primera, ultima + 1)]
        self.prestamos = {}  # mac (str) -> ip
        self.registro = registro or (lambda texto: None)
        self.estado = "Apagado"
        self._activo = False
        self._hilo = None
        self._socket = None

    # ---------------------------------------------------------------- lógica
    def _ip_para(self, mac):
        if mac in self.prestamos:
            return self.prestamos[mac]
        usadas = set(self.prestamos.values())
        for ip in self.libres:
            if ip not in usadas:
                self.prestamos[mac] = ip
                return ip
        return None

    def _respuesta(self, pedido, tipo, ip_cliente):
        cabecera = (
            struct.pack("!BBBB", 2, pedido[1], pedido[2], 0)
            + pedido[4:8]                      # xid
            + b"\x00\x00"                      # secs
            + pedido[10:12]                    # flags
            + b"\x00" * 4                      # ciaddr
            + socket.inet_aton(ip_cliente or "0.0.0.0")
            + socket.inet_aton(self.ip)        # siaddr
            + pedido[24:28]                    # giaddr
            + pedido[28:44]                    # chaddr
            + b"\x00" * 192                    # sname + file
            + MAGIA
        )
        op = bytes([53, 1, tipo]) + bytes([54, 4]) + socket.inet_aton(self.ip)
        if tipo != NAK:
            op += bytes([51, 4]) + struct.pack("!I", DURACION)
            op += bytes([1, 4]) + socket.inet_aton(self.mascara)
            op += bytes([58, 4]) + struct.pack("!I", DURACION // 2)
            op += bytes([59, 4]) + struct.pack("!I", DURACION * 7 // 8)
        op += b"\xff"
        paquete = cabecera + op
        if len(paquete) < 300:
            paquete += b"\x00" * (300 - len(paquete))
        return paquete

    def procesar(self, datos):
        """Recibe un paquete DHCP y regresa la respuesta (bytes) o None."""
        if len(datos) < 240 or datos[0] != 1 or datos[236:240] != MAGIA:
            return None
        opciones = leer_opciones(datos)
        tipo = opciones.get(53, b"\x00")[0]
        mac = datos[28:28 + min(datos[2], 16)].hex(":")

        if tipo == DISCOVER:
            ip = self._ip_para(mac)
            if ip is None:
                return None
            self.registro(f"DHCP: ofrezco {ip} a {mac}")
            return self._respuesta(datos, OFFER, ip)

        if tipo == REQUEST:
            servidor = opciones.get(54)
            if servidor is not None and servidor != socket.inet_aton(self.ip):
                return None  # el celular eligió otro servidor
            pedida = opciones.get(50)
            pedida = socket.inet_ntoa(pedida) if pedida and len(pedida) == 4 else socket.inet_ntoa(datos[12:16])
            ip = self._ip_para(mac)
            if ip is not None and pedida == ip:
                self.registro(f"DHCP: {mac} ya tiene {ip}")
                return self._respuesta(datos, ACK, ip)
            self.registro(f"DHCP: rechazo {pedida} para {mac}")
            return self._respuesta(datos, NAK, None)

        if tipo in (RELEASE, DECLINE):
            self.prestamos.pop(mac, None)
        return None

    # ------------------------------------------------------------------- red
    def iniciar(self):
        if self._activo:
            return
        if self._hilo is not None and self._hilo.is_alive():
            # el hilo anterior todavía está cerrando; él mismo se reactiva
            self._activo = True
            return
        self._activo = True
        self._hilo = threading.Thread(target=self._bucle, daemon=True)
        self._hilo.start()

    def detener(self):
        self._activo = False
        s = self._socket
        if s is not None:
            try:
                s.close()
            except OSError:
                pass
        self.estado = "Apagado"

    def _bucle(self):
        while self._activo:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                # En Windows, un socket amarrado a la IP del adaptador recibe
                # los broadcast que llegan por ese adaptador y responde por él.
                s.bind((self.ip, 67))
            except OSError as e:
                s.close()
                if not ip_presente(self.ip):
                    self.estado = f"Esperando que el adaptador tenga la IP {self.ip}"
                else:
                    quien = quien_usa_puerto(67)
                    self.estado = (f"No pude abrir el puerto 67 ({e.__class__.__name__} {getattr(e, 'winerror', '') or e.errno}). "
                                   + (f"Lo tiene ocupado: {quien}. " if quien else "")
                                   + "Usa la Conexión compartida de Windows (ver CONECTAR.md) o apaga ese servicio.")
                time.sleep(3)
                continue
            self._socket = s
            s.settimeout(1.0)
            self.estado = f"Activo en {self.ip}, dando IPs a los celulares"
            ultima_revision = time.monotonic()
            while self._activo:
                try:
                    datos, _ = s.recvfrom(2048)
                except socket.timeout:
                    # Si desconectas el cable Windows quita la IP y el socket se
                    # queda "sordo": lo cerramos y volvemos a abrir cuando regrese.
                    if time.monotonic() - ultima_revision > 2:
                        ultima_revision = time.monotonic()
                        if not ip_presente(self.ip):
                            break
                    continue
                except OSError:
                    break  # la IP desapareció (cable desconectado, etc.)
                try:
                    respuesta = self.procesar(datos)
                    if respuesta:
                        s.sendto(respuesta, ("255.255.255.255", 68))
                except Exception as e:  # noqa: BLE001 - un paquete raro no debe tumbar el servidor
                    self.registro(f"DHCP: error {e}")
            try:
                s.close()
            except OSError:
                pass
            self._socket = None
            if self._activo:
                self.estado = "Reiniciando…"
                time.sleep(1)
