"""Prueba de la conexión por cable USB, con un adb falso.

No hace falta celular: un programa «adb» de mentira contesta `adb devices`
según un archivo de estado y anota cada orden que recibe. Así se revisa que la
PC espere al celular, explique el aviso pendiente, ponga los túneles de los dos
puertos, abra la app y los quite al terminar.
"""

import os
import stat
import sys
import tempfile
import time

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)

import usb_cable  # noqa: E402

fallas = 0


def revisar(nombre, ok, detalle=""):
    global fallas
    print(("OK    " if ok else "FALLA ") + nombre + (f"  ({detalle})" if detalle else ""), flush=True)
    if not ok:
        fallas += 1


# --------------------------------------------------- leer `adb devices`
texto = """* daemon not running; starting now at tcp:5037
* daemon started successfully
List of devices attached
4f2a91c3\tdevice
emulator-5554\tunauthorized

"""
d = usb_cable.leer_dispositivos(texto)
revisar("lee dos celulares y sus estados", d == [("4f2a91c3", "device"), ("emulator-5554", "unauthorized")], str(d))
revisar("lista vacía sin celular", usb_cable.leer_dispositivos("List of devices attached\n\n") == [])
revisar("explica el aviso pendiente", "Permitir" in usb_cable.explicar_estado("unauthorized"))

# --------------------------------------------------- adb falso
carpeta = tempfile.mkdtemp(prefix="adb_falso_")
estado = os.path.join(carpeta, "estado")
bitacora = os.path.join(carpeta, "bitacora")
adb = os.path.join(carpeta, "adb")
with open(adb, "w") as f:
    f.write(f"""#!{sys.executable}
import sys
args = sys.argv[1:]
with open({bitacora!r}, "a") as b:
    b.write(" ".join(args) + "\\n")
if args == ["devices"]:
    print("List of devices attached")
    print(open({estado!r}).read(), end="")
""")
os.chmod(adb, os.stat(adb).st_mode | stat.S_IEXEC)
if sys.platform == "win32":
    # Windows no corre un script por su primera línea: hace falta un .cmd.
    with open(adb + ".cmd", "w") as f:
        f.write(f'@"{sys.executable}" "{adb}" %*\n')
    adb = adb + ".cmd"


def poner_estado(texto):
    with open(estado, "w") as f:
        f.write(texto)


def ordenes():
    try:
        return open(bitacora).read().splitlines()
    except FileNotFoundError:
        return []


def esperar(condicion, segundos=8):
    fin = time.time() + segundos
    while time.time() < fin:
        if condicion():
            return True
        time.sleep(0.1)
    return False


poner_estado("")
anotado = []
t = usb_cable.TunelUSB(registro=anotado.append)
t.iniciar(adb)
revisar("sin celular pide conectarlo", esperar(lambda: "conecta el celular" in t.estado), t.estado)

poner_estado("ABC123\tunauthorized\n")
revisar("con el aviso pendiente lo explica", esperar(lambda: "Permitir" in t.estado), t.estado)
revisar("no pone túnel sin permiso", not any("reverse tcp" in o for o in ordenes()))

poner_estado("ABC123\tdevice\n")
revisar("con permiso queda listo", esperar(lambda: t.estado.startswith("listo por USB")), t.estado)
o = ordenes()
revisar("túnel del video (5000)", "-s ABC123 reverse tcp:5000 tcp:5000" in o)
revisar("túnel de archivos (5005)", "-s ABC123 reverse tcp:5005 tcp:5005" in o)
revisar("abre la app y le dice 127.0.0.1",
        any("am start -n com.puentevideo.app/.MainActivity --es conectar 127.0.0.1" in x for x in o))
revisar("lo anota en el registro", any("túnel listo" in a for a in anotado), str(anotado))

time.sleep(2.5)
revisar("no repite el túnel cada vuelta", sum("reverse tcp:5000" in x for x in ordenes()) == 1)

poner_estado("")
revisar("si se desconecta lo nota", esperar(lambda: "conecta el celular" in t.estado), t.estado)
poner_estado("ABC123\tdevice\n")
revisar("al regresar vuelve a poner el túnel",
        esperar(lambda: sum("reverse tcp:5000" in x for x in ordenes()) == 2))

t.detener()
revisar("al terminar quita los túneles",
        esperar(lambda: "-s ABC123 reverse --remove tcp:5000" in ordenes()
                and "-s ABC123 reverse --remove tcp:5005" in ordenes(), 6))
revisar("queda apagado", t.estado == "apagado" and not t.activo)

# --------------------------------------------------- anclaje USB
cmds = usb_cable.comandos_no_gastar_datos(["Ethernet 3"])
revisar("comandos de métrica para el anclaje",
        cmds == ['netsh interface ipv4 set interface "Ethernet 3" metric=9000',
                 'netsh interface ipv6 set interface "Ethernet 3" metric=9000'], str(cmds))

print()
print("TODO BIEN" if fallas == 0 else f"{fallas} FALLAS")
sys.exit(1 if fallas else 0)
