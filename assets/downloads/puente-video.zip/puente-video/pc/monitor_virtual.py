"""Que el celular sea una pantalla más de Windows, no una copia.

El programa **ya sabe mandar cualquier pantalla**: `CapturaPantalla(numero=N)`
toma el monitor que se le diga, y la ventana deja elegirlo. Lo que falta para
el segundo monitor no es mandar: es que esa segunda pantalla exista.

Windows solo deja arrastrar ventanas a pantallas que su propio sistema conoce,
y eso no se puede inventar desde un programa normal: hace falta que algo le
diga a Windows «hay otro monitor». Hay tres maneras, y conviene conocer las
tres porque la mejor depende de cuánto riesgo y cuánto dinero quiera uno:

1. **Un adaptador HDMI falso** (se vende como *dummy plug* o *emulador EDID*,
   cuesta poco). Se conecta a un puerto HDMI libre y Windows ve un monitor de
   verdad, porque para Windows **es** un monitor de verdad. Cero software, cero
   riesgo, funciona a la primera y con lo que este programa ya tiene. Es la
   opción que recomienda este archivo.

2. **Un controlador de pantalla virtual**, que crea un monitor por software.
   El más usado hoy es Virtual Display Driver (MIT, firmado), que se instala
   con `winget`. Funciona bien, pero es un controlador de pantalla: si algo
   sale mal, el síntoma es la pantalla en negro, y eso en una laptop que es la
   única que uno tiene da mucho más miedo que ahorrarse unos pesos.

3. **Otro programa que ya haga de pantalla virtual** y que esté instalado
   (spacedesk, por ejemplo). Si ya está, su pantalla aparece en la lista como
   cualquier otra y no hay nada que instalar.

Este archivo **no instala nada solo**. Mira qué hay, lo explica, y deja el
comando listo para que la persona lo corra si quiere. Instalar un controlador
de pantalla sin que su dueño lo haya pedido explícitamente es justo la clase
de cosa que no se hace en la computadora de alguien más.
"""

import subprocess
import sys

ES_WINDOWS = sys.platform == "win32"
SIN_VENTANA = 0x08000000 if ES_WINDOWS else 0

# El de Virtual Display Driver. Se enseña, no se corre solo.
COMANDO_WINGET = "winget install --id=VirtualDrivers.Virtual-Display-Driver -e"

# Nombres que delatan a un monitor que no es físico. Se buscan en el nombre que
# Windows le pone al adaptador de video.
PISTAS_VIRTUALES = (
    ("virtual display driver", "Virtual Display Driver"),
    ("mikethetech", "Virtual Display Driver"),
    ("idd", "controlador de pantalla indirecta"),
    ("spacedesk", "spacedesk"),
    ("usb mobile monitor", "Amyuni USB Mobile Monitor"),
    ("amyuni", "Amyuni USB Mobile Monitor"),
    ("parsec", "Parsec VDD"),
    ("duet", "Duet Display"),
)


def _correr(comando, segundos=25):
    if not ES_WINDOWS:
        return False, ""
    try:
        r = subprocess.run(comando, capture_output=True, text=True, timeout=segundos,
                           creationflags=SIN_VENTANA)
        return r.returncode == 0, (r.stdout or "") + (r.stderr or "")
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def pantallas():
    """Las pantallas que Windows reconoce, con su posición y tamaño.

    Devuelve una lista de diccionarios con `numero` (el que entiende
    `CapturaPantalla`), `x`, `y`, `ancho`, `alto` y `principal`. La posición
    importa: es la que convierte un toque en el celular en una posición del
    cursor en Windows.
    """
    try:
        import mss
    except ImportError:
        return []
    try:
        with mss.mss() as sct:
            salida = []
            # El 0 de mss es el escritorio completo; los monitores van del 1.
            for i, m in enumerate(sct.monitors[1:], start=1):
                salida.append({
                    "numero": i,
                    "x": m["left"],
                    "y": m["top"],
                    "ancho": m["width"],
                    "alto": m["height"],
                    "principal": m["left"] == 0 and m["top"] == 0,
                })
            return salida
    except Exception:  # noqa: BLE001
        return []


def adaptadores_de_video():
    """Los adaptadores de video que Windows tiene, por nombre.

    Se usa para distinguir «hay dos monitores porque conectaste uno» de «hay
    dos monitores porque hay una pantalla virtual», que para el usuario es una
    diferencia importante aunque el programa los trate igual.
    """
    if not ES_WINDOWS:
        return []
    ok, texto = _correr([
        "powershell", "-NoProfile", "-Command",
        "Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name",
    ])
    if not ok:
        return []
    return [l.strip() for l in texto.splitlines() if l.strip()]


def pantalla_virtual_instalada():
    """(True/False, cómo se llama) si se ve un controlador de pantalla virtual."""
    for nombre in adaptadores_de_video():
        bajo = nombre.lower()
        for pista, bonito in PISTAS_VIRTUALES:
            if pista in bajo:
                return True, bonito
    return False, ""


def hay_winget():
    ok, _ = _correr(["winget", "--version"], segundos=10)
    return ok


def revisar():
    """Todo lo que la ventana necesita saber para enseñar la sección.

    Devuelve un diccionario con:
      pantallas        lista de pantallas
      cuantas          cuántas hay
      extendible       True si ya hay a dónde extender (más de una pantalla)
      virtual          True si una de ellas parece virtual
      virtual_nombre   cuál programa la pone
      winget           si se puede ofrecer la instalación con un clic
      consejo          una frase para enseñar tal cual
    """
    lista = pantallas()
    virtual, nombre = pantalla_virtual_instalada()
    datos = {
        "pantallas": lista,
        "cuantas": len(lista),
        "extendible": len(lista) > 1,
        "virtual": virtual,
        "virtual_nombre": nombre,
        "winget": hay_winget() if ES_WINDOWS else False,
        "comando": COMANDO_WINGET,
    }
    if len(lista) > 1 and virtual:
        datos["consejo"] = (
            f"Ya hay {len(lista)} pantallas y una la pone {nombre}. Elige abajo cuál "
            f"mandarle al celular y, en la configuración de pantalla de Windows, "
            f"déjala en «Extender».")
    elif len(lista) > 1:
        datos["consejo"] = (
            f"Ya hay {len(lista)} pantallas. Elige cuál mandarle al celular. Si quieres "
            f"que el celular sea una pantalla aparte y no una copia, en la configuración "
            f"de pantalla de Windows pon esa pantalla en «Extender».")
    else:
        datos["consejo"] = (
            "Solo hay una pantalla, así que por ahora el celular únicamente puede copiarla. "
            "Para que sea una pantalla aparte, Windows necesita creer que hay otro monitor.")
    return datos


def pasos_para_conseguir_pantalla():
    """Las tres maneras, en el orden en que conviene intentarlas.

    Texto, no acciones: la ventana lo enseña y la persona decide. Ninguna de
    estas opciones se ejecuta sola.
    """
    return [
        {
            "titulo": "Un adaptador HDMI falso (lo más seguro)",
            "riesgo": "ninguno",
            "cuerpo": (
                "Se vende como «dummy plug HDMI» o «emulador EDID» y cuesta poco. Lo conectas "
                "a un puerto HDMI libre y Windows ve un monitor de verdad, porque para Windows "
                "lo es. No instala nada, no se puede echar a perder, y funciona con lo que este "
                "programa ya tiene. Elige la resolución al comprarlo (uno de 1080p está bien)."),
            "accion": None,
        },
        {
            "titulo": "Un controlador de pantalla virtual (gratis, con cuidado)",
            "riesgo": "medio",
            "cuerpo": (
                "Virtual Display Driver crea un monitor por software. Es de código abierto, "
                "licencia MIT, y está firmado, así que se instala sin poner Windows en modo de "
                "pruebas. Pide permiso de administrador.\n\n"
                "Antes de darle: es un controlador de pantalla. Si algo sale mal el síntoma es "
                "la pantalla en negro, y se arregla entrando en modo seguro (F8 o F4 al "
                "arrancar) y desinstalándolo desde el Administrador de dispositivos. Si esta "
                "es tu única computadora, vale la pena leer eso dos veces o irte por el "
                "adaptador de arriba."),
            "accion": COMANDO_WINGET,
        },
        {
            "titulo": "Algo que ya tengas instalado",
            "riesgo": "ninguno",
            "cuerpo": (
                "Si ya tienes spacedesk, Duet o algo parecido, su pantalla virtual aparece en "
                "la lista de aquí abajo como cualquier otra y no hay nada que instalar. "
                "Enciéndela en ese programa y refresca esta ventana."),
            "accion": None,
        },
    ]
