"""La PC se prepara sola para que el celular conecte sin que nadie configure.

Al abrir el programa hace, en silencio y sin pedir administrador:

  * abre el firewall para Puente Video (si Windows deja);
  * busca cuál adaptador es el del cable;
  * avisa si ese adaptador quedó con una IP fija que estorba;
  * lee las dos IP de la conexión y dice cuál es cuál.

Sobre lo último: cuando el celular comparte internet por Ethernet, el celular
es el que reparte las IP, así que la PC recibe la suya por DHCP y la **puerta
de enlace** de ese adaptador es, justamente, la IP del celular. Por eso la PC
puede decir las dos IP sin preguntarle nada al celular y antes de que la app se
conecte. Eso es lo que hace `pareja_de_ips()`.

Lo que sí necesita permisos (cambiar la IP de un adaptador) no se hace solo:
se deja escrito qué hay que tocar, y el botón «Arreglar la conexión» lo hace
pidiendo el permiso una sola vez.
"""

import ipaddress
import re
import subprocess
import sys

import psutil

ES_WINDOWS = sys.platform == "win32"
SIN_VENTANA = 0x08000000 if ES_WINDOWS else 0


def _correr(comando, elevar=False):
    """Corre un comando. Devuelve (salió bien, texto)."""
    if not ES_WINDOWS:
        return False, "solo en Windows"
    try:
        r = subprocess.run(comando, capture_output=True, text=True, timeout=20,
                           creationflags=SIN_VENTANA)
        return r.returncode == 0, (r.stdout or r.stderr or "").strip()
    except Exception as e:  # noqa: BLE001
        return False, str(e)


# ---------------------------------------------------------------- adaptadores
def _es_inalambrico(nombre):
    n = nombre.lower()
    return any(p in n for p in ("wi-fi", "wifi", "wlan", "inalámbr", "inalambr"))


def _es_virtual(nombre):
    n = nombre.lower()
    return any(p in n for p in ("tailscale", "zerotier", "vmware", "virtualbox",
                                "hyper-v", "loopback", "bluetooth", "vethernet",
                                "tap", "tun", "npcap"))


def adaptador_del_cable():
    """El adaptador que parece ser el cable al celular.

    Se prefiere uno de cable, encendido, sin puerta de enlace a internet.
    Devuelve (nombre, ip) o (None, None).
    """
    candidatos = []
    estados = psutil.net_if_stats()
    for nombre, direcciones in psutil.net_if_addrs().items():
        estado = estados.get(nombre)
        if estado is not None and not estado.isup:
            continue
        if _es_virtual(nombre) or _es_inalambrico(nombre):
            continue
        for d in direcciones:
            if d.family.name != "AF_INET" or d.address.startswith("127."):
                continue
            candidatos.append((nombre, d.address))
    if not candidatos:
        return None, None
    # El del cable directo suele tener una IP privada rara (no la de la casa)
    def rareza(par):
        try:
            ip = ipaddress.ip_address(par[1])
        except ValueError:
            return 0
        if ip.is_link_local:      # 169.254.x.x: nadie repartió, es cable directo
            return 3
        if str(ip).startswith("192.168.1.") or str(ip).startswith("192.168.0."):
            return 0              # casi seguro el módem de la casa
        return 2
    candidatos.sort(key=rareza, reverse=True)
    return candidatos[0]


RE_IPV4 = re.compile(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b")
# Windows contesta en el idioma del sistema, así que se buscan las dos formas.
PALABRAS_GATEWAY = ("gateway", "enlace", "puerta")


def puerta_de_enlace(nombre):
    """La IP de la puerta de enlace de ese adaptador, o None.

    En una conexión por cable con el celular compartiendo internet, esta IP
    **es la del celular**. Se lee sin permisos de administrador.
    """
    if not ES_WINDOWS:
        return _puerta_de_enlace_linux(nombre)
    for comando in (["netsh", "interface", "ip", "show", "config", f"name={nombre}"],
                    ["netsh", "interface", "ip", "show", "address", f"name={nombre}"]):
        ok, texto = _correr(comando)
        if not ok:
            continue
        for linea in texto.splitlines():
            baja = linea.lower()
            if not any(p in baja for p in PALABRAS_GATEWAY):
                continue
            for encontrada in RE_IPV4.findall(linea):
                # netsh pone la métrica en la línea siguiente, no en esta, pero
                # por si acaso se descartan el 0.0.0.0 y las máscaras.
                if encontrada != "0.0.0.0" and not encontrada.startswith("255."):
                    return encontrada
    return None


def _puerta_de_enlace_linux(nombre):
    """Lo mismo en Linux, leyendo /proc/net/route. Sirve para probar fuera de Windows."""
    try:
        with open("/proc/net/route", encoding="ascii") as f:
            next(f, None)
            for linea in f:
                partes = linea.split()
                if len(partes) < 3 or partes[0] != nombre or partes[1] != "00000000":
                    continue
                crudo = int(partes[2], 16)
                if crudo == 0:
                    continue
                octetos = [(crudo >> d) & 0xFF for d in (0, 8, 16, 24)]
                return ".".join(str(o) for o in octetos)
    except (OSError, ValueError, StopIteration):
        pass
    return None


def pareja_de_ips():
    """Las dos IP de la conexión por cable, para enseñarlas juntas.

    Devuelve un diccionario con:
      adaptador  nombre del adaptador del cable, o None si no hay cable
      ip_pc      la IP de esta PC en ese cable
      ip_celular la IP del celular, si el celular es el que reparte las IP
      quien      'celular' si el celular reparte, 'pc' si reparte la PC,
                 None si todavía no se sabe
    """
    nombre, ip = adaptador_del_cable()
    if nombre is None:
        return {"adaptador": None, "ip_pc": None, "ip_celular": None, "quien": None}
    enlace = puerta_de_enlace(nombre)
    quien = None
    if enlace and enlace != ip:
        # Hay quien reparte y no somos nosotros: es el celular.
        quien = "celular"
    elif ip and not ip.startswith("169.254"):
        # Tenemos IP pero nadie nos la dio: la pusimos nosotros, repartimos.
        quien = "pc"
    return {"adaptador": nombre, "ip_pc": ip, "ip_celular": enlace, "quien": quien}


def ip_fija_estorbando(nombre):
    """True si ese adaptador tiene IP fija (DHCP apagado), que suele estorbar."""
    ok, texto = _correr(["netsh", "interface", "ip", "show", "config", f"name={nombre}"])
    if not ok:
        return False
    for linea in texto.splitlines():
        if "DHCP" in linea.upper():
            return ":" in linea and linea.split(":", 1)[1].strip().lower() in ("no", "false")
    return False


# ------------------------------------------------------------------- firewall
def abrir_firewall(puertos=(5000, 5001, 5003, 5004, 5005)):
    """Deja pasar nuestros puertos. Sin administrador suele fallar, y no pasa nada."""
    hechos = []
    for puerto in puertos:
        for protocolo in ("TCP", "UDP"):
            regla = f"Puente Video {protocolo} {puerto}"
            ok, _ = _correr(["netsh", "advfirewall", "firewall", "add", "rule",
                             f"name={regla}", "dir=in", "action=allow",
                             f"protocol={protocolo}", f"localport={puerto}"])
            if ok:
                hechos.append(regla)
    return hechos


# ------------------------------------------------------------------- arreglar
def dejar_en_automatico(nombre):
    """Le quita la IP fija al adaptador. Necesita administrador."""
    ok1, t1 = _correr(["netsh", "interface", "ip", "set", "address",
                       f"name={nombre}", "source=dhcp"])
    ok2, _ = _correr(["netsh", "interface", "ip", "set", "dnsservers",
                      f"name={nombre}", "source=dhcp"])
    return ok1 or "ya está habilitado" in t1.lower() or "already enabled" in t1.lower(), t1


def revisar():
    """Qué encontró y qué conviene hacer. Para enseñarlo en la ventana."""
    nombre, ip = adaptador_del_cable()
    if nombre is None:
        return {"adaptador": None, "ip": None, "aviso":
                "No veo ningún cable conectado. Conecta el Ethernet entre la PC y el celular."}
    aviso = ""
    if ip_fija_estorbando(nombre):
        aviso = (f"«{nombre}» tiene una IP fija puesta a mano. Si el celular no conecta, "
                 f"usa «Arreglar la conexión» para dejarlo en automático.")
    return {"adaptador": nombre, "ip": ip, "aviso": aviso}
