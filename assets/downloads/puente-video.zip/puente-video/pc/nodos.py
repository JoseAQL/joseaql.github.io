"""Nodos Puente Video: receptores Ethernet → HDMI (STM32) en un switch.

Cada nodo es un servidor TCP (puerto 5000) que solo recibe video y se anuncia
por UDP (puerto 5001) con "PUENTE-NODO|id|ancho|alto|puerto". Desde aquí la PC
le manda a cada pantalla algo distinto: su cámara, la del celular, la pantalla
completa o un pedazo de ella (pared de video) o un patrón para ubicarla.
"""

import socket
import struct
import threading
import time

import cv2
import numpy as np

try:
    import mss
except ImportError:
    mss = None

PUERTO_ANUNCIO = 5001
TIPO_JPEG, TIPO_TEXTO, TIPO_ACUSE = 1, 2, 3
MAX_EN_CAMINO = 2

FUENTES = [
    "Nada",
    "Igual que al celular",
    "Video del celular",
    "Pantalla completa",
    "Pantalla ½ izquierda", "Pantalla ½ derecha",
    "Pantalla ⅓ 1", "Pantalla ⅓ 2", "Pantalla ⅓ 3",
    "Pantalla ¼ 1", "Pantalla ¼ 2", "Pantalla ¼ 3", "Pantalla ¼ 4",
    "Patrón de prueba",
]
PARTES = {"½ izquierda": (0, 2), "½ derecha": (1, 2),
          "⅓ 1": (0, 3), "⅓ 2": (1, 3), "⅓ 3": (2, 3),
          "¼ 1": (0, 4), "¼ 2": (1, 4), "¼ 3": (2, 4), "¼ 4": (3, 4)}


def _mensaje(tipo, datos=b""):
    return struct.pack("!BI", tipo, len(datos)) + datos


def _recibir_exacto(sock, n):
    datos = bytearray()
    while len(datos) < n:
        r = sock.recv(n - len(datos))
        if not r:
            raise ConnectionError("el nodo cerró la conexión")
        datos += r
    return bytes(datos)


def ajustar(cuadro, ancho, alto):
    """Escala sin deformar y rellena de negro hasta ancho x alto exactos."""
    h, w = cuadro.shape[:2]
    escala = min(ancho / w, alto / h)
    nw, nh = max(1, int(w * escala)), max(1, int(h * escala))
    chico = cv2.resize(cuadro, (nw, nh), interpolation=cv2.INTER_AREA if escala < 1 else cv2.INTER_LINEAR)
    if (nw, nh) == (ancho, alto):
        return chico
    lienzo = np.zeros((alto, ancho, 3), np.uint8)
    x, y = (ancho - nw) // 2, (alto - nh) // 2
    lienzo[y:y + nh, x:x + nw] = chico
    return lienzo


def patron(ancho, alto, id_nodo, ip):
    img = np.full((alto, ancho, 3), (40, 32, 24), np.uint8)
    colores = [(0, 0, 255), (0, 255, 0), (255, 0, 0), (0, 255, 255), (255, 0, 255), (255, 255, 0), (255, 255, 255)]
    w = ancho // len(colores)
    for i, c in enumerate(colores):
        cv2.rectangle(img, (i * w, 0), ((i + 1) * w, alto // 6), c, -1)
    cv2.rectangle(img, (2, 2), (ancho - 3, alto - 3), (218, 198, 38), 4)
    cv2.putText(img, str(id_nodo), (ancho // 2 - alto // 6, alto * 2 // 3), cv2.FONT_HERSHEY_SIMPLEX,
                alto / 120, (255, 255, 255), max(2, alto // 60), cv2.LINE_AA)
    cv2.putText(img, f"{ip}  {ancho}x{alto}", (20, alto - 30), cv2.FONT_HERSHEY_SIMPLEX,
                alto / 600, (200, 200, 200), 2, cv2.LINE_AA)
    return img


class PantallaCompartida:
    """Captura la pantalla de la PC una sola vez para todos los nodos que la piden."""

    def __init__(self):
        self.ultimo = None
        self.pedido = 0.0
        self._hilo = None

    def obtener(self):
        self.pedido = time.time()
        if mss is not None and (self._hilo is None or not self._hilo.is_alive()):
            self._hilo = threading.Thread(target=self._bucle, daemon=True)
            self._hilo.start()
        return self.ultimo

    def _bucle(self):
        with mss.mss() as pantalla:
            while time.time() - self.pedido < 3:  # se apaga si nadie la pide
                inicio = time.perf_counter()
                try:
                    bruto = np.asarray(pantalla.grab(pantalla.monitors[1]))
                    self.ultimo = cv2.cvtColor(bruto, cv2.COLOR_BGRA2BGR)
                except Exception:  # noqa: BLE001
                    time.sleep(0.5)
                resto = 1 / 30 - (time.perf_counter() - inicio)
                if resto > 0:
                    time.sleep(resto)
        self.ultimo = None


class Nodo:
    """Conexión de la PC con un nodo. Solo se conecta si su fuente no es «Nada»,
    así el nodo queda libre para que el celular le mande video directo."""

    def __init__(self, ip, puerto, id_nodo, ancho, alto, fuentes):
        self.ip, self.puerto = ip, puerto
        self.id, self.ancho, self.alto = id_nodo, ancho, alto
        self.fuentes = fuentes          # dict nombre -> función que regresa un cuadro BGR o None
        self.fuente = "Nada"
        self.calidad = 75
        self.visto = time.time()
        self.estado = "libre"
        self.enviados = 0
        self.fps = 0
        self._pedir_identificar = False
        self._cond = threading.Condition()
        self._en_camino = 0
        threading.Thread(target=self._bucle, daemon=True).start()

    def identificar(self):
        self._pedir_identificar = True

    def _bucle(self):
        while True:
            if self.fuente == "Nada":
                self.estado = "libre"
                time.sleep(0.3)
                continue
            try:
                self._sesion()
            except (OSError, ConnectionError, struct.error) as e:
                self.estado = f"sin conexión ({e.__class__.__name__})"
                time.sleep(1.5)

    def _lector(self, s):
        try:
            while True:
                tipo, largo = struct.unpack("!BI", _recibir_exacto(s, 5))
                datos = _recibir_exacto(s, largo) if largo else b""
                if tipo == TIPO_ACUSE:
                    with self._cond:
                        self._en_camino = max(0, self._en_camino - 1)
                        self._cond.notify_all()
                elif tipo == TIPO_TEXTO:
                    texto = datos.decode("utf-8", "replace")
                    # "HOLA|NODO 3 1024x600"
                    if texto.startswith("HOLA|NODO "):
                        partes = texto[10:].split()
                        if len(partes) == 2 and "x" in partes[1]:
                            w, h = partes[1].split("x")
                            self.ancho, self.alto = int(w), int(h)
        except (OSError, ConnectionError, struct.error, ValueError):
            pass
        finally:
            with self._cond:
                self._en_camino = -1  # avisa al que manda que se cayó
                self._cond.notify_all()

    def _sesion(self):
        s = socket.create_connection((self.ip, self.puerto), timeout=3)
        s.settimeout(None)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 256 * 1024)
        with self._cond:
            self._en_camino = 0
        threading.Thread(target=self._lector, args=(s,), daemon=True).start()
        s.sendall(_mensaje(TIPO_TEXTO, ("HOLA|" + socket.gethostname()).encode()))
        self.estado = "conectado"
        cuenta, t0 = 0, time.time()
        try:
            while self.fuente != "Nada":
                if self._pedir_identificar:
                    self._pedir_identificar = False
                    s.sendall(_mensaje(TIPO_TEXTO, b"IDENTIFICAR"))
                with self._cond:
                    while self._en_camino >= MAX_EN_CAMINO:
                        self._cond.wait(1.0)
                    if self._en_camino < 0:
                        raise ConnectionError("se cayó")
                inicio = time.perf_counter()
                cuadro = self._cuadro()
                if cuadro is not None:
                    ok, jpeg = cv2.imencode(".jpg", ajustar(cuadro, self.ancho, self.alto),
                                            [cv2.IMWRITE_JPEG_QUALITY, int(self.calidad)])
                    if ok:
                        with self._cond:
                            self._en_camino += 1
                        s.sendall(_mensaje(TIPO_JPEG, jpeg.tobytes()))
                        cuenta += 1
                        self.enviados += 1
                if time.time() - t0 >= 1:
                    self.fps, cuenta, t0 = round(cuenta / (time.time() - t0)), 0, time.time()
                resto = 1 / 30 - (time.perf_counter() - inicio)
                if resto > 0:
                    time.sleep(resto)
        finally:
            self.fps = 0
            try:
                s.close()
            except OSError:
                pass

    def _cuadro(self):
        f = self.fuente
        if f == "Patrón de prueba":
            return patron(self.ancho, self.alto, self.id, self.ip)
        if f.startswith("Pantalla"):
            img = self.fuentes["pantalla"]()
            if img is None or f == "Pantalla completa":
                return img
            k, n = PARTES[f[len("Pantalla "):]]
            w = img.shape[1]
            return img[:, k * w // n:(k + 1) * w // n]
        if f == "Igual que al celular":
            return self.fuentes["celular_sale"]()
        if f == "Video del celular":
            return self.fuentes["celular_entra"]()
        return None


class Descubridor:
    """Escucha los anuncios de los nodos y mantiene la lista."""

    def __init__(self, fuentes):
        self.fuentes = fuentes
        self.nodos = {}   # "ip:puerto" -> Nodo
        self.error = ""
        threading.Thread(target=self._bucle, daemon=True).start()

    def agregar(self, ip, puerto=5000, id_nodo=0, ancho=800, alto=600):
        if ":" in ip:
            ip, puerto = ip.rsplit(":", 1)[0], int(ip.rsplit(":", 1)[1])
        clave = f"{ip}:{puerto}"
        if clave not in self.nodos:
            self.nodos[clave] = Nodo(ip, puerto, id_nodo, ancho, alto, self.fuentes)
        self.nodos[clave].visto = time.time()
        return self.nodos[clave]

    def _bucle(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("", PUERTO_ANUNCIO))
        except OSError as e:
            self.error = f"No pude escuchar anuncios en el puerto {PUERTO_ANUNCIO}: {e}"
            return
        while True:
            try:
                datos, (ip, _) = s.recvfrom(256)
                p = datos.decode("ascii", "replace").strip().split("|")
                if len(p) == 5 and p[0] == "PUENTE-NODO":
                    nodo = self.agregar(ip, int(p[4]), int(p[1]), int(p[2]), int(p[3]))
                    nodo.id = int(p[1])
            except (OSError, ValueError):
                time.sleep(0.2)

    def ordenados(self):
        return sorted(self.nodos.values(), key=lambda n: (n.id, n.ip, n.puerto))
