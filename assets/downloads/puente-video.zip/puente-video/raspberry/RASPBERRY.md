# Puente Video en Raspberry Pi (la app completa)

La Raspberry Pi corre **la misma app que la PC**, así que hace todo lo que hace la PC con el celular por el cable Ethernet:

| Función | En la Raspberry Pi |
|---|---|
| Recibir el video del celular (cámara o pantalla) | Sí |
| Mandarle video al celular: el escritorio de la Pi | Sí |
| Mandarle video al celular: webcam USB o capturadora HDMI USB | Sí (aparecen como «Cámara 0…3») |
| Mandarle video al celular: módulo de cámara de la Pi (cinta) | No directo: usa una webcam USB |
| Archivos de ida y vuelta, con reanudación | Sí (llegan a `~/Downloads`) |
| Tocar el celular mueve el ratón de la Pi | Sí (necesita X11, el instalador lo deja así) |
| Consola de pantallas HDMI (nodos) | Sí |
| Darle IP al celular (DHCP) | Mejor que la reparta el celular («Compartir vía Ethernet») |

Si lo que quieres es solo **una pantalla** que reciba video y lo muestre por HDMI, sin escritorio, usa el nodo de [`nodo/linux`](../nodo/linux/LINUX.md).

## Lo que necesitas

- Raspberry Pi 4B o 5 con **Raspberry Pi OS Bookworm con escritorio**.
- Cable Ethernet al celular (adaptador USB‑Ethernet en el celular).
- Monitor, teclado y ratón para la Pi, o acceso por VNC.

## Instalación

1. Descarga `PuenteVideo-raspberry.zip` del Release «Puente Video» del repositorio, y descomprímelo en la Pi. También sirve clonar el repo.
2. En una terminal, dentro de la carpeta `raspberry`:
   ```
   sudo sh instalar_app.sh
   ```
3. Si el instalador cambió el escritorio de Wayland a X11, reinicia: `sudo reboot`.
4. Abre **Puente Video** desde el menú (Sonido y video).
5. En el celular: conecta el cable, activa «Compartir vía Ethernet» y toca **Conectar** en la app. La Pi aparece sola; si no, escribe la IP que muestra la app de la Pi.

## Por qué X11 y no Wayland

Raspberry Pi OS Bookworm usa Wayland en la Pi 4 y la Pi 5. En Wayland ninguna app puede ver la pantalla completa ni mover el ratón de las demás, por seguridad, así que no se podría mandar el escritorio al celular ni controlarlo desde el celular. El instalador corre `raspi-config nonint do_wayland W1`, que es lo mismo que **raspi-config › Advanced Options › Wayland › X11**. Para regresar: el mismo menú, opción Wayfire o labwc.

## Estado

- **Probado aquí, en Linux con pantalla virtual (Xvfb):** la app arranca, un celular simulado le manda video y recibe el escritorio, y los toques mueven el ratón de X11 a la posición correcta, incluidas las esquinas. La prueba es `pc/prueba_raspberry.py` y corre en cada cambio en GitHub Actions.
- **Falta probar en una Raspberry Pi real:** los fps reales (se espera 720p a 15‑30 fps en una Pi 4; 1080p será más lento), y la capturadora HDMI USB con tu modelo.
