#!/bin/sh
# Instala la app completa de Puente Video (la misma de la PC) en una Raspberry Pi
# con escritorio: video de ida y vuelta con el celular por Ethernet, archivos,
# control del ratón desde el celular y la consola de nodos HDMI.
#
#   sudo sh instalar_app.sh
#
# Sirve en Raspberry Pi 4B/5 con Raspberry Pi OS Bookworm (con escritorio) y en
# cualquier Debian/Ubuntu con escritorio X11.
set -e

DESTINO=/opt/puente-video
USUARIO="${SUDO_USER:-$(id -un)}"
AQUI="$(cd "$(dirname "$0")" && pwd)"
CODIGO="$AQUI/../pc"
[ -f "$AQUI/pc/puente_video.py" ] && CODIGO="$AQUI/pc"   # dentro del .zip del Release

if [ "$(id -u)" -ne 0 ]; then
  echo "Corre con sudo: sudo sh instalar_app.sh"
  exit 1
fi
if [ ! -f "$CODIGO/puente_video.py" ]; then
  echo "No encuentro puente_video.py junto a este instalador."
  exit 1
fi

echo "== Instalando dependencias"
apt-get update -qq
apt-get install -y -qq python3 python3-tk python3-opencv python3-numpy python3-pil \
  python3-pil.imagetk python3-psutil python3-pip libxtst6
# mss y qrcode no vienen en apt de Bookworm; pip pide este permiso en Bookworm
pip3 install --break-system-packages mss qrcode 2>/dev/null || pip3 install mss qrcode

echo "== Copiando el programa a $DESTINO"
mkdir -p "$DESTINO"
cp "$CODIGO"/*.py "$DESTINO/"
[ -f "$CODIGO/icono.ico" ] && cp "$CODIGO/icono.ico" "$DESTINO/"
rm -f "$DESTINO"/prueba_*.py

cat > /usr/share/applications/puente-video.desktop <<EOF
[Desktop Entry]
Type=Application
Name=Puente Video
Comment=Video, archivos y control con el celular por cable Ethernet
Exec=python3 $DESTINO/puente_video.py
Terminal=false
Categories=AudioVideo;Network;
EOF

# La captura de pantalla y el control del ratón necesitan X11. Raspberry Pi OS
# Bookworm arranca con Wayland en Pi 4 y Pi 5, y en Wayland ninguna app puede
# ver la pantalla ni mover el ratón de las demás.
if command -v raspi-config >/dev/null 2>&1; then
  echo "== Dejando el escritorio en X11 (hace falta para mandar la pantalla y el control)"
  # do_wayland W1 = X11. Si ya estaba en X11 no cambia nada.
  if raspi-config nonint do_wayland W1; then
    CAMBIO_X11=1
  else
    echo "No pude cambiarlo solo: sudo raspi-config > Advanced Options > Wayland > X11"
  fi
fi

echo
echo "Listo. Abre «Puente Video» desde el menú (Sonido y video), o corre:"
echo "  python3 $DESTINO/puente_video.py"
[ -n "$CAMBIO_X11" ] && echo "Si estabas en Wayland, reinicia para que tome X11: sudo reboot"
exit 0
