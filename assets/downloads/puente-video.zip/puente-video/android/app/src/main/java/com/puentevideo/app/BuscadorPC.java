package com.puentevideo.app;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;

/**
 * Escucha el aviso que manda la PC para conectarse solo, sin teclear la IP.
 *
 * La PC grita una vez por segundo, por todos sus adaptadores:
 *
 *     PUENTE-PC|&lt;ip&gt;|&lt;puerto&gt;|&lt;nombre&gt;
 *
 * Escucha en todas las redes a la vez (cable y Wi-Fi), así funciona
 * igual con el cable directo que con la red de la casa.
 */
public class BuscadorPC {

    public static final int PUERTO = 5003;

    public interface Oyente {
        void encontrada(String ip, int puerto, String nombre);
    }

    private volatile boolean activo = false;
    private DatagramSocket socket;
    private Thread hilo;

    public void iniciar(final Oyente oyente) {
        if (activo) return;
        activo = true;
        hilo = new Thread(() -> {
            while (activo) {
                try {
                    // MulticastSocket para oír también el aviso por IPv6 (ff02::1),
                    // que es el que funciona en cable directo sin que nadie dé IP.
                    MulticastSocket multi = new MulticastSocket(null);
                    multi.setReuseAddress(true);
                    multi.bind(new InetSocketAddress(PUERTO));
                    multi.setBroadcast(true);
                    socket = multi;
                    unirseATodosLosNodos(multi);
                    byte[] buzon = new byte[256];
                    while (activo) {
                        DatagramPacket paquete = new DatagramPacket(buzon, buzon.length);
                        socket.receive(paquete);
                        String texto = new String(paquete.getData(), 0, paquete.getLength(),
                                StandardCharsets.UTF_8);
                        String[] partes = texto.split("\\|");
                        if (partes.length < 3 || !"PUENTE-PC".equals(partes[0])) continue;
                        String ip = partes[1].trim();
                        int puerto;
                        try {
                            puerto = Integer.parseInt(partes[2].trim());
                        } catch (NumberFormatException e) {
                            continue;
                        }
                        // La IP que vale es la del remitente: es la que sí alcanzamos.
                        String remitente = paquete.getAddress().getHostAddress();
                        if (remitente != null && !remitente.isEmpty()) ip = remitente;
                        String nombre = partes.length > 3 ? partes[3].trim() : "PC";
                        oyente.encontrada(ip, puerto, nombre);
                    }
                } catch (Exception e) {
                    // el puerto puede estar ocupado un momento: se reintenta
                    cerrarSocket();
                    if (!activo) break;
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException ie) {
                        break;
                    }
                }
            }
            cerrarSocket();
        }, "buscador-pc");
        hilo.setDaemon(true);
        hilo.start();
    }

    /** Se apunta al grupo «todos los nodos» de IPv6 en cada cable que haya. */
    private void unirseATodosLosNodos(MulticastSocket multi) {
        try {
            InetAddress grupo = InetAddress.getByName("ff02::1");
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                try {
                    if (!ni.isUp() || ni.isLoopback() || !ni.supportsMulticast()) continue;
                    multi.joinGroup(new InetSocketAddress(grupo, PUERTO), ni);
                } catch (Exception ignorado) {
                }
            }
        } catch (Exception ignorado) {
        }
    }

    public void detener() {
        activo = false;
        cerrarSocket();
    }

    private void cerrarSocket() {
        DatagramSocket s = socket;
        socket = null;
        if (s != null) {
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }
}
