package com.puentevideo.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.DisplayMetrics;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Manda la pantalla del celular en vivo (como un "espejo"), aunque la app
 * quede en segundo plano. Usa MediaProjection: Android pide permiso cada vez
 * y muestra una notificación mientras se comparte.
 */
public class ServicioPantalla extends Service {

    public static final String EXTRA_CODIGO = "codigo";
    public static final String EXTRA_DATOS = "datos";
    public static final String ACCION_DETENER = "com.puentevideo.app.DETENER";
    private static final String CANAL = "pantalla";

    public static volatile boolean activo = false;
    public static final AtomicInteger enviados = new AtomicInteger();

    private MediaProjection proyeccion;
    private VirtualDisplay pantallaVirtual;
    private ImageReader lector;
    private HandlerThread hilo;
    private long ultimo = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACCION_DETENER.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        // Android 14 exige estar en primer plano ANTES de pedir la proyección.
        Notification aviso = crearAviso();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, aviso, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, aviso);
        }

        int codigo = intent.getIntExtra(EXTRA_CODIGO, 0);
        Intent datos = intent.getParcelableExtra(EXTRA_DATOS);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null || datos == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            proyeccion = mpm.getMediaProjection(codigo, datos);
        } catch (Exception e) {
            proyeccion = null;
        }
        if (proyeccion == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        hilo = new HandlerThread("pantalla");
        hilo.start();
        Handler manejador = new Handler(hilo.getLooper());
        proyeccion.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopSelf(); // el usuario la detuvo desde Android
            }
        }, manejador);

        DisplayMetrics m = getResources().getDisplayMetrics();
        int w = m.widthPixels, h = m.heightPixels;
        int lado = Compartido.ladoLargoPantalla;
        float escala = Math.min(1f, (float) lado / Math.max(w, h));
        w = Math.max(2, Math.round(w * escala) & ~1);
        h = Math.max(2, Math.round(h * escala) & ~1);

        lector = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        lector.setOnImageAvailableListener(this::alHaberImagen, manejador);
        pantallaVirtual = proyeccion.createVirtualDisplay("PuenteVideo", w, h, m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, lector.getSurface(), null, manejador);
        activo = true;
        return START_NOT_STICKY;
    }

    private void alHaberImagen(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long ahora = SystemClock.elapsedRealtime();
            if (!Compartido.conexion.listoParaCuadro() || ahora - ultimo < 33) return;
            ultimo = ahora;

            Image.Plane plano = img.getPlanes()[0];
            ByteBuffer buf = plano.getBuffer();
            int ancho = img.getWidth(), alto = img.getHeight();
            int anchoConRelleno = plano.getRowStride() / plano.getPixelStride();
            Bitmap bmp = Bitmap.createBitmap(anchoConRelleno, alto, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            if (anchoConRelleno != ancho) {
                Bitmap recorte = Bitmap.createBitmap(bmp, 0, 0, ancho, alto);
                bmp.recycle();
                bmp = recorte;
            }
            Compartido.enviar(bmp);
            enviados.incrementAndGet();
        } catch (Throwable ignorado) {
            // un cuadro malo no tumba el servicio
        } finally {
            if (img != null) img.close();
        }
    }

    private Notification crearAviso() {
        Intent detener = new Intent(this, ServicioPantalla.class).setAction(ACCION_DETENER);
        PendingIntent pDetener = PendingIntent.getService(this, 1, detener, PendingIntent.FLAG_IMMUTABLE);
        PendingIntent pAbrir = PendingIntent.getActivity(this, 2, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.createNotificationChannel(new NotificationChannel(CANAL, "Compartir pantalla",
                        NotificationManager.IMPORTANCE_LOW));
            }
            b = new Notification.Builder(this, CANAL);
        } else {
            b = new Notification.Builder(this);
        }
        return b.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Puente Video")
                .setContentText("Mandando tu pantalla por el cable")
                .setContentIntent(pAbrir)
                .addAction(new Notification.Action.Builder(null, "Detener", pDetener).build())
                .setOngoing(true)
                .build();
    }

    @Override
    public void onDestroy() {
        activo = false;
        if (pantallaVirtual != null) pantallaVirtual.release();
        if (lector != null) lector.close();
        if (proyeccion != null) proyeccion.stop();
        if (hilo != null) hilo.quitSafely();
        stopForeground(true);
        Conexion.Oyente d = Compartido.destino;
        if (d instanceof MainActivity) ((MainActivity) d).alTerminarPantalla();
        super.onDestroy();
    }
}
