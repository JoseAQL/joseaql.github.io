package com.puentevideo.app;

import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;

/**
 * Lo que comparten la pantalla de la app y el servicio que manda la pantalla
 * del celular. La conexión vive aquí para que siga viva aunque la app quede en
 * segundo plano (por ejemplo, mientras compartes tu pantalla).
 */
public final class Compartido {

    private Compartido() { }

    /** La pantalla de la app, si está abierta (puede ser null). */
    public static volatile Conexion.Oyente destino;

    /** Si nos conectamos a un nodo HDMI, el cuadro debe caber en su pantalla. */
    public static volatile int limiteAncho = 0, limiteAlto = 0;

    /** Lado largo máximo de la pantalla que se manda (según 480p/720p/1080p). */
    public static volatile int ladoLargoPantalla = 1280;
    public static volatile int calidadJpeg = 70;

    public static final Conexion conexion = new Conexion(new Conexion.Oyente() {
        @Override
        public void alCambiarEstado(String texto, boolean conectado) {
            if (!conectado) {
                limiteAncho = 0;
                limiteAlto = 0;
            }
            Conexion.Oyente d = destino;
            if (d != null) d.alCambiarEstado(texto, conectado);
        }

        @Override
        public void alRecibirCuadro(Bitmap cuadro) {
            Conexion.Oyente d = destino;
            if (d != null) d.alRecibirCuadro(cuadro);
        }

        @Override
        public void alRecibirTexto(String texto) {
            // "HOLA|NODO 3 800x600": es un receptor Ethernet → HDMI
            if (texto.startsWith("HOLA|")) {
                int ancho = 0, alto = 0;
                if (texto.startsWith("HOLA|NODO ")) {
                    String[] partes = texto.substring(10).trim().split(" ");
                    if (partes.length == 2 && partes[1].contains("x")) {
                        try {
                            String[] wh = partes[1].split("x");
                            ancho = Integer.parseInt(wh[0]);
                            alto = Integer.parseInt(wh[1]);
                        } catch (NumberFormatException ignorado) { }
                    }
                }
                limiteAncho = ancho;
                limiteAlto = alto;
            }
            Conexion.Oyente d = destino;
            if (d != null) d.alRecibirTexto(texto);
        }
    });

    /** Ajusta al nodo (si hay), comprime a JPEG y lo deja listo para enviar. Recicla bmp. */
    public static void enviar(Bitmap bmp) {
        int la = limiteAncho, lh = limiteAlto;
        if (la > 0 && lh > 0 && (bmp.getWidth() > la || bmp.getHeight() > lh)) {
            float escala = Math.min((float) la / bmp.getWidth(), (float) lh / bmp.getHeight());
            int w = Math.max(2, Math.min(Math.round(bmp.getWidth() * escala), la) & ~1);
            int h = Math.max(2, Math.min(Math.round(bmp.getHeight() * escala), lh) & ~1);
            Bitmap chico = Bitmap.createScaledBitmap(bmp, w, h, true);
            if (chico != bmp) bmp.recycle();
            bmp = chico;
        }
        ByteArrayOutputStream jpeg = new ByteArrayOutputStream(256 * 1024);
        bmp.compress(Bitmap.CompressFormat.JPEG, calidadJpeg, jpeg);
        bmp.recycle();
        conexion.enviarCuadro(jpeg.toByteArray());
    }
}
