package com.puentevideo.app;

import android.net.Network;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Encuentra la PC sin que nadie escriba una IP.
 *
 * Prueba varios caminos a la vez y se queda con el primero que conteste. En
 * orden de qué tan rápido suelen responder:
 *
 *   0. El cable USB por depuración USB: si la PC puso el túnel de adb,
 *      127.0.0.1 llega a la PC. Si no, falla al instante y no estorba.
 *   1. La última dirección que funcionó (casi siempre es la misma).
 *   2. Quien nos dio la IP por DHCP: en el cable, esa es la PC.
 *   3. Los vecinos IPv6 del cable (fe80::). Existen aunque nadie reparta IP,
 *      así que es el camino que nunca falla con cable directo.
 *   4. Las direcciones típicas de cable (192.168.137.1, 192.168.77.1…).
 *   5. El anclaje USB: la red que el celular comparte por el cable USB.
 *   6. Barrido de toda la red, 254 direcciones con 40 hilos.
 *
 * Los avisos que grita la PC los escucha {@link BuscadorPC} aparte; los dos
 * trabajan al mismo tiempo y gana el que llegue primero.
 */
public class ConexionRapida {

    /** Cuánto se espera a cada intento. Por cable, 300 ms sobran. */
    private static final int ESPERA_MS = 350;
    private static final int ESPERA_BARRIDO_MS = 250;

    public interface Oyente {
        void encontrada(String ip, int puerto);
        void avance(String queEstoyHaciendo);
    }

    private final AtomicBoolean yaGano = new AtomicBoolean(false);
    private volatile boolean activo = false;
    private ExecutorService piscina;

    /** El túnel de adb: en el celular, la PC queda en su propia dirección. */
    public static final String LOCAL_USB = "127.0.0.1";

    /** Direcciones de cable que usan Windows y esta app por costumbre. */
    private static final String[] TIPICAS = {
            "192.168.137.1",  // Conexión compartida de Windows
            "192.168.77.1",   // la que configura esta app
            "192.168.42.129", // reparto de Android
            "192.168.43.1",
    };

    public void buscar(final Network redEthernet, final String ultimaBuena,
                       final String servidorDhcp, final int puerto, final Oyente oyente) {
        if (activo) return;
        activo = true;
        yaGano.set(false);
        piscina = Executors.newFixedThreadPool(40);

        new Thread(() -> {
            try {
                // 0: el túnel de adb por el cable USB. Sin amarrar a la red
                // Ethernet: 127.0.0.1 es local y no sale por ningún cable.
                oyente.avance("Probando el cable USB…");
                if (probar(null, LOCAL_USB, puerto, oyente)) return;

                // 1 y 2: lo más probable, de uno en uno porque son dos nada más
                oyente.avance("Probando la conexión de siempre…");
                if (probar(redEthernet, ultimaBuena, puerto, oyente)) return;
                if (probar(redEthernet, servidorDhcp, puerto, oyente)) return;

                // 3: las direcciones de siempre
                oyente.avance("Buscando la PC por el cable…");
                for (String ip : TIPICAS) {
                    if (probar(redEthernet, ip, puerto, oyente)) return;
                }

                // 5: el anclaje USB. El celular es el que reparte, así que la
                // PC es alguna de su red; esa red no es Ethernet para Android,
                // por eso va sin amarrar.
                List<String> deUsb = direccionesDeAnclajeUsb();
                if (!deUsb.isEmpty()) {
                    oyente.avance("Buscando la PC por el cable USB…");
                    barrer(null, deUsb, puerto, oyente);
                    if (yaGano.get()) return;
                    piscina = Executors.newFixedThreadPool(40);
                }

                // 6: barrido de la red entera, en paralelo
                List<String> aBarrer = direccionesDeMiRed();
                if (!aBarrer.isEmpty()) {
                    oyente.avance("Revisando la red…");
                    barrer(redEthernet, aBarrer, puerto, oyente);
                }
            } finally {
                activo = false;
                if (piscina != null) piscina.shutdownNow();
            }
        }, "conexion-rapida").start();
    }

    public void detener() {
        activo = false;
        yaGano.set(true);
        if (piscina != null) piscina.shutdownNow();
    }

    // ------------------------------------------------------------------ apoyo

    /** Intenta abrir el puerto. Si contesta, avisa y devuelve true. */
    private boolean probar(Network red, String ip, int puerto, Oyente oyente) {
        if (ip == null || ip.isEmpty() || yaGano.get()) return false;
        if (!alcanzable(red, ip, puerto, ESPERA_MS)) return false;
        if (yaGano.compareAndSet(false, true)) {
            oyente.encontrada(ip, puerto);
            return true;
        }
        return false;
    }

    private boolean alcanzable(Network red, String ip, int puerto, int esperaMs) {
        Socket s = null;
        try {
            s = new Socket();
            if (red != null) red.bindSocket(s);
            s.connect(new InetSocketAddress(ip, puerto), esperaMs);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            if (s != null) {
                try { s.close(); } catch (Exception ignorado) { }
            }
        }
    }

    /**
     * Las direcciones de la red del anclaje USB, menos la mía.
     *
     * Android llama a esa interfaz rndis0, usb0 o ncm0 según el modelo. No es
     * una red que las apps vean como tal (el celular es quien la reparte), así
     * que se encuentra por el nombre de la interfaz.
     */
    static List<String> direccionesDeAnclajeUsb() {
        List<String> salida = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                String nombre = ni.getName() == null ? "" : ni.getName();
                if (!ni.isUp() || !(nombre.startsWith("rndis") || nombre.startsWith("usb")
                        || nombre.startsWith("ncm"))) continue;
                Enumeration<InetAddress> direcciones = ni.getInetAddresses();
                while (direcciones.hasMoreElements()) {
                    InetAddress d = direcciones.nextElement();
                    if (!(d instanceof Inet4Address)) continue;
                    String ip = d.getHostAddress();
                    int corte = ip == null ? -1 : ip.lastIndexOf('.');
                    if (corte <= 0) continue;
                    String prefijo = ip.substring(0, corte + 1);
                    for (int i = 1; i < 255; i++) {
                        String otra = prefijo + i;
                        if (!otra.equals(ip)) salida.add(otra);
                    }
                }
            }
        } catch (Exception ignorado) {
        }
        return salida;
    }

    /** True si el celular está compartiendo conexión por el cable USB. */
    static boolean hayAnclajeUsb() {
        return !direccionesDeAnclajeUsb().isEmpty();
    }

    /** Todas las direcciones de mi red IPv4, menos la mía. */
    private List<String> direccionesDeMiRed() {
        List<String> salida = new ArrayList<>();
        Set<String> prefijos = new LinkedHashSet<>();
        String miIp = null;
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces != null && interfaces.hasMoreElements()) {
                NetworkInterface ni = interfaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> direcciones = ni.getInetAddresses();
                while (direcciones.hasMoreElements()) {
                    InetAddress d = direcciones.nextElement();
                    if (!(d instanceof Inet4Address)) continue;
                    String ip = d.getHostAddress();
                    if (ip == null || ip.startsWith("127.")) continue;
                    int corte = ip.lastIndexOf('.');
                    if (corte <= 0) continue;
                    prefijos.add(ip.substring(0, corte + 1));
                    if (miIp == null) miIp = ip;
                }
            }
        } catch (Exception ignorado) {
        }
        for (String prefijo : prefijos) {
            for (int i = 1; i < 255; i++) {
                String ip = prefijo + i;
                if (!ip.equals(miIp)) salida.add(ip);
            }
        }
        return salida;
    }

    private void barrer(final Network red, List<String> direcciones, final int puerto,
                        final Oyente oyente) {
        final List<String> lista = Collections.synchronizedList(direcciones);
        for (final String ip : lista) {
            if (yaGano.get()) break;
            try {
                piscina.execute(() -> {
                    if (yaGano.get()) return;
                    if (alcanzable(red, ip, puerto, ESPERA_BARRIDO_MS)
                            && yaGano.compareAndSet(false, true)) {
                        oyente.encontrada(ip, puerto);
                    }
                });
            } catch (Exception detenido) {
                break;
            }
        }
        try {
            piscina.shutdown();
            piscina.awaitTermination(12, TimeUnit.SECONDS);
        } catch (Exception ignorado) {
        }
    }
}
