package com.puentevideo.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Mandar y recibir archivos con la PC por el mismo cable, en el puerto 5005.
 *
 * Va en un socket aparte del video a propósito. TCP entrega en orden, así que
 * un archivo de 2 GB metido en el socket del video dejaría la imagen congelada
 * hasta que terminara la copia: el video quedaría esperando detrás del
 * archivo. Con dos sockets cada cosa avanza a su ritmo.
 *
 * El formato de los mensajes es el mismo del video (1 byte tipo, 4 bytes
 * largo, N datos) y los tipos empiezan en 10 para no pisar los del video.
 *
 * <h3>Por qué no pide ningún permiso de almacenamiento</h3>
 *
 * Para <b>mandar</b> se usa el selector del sistema, que entrega un Uri ya
 * autorizado: la app nunca necesita leer el almacenamiento por su cuenta.
 *
 * Para <b>recibir</b>, en Android 10 y arriba se escribe en la carpeta de
 * Descargas con MediaStore, que tampoco pide permiso. En Android 9 y abajo
 * escribir en Descargas sí pediría WRITE_EXTERNAL_STORAGE, así que ahí se cae
 * a la carpeta de la propia app: es menos cómodo de encontrar, pero no le pide
 * al usuario un permiso que suena a mucho más de lo que la app hace.
 *
 * Lo que no se intentó: navegar todo el almacenamiento del celular desde la PC.
 * Eso pide MANAGE_EXTERNAL_STORAGE, que Google casi no aprueba, y obligaría a
 * repartir el APK a mano para siempre.
 */
public class Archivos {

    public interface Oyente {
        /** Cambió algo de la lista o del estado: hay que redibujar. */
        void alCambiarArchivos();
        /** Un aviso para enseñar al usuario (llegó algo, falló algo). */
        void alAvisar(String texto);
    }

    public static final int PUERTO = 5005;

    static final int TIPO_OFERTA = 10;
    static final int TIPO_TROZO = 11;
    static final int TIPO_FIN = 12;
    static final int TIPO_ACEPTA = 13;
    static final int TIPO_RECHAZA = 14;
    static final int TIPO_LISTO = 15;

    private static final int TROZO = 256 * 1024;
    private static final int LARGO_MAXIMO = 16 * 1024 * 1024;
    private static final String SEP = "|";

    /** Un archivo que va o viene, para la lista de la pantalla. */
    public static class Copia {
        public final int id;
        public final String nombre;
        public final long tamano;
        public final boolean saliendo;
        public volatile long hechos;
        public volatile long desde;      // > 0 si se reanudó
        public volatile String estado = "esperando";
        public volatile String detalle = "";
        final long t0 = System.currentTimeMillis();
        volatile long tFin = 0;

        Copia(int id, String nombre, long tamano, boolean saliendo) {
            this.id = id;
            this.nombre = nombre;
            this.tamano = tamano;
            this.saliendo = saliendo;
        }

        public boolean terminada() {
            return estado.equals("lista") || estado.equals("falló") || estado.equals("rechazada");
        }

        public int porcentaje() {
            if (tamano <= 0) return 100;
            return (int) Math.min(100, 100 * hechos / tamano);
        }

        public String resumen() {
            StringBuilder s = new StringBuilder();
            s.append(saliendo ? "↑ " : "↓ ").append(nombre)
             .append(" · ").append(legible(tamano));
            if (estado.equals("copiando")) {
                s.append(" · ").append(porcentaje()).append(" %");
                long ms = (tFin > 0 ? tFin : System.currentTimeMillis()) - t0;
                if (ms > 300 && hechos > desde) {
                    long bps = (hechos - desde) * 1000 / ms;
                    if (bps > 0) {
                        s.append(" · ").append(legible(bps)).append("/s");
                        long faltan = tamano - hechos;
                        if (faltan > 0) s.append(" · faltan ").append(faltan / bps).append(" s");
                    }
                }
            } else {
                s.append(" · ").append(estado);
                if (!detalle.isEmpty()) s.append(" (").append(detalle).append(")");
                if (desde > 0 && estado.equals("lista")) {
                    s.append(" · se reanudó desde ").append(legible(desde));
                }
            }
            return s.toString();
        }
    }

    public static String legible(long n) {
        if (n < 1024) return n + " B";
        double v = n / 1024.0;
        if (v < 1024) return String.format(java.util.Locale.US, "%.1f kB", v);
        v /= 1024.0;
        if (v < 1024) return String.format(java.util.Locale.US, "%.1f MB", v);
        return String.format(java.util.Locale.US, "%.1f GB", v / 1024.0);
    }

    // ------------------------------------------------------------------ estado
    private final Context ctx;
    private final Oyente oyente;
    private final Object candado = new Object();
    private final List<Copia> copias = Collections.synchronizedList(new ArrayList<>());
    private final LinkedBlockingQueue<Uri> cola = new LinkedBlockingQueue<>();
    private final Map<Integer, Entrada> entrando = new HashMap<>();
    private final Map<Integer, String[]> respuestas = new HashMap<>();

    private volatile boolean activo = false;
    private volatile Socket socket;
    private volatile Network redEthernet;
    private volatile Thread hiloLectura, hiloEnvio;
    private volatile int siguienteId = 1;
    public volatile String estado = "Sin conexión de archivos";

    private static class Entrada {
        RandomAccessFile f;
        File parcial;
        String nombre;
        String suma;
        Copia copia;
    }

    public Archivos(Context ctx, Oyente oyente) {
        this.ctx = ctx.getApplicationContext();
        this.oyente = oyente;
    }

    public void setRedEthernet(Network red) {
        redEthernet = red;
    }

    public boolean conectado() {
        return socket != null;
    }

    public List<Copia> lista() {
        synchronized (copias) {
            return new ArrayList<>(copias);
        }
    }

    public void limpiarTerminadas() {
        synchronized (copias) {
            for (int i = copias.size() - 1; i >= 0; i--) {
                if (copias.get(i).terminada()) copias.remove(i);
            }
        }
        oyente.alCambiarArchivos();
    }

    /** Dónde van a quedar los archivos que lleguen, para decírselo al usuario. */
    public String dondeLlegan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return "la carpeta Descargas";
        }
        File d = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        return d != null ? d.getAbsolutePath() : "la carpeta de la app";
    }

    // --------------------------------------------------------------- arranque
    public synchronized void iniciar(String host) {
        if (activo) return;
        activo = true;
        Thread t = new Thread(() -> bucle(host), "archivos");
        hiloLectura = t;
        t.start();
    }

    public synchronized void detener() {
        activo = false;
        cerrarSocket();
        if (hiloLectura != null) hiloLectura.interrupt();
        if (hiloEnvio != null) hiloEnvio.interrupt();
        hiloLectura = null;
        hiloEnvio = null;
    }

    private void cerrarSocket() {
        Socket s;
        synchronized (candado) {
            s = socket;
            socket = null;
            candado.notifyAll();
        }
        if (s != null) {
            try { s.close(); } catch (IOException ignorado) { }
        }
        // Lo que iba a medias se deja en .parcial a propósito: así se reanuda
        // al reconectar en lugar de repetir lo que ya pasó por el cable.
        synchronized (entrando) {
            for (Entrada e : entrando.values()) {
                try { e.f.close(); } catch (IOException ignorado) { }
                if (!e.copia.terminada()) {
                    e.copia.estado = "cortada";
                    e.copia.detalle = "se puede reanudar";
                }
            }
            entrando.clear();
        }
        synchronized (copias) {
            for (Copia c : copias) {
                if (c.estado.equals("copiando") || c.estado.equals("esperando")) {
                    c.estado = "cortada";
                    c.detalle = "se puede reanudar";
                }
            }
        }
        synchronized (respuestas) {
            respuestas.notifyAll();
        }
        oyente.alCambiarArchivos();
    }

    private boolean sigo() {
        return activo && hiloLectura == Thread.currentThread();
    }

    private Socket abrir(String host) throws IOException {
        Network red = redEthernet;
        if (red != null) {
            // Igual que el video: Android no manda tráfico por un Ethernet
            // "sin internet" si el socket no se amarra a esa red.
            Socket s = new Socket();
            try {
                red.bindSocket(s);
                s.connect(new InetSocketAddress(host, PUERTO), 3000);
                return s;
            } catch (IOException e) {
                try { s.close(); } catch (IOException ignorado) { }
            }
        }
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, PUERTO), 3000);
        } catch (IOException e) {
            try { s.close(); } catch (IOException ignorado) { }
            throw e;
        }
        return s;
    }

    private void bucle(String host) {
        while (sigo()) {
            Socket s = null;
            try {
                s = abrir(host);
                s.setTcpNoDelay(true);
                synchronized (candado) {
                    if (!sigo()) throw new IOException("detenido");
                    socket = s;
                }
                estado = "Listo para mandar y recibir archivos";
                oyente.alCambiarArchivos();

                Thread envio = new Thread(this::bucleEnvio, "archivos-envio");
                hiloEnvio = envio;
                envio.start();

                InputStream entrada = new java.io.BufferedInputStream(s.getInputStream(), 256 * 1024);
                while (sigo()) {
                    int tipo = leerByte(entrada);
                    int largo = leerEntero(entrada);
                    if (largo < 0 || largo > LARGO_MAXIMO) throw new IOException("mensaje inválido");
                    byte[] datos = new byte[largo];
                    leerTodo(entrada, datos);
                    atender(tipo, datos);
                }
            } catch (IOException e) {
                if (sigo()) {
                    estado = "Sin conexión de archivos (" + e.getMessage() + "). Reintentando…";
                    oyente.alCambiarArchivos();
                }
            } finally {
                if (socket == s) cerrarSocket();
                else if (s != null) { try { s.close(); } catch (IOException ignorado) { } }
                if (hiloEnvio != null) hiloEnvio.interrupt();
            }
            if (!sigo()) break;
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                break;
            }
        }
        estado = "Sin conexión de archivos";
        oyente.alCambiarArchivos();
    }

    // ------------------------------------------------------- leer del socket
    private static int leerByte(InputStream in) throws IOException {
        int b = in.read();
        if (b < 0) throw new IOException("la PC cerró la conexión");
        return b;
    }

    private static int leerEntero(InputStream in) throws IOException {
        int v = 0;
        for (int i = 0; i < 4; i++) v = (v << 8) | leerByte(in);
        return v;
    }

    private static void leerTodo(InputStream in, byte[] destino) throws IOException {
        int leidos = 0;
        while (leidos < destino.length) {
            int r = in.read(destino, leidos, destino.length - leidos);
            if (r < 0) throw new IOException("la PC cerró la conexión");
            leidos += r;
        }
    }

    private void escribir(int tipo, byte[] datos) throws IOException {
        Socket s = socket;
        if (s == null) throw new IOException("sin conexión");
        OutputStream o = s.getOutputStream();
        // Un solo hilo escribe cabecera y cuerpo seguidos: si dos se
        // intercalaran, el otro lado leería basura y cerraría.
        synchronized (candado) {
            o.write(tipo);
            o.write((datos.length >>> 24) & 0xFF);
            o.write((datos.length >>> 16) & 0xFF);
            o.write((datos.length >>> 8) & 0xFF);
            o.write(datos.length & 0xFF);
            o.write(datos);
            o.flush();
        }
    }

    private void escribirTrozo(int id, byte[] pedazo, int largo) throws IOException {
        Socket s = socket;
        if (s == null) throw new IOException("sin conexión");
        OutputStream o = s.getOutputStream();
        int total = largo + 4;
        synchronized (candado) {
            o.write(TIPO_TROZO);
            o.write((total >>> 24) & 0xFF);
            o.write((total >>> 16) & 0xFF);
            o.write((total >>> 8) & 0xFF);
            o.write(total & 0xFF);
            o.write((id >>> 24) & 0xFF);
            o.write((id >>> 16) & 0xFF);
            o.write((id >>> 8) & 0xFF);
            o.write(id & 0xFF);
            o.write(pedazo, 0, largo);
            o.flush();
        }
    }

    // ------------------------------------------------------------------ salir
    public void mandar(List<Uri> uris) {
        cola.addAll(uris);
    }

    private void bucleEnvio() {
        try {
            while (socket != null && activo) {
                Uri uri = cola.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS);
                if (uri == null) continue;
                try {
                    mandarUno(uri);
                } catch (IOException e) {
                    oyente.alAvisar("Se cortó al mandar: " + e.getMessage());
                    return;
                }
            }
        } catch (InterruptedException ignorado) {
        }
    }

    private void mandarUno(Uri uri) throws IOException {
        String nombre = nombreDe(uri);
        long tamano = tamanoDe(uri);
        int id;
        synchronized (candado) {
            id = siguienteId++;
        }
        Copia copia = new Copia(id, nombre, tamano, true);
        copia.estado = "sumando";
        copias.add(copia);
        oyente.alCambiarArchivos();

        // La suma va en la oferta, antes de los datos, así que el archivo se
        // lee dos veces. Leer del almacenamiento del celular es mucho más
        // barato que descubrir al final que llegó mal y repetir la copia
        // completa por el cable.
        String suma = sumaDe(uri);
        if (suma == null) {
            copia.estado = "falló";
            copia.detalle = "no pude leer el archivo";
            oyente.alCambiarArchivos();
            return;
        }
        if (tamano <= 0) tamano = -1;   // algunos Uri no dicen el tamaño

        copia.estado = "esperando";
        oyente.alCambiarArchivos();
        escribir(TIPO_OFERTA, (id + SEP + nombre + SEP + (tamano < 0 ? 0 : tamano) + SEP + suma)
                .getBytes(StandardCharsets.UTF_8));

        String[] r = esperarRespuesta(id);
        if (r == null || Integer.parseInt(r[0]) != TIPO_ACEPTA) {
            copia.estado = "rechazada";
            copia.detalle = r == null ? "no contestó" : r[1];
            copia.tFin = System.currentTimeMillis();
            oyente.alCambiarArchivos();
            return;
        }
        long desde = 0;
        try {
            desde = Long.parseLong(r[1].trim());
        } catch (NumberFormatException ignorado) { }
        copia.desde = desde;
        copia.hechos = desde;
        copia.estado = "copiando";
        if (desde > 0) copia.detalle = "reanudada desde " + legible(desde);
        oyente.alCambiarArchivos();

        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("no pude abrir el archivo");
            long saltar = desde;
            while (saltar > 0) {
                long s = in.skip(saltar);
                if (s <= 0) throw new IOException("no pude reanudar este archivo");
                saltar -= s;
            }
            byte[] buffer = new byte[TROZO];
            int n;
            while (activo && socket != null && (n = in.read(buffer)) > 0) {
                escribirTrozo(id, buffer, n);
                copia.hechos += n;
                oyente.alCambiarArchivos();
            }
        }
        if (!activo || socket == null) return;
        escribir(TIPO_FIN, String.valueOf(id).getBytes(StandardCharsets.UTF_8));

        r = esperarRespuesta(id);
        copia.tFin = System.currentTimeMillis();
        if (r != null && Integer.parseInt(r[0]) == TIPO_LISTO && r[1].startsWith("ok")) {
            copia.estado = "lista";
            copia.detalle = "";
            oyente.alAvisar("Se mandó «" + nombre + "».");
        } else {
            copia.estado = "falló";
            copia.detalle = r == null ? "no contestó" : r[1];
        }
        oyente.alCambiarArchivos();
    }

    private String[] esperarRespuesta(int id) {
        long limite = System.currentTimeMillis() + 120_000;
        synchronized (respuestas) {
            while (activo && socket != null && !respuestas.containsKey(id)) {
                long falta = limite - System.currentTimeMillis();
                if (falta <= 0) return null;
                try {
                    respuestas.wait(Math.min(1000, falta));
                } catch (InterruptedException e) {
                    return null;
                }
            }
            return respuestas.remove(id);
        }
    }

    // ----------------------------------------------------------------- entrar
    private void atender(int tipo, byte[] datos) throws IOException {
        if (tipo == TIPO_OFERTA) {
            llegaOferta(new String(datos, StandardCharsets.UTF_8));
        } else if (tipo == TIPO_TROZO) {
            llegaTrozo(datos);
        } else if (tipo == TIPO_FIN) {
            llegaFin(new String(datos, StandardCharsets.UTF_8));
        } else if (tipo == TIPO_ACEPTA || tipo == TIPO_RECHAZA || tipo == TIPO_LISTO) {
            String[] partes = new String(datos, StandardCharsets.UTF_8).split("\\|", 2);
            try {
                int id = Integer.parseInt(partes[0]);
                synchronized (respuestas) {
                    respuestas.put(id, new String[]{String.valueOf(tipo),
                            partes.length > 1 ? partes[1] : ""});
                    respuestas.notifyAll();
                }
            } catch (NumberFormatException ignorado) { }
        }
    }

    private void llegaOferta(String texto) throws IOException {
        String[] p = texto.split("\\|");
        if (p.length < 4) return;
        int id;
        long tamano;
        try {
            id = Integer.parseInt(p[0]);
            tamano = Long.parseLong(p[2]);
        } catch (NumberFormatException e) {
            return;
        }
        String nombre = nombreSeguro(p[1]);
        String suma = p[3].trim().toLowerCase(java.util.Locale.US);

        // El .parcial vive en la carpeta privada de la app, no en Descargas: se
        // necesita poder posicionarse y truncar, que en MediaStore no se puede.
        // Al terminar se copia al destino final de una sola pasada.
        File dir = new File(ctx.getFilesDir(), "parciales");
        if (!dir.exists() && !dir.mkdirs()) {
            escribir(TIPO_RECHAZA, (id + SEP + "no pude crear la carpeta temporal")
                    .getBytes(StandardCharsets.UTF_8));
            return;
        }
        // El nombre del parcial lleva la suma, así que solo se reanuda si de
        // verdad es el mismo contenido: si el archivo cambió del otro lado, la
        // suma cambia y empieza de cero.
        File parcial = new File(dir, suma.substring(0, Math.min(16, suma.length())) + ".parcial");
        long desde = parcial.exists() ? Math.min(parcial.length(), tamano) : 0;

        Entrada e = new Entrada();
        e.parcial = parcial;
        e.nombre = nombre;
        e.suma = suma;
        e.copia = new Copia(id, nombre, tamano, false);
        e.copia.hechos = desde;
        e.copia.desde = desde;
        e.copia.estado = "copiando";
        if (desde > 0) e.copia.detalle = "reanudada desde " + legible(desde);
        try {
            e.f = new RandomAccessFile(parcial, "rw");
            e.f.setLength(desde);
            e.f.seek(desde);
        } catch (IOException ex) {
            escribir(TIPO_RECHAZA, (id + SEP + "no pude escribir: " + ex.getMessage())
                    .getBytes(StandardCharsets.UTF_8));
            return;
        }
        copias.add(e.copia);
        synchronized (entrando) {
            entrando.put(id, e);
        }
        oyente.alCambiarArchivos();
        escribir(TIPO_ACEPTA, (id + SEP + desde).getBytes(StandardCharsets.UTF_8));
    }

    private void llegaTrozo(byte[] datos) {
        if (datos.length < 4) return;
        int id = ((datos[0] & 0xFF) << 24) | ((datos[1] & 0xFF) << 16)
               | ((datos[2] & 0xFF) << 8) | (datos[3] & 0xFF);
        Entrada e;
        synchronized (entrando) {
            e = entrando.get(id);
        }
        if (e == null) return;
        try {
            e.f.write(datos, 4, datos.length - 4);
        } catch (IOException ex) {
            fallarEntrada(id, "no pude escribir: " + ex.getMessage());
            return;
        }
        e.copia.hechos += datos.length - 4;
        oyente.alCambiarArchivos();
    }

    private void llegaFin(String texto) throws IOException {
        int id;
        try {
            id = Integer.parseInt(texto.split("\\|")[0].trim());
        } catch (NumberFormatException ex) {
            return;
        }
        Entrada e;
        synchronized (entrando) {
            e = entrando.remove(id);
        }
        if (e == null) return;
        try { e.f.close(); } catch (IOException ignorado) { }
        e.copia.estado = "revisando";
        oyente.alCambiarArchivos();

        String real = sumaDeArchivo(e.parcial);
        e.copia.tFin = System.currentTimeMillis();
        if (real == null || (!e.suma.isEmpty() && !real.equals(e.suma))) {
            // Se borra el parcial: si la suma no cuadra, reanudar sobre él
            // arrastraría el error para siempre.
            e.parcial.delete();
            e.copia.estado = "falló";
            e.copia.detalle = "la suma no cuadra; se descartó";
            oyente.alCambiarArchivos();
            escribir(TIPO_LISTO, (id + SEP + "mal" + SEP + "suma distinta")
                    .getBytes(StandardCharsets.UTF_8));
            return;
        }

        String donde = guardarDondeSeVe(e.parcial, e.nombre);
        if (donde == null) {
            e.copia.estado = "falló";
            e.copia.detalle = "no pude guardarlo en Descargas";
            oyente.alCambiarArchivos();
            escribir(TIPO_LISTO, (id + SEP + "mal" + SEP + "no pude guardarlo")
                    .getBytes(StandardCharsets.UTF_8));
            return;
        }
        e.parcial.delete();
        e.copia.estado = "lista";
        e.copia.detalle = donde;
        oyente.alCambiarArchivos();
        oyente.alAvisar("Llegó «" + e.nombre + "» (" + legible(e.copia.tamano) + ").");
        escribir(TIPO_LISTO, (id + SEP + "ok").getBytes(StandardCharsets.UTF_8));
    }

    private void fallarEntrada(int id, String motivo) {
        Entrada e;
        synchronized (entrando) {
            e = entrando.remove(id);
        }
        if (e == null) return;
        try { e.f.close(); } catch (IOException ignorado) { }
        e.copia.estado = "falló";
        e.copia.detalle = motivo;
        e.copia.tFin = System.currentTimeMillis();
        oyente.alCambiarArchivos();
        try {
            escribir(TIPO_LISTO, (id + SEP + "mal" + SEP + motivo).getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignorado) { }
    }

    // ------------------------------------------------------------ guardar
    /**
     * Mueve el archivo ya completo a donde el usuario lo pueda ver.
     * Devuelve una descripción de dónde quedó, o null si no se pudo.
     */
    private String guardarDondeSeVe(File parcial, String nombre) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10 y arriba: Descargas con MediaStore, sin permisos.
            // MediaStore se encarga de no pisar nada: si ya hay un "foto.jpg",
            // guarda "foto (1).jpg" por su cuenta.
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, nombre);
            v.put(MediaStore.Downloads.MIME_TYPE, tipoMime(nombre));
            v.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri destino = null;
            try {
                destino = ctx.getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (destino == null) return null;
                try (InputStream in = new java.io.FileInputStream(parcial);
                     OutputStream out = ctx.getContentResolver().openOutputStream(destino)) {
                    if (out == null) throw new IOException("sin salida");
                    byte[] b = new byte[256 * 1024];
                    int n;
                    while ((n = in.read(b)) > 0) out.write(b, 0, n);
                }
                v.clear();
                v.put(MediaStore.Downloads.IS_PENDING, 0);
                ctx.getContentResolver().update(destino, v, null, null);
                return "Descargas";
            } catch (IOException | SecurityException | IllegalArgumentException e) {
                if (destino != null) {
                    // Sin esto queda una entrada a medias en Descargas, que el
                    // usuario ve como un archivo de 0 bytes que no se puede abrir.
                    try { ctx.getContentResolver().delete(destino, null, null); }
                    catch (RuntimeException ignorado) { }
                }
                return null;
            }
        }
        // Android 9 y abajo: la carpeta de la app, para no pedir
        // WRITE_EXTERNAL_STORAGE, que suena a mucho más de lo que la app hace.
        File dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) dir = new File(ctx.getFilesDir(), "Descargas");
        if (!dir.exists() && !dir.mkdirs()) return null;
        File destino = libre(dir, nombre);
        try (InputStream in = new java.io.FileInputStream(parcial);
             OutputStream out = new FileOutputStream(destino)) {
            byte[] b = new byte[256 * 1024];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
        } catch (IOException e) {
            return null;
        }
        return destino.getParentFile() != null ? destino.getParentFile().getName() : "la app";
    }

    private static File libre(File dir, String nombre) {
        File f = new File(dir, nombre);
        if (!f.exists()) return f;
        int punto = nombre.lastIndexOf('.');
        String base = punto > 0 ? nombre.substring(0, punto) : nombre;
        String ext = punto > 0 ? nombre.substring(punto) : "";
        for (int i = 2; i < 1000; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return new File(dir, base + "-" + System.currentTimeMillis() + ext);
    }

    private static String tipoMime(String nombre) {
        int punto = nombre.lastIndexOf('.');
        if (punto < 0) return "application/octet-stream";
        String ext = nombre.substring(punto + 1).toLowerCase(java.util.Locale.US);
        String m = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m != null ? m : "application/octet-stream";
    }

    /**
     * Limpia el nombre que mandó la PC antes de crear un archivo con él.
     *
     * La otra punta manda un nombre y aquí se usa para crear un archivo, así
     * que hay que quitarle cualquier intento de salirse de la carpeta. Sin
     * esto, un nombre como «../../algo» escribiría fuera de donde debe.
     */
    static String nombreSeguro(String nombre) {
        if (nombre == null) return "archivo";
        nombre = nombre.replace('\\', '/');
        int barra = nombre.lastIndexOf('/');
        if (barra >= 0) nombre = nombre.substring(barra + 1);
        StringBuilder limpio = new StringBuilder();
        for (char c : nombre.toCharArray()) {
            if (c == 0 || c < 32 || "<>:\"|?*/\\".indexOf(c) >= 0) continue;
            limpio.append(c);
        }
        String r = limpio.toString().trim();
        while (r.startsWith(".")) r = r.substring(1);
        while (r.endsWith(".") || r.endsWith(" ")) r = r.substring(0, r.length() - 1);
        if (r.isEmpty()) r = "archivo";
        return r.length() > 200 ? r.substring(0, 200) : r;
    }

    // ------------------------------------------------------------ datos del Uri
    private String nombreDe(Uri uri) {
        try (Cursor c = ctx.getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && !c.isNull(i)) return nombreSeguro(c.getString(i));
            }
        } catch (RuntimeException ignorado) { }
        String ultimo = uri.getLastPathSegment();
        return nombreSeguro(ultimo != null ? ultimo : "archivo");
    }

    private long tamanoDe(Uri uri) {
        try (Cursor c = ctx.getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !c.isNull(i)) return c.getLong(i);
            }
        } catch (RuntimeException ignorado) { }
        return 0;
    }

    private String sumaDe(Uri uri) {
        try (InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            return sumaDe(in);
        } catch (IOException e) {
            return null;
        }
    }

    private static String sumaDeArchivo(File f) {
        try (InputStream in = new java.io.FileInputStream(f)) {
            return sumaDe(in);
        } catch (IOException e) {
            return null;
        }
    }

    private static String sumaDe(InputStream in) throws IOException {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            return null;   // no existe en ningún Android, pero el compilador lo pide
        }
        byte[] b = new byte[1024 * 1024];
        int n;
        while ((n = in.read(b)) > 0) md.update(b, 0, n);
        StringBuilder s = new StringBuilder(64);
        for (byte x : md.digest()) s.append(String.format(java.util.Locale.US, "%02x", x));
        return s.toString();
    }
}
