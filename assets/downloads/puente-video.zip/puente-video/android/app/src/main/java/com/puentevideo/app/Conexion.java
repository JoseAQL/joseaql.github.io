package com.puentevideo.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Network;
import android.os.Build;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Conexión TCP con la PC. Un solo socket lleva video en los dos sentidos.
 *
 * Protocolo (igual en la PC): cada mensaje es
 *   1 byte  tipo   (1 = cuadro JPEG, 2 = texto UTF-8, 3 = acuse "ya lo mostré")
 *   4 bytes largo  (big-endian)
 *   N bytes datos
 *
 * Para que la latencia no crezca nunca se encolan cuadros: hay un solo
 * "cuadro pendiente" y como máximo 2 cuadros en camino sin acuse. Si la red
 * o el otro equipo van lentos, la cámara se salta cuadros.
 */
public class Conexion {

    public interface Oyente {
        void alCambiarEstado(String texto, boolean conectado);
        void alRecibirCuadro(Bitmap cuadro);
        void alRecibirTexto(String texto);
    }

    public static final int PUERTO = 5000;
    static final int TIPO_JPEG = 1;
    static final int TIPO_TEXTO = 2;
    static final int TIPO_ACUSE = 3;
    /** El dedo en la pantalla del celular, para mover el cursor de la PC. */
    static final int TIPO_CONTROL = 4;
    private static final int MAX_EN_CAMINO = 2;
    private static final byte[] VACIO = new byte[0];
    private static final int LARGO_MAXIMO = 16 * 1024 * 1024;

    private final Oyente oyente;
    private final Object candado = new Object();

    private volatile boolean activo = false;
    private volatile Socket socket;
    private volatile DataOutputStream salidaActual;
    private volatile Network redEthernet;
    private volatile Thread hilo;
    private byte[] pendiente;          // protegido por candado
    private final java.util.concurrent.atomic.AtomicInteger enCamino = new java.util.concurrent.atomic.AtomicInteger();

    public Conexion(Oyente oyente) {
        this.oyente = oyente;
    }

    public void setRedEthernet(Network red) {
        redEthernet = red;
    }

    public Network getRedEthernet() {
        return redEthernet;
    }

    public boolean estaActiva() {
        return activo;
    }

    /** true si hay socket y el cuadro anterior ya salió: vale la pena codificar uno nuevo. */
    public boolean listoParaCuadro() {
        synchronized (candado) {
            return socket != null && pendiente == null && enCamino.get() < MAX_EN_CAMINO;
        }
    }

    /**
     * Manda un toque a la PC. No bloquea y no se encola: si la red va lenta,
     * un toque viejo no sirve de nada.
     *
     * Va por el socket del video y no por el de archivos a propósito: son
     * mensajes de unas decenas de bytes y lo que importa es que lleguen
     * pronto, y ese socket es el que ya está puesto en modo sin retardo.
     * Mandarlos junto a los archivos los dejaría esperando detrás de una
     * copia de 2 GB, que es justo el retardo que arruina un cursor.
     */
    public void enviarControl(String mensaje) {
        Socket s = socket;
        if (s == null) return;
        try {
            DataOutputStream o = salidaActual;
            if (o == null) return;
            escribir(o, TIPO_CONTROL, mensaje.getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignorado) {
            // Un toque perdido no vale cerrar la conexión: el siguiente llega.
        }
    }

    public void enviarCuadro(byte[] jpeg) {
        synchronized (candado) {
            if (socket == null) return;
            pendiente = jpeg;
            candado.notifyAll();
        }
    }

    public synchronized void iniciar(String host, int puerto) {
        if (activo) return;
        activo = true;
        Thread t = new Thread(() -> bucle(host, puerto), "conexion");
        hilo = t;
        t.start();
    }

    public synchronized void detener() {
        activo = false;
        cerrarSocket();
        if (hilo != null) hilo.interrupt();
        hilo = null;
    }

    private void cerrarSocket() {
        Socket s;
        synchronized (candado) {
            s = socket;
            socket = null;
            pendiente = null;
            candado.notifyAll();
        }
        if (s != null) {
            try { s.close(); } catch (IOException ignorado) { }
        }
    }

    private Socket abrir(String host, int puerto) throws IOException {
        Network red = redEthernet;
        if (red != null) {
            // Primero por el cable: Android no manda tráfico por un Ethernet
            // "sin internet" a menos que el socket se amarre a esa red.
            Socket s = new Socket();
            try {
                red.bindSocket(s);
                s.connect(new InetSocketAddress(host, puerto), 3000);
                return s;
            } catch (IOException e) {
                try { s.close(); } catch (IOException ignorado) { }
            }
        }
        // Si no hay cable (o la PC está por WiFi), conexión normal.
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, puerto), 3000);
        } catch (IOException e) {
            try { s.close(); } catch (IOException ignorado) { }
            throw e;
        }
        return s;
    }

    /** Cada hilo de conexión solo sigue vivo mientras sea el hilo actual. */
    private boolean sigo() {
        return activo && hilo == Thread.currentThread();
    }

    private void bucle(String host, int puerto) {
        while (sigo()) {
            oyente.alCambiarEstado("Conectando a " + host + ":" + puerto + "…", false);
            Socket s = null;
            Thread envio = null;
            try {
                s = abrir(host, puerto);
                s.setTcpNoDelay(true);
                s.setSendBufferSize(256 * 1024);
                DataInputStream entrada = new DataInputStream(new BufferedInputStream(s.getInputStream(), 256 * 1024));
                final DataOutputStream salida = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), 256 * 1024));
                salidaActual = salida;
                enCamino.set(0);

                escribir(salida, TIPO_TEXTO, ("HOLA|" + Build.MANUFACTURER + " " + Build.MODEL).getBytes(StandardCharsets.UTF_8));

                synchronized (candado) {
                    if (!sigo()) throw new IOException("detenido");
                    socket = s;
                    pendiente = null;
                }
                final Socket actual = s;
                envio = new Thread(() -> bucleEnvio(actual, salida), "envio");
                envio.start();
                oyente.alCambiarEstado("Conectado a " + host, true);

                while (sigo()) {
                    int tipo = entrada.readUnsignedByte();
                    int largo = entrada.readInt();
                    if (largo < 0 || largo > LARGO_MAXIMO) throw new IOException("mensaje inválido");
                    byte[] datos = new byte[largo];
                    entrada.readFully(datos);
                    if (tipo == TIPO_JPEG) {
                        Bitmap b = null;
                        try {
                            b = BitmapFactory.decodeByteArray(datos, 0, largo);
                        } catch (OutOfMemoryError sinMemoria) {
                            System.gc(); // se pierde este cuadro, no la conexión
                        }
                        if (b != null) oyente.alRecibirCuadro(b);
                        escribir(salida, TIPO_ACUSE, VACIO);
                    } else if (tipo == TIPO_ACUSE) {
                        if (enCamino.decrementAndGet() < 0) enCamino.set(0);
                    } else if (tipo == TIPO_TEXTO) {
                        oyente.alRecibirTexto(new String(datos, StandardCharsets.UTF_8));
                    }
                }
            } catch (IOException e) {
                if (sigo()) oyente.alCambiarEstado("Sin conexión (" + e.getMessage() + "). Reintentando…", false);
            } finally {
                synchronized (candado) {
                    if (socket == s) socket = null;
                    salidaActual = null;
                    pendiente = null;
                    candado.notifyAll();
                }
                if (s != null) {
                    try { s.close(); } catch (IOException ignorado) { }
                }
                if (envio != null) envio.interrupt();
            }
            if (!sigo()) break;
            try {
                Thread.sleep(1500);
            } catch (InterruptedException e) {
                break;
            }
        }
        if (hilo == Thread.currentThread() || hilo == null) oyente.alCambiarEstado("Desconectado", false);
    }

    private void bucleEnvio(Socket s, DataOutputStream salida) {
        try {
            while (true) {
                byte[] cuadro;
                synchronized (candado) {
                    while (socket == s && pendiente == null) candado.wait();
                    if (socket != s) return;
                    cuadro = pendiente;
                }
                enCamino.incrementAndGet();
                escribir(salida, TIPO_JPEG, cuadro);
                synchronized (candado) {
                    // Hasta aquí se libera el lugar: así la cámara no codifica
                    // cuadros que de todos modos no podrían salir.
                    if (pendiente == cuadro) pendiente = null;
                }
            }
        } catch (InterruptedException ignorado) {
        } catch (IOException e) {
            try { s.close(); } catch (IOException ignorado) { }
        }
    }

    /** Lo usan el hilo de envío (cuadros) y el de recepción (acuses), por eso va sincronizado. */
    private static void escribir(DataOutputStream o, int tipo, byte[] datos) throws IOException {
        synchronized (o) {
            o.writeByte(tipo);
            o.writeInt(datos.length);
            o.write(datos);
            o.flush();
        }
    }
}
