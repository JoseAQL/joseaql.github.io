package com.puentevideo.app;

import android.graphics.Bitmap;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;

import java.util.EnumMap;
import java.util.Map;

/**
 * Lee el código QR que enseña la PC, usando los mismos cuadros de la cámara.
 *
 * El QR dice:  puentevideo://&lt;ip&gt;:&lt;puerto&gt;
 *
 * No hace falta ninguna librería de Google ni internet: ZXing es puro Java y
 * trabaja directo sobre el canal de luz que entrega CameraX, sin convertir a
 * bitmap, que sería lento.
 */
public class LectorQr {

    public static class Direccion {
        public final String ip;
        public final int puerto;

        Direccion(String ip, int puerto) {
            this.ip = ip;
            this.puerto = puerto;
        }
    }

    private final QRCodeReader lector = new QRCodeReader();
    private final Map<DecodeHintType, Object> pistas = new EnumMap<>(DecodeHintType.class);

    public LectorQr() {
        pistas.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
    }

    /** Busca un QR en el cuadro. Devuelve null si no hay ninguno. */
    public Direccion leer(Bitmap cuadro) {
        try {
            int ancho = cuadro.getWidth();
            int alto = cuadro.getHeight();
            int[] pixeles = new int[ancho * alto];
            cuadro.getPixels(pixeles, 0, ancho, 0, 0, ancho, alto);
            RGBLuminanceSource fuente = new RGBLuminanceSource(ancho, alto, pixeles);
            Result resultado = lector.decode(new BinaryBitmap(new HybridBinarizer(fuente)), pistas);
            return interpretar(resultado.getText());
        } catch (Exception e) {
            return null;  // lo normal: en este cuadro no había código
        } finally {
            lector.reset();
        }
    }

    /** Saca la dirección del texto del QR. */
    public static Direccion interpretar(String texto) {
        if (texto == null) return null;
        String limpio = texto.trim();
        if (limpio.startsWith("puentevideo://")) {
            limpio = limpio.substring("puentevideo://".length());
        }
        int barra = limpio.indexOf('/');
        if (barra > 0) limpio = limpio.substring(0, barra);
        String ip = limpio;
        int puerto = Conexion.PUERTO;
        int dosPuntos = limpio.lastIndexOf(':');
        if (dosPuntos > 0 && limpio.indexOf(':') == dosPuntos) {  // no confundir con IPv6
            ip = limpio.substring(0, dosPuntos);
            try {
                puerto = Integer.parseInt(limpio.substring(dosPuntos + 1));
            } catch (NumberFormatException ignorado) {
            }
        }
        if (ip.isEmpty()) return null;
        return new Direccion(ip, puerto);
    }
}
