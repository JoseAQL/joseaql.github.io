package com.puentevideo.app;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.hardware.display.DisplayManager;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Size;
import android.view.Display;
import android.view.Surface;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.core.resolutionselector.AspectRatioStrategy;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.net.Inet4Address;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity implements Conexion.Oyente {

    private static final String IP_POR_DEFECTO = "192.168.77.1";
    private static final int PIDE_CAMARA = 7;

    // Resoluciones que se piden a la cámara (lado largo x lado corto)
    private static final int[][] RESOLUCIONES = {{640, 480}, {1280, 720}, {1920, 1080}};
    private static final String[] NOMBRES_RES = {"480p", "720p", "1080p"};
    private static final int[] CALIDAD_JPEG = {65, 70, 75};

    private ImageView vistaRemota;
    private PreviewView vistaLocal;
    private EditText campoIp;
    private Button botonConectar, botonEnviar, botonCambiarCamara, botonCalidad;
    private TextView textoEstado, avisoSinVideo;
    private View panel;

    // Capa que tapa todo mientras busca la PC
    private View capaConectando;
    private TextView tituloConectando, detalleConectando;
    private Button botonEscanear, botonOtras;

    // La conexión vive en Compartido: sigue viva aunque la app quede en segundo plano.
    private final Conexion conexion = Compartido.conexion;
    private final Handler principal = new Handler(Looper.getMainLooper());
    private ExecutorService hiloCamara;
    private ProcessCameraProvider proveedor;
    private Preview preview;
    private ImageAnalysis analisis;

    private boolean camaraFrontal = false;
    private volatile boolean enviando = false;  // la cámara manda cuadros (apagada por defecto)
    private int modoEnvio = 1;                   // 0 cámara, 1 pantalla (por defecto, estilo DeX), 2 nada
    private static final int PIDE_AVISOS = 8;
    private static final String[] NOMBRES_MODO = {"Envío: cámara", "Envío: pantalla", "Envío: nada"};
    private ActivityResultLauncher<Intent> pedirPantalla;
    private int indiceRes = 1;
    private volatile int calidadJpeg = CALIDAD_JPEG[1];
    private long ultimoEnvio = 0;

    private ConnectivityManager gestorRed;
    private ConnectivityManager.NetworkCallback llamadaRed;
    private volatile String infoEthernet = "Sin cable Ethernet";

    // Busca sola la PC: así no hay que teclear ninguna IP.
    private final BuscadorPC buscador = new BuscadorPC();
    private volatile boolean buscarSolo = true;
    private boolean buscarAlVolver = false;
    private volatile String pcEncontrada = "";
    private volatile String ipEthernet = null;   // mi IP en el cable, si la hay
    private volatile String servidorDhcp = null; // quien me dio la IP: casi siempre la PC
    private long inicioBusqueda = 0;
    private final ConexionRapida rapida = new ConexionRapida();
    private volatile String pasoBusqueda = "";

    // Archivos: va en su propio socket (puerto 5005) y no en el del video,
    // porque TCP entrega en orden y un archivo grande dejaría la imagen
    // congelada esperando detrás de él.
    private Archivos archivos;
    private android.app.AlertDialog dialogoArchivos;
    private android.widget.ArrayAdapter<String> listaArchivos;
    private android.widget.TextView tituloArchivos;
    private ActivityResultLauncher<String[]> elegirArchivos;

    // Modo monitor: los toques dejan de esconder los controles y pasan a
    // mover el cursor de la PC. Arranca apagado.
    private boolean modoMonitor = false;
    private Button botonMonitor;
    private long tocadoEn = 0;
    private float tocadoX = 0, tocadoY = 0;
    private boolean arrastrando = false;
    private boolean clicDerechoHecho = false;
    private float rueda = 0;
    private static final int MS_CLIC_LARGO = 450;
    private static final float PX_PARA_ARRASTRE = 14f;

    // Lectura del código QR que enseña la PC
    private final LectorQr lectorQr = new LectorQr();
    private volatile boolean buscandoQr = false;
    private long ultimaLecturaQr = 0;

    private String estadoConexion = "Desconectado";
    private String nombrePc = "";
    private final AtomicInteger cuadrosEnviados = new AtomicInteger();
    private final AtomicInteger cuadrosRecibidos = new AtomicInteger();
    private int fpsEnviados = 0, fpsRecibidos = 0;


    private volatile Bitmap ultimoRecibido;
    private final AtomicBoolean dibujoPendiente = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        vistaRemota = findViewById(R.id.vistaRemota);
        vistaLocal = findViewById(R.id.vistaLocal);
        campoIp = findViewById(R.id.campoIp);
        botonConectar = findViewById(R.id.botonConectar);
        botonEnviar = findViewById(R.id.botonEnviar);
        botonCambiarCamara = findViewById(R.id.botonCambiarCamara);
        botonCalidad = findViewById(R.id.botonCalidad);
        textoEstado = findViewById(R.id.textoEstado);
        avisoSinVideo = findViewById(R.id.avisoSinVideo);
        panel = findViewById(R.id.panel);

        vistaLocal.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        vistaLocal.setScaleType(PreviewView.ScaleType.FIT_CENTER);

        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        campoIp.setText(prefs.getString("ip", IP_POR_DEFECTO));
        indiceRes = prefs.getInt("res", 1);
        if (indiceRes < 0 || indiceRes >= RESOLUCIONES.length) indiceRes = 1;
        calidadJpeg = CALIDAD_JPEG[indiceRes];
        Compartido.calidadJpeg = calidadJpeg;
        Compartido.ladoLargoPantalla = RESOLUCIONES[indiceRes][0];
        botonCalidad.setText(NOMBRES_RES[indiceRes]);

        hiloCamara = Executors.newSingleThreadExecutor();

        botonConectar.setOnClickListener(v -> alternarConexion());
        Button botonRed = findViewById(R.id.botonRed);
        botonRed.setOnClickListener(v -> otrasFormasDeConectar());

        capaConectando = findViewById(R.id.capaConectando);
        tituloConectando = findViewById(R.id.tituloConectando);
        detalleConectando = findViewById(R.id.detalleConectando);
        botonEscanear = findViewById(R.id.botonEscanear);
        botonOtras = findViewById(R.id.botonOtras);
        botonEscanear.setOnClickListener(v -> escanearQr());
        botonOtras.setOnClickListener(v -> otrasFormasDeConectar());
        // El selector del sistema entrega Uri ya autorizados, así que la app no
        // necesita ningún permiso de almacenamiento para mandar archivos.
        elegirArchivos = registerForActivityResult(
                new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
                    if (uris == null || uris.isEmpty()) return;
                    if (!archivos.conectado()) {
                        android.widget.Toast.makeText(this,
                                "Todavía no hay conexión de archivos con la PC.",
                                android.widget.Toast.LENGTH_LONG).show();
                        return;
                    }
                    archivos.mandar(uris);
                    refrescarListaArchivos();
                });
        pedirPantalla = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), res -> {
            if (res.getResultCode() == RESULT_OK && res.getData() != null) {
                Intent i = new Intent(this, ServicioPantalla.class)
                        .putExtra(ServicioPantalla.EXTRA_CODIGO, res.getResultCode())
                        .putExtra(ServicioPantalla.EXTRA_DATOS, res.getData());
                ContextCompat.startForegroundService(this, i);
            } else {
                modoEnvio = 2; // no dio permiso
                actualizarBotonEnvio();
            }
        });
        botonEnviar.setOnClickListener(v -> cambiarModoEnvio());
        Compartido.destino = this;
        if (ServicioPantalla.activo) {
            modoEnvio = 1;
            enviando = false;
        }
        actualizarBotonEnvio();
        if (conexion.estaActiva()) botonConectar.setText("Desconectar");
        botonCambiarCamara.setOnClickListener(v -> {
            camaraFrontal = !camaraFrontal;
            botonCambiarCamara.setText(camaraFrontal ? "Cámara frontal" : "Cámara trasera");
            vincularCamara();
        });
        archivos = new Archivos(this, new Archivos.Oyente() {
            @Override
            public void alCambiarArchivos() {
                principal.post(MainActivity.this::refrescarListaArchivos);
            }

            @Override
            public void alAvisar(String texto) {
                principal.post(() -> android.widget.Toast.makeText(
                        MainActivity.this, texto, android.widget.Toast.LENGTH_LONG).show());
            }
        });
        findViewById(R.id.botonArchivos).setOnClickListener(v -> abrirArchivos());

        botonCalidad.setOnClickListener(v -> {
            indiceRes = (indiceRes + 1) % RESOLUCIONES.length;
            calidadJpeg = CALIDAD_JPEG[indiceRes];
        Compartido.calidadJpeg = calidadJpeg;
        Compartido.ladoLargoPantalla = RESOLUCIONES[indiceRes][0];
            botonCalidad.setText(NOMBRES_RES[indiceRes]);
            getPreferences(MODE_PRIVATE).edit().putInt("res", indiceRes).apply();
            vincularCamara();
        });
        vistaRemota.setOnClickListener(v -> alternarControles());
        botonMonitor = findViewById(R.id.botonMonitor);
        botonMonitor.setOnClickListener(v -> alternarModoMonitor());
        vistaRemota.setOnTouchListener((v, ev) -> atenderToque(ev));

        vigilarEthernet();
        vigilarAvisosDeLaPc();

        // La cámara arranca apagada: no se abre ni se pide permiso hasta que elijas «cámara».
        vistaLocal.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // para la notificación de «compartiendo pantalla»
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, PIDE_AVISOS);
        }

        // Girar el teléfono 180° no dispara onConfigurationChanged: lo vigilamos aparte.
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (dm != null) dm.registerDisplayListener(oyentePantalla, principal);

        principal.postDelayed(contadorFps, 1000);
        refrescarEstado();
        atenderPedidoDeLaPc(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        atenderPedidoDeLaPc(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (buscarAlVolver) {
            // Regresó de encender el anclaje USB en Ajustes: a buscar la PC.
            buscarAlVolver = false;
            buscarSolo = true;
            pcEncontrada = "";
            inicioBusqueda = System.currentTimeMillis();
            principal.postDelayed(this::lanzarBusquedaRapida, 1500);
        }
    }

    /**
     * La PC puede abrir la app por el cable USB (adb) y decirle a dónde
     * conectarse: «--es conectar 127.0.0.1». Solo se aceptan direcciones del
     * propio celular, que es lo único que tiene sentido por el túnel de adb;
     * así una app ajena no puede mandarnos a conectar a cualquier lado.
     */
    private void atenderPedidoDeLaPc(Intent intent) {
        if (intent == null) return;
        String destino = intent.getStringExtra("conectar");
        if (destino == null) return;
        intent.removeExtra("conectar");
        if (!destino.equals(ConexionRapida.LOCAL_USB)) return;
        if (conexion.estaActiva()) return;
        conectarA(destino, Conexion.PUERTO, "cable USB");
    }

    private final DisplayManager.DisplayListener oyentePantalla = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int id) { }
        @Override public void onDisplayRemoved(int id) { }
        @Override public void onDisplayChanged(int id) { actualizarRotacion(); }
    };

    private void actualizarRotacion() {
        int rot = rotacionPantalla();
        if (preview != null) preview.setTargetRotation(rot);
        if (analisis != null) analisis.setTargetRotation(rot);
    }

    // ------------------------------------------------------------------ red

    /** Busca el adaptador USB-Ethernet aunque no tenga internet. */
    private void vigilarEthernet() {
        gestorRed = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkRequest pedido = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        llamadaRed = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(@NonNull Network red) {
                conexion.setRedEthernet(red);
                if (archivos != null) archivos.setRedEthernet(red);
                infoEthernet = "Cable Ethernet detectado, esperando IP…";
                principal.post(MainActivity.this::refrescarEstado);
            }

            @Override
            public void onLinkPropertiesChanged(@NonNull Network red, @NonNull LinkProperties lp) {
                conexion.setRedEthernet(red);
                if (archivos != null) archivos.setRedEthernet(red);
                String miIp = null;
                for (LinkAddress la : lp.getLinkAddresses()) {
                    if (la.getAddress() instanceof Inet4Address) miIp = la.getAddress().getHostAddress();
                }
                String servidor = null;
                if (Build.VERSION.SDK_INT >= 30) {
                    Inet4Address dhcp = lp.getDhcpServerAddress();
                    if (dhcp != null && !dhcp.isAnyLocalAddress()) servidor = dhcp.getHostAddress();
                }
                ipEthernet = miIp;
                servidorDhcp = servidor;
                if (miIp != null) principal.post(MainActivity.this::lanzarBusquedaRapida);
                infoEthernet = miIp != null
                        ? "Ethernet: mi IP " + miIp + (servidor != null ? " · PC " + servidor : "")
                        : "Cable Ethernet detectado, sin IP. Toca «Red» y enciende «Compartir vía Ethernet».";
                final String pc = servidor;
                principal.post(() -> {
                    // Si la PC nos dio la IP por DHCP ya sabemos su dirección.
                    if (pc != null && !conexion.estaActiva()) {
                        String actual = campoIp.getText().toString().trim();
                        if (actual.isEmpty() || actual.equals(IP_POR_DEFECTO)) campoIp.setText(pc);
                    }
                    refrescarEstado();
                });
            }

            @Override
            public void onLost(@NonNull Network red) {
                conexion.setRedEthernet(null);
                if (archivos != null) archivos.setRedEthernet(null);
                infoEthernet = "Sin cable Ethernet";
                principal.post(MainActivity.this::refrescarEstado);
            }
        };
        try {
            // requestNetwork (no solo escuchar) mantiene viva la red Ethernet
            // aunque Android la considere "sin internet".
            gestorRed.requestNetwork(pedido, llamadaRed);
        } catch (Exception e) {
            infoEthernet = "No se pudo vigilar la red: " + e.getMessage();
        }
    }

    /**
     * Escucha el aviso de la PC y se conecta solo.
     *
     * Si el usuario apretó «Desconectar» a propósito, no se vuelve a conectar
     * hasta que él lo pida; para eso está buscarSolo.
     */
    /** ¿Esta IP está en la misma red que mi cable? (mismos tres primeros números) */
    private boolean esDelCable(String ip) {
        String mia = ipEthernet;
        if (mia == null || ip == null) return false;
        int corte = mia.lastIndexOf('.');
        return corte > 0 && ip.startsWith(mia.substring(0, corte + 1));
    }

    /**
     * Arranca la búsqueda a lo bruto: prueba varios caminos a la vez.
     *
     * Corre junto con los avisos que grita la PC; gana el que llegue primero.
     */
    private void lanzarBusquedaRapida() {
        if (!buscarSolo || conexion.estaActiva()) return;
        String ultima = getPreferences(MODE_PRIVATE).getString("ip", "");
        rapida.buscar(conexion.getRedEthernet(), ultima, servidorDhcp, Conexion.PUERTO,
                new ConexionRapida.Oyente() {
                    @Override
                    public void encontrada(String ip, int puerto) {
                        principal.post(() -> conectarA(ip, puerto, "encontrada sola"));
                    }

                    @Override
                    public void avance(String queEstoyHaciendo) {
                        pasoBusqueda = queEstoyHaciendo;
                        principal.post(MainActivity.this::refrescarEstado);
                    }
                });
    }

    /** Se conecta y deja todo listo. Se llama desde cualquier camino. */
    private void conectarA(String ip, int puerto, String comoLlegue) {
        if (conexion.estaActiva()) return;
        rapida.detener();
        pcEncontrada = ip + " (" + comoLlegue + ")";
        pasoBusqueda = "";
        campoIp.setText(ip);
        getPreferences(MODE_PRIVATE).edit().putString("ip", ip).apply();
        botonConectar.setText("Desconectar");
        conexion.iniciar(ip, puerto);
        archivos.setRedEthernet(conexion.getRedEthernet());
        archivos.iniciar(ip);
        if (modoEnvio == 1 && !ServicioPantalla.activo) pedirPermisoPantalla();
        refrescarEstado();
    }

    private void vigilarAvisosDeLaPc() {
        inicioBusqueda = System.currentTimeMillis();
        lanzarBusquedaRapida();
        // Si en 7 segundos no conectó sola, se ofrece el rescate por QR.
        principal.postDelayed(() -> {
            if (conexion.estaActiva() || buscandoQr) return;
            refrescarEstado();
        }, 7200);
        buscador.iniciar((ip, puerto, nombre) -> principal.post(() -> {
            pcEncontrada = ip + " (" + nombre + ")";
            if (!buscarSolo || conexion.estaActiva()) {
                refrescarEstado();
                return;
            }
            // El cable va mejor que el Wi-Fi: se le dan unos segundos de ventaja.
            boolean esperandoCable = ipEthernet != null && !esDelCable(ip)
                    && System.currentTimeMillis() - inicioBusqueda < 5000;
            if (esperandoCable) {
                refrescarEstado();
                return;
            }
            conectarA(ip, puerto, "se anunció sola");
        }));
    }

    /**
     * Abre la pantalla de «Compartir vía Ethernet» del celular.
     *
     * Ahí se enciende la opción que hace que el celular le reparta IP a la PC
     * por el cable. Una app normal no puede encenderla sola, pero sí llevarte.
     */
    private void abrirAjustesDeRed() {
        String[] acciones = {"android.settings.TETHER_SETTINGS",
                             android.provider.Settings.ACTION_WIRELESS_SETTINGS};
        for (String accion : acciones) {
            try {
                startActivity(new Intent(accion).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                Toast.makeText(this, "Enciende «Compartir vía Ethernet»", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignorado) {
            }
        }
        Toast.makeText(this, "Abre Ajustes → Punto de acceso → Compartir vía Ethernet",
                Toast.LENGTH_LONG).show();
    }

    private void alternarConexion() {
        if (conexion.estaActiva()) {
            buscarSolo = false;  // lo desconectó a propósito
            rapida.detener();
            conexion.detener();
            archivos.detener();
            botonConectar.setText("Conectar");
            return;
        }
        buscarSolo = true;
        lanzarBusquedaRapida();
        String texto = campoIp.getText().toString().trim();
        if (texto.isEmpty()) texto = IP_POR_DEFECTO;
        String host = texto;
        int puerto = Conexion.PUERTO;
        int dosPuntos = texto.lastIndexOf(':');
        if (dosPuntos > 0) {
            host = texto.substring(0, dosPuntos);
            try { puerto = Integer.parseInt(texto.substring(dosPuntos + 1)); } catch (NumberFormatException ignorado) { }
        }
        getPreferences(MODE_PRIVATE).edit().putString("ip", texto).apply();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(campoIp.getWindowToken(), 0);
        botonConectar.setText("Desconectar");
        conexion.iniciar(host, puerto);
        archivos.setRedEthernet(conexion.getRedEthernet());
        archivos.iniciar(host);
        // modo por defecto: al conectar se pide permiso para mandar la pantalla
        if (modoEnvio == 1 && !ServicioPantalla.activo) pedirPermisoPantalla();
    }

    @Override
    public void alCambiarEstado(String texto, boolean conectado) {
        principal.post(() -> {
            estadoConexion = texto;
            if (!conectado) nombrePc = "";
            if (!conexion.estaActiva()) botonConectar.setText("Conectar");
            refrescarEstado();
        });
    }

    @Override
    public void alRecibirCuadro(Bitmap cuadro) {
        cuadrosRecibidos.incrementAndGet();
        ultimoRecibido = cuadro;
        // Solo un dibujo en cola: si llegan cuadros más rápido que la pantalla, se salta.
        if (dibujoPendiente.compareAndSet(false, true)) {
            principal.post(() -> {
                dibujoPendiente.set(false);
                Bitmap b = ultimoRecibido;
                if (b != null) {
                    vistaRemota.setImageBitmap(b);
                    avisoSinVideo.setVisibility(View.GONE);
                }
            });
        }
    }

    @Override
    public void alRecibirTexto(String texto) {
        if (texto.startsWith("HOLA|")) {
            // los límites de tamaño de un nodo HDMI los guarda Compartido
            principal.post(() -> {
                nombrePc = texto.substring(5);
                refrescarEstado();
            });
        }
    }

    private final Runnable contadorFps = new Runnable() {
        @Override
        public void run() {
            fpsEnviados = cuadrosEnviados.getAndSet(0) + ServicioPantalla.enviados.getAndSet(0);
            fpsRecibidos = cuadrosRecibidos.getAndSet(0);
            refrescarEstado();
            principal.postDelayed(this, 1000);
        }
    };

    private void refrescarEstado() {
        StringBuilder sb = new StringBuilder();
        sb.append(estadoConexion);
        if (!nombrePc.isEmpty()) sb.append(" (").append(nombrePc).append(")");
        if (conexion.estaActiva()) {
            sb.append("  ·  envío ").append(fpsEnviados).append(" fps, recibo ").append(fpsRecibidos).append(" fps");
        }
        sb.append("\n").append(infoEthernet);
        if (!conexion.estaActiva()) {
            if (!pcEncontrada.isEmpty()) {
                sb.append("\nPC: ").append(pcEncontrada);
            } else {
                sb.append("\n").append(pasoBusqueda.isEmpty()
                        ? "Buscando la PC… abre Puente Video en la PC y conecta el cable."
                        : pasoBusqueda);
            }
        }
        textoEstado.setText(sb.toString());
        refrescarCapaConectando();
    }

    /**
     * La capa de «Buscando tu PC» tapa todo mientras no hay conexión.
     *
     * Así el usuario normal nunca ve una IP. Los botones de rescate (QR y el
     * menú) solo aparecen cuando la búsqueda automática ya tardó demasiado,
     * para no pedirle trabajo a quien no lo necesita.
     */
    private void refrescarCapaConectando() {
        if (capaConectando == null) return;
        boolean conectado = conexion.estaActiva();
        if (conectado || buscandoQr) {
            capaConectando.setVisibility(View.GONE);
            return;
        }
        capaConectando.setVisibility(View.VISIBLE);
        boolean tardando = System.currentTimeMillis() - inicioBusqueda > 7000;
        tituloConectando.setText(tardando ? "No encuentro la PC" : "Buscando tu PC");
        String detalle = tardando
                ? "Revisa que el cable esté conectado y que Puente Video esté abierto en la PC."
                : (pasoBusqueda.isEmpty()
                        ? "Conecta el cable y abre Puente Video en la PC."
                        : pasoBusqueda);
        detalleConectando.setText(detalle);
        botonEscanear.setVisibility(tardando ? View.VISIBLE : View.GONE);
        botonOtras.setVisibility(tardando ? View.VISIBLE : View.GONE);
    }

    // ------------------------------------------------------- qué se manda

    /** Orden del botón: pantalla → cámara → nada → pantalla… */
    private void cambiarModoEnvio() {
        modoEnvio = modoEnvio == 1 ? 0 : (modoEnvio == 0 ? 2 : 1);
        if (modoEnvio == 0) {
            if (ServicioPantalla.activo) stopService(new Intent(this, ServicioPantalla.class));
            encenderCamara();
        } else {
            apagarCamara();
            if (modoEnvio == 1) {
                pedirPermisoPantalla();
            } else if (ServicioPantalla.activo) {
                stopService(new Intent(this, ServicioPantalla.class));
            }
        }
        actualizarBotonEnvio();
    }

    /**
     * Panel de archivos. A propósito es una lista de transferencias y no un
     * explorador del celular: navegar todo el almacenamiento desde la PC pide
     * MANAGE_EXTERNAL_STORAGE, que Google casi no aprueba y que obligaría a
     * repartir el APK a mano para siempre. Mandar y recibir no piden nada.
     */
    private void abrirArchivos() {
        if (dialogoArchivos != null && dialogoArchivos.isShowing()) {
            refrescarListaArchivos();
            return;
        }
        android.widget.LinearLayout caja = new android.widget.LinearLayout(this);
        caja.setOrientation(android.widget.LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        caja.setPadding(p, p, p, 0);

        tituloArchivos = new android.widget.TextView(this);
        tituloArchivos.setTextSize(13f);
        caja.addView(tituloArchivos);

        android.widget.ListView lv = new android.widget.ListView(this);
        listaArchivos = new android.widget.ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, new java.util.ArrayList<>());
        lv.setAdapter(listaArchivos);
        caja.addView(lv, new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        dialogoArchivos = new android.app.AlertDialog.Builder(this)
                .setTitle("Archivos")
                .setView(caja)
                .setPositiveButton("Mandar a la PC…", null)
                .setNeutralButton("Quitar terminadas", null)
                .setNegativeButton("Cerrar", null)
                .create();
        dialogoArchivos.setOnShowListener(d -> {
            // Se enganchan aquí y no en el Builder para que el diálogo no se
            // cierre al tocarlos: uno abre el selector y el otro limpia la
            // lista, y en los dos casos uno quiere seguir viendo el panel.
            dialogoArchivos.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
                    .setOnClickListener(v -> elegirArchivos.launch(new String[]{"*/*"}));
            dialogoArchivos.getButton(android.app.AlertDialog.BUTTON_NEUTRAL)
                    .setOnClickListener(v -> archivos.limpiarTerminadas());
        });
        dialogoArchivos.show();
        refrescarListaArchivos();
    }

    private void refrescarListaArchivos() {
        if (dialogoArchivos == null || !dialogoArchivos.isShowing()) return;
        if (tituloArchivos != null) {
            String t = archivos.estado;
            if (archivos.conectado()) {
                t = "Conectado con la PC por el puerto " + Archivos.PUERTO
                        + ".\nLo que llegue se guarda en " + archivos.dondeLlegan() + ".";
            }
            tituloArchivos.setText(t);
        }
        if (listaArchivos != null) {
            java.util.List<Archivos.Copia> copias = archivos.lista();
            listaArchivos.clear();
            // Al revés: lo más reciente arriba, que es lo que uno quiere ver.
            for (int i = copias.size() - 1; i >= 0; i--) {
                listaArchivos.add(copias.get(i).resumen());
            }
            listaArchivos.notifyDataSetChanged();
        }
    }

    private void pedirPermisoPantalla() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (mpm != null) {
            pedirPantalla.launch(mpm.createScreenCaptureIntent());
        } else {
            modoEnvio = 2;
            actualizarBotonEnvio();
        }
    }

    /** La cámara solo se abre (y solo se pide su permiso) cuando eliges «cámara». */
    private void encenderCamara() {
        enviando = true;
        vistaLocal.setVisibility(View.VISIBLE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PIDE_CAMARA);
        } else if (proveedor == null) {
            iniciarCamara();
        } else {
            vincularCamara();
        }
    }

    /** Enciende la cámara para leer el código QR que enseña la PC. */
    private void escanearQr() {
        buscandoQr = true;
        pasoBusqueda = "Apunta la cámara al código de la PC";
        vistaLocal.setVisibility(View.VISIBLE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PIDE_CAMARA);
        } else if (proveedor == null) {
            iniciarCamara();
        } else {
            vincularCamara();
        }
        refrescarEstado();
    }

    /** El menú de rescate: de lo más fácil a lo más laborioso. */
    private void otrasFormasDeConectar() {
        final String[] opciones = {
                "Escanear el código de la PC",
                "Buscar otra vez",
                "Escribir la dirección a mano",
                "Arreglar la red del celular",
                "Cable USB: depuración USB",
                "Cable USB: anclaje USB",
        };
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Otras formas de conectar")
                .setItems(opciones, (dialogo, cual) -> {
                    switch (cual) {
                        case 0:
                            escanearQr();
                            break;
                        case 1:
                            pcEncontrada = "";
                            inicioBusqueda = System.currentTimeMillis();
                            buscarSolo = true;
                            lanzarBusquedaRapida();
                            break;
                        case 2:
                            campoIp.setVisibility(View.VISIBLE);
                            campoIp.requestFocus();
                            Toast.makeText(this, "Escribe la dirección que sale en la PC",
                                    Toast.LENGTH_LONG).show();
                            break;
                        case 3:
                            abrirAjustesDeRed();
                            break;
                        case 4:
                            conectarPorUsbAdb();
                            break;
                        default:
                            abrirAnclajeUsb();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Cable USB con depuración USB: la PC pone el túnel de adb y aquí basta con
     * conectarse a 127.0.0.1. Si el túnel no está, se explica qué falta.
     */
    private void conectarPorUsbAdb() {
        if (conexion.estaActiva()) return;
        new Thread(() -> {
            boolean hay = false;
            java.net.Socket s = new java.net.Socket();
            try {
                s.connect(new java.net.InetSocketAddress(ConexionRapida.LOCAL_USB, Conexion.PUERTO), 800);
                hay = true;
            } catch (Exception ignorado) {
            } finally {
                try { s.close(); } catch (Exception ignorado) { }
            }
            final boolean listo = hay;
            principal.post(() -> {
                if (listo) {
                    conectarA(ConexionRapida.LOCAL_USB, Conexion.PUERTO, "cable USB");
                    return;
                }
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Conectar por el cable USB")
                        .setMessage("1. En el celular: Ajustes › Opciones de desarrollador › "
                                + "activa «Depuración USB».\n"
                                + "   (Si no ves Opciones de desarrollador: Ajustes › Acerca del "
                                + "teléfono › toca 7 veces «Número de compilación» o «Versión de MIUI».)\n\n"
                                + "2. Conecta el cable USB a la PC y acepta «¿Permitir depuración USB?».\n\n"
                                + "3. En la PC, en «Cable USB del celular», presiona "
                                + "«Conectar por USB». La app se conecta sola.")
                        .setPositiveButton("Abrir opciones de desarrollador", (d, w) -> {
                            try {
                                startActivity(new Intent(
                                        android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
                            } catch (Exception e) {
                                Toast.makeText(this, "Actívalas primero desde «Acerca del teléfono»",
                                        Toast.LENGTH_LONG).show();
                            }
                        })
                        .setNegativeButton("Cerrar", null)
                        .show();
            });
        }, "usb-adb").start();
    }

    /**
     * Cable USB con anclaje: el celular le reparte IP a la PC por el USB, como
     * con el cable Ethernet. Una app no puede encenderlo sola; se lleva al
     * usuario a la pantalla y, al volver, se busca la PC.
     */
    private void abrirAnclajeUsb() {
        if (ConexionRapida.hayAnclajeUsb()) {
            buscarSolo = true;
            pcEncontrada = "";
            inicioBusqueda = System.currentTimeMillis();
            lanzarBusquedaRapida();
            Toast.makeText(this, "El anclaje USB ya está encendido: buscando la PC…", Toast.LENGTH_SHORT).show();
            return;
        }
        buscarAlVolver = true;
        String[] acciones = {"android.settings.TETHER_SETTINGS",
                             android.provider.Settings.ACTION_WIRELESS_SETTINGS};
        for (String accion : acciones) {
            try {
                startActivity(new Intent(accion).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                Toast.makeText(this, "Enciende «Anclaje USB» y regresa a la app. "
                        + "Apaga los datos móviles si no quieres que la PC los use.", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignorado) {
            }
        }
        Toast.makeText(this, "Abre Ajustes › Compartir conexión › Anclaje USB", Toast.LENGTH_LONG).show();
    }

    private void apagarCamara() {
        buscandoQr = false;
        enviando = false;
        if (proveedor != null) proveedor.unbindAll();
        vistaLocal.setVisibility(View.GONE);
    }

    private void actualizarBotonEnvio() {
        botonEnviar.setText(NOMBRES_MODO[modoEnvio]);
    }

    /** Lo llama el servicio cuando se deja de compartir (por ejemplo desde la notificación). */
    public void alTerminarPantalla() {
        principal.post(() -> {
            if (modoEnvio == 1) {
                modoEnvio = 2;
                actualizarBotonEnvio();
            }
        });
    }

    /** Tocar el video esconde los controles y las barras: la tablet queda como monitor. */
    /**
     * Convierte un toque en la vista a la proporción sobre la imagen de la PC.
     *
     * El detalle que hay que cuidar: la imagen se dibuja con `fitCenter`, así
     * que casi nunca llena la vista; quedan franjas negras arriba y abajo, o a
     * los lados. Tomar la proporción sobre el tamaño de la **vista** haría que
     * el cursor se desplazara cada vez más conforme uno se aleja del centro, y
     * ese error es de los que se sienten como «está mal calibrado» sin que se
     * vea de dónde sale. Por eso se invierte la matriz de dibujo del
     * ImageView, que es la que sabe dónde quedó la imagen de verdad.
     *
     * Devuelve null si el dedo cayó en la franja negra, fuera de la imagen.
     */
    private float[] proporcionDelToque(float x, float y) {
        android.graphics.drawable.Drawable d = vistaRemota.getDrawable();
        if (d == null) return null;
        int ancho = d.getIntrinsicWidth(), alto = d.getIntrinsicHeight();
        if (ancho <= 0 || alto <= 0) return null;
        android.graphics.Matrix inversa = new android.graphics.Matrix();
        if (!vistaRemota.getImageMatrix().invert(inversa)) return null;
        float[] punto = { x - vistaRemota.getPaddingLeft(), y - vistaRemota.getPaddingTop() };
        inversa.mapPoints(punto);
        float px = punto[0] / ancho, py = punto[1] / alto;
        if (px < 0 || px > 1 || py < 0 || py > 1) return null;
        return new float[] { px, py };
    }

    private void alternarModoMonitor() {
        modoMonitor = !modoMonitor;
        botonMonitor.setText(modoMonitor ? "Usar como monitor: encendido" : "Usar como monitor: apagado");
        if (modoMonitor) {
            android.widget.Toast.makeText(this,
                    "Toca para mover y dar clic. Mantén apretado para clic derecho. "
                    + "En la PC hay que encenderlo también.",
                    android.widget.Toast.LENGTH_LONG).show();
            // Con el panel encima no se alcanza la pantalla de la PC, y ya no
            // se puede esconder tocando, porque tocar ahora es dar clic.
            if (panel.getVisibility() == View.VISIBLE) alternarControles();
        }
    }

    /** Los toques sobre el video. Devuelve true cuando se los queda el modo monitor. */
    private boolean atenderToque(MotionEvent ev) {
        if (!modoMonitor || !conexion.estaActiva()) return false;

        // Dos dedos = rueda. Se manda por tramos para que no se vaya de largo.
        if (ev.getPointerCount() >= 2) {
            if (ev.getActionMasked() == MotionEvent.ACTION_MOVE) {
                float[] p = proporcionDelToque(ev.getX(0), ev.getY(0));
                float avance = ev.getY(0) - tocadoY;
                tocadoY = ev.getY(0);
                rueda += avance;
                if (p != null && Math.abs(rueda) > 40) {
                    int pasos = (int) (rueda / 40);
                    rueda -= pasos * 40;
                    conexion.enviarControl("rueda|" + p[0] + "|" + p[1] + "|" + pasos);
                }
            } else {
                tocadoY = ev.getY(0);
                rueda = 0;
            }
            return true;
        }

        float[] p = proporcionDelToque(ev.getX(), ev.getY());
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                tocadoEn = System.currentTimeMillis();
                tocadoX = ev.getX();
                tocadoY = ev.getY();
                arrastrando = false;
                clicDerechoHecho = false;
                if (p != null) conexion.enviarControl("mover|" + p[0] + "|" + p[1]);
                return true;

            case MotionEvent.ACTION_MOVE:
                if (p == null) return true;
                boolean lejos = Math.abs(ev.getX() - tocadoX) > PX_PARA_ARRASTRE
                        || Math.abs(ev.getY() - tocadoY) > PX_PARA_ARRASTRE;
                if (!arrastrando && lejos) {
                    // Se movió: ya no es un clic, es un arrastre. Se aprieta
                    // el botón ahora y se suelta al levantar el dedo, que es
                    // lo que deja mover ventanas y seleccionar texto.
                    arrastrando = true;
                    conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|izq|abajo");
                }
                if (!arrastrando && !clicDerechoHecho
                        && System.currentTimeMillis() - tocadoEn > MS_CLIC_LARGO) {
                    clicDerechoHecho = true;
                    conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|der|abajo");
                    conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|der|arriba");
                }
                conexion.enviarControl("mover|" + p[0] + "|" + p[1]);
                return true;

            case MotionEvent.ACTION_UP:
                if (p == null) return true;
                if (arrastrando) {
                    conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|izq|arriba");
                } else if (!clicDerechoHecho) {
                    if (System.currentTimeMillis() - tocadoEn > MS_CLIC_LARGO) {
                        conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|der|abajo");
                        conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|der|arriba");
                    } else {
                        conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|izq|abajo");
                        conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|izq|arriba");
                    }
                }
                arrastrando = false;
                return true;

            case MotionEvent.ACTION_CANCEL:
                if (arrastrando && p != null) {
                    // Sin esto el botón se queda apretado en la PC y todo lo
                    // que el cursor toque después se arrastra solo.
                    conexion.enviarControl("clic|" + p[0] + "|" + p[1] + "|izq|arriba");
                }
                arrastrando = false;
                return true;

            default:
                return true;
        }
    }

    private void alternarControles() {
        boolean ocultar = panel.getVisibility() == View.VISIBLE;
        panel.setVisibility(ocultar ? View.GONE : View.VISIBLE);
        vistaLocal.setVisibility(ocultar && modoEnvio != 0 ? View.GONE : View.VISIBLE);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (ocultar) {
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            c.hide(WindowInsetsCompat.Type.systemBars());
        } else {
            c.show(WindowInsetsCompat.Type.systemBars());
        }
    }

    // --------------------------------------------------------------- cámara

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PIDE_CAMARA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (modoEnvio == 0) {
                    if (proveedor == null) iniciarCamara(); else vincularCamara();
                }
            } else {
                estadoConexion = "Sin permiso de cámara: puedes mandar la pantalla o solo ver el video de la PC";
                modoEnvio = 2;
                apagarCamara();
                actualizarBotonEnvio();
                refrescarEstado();
            }
        }
    }

    private void iniciarCamara() {
        ListenableFuture<ProcessCameraProvider> futuro = ProcessCameraProvider.getInstance(this);
        futuro.addListener(() -> {
            try {
                proveedor = futuro.get();
                vincularCamara();
            } catch (Exception e) {
                estadoConexion = "No se pudo abrir la cámara: " + e.getMessage();
                refrescarEstado();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private int rotacionPantalla() {
        Display d = vistaLocal.getDisplay();
        if (d == null) d = getWindowManager().getDefaultDisplay();
        return d != null ? d.getRotation() : Surface.ROTATION_0;
    }

    private void vincularCamara() {
        if (proveedor == null) return;
        if (modoEnvio != 0) { // cámara apagada: no se vuelve a abrir al cambiar calidad o lente
            proveedor.unbindAll();
            return;
        }
        proveedor.unbindAll();
        int rot = rotacionPantalla();
        int[] r = RESOLUCIONES[indiceRes];
        boolean es43 = r[0] * 3 == r[1] * 4;

        preview = new Preview.Builder()
                .setTargetRotation(rot)
                .setResolutionSelector(new ResolutionSelector.Builder()
                        .setAspectRatioStrategy(es43 ? AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
                                : AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                        .build())
                .build();
        preview.setSurfaceProvider(vistaLocal.getSurfaceProvider());

        ResolutionSelector selector = new ResolutionSelector.Builder()
                .setAspectRatioStrategy(es43 ? AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
                        : AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(new ResolutionStrategy(new Size(r[0], r[1]),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
                .build();
        analisis = new ImageAnalysis.Builder()
                .setResolutionSelector(selector)
                .setTargetRotation(rot)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build();
        analisis.setAnalyzer(hiloCamara, this::procesarCuadro);

        CameraSelector cual = camaraFrontal ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA;
        try {
            proveedor.bindToLifecycle(this, cual, preview, analisis);
        } catch (Exception e) {
            estadoConexion = "No se pudo usar esa cámara: " + e.getMessage();
            refrescarEstado();
        }
    }

    /** Corre en el hilo de cámara: convierte el cuadro a JPEG y lo deja listo para enviar. */
    private void procesarCuadro(@NonNull ImageProxy imagen) {
        try {
            if (buscandoQr) {
                long ahoraQr = SystemClock.elapsedRealtime();
                if (ahoraQr - ultimaLecturaQr < 250) return;
                ultimaLecturaQr = ahoraQr;
                LectorQr.Direccion d = lectorQr.leer(imagen.toBitmap());
                if (d != null) {
                    principal.post(() -> {
                        if (!buscandoQr) return;
                        buscandoQr = false;
                        apagarCamara();
                        conectarA(d.ip, d.puerto, "código QR");
                    });
                }
                return;
            }
            if (!enviando || !conexion.listoParaCuadro()) return;
            long ahora = SystemClock.elapsedRealtime();
            if (ahora - ultimoEnvio < 30) return; // máximo ~30 fps
            ultimoEnvio = ahora;

            Bitmap bmp = imagen.toBitmap();
            int giro = imagen.getImageInfo().getRotationDegrees();
            if (giro != 0) {
                Matrix m = new Matrix();
                m.postRotate(giro);
                Bitmap girado = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                if (girado != bmp) bmp.recycle();
                bmp = girado;
            }
            Compartido.enviar(bmp); // ajusta al nodo si hace falta, JPEG y a la cola
            cuadrosEnviados.incrementAndGet();
        } catch (Throwable ignorado) {
            // Un cuadro malo no debe tumbar la app.
        } finally {
            imagen.close();
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration nueva) {
        super.onConfigurationChanged(nueva);
        // Al girar el teléfono el video que mando también gira.
        principal.post(this::actualizarRotacion);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        principal.removeCallbacksAndMessages(null);
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        if (dm != null) dm.unregisterDisplayListener(oyentePantalla);
        if (Compartido.destino == this) Compartido.destino = null;
        // si estás compartiendo la pantalla, la conexión sigue viva en segundo plano
        if (!ServicioPantalla.activo) {
            conexion.detener();
            // Puede ser nulo si onCreate no llegó a terminar.
            if (archivos != null) archivos.detener();
        }
        if (gestorRed != null && llamadaRed != null) {
            try { gestorRed.unregisterNetworkCallback(llamadaRed); } catch (Exception ignorado) { }
        }
        buscador.detener();
        rapida.detener();
        if (hiloCamara != null) hiloCamara.shutdown();
    }
}
