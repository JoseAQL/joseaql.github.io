# Puente Video

Video en vivo **en los dos sentidos** entre el celular y la PC por un cable Ethernet directo (celular con adaptador USB‑C a Ethernet). La cámara del celular se ve en la PC y, al mismo tiempo, la cámara o la pantalla de la PC se ve en el celular.

| Carpeta | Qué es |
|---|---|
| `android/` | App de Android (Java + CameraX). Se compila sola en GitHub Actions → `PuenteVideo.apk` |
| `pc/` | Programa para Windows 10/11 (Python + Tkinter + OpenCV). Se compila solo → `PuenteVideo.exe` |
| `nodo/` | **Receptor Ethernet → HDMI con STM32H743** para mandar video a varias pantallas por un switch (firmware, simulador y diseño electrónico). Ver [nodo/README.md](nodo/README.md) |

Los archivos se descargan desde **Releases → Puente Video** del repo. **Paso a paso para conectar: [CONECTAR.md](CONECTAR.md).**

## Cómo usarlo

1. Conecta el adaptador Ethernet al celular y el cable a la PC.
2. Abre `PuenteVideo.exe`. La primera vez elige tu adaptador en «Cable Ethernet» y presiona **Configurar (192.168.77.1)**. Windows pide permiso de administrador: con eso la PC queda con IP fija en ese puerto y el firewall deja pasar el video.
3. El programa le da IP al celular solo (servidor DHCP integrado), sin puerta de enlace, así que el celular sigue usando WiFi o datos para internet.
4. Instala `PuenteVideo.apk` en el celular, ábrelo, acepta el permiso de cámara y toca **Conectar** (la IP ya viene puesta: `192.168.77.1`).
5. En la PC elige qué mandar al celular: Cámara 0‑3, Pantalla o Nada.

Toca la pantalla del celular para esconder o mostrar los controles. En la PC, doble clic o F11 para pantalla completa.

**También funciona por WiFi:** si la PC y el celular están en la misma red, escribe en el celular la IP de la PC que aparece en el programa.

## Cómo funciona

- La PC es el servidor TCP en el puerto **5000**. Un solo socket lleva los dos videos.
- Cada cuadro viaja como JPEG con un encabezado de 5 bytes: `tipo (1 = JPEG, 2 = texto, 3 = acuse)` + `largo (4 bytes, big-endian)`.
- Quien recibe un cuadro contesta un acuse al mostrarlo y nunca hay más de 2 cuadros en camino: si la red o el otro equipo van lentos, se saltan cuadros y la latencia no crece.
- En Android el socket se amarra a la red Ethernet (`Network.bindSocket`), porque Android no manda tráfico por un Ethernet «sin internet» si no se le pide.
- Por Ethernet, 720p a 30 fps son unos 3‑5 MB/s, muy por debajo de los 100 Mb/s de un adaptador sencillo.

## Si algo no conecta

- **El celular no recibe IP:** cuando el programa ya diga «DHCP: Activo», desconecta y vuelve a conectar el adaptador del celular (si lo conectaste antes, Android tarda minutos en volver a pedir IP). También revisa en el programa que diga «✔ El cable tiene la IP 192.168.77.1» y «DHCP: Activo». En Samsung revisa Ajustes → Conexiones → Más ajustes → Ethernet. En Xiaomi/Poco activa **OTG** en Ajustes adicionales.
- **Conecta pero no llega video a la PC:** presiona «Configurar» otra vez para crear las reglas del firewall. Si alguna vez le diste «Cancelar» al aviso del firewall de Windows, borra la regla de bloqueo de PuenteVideo en «Firewall de Windows Defender → Configuración avanzada → Reglas de entrada».
- **«No encontré la cámara»:** prueba con Cámara 1 o 2, o cierra el programa que la esté usando (Zoom, Teams…).
- Para regresar el puerto Ethernet a como estaba, usa **Regresar a automático**.

## Mandar la pantalla y usar una tablet como monitor

- **Celular → PC (pantalla en vivo):** es el modo por defecto («Envío: pantalla»): al tocar «Conectar» Android pide permiso para compartir la pantalla. La cámara empieza apagada; el botón de envío cambia entre pantalla → cámara → nada, y el permiso de cámara solo se pide la primera vez que eliges «cámara». Android pide permiso y muestra una notificación; puedes salir de la app y se sigue mandando lo que ves (como un espejo). Para dejar de compartir usa «Detener» en la notificación.
- **PC → celular o tablet:** en «Fuente» elige «Pantalla 1», «Pantalla 2»… (uno por monitor).
- **Tablet como segundo monitor (extendido):** Windows necesita un monitor virtual. Instala el *Virtual Display Driver* (gratis, de código abierto) en PowerShell con `winget install --id=VirtualDrivers.Virtual-Display-Driver -e`; activa el monitor virtual con su app (Virtual Driver Control), acomódalo en Configuración → Pantalla → «Extender estas pantallas», reinicia Puente Video y elige ese monitor en «Fuente». En la tablet toca el video para esconder los controles y que quede a pantalla completa.
- Por ahora es solo imagen: tocar la tablet todavía no mueve el mouse de la PC.

## Con el cable USB del celular (sin adaptador Ethernet)

Sirve el cable de carga original. Hay dos formas, y las dos están en la app de la PC, en **Cable USB del celular**, y en el celular en **Otras formas de conectar**:

1. **Depuración USB (ADB), la recomendada.** En el celular activa *Opciones de desarrollador › Depuración USB* (si no las ves: *Acerca del teléfono*, toca 7 veces *Número de compilación* o *Versión de MIUI*). Conecta el cable, en la PC presiona **Conectar por USB** y acepta en el celular «¿Permitir depuración USB?». La PC pone un túnel por el cable y abre la app, que se conecta sola. No usa IPs, ni red, ni firewall, ni datos. La primera vez la PC baja `adb` de Google (unos 7 MB), con tu permiso.
2. **Anclaje USB.** En el celular: *Ajustes › Compartir conexión › Anclaje USB*. El celular le da IP a la PC por el cable, igual que con el adaptador Ethernet, y la app lo encuentra sola. Ojo: Windows puede salir a internet por ahí y gastar datos móviles; el botón **Anclaje USB: que no gaste mis datos** hace que Windows prefiera tu Wi‑Fi, y para cortarlo del todo apaga los datos móviles.

Video, archivos y control van por el mismo cable USB en las dos formas.

## Raspberry Pi: la app completa

La Raspberry Pi 4B o 5 (con escritorio) corre la misma app que la PC: recibe el video del celular, le manda su escritorio o una webcam o capturadora HDMI USB, pasa archivos y deja que el celular mueva el ratón. Se instala con `sudo sh instalar_app.sh` desde `PuenteVideo-raspberry.zip` del Release. Detalles en [`raspberry/RASPBERRY.md`](raspberry/RASPBERRY.md).

## Pantallas HDMI (nodos)

En el programa de la PC, **Pantallas HDMI (nodos)…** abre una consola donde aparecen los receptores conectados al switch. A cada uno le eliges qué mostrar (cámara, video del celular, pantalla completa o un pedazo para hacer pared de video, patrón de prueba) y con **Identificar todas** cada pantalla muestra su número. El celular también puede mandar directo a un nodo escribiendo su IP.

## El celular como segundo monitor

El programa siempre supo mandar **cualquier** pantalla: en «Lo que mando al celular» eliges Pantalla 1,
Pantalla 2, la que sea. Lo que faltaba no era mandar, era que esa segunda pantalla existiera, porque Windows
solo deja arrastrar ventanas a pantallas que su propio sistema conoce, y eso no se puede inventar desde un
programa normal.

Hay tres maneras de conseguirla. El botón **Segundo monitor…** las explica y te deja ver cuáles pantallas
reconoce Windows en este momento:

1. **Un adaptador HDMI falso** (se vende como *dummy plug* o *emulador EDID*, cuesta poco). Lo conectas a un
   puerto HDMI libre y Windows ve un monitor de verdad, porque para Windows **lo es**. No instala nada y no
   se puede echar a perder. **Es la que recomiendo.**
2. **Un controlador de pantalla virtual** (Virtual Display Driver, código abierto y firmado). El botón te
   deja correrlo, pero te avisa antes: es un controlador de pantalla, y si algo sale mal el síntoma es la
   pantalla en negro. **El programa nunca lo instala solo.**
3. **Algo que ya tengas** (spacedesk, Duet…). Si ya está, su pantalla aparece sola en la lista.

Una vez que haya dos pantallas, ponla en **Extender** en la configuración de pantalla de Windows, elige esa
pantalla aquí, y ya puedes arrastrarle ventanas.

### Y poder usarla, no solo verla

Una imagen de un monitor no es un monitor. Con la casilla **«Dejar que el celular mueva el cursor y haga
clic»**, los toques en el celular manejan la PC: tocar es clic, mantener apretado es clic derecho, arrastrar
mueve ventanas y selecciona texto, y dos dedos son la rueda. En el celular hay que encenderlo también, con
**Usar como monitor**.

Arranca apagado a propósito, y se apaga solo al cerrar y al desconectarse el celular: el permiso muere con la
conexión que lo recibió. Si no, bastaría con desconectar el cable y conectar otro teléfono para heredar un
permiso que su dueño nunca dio.

## Pasar archivos por el mismo cable

El cable que lleva el video es Ethernet directo entre los dos equipos, así que es el camino más rápido que hay
para pasarle un archivo al celular: sin nube, sin internet, y sin que ninguna app recomprima el video o la foto.
En la PC el botón **Archivos (mandar y recibir)…** y en el celular **Archivos** abren el mismo panel, y va en los
dos sentidos. Sirve para cualquier cosa: fotos, PDF, documentos de Word, videos.

Cómo se usa:

- **De la PC al celular**: arrastra los archivos a la ventana de archivos, o usa el botón. Lo que llegue queda en
  la carpeta **Descargas** del celular (en Android 9 o más viejo, en la carpeta de la propia app, porque ahí
  escribir en Descargas pediría un permiso de almacenamiento que la app no necesita para nada más).
- **Del celular a la PC**: botón **Mandar a la PC…**, que abre el selector de archivos de Android. Lo que llegue
  queda en **Descargas** (la misma carpeta que dice el celular), y hay un botón que abre esa carpeta.

Dos cosas que conviene saber:

- **Si el cable se desconecta a la mitad, no se pierde lo que ya pasó.** Al reconectar sigue desde donde se quedó.
  Con un video grande eso es la diferencia entre un estorbo y volver a empezar.
- **Se revisa que el archivo llegue completo e igual.** Cada archivo viaja con su suma SHA-256 y se compara al
  final; si no cuadra, el panel lo dice y el archivo se descarta en lugar de quedarse ahí a medias. Un documento
  de Word con un byte cambiado no avisa: abre mal mucho después, cuando ya nadie se acuerda de cómo llegó.

Los archivos van por el puerto 5005, aparte del video, que va por el 5000. Son dos conexiones a propósito: si el
archivo compartiera la del video, la imagen se congelaría mientras pasa la copia.

## Pendiente / ideas

- Audio (todavía no lleva sonido).
- Usar el video del celular como cámara virtual en Zoom/OBS.
- Explorar el celular desde la PC como un gestor de archivos completo. No está hecho porque eso sí pediría el
  permiso `MANAGE_EXTERNAL_STORAGE`, que Google casi no aprueba en la tienda; mandar y recibir, en cambio, no
  piden ningún permiso.

## Versiones

| Versión | Cambios |
|---|---|
| v5.4 | **Conectar con el cable USB del celular**, sin adaptador Ethernet: por depuración USB (túnel de adb; la PC baja adb sola y abre la app en el celular) o por anclaje USB (el celular reparte IP como con el Ethernet; botón para que Windows no gaste los datos). |
| v5.3 | **Raspberry Pi con la app completa** (video de ida y vuelta, archivos, control del ratón por X11, instalador y paquete en el Release). En la PC, el panel de la derecha tiene barra de desplazamiento y los archivos llegan a **Descargas**. En el celular, en horizontal el panel mide 272 dp. |
| v5.2 | **El celular como segundo monitor**: el programa reconoce las pantallas que tiene Windows, explica las tres formas de conseguir una segunda (sin instalar nada solo) y deja **tocar el celular para mover el cursor de la PC**. Además, el celular **en horizontal** ya acomoda el panel al costado en lugar de cortarlo, y el panel tiene deslizador para llegar a los botones de abajo. |
| v5.1 | **Pasar archivos por el mismo cable**, en los dos sentidos, con reanudación si se corta y comprobación SHA-256. En la PC también se ve, por fin, **cuál IP es la del celular y cuál la de la PC**, en renglones separados y con aviso si quedaron en redes distintas. |
| v5 | **Nunca se teclea una IP.** El celular prueba en cascada la última que sirvió, quien le dio IP por DHCP, las direcciones típicas de cable, los avisos de la PC (IPv4 y IPv6 multicast, que funciona sin que nadie reparta IP) y un barrido de la red. Si tarda, la PC enseña un **código QR** y el celular lo lee con la cámara; debajo, el menú «Otras formas de conectar». La PC escucha en doble pila, abre su firewall sola y trae el botón **Arreglar la conexión**. Pantallas rediseñadas con tarjetas redondeadas. |
| v4 | **Conexión sola, sin teclear IP**: la PC se anuncia por la red y el celular la encuentra y se conecta (prefiere el cable sobre el Wi‑Fi). Captura de pantalla con respaldos (Desktop Duplication → mss → Pillow) que arregla el error `BitBlt` de algunas laptops, escalado de pantalla por monitor, botón **Red** en el celular que lleva a «Compartir vía Ethernet», y tutorial con el método del celular repartiendo IP. |
| v3 | La cámara arranca apagada y la pantalla es lo que se manda por defecto (estilo DeX); la cámara solo se abre y pide permiso al elegirla. |
| v2.1 | El celular manda su pantalla en vivo (también en segundo plano), la PC elige qué monitor mandar, tablet como segundo monitor con monitor virtual, pantalla completa al ocultar controles. |
| v2 | Nodos Ethernet → HDMI: protocolo para receptores, consola de pantallas en la PC (pared de video, identificar), el celular ajusta el video al tamaño del nodo, firmware STM32H743 y diseño electrónico. |
| v1.1 | Revisión con Fable: acuses para que no se acumule retraso, el celular mantiene viva la red Ethernet, reglas de firewall por puerto, el DHCP se recupera al desconectar el cable, webcams en MJPG a 30 fps, elección más segura del adaptador, giro de 180° y APK con firma fija (se actualiza sin desinstalar). |
| v1 | Video en vivo en ambos sentidos (JPEG por TCP), DHCP integrado, configuración del adaptador desde el programa, cámara frontal/trasera y 480p/720p/1080p en el celular, cámara o pantalla en la PC. |
