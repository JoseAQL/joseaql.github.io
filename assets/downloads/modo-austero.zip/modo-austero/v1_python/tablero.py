# -*- coding: utf-8 -*-
"""
tablero.py - Tablero en la terminal (funciona por SSH/Tailscale). `austero ver`

Muestra estadisticas tipo overclock y, si la prendes (tecla i), la vista de la camara con bloques de color.
Salir del tablero (q) NO apaga el nucleo; Q si lo apaga.
"""
from __future__ import print_function

import base64
import os
import select
import shutil
import sys
import termios
import threading
import time
import tty

import numpy as np

from cliente import enviar

E = "\x1b["
RESET = E + "0m"
NEGRITA = E + "1m"
TENUE = E + "2m"


def col(c):
    return E + "38;5;%dm" % c


VERDE, AMAR, ROJO, CIAN, GRIS, MAG = col(82), col(220), col(196), col(45), col(244), col(207)

AYUDA = [
    "q salir  Q apagar núcleo  1-9 modelo  0 ninguno  a auto-ajuste  c calibrar  C método  v verificar  m mm",
    "p proyector  w web  h manos  i vista  b buscar  f fondo  o marcas  e enseñar  t guardar al dataset  s foto",
    "[ ] umbral  { } tamaño YOLO  ( ) nms  g/G gamma  l/L clahe  k/K kernel  n/N nitidez  B benchmark  P perfil",
]
AYUDA_ENS = "ENSEÑANDO: flechas mover  + - tamaño  * / ancho  Enter guardar  x la cámara propone  Esc terminar"


def barra(p, ancho=12):
    if p is None:
        return GRIS + "·" * ancho + RESET
    p = max(0.0, min(100.0, float(p)))
    n = int(round(p / 100.0 * ancho))
    c = VERDE if p < 60 else (AMAR if p < 85 else ROJO)
    return c + "█" * n + GRIS + "░" * (ancho - n) + RESET


def temp_txt(t):
    if not t:
        return "-"
    partes = []
    for k, v in sorted(t.items()):
        if k.lower().startswith(("pmic", "thermal", "ao")):
            continue
        c = VERDE if v < 55 else (AMAR if v < 70 else ROJO)
        partes.append("%s %s%.0f°%s" % (k.replace("-therm", ""), c, v, RESET))
    return "  ".join(partes[:5])


def resumen_texto(e, color=False):
    s = e.get("stats", {})
    c = e.get("calib", {})
    lin = []
    lin.append("modelo: %s  (%s)  %s fps  %s ms (p95 %s)  camara %s fps" % (
        e.get("modelo") or "ninguno", e.get("motor") or "-", e.get("fps"), e.get("lat_ms"), e.get("lat_p95"),
        e.get("fps_camara")))
    lin.append("CPU %s%% %s  GPU %s%%  RAM %s/%s MB  swap %s MB  proceso %.0f%% CPU %.0f MB  %s" % (
        int(s.get("cpu_prom", 0)), s.get("cpu"), s.get("gpu"), s.get("ram_mb"), s.get("ram_total_mb"),
        s.get("swap_mb"), s.get("proc_cpu", 0), s.get("proc_ram_mb", 0),
        ("%.1f W" % (s["potencia_mw"] / 1000.0)) if s.get("potencia_mw") else ""))
    lin.append("temperaturas: %s" % ", ".join("%s %.0f" % (k, v) for k, v in sorted(s.get("temp", {}).items())))
    lin.append("proyector %s | calibracion %s (%s px%s) | manos %s | web %s | buscar %s | fondo %s" % (
        _si(e.get("proyector")), c.get("metodo") if c.get("lista") else "NO", c.get("error_px"),
        ", %.2f px/mm" % c["px_por_mm"] if c.get("px_por_mm") else "", _si(e.get("manos")),
        e.get("web") or "off", _si(e.get("buscar")), _si(e.get("fondo"))))
    if e.get("params"):
        lin.append("params: " + "  ".join("%s=%s" % kv for kv in sorted(e["params"].items())))
    lin.append("filtros: " + "  ".join("%s=%s" % kv for kv in sorted(e.get("filtros", {}).items())))
    if e.get("memoria"):
        lin.append("memoria: " + ", ".join("%s (%d)" % kv for kv in sorted(e["memoria"].items())))
    if e.get("modelo_error"):
        lin.append("error modelo: " + e["modelo_error"])
    return "\n".join(lin)


def _si(v):
    return "on" if v else "off"


class Tablero(object):
    def __init__(self):
        self.vivo = True
        self.vista = False
        self.estado = {}
        self.vista_img = None
        self.mensaje = ""
        self.tabla = ""
        self.ocupado = False
        self._fd = sys.stdin.fileno()
        self._viejo = termios.tcgetattr(self._fd)
        self.truecolor = os.environ.get("COLORTERM", "") in ("truecolor", "24bit") or os.name == "nt" \
            or os.environ.get("WT_SESSION") is not None or os.environ.get("AUSTERO_TRUECOLOR") == "1"

    # ---------------------------------------------------------------- comandos sin congelar la pantalla
    def mandar(self, msg):
        def f():
            self.ocupado = True
            try:
                r = enviar(msg)
                self.mensaje = r.get("msg") or ("ok" if r.get("ok") else "error")
                if r.get("tabla"):
                    self.tabla = r["tabla"]
            except Exception as ex:
                self.mensaje = "error: %s" % ex
            self.ocupado = False
        threading.Thread(target=f, daemon=True).start()

    def preguntar(self, texto):
        termios.tcsetattr(self._fd, termios.TCSADRAIN, self._viejo)
        sys.stdout.write(E + "?25h" + "\n" + NEGRITA + texto + RESET)
        sys.stdout.flush()
        try:
            r = input()
        except EOFError:
            r = ""
        tty.setcbreak(self._fd)
        sys.stdout.write(E + "?25l")
        return r.strip()

    # ---------------------------------------------------------------- teclas
    def tecla(self):
        r, _, _ = select.select([sys.stdin], [], [], 0.25)
        if not r:
            return None
        ch = os.read(self._fd, 1).decode("utf-8", "ignore")
        if ch == "\x1b":
            r, _, _ = select.select([sys.stdin], [], [], 0.03)
            if r:
                sec = os.read(self._fd, 2).decode("utf-8", "ignore")
                return {"[A": "ARRIBA", "[B": "ABAJO", "[C": "DER", "[D": "IZQ"}.get(sec, "ESC")
            return "ESC"
        return ch

    def atender(self, k):
        ens = self.estado.get("ensenando")
        if ens:
            mov = {"ARRIBA": (0, -1), "ABAJO": (0, 1), "IZQ": (-1, 0), "DER": (1, 0)}
            if k in mov:
                return self.mandar({"cmd": "ensenar", "accion": "mover", "dx": mov[k][0], "dy": mov[k][1]})
            if k in ("+", "="):
                return self.mandar({"cmd": "ensenar", "accion": "tam", "dw": 1, "dh": 1})
            if k in ("-", "_"):
                return self.mandar({"cmd": "ensenar", "accion": "tam", "dw": -1, "dh": -1})
            if k == "*":
                return self.mandar({"cmd": "ensenar", "accion": "tam", "dw": 1, "dh": 0})
            if k == "/":
                return self.mandar({"cmd": "ensenar", "accion": "tam", "dw": -1, "dh": 0})
            if k in ("\n", "\r"):
                return self.mandar({"cmd": "ensenar", "accion": "guardar"})
            if k == "x":
                return self.mandar({"cmd": "ensenar", "accion": "auto"})
            if k == "ESC":
                return self.mandar({"cmd": "ensenar", "accion": "cancelar"})
        if k == "q":
            self.vivo = False
        elif k == "Q":
            self.mandar({"cmd": "apagar"})
            time.sleep(0.3)
            self.vivo = False
        elif k and k.isdigit():
            self.mandar({"cmd": "modelo", "id": k})
        elif k == "a":
            self.mandar({"cmd": "autoajuste"})
        elif k == "c":
            self.mandar({"cmd": "calibrar", "metodo": "aruco"})
        elif k == "C":
            m = self.preguntar("Método [aruco|puntos|esquinas|graycode]: ") or "aruco"
            self.mandar({"cmd": "calibrar", "metodo": m})
        elif k == "v":
            self.mandar({"cmd": "verificar"})
        elif k == "m":
            self.mandar({"cmd": "mm"})
        elif k in "pwhbo" and k:
            self.mandar({"cmd": {"p": "proyector", "w": "web", "h": "manos", "b": "buscar", "o": "marcas"}[k]})
        elif k == "i":
            self.vista = not self.vista
            self.vista_img = None
        elif k == "f":
            self.mandar({"cmd": "fondo"})
        elif k == "e":
            nombre = self.preguntar("¿Qué pieza le vas a enseñar? (ej. tijera mayo): ")
            if nombre:
                self.mandar({"cmd": "ensenar", "accion": "inicio", "clase": nombre})
        elif k == "t":
            self.mandar({"cmd": "confirmar"})
        elif k == "s":
            self.mandar({"cmd": "foto"})
        elif k in ("[", "]"):
            self.mandar({"cmd": "param", "k": "umbral", "delta": -0.05 if k == "[" else 0.05})
        elif k in ("(", ")"):
            self.mandar({"cmd": "param", "k": "nms", "delta": -0.05 if k == "(" else 0.05})
        elif k in ("{", "}"):
            self.mandar({"cmd": "param", "k": "entrada", "delta": -1 if k == "{" else 1})
        elif k in ("g", "G"):
            self.mandar({"cmd": "filtro", "k": "gamma", "delta": -0.1 if k == "g" else 0.1})
        elif k in ("l", "L"):
            self.mandar({"cmd": "filtro", "k": "clahe", "delta": -0.5 if k == "l" else 0.5})
        elif k in ("k", "K"):
            self.mandar({"cmd": "filtro", "k": "suavizado", "delta": -1 if k == "k" else 1})
        elif k in ("n", "N"):
            self.mandar({"cmd": "filtro", "k": "nitidez", "delta": -0.25 if k == "n" else 0.25})
        elif k == "B":
            s = self.preguntar("Segundos por modelo [20]: ") or "20"
            ids = self.preguntar("Modelos (teclas separadas por espacio, Enter = todos): ")
            self.tabla = ""
            self.mandar({"cmd": "bench", "modelos": ids.split(), "seg": float(s)})
        elif k == "P":
            p = self.preguntar("Perfil de energía [max|normal|5w]: ")
            if p:
                self.mandar({"cmd": "perfil", "nombre": p})

    # ---------------------------------------------------------------- dibujo
    def pedir(self):
        while self.vivo:
            try:
                self.estado = enviar({"cmd": "estado"}, timeout=3).get("estado", {})
                if self.vista:
                    cols, filas = shutil.get_terminal_size((100, 40))
                    w = min(cols - 2, 110)
                    h = max(6, min(filas - 22, int(w * 9 / 16 / 2)))
                    v = enviar({"cmd": "vista", "w": w, "h": h}, timeout=3).get("vista")
                    if v:
                        a = np.frombuffer(base64.b64decode(v["bgr"]), np.uint8).reshape(v["h"], v["w"], 3)
                        self.vista_img = a
            except Exception as ex:
                self.estado = {"_error": str(ex)}
            time.sleep(0.35 if self.vista else 0.8)

    def _vista_txt(self):
        a = self.vista_img
        if a is None:
            return [GRIS + "  (esperando vista...)" + RESET]
        out = []
        for y in range(0, a.shape[0] - 1, 2):
            fila = []
            for x in range(a.shape[1]):
                b1, g1, r1 = a[y, x]
                b2, g2, r2 = a[y + 1, x]
                if self.truecolor:
                    fila.append("%s38;2;%d;%d;%dm%s48;2;%d;%d;%dm▀" % (E, r1, g1, b1, E, r2, g2, b2))
                else:
                    fila.append("%s38;5;%dm%s48;5;%dm▀" % (E, _c256(r1, g1, b1), E, _c256(r2, g2, b2)))
            out.append(" " + "".join(fila) + RESET)
        return out

    def dibujar(self):
        e = self.estado
        cols, _ = shutil.get_terminal_size((100, 40))
        L = []
        if "_error" in e:
            L.append(ROJO + "No hay conexión con el núcleo: " + e["_error"] + RESET)
            L.append("Arráncalo con:  austero start")
        else:
            s = e.get("stats", {})
            L.append(NEGRITA + CIAN + " MODO AUSTERO " + RESET + GRIS + "─" * 3 + RESET +
                     " modelo %s%s%s %s(%s)%s   %s%.1f fps%s  %.0f ms %s(p95 %.0f)%s  cám %.0f fps %s" % (
                         NEGRITA, e.get("modelo") or "ninguno", RESET, GRIS, e.get("motor") or "-", RESET,
                         VERDE, e.get("fps", 0), RESET, e.get("lat_ms", 0), GRIS, e.get("lat_p95", 0), RESET,
                         e.get("fps_camara", 0), (AMAR + "⏳ " + e["ocupado"] + RESET) if e.get("ocupado") else ""))
            cpus = s.get("cpu") or []
            L.append(" CPU %s %3d%%  %s   GPU %s %s%%   %s" % (
                barra(s.get("cpu_prom")), int(s.get("cpu_prom", 0)),
                " ".join(barra(c, 4) for c in cpus), barra(s.get("gpu")),
                s.get("gpu") if s.get("gpu") is not None else "-",
                ("%s%.1f W%s" % (MAG, s["potencia_mw"] / 1000.0, RESET)) if s.get("potencia_mw") else ""))
            rt = float(s.get("ram_total_mb") or 1)
            L.append(" RAM %s %d/%d MB  swap %d MB   proceso %.0f%% CPU  %.0f MB   %s" % (
                barra(100.0 * s.get("ram_mb", 0) / rt), s.get("ram_mb", 0), rt, s.get("swap_mb", 0),
                s.get("proc_cpu", 0), s.get("proc_ram_mb", 0), temp_txt(s.get("temp"))))
            c = e.get("calib", {})
            L.append(" proyector %s  calibración %s  manos %s  web %s  buscar %s  fondo %s" % (
                _on(e.get("proyector")),
                (VERDE + "%s %.1f px" % (c.get("metodo"), c.get("error_px") or 0) + RESET +
                 (" %.2f px/mm" % c["px_por_mm"] if c.get("px_por_mm") else "")) if c.get("lista") else ROJO + "NO" + RESET,
                _on(e.get("manos")), (VERDE + e["web"] + RESET) if e.get("web") else _on(False),
                _on(e.get("buscar")), _on(e.get("fondo"))))
            p = e.get("params") or {}
            f = e.get("filtros") or {}
            L.append(" " + GRIS + "params " + RESET + "  ".join("%s=%s" % kv for kv in sorted(p.items())) +
                     GRIS + "   filtros " + RESET + "  ".join("%s=%s" % kv for kv in sorted(f.items())))
            cat = e.get("catalogo", [])
            L.append(" " + GRIS + "modelos " + RESET + " ".join(
                (NEGRITA + VERDE if x["id"] == e.get("modelo") else GRIS) + "%s:%s" % (x["tecla"], x["id"]) + RESET
                for x in cat))
            mem = e.get("memoria") or {}
            if mem:
                L.append(" " + GRIS + "memoria " + RESET + ", ".join("%s (%d)" % kv for kv in sorted(mem.items())))
            dets = e.get("dets") or []
            if dets:
                L.append(" " + GRIS + "ve: " + RESET + "  ".join(
                    "%s %s%%%s" % (d["clase"], int(d["conf"] * 100),
                                   (" %s°" % d["angulo"]) if d.get("angulo") is not None else "") for d in dets[:6]))
            if e.get("modelo_error"):
                L.append(" " + ROJO + e["modelo_error"] + RESET)
            if self.vista:
                L.extend(self._vista_txt())
            if self.tabla:
                L.extend(" " + l for l in self.tabla.splitlines())
            L.append(GRIS + "─" * min(cols, 110) + RESET)
            for l in (e.get("log") or [])[-4:]:
                L.append(" " + TENUE + l[:cols - 2] + RESET)
            if self.mensaje:
                L.append(" " + AMAR + ("⏳ " if self.ocupado else "» ") + self.mensaje[:cols - 4] + RESET)
            if e.get("ensenando"):
                L.append(" " + NEGRITA + AMAR + AYUDA_ENS + RESET)
            for a in AYUDA:
                L.append(" " + GRIS + a[:cols - 2] + RESET)
        sys.stdout.write(E + "H" + "".join(l + E + "K\n" for l in L) + E + "J")
        sys.stdout.flush()

    def correr(self):
        tty.setcbreak(self._fd)
        sys.stdout.write(E + "?25l" + E + "2J")
        threading.Thread(target=self.pedir, daemon=True).start()
        try:
            while self.vivo:
                k = self.tecla()
                if k:
                    self.atender(k)
                self.dibujar()
        finally:
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._viejo)
            sys.stdout.write(RESET + E + "?25h\n")


def _on(v):
    return (VERDE + "on" + RESET) if v else (GRIS + "off" + RESET)


def _c256(r, g, b):
    r, g, b = int(r), int(g), int(b)
    if abs(r - g) < 10 and abs(g - b) < 10:
        return 232 + min(23, r * 24 // 256)
    return 16 + 36 * (r * 6 // 256) + 6 * (g * 6 // 256) + (b * 6 // 256)


if __name__ == "__main__":
    Tablero().correr()
