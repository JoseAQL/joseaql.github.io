# -*- coding: utf-8 -*-
"""
modelos.py - Banco de modelos. Solo UNO cargado a la vez (la Nano tiene 4 GB compartidos CPU/GPU).

Todos devuelven la misma cosa:  [{"clase", "conf", "caja": [x1,y1,x2,y2], ...extra}]
en pixeles de la imagen de proceso (config camara.ancho_proceso).

Tecla  id               que es
  1    fondo            resta de fondo con OpenCV (sin red neuronal; casi no gasta)
  2    ssd_general      detectNet SSD-MobileNet-v2 COCO (jetson-inference, MIT)
  3    ssd_propio       detectNet con TU ONNX re-entrenado (modelos/ssd_instrumental/)
  4    yolo_mit4        YOLO11-L de 4 instrumentos (amirrezamortazavifard, MIT)
  5    yolo_doccheck12  YOLOv5-L de 12 instrumentos (DocCheck Rona, CC BY-NC 4.0)
  6    orientacion      angulo 0-357 de cada pieza (DocCheck Rona, CC BY-NC 4.0)
  7    ejemplos         "Terminator": busca lo que le ensenaste (memoria/)
  8    fondo_ia         backgroundNet U2-Net (jetson-inference)
  9    yolo_alumno      tu YOLO nano entrenado en Colab con tus ejemplos (colab/)
Aparte (tecla h): manos con poseNet resnet18-hand.

YOLO corre con TensorRT (.engine) si hay tensorrt+pycuda; si no, con onnxruntime; si no, con OpenCV DNN (CPU).
"""
from __future__ import print_function

import gc
import os
import time

import cv2
import numpy as np

from util import DIR_MODELOS, log

try:
    import jetson_inference as ji
    import jetson_utils as ju
except Exception:
    try:
        import jetson.inference as ji
        import jetson.utils as ju
    except Exception:
        ji = ju = None


def _cuda(img_bgr):
    rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    return ju.cudaFromNumpy(rgb)


def _nms(cajas, confs, iou):
    if not cajas:
        return []
    b = [[float(x1), float(y1), float(x2 - x1), float(y2 - y1)] for x1, y1, x2, y2 in cajas]
    idx = cv2.dnn.NMSBoxes(b, [float(c) for c in confs], 0.0, float(iou))
    return [int(i) for i in np.array(idx).reshape(-1)]


# ====================================================================== base
class Modelo(object):
    id = "base"
    nombre = "base"
    licencia = ""
    necesita = ""          # que hay que instalar
    params_def = {"umbral": 0.4, "nms": 0.45}

    def __init__(self, ctx):
        self.ctx = ctx      # acceso a fondo, memoria, calibracion
        self.p = dict(self.params_def)
        self.ok = False
        self.error = ""
        self.motor = ""

    def disponible(self):
        return True, ""

    def cargar(self):
        self.ok = True
        return True

    def liberar(self):
        self.ok = False

    def procesar(self, img):
        return []

    def poner(self, k, v):
        if k not in self.p:
            return False
        tipo = type(self.params_def[k])
        self.p[k] = tipo(v)
        return True


# ====================================================================== 1 fondo (OpenCV)
def segmentar_fondo(img, fondo, umbral=30, area_min=400, mascara_ignorar=None):
    """Regiones distintas al fondo. Devuelve [(contorno, caja)]."""
    if fondo is None or fondo.shape != img.shape:
        return []
    a = cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    b = cv2.GaussianBlur(cv2.cvtColor(fondo, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    dif = cv2.absdiff(a, b)
    # el color tambien cuenta (pieza gris sobre mesa de color)
    dc = cv2.absdiff(cv2.GaussianBlur(img, (5, 5), 0), cv2.GaussianBlur(fondo, (5, 5), 0)).max(2)
    dif = cv2.max(dif, dc)
    _, m = cv2.threshold(dif, umbral, 255, cv2.THRESH_BINARY)
    if mascara_ignorar is not None:
        m[mascara_ignorar > 0] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    r = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = r[0] if len(r) == 2 else r[1]
    res = []
    for c in cnts:
        if cv2.contourArea(c) < area_min:
            continue
        x, y, w, h = cv2.boundingRect(c)
        res.append((c, [x, y, x + w, y + h]))
    return res


class Fondo(Modelo):
    id, nombre = "fondo", "Resta de fondo (OpenCV)"
    licencia = "propio"
    params_def = {"umbral": 30.0, "area_min": 400.0, "nms": 0.45}

    def procesar(self, img):
        res = []
        for c, caja in segmentar_fondo(img, self.ctx.fondo, self.p["umbral"], self.p["area_min"],
                                       self.ctx.mascara_proy):
            (cx, cy), (w, h), ang = cv2.minAreaRect(c)
            if w < h:
                ang += 90
            res.append({"clase": "objeto", "conf": 1.0, "caja": caja, "contorno": c,
                        "angulo": round(ang % 180, 1)})
        return res


# ====================================================================== 2/3 detectNet SSD
class SSD(Modelo):
    id, nombre = "ssd_general", "detectNet SSD-MobileNet-v2 (COCO)"
    licencia = "MIT (jetson-inference)"
    necesita = "jetson-inference"
    red = "ssd-mobilenet-v2"
    onnx = None

    def disponible(self):
        if ji is None:
            return False, "falta jetson-inference"
        if self.onnx and not os.path.exists(self.onnx):
            return False, "falta %s (entrena con colab/ o GUIA)" % os.path.relpath(self.onnx, DIR_MODELOS)
        return True, ""

    def cargar(self):
        ok, msg = self.disponible()
        if not ok:
            self.error = msg
            return False
        try:
            if self.onnx:
                d = os.path.dirname(self.onnx)
                self.net = ji.detectNet(argv=["--model=" + self.onnx, "--labels=" + os.path.join(d, "labels.txt"),
                                              "--input-blob=input_0", "--output-cvg=scores", "--output-bbox=boxes",
                                              "--threshold=%.2f" % self.p["umbral"]])
            else:
                self.net = ji.detectNet(self.red, threshold=self.p["umbral"])
            self.motor = "TensorRT (detectNet)"
            self.ok = True
        except Exception as e:
            self.error = str(e)
        return self.ok

    def poner(self, k, v):
        r = Modelo.poner(self, k, v)
        if r and k == "umbral" and self.ok:
            try:
                self.net.SetConfidenceThreshold(float(v))
            except Exception:
                pass
        return r

    def liberar(self):
        self.net = None
        self.ok = False
        gc.collect()

    def procesar(self, img):
        dets = self.net.Detect(_cuda(img), overlay="none")
        return [{"clase": self.net.GetClassDesc(d.ClassID), "conf": float(d.Confidence),
                 "caja": [int(d.Left), int(d.Top), int(d.Right), int(d.Bottom)]} for d in dets]


class SSDPropio(SSD):
    id, nombre = "ssd_propio", "detectNet SSD-MobileNet re-entrenado (tuyo)"
    licencia = "tuyo"
    onnx = os.path.join(DIR_MODELOS, "ssd_instrumental", "ssd-mobilenet.onnx")


# ====================================================================== motores para ONNX / TensorRT
class MotorTRT(object):
    """TensorRT 8.x + pycuda. Comparte el contexto primario de CUDA con jetson-inference."""

    def __init__(self, engine):
        import tensorrt as trt
        import pycuda.driver as cuda
        cuda.init()
        self.cuda = cuda
        self.cctx = cuda.Device(0).retain_primary_context()
        self.cctx.push()
        try:
            lg = trt.Logger(trt.Logger.WARNING)
            with open(engine, "rb") as f:
                self.engine = trt.Runtime(lg).deserialize_cuda_engine(f.read())
            self.context = self.engine.create_execution_context()
            self.ent, self.sal, self.bind = None, [], []
            for i in range(self.engine.num_bindings):
                shp = tuple(self.engine.get_binding_shape(i))
                dt = trt.nptype(self.engine.get_binding_dtype(i))
                host = cuda.pagelocked_empty(int(np.prod(shp)), dt)
                dev = cuda.mem_alloc(host.nbytes)
                self.bind.append(int(dev))
                if self.engine.binding_is_input(i):
                    self.ent = (host, dev, shp)
                else:
                    self.sal.append((host, dev, shp))
        finally:
            self.cctx.pop()
        self.forma_entrada = self.ent[2]

    def __call__(self, x):
        self.cctx.push()
        try:
            h, d, _ = self.ent
            np.copyto(h, x.ravel().astype(h.dtype))
            self.cuda.memcpy_htod(d, h)
            self.context.execute_v2(self.bind)
            outs = []
            for h2, d2, shp in self.sal:
                self.cuda.memcpy_dtoh(h2, d2)
                outs.append(h2.reshape(shp).astype(np.float32))
            return outs
        finally:
            self.cctx.pop()

    def cerrar(self):
        self.cctx.push()
        try:
            for _, d, _ in [self.ent] + self.sal:
                d.free()
            del self.context, self.engine
        finally:
            self.cctx.pop()
            self.cctx.detach()


class MotorORT(object):
    def __init__(self, onnx):
        import onnxruntime as ort
        prov = [p for p in ("TensorrtExecutionProvider", "CUDAExecutionProvider", "CPUExecutionProvider")
                if p in ort.get_available_providers()]
        prov = [p for p in prov if p != "TensorrtExecutionProvider"] or prov
        self.s = ort.InferenceSession(onnx, providers=prov)
        self.nombre = self.s.get_inputs()[0].name
        self.forma_entrada = tuple(self.s.get_inputs()[0].shape)
        self.prov = self.s.get_providers()[0]

    def __call__(self, x):
        return [o.astype(np.float32) for o in self.s.run(None, {self.nombre: x})]

    def cerrar(self):
        del self.s


class MotorCV(object):
    def __init__(self, onnx, forma):
        self.net = cv2.dnn.readNetFromONNX(onnx)
        self.forma_entrada = forma

    def __call__(self, x):
        self.net.setInput(x)
        names = self.net.getUnconnectedOutLayersNames()
        return [o.astype(np.float32) for o in self.net.forward(names)]

    def cerrar(self):
        del self.net


def abrir_motor(base, forma_def):
    """base = ruta sin extension. Prueba .engine (TensorRT) -> .onnx con onnxruntime -> .onnx con OpenCV."""
    errores = []
    if os.path.exists(base + ".engine"):
        try:
            return MotorTRT(base + ".engine"), "TensorRT"
        except Exception as e:
            errores.append("TRT: %s" % e)
    if os.path.exists(base + ".onnx"):
        try:
            m = MotorORT(base + ".onnx")
            return m, "onnxruntime " + m.prov
        except Exception as e:
            errores.append("ORT: %s" % e)
        try:
            return MotorCV(base + ".onnx", forma_def), "OpenCV DNN (CPU)"
        except Exception as e:
            errores.append("CV: %s" % e)
    raise RuntimeError("; ".join(errores) or "no existe %s.engine ni %s.onnx" % (base, base))


# ====================================================================== 4/5/9 YOLO
def letterbox(img, lado):
    h, w = img.shape[:2]
    r = min(lado / float(w), lado / float(h))
    nw, nh = int(round(w * r)), int(round(h * r))
    lienzo = np.full((lado, lado, 3), 114, np.uint8)
    dx, dy = (lado - nw) // 2, (lado - nh) // 2
    lienzo[dy:dy + nh, dx:dx + nw] = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    return lienzo, r, dx, dy


class Yolo(Modelo):
    id, nombre = "yolo_mit4", "YOLO11-L 4 instrumentos (MIT)"
    licencia = "MIT"
    carpeta = "yolo_mit4"
    formato = "v8"              # v8/v11: [1, 4+nc, N]   v5: [1, N, 5+nc]
    clases = ["Bisturi", "Pinza diseccion recta", "Tijera Mayo recta", "Tijera Mayo curva"]
    params_def = {"umbral": 0.35, "nms": 0.45, "entrada": 416}

    def _base(self):
        return os.path.join(DIR_MODELOS, self.carpeta, "modelo_%d" % int(self.p["entrada"]))

    def tamanos(self):
        d = os.path.join(DIR_MODELOS, self.carpeta)
        res = []
        if os.path.isdir(d):
            for f in os.listdir(d):
                if f.startswith("modelo_") and (f.endswith(".onnx") or f.endswith(".engine")):
                    try:
                        res.append(int(f.split("_")[1].split(".")[0]))
                    except Exception:
                        pass
        return sorted(set(res))

    def disponible(self):
        t = self.tamanos()
        if not t:
            return False, "faltan modelos/%s/modelo_*.onnx (corre modelos/descargar.sh)" % self.carpeta
        return True, ""

    def cargar(self):
        t = self.tamanos()
        if not t:
            self.error = self.disponible()[1]
            return False
        if int(self.p["entrada"]) not in t:
            self.p["entrada"] = min(t, key=lambda v: abs(v - int(self.p["entrada"])))
        lado = int(self.p["entrada"])
        names = os.path.join(DIR_MODELOS, self.carpeta, "clases.txt")
        if os.path.exists(names):
            self.clases = [l.strip() for l in open(names) if l.strip()]
        try:
            self.m, self.motor = abrir_motor(self._base(), (1, 3, lado, lado))
            self.ok = True
        except Exception as e:
            self.error = str(e)
        return self.ok

    def liberar(self):
        try:
            self.m.cerrar()
        except Exception:
            pass
        self.m = None
        self.ok = False
        gc.collect()

    def poner(self, k, v):
        r = Modelo.poner(self, k, v)
        if r and k == "entrada" and self.ok:      # otro tamano = otro archivo: recargar
            self.liberar()
            self.cargar()
        return r

    def procesar(self, img):
        lado = int(self.p["entrada"])
        lb, r, dx, dy = letterbox(img, lado)
        x = cv2.cvtColor(lb, cv2.COLOR_BGR2RGB).transpose(2, 0, 1)[None].astype(np.float32) / 255.0
        out = self.m(np.ascontiguousarray(x))[0]
        out = out[0]
        if self.formato == "v5":
            conf_obj = out[:, 4]
            cls_sc = out[:, 5:] * conf_obj[:, None]
            cajas = out[:, :4]
        else:
            if out.shape[0] < out.shape[1]:
                out = out.T
            cajas = out[:, :4]
            cls_sc = out[:, 4:]
        cid = cls_sc.argmax(1)
        conf = cls_sc[np.arange(len(cid)), cid]
        sel = conf >= self.p["umbral"]
        cajas, cid, conf = cajas[sel], cid[sel], conf[sel]
        xyxy = []
        for cx, cy, w, h in cajas:
            x1 = (cx - w / 2 - dx) / r
            y1 = (cy - h / 2 - dy) / r
            x2 = (cx + w / 2 - dx) / r
            y2 = (cy + h / 2 - dy) / r
            xyxy.append([int(x1), int(y1), int(x2), int(y2)])
        keep = _nms(xyxy, conf, self.p["nms"])
        res = []
        for i in keep:
            c = int(cid[i])
            res.append({"clase": self.clases[c] if c < len(self.clases) else str(c),
                        "conf": float(conf[i]), "caja": xyxy[i]})
        return res


class YoloDocCheck(Yolo):
    id, nombre = "yolo_doccheck12", "YOLOv5-L 12 instrumentos (DocCheck Rona)"
    licencia = "CC BY-NC 4.0 (sin uso comercial)"
    carpeta = "yolo_doccheck12"
    formato = "v5"
    clases = ["Pinza anatomica estandar", "Pinza anatomica delgada", "Pinza quirurgica", "Pinza de astillas",
              "Mango bisturi n3", "Mango bisturi n4", "Hoja bisturi abombada", "Hoja bisturi delgada",
              "Tijera quirurgica punta/punta", "Tijera quirurgica punta/roma", "Tijera de diseccion",
              "Aguja de diseccion"]


class YoloAlumno(Yolo):
    id, nombre = "yolo_alumno", "YOLO nano alumno (entrenado con tus ejemplos)"
    licencia = "tuyo (Ultralytics AGPL al entrenar)"
    carpeta = "yolo_alumno"
    clases = []
    params_def = {"umbral": 0.35, "nms": 0.45, "entrada": 320}


# ====================================================================== 6 orientacion
class Orientacion(Modelo):
    """AlexNet de DocCheck: recorte cuadrado (diagonal de la caja) -> 128x128 gris -> 358 angulos.
    Las piezas las saca de la resta de fondo (o de la memoria), asi no necesita otro detector."""
    id, nombre = "orientacion", "Orientacion 0-357 grados (DocCheck Rona)"
    licencia = "CC BY-NC 4.0 (sin uso comercial)"
    params_def = {"umbral": 30.0, "area_min": 400.0, "nms": 0.45}

    def disponible(self):
        b = os.path.join(DIR_MODELOS, "orientacion", "modelo")
        if os.path.exists(b + ".onnx") or os.path.exists(b + ".engine"):
            return True, ""
        return False, "falta modelos/orientacion/modelo.onnx (corre modelos/descargar.sh)"

    def cargar(self):
        try:
            self.m, self.motor = abrir_motor(os.path.join(DIR_MODELOS, "orientacion", "modelo"), (1, 1, 128, 128))
            self.ok = True
        except Exception as e:
            self.error = str(e)
        return self.ok

    def liberar(self):
        try:
            self.m.cerrar()
        except Exception:
            pass
        self.ok = False
        gc.collect()

    def procesar(self, img):
        gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        res = []
        for c, (x1, y1, x2, y2) in segmentar_fondo(img, self.ctx.fondo, self.p["umbral"], self.p["area_min"],
                                                   self.ctx.mascara_proy)[:6]:
            cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
            lado = int(np.hypot(x2 - x1, y2 - y1) * 1.05) + 4
            M = np.float32([[1, 0, lado / 2.0 - cx], [0, 1, lado / 2.0 - cy]])
            rec = cv2.warpAffine(gris, M, (lado, lado), borderValue=int(np.median(gris)))
            rec = cv2.resize(rec, (144, 144))[8:136, 8:136]
            x = (rec.astype(np.float32) / 255.0)[None, None]
            log_ = self.m(np.ascontiguousarray(x))[0].ravel()
            ang = int(np.argmax(log_))
            p = np.exp(log_ - log_.max())
            p /= p.sum()
            res.append({"clase": "%d grados" % ang, "conf": float(p.max()), "caja": [x1, y1, x2, y2],
                        "angulo": ang, "contorno": c})
        return res


# ====================================================================== 7 ejemplos (Terminator)
class Ejemplos(Modelo):
    id, nombre = "ejemplos", "Ejemplos ensenados (Terminator)"
    licencia = "propio"
    params_def = {"umbral": 0.55, "dif": 30.0, "area_min": 400.0, "nms": 0.45}

    def disponible(self):
        if not self.ctx.memoria.clases():
            return False, "aun no le ensenas nada (tecla e)"
        return True, ""

    def procesar(self, img):
        return self.ctx.memoria.buscar(img, self.ctx.fondo, self.ctx.mascara_proy, umbral=self.p["umbral"],
                                       dif=self.p["dif"], area_min=self.p["area_min"])


# ====================================================================== 8 backgroundNet
class FondoIA(Modelo):
    id, nombre = "fondo_ia", "backgroundNet U2-Net (jetson-inference)"
    licencia = "MIT (jetson-inference)"
    params_def = {"umbral": 0.5, "area_min": 400.0, "nms": 0.45}

    def disponible(self):
        if ji is None or not hasattr(ji, "backgroundNet"):
            return False, "falta jetson-inference con backgroundNet (version 2023+)"
        return True, ""

    def cargar(self):
        ok, m = self.disponible()
        if not ok:
            self.error = m
            return False
        try:
            self.net = ji.backgroundNet("u2net")
            self.motor = "TensorRT (backgroundNet)"
            self.ok = True
        except Exception as e:
            self.error = str(e)
        return self.ok

    def liberar(self):
        self.net = None
        self.ok = False
        gc.collect()

    def procesar(self, img):
        rgba = ju.cudaFromNumpy(cv2.cvtColor(img, cv2.COLOR_BGR2RGBA))
        self.net.Process(rgba, filter="linear")
        ju.cudaDeviceSynchronize()
        a = ju.cudaToNumpy(rgba)[:, :, 3]
        m = (a > int(255 * self.p["umbral"])).astype(np.uint8) * 255
        r = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = r[0] if len(r) == 2 else r[1]
        res = []
        for c in cnts:
            if cv2.contourArea(c) >= self.p["area_min"]:
                x, y, w, h = cv2.boundingRect(c)
                res.append({"clase": "objeto", "conf": 1.0, "caja": [x, y, x + w, y + h], "contorno": c})
        return res


# ====================================================================== manos (aparte)
class Manos(object):
    nombre = "poseNet resnet18-hand"

    def __init__(self):
        self.ok = False
        self.error = ""
        self.motor = ""
        self.umbral = 0.15

    def cargar(self):
        if ji is not None:
            try:
                self.net = ji.poseNet("resnet18-hand", threshold=self.umbral)
                self.motor = "poseNet"
                self.ok = True
                return True
            except Exception as e:
                self.error = str(e)
        try:
            import mediapipe as mp
            self.mp = mp.solutions.hands.Hands(max_num_hands=2, model_complexity=0)
            self.motor = "MediaPipe (CPU)"
            self.ok = True
        except Exception as e:
            self.error = (self.error + "; " if self.error else "") + "sin poseNet ni mediapipe: %s" % e
        return self.ok

    def liberar(self):
        self.net = self.mp = None
        self.ok = False
        gc.collect()

    def procesar(self, img):
        """[{"puntos": [(x,y) o None]*21, "lado": "?"}]"""
        h, w = img.shape[:2]
        res = []
        if self.motor == "poseNet":
            for p in self.net.Process(_cuda(img), overlay="none"):
                pts = [None] * 21
                for k in p.Keypoints:
                    if 0 <= k.ID < 21:
                        pts[k.ID] = (int(k.x), int(k.y))
                res.append({"puntos": pts})
        else:
            r = self.mp.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            for lm in (r.multi_hand_landmarks or []):
                res.append({"puntos": [(int(q.x * w), int(q.y * h)) for q in lm.landmark]})
        return res


CATALOGO = [Fondo, SSD, SSDPropio, Yolo, YoloDocCheck, Orientacion, Ejemplos, FondoIA, YoloAlumno]
POR_TECLA = {str(i + 1): c.id for i, c in enumerate(CATALOGO)}


def clase_por_id(id_):
    for c in CATALOGO:
        if c.id == id_:
            return c
    return None
