# -*- coding: utf-8 -*-
"""
bench.py - Benchmark tipo overclock de todos los modelos, uno por uno, con los MISMOS cuadros.

Por cada modelo mide:
  carga (s), FPS, latencia p50/p95 (ms), CPU % (prom. nucleos y del proceso), GPU %, RAM del sistema y
  del proceso (MB), temperatura maxima, consumo (mW, de tegrastats), detecciones por cuadro y
  "aciertos": de las fotos que guardaste al ENSENAR (dataset/), cuantas piezas encontro (IoU >= 0.3,
  sin importar el nombre de la clase, porque cada modelo tiene sus propios nombres).
Resultados: bench/bench_FECHA.md y .csv
"""
from __future__ import print_function

import csv
import glob
import os
import time

import cv2
import numpy as np

import modelos as M
from util import DIR_BENCH, DIR_DATASET, log


def _iou(a, b):
    x1, y1 = max(a[0], b[0]), max(a[1], b[1])
    x2, y2 = min(a[2], b[2]), min(a[3], b[3])
    i = max(0, x2 - x1) * max(0, y2 - y1)
    u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - i
    return i / float(u) if u > 0 else 0.0


def _verdad(nucleo, maximo=30):
    """Fotos ensenadas con su etiqueta YOLO, redimensionadas a la imagen de proceso."""
    res = []
    for f in sorted(glob.glob(os.path.join(DIR_DATASET, "images", "*.jpg")))[-maximo:]:
        lab = f.replace(os.sep + "images" + os.sep, os.sep + "labels" + os.sep)[:-4] + ".txt"
        if not os.path.exists(lab):
            continue
        img = cv2.imread(f)
        if img is None:
            continue
        img = cv2.resize(img, (nucleo.ancho_proc, nucleo.alto_proc))
        W, H = nucleo.ancho_proc, nucleo.alto_proc
        cajas = []
        for l in open(lab):
            p = l.split()
            if len(p) == 5:
                cx, cy, w, h = [float(v) for v in p[1:]]
                cajas.append([(cx - w / 2) * W, (cy - h / 2) * H, (cx + w / 2) * W, (cy + h / 2) * H])
        res.append((img, cajas))
    return res


def _clip(nucleo, n):
    cuadros = []
    _, k = nucleo.cam.leer()
    for _ in range(n):
        img, k = nucleo.cam.esperar_nuevo(k, 1.0)
        if img is None:
            break
        p = cv2.resize(img, (nucleo.ancho_proc, nucleo.alto_proc), interpolation=cv2.INTER_AREA)
        cuadros.append(nucleo.filtros.aplicar(p))
    return cuadros


def correr(nucleo, ids, segundos):
    cfg = nucleo.cfg.get("bench", {})
    if not ids or ids == ["todos"]:
        ids = [c.id for c in M.CATALOGO]
    ids = [M.POR_TECLA.get(str(i), str(i)) for i in ids]
    previo = nucleo.modelo.id if nucleo.modelo else None
    if nucleo.modelo:
        nucleo.modelo.liberar()
        nucleo.modelo = None
    clip = _clip(nucleo, int(cfg.get("frames_clip", 60)))
    if not clip:
        return {"ok": False, "msg": "bench: sin camara"}
    verdad = _verdad(nucleo)
    if nucleo.fondo is None and any(i in ("fondo", "orientacion", "ejemplos") for i in ids):
        nucleo.cmd_fondo({})
    log("bench: %d modelos x %.0f s, clip de %d cuadros, %d fotos con etiqueta"
        % (len(ids), segundos, len(clip), len(verdad)))
    filas = []
    for id_ in ids:
        C = M.clase_por_id(id_)
        if C is None:
            continue
        m = C(nucleo)
        ok, por_que = m.disponible()
        fila = {"modelo": id_, "nombre": C.nombre, "licencia": C.licencia}
        if not ok:
            fila["nota"] = "no disponible: " + por_que
            filas.append(fila)
            log("bench %s: %s" % (id_, fila["nota"]))
            continue
        ram0 = nucleo.stats.foto().get("ram_mb", 0)
        t = time.time()
        if not m.cargar():
            fila["nota"] = "no cargo: " + m.error
            filas.append(fila)
            continue
        fila["carga_s"] = round(time.time() - t, 1)
        fila["motor"] = m.motor
        nucleo.ocupado = "bench %s" % id_
        log("bench %s: cargado en %.1f s (%s)" % (id_, fila["carga_s"], m.motor))
        for i in range(int(cfg.get("calentamiento", 10))):
            m.procesar(clip[i % len(clip)])
        lat, ndet, muestras = [], [], []
        t0 = time.time()
        t_m = t0
        i = 0
        while time.time() - t0 < segundos:
            a = time.time()
            d = m.procesar(clip[i % len(clip)])
            lat.append((time.time() - a) * 1000)
            ndet.append(len(d))
            i += 1
            if time.time() - t_m >= 1.0:
                muestras.append(nucleo.stats.foto())
                t_m = time.time()
                nucleo.proy.actualizar()
        dur = time.time() - t0
        fila["fps"] = round(i / dur, 1)
        fila["lat_p50"] = round(float(np.percentile(lat, 50)), 1)
        fila["lat_p95"] = round(float(np.percentile(lat, 95)), 1)
        fila["det_por_cuadro"] = round(float(np.mean(ndet)), 2)

        def prom(k):
            v = [s.get(k) for s in muestras if s.get(k) is not None]
            return round(float(np.mean(v)), 1) if v else None
        fila["cpu_%"] = prom("cpu_prom")
        fila["cpu_proc_%"] = prom("proc_cpu")
        fila["gpu_%"] = prom("gpu")
        fila["ram_mb"] = prom("ram_mb")
        fila["ram_extra_mb"] = round(fila["ram_mb"] - ram0, 0) if fila["ram_mb"] else None
        fila["ram_proc_mb"] = prom("proc_ram_mb")
        tm = [max([v for k, v in s.get("temp", {}).items()] or [0]) for s in muestras]
        fila["temp_max"] = round(max(tm), 1) if tm else None
        fila["potencia_mw"] = prom("potencia_mw")
        if verdad:
            total, hallados = 0, 0
            for img, cajas in verdad:
                d = m.procesar(img)
                for c in cajas:
                    total += 1
                    if any(_iou(c, x["caja"]) >= 0.3 for x in d):
                        hallados += 1
            fila["aciertos"] = "%d/%d" % (hallados, total)
            fila["aciertos_%"] = round(100.0 * hallados / max(1, total), 1)
        m.liberar()
        filas.append(fila)
        log("bench %s: %.1f fps, %.0f ms, GPU %s%%, aciertos %s" % (
            id_, fila["fps"], fila["lat_p50"], fila.get("gpu_%"), fila.get("aciertos", "-")))
        time.sleep(1.5)   # que se enfrie y baje la RAM antes del siguiente
    nucleo.ocupado = ""
    arch = _escribir(filas)
    if previo:
        nucleo.cmd_modelo({"id": previo})
    return {"ok": True, "msg": "bench listo: %s" % os.path.relpath(arch, os.path.dirname(DIR_BENCH)),
            "tabla": tabla_texto(filas), "filas": filas}


COLS = [("modelo", "Modelo"), ("fps", "FPS"), ("lat_p50", "ms p50"), ("lat_p95", "ms p95"), ("cpu_%", "CPU%"),
        ("gpu_%", "GPU%"), ("ram_extra_mb", "+RAM MB"), ("temp_max", "Temp C"), ("potencia_mw", "mW"),
        ("det_por_cuadro", "Det/cuadro"), ("aciertos", "Aciertos"), ("carga_s", "Carga s"), ("motor", "Motor")]


def tabla_texto(filas):
    def v(f, k):
        x = f.get(k)
        return "-" if x is None else str(x)
    anchos = [max([len(t)] + [len(v(f, k)) for f in filas]) for k, t in COLS]
    lin = [" | ".join(t.ljust(a) for (k, t), a in zip(COLS, anchos))]
    lin.append("-+-".join("-" * a for a in anchos))
    for f in filas:
        if "nota" in f:
            lin.append(f["modelo"].ljust(anchos[0]) + " | " + f["nota"])
        else:
            lin.append(" | ".join(v(f, k).ljust(a) for (k, _), a in zip(COLS, anchos)))
    return "\n".join(lin)


def _escribir(filas):
    if not os.path.isdir(DIR_BENCH):
        os.makedirs(DIR_BENCH)
    base = os.path.join(DIR_BENCH, time.strftime("bench_%Y%m%d_%H%M"))
    claves = []
    for f in filas:
        for k in f:
            if k not in claves:
                claves.append(k)
    with open(base + ".csv", "w") as fh:
        w = csv.DictWriter(fh, fieldnames=claves)
        w.writeheader()
        for f in filas:
            w.writerow(f)
    with open(base + ".md", "w") as fh:
        fh.write("# Benchmark Modo Austero %s\n\n" % time.strftime("%Y-%m-%d %H:%M"))
        fh.write("| " + " | ".join(t for _, t in COLS) + " |\n")
        fh.write("|" + "---|" * len(COLS) + "\n")
        for f in filas:
            if "nota" in f:
                fh.write("| %s | %s |%s\n" % (f["modelo"], f["nota"], " |" * (len(COLS) - 2)))
            else:
                fh.write("| " + " | ".join("-" if f.get(k) is None else str(f.get(k)) for k, _ in COLS) + " |\n")
    return base + ".md"
