# -*- coding: utf-8 -*-
"""
stats.py - Estadisticas tipo overclock: CPU por nucleo, GPU, RAM, swap, temperaturas, consumo
y lo que gasta el propio programa. En la Jetson usa tegrastats; en otra PC lee /proc y /sys.
"""
from __future__ import print_function

import os
import re
import subprocess
import threading
import time


class Estadisticas(object):
    def __init__(self, intervalo_ms=1000):
        self.intervalo = intervalo_ms
        self.d = {"cpu": [], "cpu_prom": 0.0, "gpu": None, "ram_mb": 0, "ram_total_mb": 0, "swap_mb": 0,
                  "temp": {}, "potencia_mw": None, "proc_cpu": 0.0, "proc_ram_mb": 0.0, "fuente": "",
                  "emc": None}
        self.vivo = False
        self._p = None
        self._prev_proc = None
        self._prev_stat = None

    # ---------------------------------------------------------------- tegrastats
    def _parse_tegra(self, l):
        d = self.d
        m = re.search(r"RAM (\d+)/(\d+)MB", l)
        if m:
            d["ram_mb"], d["ram_total_mb"] = int(m.group(1)), int(m.group(2))
        m = re.search(r"SWAP (\d+)/(\d+)MB", l)
        if m:
            d["swap_mb"] = int(m.group(1))
        m = re.search(r"CPU \[([^\]]*)\]", l)
        if m:
            cpus = []
            for c in m.group(1).split(","):
                mm = re.match(r"\s*(\d+)%@(\d+)", c)
                cpus.append(int(mm.group(1)) if mm else 0)
            d["cpu"] = cpus
            d["cpu_prom"] = sum(cpus) / float(len(cpus)) if cpus else 0
        m = re.search(r"GR3D_FREQ (\d+)%(?:@(\d+))?", l)
        if m:
            d["gpu"] = int(m.group(1))
            d["gpu_mhz"] = int(m.group(2)) if m.group(2) else None
        m = re.search(r"EMC_FREQ (\d+)%", l)
        if m:
            d["emc"] = int(m.group(1))
        d["temp"] = {k: float(v) for k, v in re.findall(r"(\w+)@(-?[\d.]+)C", l) if not k.startswith("PMIC")}
        m = re.search(r"(?:POM_5V_IN|VDD_IN) (\d+)(?:mW)?/(\d+)", l)
        if m:
            d["potencia_mw"] = int(m.group(1))

    def _hilo_tegra(self):
        try:
            self._p = subprocess.Popen(["tegrastats", "--interval", str(self.intervalo)],
                                       stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, universal_newlines=True)
        except Exception:
            self._p = None
            return self._hilo_proc()
        self.d["fuente"] = "tegrastats"
        for l in self._p.stdout:
            if not self.vivo:
                break
            self._parse_tegra(l)
            self._proceso()

    # ---------------------------------------------------------------- /proc (PC o si no hay tegrastats)
    def _hilo_proc(self):
        self.d["fuente"] = "/proc"
        while self.vivo:
            try:
                lineas = [l.split() for l in open("/proc/stat") if l.startswith("cpu") and l[3] != " "]
                act = [(sum(map(int, c[1:])), int(c[4]) + int(c[5])) for c in lineas]
                if self._prev_stat and len(self._prev_stat) == len(act):
                    cpus = []
                    for (t1, i1), (t0, i0) in zip(act, self._prev_stat):
                        dt = max(1, t1 - t0)
                        cpus.append(int(round(100.0 * (1 - (i1 - i0) / float(dt)))))
                    self.d["cpu"] = cpus
                    self.d["cpu_prom"] = sum(cpus) / float(len(cpus)) if cpus else 0
                self._prev_stat = act
                mi = {}
                for l in open("/proc/meminfo"):
                    k, v = l.split(":")
                    mi[k] = int(v.split()[0]) // 1024
                self.d["ram_total_mb"] = mi.get("MemTotal", 0)
                self.d["ram_mb"] = mi.get("MemTotal", 0) - mi.get("MemAvailable", 0)
                self.d["swap_mb"] = mi.get("SwapTotal", 0) - mi.get("SwapFree", 0)
                temps = {}
                base = "/sys/class/thermal"
                if os.path.isdir(base):
                    for z in sorted(os.listdir(base)):
                        if z.startswith("thermal_zone"):
                            try:
                                tipo = open(os.path.join(base, z, "type")).read().strip()
                                temps[tipo[:8]] = int(open(os.path.join(base, z, "temp")).read()) / 1000.0
                            except Exception:
                                pass
                self.d["temp"] = temps
                g = "/sys/devices/gpu.0/load"   # Jetson sin tegrastats
                if os.path.exists(g):
                    self.d["gpu"] = int(open(g).read()) / 10
            except Exception:
                pass
            self._proceso()
            time.sleep(self.intervalo / 1000.0)

    def _proceso(self):
        try:
            st = open("/proc/self/stat").read().split()
            ticks = int(st[13]) + int(st[14])
            ahora = time.time()
            if self._prev_proc:
                t0, k0 = self._prev_proc
                self.d["proc_cpu"] = 100.0 * (ticks - k0) / os.sysconf("SC_CLK_TCK") / max(1e-3, ahora - t0)
            self._prev_proc = (ahora, ticks)
            for l in open("/proc/self/status"):
                if l.startswith("VmRSS"):
                    self.d["proc_ram_mb"] = int(l.split()[1]) / 1024.0
        except Exception:
            pass

    def iniciar(self):
        self.vivo = True
        f = self._hilo_tegra if _hay("tegrastats") else self._hilo_proc
        threading.Thread(target=f, daemon=True).start()

    def detener(self):
        self.vivo = False
        if self._p:
            try:
                self._p.terminate()
            except Exception:
                pass

    def foto(self):
        return dict(self.d)

    def temp_max(self):
        t = [v for k, v in self.d.get("temp", {}).items() if not k.lower().startswith(("pmic", "thermal"))]
        return max(t) if t else None


def _hay(cmd):
    for p in os.environ.get("PATH", "").split(os.pathsep):
        if os.path.exists(os.path.join(p, cmd)):
            return True
    return False


# ---------------------------------------------------------------- perfiles de energia (Jetson)
def perfil_energia(nombre):
    """max  -> nvpmodel 10W + jetson_clocks (relojes al maximo, como overclock)
       5w   -> nvpmodel 5W (ahorro)
       normal -> 10W sin fijar relojes"""
    cmds = {
        "max": [["sudo", "-n", "nvpmodel", "-m", "0"], ["sudo", "-n", "jetson_clocks"]],
        "normal": [["sudo", "-n", "jetson_clocks", "--restore"], ["sudo", "-n", "nvpmodel", "-m", "0"]],
        "5w": [["sudo", "-n", "jetson_clocks", "--restore"], ["sudo", "-n", "nvpmodel", "-m", "1"]],
    }.get(nombre)
    if not cmds:
        return "perfiles: max | normal | 5w"
    sal = []
    for c in cmds:
        try:
            r = subprocess.call(c, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            sal.append("%s -> %s" % (" ".join(c[2:]), "ok" if r == 0 else "error %d" % r))
        except Exception as e:
            sal.append("%s -> %s" % (" ".join(c[2:]), e))
    if any("error" in s for s in sal):
        sal.append("(si pide contrasena: corre 'sudo austero perfil %s' o agrega nvpmodel/jetson_clocks a sudoers con instalar.sh)" % nombre)
    return "; ".join(sal)
