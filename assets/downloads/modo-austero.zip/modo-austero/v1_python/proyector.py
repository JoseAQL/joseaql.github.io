# -*- coding: utf-8 -*-
"""
proyector.py - Ventana a pantalla completa en el HDMI del proyector.

Solo redibuja cuando algo cambia (ahorro). Capas:
  patron   -> imagen completa para calibrar (tapa todo lo demas)
  sombra   -> el rectangulo que tu mueves para ensenar una pieza
  marcas   -> contornos/cajas de lo que se detecto (ya en coordenadas del proyector)
  mensaje  -> texto chico abajo
"""
from __future__ import print_function

import threading

import cv2
import numpy as np

from util import log, preparar_display

VENTANA = "austero_proyector"


class Proyector(object):
    def __init__(self, cfg, simulado=False):
        self.cfg = cfg
        self.w, self.h = int(cfg.get("ancho", 1920)), int(cfg.get("alto", 1080))
        self.simulado = simulado
        self.encendido = False
        self.relleno = 0
        self.patron = None
        self.sombra = None          # dict x, y, w, h, texto
        self.marcas = []            # [(puntos Nx2 en proyector, color BGR, texto)]
        self._firma = []
        self.mensaje = ""
        self._img = np.zeros((self.h, self.w, 3), np.uint8)
        self._sucio = True
        self._ventana = False
        self._lock = threading.Lock()

    # ---------------------------------------------------------------- encendido
    def encender(self):
        if self.encendido:
            return True
        if not self.simulado:
            try:
                preparar_display(self.cfg.get("display", ":0"))
                cv2.namedWindow(VENTANA, cv2.WINDOW_NORMAL)
                cv2.moveWindow(VENTANA, int(self.cfg.get("offset_x", 0)), int(self.cfg.get("offset_y", 0)))
                cv2.setWindowProperty(VENTANA, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
                self._ventana = True
            except Exception as e:
                log("proyector: no pude abrir la ventana (%s). Sigo sin proyector." % e)
                return False
        self.encendido = True
        self._sucio = True
        return True

    def apagar(self):
        self.encendido = False
        if self._ventana:
            try:
                cv2.destroyWindow(VENTANA)
                cv2.waitKey(1)
            except Exception:
                pass
            self._ventana = False

    # ---------------------------------------------------------------- capas
    def poner_patron(self, img):
        with self._lock:
            if img is not None and (img.shape[1] != self.w or img.shape[0] != self.h):
                img = cv2.resize(img, (self.w, self.h), interpolation=cv2.INTER_NEAREST)
            if img is not None and img.ndim == 2:
                img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
            self.patron = img
            self._sucio = True
        self.actualizar()

    def quitar_patron(self):
        self.poner_patron(None)

    def poner_sombra(self, sombra):
        with self._lock:
            self.sombra = sombra
            self._sucio = True

    def poner_marcas(self, marcas):
        with self._lock:
            firma = [(np.asarray(p).tobytes(), c, t) for p, c, t in marcas]
            if firma != self._firma:
                self._firma = firma
                self.marcas = marcas
                self._sucio = True

    def poner_mensaje(self, txt):
        if txt != self.mensaje:
            self.mensaje = txt
            self._sucio = True

    # ---------------------------------------------------------------- dibujo
    def _componer(self):
        if self.patron is not None:
            return self.patron.copy()
        img = np.full((self.h, self.w, 3), self.relleno, np.uint8)
        for pts, color, txt in self.marcas:
            p = np.int32(pts).reshape(-1, 1, 2)
            cv2.polylines(img, [p], True, color, 4)
            if txt:
                x, y = p[:, 0, 0].min(), p[:, 0, 1].min()
                cv2.putText(img, txt, (int(x), int(max(30, y - 10))), cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2)
        s = self.sombra
        if s:
            x, y, w, h = int(s["x"]), int(s["y"]), int(s["w"]), int(s["h"])
            # la "sombra": todo iluminado menos el rectangulo -> la pieza queda en la zona oscura
            if s.get("estilo", "marco") == "sombra":
                img[:] = (90, 90, 90)
                img[y:y + h, x:x + w] = 0
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 220, 255), 4)
            for cx, cy in ((x, y), (x + w, y), (x, y + h), (x + w, y + h)):
                cv2.circle(img, (cx, cy), 10, (0, 220, 255), -1)
            if s.get("texto"):
                cv2.putText(img, s["texto"], (x, max(35, y - 14)), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 220, 255), 2)
        if self.mensaje:
            cv2.putText(img, self.mensaje, (30, self.h - 30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (200, 200, 200), 2)
        return img

    def actualizar(self):
        """Llamar en el lazo principal. Solo redibuja si algo cambio."""
        if not self.encendido:
            return
        with self._lock:
            if self._sucio:
                self._img = self._componer()
                self._sucio = False
                if self._ventana:
                    cv2.imshow(VENTANA, self._img)
        if self._ventana:
            cv2.waitKey(1)

    def imagen_actual(self):
        """Lo que esta saliendo por el proyector (la camara simulada lo usa)."""
        if not self.encendido:
            return None
        with self._lock:
            if self._sucio:
                self._img = self._componer()
                self._sucio = False
            return self._img
