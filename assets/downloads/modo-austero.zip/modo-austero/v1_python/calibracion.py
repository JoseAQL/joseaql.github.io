# -*- coding: utf-8 -*-
"""
calibracion.py - Proyector <-> camara (homografia de la mesa) y escala en milimetros.

Metodos (austero calibrar <metodo>):
  aruco     (por defecto) 18 marcadores ArUco con ID: una sola foto, aguanta que tapes algunos.
  puntos    rejilla de 10x6 circulos (el de arriba a la izquierda es mas grande para saber la orientacion).
  esquinas  4 puntos, uno por uno. El mas simple; sirve de respaldo.
  graycode  franjas binarias (32 fotos). Mapa pixel a pixel, el mas preciso y el mas lento.

Lazo cerrado: verificar() proyecta 3 puntos al azar y mide donde los ve la camara. Si el error pasa
la tolerancia, el nucleo recalibra solo (si config.calibracion.recalibrar_si_falla).
Todo se guarda en perfiles/calibracion.json en pixeles de la camara a resolucion completa.
"""
from __future__ import print_function

import random
import time

import cv2
import numpy as np

from util import ARCH_CALIB, cargar_json, guardar_json, log

aruco = getattr(cv2, "aruco", None)
DICCIONARIO = 0  # DICT_4X4_50
ID_MARCADOR_MM = 49


# ====================================================================== ArUco compatible con OpenCV 4.1 (Jetson) y 4.7+
def _dic():
    return aruco.getPredefinedDictionary(aruco.DICT_4X4_50)


def dibujar_marcador(id_, lado):
    if hasattr(aruco, "generateImageMarker"):
        return aruco.generateImageMarker(_dic(), id_, lado)
    return aruco.drawMarker(_dic(), id_, lado)


def detectar_marcadores(gris):
    if aruco is None:
        return [], None
    if hasattr(aruco, "ArucoDetector"):
        det = aruco.ArucoDetector(_dic(), aruco.DetectorParameters())
        esq, ids, _ = det.detectMarkers(gris)
    else:
        esq, ids, _ = aruco.detectMarkers(gris, _dic(), parameters=aruco.DetectorParameters_create())
    return esq, ids


# ====================================================================== utilidades
def transformar(H, pts):
    pts = np.float32(pts).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(pts, H).reshape(-1, 2)


def _centro_blob(dif, umbral=40, area_min=15):
    _, b = cv2.threshold(dif, umbral, 255, cv2.THRESH_BINARY)
    n, et, st, cen = cv2.connectedComponentsWithStats(b)
    if n <= 1:
        return None
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    if st[i, cv2.CC_STAT_AREA] < area_min:
        return None
    m = (et == i).astype(np.float32) * dif.astype(np.float32)   # centroide pesado por brillo
    ys, xs = np.nonzero(m)
    w = m[ys, xs]
    return float((xs * w).sum() / w.sum()), float((ys * w).sum() / w.sum())


def _gris(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img


# ====================================================================== calibracion
class Calibracion(object):
    def __init__(self, cam, proy, cfg):
        self.cam, self.proy, self.cfg = cam, proy, cfg
        self.H_c2p = None   # camara -> proyector
        self.H_p2c = None
        self.H_c2mm = None  # camara -> milimetros sobre la mesa
        self.px_por_mm = None
        self.error_px = None
        self.metodo = None
        self.t = 0
        self.cargar()

    # ---------------------------------------------------------------- guardar/cargar
    def cargar(self):
        d = cargar_json(ARCH_CALIB)
        if not d:
            return False
        try:
            self.H_c2p = np.array(d["H_c2p"], np.float64)
            self.H_p2c = np.linalg.inv(self.H_c2p)
            self.metodo, self.error_px, self.t = d.get("metodo"), d.get("error_px"), d.get("t", 0)
            if d.get("H_c2mm"):
                self.H_c2mm = np.array(d["H_c2mm"], np.float64)
                self.px_por_mm = d.get("px_por_mm")
            return True
        except Exception:
            return False

    def guardar(self):
        guardar_json(ARCH_CALIB, {
            "H_c2p": self.H_c2p.tolist() if self.H_c2p is not None else None,
            "H_c2mm": self.H_c2mm.tolist() if self.H_c2mm is not None else None,
            "px_por_mm": self.px_por_mm, "metodo": self.metodo, "error_px": self.error_px,
            "t": self.t, "camara": [self.cam.ancho, self.cam.alto], "proyector": [self.proy.w, self.proy.h]})

    @property
    def lista(self):
        return self.H_c2p is not None

    def cam_a_proy(self, pts, escala=1.0):
        """pts en la imagen de proceso (escala = ancho_completo / ancho_proceso)."""
        return transformar(self.H_c2p, np.float32(pts) * escala)

    def proy_a_cam(self, pts, escala=1.0):
        return transformar(self.H_p2c, pts) / escala

    def cam_a_mm(self, pts, escala=1.0):
        if self.H_c2mm is None:
            return None
        return transformar(self.H_c2mm, np.float32(pts) * escala)

    # ---------------------------------------------------------------- captura con patron
    def _foto(self, patron, n=2, espera=0.35):
        self.proy.poner_patron(patron)
        return self.cam.promedio(n, espera)

    def _negro(self):
        return np.zeros((self.proy.h, self.proy.w), np.uint8)

    # ---------------------------------------------------------------- metodos
    def calibrar(self, metodo="aruco", aviso=log):
        if not self.proy.encendido and not self.proy.encender():
            aviso("calibrar: el proyector no esta encendido")
            return False
        metodo = (metodo or "aruco").lower()
        f = {"aruco": self._aruco, "puntos": self._puntos, "esquinas": self._esquinas,
             "graycode": self._graycode}.get(metodo)
        if f is None:
            aviso("metodo desconocido: %s (aruco|puntos|esquinas|graycode)" % metodo)
            return False
        t0 = time.time()
        try:
            res = f(aviso)
        finally:
            self.proy.quitar_patron()
        if res is None:
            aviso("calibracion %s: FALLO" % metodo)
            return False
        H, err, npts = res
        self.H_c2p, self.H_p2c = H, np.linalg.inv(H)
        self.metodo, self.error_px, self.t = metodo, round(float(err), 2), time.time()
        aviso("calibracion %s OK: %d puntos, error %.2f px, %.1f s" % (metodo, npts, err, time.time() - t0))
        if self.cfg.get("marcador_mm", {}).get("habilitado", True):
            self.medir_mm(aviso)
        self.guardar()
        return True

    def _ajustar(self, cam_pts, proy_pts, ransac=True):
        cam_pts, proy_pts = np.float32(cam_pts), np.float32(proy_pts)
        if len(cam_pts) < 4:
            return None
        if len(cam_pts) == 4:
            H = cv2.getPerspectiveTransform(cam_pts, proy_pts)
            return H, 0.0, 4
        H, msk = cv2.findHomography(cam_pts, proy_pts, cv2.RANSAC if ransac else 0, 6.0)
        if H is None:
            return None
        ok = msk.ravel().astype(bool) if msk is not None else np.ones(len(cam_pts), bool)
        # error medido en pixeles de la CAMARA (lo que importa para recortar bien la pieza)
        Hi = np.linalg.inv(H)
        err = np.linalg.norm(transformar(Hi, proy_pts[ok]) - cam_pts[ok], axis=1).mean()
        return H, err, int(ok.sum())

    def _aruco(self, aviso):
        if aruco is None:
            aviso("este OpenCV no trae aruco; usa: austero calibrar puntos")
            return None
        W, Hh = self.proy.w, self.proy.h
        lado = int(Hh / 5.2)
        cols, filas = 6, 3
        img = np.full((Hh, W), 255, np.uint8)
        proy_pts, ids_pos = [], {}
        mx = (W - cols * lado) / (cols + 1.0)
        my = (Hh - filas * lado) / (filas + 1.0)
        k = 0
        for f in range(filas):
            for c in range(cols):
                x = int(mx + c * (lado + mx))
                y = int(my + f * (lado + my))
                img[y:y + lado, x:x + lado] = dibujar_marcador(k, lado)
                ids_pos[k] = np.float32([[x, y], [x + lado, y], [x + lado, y + lado], [x, y + lado]])
                k += 1
        foto = self._foto(img, n=2)
        if foto is None:
            return None
        esq, ids = detectar_marcadores(_gris(foto))
        if ids is None:
            aviso("aruco: no vi ningun marcador (sube la exposicion o baja la luz del cuarto)")
            return None
        cam_pts = []
        for e, i in zip(esq, ids.ravel()):
            if int(i) in ids_pos:
                cam_pts.extend(e.reshape(4, 2))
                proy_pts.extend(ids_pos[int(i)])
        aviso("aruco: vi %d de %d marcadores" % (len(cam_pts) // 4, len(ids_pos)))
        if len(cam_pts) < 8:
            return None
        return self._ajustar(cam_pts, proy_pts)

    def _puntos(self, aviso):
        W, Hh = self.proy.w, self.proy.h
        cols, filas = 10, 6
        r = max(8, int(min(W, Hh) / 60))
        img = np.zeros((Hh, W), np.uint8)
        proy_pts = []
        for f in range(filas):
            for c in range(cols):
                x = int(W * (0.1 + 0.8 * c / (cols - 1)))
                y = int(Hh * (0.1 + 0.8 * f / (filas - 1)))
                cv2.circle(img, (x, y), int(r * 1.6) if (f == 0 and c == 0) else r, 255, -1)
                proy_pts.append((x, y))
        negro = self._foto(self._negro())
        foto = self._foto(img)
        if foto is None or negro is None:
            return None
        dif = cv2.subtract(_gris(foto), _gris(negro))
        dif = cv2.GaussianBlur(dif, (3, 3), 0)
        _, b = cv2.threshold(dif, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        n, et, st, cen = cv2.connectedComponentsWithStats(b)
        blobs = [(cen[i], st[i, cv2.CC_STAT_AREA]) for i in range(1, n) if st[i, cv2.CC_STAT_AREA] >= 6]
        if len(blobs) < cols * filas:
            aviso("puntos: vi %d de %d circulos" % (len(blobs), cols * filas))
            return None
        blobs.sort(key=lambda b: -b[1])
        blobs = blobs[:cols * filas]
        grande = blobs[0][0]
        pts = np.float32([b[0] for b in blobs])
        # ordenar: findCirclesGrid sobre una imagen limpia hecha con los centros
        lim = np.zeros_like(b)
        for p in pts:
            cv2.circle(lim, (int(p[0]), int(p[1])), 4, 255, -1)
        prm = cv2.SimpleBlobDetector_Params()
        prm.filterByColor, prm.blobColor = True, 255
        prm.minArea, prm.filterByInertia, prm.filterByConvexity, prm.filterByCircularity = 10, False, False, False
        ok, grid = cv2.findCirclesGrid(lim, (cols, filas), flags=cv2.CALIB_CB_SYMMETRIC_GRID,
                                       blobDetector=cv2.SimpleBlobDetector_create(prm))
        if not ok:
            aviso("puntos: no pude ordenar la rejilla")
            return None
        grid = grid.reshape(-1, 2)
        candidatos = [grid, grid[::-1]]
        # el punto 0 tiene que ser el circulo grande
        g = min(candidatos, key=lambda c: np.linalg.norm(c[0] - grande))
        if np.linalg.norm(g[0] - grande) > 15:
            # rejilla girada 90 grados (proyector de lado): probar transpuesta
            gt = grid.reshape(filas, cols, 2)
            aviso("puntos: orientacion rara, revisa que el proyector no este girado")
            g = min([gt.reshape(-1, 2), gt[::-1, ::-1].reshape(-1, 2)], key=lambda c: np.linalg.norm(c[0] - grande))
        return self._ajustar(g, proy_pts)

    def _esquinas(self, aviso):
        W, Hh = self.proy.w, self.proy.h
        m = 0.12
        objetivos = [(W * m, Hh * m), (W * (1 - m), Hh * m), (W * (1 - m), Hh * (1 - m)), (W * m, Hh * (1 - m))]
        negro = self._foto(self._negro())
        if negro is None:
            return None
        cam_pts = []
        for i, (x, y) in enumerate(objetivos):
            img = self._negro()
            cv2.circle(img, (int(x), int(y)), int(Hh / 30), 255, -1)
            foto = self._foto(img)
            p = _centro_blob(cv2.subtract(_gris(foto), _gris(negro)))
            if p is None:
                aviso("esquinas: no vi el punto %d" % (i + 1))
                return None
            cam_pts.append(p)
        return self._ajustar(cam_pts, objetivos, ransac=False)

    def _graycode(self, aviso, paso=8):
        W, Hh = self.proy.w, self.proy.h
        cw, ch = W // paso, Hh // paso
        bx, by = int(np.ceil(np.log2(cw))), int(np.ceil(np.log2(ch)))
        xs, ys = np.arange(cw), np.arange(ch)
        gx, gy = xs ^ (xs >> 1), ys ^ (ys >> 1)
        negro = self._foto(self._negro())
        blanco = self._foto(np.full((Hh, W), 255, np.uint8))
        if negro is None or blanco is None:
            return None
        valido = (_gris(blanco).astype(np.int16) - _gris(negro)) > 25

        def leer_bits(codigos, nbits, eje):
            val = np.zeros(valido.shape, np.int32)
            for b in range(nbits - 1, -1, -1):
                bit = ((codigos >> b) & 1).astype(np.uint8) * 255
                pat = np.tile(bit, (ch, 1)) if eje == 0 else np.tile(bit[:, None], (1, cw))
                pat = cv2.resize(pat, (W, Hh), interpolation=cv2.INTER_NEAREST)
                a = _gris(self._foto(pat, n=1, espera=0.25)).astype(np.int16)
                bb = _gris(self._foto(255 - pat, n=1, espera=0.25)).astype(np.int16)
                valido[:] &= np.abs(a - bb) > 8
                val = (val << 1) | (a > bb).astype(np.int32)
            # gris -> binario
            res = val.copy()
            s = val >> 1
            while s.any():
                res ^= s
                s >>= 1
            return res
        aviso("graycode: %d fotos, espera unos segundos..." % (2 * 2 * (bx + by)))
        col = leer_bits(gx, bx, 0)
        fil = leer_bits(gy, by, 1)
        ys_c, xs_c = np.nonzero(valido)
        if len(xs_c) < 50:
            return None
        sel = np.arange(0, len(xs_c), max(1, len(xs_c) // 3000))
        cam = np.float32(np.stack([xs_c[sel], ys_c[sel]], 1))
        pro = np.float32(np.stack([col[ys_c[sel], xs_c[sel]] * paso + paso / 2.0,
                                   fil[ys_c[sel], xs_c[sel]] * paso + paso / 2.0], 1))
        try:
            np.savez_compressed(ARCH_CALIB.replace(".json", "_graycode.npz"),
                                col=col.astype(np.int16), fil=fil.astype(np.int16), valido=valido)
        except Exception:
            pass
        return self._ajustar(cam, pro)

    # ---------------------------------------------------------------- lazo cerrado
    def verificar(self, aviso=log, n=3):
        """Proyecta n puntos al azar y compara donde deberian caer con donde los ve la camara."""
        if not self.lista:
            return None
        if not self.proy.encendido:
            return None
        W, Hh = self.proy.w, self.proy.h
        try:
            negro = self._foto(self._negro())
            errs = []
            for _ in range(n):
                x, y = random.uniform(0.2, 0.8) * W, random.uniform(0.2, 0.8) * Hh
                img = self._negro()
                cv2.circle(img, (int(x), int(y)), int(Hh / 40), 255, -1)
                p = _centro_blob(cv2.subtract(_gris(self._foto(img)), _gris(negro)))
                if p is None:
                    continue
                esperado = transformar(self.H_p2c, [(x, y)])[0]
                errs.append(float(np.linalg.norm(esperado - np.float32(p))))
        finally:
            self.proy.quitar_patron()
        if not errs:
            aviso("verificar: no vi los puntos de prueba")
            return None
        e = float(np.mean(errs))
        self.error_px = round(e, 2)
        aviso("verificar: error %.1f px (tolerancia %s)" % (e, self.cfg.get("tolerancia_px", 8)))
        return e

    # ---------------------------------------------------------------- milimetros
    def medir_mm(self, aviso=log):
        """Busca un ArUco IMPRESO (ID 49, lado conocido) sobre la mesa para sacar la escala en mm."""
        if aruco is None:
            return False
        mm = float(self.cfg.get("marcador_mm", {}).get("lado_mm", 50))
        id_ = int(self.cfg.get("marcador_mm", {}).get("id", ID_MARCADOR_MM))
        if self.proy.encendido:
            self.proy.poner_patron(np.full((self.proy.h, self.proy.w), 200, np.uint8))
        foto = self.cam.promedio(2, 0.3)
        if self.proy.encendido:
            self.proy.quitar_patron()
        if foto is None:
            return False
        esq, ids = detectar_marcadores(_gris(foto))
        if ids is None or id_ not in ids.ravel():
            aviso("mm: no vi el marcador impreso ID %d (opcional; imprime perfiles/marcador_mm.png)" % id_)
            return False
        e = esq[list(ids.ravel()).index(id_)].reshape(4, 2)
        dst = np.float32([[0, 0], [mm, 0], [mm, mm], [0, mm]])
        self.H_c2mm = cv2.getPerspectiveTransform(np.float32(e), dst)
        lados = [np.linalg.norm(e[i] - e[(i + 1) % 4]) for i in range(4)]
        self.px_por_mm = round(float(np.mean(lados)) / mm, 4)
        aviso("mm: %.2f px por mm" % self.px_por_mm)
        return True


def guardar_marcador_impreso(ruta_png, id_=ID_MARCADOR_MM, lado_mm=50, dpi=300):
    """PNG para imprimir a escala 100%: el cuadro negro mide lado_mm."""
    lado = int(lado_mm / 25.4 * dpi)
    m = dibujar_marcador(id_, lado)
    borde = lado // 4
    img = np.full((lado + 2 * borde, lado + 2 * borde), 255, np.uint8)
    img[borde:borde + lado, borde:borde + lado] = m
    cv2.putText(img, "ID %d - %d mm - imprimir al 100%%" % (id_, lado_mm), (borde, borde // 2),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, 0, 2)
    cv2.imwrite(ruta_png, img)
