# -*- coding: utf-8 -*-
"""cliente.py - Manda comandos al nucleo por el socket local. Lo usa el script `austero`."""
from __future__ import print_function

import json
import socket
import sys

from util import SOCKET


def enviar(msg, timeout=900):
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(timeout)
    s.connect(SOCKET)
    s.sendall((json.dumps(msg) + "\n").encode("utf-8"))
    datos = b""
    while not datos.endswith(b"\n"):
        p = s.recv(1 << 20)
        if not p:
            break
        datos += p
    s.close()
    return json.loads(datos.decode("utf-8"))


AYUDA = """uso: austero <comando>
  status | log                         estado y ultimos mensajes
  modelo <1-9|id|0>                     cambiar de modelo (0 = ninguno)
  param <nombre> <valor>                umbral, nms, entrada (tamano YOLO), area_min, dif
  filtro <nombre> <valor>               gamma, clahe, suavizado (kernel), nitidez
  autoajuste                            ajustar la camara sola
  calibrar [aruco|puntos|esquinas|graycode]
  verificar | mm                        revisar la calibracion / medir escala en mm
  proyector|web|manos|buscar|marcas on|off
  fondo                                 foto de la mesa vacia
  ensenar "<pieza>" | ensenar guardar|auto|cancelar
  confirmar                             guardar foto + detecciones actuales en dataset/
  olvidar "<pieza>"
  bench [ids o teclas...] [--seg N]      benchmark (todos si no dices cuales)
  perfil max|normal|5w                  energia de la Jetson (nvpmodel / jetson_clocks)
  foto
  sim revolver|vaciar|marcador|mover_proyector   (solo camara simulada)"""


def armar(args):
    if not args:
        return None
    c, r = args[0], args[1:]
    if c in ("status", "estado"):
        return {"cmd": "estado"}
    if c == "log":
        return {"cmd": "log", "n": int(r[0]) if r else 30}
    if c == "modelo":
        return {"cmd": "modelo", "id": r[0] if r else "0"}
    if c in ("param", "filtro"):
        return {"cmd": c, "k": r[0], "v": r[1]}
    if c in ("proyector", "web", "manos", "buscar", "marcas"):
        return {"cmd": c, "on": r[0] if r else None}
    if c == "calibrar":
        return {"cmd": "calibrar", "metodo": r[0] if r else None}
    if c == "ensenar":
        if r and r[0] in ("guardar", "auto", "cancelar"):
            return {"cmd": "ensenar", "accion": r[0]}
        return {"cmd": "ensenar", "accion": "inicio", "clase": " ".join(r)}
    if c == "olvidar":
        return {"cmd": "olvidar", "clase": " ".join(r)}
    if c == "bench":
        seg = None
        ids = []
        i = 0
        while i < len(r):
            if r[i] == "--seg" and i + 1 < len(r):
                seg = float(r[i + 1])
                i += 2
                continue
            ids.append(r[i])
            i += 1
        return {"cmd": "bench", "modelos": ids, "seg": seg}
    if c == "perfil":
        return {"cmd": "perfil", "nombre": r[0] if r else ""}
    if c == "sim":
        return {"cmd": "sim", "accion": r[0] if r else "revolver", "tipo": r[1] if len(r) > 1 else "tijera",
                "n": int(r[1]) if len(r) > 1 and r[1].isdigit() else 3}
    return {"cmd": c}


def main():
    msg = armar(sys.argv[1:])
    if msg is None or sys.argv[1] in ("-h", "--help", "ayuda"):
        print(AYUDA)
        return 0
    try:
        r = enviar(msg)
    except Exception as e:
        print("el nucleo no esta corriendo (austero start)  [%s]" % e)
        return 2
    if msg["cmd"] == "estado":
        from tablero import resumen_texto
        print(resumen_texto(r["estado"]))
    elif msg["cmd"] == "log":
        print("\n".join(r.get("log", [])))
    else:
        if r.get("tabla"):
            print(r["tabla"])
        print(r.get("msg") or ("ok" if r.get("ok") else "error"))
    return 0 if r.get("ok", True) else 1


if __name__ == "__main__":
    sys.exit(main())
