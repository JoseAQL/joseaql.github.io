# -*- coding: utf-8 -*-
"""
web.py - Pagina web OPCIONAL (apagada por defecto). `austero web on`
Una sola pagina sin librerias: video MJPEG a pocos fps, estadisticas y botones. Si nadie la mira,
el nucleo no dibuja nada para ella.
"""
from __future__ import print_function

import json
import socket
import threading
import time

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:  # pragma: no cover
    raise

import cv2

PAGINA = u"""<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Modo Austero</title>
<style>
:root{--f:#0d1014;--c:#151a20;--t:#d7dde4;--g:#7b8794;--v:#5bd68a;--a:#f5c451;--r:#ef6b6b}
body{margin:0;background:var(--f);color:var(--t);font:14px/1.4 ui-monospace,Menlo,Consolas,monospace}
main{max-width:1100px;margin:auto;padding:12px 16px;display:grid;gap:12px;grid-template-columns:minmax(0,2fr) minmax(0,1fr)}
@media(max-width:800px){main{grid-template-columns:1fr}}
section{background:var(--c);border-radius:8px;padding:10px}
img{width:100%;border-radius:6px;background:#000;display:block}
button{background:#222a33;color:var(--t);border:1px solid #2f3a46;border-radius:6px;padding:6px 9px;margin:2px;cursor:pointer;font:inherit}
button:hover{border-color:var(--v)} .on{color:var(--v)} .off{color:var(--g)}
h1{font-size:15px;margin:0 0 6px} .bar{height:8px;background:#222a33;border-radius:4px;overflow:hidden;margin:2px 0 6px}
.bar i{display:block;height:100%;background:var(--v)} pre{white-space:pre-wrap;margin:0;color:var(--g);font-size:12px}
</style></head><body><main>
<section><img src="/stream.mjpg" alt="camara"><div id="dets"></div></section>
<section><h1>MODO AUSTERO</h1><div id="st"></div>
<div id="botones"></div>
<div><button onclick="c('autoajuste')">auto-ajuste</button><button onclick="c('calibrar',{metodo:'aruco'})">calibrar aruco</button>
<button onclick="c('calibrar',{metodo:'puntos'})">puntos</button><button onclick="c('calibrar',{metodo:'esquinas'})">esquinas</button>
<button onclick="c('calibrar',{metodo:'graycode'})">graycode</button><button onclick="c('verificar')">verificar</button>
<button onclick="c('fondo')">fondo</button><button onclick="c('manos')">manos</button><button onclick="c('buscar')">buscar</button>
<button onclick="c('proyector')">proyector</button><button onclick="ens()">enseñar…</button>
<button onclick="c('ensenar',{accion:'auto'})">propuesta</button><button onclick="c('ensenar',{accion:'guardar'})">guardar ejemplo</button>
<button onclick="c('ensenar',{accion:'cancelar'})">terminar</button><button onclick="c('web',{on:false})">apagar web</button></div>
<pre id="log"></pre></section></main>
<script>
function c(cmd,x){x=x||{};x.cmd=cmd;fetch('/cmd',{method:'POST',body:JSON.stringify(x)}).then(r=>r.json()).then(r=>{if(r.msg)document.getElementById('log').textContent='» '+r.msg})}
function ens(){var n=prompt('¿Qué pieza?');if(n)c('ensenar',{accion:'inicio',clase:n})}
function b(p){p=Math.max(0,Math.min(100,p||0));return '<div class="bar"><i style="width:'+p+'%;background:'+(p<60?'var(--v)':p<85?'var(--a)':'var(--r)')+'"></i></div>'}
document.addEventListener('keydown',e=>{var m={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[e.key];if(m){c('ensenar',{accion:'mover',dx:m[0],dy:m[1]});e.preventDefault()}
 if(e.key=='Enter')c('ensenar',{accion:'guardar'});if(e.key=='+')c('ensenar',{accion:'tam',dw:1,dh:1});if(e.key=='-')c('ensenar',{accion:'tam',dw:-1,dh:-1})});
function t(){fetch('/estado').then(r=>r.json()).then(e=>{var s=e.stats||{};
 document.getElementById('st').innerHTML='modelo <b>'+(e.modelo||'ninguno')+'</b> '+(e.motor||'')+'<br>'+e.fps+' fps · '+e.lat_ms+' ms<br>CPU '+Math.round(s.cpu_prom||0)+'%'+b(s.cpu_prom)+'GPU '+(s.gpu==null?'-':s.gpu)+'%'+b(s.gpu)+'RAM '+s.ram_mb+'/'+s.ram_total_mb+' MB'+b(100*s.ram_mb/(s.ram_total_mb||1))+
 'temp '+Object.entries(s.temp||{}).map(k=>k[0]+' '+Math.round(k[1])+'°').join(' ')+(s.potencia_mw?' · '+(s.potencia_mw/1000).toFixed(1)+' W':'')+'<br>calibración '+(e.calib.lista?e.calib.metodo+' '+e.calib.error_px+' px':'NO');
 document.getElementById('botones').innerHTML=(e.catalogo||[]).map(m=>'<button class="'+(m.id==e.modelo?'on':'off')+'" onclick="c(\\'modelo\\',{id:\\''+m.id+'\\'})">'+m.tecla+' '+m.id+'</button>').join('')+'<button onclick="c(\\'modelo\\',{id:\\'0\\'})">0 ninguno</button>';
 document.getElementById('dets').textContent=(e.dets||[]).map(d=>d.clase+' '+Math.round(d.conf*100)+'%').join('  ');
 if(!document.getElementById('log').textContent.startsWith('»'))document.getElementById('log').textContent=(e.log||[]).join('\\n')}).catch(()=>{})}
setInterval(t,1000);t();
</script></body></html>"""


class _Servidor(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class ServidorWeb(object):
    def __init__(self, nucleo, puerto):
        self.n = nucleo
        self.puerto = puerto
        self.srv = None
        ip = "0.0.0.0"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("100.100.100.100", 80))   # IP de Tailscale si existe
            ip = s.getsockname()[0]
            s.close()
        except Exception:
            pass
        self.url = "http://%s:%d" % (ip, puerto)

    def iniciar(self):
        n = self.n
        fps = float(n.cfg.get("web", {}).get("fps_stream", 5))

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _json(self, d):
                from nucleo import _json_np
                b = json.dumps(d, ensure_ascii=False, default=_json_np).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_GET(self):
                if self.path.startswith("/estado"):
                    return self._json(n.estado())
                if self.path.startswith("/stream.mjpg"):
                    self.send_response(200)
                    self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=f")
                    self.end_headers()
                    try:
                        while n.web is not None:
                            n.t_anotada_pedida = time.time()
                            img = n.anotada
                            if img is not None:
                                ok, j = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 70])
                                self.wfile.write(b"--f\r\nContent-Type: image/jpeg\r\nContent-Length: " +
                                                 str(len(j)).encode() + b"\r\n\r\n" + j.tobytes() + b"\r\n")
                            time.sleep(1.0 / fps)
                    except Exception:
                        pass
                    return
                b = PAGINA.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def do_POST(self):
                largo = int(self.headers.get("Content-Length", 0))
                msg = json.loads(self.rfile.read(largo).decode("utf-8") or "{}")
                self._json(n.atender(msg))

        self.srv = _Servidor(("0.0.0.0", self.puerto), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def detener(self):
        if self.srv:
            srv = self.srv
            self.srv = None
            threading.Thread(target=srv.shutdown, daemon=True).start()
