# -*- coding: utf-8 -*-
"""
memoria.py - El modo "Terminator": tu le ensenas donde esta una pieza y despues busca las parecidas.

Ensenar:
  1. pones la sombra/marco del proyector sobre la pieza (o la camara la propone sola: auto-sombra)
  2. se recorta esa zona, se separa la pieza del fondo y se guarda su "huella":
       forma (contorno + momentos de Hu), proporcion largo/ancho, tamano, color (histograma HSV)
  3. ademas se guarda la foto completa con su etiqueta YOLO en dataset/ para entrenar un modelo despues

Buscar:
  candidatos = lo que es distinto al fondo  ->  se compara su huella con todas las ensenadas
  la clase con mas parecido gana si pasa el umbral. No necesita red neuronal: corre en CPU y gasta poco.
"""
from __future__ import print_function

import json
import os
import time

import cv2
import numpy as np

from util import DIR_DATASET, DIR_MEMORIA, guardar_json, log


def _contornos(m):
    r = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return r[0] if len(r) == 2 else r[1]


def _huella(img, contorno):
    x, y, w, h = cv2.boundingRect(contorno)
    (cx, cy), (rw, rh), ang = cv2.minAreaRect(contorno)
    largo, ancho = max(rw, rh), max(1.0, min(rw, rh))
    m = np.zeros(img.shape[:2], np.uint8)
    cv2.drawContours(m, [contorno], -1, 255, -1)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], m, [16, 8], [0, 180, 0, 256])
    cv2.normalize(hist, hist, 1.0, 0, cv2.NORM_L1)
    hu = cv2.HuMoments(cv2.moments(contorno)).ravel()
    hu = -np.sign(hu) * np.log10(np.abs(hu) + 1e-30)
    if rw < rh:
        ang += 90
    return {"area": float(cv2.contourArea(contorno)), "largo": float(largo), "ancho": float(ancho),
            "proporcion": float(largo / ancho), "hu": hu.tolist(), "hist": hist.ravel().tolist(),
            "angulo": float(ang % 180), "caja": [int(x), int(y), int(x + w), int(y + h)]}


def segmentar_en_recorte(img, caja, fondo=None, mascara=None, dif=30):
    """La pieza mas grande dentro de 'caja'. Con fondo usa la diferencia; sin fondo usa el contraste
    contra el borde del recorte (la mesa)."""
    H, W = img.shape[:2]
    x1, y1, x2, y2 = [int(v) for v in caja]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(W, x2), min(H, y2)
    if x2 - x1 < 8 or y2 - y1 < 8:
        return None
    rec = img[y1:y2, x1:x2]
    if fondo is not None and fondo.shape == img.shape:
        d = cv2.absdiff(cv2.GaussianBlur(rec, (5, 5), 0), cv2.GaussianBlur(fondo[y1:y2, x1:x2], (5, 5), 0)).max(2)
        _, m = cv2.threshold(d, dif, 255, cv2.THRESH_BINARY)
    else:
        g = cv2.GaussianBlur(cv2.cvtColor(rec, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        borde = np.concatenate([g[0], g[-1], g[:, 0], g[:, -1]])
        d = cv2.absdiff(g, np.full_like(g, int(np.median(borde))))
        _, m = cv2.threshold(d, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if mascara is not None:
        m[mascara[y1:y2, x1:x2] > 0] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    cnts = [c for c in _contornos(m) if cv2.contourArea(c) > 30]
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)
    return c + np.array([[[x1, y1]]], np.int32)


class Memoria(object):
    def __init__(self):
        self.ejemplos = []      # [{"clase", "huella", "contorno"}]
        self._lista_clases = []
        self.recargar()

    # ---------------------------------------------------------------- archivo
    def clases(self):
        return list(self._lista_clases)

    def _arch_clases(self):
        return os.path.join(DIR_MEMORIA, "clases.txt")

    def recargar(self):
        self.ejemplos = []
        self._lista_clases = []
        if os.path.exists(self._arch_clases()):
            self._lista_clases = [l.strip() for l in open(self._arch_clases()) if l.strip()]
        for cl in self._lista_clases:
            d = os.path.join(DIR_MEMORIA, _slug(cl))
            if not os.path.isdir(d):
                continue
            for f in sorted(os.listdir(d)):
                if f.endswith(".json"):
                    try:
                        hu = json.load(open(os.path.join(d, f)))
                        c = np.load(os.path.join(d, f.replace(".json", ".npy")))
                        self.ejemplos.append({"clase": cl, "huella": hu, "contorno": c,
                                              "hist": np.float32(hu["hist"]).reshape(16, 8)})
                    except Exception:
                        pass

    def resumen(self):
        cuenta = {}
        for e in self.ejemplos:
            cuenta[e["clase"]] = cuenta.get(e["clase"], 0) + 1
        return cuenta

    def indice(self, clase):
        if clase not in self._lista_clases:
            self._lista_clases.append(clase)
            if not os.path.isdir(DIR_MEMORIA):
                os.makedirs(DIR_MEMORIA)
            with open(self._arch_clases(), "w") as f:
                f.write("\n".join(self._lista_clases) + "\n")
        return self._lista_clases.index(clase)

    # ---------------------------------------------------------------- ensenar
    def ensenar(self, img, caja_cam, clase, fondo=None, mascara=None, mm_por_px=None):
        c = segmentar_en_recorte(img, caja_cam, fondo, mascara)
        if c is None:
            return None, "no encontre una pieza dentro de la sombra (prueba con 'f' para guardar el fondo vacio)"
        hu = _huella(img, c)
        if mm_por_px:
            hu["largo_mm"] = round(hu["largo"] * mm_por_px, 1)
            hu["ancho_mm"] = round(hu["ancho"] * mm_por_px, 1)
        idx = self.indice(clase)
        d = os.path.join(DIR_MEMORIA, _slug(clase))
        if not os.path.isdir(d):
            os.makedirs(d)
        n = len([f for f in os.listdir(d) if f.endswith(".json")]) + 1
        base = os.path.join(d, "%03d" % n)
        x1, y1, x2, y2 = hu["caja"]
        cv2.imwrite(base + ".jpg", img[y1:y2, x1:x2])
        np.save(base + ".npy", c)
        guardar_json(base + ".json", hu)
        # dataset para entrenar despues (foto completa + etiqueta YOLO)
        self._guardar_dataset(img, [(idx, hu["caja"])])
        self.ejemplos.append({"clase": clase, "huella": hu, "contorno": c,
                              "hist": np.float32(hu["hist"]).reshape(16, 8)})
        extra = " (%.0f x %.0f mm)" % (hu["largo_mm"], hu["ancho_mm"]) if "largo_mm" in hu else ""
        return {"caja": hu["caja"], "contorno": c, "angulo": hu["angulo"]}, \
            "aprendi '%s' ejemplo %d%s" % (clase, n, extra)

    def _guardar_dataset(self, img, etiquetas):
        di, dl = os.path.join(DIR_DATASET, "images"), os.path.join(DIR_DATASET, "labels")
        for d in (di, dl):
            if not os.path.isdir(d):
                os.makedirs(d)
        nombre = time.strftime("%Y%m%d_%H%M%S_") + "%03d" % int((time.time() % 1) * 1000)
        H, W = img.shape[:2]
        cv2.imwrite(os.path.join(di, nombre + ".jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 92])
        with open(os.path.join(dl, nombre + ".txt"), "w") as f:
            for idx, (x1, y1, x2, y2) in etiquetas:
                f.write("%d %.6f %.6f %.6f %.6f\n" % (idx, (x1 + x2) / 2.0 / W, (y1 + y2) / 2.0 / H,
                                                     (x2 - x1) / float(W), (y2 - y1) / float(H)))
        with open(os.path.join(DIR_DATASET, "clases.txt"), "w") as f:
            f.write("\n".join(self._lista_clases) + "\n")

    def confirmar_detecciones(self, img, dets):
        """Guarda una foto con todas las detecciones actuales como etiquetas (para crecer el dataset)."""
        et = [(self.indice(d["clase"]), d["caja"]) for d in dets if d["clase"] in self._lista_clases]
        if et:
            self._guardar_dataset(img, et)
        return len(et)

    # ---------------------------------------------------------------- buscar
    def candidatos(self, img, fondo, mascara, dif=30, area_min=400):
        if fondo is not None and fondo.shape == img.shape:
            from modelos import segmentar_fondo
            return [c for c, _ in segmentar_fondo(img, fondo, dif, area_min, mascara)]
        # sin fondo: bordes (gasta un poco mas y es menos limpio)
        g = cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        e = cv2.Canny(g, 40, 110)
        if mascara is not None:
            e[mascara > 0] = 0
        e = cv2.dilate(e, np.ones((5, 5), np.uint8), iterations=2)
        e = cv2.erode(e, np.ones((3, 3), np.uint8))
        return [c for c in _contornos(e) if cv2.contourArea(c) >= area_min]

    def parecido(self, hu, c, ej):
        h2 = ej["huella"]
        forma = float(np.exp(-4.0 * cv2.matchShapes(c, ej["contorno"], cv2.CONTOURS_MATCH_I1, 0)))
        prop = min(hu["proporcion"], h2["proporcion"]) / max(hu["proporcion"], h2["proporcion"])
        tam = min(hu["area"], h2["area"]) / max(hu["area"], h2["area"], 1.0)
        tam = tam ** 0.5
        col = max(0.0, cv2.compareHist(np.float32(hu["hist"]).reshape(16, 8), ej["hist"], cv2.HISTCMP_CORREL))
        return 0.45 * forma + 0.2 * prop + 0.2 * tam + 0.15 * col

    def buscar(self, img, fondo, mascara, umbral=0.55, dif=30, area_min=400):
        if not self.ejemplos:
            return []
        res = []
        for c in self.candidatos(img, fondo, mascara, dif, area_min)[:20]:
            hu = _huella(img, c)
            mejor = {}
            for ej in self.ejemplos:
                s = self.parecido(hu, c, ej)
                if s > mejor.get(ej["clase"], 0):
                    mejor[ej["clase"]] = s
            if not mejor:
                continue
            cl = max(mejor, key=mejor.get)
            if mejor[cl] >= umbral:
                res.append({"clase": cl, "conf": round(mejor[cl], 3), "caja": hu["caja"], "contorno": c,
                            "angulo": round(hu["angulo"], 1)})
        return res

    def borrar_clase(self, clase):
        """No borra archivos (por seguridad): solo la quita de clases.txt."""
        if clase in self._lista_clases:
            self._lista_clases.remove(clase)
            with open(self._arch_clases(), "w") as f:
                f.write("\n".join(self._lista_clases) + "\n")
            self.recargar()
            return True
        return False


def _slug(s):
    out = "".join(ch if ch.isalnum() else "_" for ch in s.strip().lower())
    return out.strip("_") or "pieza"
