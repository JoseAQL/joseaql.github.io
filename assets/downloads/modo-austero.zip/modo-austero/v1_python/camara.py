# -*- coding: utf-8 -*-
"""
camara.py - Captura en un hilo (siempre el cuadro mas nuevo), controles V4L2, filtros y auto-ajuste.

Tipos de camara (config "camara.tipo"):
  usb   -> cv2.VideoCapture con V4L2 (MJPG), controles por v4l2-ctl
  csi   -> jetson_utils.videoSource("csi://0")
  sim   -> camara simulada (mesa + instrumentos + lo que proyecta el proyector), para probar sin Jetson
"""
from __future__ import print_function

import math
import re
import subprocess
import threading
import time

import cv2
import numpy as np

from util import log


# ====================================================================== controles V4L2
class ControlesV4L2(object):
    def __init__(self, dev):
        self.dev = dev
        self.lista = self._listar()

    def _listar(self):
        try:
            sal = subprocess.check_output(["v4l2-ctl", "-d", self.dev, "--list-ctrls"],
                                          stderr=subprocess.STDOUT).decode("utf-8", "ignore")
        except Exception:
            return {}
        res = {}
        for linea in sal.splitlines():
            m = re.match(r"\s*(\w+)\s+0x[0-9a-f]+\s+\((\w+)\)\s*:\s*(.*)", linea)
            if not m:
                continue
            d = {"tipo": m.group(2)}
            for k, v in re.findall(r"(\w+)=(-?\d+)", m.group(3)):
                d[k] = int(v)
            res[m.group(1)] = d
        return res

    def tiene(self, nombre):
        return nombre in self.lista

    def rango(self, nombre):
        d = self.lista.get(nombre, {})
        return d.get("min", 0), d.get("max", 0)

    def leer(self, nombre):
        try:
            sal = subprocess.check_output(["v4l2-ctl", "-d", self.dev, "--get-ctrl=" + nombre],
                                          stderr=subprocess.STDOUT).decode()
            return int(sal.split(":")[-1])
        except Exception:
            return self.lista.get(nombre, {}).get("value")

    def poner(self, nombre, valor):
        if nombre not in self.lista:
            return False
        try:
            subprocess.call(["v4l2-ctl", "-d", self.dev, "--set-ctrl=%s=%d" % (nombre, int(valor))],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.lista[nombre]["value"] = int(valor)
            return True
        except Exception:
            return False


class ControlesSim(object):
    """Los mismos controles, pero para la camara simulada (sirve para probar el auto-ajuste)."""
    def __init__(self):
        self.lista = {
            "exposure_auto": {"tipo": "menu", "min": 0, "max": 3, "value": 3},
            "exposure_absolute": {"tipo": "int", "min": 3, "max": 2047, "value": 1500},
            "gain": {"tipo": "int", "min": 0, "max": 255, "value": 0},
        }

    def tiene(self, n):
        return n in self.lista

    def rango(self, n):
        return self.lista[n]["min"], self.lista[n]["max"]

    def leer(self, n):
        return self.lista.get(n, {}).get("value")

    def poner(self, n, v):
        if n in self.lista:
            self.lista[n]["value"] = int(max(self.lista[n]["min"], min(self.lista[n]["max"], v)))
            return True
        return False

    def factor(self):
        e = self.lista["exposure_absolute"]["value"]
        g = self.lista["gain"]["value"]
        return (e / 300.0) * (1.0 + g / 64.0)


# ====================================================================== camara simulada
class EscenaSim(object):
    """Mesa vista desde arriba. Lo que proyecta el proyector cae sobre la mesa con una homografia 'real'
    que el programa no conoce: la calibracion la tiene que descubrir."""

    def __init__(self, ancho, alto, semilla=3):
        self.w, self.h = ancho, alto
        rs = np.random.RandomState(semilla)
        base = np.full((alto, ancho, 3), (70, 75, 72), np.float32)
        ruido = rs.normal(0, 4, (alto // 8, ancho // 8, 1)).astype(np.float32)
        base += cv2.resize(ruido, (ancho, alto))[:, :, None]
        self.mesa = base
        # donde cae el proyector en la camara (homografia real desconocida para el programa)
        m = 0.08
        self.esq_proy_en_cam = np.float32([[ancho * m, alto * (m + 0.02)], [ancho * (1 - m * 0.7), alto * m],
                                           [ancho * (1 - m), alto * (1 - m)], [ancho * (m * 1.2), alto * (1 - m * 1.1)]])
        self.proy_wh = None
        self.objetos = []
        self.rs = rs
        self.revolver(2)
        self.mm_por_px = 0.75   # para el marcador impreso simulado
        self.marcador = None

    def revolver(self, n=3):
        tipos = ["tijera", "bisturi", "pinza"]
        self.objetos = []
        for i in range(n):
            t = tipos[i % len(tipos)]
            self.objetos.append({"tipo": t, "x": self.rs.uniform(0.25, 0.75) * self.w,
                                 "y": self.rs.uniform(0.3, 0.7) * self.h, "ang": self.rs.uniform(0, 180)})

    @staticmethod
    def dibujar_objeto(img, o, escala=1.0):
        x, y, a = o["x"], o["y"], math.radians(o["ang"])
        c, s = math.cos(a), math.sin(a)

        def P(dx, dy):
            return (int(x + (dx * c - dy * s) * escala), int(y + (dx * s + dy * c) * escala))
        col = (205, 205, 210)
        if o["tipo"] == "tijera":
            cv2.line(img, P(-90, -14), P(60, 10), col, 7)
            cv2.line(img, P(-90, 14), P(60, -10), col, 7)
            cv2.circle(img, P(-105, -20), 15, col, 5)
            cv2.circle(img, P(-105, 20), 15, col, 5)
        elif o["tipo"] == "bisturi":
            cv2.line(img, P(-90, 0), P(40, 0), col, 10)
            pts = np.array([P(40, -6), P(85, 0), P(40, 7)], np.int32)
            cv2.fillPoly(img, [pts], (225, 225, 230))
        else:
            cv2.line(img, P(-80, -3), P(70, -16), col, 6)
            cv2.line(img, P(-80, 3), P(70, 16), col, 6)

    def render(self, proy_img, factor_luz):
        img = self.mesa.copy()
        luz = np.full((self.h, self.w), 0.55, np.float32)
        if proy_img is not None:
            proy_img = cv2.resize(proy_img, (960, int(960 * proy_img.shape[0] / proy_img.shape[1])),
                                  interpolation=cv2.INTER_AREA)
            ph, pw = proy_img.shape[:2]
            src = np.float32([[0, 0], [pw, 0], [pw, ph], [0, ph]])
            H = cv2.getPerspectiveTransform(src, self.esq_proy_en_cam)
            pr = cv2.warpPerspective(proy_img, H, (self.w, self.h)).astype(np.float32) / 255.0
            luz3 = 0.55 + 1.3 * pr
        else:
            luz3 = np.repeat(luz[:, :, None], 3, 2)
        objs = np.zeros((self.h, self.w, 3), np.uint8)
        for o in self.objetos:
            self.dibujar_objeto(objs, o)
        if self.marcador is not None:
            mk, (mx, my) = self.marcador
            objs[my:my + mk.shape[0], mx:mx + mk.shape[1]] = mk
            img[my:my + mk.shape[0], mx:mx + mk.shape[1]] = 0
        msk = objs.max(2) > 0
        img[msk] = objs[msk].astype(np.float32) * 0.85
        img = img * luz3 * factor_luz
        img += np.random.normal(0, 2.0, img.shape).astype(np.float32)
        return np.clip(img, 0, 255).astype(np.uint8)


# ====================================================================== camara
class Camara(object):
    def __init__(self, cfg):
        self.cfg = cfg
        self.tipo = cfg.get("tipo", "usb")
        self.ancho, self.alto = int(cfg.get("ancho", 1280)), int(cfg.get("alto", 720))
        self.cuadro = None
        self.n = 0
        self.t_cuadro = 0.0
        self.fps_cap = 0.0
        self.vivo = False
        self.ok = False
        self.error = ""
        self.proyector = None       # solo lo usa la simulada
        self.escena = None
        self.ctl = None
        self._lock = threading.Lock()
        self._abrir()

    def _abrir(self):
        if self.tipo == "sim":
            self.escena = EscenaSim(self.ancho, self.alto)
            self.ctl = ControlesSim()
            self.ok = True
            return
        if self.tipo == "csi":
            try:
                from jetson_utils import videoSource, cudaToNumpy, cudaDeviceSynchronize
                self._src = videoSource("csi://%d" % int(self.cfg.get("indice", 0)),
                                        argv=["--input-width=%d" % self.ancho, "--input-height=%d" % self.alto])
                self._a_numpy = (cudaToNumpy, cudaDeviceSynchronize)
                self.ok = True
            except Exception as e:
                self.error = "csi: %s" % e
            return
        dev = "/dev/video%d" % int(self.cfg.get("indice", 0))
        self.cap = cv2.VideoCapture(int(self.cfg.get("indice", 0)), cv2.CAP_V4L2)
        if self.cfg.get("mjpg", True):
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.ancho)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.alto)
        self.cap.set(cv2.CAP_PROP_FPS, int(self.cfg.get("fps", 30)))
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self.ok = self.cap.isOpened()
        if not self.ok:
            self.error = "no abre %s" % dev
        self.ctl = ControlesV4L2(dev)

    def _leer_uno(self):
        if self.tipo == "sim":
            time.sleep(1.0 / 20)
            proy = self.proyector.imagen_actual() if self.proyector is not None else None
            return self.escena.render(proy, self.ctl.factor())
        if self.tipo == "csi":
            img = self._src.Capture()
            if img is None:
                return None
            self._a_numpy[1]()
            return cv2.cvtColor(self._a_numpy[0](img), cv2.COLOR_RGB2BGR)
        ok, img = self.cap.read()
        return img if ok else None

    def _hilo(self):
        t0, n0 = time.time(), 0
        while self.vivo:
            img = self._leer_uno()
            if img is None:
                time.sleep(0.05)
                continue
            with self._lock:
                self.cuadro = img
                self.n += 1
                self.t_cuadro = time.time()
            n0 += 1
            if time.time() - t0 >= 1.0:
                self.fps_cap = n0 / (time.time() - t0)
                t0, n0 = time.time(), 0

    def iniciar(self):
        if not self.ok:
            log("camara:", self.error)
            return False
        self.vivo = True
        threading.Thread(target=self._hilo, daemon=True).start()
        return True

    def leer(self):
        with self._lock:
            return self.cuadro, self.n

    def esperar_nuevo(self, n_anterior, timeout=1.0):
        t = time.time()
        while time.time() - t < timeout:
            img, n = self.leer()
            if img is not None and n > n_anterior:
                return img, n
            time.sleep(0.005)
        return self.leer()

    def promedio(self, cuantos=3, espera=0.25):
        """Varios cuadros nuevos promediados (para calibrar, quita ruido). Espera a que el proyector cambie."""
        time.sleep(espera)
        _, n = self.leer()
        acc = None
        for _ in range(cuantos):
            img, n = self.esperar_nuevo(n)
            if img is None:
                continue
            f = img.astype(np.float32)
            acc = f if acc is None else acc + f
        return None if acc is None else (acc / cuantos).astype(np.uint8)

    def detener(self):
        self.vivo = False
        time.sleep(0.1)
        try:
            self.cap.release()
        except Exception:
            pass


# ====================================================================== filtros de software
class Filtros(object):
    """gamma, CLAHE, suavizado (kernel) y nitidez. Si todo esta en neutro no gasta nada."""

    def __init__(self, cfg):
        self.p = {"gamma": 1.0, "clahe": 0.0, "suavizado": 0, "nitidez": 0.0}
        self.p.update(cfg or {})
        self._lut_g = None
        self._clahe = None
        self._rehacer()

    def poner(self, k, v):
        if k not in self.p:
            return False
        if k == "suavizado":
            v = int(v)
            v = 0 if v < 3 else (v | 1)
            v = min(v, 15)
        else:
            v = float(v)
        self.p[k] = v
        self._rehacer()
        return True

    def _rehacer(self):
        g = float(self.p["gamma"])
        self._lut_g = None if abs(g - 1.0) < 0.01 else \
            np.array([((i / 255.0) ** (1.0 / g)) * 255 for i in range(256)], np.uint8)
        c = float(self.p["clahe"])
        self._clahe = cv2.createCLAHE(clipLimit=c, tileGridSize=(8, 8)) if c > 0.05 else None

    def aplicar(self, img):
        if self._lut_g is not None:
            img = cv2.LUT(img, self._lut_g)
        if self._clahe is not None:
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            lab[:, :, 0] = self._clahe.apply(lab[:, :, 0])
            img = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        k = int(self.p["suavizado"])
        if k >= 3:
            img = cv2.GaussianBlur(img, (k, k), 0)
        s = float(self.p["nitidez"])
        if s > 0.01:
            bl = cv2.GaussianBlur(img, (0, 0), 2.0)
            img = cv2.addWeighted(img, 1.0 + s, bl, -s, 0)
        return img


# ====================================================================== auto-ajuste
def _medir(cam, n=3):
    img = cam.promedio(n, espera=0.35)
    if img is None:
        return None, None, None
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = g.shape
    centro = g[h // 6:h - h // 6, w // 6:w - w // 6]
    return float(centro.mean()), float((g >= 250).mean()), float(centro.std())


def autoajuste(cam, filtros, objetivo=115, max_sat=0.01, aviso=log):
    """Ajusta exposicion y ganancia de la camara (si se puede) y luego gamma/CLAHE por software."""
    ctl = cam.ctl
    reporte = []
    nexp = None
    for n in ("exposure_absolute", "exposure_time_absolute"):
        if ctl and ctl.tiene(n):
            nexp = n
    if nexp:
        for n_auto, manual in (("exposure_auto", 1), ("auto_exposure", 1)):
            if ctl.tiene(n_auto):
                ctl.poner(n_auto, manual)
        lo, hi = ctl.rango(nexp)
        lo = max(lo, 1)
        a, b = math.log(lo), math.log(max(hi, lo + 1))
        mejor = None
        for it in range(9):
            e = int(math.exp((a + b) / 2))
            ctl.poner(nexp, e)
            m, sat, _ = _medir(cam)
            if m is None:
                break
            err = abs(m - objetivo) + (400 * (sat - max_sat) if sat > max_sat else 0)
            if mejor is None or err < mejor[0]:
                mejor = (err, e, m, sat)
            aviso("auto-ajuste: exp=%d brillo=%.0f saturados=%.1f%%" % (e, m, sat * 100))
            if abs(m - objetivo) < 6 and sat <= max_sat:
                break
            if m < objetivo and sat <= max_sat:
                a = math.log(e)
            else:
                b = math.log(e)
        if mejor:
            ctl.poner(nexp, mejor[1])
            reporte.append("exposicion=%d" % mejor[1])
            # sin luz suficiente con la exposicion maxima: subir ganancia
            if mejor[2] < objetivo - 20 and ctl.tiene("gain"):
                glo, ghi = ctl.rango("gain")
                for g in np.linspace(glo, ghi, 6)[1:]:
                    ctl.poner("gain", int(g))
                    m, sat, _ = _medir(cam)
                    if m is None or m >= objetivo - 8 or sat > max_sat:
                        break
                reporte.append("ganancia=%s" % ctl.leer("gain"))
    # balance de blancos: dejar que se acomode y fijarlo
    for n_auto, n_val in (("white_balance_temperature_auto", "white_balance_temperature"),
                          ("white_balance_automatic", "white_balance_temperature")):
        if ctl and ctl.tiene(n_auto) and ctl.tiene(n_val):
            ctl.poner(n_auto, 1)
            time.sleep(1.2)
            v = ctl.leer(n_val)
            ctl.poner(n_auto, 0)
            if v:
                ctl.poner(n_val, v)
                reporte.append("blancos=%d" % v)
            break
    # software: lo que la camara no alcanzo
    filtros.poner("gamma", 1.0)
    filtros.poner("clahe", 0.0)
    m, sat, std = _medir(cam)
    if m is not None:
        if abs(m - objetivo) > 15 and 5 < m < 250:
            gam = math.log(m / 255.0) / math.log(objetivo / 255.0)
            gam = max(0.6, min(1.8, gam))
            filtros.poner("gamma", round(gam, 2))
            reporte.append("gamma=%.2f" % gam)
        if std < 35:
            filtros.poner("clahe", 2.0)
            reporte.append("clahe=2.0 (poco contraste)")
        reporte.append("brillo=%.0f" % m)
    texto = "auto-ajuste listo: " + ", ".join(reporte) if reporte else "auto-ajuste: la camara no tiene controles"
    aviso(texto)
    return texto
