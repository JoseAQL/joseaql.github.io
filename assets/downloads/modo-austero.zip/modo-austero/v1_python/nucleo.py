# -*- coding: utf-8 -*-
"""
nucleo.py - El proceso de fondo del Modo Austero. Se arranca con `austero start` y se controla por
un socket local (/tmp/austero.sock) con `austero <comando>` o con el tablero (`austero ver`).

Nada visual corre si no lo pides: sin ventana, sin pagina web y sin vista. Lo unico que siempre corre es
camara -> filtros -> modelo activo (uno) -> salida al proyector (solo si cambia).
"""
from __future__ import print_function

import base64
import json
import os
import queue
import signal
import socket
import threading
import time
import traceback

import cv2
import numpy as np

import modelos as M
from calibracion import Calibracion, guardar_marcador_impreso
from camara import Camara, Filtros, autoajuste
from memoria import Memoria
from proyector import Proyector
from stats import Estadisticas, perfil_energia
from util import (ARCH_FILTROS, BASE, SOCKET, DIR_BENCH, cargar_config, cargar_json, fusionar, guardar_json,
                  log, ruta, ultimos_log)

COLORES = [(0, 220, 255), (80, 255, 80), (255, 160, 60), (255, 80, 200), (60, 120, 255), (200, 255, 255)]


def color_de(nombre):
    return COLORES[sum(ord(ch) for ch in str(nombre)) % len(COLORES)]


class Nucleo(object):
    def __init__(self):
        self.cfg = cargar_config()
        self.vivo = True
        self.cola = queue.Queue()
        sim = self.cfg["camara"].get("tipo") == "sim"
        self.cam = Camara(self.cfg["camara"])
        self.proy = Proyector(self.cfg["proyector"], simulado=sim or self.cfg["proyector"].get("simulado", False))
        self.cam.proyector = self.proy
        self.filtros = Filtros(fusionar(dict(self.cfg.get("filtros", {})), cargar_json(ARCH_FILTROS, {}) or {}))
        self.stats = Estadisticas()
        self.calib = Calibracion(self.cam, self.proy, self.cfg["calibracion"])
        self.memoria = Memoria()
        self.ancho_proc = int(self.cfg["camara"].get("ancho_proceso", 640))
        self.escala = self.cam.ancho / float(self.ancho_proc)
        self.alto_proc = int(round(self.cam.alto / self.escala))
        # estado
        self.fondo = None
        self.mascara_proy = None
        self.modelo = None
        self.manos = None
        self.manos_res = []
        self.dets = []
        self.buscar = False
        self.mostrar_en_proyector = True
        self.ensenando = None        # {"clase", "sombra": {x,y,w,h}, "propuesta": bool}
        self.fps = 0.0
        self.lat_ms = 0.0
        self.lat_hist = []
        self.t_vista = 0
        self.vista_tam = (80, 40)
        self.vista_buf = None
        self.anotada = None
        self.t_anotada_pedida = 0
        self.web = None
        self.ocupado = ""
        self.t_verif = time.time()
        self.ultimo_proc = None
        self._proy_version = None

    # ================================================================ arranque / fin
    def iniciar(self):
        log("Modo Austero iniciando (camara %s %dx%d, proceso %dx%d)" % (
            self.cam.tipo, self.cam.ancho, self.cam.alto, self.ancho_proc, self.alto_proc))
        self.stats.iniciar()
        if not self.cam.iniciar():
            log("sin camara; el nucleo sigue para que puedas revisar con 'austero status'")
        self._servidor()
        if self.cfg["proyector"].get("habilitado", True):
            self.proy.encender()
        self.cam.esperar_nuevo(0, 3.0)
        if self.cfg["autoajuste"].get("al_iniciar"):
            self.cmd_autoajuste({})
        if self.proy.encendido and self.cfg["calibracion"].get("automatica_al_iniciar", True):
            self.cmd_calibrar({"metodo": self.cfg["calibracion"].get("metodo", "aruco")})
        ini = self.cfg.get("inicio", {})
        if ini.get("modelo"):
            self.cmd_modelo({"id": ini["modelo"]})
        if ini.get("manos"):
            self.cmd_manos({"on": True})
        if ini.get("web"):
            self.cmd_web({"on": True})
        self.buscar = bool(ini.get("buscar", False))
        if not os.path.exists(ruta("perfiles", "marcador_mm.png")):
            try:
                guardar_marcador_impreso(ruta("perfiles", "marcador_mm.png"),
                                         lado_mm=int(self.cfg["calibracion"]["marcador_mm"].get("lado_mm", 50)))
            except Exception:
                pass

    def cerrar(self):
        log("apagando...")
        self.vivo = False
        try:
            if self.modelo:
                self.modelo.liberar()
            if self.manos:
                self.manos.liberar()
        except Exception:
            pass
        if self.web:
            self.web.detener()
        self.proy.apagar()
        self.cam.detener()
        self.stats.detener()
        try:
            os.unlink(SOCKET)
        except Exception:
            pass

    # ================================================================ socket de control
    def _servidor(self):
        try:
            os.unlink(SOCKET)
        except Exception:
            pass
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.bind(SOCKET)
        os.chmod(SOCKET, 0o660)
        s.listen(8)

        def atender(c):
            try:
                datos = b""
                while not datos.endswith(b"\n"):
                    p = c.recv(65536)
                    if not p:
                        break
                    datos += p
                msg = json.loads(datos.decode("utf-8") or "{}")
                resp = self.atender(msg)
                c.sendall((json.dumps(resp, ensure_ascii=False, default=_json_np) + "\n").encode("utf-8"))
            except Exception as e:
                try:
                    c.sendall((json.dumps({"ok": False, "msg": str(e)}) + "\n").encode())
                except Exception:
                    pass
            finally:
                c.close()

        def bucle():
            while self.vivo:
                try:
                    c, _ = s.accept()
                    threading.Thread(target=atender, args=(c,), daemon=True).start()
                except Exception:
                    time.sleep(0.1)
        threading.Thread(target=bucle, daemon=True).start()

    def atender(self, msg):
        """Comandos de solo lectura se responden aqui; los demas van a la cola del lazo principal."""
        cmd = msg.get("cmd", "estado")
        if cmd == "estado":
            return {"ok": True, "estado": self.estado()}
        if cmd == "log":
            return {"ok": True, "log": ultimos_log(int(msg.get("n", 20)))}
        if cmd == "vista":
            self.t_vista = time.time()
            self.vista_tam = (int(msg.get("w", 80)), int(msg.get("h", 40)))
            b = self.vista_buf
            if b is None:
                return {"ok": True, "vista": None}
            return {"ok": True, "vista": {"w": b.shape[1], "h": b.shape[0],
                                          "bgr": base64.b64encode(b.tobytes()).decode("ascii")}}
        ev = threading.Event()
        caja = {}
        self.cola.put((msg, ev, caja))
        ev.wait(timeout=float(msg.get("timeout", 600)))
        return caja.get("r", {"ok": False, "msg": "sin respuesta (ocupado: %s)" % self.ocupado})

    def _procesar_cola(self):
        while True:
            try:
                msg, ev, caja = self.cola.get_nowait()
            except queue.Empty:
                return
            cmd = msg.get("cmd", "")
            f = getattr(self, "cmd_" + cmd, None)
            try:
                if f is None:
                    r = {"ok": False, "msg": "comando desconocido: %s" % cmd}
                else:
                    self.ocupado = cmd
                    r = f(msg) or {"ok": True}
            except Exception as e:
                traceback.print_exc()
                r = {"ok": False, "msg": "%s: %s" % (cmd, e)}
            self.ocupado = ""
            if "msg" in r and r["msg"]:
                log(r["msg"])
            caja["r"] = r
            ev.set()

    # ================================================================ estado
    def estado(self):
        st = self.stats.foto()
        m = self.modelo
        return {
            "fps": round(self.fps, 1), "lat_ms": round(self.lat_ms, 1),
            "lat_p95": round(float(np.percentile(self.lat_hist, 95)), 1) if self.lat_hist else 0,
            "fps_camara": round(self.cam.fps_cap, 1), "camara_ok": self.cam.ok,
            "modelo": m.id if m else None, "modelo_nombre": m.nombre if m else "ninguno",
            "motor": m.motor if m else "", "params": m.p if m else {}, "modelo_error": (m.error if m else ""),
            "filtros": self.filtros.p, "manos": bool(self.manos and self.manos.ok), "n_manos": len(self.manos_res),
            "web": self.web.url if self.web else None, "proyector": self.proy.encendido,
            "buscar": self.buscar, "fondo": self.fondo is not None,
            "calib": {"lista": self.calib.lista, "metodo": self.calib.metodo, "error_px": self.calib.error_px,
                      "px_por_mm": self.calib.px_por_mm},
            "ensenando": ({"clase": self.ensenando["clase"], "sombra": self.ensenando["sombra"],
                           "propuesta": self.ensenando.get("propuesta", False)} if self.ensenando else None),
            "memoria": self.memoria.resumen(),
            "dets": [{"clase": str(d["clase"]), "conf": round(float(d["conf"]), 2), "caja": [int(v) for v in d["caja"]],
                      "angulo": (float(d["angulo"]) if d.get("angulo") is not None else None)}
                     for d in self.dets[:12]],
            "stats": st, "ocupado": self.ocupado, "log": ultimos_log(6),
            "catalogo": [{"tecla": str(i + 1), "id": c.id, "nombre": c.nombre}
                         for i, c in enumerate(M.CATALOGO)],
        }

    # ================================================================ lazo principal
    def correr(self):
        """El lazo nunca se cae por un error: lo registra y sigue."""
        while self.vivo:
            try:
                self._correr()
            except Exception as e:
                traceback.print_exc()
                log("error en el lazo: %s (sigo)" % e)
                time.sleep(0.5)

    def _correr(self):
        n_prev, t0, cuenta = 0, time.time(), 0
        fps_max = float(self.cfg["camara"].get("fps_max", 0) or 0)
        while self.vivo:
            self._procesar_cola()
            if not self.cam.vivo:
                time.sleep(0.1)
                self.proy.actualizar()
                continue
            img, n = self.cam.esperar_nuevo(n_prev, 0.5)
            if img is None or n == n_prev:
                self.proy.actualizar()
                continue
            n_prev = n
            ti = time.time()
            proc = cv2.resize(img, (self.ancho_proc, self.alto_proc), interpolation=cv2.INTER_AREA)
            proc = self.filtros.aplicar(proc)
            self.ultimo_proc = proc
            self._actualizar_mascara()
            dets = []
            if self.modelo is not None and self.modelo.ok:
                try:
                    dets = self.modelo.procesar(proc)
                except Exception as e:
                    log("modelo %s fallo: %s" % (self.modelo.id, e))
                    traceback.print_exc()
                    self.modelo.ok = False
            if self.buscar and (self.modelo is None or self.modelo.id != "ejemplos") and self.memoria.ejemplos:
                dets = dets + self.memoria.buscar(proc, self.fondo, self.mascara_proy)
            self.dets = dets
            if self.manos is not None and self.manos.ok:
                try:
                    self.manos_res = self.manos.procesar(proc)
                except Exception as e:
                    log("manos fallo: %s" % e)
                    self.manos.ok = False
            lat = (time.time() - ti) * 1000.0
            self.lat_ms = 0.8 * self.lat_ms + 0.2 * lat if self.lat_ms else lat
            self.lat_hist.append(lat)
            del self.lat_hist[:-120]
            self._salida_proyector()
            self._salidas_visuales(proc)
            self.proy.actualizar()
            cuenta += 1
            if time.time() - t0 >= 1.0:
                self.fps = cuenta / (time.time() - t0)
                t0, cuenta = time.time(), 0
            self._verificacion_periodica()
            if fps_max > 0:
                resto = 1.0 / fps_max - (time.time() - ti)
                if resto > 0:
                    time.sleep(resto)

    def _actualizar_mascara(self):
        """Zona de la camara donde el proyector esta pintando algo: se ignora al buscar piezas."""
        if not (self.proy.encendido and self.calib.lista):
            self.mascara_proy = None
            return
        img = self.proy.imagen_actual()
        ver = id(img)
        if ver == self._proy_version:
            return
        self._proy_version = ver
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        if g.max() < 10:
            self.mascara_proy = None
            return
        S = np.diag([1.0 / self.escala, 1.0 / self.escala, 1.0])
        Hp = S.dot(self.calib.H_p2c)
        m = cv2.warpPerspective((g > 10).astype(np.uint8) * 255, Hp, (self.ancho_proc, self.alto_proc),
                                flags=cv2.INTER_NEAREST)
        self.mascara_proy = cv2.dilate(m, np.ones((9, 9), np.uint8))

    def _salida_proyector(self):
        if not (self.proy.encendido and self.calib.lista):
            return
        if self.ensenando:
            s = dict(self.ensenando["sombra"])
            s["texto"] = ("? %s  (Enter = si)" if self.ensenando.get("propuesta") else "%s") % self.ensenando["clase"]
            self.proy.poner_sombra(s)
        else:
            self.proy.poner_sombra(None)
        marcas = []
        if self.mostrar_en_proyector:
            for d in self.dets[:12]:
                if "contorno" in d and d["contorno"] is not None:
                    pts = d["contorno"].reshape(-1, 2)
                    if len(pts) > 40:
                        pts = pts[::max(1, len(pts) // 40)]
                else:
                    x1, y1, x2, y2 = d["caja"]
                    pts = np.float32([[x1, y1], [x2, y1], [x2, y2], [x1, y2]])
                pp = self.calib.cam_a_proy(pts, self.escala)
                # redondear a 4 px para no redibujar el proyector por ruido de 1 pixel
                pp = (np.round(pp / 4.0) * 4).astype(np.int32)
                txt = "%s %.0f%%" % (d["clase"], d["conf"] * 100) if d["conf"] < 0.999 else d["clase"]
                marcas.append((pp, color_de(d["clase"]), txt))
        self.proy.poner_marcas(marcas)

    def anotar(self, img):
        out = img.copy()
        for d in self.dets:
            col = color_de(d["clase"])
            x1, y1, x2, y2 = [int(v) for v in d["caja"]]
            if d.get("contorno") is not None:
                cv2.drawContours(out, [d["contorno"]], -1, col, 2)
            else:
                cv2.rectangle(out, (x1, y1), (x2, y2), col, 2)
            t = d["clase"] + ("" if d["conf"] >= 0.999 else " %.0f%%" % (d["conf"] * 100))
            cv2.putText(out, t, (x1, max(12, y1 - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, col, 1)
        for mano in self.manos_res:
            for p in mano["puntos"]:
                if p:
                    cv2.circle(out, p, 3, (0, 255, 0), -1)
        if self.ensenando:
            s = self.ensenando["sombra"]
            if self.calib.lista:
                pts = np.float32([[s["x"], s["y"]], [s["x"] + s["w"], s["y"]],
                                  [s["x"] + s["w"], s["y"] + s["h"]], [s["x"], s["y"] + s["h"]]])
                pc = self.calib.proy_a_cam(pts, self.escala).astype(np.int32)
            else:
                pc = np.int32([[s["x"], s["y"]], [s["x"] + s["w"], s["y"]],
                               [s["x"] + s["w"], s["y"] + s["h"]], [s["x"], s["y"] + s["h"]]])
            cv2.polylines(out, [pc.reshape(-1, 1, 2)], True, (0, 220, 255), 2)
        return out

    def _salidas_visuales(self, proc):
        """Solo se dibuja si alguien esta mirando (vista de terminal o pagina web)."""
        ahora = time.time()
        quiere_vista = ahora - self.t_vista < 3.0
        quiere_web = self.web is not None and ahora - self.t_anotada_pedida < 3.0
        if not (quiere_vista or quiere_web):
            return
        an = self.anotar(proc)
        if quiere_web:
            self.anotada = an
        if quiere_vista:
            w, h = self.vista_tam
            self.vista_buf = cv2.resize(an, (max(8, w), max(8, h * 2)), interpolation=cv2.INTER_AREA)

    def _verificacion_periodica(self):
        cada = float(self.cfg["calibracion"].get("verificar_cada_s", 0) or 0)
        if cada <= 0 or not (self.proy.encendido and self.calib.lista) or self.ensenando:
            return
        if time.time() - self.t_verif < cada:
            return
        self.t_verif = time.time()
        e = self.calib.verificar()
        tol = float(self.cfg["calibracion"].get("tolerancia_px", 8))
        if e is not None and e > tol and self.cfg["calibracion"].get("recalibrar_si_falla", True):
            log("la camara o el proyector se movieron (%.1f px): recalibrando..." % e)
            self.cmd_calibrar({"metodo": self.cfg["calibracion"].get("metodo", "aruco")})

    # ================================================================ comandos
    def cmd_apagar(self, msg):
        self.vivo = False
        return {"ok": True, "msg": "apagado"}

    def cmd_modelo(self, msg):
        id_ = str(msg.get("id", ""))
        id_ = M.POR_TECLA.get(id_, id_)
        if self.modelo is not None:
            self.modelo.liberar()
            self.modelo = None
        if id_ in ("", "0", "ninguno"):
            return {"ok": True, "msg": "sin modelo (solo camara)"}
        C = M.clase_por_id(id_)
        if C is None:
            return {"ok": False, "msg": "no existe el modelo '%s'" % id_}
        m = C(self)
        guardado = cargar_json(ruta("perfiles", "params_%s.json" % C.id), {}) or {}
        for k, v in guardado.items():
            m.poner(k, v)
        ok, por_que = m.disponible()
        if not ok:
            return {"ok": False, "msg": "%s no disponible: %s" % (C.id, por_que)}
        t = time.time()
        if not m.cargar():
            return {"ok": False, "msg": "%s no cargo: %s" % (C.id, m.error)}
        self.modelo = m
        if C.id in ("fondo", "orientacion", "ejemplos") and self.fondo is None:
            self.cmd_fondo({})
        return {"ok": True, "msg": "modelo %s listo en %.1f s (%s)" % (C.id, time.time() - t, m.motor or "CPU")}

    def cmd_param(self, msg):
        """Mover en vivo umbral, nms, entrada (tamano YOLO), area_min, dif..."""
        if self.modelo is None:
            return {"ok": False, "msg": "no hay modelo activo"}
        k, v = msg.get("k"), msg.get("v")
        if msg.get("delta") is not None and k in self.modelo.p:
            v = self.modelo.p[k] + type(self.modelo.p[k])(msg["delta"])
            if k == "entrada":
                t = getattr(self.modelo, "tamanos", lambda: [])()
                if t:
                    i = t.index(self.modelo.p[k]) if self.modelo.p[k] in t else 0
                    i = max(0, min(len(t) - 1, i + (1 if float(msg["delta"]) > 0 else -1)))
                    v = t[i]
            if k in ("umbral", "nms") and isinstance(v, float) and v <= 1.0:
                v = max(0.01, min(0.99, v))
        if not self.modelo.poner(k, v):
            return {"ok": False, "msg": "parametro '%s' no existe en %s (hay: %s)" % (k, self.modelo.id,
                                                                                   ", ".join(self.modelo.p))}
        guardar_json(ruta("perfiles", "params_%s.json" % self.modelo.id), self.modelo.p)
        return {"ok": True, "msg": "%s.%s = %s" % (self.modelo.id, k, self.modelo.p[k])}

    def cmd_filtro(self, msg):
        k = msg.get("k")
        v = msg.get("v")
        if msg.get("delta") is not None and k in self.filtros.p:
            v = self.filtros.p[k] + float(msg["delta"])
            if k == "suavizado":
                v = self.filtros.p[k] + (2 if float(msg["delta"]) > 0 else -2)
                if v == 1:
                    v = 3 if float(msg["delta"]) > 0 else 0
            v = max(0.0, v)
        if not self.filtros.poner(k, v):
            return {"ok": False, "msg": "filtros: gamma, clahe, suavizado (kernel), nitidez"}
        guardar_json(ARCH_FILTROS, self.filtros.p)
        return {"ok": True, "msg": "filtro %s = %s" % (k, self.filtros.p[k])}

    def cmd_autoajuste(self, msg):
        t = autoajuste(self.cam, self.filtros, self.cfg["autoajuste"].get("brillo_objetivo", 115),
                       self.cfg["autoajuste"].get("max_saturados", 0.01))
        guardar_json(ARCH_FILTROS, self.filtros.p)
        return {"ok": True, "msg": t}

    def cmd_calibrar(self, msg):
        metodo = msg.get("metodo") or self.cfg["calibracion"].get("metodo", "aruco")
        ok = self.calib.calibrar(metodo)
        self._proy_version = None
        return {"ok": ok, "msg": "calibracion %s: %s" % (metodo, "lista" if ok else "fallo")}

    def cmd_verificar(self, msg):
        e = self.calib.verificar()
        return {"ok": e is not None, "msg": "error %.1f px" % e if e is not None else "no se pudo verificar"}

    def cmd_mm(self, msg):
        ok = self.calib.medir_mm()
        if ok:
            self.calib.guardar()
        return {"ok": ok}

    def cmd_proyector(self, msg):
        on = _on(msg, not self.proy.encendido)
        if on:
            ok = self.proy.encender()
            return {"ok": ok, "msg": "proyector encendido" if ok else "no pude abrir el proyector"}
        self.proy.apagar()
        return {"ok": True, "msg": "proyector apagado"}

    def cmd_marcas(self, msg):
        self.mostrar_en_proyector = _on(msg, not self.mostrar_en_proyector)
        return {"ok": True, "msg": "marcas en proyector: %s" % self.mostrar_en_proyector}

    def cmd_manos(self, msg):
        on = _on(msg, not (self.manos and self.manos.ok))
        if self.manos:
            self.manos.liberar()
            self.manos = None
            self.manos_res = []
        if not on:
            return {"ok": True, "msg": "manos apagadas"}
        m = M.Manos()
        if not m.cargar():
            return {"ok": False, "msg": "manos: %s" % m.error}
        self.manos = m
        return {"ok": True, "msg": "manos encendidas (%s)" % m.motor}

    def cmd_web(self, msg):
        on = _on(msg, self.web is None)
        if not on:
            if self.web:
                self.web.detener()
                self.web = None
            return {"ok": True, "msg": "pagina web apagada"}
        if self.web:
            return {"ok": True, "msg": "web ya estaba en %s" % self.web.url}
        import web
        self.web = web.ServidorWeb(self, int(self.cfg["web"].get("puerto", 8091)))
        self.web.iniciar()
        return {"ok": True, "msg": "pagina web en %s" % self.web.url}

    def cmd_buscar(self, msg):
        self.buscar = _on(msg, not self.buscar)
        if self.buscar and self.fondo is None:
            self.cmd_fondo({})
        return {"ok": True, "msg": "buscar piezas ensenadas: %s" % self.buscar}

    def cmd_fondo(self, msg):
        """Foto de la mesa VACIA (con el proyector en negro). La resta de fondo y el modo ensenar la usan."""
        prev = self.proy.patron
        if self.proy.encendido:
            self.proy.poner_patron(np.zeros((self.proy.h, self.proy.w), np.uint8))
        img = self.cam.promedio(4, 0.35)
        if self.proy.encendido:
            self.proy.poner_patron(prev)
        if img is None:
            return {"ok": False, "msg": "sin imagen para el fondo"}
        p = cv2.resize(img, (self.ancho_proc, self.alto_proc), interpolation=cv2.INTER_AREA)
        self.fondo = self.filtros.aplicar(p)
        cv2.imwrite(ruta("perfiles", "fondo.jpg"), self.fondo)
        return {"ok": True, "msg": "fondo guardado (deja la mesa vacia cuando lo tomes)"}

    # ---------------------------------------------------------------- ensenar
    def cmd_ensenar(self, msg):
        acc = msg.get("accion", "inicio")
        if acc == "inicio":
            clase = (msg.get("clase") or "").strip()
            if not clase:
                return {"ok": False, "msg": "dime el nombre: austero ensenar \"tijera mayo\""}
            if self.calib.lista:
                W, H = self.proy.w, self.proy.h
                s = {"x": W // 2 - 180, "y": H // 2 - 120, "w": 360, "h": 240}
            else:
                s = {"x": self.ancho_proc // 2 - 80, "y": self.alto_proc // 2 - 50, "w": 160, "h": 100}
            self.ensenando = {"clase": clase, "sombra": s}
            if self.fondo is None:
                self.cmd_fondo({})
            return {"ok": True, "msg": "ensenando '%s': mueve la sombra con las flechas, +/- tamano, "
                                       "Enter guarda, x = que la camara la proponga" % clase}
        if not self.ensenando:
            return {"ok": False, "msg": "primero: ensenar inicio <clase>"}
        s = self.ensenando["sombra"]
        paso = 40 if self.calib.lista else 10
        if acc == "mover":
            s["x"] += int(float(msg.get("dx", 0)) * paso)
            s["y"] += int(float(msg.get("dy", 0)) * paso)
            self.ensenando["propuesta"] = False
            return {"ok": True}
        if acc == "tam":
            dw, dh = int(float(msg.get("dw", 0)) * paso), int(float(msg.get("dh", 0)) * paso)
            s["x"] -= dw // 2
            s["y"] -= dh // 2
            s["w"] = max(paso, s["w"] + dw)
            s["h"] = max(paso, s["h"] + dh)
            return {"ok": True}
        if acc == "auto":
            return self._auto_sombra()
        if acc == "cancelar":
            self.ensenando = None
            self.proy.poner_sombra(None)
            return {"ok": True, "msg": "ensenar cancelado"}
        if acc == "guardar":
            img = self.ultimo_proc
            if img is None:
                return {"ok": False, "msg": "sin imagen"}
            caja = self._sombra_en_cam()
            ej, txt = self.memoria.ensenar(img, caja, self.ensenando["clase"], self.fondo, self.mascara_proy,
                                           (1.0 / self.calib.px_por_mm * self.escala) if self.calib.px_por_mm else None)
            self.ensenando["propuesta"] = False
            if ej:
                self.dets = [{"clase": self.ensenando["clase"], "conf": 1.0, "caja": ej["caja"],
                              "contorno": ej["contorno"]}]
            return {"ok": ej is not None, "msg": txt}
        return {"ok": False, "msg": "acciones: inicio, mover, tam, auto, guardar, cancelar"}

    def _sombra_en_cam(self):
        s = self.ensenando["sombra"]
        if not self.calib.lista:
            return [s["x"], s["y"], s["x"] + s["w"], s["y"] + s["h"]]
        pts = np.float32([[s["x"], s["y"]], [s["x"] + s["w"], s["y"]],
                          [s["x"] + s["w"], s["y"] + s["h"]], [s["x"], s["y"] + s["h"]]])
        pc = self.calib.proy_a_cam(pts, self.escala)
        x1, y1 = pc.min(0)
        x2, y2 = pc.max(0)
        return [int(x1), int(y1), int(x2), int(y2)]

    def _auto_sombra(self):
        """La camara propone: el objeto nuevo mas grande sobre la mesa."""
        img = self.ultimo_proc
        cands = self.memoria.candidatos(img, self.fondo, self.mascara_proy)
        if not cands:
            return {"ok": False, "msg": "no veo nada nuevo sobre la mesa (toma el fondo vacio con 'f')"}
        c = max(cands, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(c)
        m = 12
        x, y, w, h = x - m, y - m, w + 2 * m, h + 2 * m
        if self.calib.lista:
            pp = self.calib.cam_a_proy(np.float32([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]), self.escala)
            x1, y1 = pp.min(0)
            x2, y2 = pp.max(0)
            self.ensenando["sombra"] = {"x": int(x1), "y": int(y1), "w": int(x2 - x1), "h": int(y2 - y1)}
        else:
            self.ensenando["sombra"] = {"x": x, "y": y, "w": w, "h": h}
        self.ensenando["propuesta"] = True
        return {"ok": True, "msg": "propuesta: ¿es ahi? Enter = guardar, flechas = corregir"}

    def cmd_confirmar(self, msg):
        if self.ultimo_proc is None:
            return {"ok": False}
        n = self.memoria.confirmar_detecciones(self.ultimo_proc, self.dets)
        return {"ok": True, "msg": "foto + %d etiquetas guardadas en dataset/" % n}

    def cmd_olvidar(self, msg):
        ok = self.memoria.borrar_clase(msg.get("clase", ""))
        return {"ok": ok, "msg": "olvidada" if ok else "no existe esa clase"}

    # ---------------------------------------------------------------- otros
    def cmd_perfil(self, msg):
        return {"ok": True, "msg": perfil_energia(msg.get("nombre", ""))}

    def cmd_foto(self, msg):
        img, _ = self.cam.leer()
        if img is None:
            return {"ok": False, "msg": "sin imagen"}
        a = ruta("perfiles", time.strftime("foto_%Y%m%d_%H%M%S.jpg"))
        cv2.imwrite(a, self.anotar(self.ultimo_proc) if self.ultimo_proc is not None else img)
        return {"ok": True, "msg": "foto: %s" % os.path.relpath(a, BASE)}

    def cmd_bench(self, msg):
        import bench
        return bench.correr(self, msg.get("modelos") or [], float(msg.get("seg") or
                                                                 self.cfg["bench"]["segundos_por_modelo"]))

    def cmd_sim(self, msg):
        if self.cam.escena is None:
            return {"ok": False, "msg": "solo con camara simulada"}
        acc = msg.get("accion", "revolver")
        if acc == "revolver":
            self.cam.escena.revolver(int(msg.get("n", 3)))
        elif acc == "pieza":     # una sola pieza de un tipo en un lugar al azar (pruebas)
            rs = np.random
            self.cam.escena.objetos = [{"tipo": msg.get("tipo", "tijera"), "x": rs.uniform(0.3, 0.7) * self.cam.ancho,
                                        "y": rs.uniform(0.35, 0.65) * self.cam.alto, "ang": rs.uniform(0, 180)}]
        elif acc == "vaciar":
            self.cam.escena.objetos = []
        elif acc == "marcador":
            from calibracion import dibujar_marcador
            lado = int(50 / self.cam.escena.mm_por_px)
            self.cam.escena.marcador = (cv2.cvtColor(dibujar_marcador(49, lado), cv2.COLOR_GRAY2BGR), (60, 60))
        elif acc == "mover_proyector":
            self.cam.escena.esq_proy_en_cam += np.float32(msg.get("d", [6, 4]))
        return {"ok": True, "msg": "sim %s" % acc}


def _json_np(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


def _on(msg, defecto):
    v = msg.get("on")
    if v is None:
        return defecto
    if isinstance(v, str):
        return v.lower() in ("1", "on", "si", "sí", "true", "encender", "prender")
    return bool(v)


def main():
    n = Nucleo()
    signal.signal(signal.SIGTERM, lambda *a: setattr(n, "vivo", False))
    signal.signal(signal.SIGINT, lambda *a: setattr(n, "vivo", False))
    try:
        n.iniciar()
        n.correr()
    finally:
        n.cerrar()


if __name__ == "__main__":
    main()
