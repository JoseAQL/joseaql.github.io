# -*- coding: utf-8 -*-
"""Cosas comunes: rutas, configuracion, registro. Compatible con Python 3.6 (JetPack 4.6)."""
from __future__ import print_function

import json
import os
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
SOCKET = os.environ.get("AUSTERO_SOCKET", "/tmp/austero.sock")
ARCH_CONFIG = os.path.join(BASE, "config.json")
ARCH_CALIB = os.path.join(BASE, "perfiles", "calibracion.json")
ARCH_FILTROS = os.path.join(BASE, "perfiles", "filtros.json")
DIR_MEMORIA = os.path.join(BASE, "memoria")
DIR_DATASET = os.path.join(BASE, "dataset")
DIR_BENCH = os.path.join(BASE, "bench")
DIR_MODELOS = os.path.join(BASE, "modelos")


def ruta(*partes):
    return os.path.join(BASE, *partes)


def fusionar(base, extra):
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            fusionar(base[k], v)
        else:
            base[k] = v
    return base


def cargar_json(arch, defecto=None):
    try:
        with open(arch) as f:
            return json.load(f)
    except Exception:
        return defecto


def guardar_json(arch, datos):
    d = os.path.dirname(arch)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    tmp = arch + ".tmp"
    with open(tmp, "w") as f:
        json.dump(datos, f, indent=1, ensure_ascii=False)
    os.rename(tmp, arch)


def cargar_config():
    cfg = cargar_json(ARCH_CONFIG, {}) or {}
    local = cargar_json(ruta("config_local.json"), {}) or {}   # tus cambios (no se pisan al actualizar)
    cfg = fusionar(cfg, local)
    if os.environ.get("AUSTERO_SIM") == "1":   # austero start --sim: camara y proyector simulados
        cfg["camara"]["tipo"] = "sim"
        cfg["proyector"]["simulado"] = True
    return cfg


_REG = []


def log(*args):
    msg = time.strftime("%H:%M:%S ") + " ".join(str(a) for a in args)
    _REG.append(msg)
    del _REG[:-200]
    print(msg)
    sys.stdout.flush()


def ultimos_log(n=8):
    return _REG[-n:]


def en_jetson():
    try:
        return "tegra" in open("/proc/device-tree/compatible").read() or os.path.exists("/etc/nv_tegra_release")
    except Exception:
        return os.path.exists("/etc/nv_tegra_release")


def preparar_display(display=":0"):
    """Para abrir la ventana del proyector en el HDMI aunque el programa se lance por SSH."""
    if not os.environ.get("DISPLAY"):
        os.environ["DISPLAY"] = display
    if not os.environ.get("XAUTHORITY"):
        xa = os.path.expanduser("~/.Xauthority")
        if os.path.exists(xa):
            os.environ["XAUTHORITY"] = xa
