// calibracion.hpp - proyector <-> camara (homografia de la mesa) y escala en milimetros.
//   aruco    (por defecto) 18 marcadores con ID, una foto, aguanta que tapes algunos
//   puntos   rejilla 10x6 de circulos (el primero mas grande marca la orientacion)
//   esquinas 4 puntos uno por uno (respaldo, el mas simple)
//   graycode franjas binarias, mapa pixel a pixel (el mas preciso y lento)
// verificar(): lazo cerrado, proyecta puntos al azar y mide el error en pixeles.
#pragma once

#include <functional>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "camara.hpp"
#include "proyector.hpp"

class Calibracion {
public:
    Calibracion(Camara& cam, Proyector& proy, const json& cfg);
    bool lista() const { return !H_c2p.empty(); }
    bool calibrar(const std::string& metodo);
    double verificar(int n = 3);      // -1 si no se pudo
    bool medir_mm();
    void guardar();
    bool cargar();

    // pts en la imagen de proceso; escala = ancho_camara / ancho_proceso
    std::vector<cv::Point2f> cam_a_proy(const std::vector<cv::Point2f>& pts, double escala) const;
    std::vector<cv::Point2f> proy_a_cam(const std::vector<cv::Point2f>& pts, double escala) const;

    cv::Mat H_c2p, H_p2c, H_c2mm;   // CV_64F 3x3
    double px_por_mm = 0, error_px = -1, t = 0;
    std::string metodo;
    json cfg;

private:
    Camara& cam_;
    Proyector& proy_;
    cv::Mat foto(const cv::Mat& patron, int n = 2, double espera = 0.35);
    cv::Mat negro();
    bool ajustar(const std::vector<cv::Point2f>& cam, const std::vector<cv::Point2f>& pro, bool ransac, cv::Mat& H,
                 double& err, int& n);
    bool m_aruco(cv::Mat& H, double& err, int& n);
    bool m_puntos(cv::Mat& H, double& err, int& n);
    bool m_esquinas(cv::Mat& H, double& err, int& n);
    bool m_graycode(cv::Mat& H, double& err, int& n);
};

cv::Mat dibujar_marcador(int id, int lado);
void detectar_marcadores(const cv::Mat& gris, std::vector<std::vector<cv::Point2f>>& esq, std::vector<int>& ids);
void guardar_marcador_impreso(const std::string& png, int id, int lado_mm, int dpi = 300);
