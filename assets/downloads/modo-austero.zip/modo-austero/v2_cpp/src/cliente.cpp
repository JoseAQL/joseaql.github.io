// cliente.cpp - austero-cli: manda comandos al nucleo y tiene el tablero de terminal (austero ver).
// Funciona por SSH/Tailscale. Salir del tablero (q) NO apaga el nucleo; Q si lo apaga.
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <termios.h>
#include <unistd.h>

#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <mutex>
#include <sstream>
#include <thread>

#include "util.hpp"

using util::fmt;

// ====================================================================== socket
static json enviar(const json& msg, double timeout = 900) {
    int s = socket(AF_UNIX, SOCK_STREAM, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, util::socket_path().c_str(), sizeof(a.sun_path) - 1);
    if (connect(s, (sockaddr*)&a, sizeof a) != 0) {
        close(s);
        throw std::runtime_error("el nucleo no esta corriendo (austero start)");
    }
    timeval tv{(long)timeout, 0};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    std::string d = msg.dump() + "\n";
    send(s, d.data(), d.size(), MSG_NOSIGNAL);
    std::string r;
    char buf[1 << 16];
    while (r.empty() || r.back() != '\n') {
        ssize_t k = recv(s, buf, sizeof buf, 0);
        if (k <= 0) break;
        r.append(buf, k);
    }
    close(s);
    if (r.empty()) throw std::runtime_error("sin respuesta del nucleo");
    return json::parse(r);
}

// ====================================================================== texto
static const char* E = "\x1b[";
static std::string col(int c) { return fmt("\x1b[38;5;%dm", c); }
static const std::string RESET = "\x1b[0m", NEG = "\x1b[1m", TEN = "\x1b[2m";
static const std::string VERDE = col(82), AMAR = col(220), ROJO = col(196), CIAN = col(45), GRIS = col(244), MAG = col(207);

static std::string barra(double p, int ancho = 12) {
    if (p < 0) return GRIS + std::string(ancho, '.') + RESET;
    p = std::max(0.0, std::min(100.0, p));
    int n = (int)std::round(p / 100 * ancho);
    std::string c = p < 60 ? VERDE : (p < 85 ? AMAR : ROJO), s = c;
    for (int i = 0; i < n; i++) s += "█";
    s += GRIS;
    for (int i = n; i < ancho; i++) s += "░";
    return s + RESET;
}
static std::string onoff(bool v) { return v ? VERDE + "on" + RESET : GRIS + "off" + RESET; }
static double num(const json& j, const char* k, double d = -1) {
    return j.contains(k) && j[k].is_number() ? j[k].get<double>() : d;
}
static std::string kv(const json& o) {
    std::string s;
    for (auto it = o.begin(); it != o.end(); ++it)
        s += it.key() + "=" + (it.value().is_number_float() ? fmt("%g", it.value().get<double>()) : it.value().dump()) + "  ";
    return s;
}

static std::string resumen(const json& e) {
    json s = e.value("stats", json::object()), c = e.value("calib", json::object());
    std::string t;
    t += fmt("modelo: %s (%s)  %.1f fps  %.1f ms (p95 %.1f)  camara %.1f fps  [nucleo %s]\n",
             e["modelo"].is_null() ? "ninguno" : e["modelo"].get<std::string>().c_str(), e.value("motor", "-").c_str(),
             num(e, "fps"), num(e, "lat_ms"), num(e, "lat_p95"), num(e, "fps_camara"), e.value("motor_nucleo", "?").c_str());
    t += fmt("CPU %.0f%% %s  GPU %s%%  RAM %.0f/%.0f MB  swap %.0f MB  proceso %.0f%% CPU %.0f MB", num(s, "cpu_prom", 0),
             s.value("cpu", json::array()).dump().c_str(), s["gpu"].is_null() ? "-" : s["gpu"].dump().c_str(),
             num(s, "ram_mb", 0), num(s, "ram_total_mb", 0), num(s, "swap_mb", 0), num(s, "proc_cpu", 0),
             num(s, "proc_ram_mb", 0));
    if (!s["potencia_mw"].is_null()) t += fmt("  %.1f W", num(s, "potencia_mw") / 1000);
    t += "\ntemperaturas: ";
    for (auto it = s["temp"].begin(); it != s["temp"].end(); ++it) t += fmt("%s %.0f  ", it.key().c_str(), it.value().get<double>());
    t += fmt("\nproyector %s | calibracion %s (%s px) | manos %s | web %s | buscar %s | fondo %s\n",
             e.value("proyector", false) ? "on" : "off", c.value("lista", false) ? c.value("metodo", "").c_str() : "NO",
             c["error_px"].dump().c_str(), e.value("manos", false) ? "on" : "off",
             e["web"].is_null() ? "off" : e["web"].get<std::string>().c_str(), e.value("buscar", false) ? "on" : "off",
             e.value("fondo", false) ? "on" : "off");
    if (!e["params"].empty()) t += "params: " + kv(e["params"]) + "\n";
    t += "filtros: " + kv(e["filtros"]) + "\n";
    if (!e["memoria"].empty()) t += "memoria: " + kv(e["memoria"]) + "\n";
    if (e.value("modelo_error", "") != "") t += "error modelo: " + e.value("modelo_error", "") + "\n";
    return t;
}

// ====================================================================== tablero
static const char* AYUDA[] = {
    "q salir  Q apagar núcleo  1-9 modelo  0 ninguno  a auto-ajuste  c calibrar  C método  v verificar  m mm",
    "p proyector  w web  h manos  i vista  b buscar  f fondo  o marcas  e enseñar  t guardar al dataset  s foto",
    "[ ] umbral  { } tamaño YOLO  ( ) nms  g/G gamma  l/L clahe  k/K kernel  n/N nitidez  B benchmark  P perfil"};
static const char* AYUDA_ENS = "ENSEÑANDO: flechas mover  + - tamaño  * / ancho  Enter guardar  x la cámara propone  Esc terminar";

struct Tablero {
    std::atomic<bool> vivo{true}, vista{false}, ocupado{false};
    std::mutex mx;
    json est;
    std::string mensaje, tabla, err;
    std::vector<unsigned char> vbuf;
    int vw = 0, vh = 0;
    termios viejo{};
    bool truecolor = false;

    void mandar(json m) {
        std::thread([this, m]() {
            ocupado = true;
            try {
                json r = enviar(m);
                std::lock_guard<std::mutex> lk(mx);
                mensaje = r.value("msg", "");
                if (mensaje.empty()) mensaje = r.value("ok", false) ? "ok" : "error";
                if (r.contains("tabla")) tabla = r.value("tabla", "");
            } catch (const std::exception& e) {
                std::lock_guard<std::mutex> lk(mx);
                mensaje = std::string("error: ") + e.what();
            }
            ocupado = false;
        }).detach();
    }

    std::string preguntar(const std::string& t) {
        tcsetattr(0, TCSADRAIN, &viejo);
        std::cout << "\x1b[?25h\n" << NEG << t << RESET << std::flush;
        std::string r;
        std::getline(std::cin, r);
        modo_crudo();
        std::cout << "\x1b[?25l";
        while (!r.empty() && (r.back() == ' ' || r.back() == '\r')) r.pop_back();
        return r;
    }
    void modo_crudo() {
        termios t = viejo;
        t.c_lflag &= ~(ICANON | ECHO);
        t.c_cc[VMIN] = 0;
        t.c_cc[VTIME] = 0;
        tcsetattr(0, TCSADRAIN, &t);
    }

    std::string tecla() {
        fd_set fs;
        FD_ZERO(&fs);
        FD_SET(0, &fs);
        timeval tv{0, 250000};
        if (select(1, &fs, nullptr, nullptr, &tv) <= 0) return "";
        char c;
        if (read(0, &c, 1) != 1) return "";
        if (c == 0x1b) {
            FD_ZERO(&fs);
            FD_SET(0, &fs);
            timeval t2{0, 30000};
            if (select(1, &fs, nullptr, nullptr, &t2) > 0) {
                char s[2] = {0, 0};
                if (read(0, s, 2) == 2 && s[0] == '[') {
                    if (s[1] == 'A') return "ARRIBA";
                    if (s[1] == 'B') return "ABAJO";
                    if (s[1] == 'C') return "DER";
                    if (s[1] == 'D') return "IZQ";
                }
            }
            return "ESC";
        }
        return std::string(1, c);
    }

    void atender(const std::string& k) {
        bool ens = false;
        {
            std::lock_guard<std::mutex> lk(mx);
            ens = est.contains("ensenando") && !est["ensenando"].is_null();
        }
        if (ens) {
            if (k == "ARRIBA") return mandar({{"cmd", "ensenar"}, {"accion", "mover"}, {"dx", 0}, {"dy", -1}});
            if (k == "ABAJO") return mandar({{"cmd", "ensenar"}, {"accion", "mover"}, {"dx", 0}, {"dy", 1}});
            if (k == "IZQ") return mandar({{"cmd", "ensenar"}, {"accion", "mover"}, {"dx", -1}, {"dy", 0}});
            if (k == "DER") return mandar({{"cmd", "ensenar"}, {"accion", "mover"}, {"dx", 1}, {"dy", 0}});
            if (k == "+" || k == "=") return mandar({{"cmd", "ensenar"}, {"accion", "tam"}, {"dw", 1}, {"dh", 1}});
            if (k == "-" || k == "_") return mandar({{"cmd", "ensenar"}, {"accion", "tam"}, {"dw", -1}, {"dh", -1}});
            if (k == "*") return mandar({{"cmd", "ensenar"}, {"accion", "tam"}, {"dw", 1}, {"dh", 0}});
            if (k == "/") return mandar({{"cmd", "ensenar"}, {"accion", "tam"}, {"dw", -1}, {"dh", 0}});
            if (k == "\n" || k == "\r") return mandar({{"cmd", "ensenar"}, {"accion", "guardar"}});
            if (k == "x") return mandar({{"cmd", "ensenar"}, {"accion", "auto"}});
            if (k == "ESC") return mandar({{"cmd", "ensenar"}, {"accion", "cancelar"}});
        }
        if (k == "q") vivo = false;
        else if (k == "Q") {
            mandar({{"cmd", "apagar"}});
            util::dormir(0.3);
            vivo = false;
        } else if (k.size() == 1 && isdigit((unsigned char)k[0])) mandar({{"cmd", "modelo"}, {"id", k}});
        else if (k == "a") mandar({{"cmd", "autoajuste"}});
        else if (k == "c") mandar({{"cmd", "calibrar"}, {"metodo", "aruco"}});
        else if (k == "C") {
            std::string m = preguntar("Método [aruco|puntos|esquinas|graycode]: ");
            mandar({{"cmd", "calibrar"}, {"metodo", m.empty() ? "aruco" : m}});
        } else if (k == "v") mandar({{"cmd", "verificar"}});
        else if (k == "m") mandar({{"cmd", "mm"}});
        else if (k == "p") mandar({{"cmd", "proyector"}});
        else if (k == "w") mandar({{"cmd", "web"}});
        else if (k == "h") mandar({{"cmd", "manos"}});
        else if (k == "b") mandar({{"cmd", "buscar"}});
        else if (k == "o") mandar({{"cmd", "marcas"}});
        else if (k == "i") vista = !vista;
        else if (k == "f") mandar({{"cmd", "fondo"}});
        else if (k == "e") {
            std::string n = preguntar("¿Qué pieza le vas a enseñar? (ej. tijera mayo): ");
            if (!n.empty()) mandar({{"cmd", "ensenar"}, {"accion", "inicio"}, {"clase", n}});
        } else if (k == "t") mandar({{"cmd", "confirmar"}});
        else if (k == "s") mandar({{"cmd", "foto"}});
        else if (k == "[" || k == "]") mandar({{"cmd", "param"}, {"k", "umbral"}, {"delta", k == "[" ? -0.05 : 0.05}});
        else if (k == "(" || k == ")") mandar({{"cmd", "param"}, {"k", "nms"}, {"delta", k == "(" ? -0.05 : 0.05}});
        else if (k == "{" || k == "}") mandar({{"cmd", "param"}, {"k", "entrada"}, {"delta", k == "{" ? -1 : 1}});
        else if (k == "g" || k == "G") mandar({{"cmd", "filtro"}, {"k", "gamma"}, {"delta", k == "g" ? -0.1 : 0.1}});
        else if (k == "l" || k == "L") mandar({{"cmd", "filtro"}, {"k", "clahe"}, {"delta", k == "l" ? -0.5 : 0.5}});
        else if (k == "k" || k == "K") mandar({{"cmd", "filtro"}, {"k", "suavizado"}, {"delta", k == "k" ? -1 : 1}});
        else if (k == "n" || k == "N") mandar({{"cmd", "filtro"}, {"k", "nitidez"}, {"delta", k == "n" ? -0.25 : 0.25}});
        else if (k == "B") {
            std::string s = preguntar("Segundos por modelo [20]: ");
            std::string ids = preguntar("Modelos (teclas separadas por espacio, Enter = todos): ");
            json l = json::array();
            std::stringstream ss(ids);
            std::string x;
            while (ss >> x) l.push_back(x);
            {
                std::lock_guard<std::mutex> lk(mx);
                tabla.clear();
            }
            mandar({{"cmd", "bench"}, {"modelos", l}, {"seg", s.empty() ? 20.0 : std::atof(s.c_str())}});
        } else if (k == "P") {
            std::string p = preguntar("Perfil de energía [max|normal|5w]: ");
            if (!p.empty()) mandar({{"cmd", "perfil"}, {"nombre", p}});
        }
    }

    void pedir() {
        while (vivo) {
            try {
                json e = enviar({{"cmd", "estado"}}, 3).value("estado", json::object());
                std::vector<unsigned char> vb;
                int w = 0, h = 0;
                if (vista) {
                    winsize ws{};
                    ioctl(1, TIOCGWINSZ, &ws);
                    int cols = ws.ws_col ? ws.ws_col : 100, filas = ws.ws_row ? ws.ws_row : 40;
                    int vw2 = std::min(cols - 2, 110), vh2 = std::max(6, std::min(filas - 22, vw2 * 9 / 32));
                    json v = enviar({{"cmd", "vista"}, {"w", vw2}, {"h", vh2}}, 3).value("vista", json());
                    if (v.is_object()) {
                        w = v["w"];
                        h = v["h"];
                        std::string b64 = v["bgr"];
                        static int T[256];
                        static bool ini = false;
                        if (!ini) {
                            const char* a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
                            for (int i = 0; i < 256; i++) T[i] = -1;
                            for (int i = 0; i < 64; i++) T[(unsigned char)a[i]] = i;
                            ini = true;
                        }
                        unsigned val = 0;
                        int bits = -8;
                        for (unsigned char ch : b64) {
                            if (T[ch] < 0) break;
                            val = (val << 6) | T[ch];
                            bits += 6;
                            if (bits >= 0) {
                                vb.push_back((val >> bits) & 0xFF);
                                bits -= 8;
                            }
                        }
                    }
                }
                std::lock_guard<std::mutex> lk(mx);
                est = e;
                err.clear();
                if (vista && !vb.empty()) {
                    vbuf = vb;
                    vw = w;
                    vh = h;
                }
            } catch (const std::exception& ex) {
                std::lock_guard<std::mutex> lk(mx);
                err = ex.what();
            }
            util::dormir(vista ? 0.35 : 0.8);
        }
    }

    static int c256(int r, int g, int b) {
        if (std::abs(r - g) < 10 && std::abs(g - b) < 10) return 232 + std::min(23, r * 24 / 256);
        return 16 + 36 * (r * 6 / 256) + 6 * (g * 6 / 256) + (b * 6 / 256);
    }

    void dibujar() {
        winsize ws{};
        ioctl(1, TIOCGWINSZ, &ws);
        int cols = ws.ws_col ? ws.ws_col : 100;
        std::vector<std::string> L;
        std::lock_guard<std::mutex> lk(mx);
        if (!err.empty()) {
            L.push_back(ROJO + "No hay conexión con el núcleo: " + err + RESET);
            L.push_back("Arráncalo con:  austero start");
        } else if (est.is_object() && !est.empty()) {
            const json& e = est;
            json s = e.value("stats", json::object()), c = e.value("calib", json::object());
            L.push_back(NEG + CIAN + " MODO AUSTERO " + RESET + GRIS + "C++ ─ " + RESET + "modelo " + NEG +
                        (e["modelo"].is_null() ? "ninguno" : e["modelo"].get<std::string>()) + RESET + GRIS + " (" +
                        e.value("motor", "-") + ")" + RESET + "   " + VERDE + fmt("%.1f fps", num(e, "fps", 0)) + RESET +
                        fmt("  %.0f ms ", num(e, "lat_ms", 0)) + GRIS + fmt("(p95 %.0f)", num(e, "lat_p95", 0)) + RESET +
                        fmt("  cám %.0f fps ", num(e, "fps_camara", 0)) +
                        (e.value("ocupado", "") != "" ? AMAR + "⏳ " + e.value("ocupado", "") + RESET : ""));
            std::string cores;
            for (auto& x : s.value("cpu", json::array())) cores += barra(x.get<double>(), 4) + " ";
            L.push_back(" CPU " + barra(num(s, "cpu_prom", 0)) + fmt(" %3.0f%%  ", num(s, "cpu_prom", 0)) + cores +
                        "  GPU " + barra(num(s, "gpu")) + " " + (s["gpu"].is_null() ? "-" : s["gpu"].dump()) + "%   " +
                        (s["potencia_mw"].is_null() ? "" : MAG + fmt("%.1f W", num(s, "potencia_mw") / 1000) + RESET));
            double rt = std::max(1.0, num(s, "ram_total_mb", 1));
            std::string temps;
            for (auto it = s["temp"].begin(); it != s["temp"].end(); ++it) {
                double t = it.value();
                if (it.key().find("thermal") != std::string::npos || it.key().find("PMIC") != std::string::npos) continue;
                temps += it.key() + " " + (t < 55 ? VERDE : (t < 70 ? AMAR : ROJO)) + fmt("%.0f°", t) + RESET + "  ";
            }
            L.push_back(" RAM " + barra(100 * num(s, "ram_mb", 0) / rt) +
                        fmt(" %.0f/%.0f MB  swap %.0f MB   proceso %.0f%% CPU  %.0f MB   ", num(s, "ram_mb", 0), rt,
                            num(s, "swap_mb", 0), num(s, "proc_cpu", 0), num(s, "proc_ram_mb", 0)) +
                        temps);
            std::string cal = c.value("lista", false)
                                  ? VERDE + c.value("metodo", "") + fmt(" %.1f px", num(c, "error_px", 0)) + RESET +
                                        (c["px_por_mm"].is_null() ? "" : fmt(" %.2f px/mm", num(c, "px_por_mm")))
                                  : ROJO + "NO" + RESET;
            L.push_back(" proyector " + onoff(e.value("proyector", false)) + "  calibración " + cal + "  manos " +
                        onoff(e.value("manos", false)) + "  web " +
                        (e["web"].is_null() ? onoff(false) : VERDE + e["web"].get<std::string>() + RESET) + "  buscar " +
                        onoff(e.value("buscar", false)) + "  fondo " + onoff(e.value("fondo", false)));
            L.push_back(" " + GRIS + "params " + RESET + kv(e.value("params", json::object())) + GRIS + " filtros " + RESET +
                        kv(e.value("filtros", json::object())));
            std::string mods = " " + GRIS + "modelos " + RESET;
            for (auto& m : e.value("catalogo", json::array())) {
                bool act = !e["modelo"].is_null() && m.value("id", "") == e["modelo"].get<std::string>();
                mods += (act ? NEG + VERDE : GRIS) + m.value("tecla", "") + ":" + m.value("id", "") + RESET + " ";
            }
            L.push_back(mods);
            if (!e["memoria"].empty()) L.push_back(" " + GRIS + "memoria " + RESET + kv(e["memoria"]));
            if (!e["dets"].empty()) {
                std::string d = " " + GRIS + "ve: " + RESET;
                int i = 0;
                for (auto& x : e["dets"]) {
                    if (i++ >= 6) break;
                    d += x.value("clase", "") + fmt(" %.0f%%", num(x, "conf", 0) * 100) +
                         (x["angulo"].is_null() ? "" : fmt(" %.0f°", num(x, "angulo"))) + "  ";
                }
                L.push_back(d);
            }
            if (e.value("modelo_error", "") != "") L.push_back(" " + ROJO + e.value("modelo_error", "") + RESET);
            if (vista) {
                if (vbuf.empty()) L.push_back(GRIS + "  (esperando vista...)" + RESET);
                for (int y = 0; y + 1 < vh && !vbuf.empty(); y += 2) {
                    std::string f = " ";
                    for (int x = 0; x < vw; x++) {
                        const unsigned char* a = &vbuf[(y * vw + x) * 3];
                        const unsigned char* b = &vbuf[((y + 1) * vw + x) * 3];
                        if (truecolor) f += fmt("\x1b[38;2;%d;%d;%dm\x1b[48;2;%d;%d;%dm▀", a[2], a[1], a[0], b[2], b[1], b[0]);
                        else f += fmt("\x1b[38;5;%dm\x1b[48;5;%dm▀", c256(a[2], a[1], a[0]), c256(b[2], b[1], b[0]));
                    }
                    L.push_back(f + RESET);
                }
            }
            if (!tabla.empty()) {
                std::stringstream ss(tabla);
                std::string l;
                while (std::getline(ss, l)) L.push_back(" " + l);
            }
            L.push_back(GRIS + std::string(std::min(cols, 110) * 3 / 3, '-') + RESET);
            for (auto& l : e.value("log", json::array())) L.push_back(" " + TEN + l.get<std::string>().substr(0, cols - 2) + RESET);
            if (!mensaje.empty()) L.push_back(" " + AMAR + (ocupado ? "⏳ " : "» ") + mensaje.substr(0, cols - 4) + RESET);
            if (!e["ensenando"].is_null()) L.push_back(" " + NEG + AMAR + AYUDA_ENS + RESET);
            for (auto a : AYUDA) L.push_back(" " + GRIS + std::string(a).substr(0, cols * 2) + RESET);
        } else {
            L.push_back("conectando...");
        }
        std::string out = "\x1b[H";
        for (auto& l : L) out += l + "\x1b[K\n";
        out += "\x1b[J";
        std::cout << out << std::flush;
    }

    int correr() {
        const char* ct = getenv("COLORTERM");
        truecolor = (ct && (std::string(ct) == "truecolor" || std::string(ct) == "24bit")) || getenv("WT_SESSION") ||
                    (getenv("AUSTERO_TRUECOLOR") && std::string(getenv("AUSTERO_TRUECOLOR")) == "1");
        tcgetattr(0, &viejo);
        modo_crudo();
        std::cout << "\x1b[?25l\x1b[2J" << std::flush;
        std::thread t(&Tablero::pedir, this);
        while (vivo) {
            std::string k = tecla();
            if (!k.empty()) atender(k);
            dibujar();
        }
        tcsetattr(0, TCSADRAIN, &viejo);
        std::cout << RESET << "\x1b[?25h\n" << std::flush;
        t.join();
        return 0;
    }
};

// ====================================================================== CLI
static const char* AYUDA_CLI = R"(uso: austero <comando>
  start [--sim] | stop | restart | ver | logs
  status | log                         estado y ultimos mensajes
  modelo <1-9|id|0>                     cambiar de modelo (0 = ninguno)
  param <nombre> <valor>                umbral, nms, entrada (tamano YOLO), area_min, dif
  filtro <nombre> <valor>               gamma, clahe, suavizado (kernel), nitidez
  autoajuste                            ajustar la camara sola
  calibrar [aruco|puntos|esquinas|graycode]
  verificar | mm                        revisar la calibracion / medir escala en mm
  proyector|web|manos|buscar|marcas on|off
  fondo                                 foto de la mesa vacia
  ensenar "<pieza>" | ensenar guardar|auto|cancelar
  confirmar                             guardar foto + detecciones actuales en dataset/
  olvidar "<pieza>"
  bench [ids o teclas...] [--seg N]      benchmark (todos si no dices cuales)
  perfil max|normal|5w                  energia de la Jetson (nvpmodel / jetson_clocks)
  foto
  sim revolver|vaciar|pieza <tipo>|marcador|mover_proyector   (solo --sim))";

int main(int argc, char** argv) {
    std::vector<std::string> a(argv + 1, argv + argc);
    if (a.empty() || a[0] == "-h" || a[0] == "--help" || a[0] == "ayuda") {
        std::cout << AYUDA_CLI << std::endl;
        return 0;
    }
    if (a[0] == "ver" || a[0] == "tablero") return Tablero().correr();
    std::string c = a[0];
    auto resto = [&](size_t i) {
        std::string s;
        for (size_t k = i; k < a.size(); k++) s += (k > i ? " " : "") + a[k];
        return s;
    };
    json m;
    if (c == "status" || c == "estado") m = {{"cmd", "estado"}};
    else if (c == "log") m = {{"cmd", "log"}, {"n", a.size() > 1 ? std::atoi(a[1].c_str()) : 30}};
    else if (c == "modelo") m = {{"cmd", "modelo"}, {"id", a.size() > 1 ? a[1] : "0"}};
    else if ((c == "param" || c == "filtro") && a.size() >= 3) m = {{"cmd", c}, {"k", a[1]}, {"v", a[2]}};
    else if (c == "proyector" || c == "web" || c == "manos" || c == "buscar" || c == "marcas")
        m = {{"cmd", c}, {"on", a.size() > 1 ? json(a[1]) : json(nullptr)}};
    else if (c == "calibrar") m = {{"cmd", "calibrar"}, {"metodo", a.size() > 1 ? json(a[1]) : json(nullptr)}};
    else if (c == "ensenar") {
        if (a.size() > 1 && (a[1] == "guardar" || a[1] == "auto" || a[1] == "cancelar"))
            m = {{"cmd", "ensenar"}, {"accion", a[1]}};
        else
            m = {{"cmd", "ensenar"}, {"accion", "inicio"}, {"clase", resto(1)}};
    } else if (c == "olvidar") m = {{"cmd", "olvidar"}, {"clase", resto(1)}};
    else if (c == "bench") {
        json ids = json::array();
        json seg = nullptr;
        for (size_t i = 1; i < a.size(); i++) {
            if (a[i] == "--seg" && i + 1 < a.size()) seg = std::atof(a[++i].c_str());
            else ids.push_back(a[i]);
        }
        m = {{"cmd", "bench"}, {"modelos", ids}, {"seg", seg}};
    } else if (c == "perfil") m = {{"cmd", "perfil"}, {"nombre", a.size() > 1 ? a[1] : ""}};
    else if (c == "sim") {
        m = {{"cmd", "sim"}, {"accion", a.size() > 1 ? a[1] : "revolver"}};
        if (a.size() > 2) {
            m["tipo"] = a[2];
            if (isdigit((unsigned char)a[2][0])) m["n"] = std::atoi(a[2].c_str());
        }
    } else m = {{"cmd", c}};
    try {
        json r = enviar(m);
        if (c == "status" || c == "estado") std::cout << resumen(r.value("estado", json::object()));
        else if (c == "log")
            for (auto& l : r.value("log", json::array())) std::cout << l.get<std::string>() << "\n";
        else {
            if (r.contains("tabla")) std::cout << r.value("tabla", "");
            std::string msg = r.value("msg", "");
            std::cout << (msg.empty() ? (r.value("ok", false) ? "ok" : "error") : msg) << std::endl;
        }
        return r.value("ok", true) ? 0 : 1;
    } catch (const std::exception& e) {
        std::cout << e.what() << std::endl;
        return 2;
    }
}
