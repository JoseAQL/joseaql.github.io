// memoria.hpp - el modo "Terminator": le ensenas donde esta una pieza y despues busca las parecidas.
//  Ensenar: recorta la zona de la sombra, separa la pieza del fondo y guarda su "huella":
//           contorno + momentos de Hu, proporcion largo/ancho, area, histograma de color HSV.
//           Tambien guarda la foto completa con etiqueta YOLO en dataset/ para entrenar un modelo despues.
//  Buscar:  candidatos = lo distinto al fondo -> se comparan sus huellas con las ensenadas.
//  Sin red neuronal: corre en CPU y gasta muy poco.
#pragma once

#include <map>
#include <mutex>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "deteccion.hpp"

struct Huella {
    double area = 0, largo = 0, ancho = 0, proporcion = 1, angulo = 0;
    cv::Mat hist;   // 16x8 CV_32F, suma 1
    cv::Rect caja;
    std::vector<cv::Point> contorno;
};

struct Ejemplo {
    std::string clase;
    Huella h;
};

class Memoria {
public:
    Memoria();
    void recargar();
    std::vector<std::string> clases() const { return clases_; }
    std::map<std::string, int> resumen() const;
    bool vacia() const { return ejemplos_.empty(); }
    int indice(const std::string& clase);

    // regresa mensaje; si ok, llena 'det'
    bool ensenar(const cv::Mat& img, const cv::Rect& caja, const std::string& clase, const cv::Mat& fondo,
                 const cv::Mat& mascara, double mm_por_px, Det& det, std::string& msg);
    std::vector<std::vector<cv::Point>> candidatos(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& mascara,
                                                   double dif = 30, double area_min = 400);
    std::vector<Det> buscar(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& mascara, double umbral = 0.55,
                            double dif = 30, double area_min = 400);
    int confirmar(const cv::Mat& img, const std::vector<Det>& dets);
    bool olvidar(const std::string& clase);

private:
    std::vector<std::string> clases_;
    std::vector<Ejemplo> ejemplos_;
    mutable std::mutex mx_;
    void guardar_clases();
    void guardar_dataset(const cv::Mat& img, const std::vector<std::pair<int, cv::Rect>>& et);
};

Huella calcular_huella(const cv::Mat& img, const std::vector<cv::Point>& c);
double parecido(const Huella& a, const Huella& b);
