#include "proyector.hpp"

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

static const char* VENTANA = "austero_proyector";

Proyector::Proyector(const json& cfg, bool sim) : simulado(sim), cfg_(cfg) {
    w = cfg.value("ancho", 1920);
    h = cfg.value("alto", 1080);
    img_ = cv::Mat::zeros(h, w, CV_8UC3);
}

bool Proyector::encender() {
    if (encendido) return true;
    if (!simulado) {
        try {
            util::preparar_display(cfg_.value("display", ":0"));
            cv::namedWindow(VENTANA, cv::WINDOW_NORMAL);
            cv::moveWindow(VENTANA, cfg_.value("offset_x", 0), cfg_.value("offset_y", 0));
            cv::setWindowProperty(VENTANA, cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN);
            ventana_ = true;
        } catch (const std::exception& e) {
            util::log(std::string("proyector: no pude abrir la ventana (") + e.what() + "). Sigo sin proyector.");
            return false;
        }
    }
    encendido = true;
    std::lock_guard<std::mutex> lk(mx_);
    sucio_ = true;
    return true;
}

void Proyector::apagar() {
    encendido = false;
    if (ventana_) {
        try {
            cv::destroyWindow(VENTANA);
            cv::waitKey(1);
        } catch (...) {
        }
        ventana_ = false;
    }
}

void Proyector::poner_patron(const cv::Mat& img) {
    {
        std::lock_guard<std::mutex> lk(mx_);
        if (img.empty()) {
            patron_.release();
        } else {
            cv::Mat p = img;
            if (p.cols != w || p.rows != h) cv::resize(p, p, cv::Size(w, h), 0, 0, cv::INTER_NEAREST);
            if (p.channels() == 1) cv::cvtColor(p, p, cv::COLOR_GRAY2BGR);
            patron_ = p;
        }
        sucio_ = true;
    }
    actualizar();
}

bool Proyector::hay_patron() {
    std::lock_guard<std::mutex> lk(mx_);
    return !patron_.empty();
}

void Proyector::poner_sombra(const Sombra& s) {
    std::lock_guard<std::mutex> lk(mx_);
    if (s.activa != sombra_.activa || s.x != sombra_.x || s.y != sombra_.y || s.w != sombra_.w || s.h != sombra_.h ||
        s.texto != sombra_.texto) {
        sombra_ = s;
        sucio_ = true;
    }
}

void Proyector::poner_marcas(const std::vector<Marca>& m) {
    std::string f;
    for (auto& k : m) {
        f += k.texto + "|";
        for (auto& p : k.pts) f += std::to_string(p.x) + "," + std::to_string(p.y) + ";";
    }
    std::lock_guard<std::mutex> lk(mx_);
    if (f != firma_) {
        firma_ = f;
        marcas_ = m;
        sucio_ = true;
    }
}

void Proyector::poner_mensaje(const std::string& t) {
    std::lock_guard<std::mutex> lk(mx_);
    if (t != mensaje_) {
        mensaje_ = t;
        sucio_ = true;
    }
}

cv::Mat Proyector::componer() {
    if (!patron_.empty()) return patron_.clone();
    cv::Mat img(h, w, CV_8UC3, cv::Scalar::all(relleno));
    for (auto& m : marcas_) {
        if (m.pts.size() < 2) continue;
        cv::polylines(img, std::vector<std::vector<cv::Point>>{m.pts}, true, m.color, 4);
        if (!m.texto.empty()) {
            cv::Rect r = cv::boundingRect(m.pts);
            cv::putText(img, m.texto, cv::Point(r.x, std::max(30, r.y - 10)), cv::FONT_HERSHEY_SIMPLEX, 1.0, m.color, 2);
        }
    }
    if (sombra_.activa) {
        cv::Scalar c(0, 220, 255);
        cv::rectangle(img, cv::Rect(sombra_.x, sombra_.y, sombra_.w, sombra_.h), c, 4);
        for (auto p : {cv::Point(sombra_.x, sombra_.y), cv::Point(sombra_.x + sombra_.w, sombra_.y),
                       cv::Point(sombra_.x, sombra_.y + sombra_.h), cv::Point(sombra_.x + sombra_.w, sombra_.y + sombra_.h)})
            cv::circle(img, p, 10, c, -1);
        if (!sombra_.texto.empty())
            cv::putText(img, sombra_.texto, cv::Point(sombra_.x, std::max(35, sombra_.y - 14)), cv::FONT_HERSHEY_SIMPLEX,
                        1.1, c, 2);
    }
    if (!mensaje_.empty())
        cv::putText(img, mensaje_, cv::Point(30, h - 30), cv::FONT_HERSHEY_SIMPLEX, 1.0, cv::Scalar(200, 200, 200), 2);
    return img;
}

void Proyector::actualizar() {
    if (!encendido) return;
    {
        std::lock_guard<std::mutex> lk(mx_);
        if (sucio_) {
            img_ = componer();
            sucio_ = false;
            version_++;
            if (ventana_) cv::imshow(VENTANA, img_);
        }
    }
    if (ventana_) cv::waitKey(1);
}

cv::Mat Proyector::imagen_actual() {
    if (!encendido) return cv::Mat();
    std::lock_guard<std::mutex> lk(mx_);
    if (sucio_) {
        img_ = componer();
        sucio_ = false;
        version_++;
    }
    return img_;
}
