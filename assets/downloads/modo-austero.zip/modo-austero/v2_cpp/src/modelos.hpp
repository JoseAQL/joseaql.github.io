// modelos.hpp - banco de modelos. Solo UNO cargado a la vez (la Nano tiene 4 GB compartidos CPU/GPU).
//
// Tecla  id               que es
//   1    fondo            resta de fondo con OpenCV (sin red; casi no gasta)
//   2    ssd_general      detectNet SSD-MobileNet-v2 COCO (jetson-inference, MIT)
//   3    ssd_propio       detectNet con TU ONNX re-entrenado (modelos/ssd_instrumental/)
//   4    yolo_mit4        YOLO11-L, 4 instrumentos (amirrezamortazavifard, MIT)
//   5    yolo_doccheck12  YOLOv5-L, 12 instrumentos (DocCheck Rona, CC BY-NC 4.0)
//   6    orientacion      angulo 0-357 de cada pieza (DocCheck Rona, CC BY-NC 4.0)
//   7    ejemplos         "Terminator": busca lo que le ensenaste
//   8    fondo_ia         backgroundNet U2-Net (jetson-inference)
//   9    yolo_alumno      tu YOLO nano entrenado en Colab con tus ejemplos
// Aparte (tecla h): manos con poseNet resnet18-hand.
//
// YOLO y orientacion: TensorRT (.engine) en la Jetson; si no hay, OpenCV DNN (CPU) con el .onnx.
#pragma once

#include <map>
#include <memory>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "deteccion.hpp"

// ------------------------------------------------------------ motor de inferencia
class Motor {
public:
    virtual ~Motor() {}
    virtual std::vector<cv::Mat> correr(const cv::Mat& blob) = 0;   // blob NCHW float32
    std::vector<int> forma_entrada;                                 // N,C,H,W
    std::string nombre;
};
// base = ruta sin extension: prueba base.engine (TensorRT) y luego base.onnx (OpenCV DNN)
std::unique_ptr<Motor> abrir_motor(const std::string& base, const std::vector<int>& forma_def, std::string& error);

// ------------------------------------------------------------ modelo
class Modelo {
public:
    explicit Modelo(Contexto& ctx) : ctx(ctx) {}
    virtual ~Modelo() {}
    virtual std::string id() const = 0;
    virtual std::string nombre() const = 0;
    virtual std::string licencia() const { return ""; }
    virtual bool disponible(std::string& por_que) { return true; }
    virtual bool cargar() { ok = true; return true; }
    virtual void liberar() { ok = false; }
    virtual std::vector<Det> procesar(const cv::Mat& img) = 0;
    virtual bool poner(const std::string& k, double v);
    virtual std::vector<int> tamanos() { return {}; }
    json params_json() const;

    bool ok = false;
    std::string error, motor;
    std::map<std::string, double> p;
    Contexto& ctx;
};

struct InfoModelo {
    std::string tecla, id, nombre;
};
std::vector<InfoModelo> catalogo();
std::unique_ptr<Modelo> crear_modelo(const std::string& id_o_tecla, Contexto& ctx);

// ------------------------------------------------------------ manos (aparte)
struct Mano {
    std::vector<cv::Point2f> puntos;   // 21; (-1,-1) si no se vio
};
class Manos {
public:
    Manos();
    ~Manos();
    bool cargar();
    void liberar();
    std::vector<Mano> procesar(const cv::Mat& img);
    bool ok = false;
    std::string error, motor;
    float umbral = 0.15f;

private:
    struct Impl;
    Impl* impl_ = nullptr;
};

bool hay_jetson_inference();
bool hay_tensorrt();
