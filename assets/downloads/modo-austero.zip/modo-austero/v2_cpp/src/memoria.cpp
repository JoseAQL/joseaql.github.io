#include "memoria.hpp"

#include <climits>
#include <cmath>
#include <algorithm>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

using util::fmt;

static std::string dir_mem() { return util::ruta("memoria"); }
static std::string dir_data() { return util::ruta("dataset"); }

// ====================================================================== segmentacion (tambien la usan los modelos)
static std::vector<std::vector<cv::Point>> contornos(const cv::Mat& m) {
    std::vector<std::vector<cv::Point>> c;
    cv::findContours(m.clone(), c, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    return c;
}

std::vector<std::vector<cv::Point>> segmentar_fondo(const cv::Mat& img, const cv::Mat& fondo, double umbral,
                                                    double area_min, const cv::Mat& ignorar) {
    std::vector<std::vector<cv::Point>> res;
    if (fondo.empty() || fondo.size() != img.size()) return res;
    cv::Mat a, b, dif, dc;
    cv::GaussianBlur(img, a, cv::Size(5, 5), 0);
    cv::GaussianBlur(fondo, b, cv::Size(5, 5), 0);
    cv::absdiff(a, b, dc);
    // maximo de los 3 canales: una pieza gris sobre mesa de color tambien cuenta
    std::vector<cv::Mat> ch;
    cv::split(dc, ch);
    dif = cv::max(cv::max(ch[0], ch[1]), ch[2]);
    cv::Mat m;
    cv::threshold(dif, m, umbral, 255, cv::THRESH_BINARY);
    if (!ignorar.empty()) m.setTo(0, ignorar);
    cv::morphologyEx(m, m, cv::MORPH_CLOSE, cv::Mat::ones(9, 9, CV_8U));
    cv::morphologyEx(m, m, cv::MORPH_OPEN, cv::Mat::ones(3, 3, CV_8U));
    for (auto& c : contornos(m))
        if (cv::contourArea(c) >= area_min) res.push_back(c);
    return res;
}

// ====================================================================== huella
Huella calcular_huella(const cv::Mat& img, const std::vector<cv::Point>& c) {
    Huella h;
    h.contorno = c;
    h.caja = cv::boundingRect(c);
    cv::RotatedRect rr = cv::minAreaRect(c);
    h.largo = std::max(rr.size.width, rr.size.height);
    h.ancho = std::max(1.f, std::min(rr.size.width, rr.size.height));
    h.proporcion = h.largo / h.ancho;
    double ang = rr.angle + (rr.size.width < rr.size.height ? 90 : 0);
    h.angulo = std::fmod(ang + 360.0, 180.0);
    h.area = cv::contourArea(c);
    // histograma solo dentro de la caja (barato)
    cv::Rect r = h.caja & cv::Rect(0, 0, img.cols, img.rows);
    cv::Mat m = cv::Mat::zeros(r.size(), CV_8U);
    std::vector<std::vector<cv::Point>> cc = {c};
    cv::drawContours(m, cc, -1, cv::Scalar(255), -1, cv::LINE_8, cv::noArray(), INT_MAX, -r.tl());
    cv::Mat hsv;
    cv::cvtColor(img(r), hsv, cv::COLOR_BGR2HSV);
    int canales[] = {0, 1}, tam[] = {16, 8};
    float rh[] = {0, 180}, rs[] = {0, 256};
    const float* rangos[] = {rh, rs};
    cv::calcHist(&hsv, 1, canales, m, h.hist, 2, tam, rangos);
    cv::normalize(h.hist, h.hist, 1.0, 0, cv::NORM_L1);
    return h;
}

double parecido(const Huella& a, const Huella& b) {
    double forma = std::exp(-4.0 * cv::matchShapes(a.contorno, b.contorno, cv::CONTOURS_MATCH_I1, 0));
    double prop = std::min(a.proporcion, b.proporcion) / std::max(a.proporcion, b.proporcion);
    double tam = std::sqrt(std::min(a.area, b.area) / std::max(std::max(a.area, b.area), 1.0));
    double col = (a.hist.empty() || b.hist.empty()) ? 0 : std::max(0.0, cv::compareHist(a.hist, b.hist, cv::HISTCMP_CORREL));
    return 0.45 * forma + 0.2 * prop + 0.2 * tam + 0.15 * col;
}

static json huella_json(const Huella& h) {
    json c = json::array();
    for (auto& p : h.contorno) c.push_back({p.x, p.y});
    std::vector<float> hist;
    if (!h.hist.empty()) hist.assign((float*)h.hist.datastart, (float*)h.hist.dataend);
    return {{"area", h.area}, {"largo", h.largo}, {"ancho", h.ancho}, {"proporcion", h.proporcion},
            {"angulo", h.angulo}, {"caja", {h.caja.x, h.caja.y, h.caja.x + h.caja.width, h.caja.y + h.caja.height}},
            {"contorno", c}, {"hist", hist}};
}
static bool huella_de_json(const json& j, Huella& h) {
    try {
        h.area = j.at("area");
        h.largo = j.at("largo");
        h.ancho = j.at("ancho");
        h.proporcion = j.at("proporcion");
        h.angulo = j.value("angulo", 0.0);
        auto c = j.at("caja");
        h.caja = cv::Rect(cv::Point(c[0], c[1]), cv::Point(c[2], c[3]));
        for (auto& p : j.at("contorno")) h.contorno.push_back(cv::Point(p[0], p[1]));
        std::vector<float> hist = j.at("hist").get<std::vector<float>>();
        if (hist.size() == 128) h.hist = cv::Mat(16, 8, CV_32F, hist.data()).clone();
        return h.contorno.size() >= 3;
    } catch (...) {
        return false;
    }
}

// ====================================================================== memoria
Memoria::Memoria() { recargar(); }

void Memoria::recargar() {
    std::lock_guard<std::mutex> lk(mx_);
    clases_ = util::leer_lineas(dir_mem() + "/clases.txt");
    ejemplos_.clear();
    for (auto& cl : clases_) {
        std::string d = dir_mem() + "/" + util::slug(cl);
        for (auto& f : util::listar(d)) {
            if (f.size() < 5 || f.substr(f.size() - 5) != ".json") continue;
            Huella h;
            if (huella_de_json(util::cargar_json(d + "/" + f), h)) ejemplos_.push_back({cl, h});
        }
    }
}

std::map<std::string, int> Memoria::resumen() const {
    std::lock_guard<std::mutex> lk(mx_);
    std::map<std::string, int> r;
    for (auto& e : ejemplos_) r[e.clase]++;
    return r;
}

void Memoria::guardar_clases() {
    std::string t;
    for (auto& c : clases_) t += c + "\n";
    util::escribir_texto(dir_mem() + "/clases.txt", t);
}

int Memoria::indice(const std::string& clase) {
    for (size_t i = 0; i < clases_.size(); i++)
        if (clases_[i] == clase) return (int)i;
    clases_.push_back(clase);
    guardar_clases();
    return (int)clases_.size() - 1;
}

static bool segmentar_en_recorte(const cv::Mat& img, cv::Rect caja, const cv::Mat& fondo, const cv::Mat& mascara,
                                 std::vector<cv::Point>& out, double dif = 30) {
    caja &= cv::Rect(0, 0, img.cols, img.rows);
    if (caja.width < 8 || caja.height < 8) return false;
    cv::Mat rec = img(caja), m;
    if (!fondo.empty() && fondo.size() == img.size()) {
        cv::Mat a, b, d;
        cv::GaussianBlur(rec, a, cv::Size(5, 5), 0);
        cv::GaussianBlur(fondo(caja), b, cv::Size(5, 5), 0);
        cv::absdiff(a, b, d);
        std::vector<cv::Mat> ch;
        cv::split(d, ch);
        cv::threshold(cv::max(cv::max(ch[0], ch[1]), ch[2]), m, dif, 255, cv::THRESH_BINARY);
    } else {
        cv::Mat g;
        cv::cvtColor(rec, g, cv::COLOR_BGR2GRAY);
        cv::GaussianBlur(g, g, cv::Size(5, 5), 0);
        std::vector<uchar> borde;
        for (int x = 0; x < g.cols; x++) {
            borde.push_back(g.at<uchar>(0, x));
            borde.push_back(g.at<uchar>(g.rows - 1, x));
        }
        for (int y = 0; y < g.rows; y++) {
            borde.push_back(g.at<uchar>(y, 0));
            borde.push_back(g.at<uchar>(y, g.cols - 1));
        }
        std::nth_element(borde.begin(), borde.begin() + borde.size() / 2, borde.end());
        cv::Mat d;
        cv::absdiff(g, cv::Scalar(borde[borde.size() / 2]), d);
        cv::threshold(d, m, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);
    }
    if (!mascara.empty()) m.setTo(0, mascara(caja));
    cv::morphologyEx(m, m, cv::MORPH_CLOSE, cv::Mat::ones(7, 7, CV_8U));
    double mej = 30;
    bool hay = false;
    for (auto& c : contornos(m)) {
        double a = cv::contourArea(c);
        if (a > mej) {
            mej = a;
            out = c;
            hay = true;
        }
    }
    if (!hay) return false;
    for (auto& p : out) p += caja.tl();
    return true;
}

void Memoria::guardar_dataset(const cv::Mat& img, const std::vector<std::pair<int, cv::Rect>>& et) {
    std::string n = util::fecha_archivo() + fmt("_%03d", (int)(std::fmod(util::epoch(), 1.0) * 1000));
    util::crear_dirs(dir_data() + "/images");
    util::crear_dirs(dir_data() + "/labels");
    cv::imwrite(dir_data() + "/images/" + n + ".jpg", img, {cv::IMWRITE_JPEG_QUALITY, 92});
    std::string t;
    double W = img.cols, H = img.rows;
    for (auto& e : et) {
        cv::Rect r = e.second;
        t += fmt("%d %.6f %.6f %.6f %.6f\n", e.first, (r.x + r.width / 2.0) / W, (r.y + r.height / 2.0) / H,
                 r.width / W, r.height / H);
    }
    util::escribir_texto(dir_data() + "/labels/" + n + ".txt", t);
    std::string cl;
    for (auto& c : clases_) cl += c + "\n";
    util::escribir_texto(dir_data() + "/clases.txt", cl);
}

bool Memoria::ensenar(const cv::Mat& img, const cv::Rect& caja, const std::string& clase, const cv::Mat& fondo,
                      const cv::Mat& mascara, double mm_por_px, Det& det, std::string& msg) {
    std::vector<cv::Point> c;
    if (!segmentar_en_recorte(img, caja, fondo, mascara, c)) {
        msg = "no encontre una pieza dentro de la sombra (toma el fondo vacio con 'f')";
        return false;
    }
    Huella h = calcular_huella(img, c);
    std::lock_guard<std::mutex> lk(mx_);
    int idx = indice(clase);
    std::string d = dir_mem() + "/" + util::slug(clase);
    util::crear_dirs(d);
    int n = 1;
    for (auto& f : util::listar(d))
        if (f.size() > 5 && f.substr(f.size() - 5) == ".json") n++;
    std::string base = d + fmt("/%03d", n);
    cv::imwrite(base + ".jpg", img(h.caja & cv::Rect(0, 0, img.cols, img.rows)));
    json j = huella_json(h);
    if (mm_por_px > 0) {
        j["largo_mm"] = std::round(h.largo * mm_por_px * 10) / 10;
        j["ancho_mm"] = std::round(h.ancho * mm_por_px * 10) / 10;
    }
    util::guardar_json(base + ".json", j);
    guardar_dataset(img, {{idx, h.caja}});
    ejemplos_.push_back({clase, h});
    det.clase = clase;
    det.conf = 1.f;
    det.caja = h.caja;
    det.contorno = c;
    det.angulo = (float)h.angulo;
    msg = fmt("aprendi '%s' ejemplo %d", clase.c_str(), n);
    if (mm_por_px > 0) msg += fmt(" (%.0f x %.0f mm)", h.largo * mm_por_px, h.ancho * mm_por_px);
    return true;
}

std::vector<std::vector<cv::Point>> Memoria::candidatos(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& mascara,
                                                        double dif, double area_min) {
    if (!fondo.empty() && fondo.size() == img.size()) return segmentar_fondo(img, fondo, dif, area_min, mascara);
    // sin fondo: bordes (gasta un poco mas y es menos limpio)
    cv::Mat g, e;
    cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
    cv::GaussianBlur(g, g, cv::Size(5, 5), 0);
    cv::Canny(g, e, 40, 110);
    if (!mascara.empty()) e.setTo(0, mascara);
    cv::dilate(e, e, cv::Mat::ones(5, 5, CV_8U), cv::Point(-1, -1), 2);
    cv::erode(e, e, cv::Mat::ones(3, 3, CV_8U));
    std::vector<std::vector<cv::Point>> r;
    for (auto& c : contornos(e))
        if (cv::contourArea(c) >= area_min) r.push_back(c);
    return r;
}

std::vector<Det> Memoria::buscar(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& mascara, double umbral,
                                 double dif, double area_min) {
    std::vector<Det> res;
    std::lock_guard<std::mutex> lk(mx_);
    if (ejemplos_.empty()) return res;
    auto cands = candidatos(img, fondo, mascara, dif, area_min);
    if (cands.size() > 20) cands.resize(20);
    for (auto& c : cands) {
        Huella h = calcular_huella(img, c);
        std::map<std::string, double> mejor;
        for (auto& e : ejemplos_) {
            double s = parecido(h, e.h);
            if (s > mejor[e.clase]) mejor[e.clase] = s;
        }
        std::string cl;
        double s = 0;
        for (auto& kv : mejor)
            if (kv.second > s) {
                s = kv.second;
                cl = kv.first;
            }
        if (s >= umbral) {
            Det d;
            d.clase = cl;
            d.conf = (float)s;
            d.caja = h.caja;
            d.contorno = c;
            d.angulo = (float)h.angulo;
            res.push_back(d);
        }
    }
    return res;
}

int Memoria::confirmar(const cv::Mat& img, const std::vector<Det>& dets) {
    std::lock_guard<std::mutex> lk(mx_);
    std::vector<std::pair<int, cv::Rect>> et;
    for (auto& d : dets)
        for (size_t i = 0; i < clases_.size(); i++)
            if (clases_[i] == d.clase) et.push_back({(int)i, d.caja});
    if (!et.empty()) guardar_dataset(img, et);
    return (int)et.size();
}

bool Memoria::olvidar(const std::string& clase) {
    {
        std::lock_guard<std::mutex> lk(mx_);
        auto it = std::find(clases_.begin(), clases_.end(), clase);
        if (it == clases_.end()) return false;
        clases_.erase(it);   // los archivos no se borran (por seguridad), solo deja de usarlos
        guardar_clases();
    }
    recargar();
    return true;
}
