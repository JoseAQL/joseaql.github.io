// util.hpp - rutas, registro, JSON y archivos. C++14 (gcc 7.5 de JetPack 4.6).
#pragma once

#include <chrono>
#include <mutex>
#include <string>
#include <vector>

#include "json.hpp"

using json = nlohmann::json;

namespace util {

// carpeta del proyecto (donde esta config.json). Se fija al arrancar.
void fijar_base(const std::string& b);
const std::string& base();
std::string ruta(const std::string& rel);

std::string socket_path();

// tiempo
double ahora();                 // segundos (reloj monotono)
double epoch();                 // segundos desde 1970
std::string hora();             // "HH:MM:SS"
std::string fecha_archivo();    // "YYYYmmdd_HHMMSS"
void dormir(double s);

// registro (consola + ultimos 200 en memoria)
void log(const std::string& msg);
std::vector<std::string> ultimos_log(size_t n);
std::string fmt(const char* f, ...);

// archivos
bool existe(const std::string& p);
bool es_dir(const std::string& p);
bool crear_dirs(const std::string& p);
std::vector<std::string> listar(const std::string& dir);   // nombres, ordenados
std::string leer_texto(const std::string& p);
bool escribir_texto(const std::string& p, const std::string& t);
std::string dir_de(const std::string& p);
std::vector<std::string> leer_lineas(const std::string& p);

json cargar_json(const std::string& p, const json& defecto = json::object());
bool guardar_json(const std::string& p, const json& j);
void fusionar(json& a, const json& b);
json cargar_config();

bool en_jetson();
void preparar_display(const std::string& disp);
std::string slug(const std::string& s);

// cronometro simple
struct Crono {
    double t0;
    Crono() : t0(ahora()) {}
    double ms() const { return (ahora() - t0) * 1000.0; }
    double s() const { return ahora() - t0; }
};

}  // namespace util
