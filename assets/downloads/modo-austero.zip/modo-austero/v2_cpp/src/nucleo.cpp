#include "nucleo.hpp"

#include <signal.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include <algorithm>
#include <cmath>
#include <iostream>
#include <thread>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "bench.hpp"
#include "web.hpp"

using util::fmt;
using util::log;

static const cv::Scalar COLORES[] = {{0, 220, 255}, {80, 255, 80}, {255, 160, 60}, {255, 80, 200}, {60, 120, 255}, {200, 255, 255}};
static cv::Scalar color_de(const std::string& s) {
    unsigned h = 0;
    for (unsigned char c : s) h += c;
    return COLORES[h % 6];
}

static bool on(const json& m, bool defecto) {
    if (!m.contains("on") || m["on"].is_null()) return defecto;
    if (m["on"].is_boolean()) return m["on"];
    if (m["on"].is_number()) return m["on"].get<double>() != 0;
    std::string v = m["on"];
    return v == "1" || v == "on" || v == "si" || v == "sí" || v == "true" || v == "prender" || v == "encender";
}
static json R(bool ok, const std::string& msg = "") { return {{"ok", ok}, {"msg", msg}}; }

// ====================================================================== arranque
Nucleo::Nucleo() {
    cfg = util::cargar_config();
    cam.reset(new Camara(cfg["camara"]));
    bool sim = cfg["camara"].value("tipo", "usb") == "sim" || cfg["proyector"].value("simulado", false);
    proy.reset(new Proyector(cfg["proyector"], sim));
    Proyector* p = proy.get();
    cam->imagen_proyector = [p]() { return p->imagen_actual(); };
    json fp = cfg.value("filtros", json::object());
    util::fusionar(fp, util::cargar_json(util::ruta("perfiles/filtros.json")));
    filtros.reset(new Filtros(fp));
    calib.reset(new Calibracion(*cam, *proy, cfg["calibracion"]));
    ctx.memoria = &memoria;
    ancho_proc = cfg["camara"].value("ancho_proceso", 640);
    escala = cam->ancho / (double)ancho_proc;
    alto_proc = (int)std::round(cam->alto / escala);
}
Nucleo::~Nucleo() {}

void Nucleo::iniciar() {
    log(fmt("Modo Austero C++ iniciando (camara %s %dx%d, proceso %dx%d, TensorRT %s, jetson-inference %s)",
            cam->tipo.c_str(), cam->ancho, cam->alto, ancho_proc, alto_proc, hay_tensorrt() ? "si" : "no",
            hay_jetson_inference() ? "si" : "no"));
    stats.iniciar();
    if (!cam->iniciar()) log("sin camara; el nucleo sigue para que puedas revisar con 'austero status'");
    std::thread(&Nucleo::servidor, this).detach();
    if (cfg["proyector"].value("habilitado", true)) proy->encender();
    cv::Mat img;
    long n;
    cam->esperar_nuevo(0, img, n, 3.0);
    if (cfg["autoajuste"].value("al_iniciar", false)) cmd({{"cmd", "autoajuste"}});
    if (proy->encendido && cfg["calibracion"].value("automatica_al_iniciar", true))
        cmd({{"cmd", "calibrar"}, {"metodo", cfg["calibracion"].value("metodo", "aruco")}});
    json ini = cfg.value("inicio", json::object());
    if (ini.value("modelo", "") != "") log(cmd({{"cmd", "modelo"}, {"id", ini.value("modelo", "")}}).value("msg", ""));
    if (ini.value("manos", false)) cmd({{"cmd", "manos"}, {"on", true}});
    if (ini.value("web", false)) cmd({{"cmd", "web"}, {"on", true}});
    buscar = ini.value("buscar", false);
    std::string png = util::ruta("perfiles/marcador_mm.png");
    if (!util::existe(png))
        guardar_marcador_impreso(png, cfg["calibracion"].value("/marcador_mm/id"_json_pointer, 49),
                                 cfg["calibracion"].value("/marcador_mm/lado_mm"_json_pointer, 50));
    t_verif_ = util::ahora();
}

void Nucleo::cerrar() {
    log("apagando...");
    vivo = false;
    if (modelo) modelo->liberar();
    modelo.reset();
    if (manos) manos->liberar();
    manos.reset();
    if (web) web->detener();
    web.reset();
    proy->apagar();
    cam->detener();
    stats.detener();
    if (srv_fd_ >= 0) close(srv_fd_);
    unlink(util::socket_path().c_str());
}

// ====================================================================== socket de control
void Nucleo::servidor() {
    std::string sp = util::socket_path();
    unlink(sp.c_str());
    srv_fd_ = socket(AF_UNIX, SOCK_STREAM, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, sp.c_str(), sizeof(a.sun_path) - 1);
    if (bind(srv_fd_, (sockaddr*)&a, sizeof a) != 0 || listen(srv_fd_, 8) != 0) {
        log("no pude abrir el socket " + sp);
        return;
    }
    chmod(sp.c_str(), 0660);
    while (vivo) {
        int c = accept(srv_fd_, nullptr, nullptr);
        if (c < 0) {
            util::dormir(0.05);
            continue;
        }
        std::thread([this, c]() {
            std::string datos;
            char buf[65536];
            while (datos.empty() || datos.back() != '\n') {
                ssize_t k = recv(c, buf, sizeof buf, 0);
                if (k <= 0) break;
                datos.append(buf, k);
            }
            json resp;
            try {
                resp = atender(json::parse(datos.empty() ? "{}" : datos));
            } catch (const std::exception& e) {
                resp = R(false, e.what());
            }
            std::string s = resp.dump(-1, ' ', false, json::error_handler_t::replace) + "\n";
            size_t env = 0;
            while (env < s.size()) {
                ssize_t k = send(c, s.data() + env, s.size() - env, MSG_NOSIGNAL);
                if (k <= 0) break;
                env += k;
            }
            close(c);
        }).detach();
    }
}

// solo-lectura se contesta aqui; lo demas pasa por la cola del hilo principal
json Nucleo::atender(const json& msg) {
    std::string c = msg.value("cmd", "estado");
    if (c == "estado") return {{"ok", true}, {"estado", estado()}};
    if (c == "log") return {{"ok", true}, {"log", util::ultimos_log(msg.value("n", 20))}};
    if (c == "vista") {
        t_vista = util::ahora();
        vista_w = msg.value("w", 80);
        vista_h = msg.value("h", 40);
        std::lock_guard<std::mutex> lk(vista_mx);
        if (vista_buf.empty()) return {{"ok", true}, {"vista", nullptr}};
        std::vector<uchar> b(vista_buf.datastart, vista_buf.dataend);
        // base64 sencillo
        static const char* T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        std::string s;
        s.reserve(b.size() * 4 / 3 + 4);
        for (size_t i = 0; i < b.size(); i += 3) {
            unsigned v = b[i] << 16 | (i + 1 < b.size() ? b[i + 1] << 8 : 0) | (i + 2 < b.size() ? b[i + 2] : 0);
            s += T[(v >> 18) & 63];
            s += T[(v >> 12) & 63];
            s += i + 1 < b.size() ? T[(v >> 6) & 63] : '=';
            s += i + 2 < b.size() ? T[v & 63] : '=';
        }
        return {{"ok", true}, {"vista", {{"w", vista_buf.cols}, {"h", vista_buf.rows}, {"bgr", s}}}};
    }
    auto p = std::make_shared<Pedido>();
    p->msg = msg;
    std::unique_lock<std::mutex> lk(cola_mx_);
    cola_.push_back(p);
    double tmax = msg.value("timeout", 900.0);
    if (!cola_cv_.wait_for(lk, std::chrono::milliseconds((long long)(tmax * 1000)), [&] { return p->listo; }))
        return R(false, "sin respuesta (ocupado: " + ocupado + ")");
    return p->resp;
}

void Nucleo::procesar_cola() {
    while (true) {
        std::shared_ptr<Pedido> p;
        {
            std::lock_guard<std::mutex> lk(cola_mx_);
            if (cola_.empty()) return;
            p = cola_.front();
            cola_.pop_front();
        }
        json r;
        try {
            ocupado = p->msg.value("cmd", "");
            r = cmd(p->msg);
        } catch (const std::exception& e) {
            r = R(false, p->msg.value("cmd", "") + ": " + e.what());
        }
        ocupado.clear();
        if (r.value("msg", "") != "") log(r.value("msg", ""));
        {
            std::lock_guard<std::mutex> lk(cola_mx_);
            p->resp = r;
            p->listo = true;
        }
        cola_cv_.notify_all();
    }
}

// ====================================================================== estado
json Nucleo::estado() {
    Muestra s = stats.foto();
    json j;
    j["fps"] = std::round(fps * 10) / 10;
    j["lat_ms"] = std::round(lat_ms * 10) / 10;
    double p95 = 0;
    {
        std::vector<double> v(lat_hist.begin(), lat_hist.end());
        if (!v.empty()) {
            std::sort(v.begin(), v.end());
            p95 = v[(size_t)(0.95 * (v.size() - 1))];
        }
    }
    j["lat_p95"] = std::round(p95 * 10) / 10;
    j["fps_camara"] = std::round(cam->fps_cap * 10) / 10;
    j["camara_ok"] = cam->ok;
    Modelo* m = modelo.get();
    j["modelo"] = m ? json(m->id()) : json(nullptr);
    j["modelo_nombre"] = m ? m->nombre() : "ninguno";
    j["motor"] = m ? m->motor : "";
    j["params"] = m ? m->params_json() : json::object();
    j["modelo_error"] = m ? m->error : "";
    j["filtros"] = filtros->params();
    j["manos"] = manos && manos->ok;
    j["n_manos"] = manos_res.size();
    j["web"] = web ? json(web->url) : json(nullptr);
    j["proyector"] = (bool)proy->encendido;
    j["buscar"] = buscar;
    j["fondo"] = !ctx.fondo.empty();
    j["calib"] = {{"lista", calib->lista()}, {"metodo", calib->metodo},
                  {"error_px", calib->error_px >= 0 ? json(calib->error_px) : json(nullptr)},
                  {"px_por_mm", calib->px_por_mm > 0 ? json(calib->px_por_mm) : json(nullptr)}};
    if (ens.activo)
        j["ensenando"] = {{"clase", ens.clase},
                          {"sombra", {{"x", ens.sombra.x}, {"y", ens.sombra.y}, {"w", ens.sombra.w}, {"h", ens.sombra.h}}},
                          {"propuesta", ens.propuesta}};
    else
        j["ensenando"] = nullptr;
    json mem = json::object();
    for (auto& kv : memoria.resumen()) mem[kv.first] = kv.second;
    j["memoria"] = mem;
    json dd = json::array();
    {
        std::lock_guard<std::mutex> lk(dets_mx);
        for (size_t i = 0; i < dets.size() && i < 12; i++) dd.push_back(det_json(dets[i]));
    }
    j["dets"] = dd;
    j["stats"] = s.a_json();
    j["ocupado"] = ocupado;
    j["log"] = util::ultimos_log(6);
    json cat = json::array();
    for (auto& c : catalogo()) cat.push_back({{"tecla", c.tecla}, {"id", c.id}, {"nombre", c.nombre}});
    j["catalogo"] = cat;
    j["motor_nucleo"] = "C++";
    return j;
}

// ====================================================================== lazo principal
cv::Mat Nucleo::procesar_cuadro(const cv::Mat& img) {
    cv::Mat p;
    cv::resize(img, p, cv::Size(ancho_proc, alto_proc), 0, 0, cv::INTER_AREA);
    filtros->aplicar(p);
    return p;
}

void Nucleo::correr() {
    while (vivo) {   // el lazo nunca se cae por un error: lo registra y sigue
        try {
            lazo();
        } catch (const std::exception& e) {
            log(std::string("error en el lazo: ") + e.what() + " (sigo)");
            util::dormir(0.5);
        }
    }
}

void Nucleo::lazo() {
    long n_prev = 0;
    double t0 = util::ahora(), fps_max = cfg["camara"].value("fps_max", 0.0);
    int cuenta = 0;
    while (vivo) {
        procesar_cola();
        if (!cam->vivo) {
            util::dormir(0.1);
            proy->actualizar();
            continue;
        }
        cv::Mat img;
        long n;
        if (!cam->esperar_nuevo(n_prev, img, n, 0.5) || n == n_prev) {
            proy->actualizar();
            continue;
        }
        n_prev = n;
        util::Crono cr;
        cv::Mat proc = procesar_cuadro(img);
        ultimo_proc = proc;
        actualizar_mascara();
        std::vector<Det> d;
        if (modelo && modelo->ok) {
            try {
                d = modelo->procesar(proc);
            } catch (const std::exception& e) {
                log("modelo " + modelo->id() + " fallo: " + e.what());
                modelo->ok = false;
            }
        }
        if (buscar && (!modelo || modelo->id() != "ejemplos") && !memoria.vacia()) {
            auto b = memoria.buscar(proc, ctx.fondo, ctx.mascara_proy);
            d.insert(d.end(), b.begin(), b.end());
        }
        {
            std::lock_guard<std::mutex> lk(dets_mx);
            dets = d;
        }
        if (manos && manos->ok) manos_res = manos->procesar(proc);
        double lat = cr.ms();
        lat_ms = lat_ms > 0 ? 0.8 * lat_ms + 0.2 * lat : lat;
        lat_hist.push_back(lat);
        while (lat_hist.size() > 120) lat_hist.pop_front();
        salida_proyector();
        salidas_visuales(proc);
        proy->actualizar();
        cuenta++;
        double t = util::ahora();
        if (t - t0 >= 1.0) {
            fps = cuenta / (t - t0);
            t0 = t;
            cuenta = 0;
        }
        verificacion_periodica();
        if (fps_max > 0) util::dormir(1.0 / fps_max - cr.s());
    }
}

void Nucleo::actualizar_mascara() {
    if (!(proy->encendido && calib->lista())) {
        ctx.mascara_proy.release();
        return;
    }
    cv::Mat img = proy->imagen_actual();
    if (proy->version() == proy_version_) return;
    proy_version_ = proy->version();
    cv::Mat g;
    cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
    double mx;
    cv::minMaxLoc(g, nullptr, &mx);
    if (mx < 10) {
        ctx.mascara_proy.release();
        return;
    }
    cv::Mat S = cv::Mat::diag(cv::Mat(cv::Vec3d(1.0 / escala, 1.0 / escala, 1.0)));
    cv::Mat H = S * calib->H_p2c, m;
    cv::warpPerspective(g > 10, m, H, cv::Size(ancho_proc, alto_proc), cv::INTER_NEAREST);
    cv::dilate(m, ctx.mascara_proy, cv::Mat::ones(9, 9, CV_8U));
}

void Nucleo::salida_proyector() {
    if (!(proy->encendido && calib->lista())) return;
    Sombra s = ens.sombra;
    s.activa = ens.activo;
    if (ens.activo) s.texto = ens.propuesta ? "? " + ens.clase + "  (Enter = si)" : ens.clase;
    proy->poner_sombra(s);
    std::vector<Marca> marcas;
    if (marcas_proy) {
        std::lock_guard<std::mutex> lk(dets_mx);
        for (size_t i = 0; i < dets.size() && i < 12; i++) {
            const Det& d = dets[i];
            std::vector<cv::Point2f> pts;
            if (!d.contorno.empty()) {
                size_t paso = std::max<size_t>(1, d.contorno.size() / 40);
                for (size_t k = 0; k < d.contorno.size(); k += paso) pts.push_back(d.contorno[k]);
            } else {
                pts = {d.caja.tl(), cv::Point2f(d.caja.br().x, d.caja.y), d.caja.br(), cv::Point2f(d.caja.x, d.caja.br().y)};
            }
            Marca m;
            for (auto& q : calib->cam_a_proy(pts, escala))   // redondeo a 4 px: no redibujar por ruido
                m.pts.push_back(cv::Point((int)std::round(q.x / 4) * 4, (int)std::round(q.y / 4) * 4));
            m.color = color_de(d.clase);
            m.texto = d.conf < 0.999f ? fmt("%s %.0f%%", d.clase.c_str(), d.conf * 100) : d.clase;
            marcas.push_back(m);
        }
    }
    proy->poner_marcas(marcas);
}

cv::Mat Nucleo::anotar(const cv::Mat& img) {
    cv::Mat out = img.clone();
    {
        std::lock_guard<std::mutex> lk(dets_mx);
        for (auto& d : dets) {
            cv::Scalar c = color_de(d.clase);
            if (!d.contorno.empty())
                cv::drawContours(out, std::vector<std::vector<cv::Point>>{d.contorno}, -1, c, 2);
            else
                cv::rectangle(out, d.caja, c, 2);
            std::string t = d.conf < 0.999f ? fmt("%s %.0f%%", d.clase.c_str(), d.conf * 100) : d.clase;
            cv::putText(out, t, cv::Point(d.caja.x, std::max(12, d.caja.y - 4)), cv::FONT_HERSHEY_SIMPLEX, 0.45, c, 1);
        }
    }
    for (auto& m : manos_res)
        for (auto& p : m.puntos)
            if (p.x >= 0) cv::circle(out, p, 3, cv::Scalar(0, 255, 0), -1);
    if (ens.activo) {
        cv::Rect r = sombra_en_cam();
        cv::rectangle(out, r, cv::Scalar(0, 220, 255), 2);
    }
    return out;
}

void Nucleo::salidas_visuales(const cv::Mat& proc) {
    double t = util::ahora();
    bool v = t - t_vista < 3.0, w = web && t - t_web < 3.0;
    if (!v && !w) return;   // nadie esta mirando: no se dibuja nada
    cv::Mat an = anotar(proc);
    std::lock_guard<std::mutex> lk(vista_mx);
    if (w) anotada = an;
    if (v) cv::resize(an, vista_buf, cv::Size(std::max(8, vista_w), std::max(8, vista_h * 2)), 0, 0, cv::INTER_AREA);
}

void Nucleo::verificacion_periodica() {
    double cada = cfg["calibracion"].value("verificar_cada_s", 0.0);
    if (cada <= 0 || !(proy->encendido && calib->lista()) || ens.activo) return;
    if (util::ahora() - t_verif_ < cada) return;
    t_verif_ = util::ahora();
    double e = calib->verificar();
    if (e > cfg["calibracion"].value("tolerancia_px", 8.0) && cfg["calibracion"].value("recalibrar_si_falla", true)) {
        log(fmt("la camara o el proyector se movieron (%.1f px): recalibrando...", e));
        cmd({{"cmd", "calibrar"}});
    }
}

// ====================================================================== ensenar
cv::Rect Nucleo::sombra_en_cam() {
    Sombra& s = ens.sombra;
    if (!calib->lista()) return cv::Rect(s.x, s.y, s.w, s.h);
    auto pc = calib->proy_a_cam({cv::Point2f(s.x, s.y), cv::Point2f(s.x + s.w, s.y), cv::Point2f(s.x + s.w, s.y + s.h),
                                 cv::Point2f(s.x, s.y + s.h)},
                                escala);
    return cv::boundingRect(pc);
}

json Nucleo::auto_sombra() {
    if (ultimo_proc.empty()) return R(false, "sin imagen");
    auto cs = memoria.candidatos(ultimo_proc, ctx.fondo, ctx.mascara_proy);
    if (cs.empty()) return R(false, "no veo nada nuevo sobre la mesa (toma el fondo vacio con 'f')");
    auto c = *std::max_element(cs.begin(), cs.end(), [](const std::vector<cv::Point>& a, const std::vector<cv::Point>& b) {
        return cv::contourArea(a) < cv::contourArea(b);
    });
    cv::Rect r = cv::boundingRect(c);
    int m = 12;
    r = cv::Rect(r.x - m, r.y - m, r.width + 2 * m, r.height + 2 * m);
    if (calib->lista()) {
        auto pp = calib->cam_a_proy({r.tl(), cv::Point2f(r.br().x, r.y), r.br(), cv::Point2f(r.x, r.br().y)}, escala);
        cv::Rect q = cv::boundingRect(pp);
        ens.sombra.x = q.x;
        ens.sombra.y = q.y;
        ens.sombra.w = q.width;
        ens.sombra.h = q.height;
    } else {
        ens.sombra.x = r.x;
        ens.sombra.y = r.y;
        ens.sombra.w = r.width;
        ens.sombra.h = r.height;
    }
    ens.propuesta = true;
    return R(true, "propuesta: ¿es ahi? Enter = guardar, flechas = corregir");
}

// ====================================================================== comandos (hilo principal)
json Nucleo::cmd(const json& m) {
    std::string c = m.value("cmd", "");
    if (c == "apagar") {
        vivo = false;
        return R(true, "apagado");
    }
    if (c == "estado") return {{"ok", true}, {"estado", estado()}};
    if (c == "modelo") {
        std::string id = m.contains("id") ? (m["id"].is_string() ? m["id"].get<std::string>() : m["id"].dump()) : "0";
        if (modelo) modelo->liberar();
        modelo.reset();
        if (id == "0" || id == "ninguno" || id.empty()) return R(true, "sin modelo (solo camara)");
        auto mm = crear_modelo(id, ctx);
        if (!mm) return R(false, "no existe el modelo '" + id + "'");
        json g = util::cargar_json(util::ruta("perfiles/params_" + mm->id() + ".json"));
        for (auto it = g.begin(); it != g.end(); ++it)
            if (it.value().is_number()) mm->poner(it.key(), it.value());
        std::string w;
        if (!mm->disponible(w)) return R(false, mm->id() + " no disponible: " + w);
        util::Crono cr;
        if (!mm->cargar()) return R(false, mm->id() + " no cargo: " + mm->error);
        std::string nid = mm->id();
        modelo = std::move(mm);
        if ((nid == "fondo" || nid == "orientacion" || nid == "ejemplos") && ctx.fondo.empty()) cmd({{"cmd", "fondo"}});
        return R(true, fmt("modelo %s listo en %.1f s (%s)", nid.c_str(), cr.s(), modelo->motor.empty() ? "CPU" : modelo->motor.c_str()));
    }
    if (c == "param") {
        if (!modelo) return R(false, "no hay modelo activo");
        std::string k = m.value("k", "");
        if (!modelo->p.count(k)) {
            std::string hay;
            for (auto& kv : modelo->p) hay += kv.first + " ";
            return R(false, "parametro '" + k + "' no existe en " + modelo->id() + " (hay: " + hay + ")");
        }
        double v;
        if (m.contains("delta") && !m["delta"].is_null()) {
            double d = m["delta"].is_string() ? std::atof(m["delta"].get<std::string>().c_str()) : m["delta"].get<double>();
            if (k == "entrada") {
                auto t = modelo->tamanos();
                if (t.empty()) return R(false, "este modelo no cambia de tamano");
                auto it = std::find(t.begin(), t.end(), (int)modelo->p[k]);
                int i = it == t.end() ? 0 : (int)(it - t.begin());
                i = std::max(0, std::min((int)t.size() - 1, i + (d > 0 ? 1 : -1)));
                v = t[i];
            } else {
                v = modelo->p[k] + d;
                if ((k == "umbral" || k == "nms") && modelo->p[k] <= 1.0) v = std::max(0.01, std::min(0.99, v));
            }
        } else {
            v = m["v"].is_string() ? std::atof(m["v"].get<std::string>().c_str()) : m["v"].get<double>();
        }
        modelo->poner(k, v);
        util::guardar_json(util::ruta("perfiles/params_" + modelo->id() + ".json"), modelo->params_json());
        return R(true, fmt("%s.%s = %g", modelo->id().c_str(), k.c_str(), modelo->p[k]));
    }
    if (c == "filtro") {
        std::string k = m.value("k", "");
        double v;
        if (m.contains("delta") && !m["delta"].is_null()) {
            double d = m["delta"].is_string() ? std::atof(m["delta"].get<std::string>().c_str()) : m["delta"].get<double>();
            if (k == "suavizado") {
                int s = (int)filtros->get(k);
                v = d > 0 ? (s < 3 ? 3 : s + 2) : (s <= 3 ? 0 : s - 2);
            } else {
                v = std::max(0.0, filtros->get(k) + d);
            }
        } else {
            v = m["v"].is_string() ? std::atof(m["v"].get<std::string>().c_str()) : m["v"].get<double>();
        }
        if (!filtros->poner(k, v)) return R(false, "filtros: gamma, clahe, suavizado (kernel), nitidez");
        util::guardar_json(util::ruta("perfiles/filtros.json"), filtros->params());
        return R(true, fmt("filtro %s = %g", k.c_str(), filtros->get(k)));
    }
    if (c == "autoajuste") {
        std::string t = autoajuste(*cam, *filtros, cfg["autoajuste"].value("brillo_objetivo", 115.0),
                                   cfg["autoajuste"].value("max_saturados", 0.01));
        util::guardar_json(util::ruta("perfiles/filtros.json"), filtros->params());
        return R(true, t);
    }
    if (c == "calibrar") {
        std::string met = m.value("metodo", json(nullptr)).is_string() ? m["metodo"].get<std::string>()
                                                                          : cfg["calibracion"].value("metodo", "aruco");
        bool ok = calib->calibrar(met);
        proy_version_ = -1;
        return R(ok, "calibracion " + met + (ok ? ": lista" : ": fallo"));
    }
    if (c == "verificar") {
        double e = calib->verificar();
        return R(e >= 0, e >= 0 ? fmt("error %.1f px", e) : "no se pudo verificar");
    }
    if (c == "mm") {
        bool ok = calib->medir_mm();
        if (ok) calib->guardar();
        return R(ok);
    }
    if (c == "proyector") {
        if (on(m, !proy->encendido)) {
            bool ok = proy->encender();
            return R(ok, ok ? "proyector encendido" : "no pude abrir el proyector");
        }
        proy->apagar();
        return R(true, "proyector apagado");
    }
    if (c == "marcas") {
        marcas_proy = on(m, !marcas_proy);
        return R(true, std::string("marcas en proyector: ") + (marcas_proy ? "on" : "off"));
    }
    if (c == "manos") {
        bool quiere = on(m, !(manos && manos->ok));
        if (manos) manos->liberar();
        manos.reset();
        manos_res.clear();
        if (!quiere) return R(true, "manos apagadas");
        manos.reset(new Manos());
        if (!manos->cargar()) {
            std::string e = manos->error;
            manos.reset();
            return R(false, "manos: " + e);
        }
        return R(true, "manos encendidas (" + manos->motor + ")");
    }
    if (c == "web") {
        if (!on(m, !web)) {
            if (web) web->detener();
            web.reset();
            return R(true, "pagina web apagada");
        }
        if (web) return R(true, "web ya estaba en " + web->url);
        web.reset(new ServidorWeb(*this, cfg["web"].value("puerto", 8091)));
        if (!web->iniciar()) {
            web.reset();
            return R(false, "no pude abrir el puerto de la web");
        }
        return R(true, "pagina web en " + web->url);
    }
    if (c == "buscar") {
        buscar = on(m, !buscar);
        if (buscar && ctx.fondo.empty()) cmd({{"cmd", "fondo"}});
        return R(true, std::string("buscar piezas ensenadas: ") + (buscar ? "on" : "off"));
    }
    if (c == "fondo") {   // foto de la mesa VACIA con el proyector en negro
        bool habia = proy->hay_patron();
        if (proy->encendido) proy->poner_patron(cv::Mat::zeros(proy->h, proy->w, CV_8U));
        cv::Mat img = cam->promedio(4, 0.35);
        if (proy->encendido && !habia) proy->quitar_patron();
        if (img.empty()) return R(false, "sin imagen para el fondo");
        ctx.fondo = procesar_cuadro(img);
        cv::imwrite(util::ruta("perfiles/fondo.jpg"), ctx.fondo);
        return R(true, "fondo guardado (deja la mesa vacia cuando lo tomes)");
    }
    if (c == "ensenar") {
        std::string acc = m.value("accion", "inicio");
        int paso = calib->lista() ? 40 : 10;
        if (acc == "inicio") {
            std::string cl = m.value("clase", "");
            if (cl.empty()) return R(false, "dime el nombre: austero ensenar \"tijera mayo\"");
            ens = Ensenando();
            ens.activo = true;
            ens.clase = cl;
            if (calib->lista()) ens.sombra = {proy->w / 2 - 180, proy->h / 2 - 120, 360, 240, "", true};
            else ens.sombra = {ancho_proc / 2 - 80, alto_proc / 2 - 50, 160, 100, "", true};
            if (ctx.fondo.empty()) cmd({{"cmd", "fondo"}});
            return R(true, "ensenando '" + cl + "': flechas mueven la sombra, +/- tamano, Enter guarda, x = la camara propone");
        }
        if (!ens.activo) return R(false, "primero: austero ensenar <pieza>");
        if (acc == "mover") {
            ens.sombra.x += (int)(m.value("dx", 0.0) * paso);
            ens.sombra.y += (int)(m.value("dy", 0.0) * paso);
            ens.propuesta = false;
            return R(true);
        }
        if (acc == "tam") {
            int dw = (int)(m.value("dw", 0.0) * paso), dh = (int)(m.value("dh", 0.0) * paso);
            ens.sombra.x -= dw / 2;
            ens.sombra.y -= dh / 2;
            ens.sombra.w = std::max(paso, ens.sombra.w + dw);
            ens.sombra.h = std::max(paso, ens.sombra.h + dh);
            return R(true);
        }
        if (acc == "auto") return auto_sombra();
        if (acc == "cancelar") {
            ens.activo = false;
            Sombra s;
            proy->poner_sombra(s);
            return R(true, "ensenar terminado");
        }
        if (acc == "guardar") {
            if (ultimo_proc.empty()) return R(false, "sin imagen");
            Det d;
            std::string msg;
            double mmpx = calib->px_por_mm > 0 ? escala / calib->px_por_mm : 0;
            bool ok = memoria.ensenar(ultimo_proc, sombra_en_cam(), ens.clase, ctx.fondo, ctx.mascara_proy, mmpx, d, msg);
            ens.propuesta = false;
            if (ok) {
                std::lock_guard<std::mutex> lk(dets_mx);
                dets = {d};
            }
            return R(ok, msg);
        }
        return R(false, "acciones: inicio, mover, tam, auto, guardar, cancelar");
    }
    if (c == "confirmar") {
        if (ultimo_proc.empty()) return R(false);
        std::vector<Det> d;
        {
            std::lock_guard<std::mutex> lk(dets_mx);
            d = dets;
        }
        int n = memoria.confirmar(ultimo_proc, d);
        return R(true, fmt("foto + %d etiquetas guardadas en dataset/", n));
    }
    if (c == "olvidar") {
        bool ok = memoria.olvidar(m.value("clase", ""));
        return R(ok, ok ? "olvidada" : "no existe esa clase");
    }
    if (c == "perfil") return R(true, perfil_energia(m.value("nombre", "")));
    if (c == "foto") {
        if (ultimo_proc.empty()) return R(false, "sin imagen");
        std::string a = "perfiles/foto_" + util::fecha_archivo() + ".jpg";
        cv::imwrite(util::ruta(a), anotar(ultimo_proc));
        return R(true, "foto: " + a);
    }
    if (c == "bench") {
        std::vector<std::string> ids;
        if (m.contains("modelos") && m["modelos"].is_array())
            for (auto& x : m["modelos"]) ids.push_back(x.is_string() ? x.get<std::string>() : x.dump());
        double seg = m.contains("seg") && m["seg"].is_number() ? m["seg"].get<double>()
                                                                 : cfg["bench"].value("segundos_por_modelo", 20.0);
        return correr_bench(*this, ids, seg);
    }
    if (c == "sim") {
        if (!cam->escena) return R(false, "solo con camara simulada (austero start --sim)");
        std::string acc = m.value("accion", "revolver");
        EscenaSim& e = *cam->escena;
        if (acc == "revolver") e.revolver(m.value("n", 3));
        else if (acc == "pieza") e.pieza(m.value("tipo", "tijera"));
        else if (acc == "vaciar") {
            std::lock_guard<std::mutex> lk(e.mx);
            e.objetos.clear();
        } else if (acc == "marcador") {
            cv::Mat mk;
            cv::cvtColor(dibujar_marcador(49, (int)(50 / e.mm_por_px)), mk, cv::COLOR_GRAY2BGR);
            std::lock_guard<std::mutex> lk(e.mx);
            e.marcador = mk;
        } else if (acc == "mover_proyector") {
            for (auto& p : e.esq_proy_en_cam) p += cv::Point2f(6, 4);
        }
        return R(true, "sim " + acc);
    }
    return R(false, "comando desconocido: " + c);
}

// ====================================================================== main
static Nucleo* g_n = nullptr;
static void senal(int) {
    if (g_n) g_n->vivo = false;
}

int main(int argc, char** argv) {
    // la carpeta del proyecto: la del ejecutable/.. o la que diga AUSTERO_DIR
    std::string base = getenv("AUSTERO_DIR") ? getenv("AUSTERO_DIR") : "";
    if (base.empty()) {
        char b[4096];
        ssize_t k = readlink("/proc/self/exe", b, sizeof b - 1);
        if (k > 0) {
            b[k] = 0;
            base = util::dir_de(util::dir_de(b));
        } else {
            base = ".";
        }
    }
    util::fijar_base(base);
    util::crear_dirs(util::ruta("perfiles"));
    signal(SIGPIPE, SIG_IGN);
    Nucleo n;
    g_n = &n;
    signal(SIGTERM, senal);
    signal(SIGINT, senal);
    n.iniciar();
    n.correr();
    n.cerrar();
    return 0;
}
