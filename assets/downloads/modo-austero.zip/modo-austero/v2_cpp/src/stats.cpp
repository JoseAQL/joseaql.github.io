#include "stats.hpp"

#include <unistd.h>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <regex>
#include <sstream>

json Muestra::a_json() const {
    json t = json::object();
    for (auto& kv : temp) t[kv.first] = kv.second;
    return {{"cpu", cpu}, {"cpu_prom", cpu_prom}, {"gpu", gpu < 0 ? json(nullptr) : json(gpu)},
            {"ram_mb", ram_mb}, {"ram_total_mb", ram_total_mb}, {"swap_mb", swap_mb}, {"temp", t},
            {"potencia_mw", potencia_mw < 0 ? json(nullptr) : json(potencia_mw)}, {"proc_cpu", proc_cpu},
            {"proc_ram_mb", proc_ram_mb}, {"fuente", fuente}, {"emc", emc < 0 ? json(nullptr) : json(emc)}};
}
double Muestra::temp_max() const {
    double m = -1;
    for (auto& kv : temp)
        if (kv.first.find("PMIC") == std::string::npos && kv.first.find("thermal") == std::string::npos)
            m = std::max(m, kv.second);
    return m;
}

static bool hay(const char* cmd) {
    const char* p = getenv("PATH");
    if (!p) return false;
    std::stringstream ss(p);
    std::string d;
    while (std::getline(ss, d, ':'))
        if (access((d + "/" + cmd).c_str(), X_OK) == 0) return true;
    return false;
}

void Estadisticas::iniciar(int ms) {
    intervalo_ = ms;
    vivo_ = true;
    hilo_ = std::thread(&Estadisticas::bucle, this);
}
void Estadisticas::detener() {
    vivo_ = false;
    if (tegra_) {
        // tegrastats sigue escribiendo; cerramos el pipe y el hilo termina
        system("pkill -f 'tegrastats --interval' >/dev/null 2>&1");
    }
    if (hilo_.joinable()) hilo_.join();
    if (tegra_) pclose(tegra_);
    tegra_ = nullptr;
}
Muestra Estadisticas::foto() {
    std::lock_guard<std::mutex> lk(mx_);
    return m_;
}

void Estadisticas::bucle() {
    if (hay("tegrastats")) {
        tegra_ = popen(util::fmt("tegrastats --interval %d 2>/dev/null", intervalo_).c_str(), "r");
    }
    if (tegra_) {
        {
            std::lock_guard<std::mutex> lk(mx_);
            m_.fuente = "tegrastats";
        }
        char buf[4096];
        while (vivo_ && fgets(buf, sizeof buf, tegra_)) {
            parse_tegra(buf);
            proceso();
        }
        return;
    }
    {
        std::lock_guard<std::mutex> lk(mx_);
        m_.fuente = "/proc";
    }
    while (vivo_) {
        leer_proc();
        proceso();
        for (int i = 0; i < intervalo_ / 50 && vivo_; i++) util::dormir(0.05);
    }
}

void Estadisticas::parse_tegra(const std::string& l) {
    static const std::regex r_ram(R"(RAM (\d+)/(\d+)MB)"), r_swap(R"(SWAP (\d+)/(\d+)MB)"), r_cpu(R"(CPU \[([^\]]*)\])"),
        r_c1(R"((\d+)%@(\d+))"), r_gpu(R"(GR3D_FREQ (\d+)%(?:@(\d+))?)"), r_emc(R"(EMC_FREQ (\d+)%)"),
        r_t(R"((\w+)@(-?[\d.]+)C)"), r_pot(R"((?:POM_5V_IN|VDD_IN) (\d+)(?:mW)?/(\d+))");
    Muestra m = foto();
    std::smatch s;
    if (std::regex_search(l, s, r_ram)) {
        m.ram_mb = std::stoi(s[1]);
        m.ram_total_mb = std::stoi(s[2]);
    }
    if (std::regex_search(l, s, r_swap)) m.swap_mb = std::stoi(s[1]);
    if (std::regex_search(l, s, r_cpu)) {
        m.cpu.clear();
        std::string c = s[1];
        std::stringstream ss(c);
        std::string t;
        while (std::getline(ss, t, ',')) {
            std::smatch q;
            m.cpu.push_back(std::regex_search(t, q, r_c1) ? std::stoi(q[1]) : 0);
        }
        double sum = 0;
        for (int v : m.cpu) sum += v;
        m.cpu_prom = m.cpu.empty() ? 0 : sum / m.cpu.size();
    }
    if (std::regex_search(l, s, r_gpu)) {
        m.gpu = std::stoi(s[1]);
        if (s[2].matched) m.gpu_mhz = std::stoi(s[2]);
    }
    if (std::regex_search(l, s, r_emc)) m.emc = std::stoi(s[1]);
    m.temp.clear();
    for (auto it = std::sregex_iterator(l.begin(), l.end(), r_t); it != std::sregex_iterator(); ++it) {
        std::string k = (*it)[1];
        if (k.find("PMIC") == std::string::npos) m.temp[k] = std::stod((*it)[2]);
    }
    if (std::regex_search(l, s, r_pot)) m.potencia_mw = std::stoi(s[1]);
    std::lock_guard<std::mutex> lk(mx_);
    double pc = m_.proc_cpu, pr = m_.proc_ram_mb;
    m_ = m;
    m_.proc_cpu = pc;
    m_.proc_ram_mb = pr;
}

void Estadisticas::leer_proc() {
    Muestra m = foto();
    std::ifstream st("/proc/stat");
    std::string l;
    std::vector<std::pair<long long, long long>> act;
    while (std::getline(st, l)) {
        if (l.compare(0, 3, "cpu") != 0 || l.size() < 4 || l[3] == ' ') continue;
        std::stringstream ss(l);
        std::string nom;
        ss >> nom;
        long long v, tot = 0, idle = 0;
        int i = 0;
        while (ss >> v) {
            tot += v;
            if (i == 3 || i == 4) idle += v;
            i++;
        }
        act.push_back({tot, idle});
    }
    if (prev_cpu_.size() == act.size() && !act.empty()) {
        m.cpu.clear();
        double sum = 0;
        for (size_t i = 0; i < act.size(); i++) {
            long long dt = std::max(1LL, act[i].first - prev_cpu_[i].first);
            int p = (int)std::round(100.0 * (1.0 - (double)(act[i].second - prev_cpu_[i].second) / dt));
            m.cpu.push_back(p);
            sum += p;
        }
        m.cpu_prom = sum / act.size();
    }
    prev_cpu_ = act;
    std::ifstream mi("/proc/meminfo");
    std::map<std::string, long> mm;
    while (std::getline(mi, l)) {
        size_t k = l.find(':');
        if (k != std::string::npos) mm[l.substr(0, k)] = std::atol(l.c_str() + k + 1) / 1024;
    }
    m.ram_total_mb = (int)mm["MemTotal"];
    m.ram_mb = (int)(mm["MemTotal"] - mm["MemAvailable"]);
    m.swap_mb = (int)(mm["SwapTotal"] - mm["SwapFree"]);
    m.temp.clear();
    for (auto& z : util::listar("/sys/class/thermal")) {
        if (z.compare(0, 12, "thermal_zone") != 0) continue;
        std::string tipo = util::leer_texto("/sys/class/thermal/" + z + "/type");
        std::string tv = util::leer_texto("/sys/class/thermal/" + z + "/temp");
        while (!tipo.empty() && (tipo.back() == '\n' || tipo.back() == ' ')) tipo.pop_back();
        if (!tv.empty()) m.temp[tipo.substr(0, 10)] = std::atof(tv.c_str()) / 1000.0;
    }
    std::string g = util::leer_texto("/sys/devices/gpu.0/load");
    if (!g.empty()) m.gpu = std::atoi(g.c_str()) / 10;
    std::lock_guard<std::mutex> lk(mx_);
    double pc = m_.proc_cpu, pr = m_.proc_ram_mb;
    m_ = m;
    m_.proc_cpu = pc;
    m_.proc_ram_mb = pr;
}

void Estadisticas::proceso() {
    std::string s = util::leer_texto("/proc/self/stat");
    size_t k = s.rfind(')');
    if (k == std::string::npos) return;
    std::stringstream ss(s.substr(k + 2));
    std::vector<std::string> f;
    std::string t;
    while (ss >> t) f.push_back(t);
    if (f.size() < 13) return;
    long ticks = std::atol(f[11].c_str()) + std::atol(f[12].c_str());   // utime + stime
    double ahora = util::ahora(), cpu = 0;
    if (prev_ticks_ >= 0) cpu = 100.0 * (ticks - prev_ticks_) / sysconf(_SC_CLK_TCK) / std::max(1e-3, ahora - prev_t_);
    prev_ticks_ = ticks;
    prev_t_ = ahora;
    double rss = 0;
    std::ifstream st("/proc/self/status");
    std::string l;
    while (std::getline(st, l))
        if (l.compare(0, 6, "VmRSS:") == 0) rss = std::atof(l.c_str() + 6) / 1024.0;
    std::lock_guard<std::mutex> lk(mx_);
    m_.proc_cpu = cpu;
    m_.proc_ram_mb = rss;
}

std::string perfil_energia(const std::string& n) {
    std::vector<std::string> cmds;
    if (n == "max") cmds = {"nvpmodel -m 0", "jetson_clocks"};
    else if (n == "normal") cmds = {"jetson_clocks --restore", "nvpmodel -m 0"};
    else if (n == "5w") cmds = {"jetson_clocks --restore", "nvpmodel -m 1"};
    else return "perfiles: max (10 W + relojes al maximo) | normal (10 W) | 5w (ahorro)";
    std::string r;
    bool error = false;
    for (auto& c : cmds) {
        int x = system(("sudo -n " + c + " >/dev/null 2>&1").c_str());
        r += c + (x == 0 ? " -> ok; " : " -> error; ");
        error |= x != 0;
    }
    if (error) r += "(si pide contrasena corre: sudo ./instalar.sh --sudoers)";
    return r;
}
