// bench.hpp - benchmark tipo overclock de los modelos, uno por uno, con los MISMOS cuadros.
// Por modelo: carga, FPS, latencia p50/p95, CPU, GPU, RAM extra, temperatura maxima, consumo,
// detecciones por cuadro y "aciertos" contra las fotos que guardaste al ENSENAR (IoU >= 0.3).
// Resultado: bench/bench_FECHA.md y .csv
#pragma once

#include <string>
#include <vector>

#include "util.hpp"

class Nucleo;
json correr_bench(Nucleo& n, std::vector<std::string> ids, double segundos);
std::string tabla_texto(const json& filas);
