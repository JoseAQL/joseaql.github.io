#include "calibracion.hpp"

#include <cmath>
#include <numeric>

#include <opencv2/aruco.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

using util::fmt;
using util::log;

// ====================================================================== ArUco (OpenCV 4.1 contrib, incluido en terceros/)
static cv::Ptr<cv::aruco::Dictionary> dic() { return cv::aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_50); }

cv::Mat dibujar_marcador(int id, int lado) {
    cv::Mat m;
    cv::aruco::drawMarker(dic(), id, lado, m);
    return m;
}
void detectar_marcadores(const cv::Mat& gris, std::vector<std::vector<cv::Point2f>>& esq, std::vector<int>& ids) {
    cv::Ptr<cv::aruco::DetectorParameters> p = cv::aruco::DetectorParameters::create();
    cv::aruco::detectMarkers(gris, dic(), esq, ids, p);
}
void guardar_marcador_impreso(const std::string& png, int id, int lado_mm, int dpi) {
    int lado = (int)(lado_mm / 25.4 * dpi), borde = lado / 4;
    cv::Mat img(lado + 2 * borde, lado + 2 * borde, CV_8U, cv::Scalar(255));
    dibujar_marcador(id, lado).copyTo(img(cv::Rect(borde, borde, lado, lado)));
    cv::putText(img, fmt("ID %d - %d mm - imprimir al 100%%", id, lado_mm), cv::Point(borde, borde / 2),
                cv::FONT_HERSHEY_SIMPLEX, 1.2, cv::Scalar(0), 2);
    util::crear_dirs(util::dir_de(png));
    cv::imwrite(png, img);
}

static cv::Mat gris(const cv::Mat& a) {
    if (a.channels() == 1) return a;
    cv::Mat g;
    cv::cvtColor(a, g, cv::COLOR_BGR2GRAY);
    return g;
}

static std::vector<cv::Point2f> transformar(const cv::Mat& H, const std::vector<cv::Point2f>& p) {
    std::vector<cv::Point2f> r;
    if (p.empty() || H.empty()) return r;
    cv::perspectiveTransform(p, r, H);
    return r;
}

// centroide (pesado por brillo) del blob mas grande
static bool centro_blob(const cv::Mat& dif, cv::Point2f& c, int umbral = 40) {
    cv::Mat b, et, st, cen;
    cv::threshold(dif, b, umbral, 255, cv::THRESH_BINARY);
    int n = cv::connectedComponentsWithStats(b, et, st, cen);
    if (n <= 1) return false;
    int mej = 1;
    for (int i = 2; i < n; i++)
        if (st.at<int>(i, cv::CC_STAT_AREA) > st.at<int>(mej, cv::CC_STAT_AREA)) mej = i;
    if (st.at<int>(mej, cv::CC_STAT_AREA) < 15) return false;
    double sx = 0, sy = 0, sw = 0;
    for (int y = 0; y < et.rows; y++) {
        const int* e = et.ptr<int>(y);
        const uchar* d = dif.ptr<uchar>(y);
        for (int x = 0; x < et.cols; x++)
            if (e[x] == mej) {
                sx += x * d[x];
                sy += y * d[x];
                sw += d[x];
            }
    }
    if (sw <= 0) return false;
    c = cv::Point2f((float)(sx / sw), (float)(sy / sw));
    return true;
}

// ====================================================================== clase
Calibracion::Calibracion(Camara& cam, Proyector& proy, const json& c) : cfg(c), cam_(cam), proy_(proy) { cargar(); }

bool Calibracion::cargar() {
    json d = util::cargar_json(util::ruta("perfiles/calibracion.json"), json());
    if (!d.is_object() || !d.contains("H_c2p") || d["H_c2p"].is_null()) return false;
    try {
        H_c2p = cv::Mat(3, 3, CV_64F);
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) H_c2p.at<double>(i, j) = d["H_c2p"][i][j];
        H_p2c = H_c2p.inv();
        metodo = d.value("metodo", "");
        error_px = d.value("error_px", -1.0);
        t = d.value("t", 0.0);
        if (d.contains("H_c2mm") && !d["H_c2mm"].is_null()) {
            H_c2mm = cv::Mat(3, 3, CV_64F);
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++) H_c2mm.at<double>(i, j) = d["H_c2mm"][i][j];
            px_por_mm = d.value("px_por_mm", 0.0);
        }
        return true;
    } catch (...) {
        H_c2p.release();
        return false;
    }
}

static json mat_json(const cv::Mat& H) {
    if (H.empty()) return nullptr;
    json j = json::array();
    for (int i = 0; i < 3; i++) j.push_back({H.at<double>(i, 0), H.at<double>(i, 1), H.at<double>(i, 2)});
    return j;
}

void Calibracion::guardar() {
    util::guardar_json(util::ruta("perfiles/calibracion.json"),
                       {{"H_c2p", mat_json(H_c2p)}, {"H_c2mm", mat_json(H_c2mm)}, {"px_por_mm", px_por_mm},
                        {"metodo", metodo}, {"error_px", error_px}, {"t", t}, {"camara", {cam_.ancho, cam_.alto}},
                        {"proyector", {proy_.w, proy_.h}}});
}

std::vector<cv::Point2f> Calibracion::cam_a_proy(const std::vector<cv::Point2f>& pts, double esc) const {
    std::vector<cv::Point2f> p = pts;
    for (auto& q : p) q *= (float)esc;
    return transformar(H_c2p, p);
}
std::vector<cv::Point2f> Calibracion::proy_a_cam(const std::vector<cv::Point2f>& pts, double esc) const {
    auto r = transformar(H_p2c, pts);
    for (auto& q : r) q *= (float)(1.0 / esc);
    return r;
}

cv::Mat Calibracion::foto(const cv::Mat& patron, int n, double espera) {
    proy_.poner_patron(patron);
    return cam_.promedio(n, espera);
}
cv::Mat Calibracion::negro() { return cv::Mat::zeros(proy_.h, proy_.w, CV_8U); }

bool Calibracion::ajustar(const std::vector<cv::Point2f>& cam, const std::vector<cv::Point2f>& pro, bool ransac,
                          cv::Mat& H, double& err, int& n) {
    if (cam.size() < 4) return false;
    if (cam.size() == 4) {
        H = cv::getPerspectiveTransform(cam, pro);
        err = 0;
        n = 4;
        return true;
    }
    cv::Mat msk;
    H = cv::findHomography(cam, pro, ransac ? cv::RANSAC : 0, 6.0, msk);
    if (H.empty()) return false;
    cv::Mat Hi = H.inv();
    std::vector<cv::Point2f> pc, cc;
    for (size_t i = 0; i < cam.size(); i++)
        if (msk.empty() || msk.at<uchar>((int)i)) {
            pc.push_back(pro[i]);
            cc.push_back(cam[i]);
        }
    auto back = transformar(Hi, pc);
    double s = 0;
    for (size_t i = 0; i < back.size(); i++) s += cv::norm(back[i] - cc[i]);
    err = back.empty() ? 0 : s / back.size();   // error en pixeles de la CAMARA
    n = (int)cc.size();
    return true;
}

bool Calibracion::calibrar(const std::string& m) {
    std::string met = m.empty() ? "aruco" : m;
    if (!proy_.encendido && !proy_.encender()) {
        log("calibrar: el proyector no esta encendido");
        return false;
    }
    util::Crono cr;
    cv::Mat H;
    double err = 0;
    int n = 0;
    bool ok = false;
    try {
        if (met == "aruco") ok = m_aruco(H, err, n);
        else if (met == "puntos") ok = m_puntos(H, err, n);
        else if (met == "esquinas") ok = m_esquinas(H, err, n);
        else if (met == "graycode") ok = m_graycode(H, err, n);
        else {
            log("metodo desconocido: " + met + " (aruco|puntos|esquinas|graycode)");
            proy_.quitar_patron();
            return false;
        }
    } catch (const std::exception& e) {
        log(std::string("calibracion: ") + e.what());
        ok = false;
    }
    proy_.quitar_patron();
    if (!ok) {
        log("calibracion " + met + ": FALLO");
        return false;
    }
    H_c2p = H;
    H_p2c = H.inv();
    metodo = met;
    error_px = std::round(err * 100) / 100;
    t = util::epoch();
    log(fmt("calibracion %s OK: %d puntos, error %.2f px, %.1f s", met.c_str(), n, err, cr.s()));
    if (cfg.value("/marcador_mm/habilitado"_json_pointer, true)) medir_mm();
    guardar();
    return true;
}

bool Calibracion::m_aruco(cv::Mat& H, double& err, int& n) {
    int W = proy_.w, Hh = proy_.h, lado = (int)(Hh / 5.2), cols = 6, filas = 3;
    cv::Mat img(Hh, W, CV_8U, cv::Scalar(255));
    std::map<int, std::vector<cv::Point2f>> pos;
    double mx = (W - cols * lado) / (cols + 1.0), my = (Hh - filas * lado) / (filas + 1.0);
    int k = 0;
    for (int f = 0; f < filas; f++)
        for (int c = 0; c < cols; c++, k++) {
            int x = (int)(mx + c * (lado + mx)), y = (int)(my + f * (lado + my));
            dibujar_marcador(k, lado).copyTo(img(cv::Rect(x, y, lado, lado)));
            pos[k] = {cv::Point2f(x, y), cv::Point2f(x + lado, y), cv::Point2f(x + lado, y + lado), cv::Point2f(x, y + lado)};
        }
    cv::Mat f = foto(img, 2);
    if (f.empty()) return false;
    std::vector<std::vector<cv::Point2f>> esq;
    std::vector<int> ids;
    detectar_marcadores(gris(f), esq, ids);
    std::vector<cv::Point2f> cam, pro;
    for (size_t i = 0; i < ids.size(); i++)
        if (pos.count(ids[i]))
            for (int j = 0; j < 4; j++) {
                cam.push_back(esq[i][j]);
                pro.push_back(pos[ids[i]][j]);
            }
    log(fmt("aruco: vi %d de %d marcadores", (int)cam.size() / 4, (int)pos.size()));
    if (cam.size() < 8) {
        if (cam.empty()) log("aruco: no vi ninguno (sube la exposicion o baja la luz del cuarto)");
        return false;
    }
    return ajustar(cam, pro, true, H, err, n);
}

bool Calibracion::m_puntos(cv::Mat& H, double& err, int& n) {
    int W = proy_.w, Hh = proy_.h, cols = 10, filas = 6;
    int r = std::max(8, std::min(W, Hh) / 60);
    cv::Mat img = negro();
    std::vector<cv::Point2f> pro;
    for (int f = 0; f < filas; f++)
        for (int c = 0; c < cols; c++) {
            int x = (int)(W * (0.1 + 0.8 * c / (cols - 1))), y = (int)(Hh * (0.1 + 0.8 * f / (filas - 1)));
            cv::circle(img, cv::Point(x, y), (f == 0 && c == 0) ? (int)(r * 1.6) : r, cv::Scalar(255), -1);
            pro.push_back(cv::Point2f(x, y));
        }
    cv::Mat ng = foto(negro()), fo = foto(img);
    if (ng.empty() || fo.empty()) return false;
    cv::Mat dif, b, et, st, cen;
    cv::subtract(gris(fo), gris(ng), dif);
    cv::GaussianBlur(dif, dif, cv::Size(3, 3), 0);
    cv::threshold(dif, b, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);
    int nb = cv::connectedComponentsWithStats(b, et, st, cen);
    std::vector<std::pair<int, cv::Point2f>> blobs;
    for (int i = 1; i < nb; i++)
        if (st.at<int>(i, cv::CC_STAT_AREA) >= 6)
            blobs.push_back({st.at<int>(i, cv::CC_STAT_AREA), cv::Point2f((float)cen.at<double>(i, 0), (float)cen.at<double>(i, 1))});
    if ((int)blobs.size() < cols * filas) {
        log(fmt("puntos: vi %d de %d circulos", (int)blobs.size(), cols * filas));
        return false;
    }
    std::sort(blobs.begin(), blobs.end(), [](const std::pair<int, cv::Point2f>& a, const std::pair<int, cv::Point2f>& b) {
        return a.first > b.first;
    });
    blobs.resize(cols * filas);
    cv::Point2f grande = blobs[0].second;
    cv::Mat lim = cv::Mat::zeros(b.size(), CV_8U);
    for (auto& bl : blobs) cv::circle(lim, bl.second, 4, cv::Scalar(255), -1);
    cv::SimpleBlobDetector::Params prm;
    prm.filterByColor = true;
    prm.blobColor = 255;
    prm.minArea = 10;
    prm.filterByInertia = prm.filterByConvexity = prm.filterByCircularity = false;
    std::vector<cv::Point2f> grid;
    if (!cv::findCirclesGrid(lim, cv::Size(cols, filas), grid, cv::CALIB_CB_SYMMETRIC_GRID,
                             cv::SimpleBlobDetector::create(prm))) {
        log("puntos: no pude ordenar la rejilla");
        return false;
    }
    std::vector<cv::Point2f> inv(grid.rbegin(), grid.rend());
    if (cv::norm(inv[0] - grande) < cv::norm(grid[0] - grande)) grid = inv;
    if (cv::norm(grid[0] - grande) > 15) log("puntos: orientacion rara, revisa que el proyector no este girado");
    return ajustar(grid, pro, true, H, err, n);
}

bool Calibracion::m_esquinas(cv::Mat& H, double& err, int& n) {
    int W = proy_.w, Hh = proy_.h;
    double m = 0.12;
    std::vector<cv::Point2f> obj = {{(float)(W * m), (float)(Hh * m)}, {(float)(W * (1 - m)), (float)(Hh * m)},
                                    {(float)(W * (1 - m)), (float)(Hh * (1 - m))}, {(float)(W * m), (float)(Hh * (1 - m))}};
    cv::Mat ng = foto(negro());
    if (ng.empty()) return false;
    std::vector<cv::Point2f> cam;
    for (size_t i = 0; i < obj.size(); i++) {
        cv::Mat img = negro();
        cv::circle(img, obj[i], Hh / 30, cv::Scalar(255), -1);
        cv::Mat dif;
        cv::subtract(gris(foto(img)), gris(ng), dif);
        cv::Point2f p;
        if (!centro_blob(dif, p)) {
            log(fmt("esquinas: no vi el punto %d", (int)i + 1));
            return false;
        }
        cam.push_back(p);
    }
    return ajustar(cam, obj, false, H, err, n);
}

bool Calibracion::m_graycode(cv::Mat& H, double& err, int& n) {
    const int paso = 8;
    int W = proy_.w, Hh = proy_.h, cw = W / paso, ch = Hh / paso;
    int bx = (int)std::ceil(std::log2((double)cw)), by = (int)std::ceil(std::log2((double)ch));
    cv::Mat ng = foto(negro()), bl = foto(cv::Mat(Hh, W, CV_8U, cv::Scalar(255)));
    if (ng.empty() || bl.empty()) return false;
    cv::Mat d16;
    cv::subtract(gris(bl), gris(ng), d16, cv::noArray(), CV_16S);
    cv::Mat valido = d16 > 25;
    log(fmt("graycode: %d fotos, espera unos segundos...", 2 * (bx + by) + 2));

    auto leer = [&](int nbits, bool columnas) {
        cv::Mat val = cv::Mat::zeros(valido.size(), CV_32S);
        for (int b = nbits - 1; b >= 0; b--) {
            cv::Mat pat(ch, cw, CV_8U);
            for (int y = 0; y < ch; y++)
                for (int x = 0; x < cw; x++) {
                    int v = columnas ? x : y;
                    int g = v ^ (v >> 1);
                    pat.at<uchar>(y, x) = ((g >> b) & 1) ? 255 : 0;
                }
            cv::resize(pat, pat, cv::Size(W, Hh), 0, 0, cv::INTER_NEAREST);
            cv::Mat a = gris(foto(pat, 1, 0.25)), inv = gris(foto(255 - pat, 1, 0.25));
            cv::Mat dd;
            cv::absdiff(a, inv, dd);
            valido &= dd > 8;
            cv::Mat bit = a > inv;     // 255 donde 1
            for (int y = 0; y < val.rows; y++) {
                int* v = val.ptr<int>(y);
                const uchar* bb = bit.ptr<uchar>(y);
                for (int x = 0; x < val.cols; x++) v[x] = (v[x] << 1) | (bb[x] ? 1 : 0);
            }
        }
        // gris -> binario
        for (int y = 0; y < val.rows; y++) {
            int* v = val.ptr<int>(y);
            for (int x = 0; x < val.cols; x++) {
                int g = v[x], r = g;
                for (int s = g >> 1; s; s >>= 1) r ^= s;
                v[x] = r;
            }
        }
        return val;
    };
    cv::Mat col = leer(bx, true), fil = leer(by, false);
    std::vector<cv::Point2f> cam, pro;
    int total = cv::countNonZero(valido), salto = std::max(1, total / 3000), k = 0;
    for (int y = 0; y < valido.rows; y++)
        for (int x = 0; x < valido.cols; x++)
            if (valido.at<uchar>(y, x) && (k++ % salto == 0)) {
                cam.push_back(cv::Point2f(x, y));
                pro.push_back(cv::Point2f(col.at<int>(y, x) * paso + paso / 2.f, fil.at<int>(y, x) * paso + paso / 2.f));
            }
    if (cam.size() < 50) return false;
    cv::FileStorage fs(util::ruta("perfiles/calibracion_graycode.yml.gz"), cv::FileStorage::WRITE);
    fs << "col" << col << "fil" << fil << "valido" << valido;
    return ajustar(cam, pro, true, H, err, n);
}

double Calibracion::verificar(int n) {
    if (!lista() || !proy_.encendido) return -1;
    cv::RNG rng((uint64)cv::getTickCount());
    cv::Mat ng = foto(negro());
    std::vector<double> errs;
    for (int i = 0; i < n; i++) {
        float x = (float)(rng.uniform(0.2, 0.8) * proy_.w), y = (float)(rng.uniform(0.2, 0.8) * proy_.h);
        cv::Mat img = negro();
        cv::circle(img, cv::Point2f(x, y), proy_.h / 40, cv::Scalar(255), -1);
        cv::Mat dif;
        cv::subtract(gris(foto(img)), gris(ng), dif);
        cv::Point2f p;
        if (!centro_blob(dif, p)) continue;
        auto e = transformar(H_p2c, {cv::Point2f(x, y)});
        errs.push_back(cv::norm(e[0] - p));
    }
    proy_.quitar_patron();
    if (errs.empty()) {
        log("verificar: no vi los puntos de prueba");
        return -1;
    }
    double e = std::accumulate(errs.begin(), errs.end(), 0.0) / errs.size();
    error_px = std::round(e * 100) / 100;
    log(fmt("verificar: error %.1f px (tolerancia %.0f)", e, cfg.value("tolerancia_px", 8.0)));
    return e;
}

bool Calibracion::medir_mm() {
    double mm = cfg.value("/marcador_mm/lado_mm"_json_pointer, 50.0);
    int id = cfg.value("/marcador_mm/id"_json_pointer, 49);
    if (proy_.encendido) proy_.poner_patron(cv::Mat(proy_.h, proy_.w, CV_8U, cv::Scalar(200)));
    cv::Mat f = cam_.promedio(2, 0.3);
    if (proy_.encendido) proy_.quitar_patron();
    if (f.empty()) return false;
    std::vector<std::vector<cv::Point2f>> esq;
    std::vector<int> ids;
    detectar_marcadores(gris(f), esq, ids);
    for (size_t i = 0; i < ids.size(); i++)
        if (ids[i] == id) {
            std::vector<cv::Point2f> dst = {{0, 0}, {(float)mm, 0}, {(float)mm, (float)mm}, {0, (float)mm}};
            H_c2mm = cv::getPerspectiveTransform(esq[i], dst);
            double s = 0;
            for (int j = 0; j < 4; j++) s += cv::norm(esq[i][j] - esq[i][(j + 1) % 4]);
            px_por_mm = std::round(s / 4 / mm * 10000) / 10000;
            log(fmt("mm: %.2f px por mm", px_por_mm));
            return true;
        }
    log(fmt("mm: no vi el marcador impreso ID %d (opcional; imprime perfiles/marcador_mm.png)", id));
    return false;
}
