// stats.hpp - estadisticas tipo overclock: CPU por nucleo, GPU, RAM, swap, temperaturas, consumo y lo que
// gasta el propio programa. En la Jetson lee tegrastats; en otra PC lee /proc y /sys.
#pragma once

#include <atomic>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "util.hpp"

struct Muestra {
    std::vector<int> cpu;
    double cpu_prom = 0;
    int gpu = -1, gpu_mhz = -1, emc = -1;
    int ram_mb = 0, ram_total_mb = 0, swap_mb = 0;
    std::map<std::string, double> temp;
    int potencia_mw = -1;
    double proc_cpu = 0, proc_ram_mb = 0;
    std::string fuente;
    json a_json() const;
    double temp_max() const;
};

class Estadisticas {
public:
    void iniciar(int intervalo_ms = 1000);
    void detener();
    Muestra foto();

private:
    std::atomic<bool> vivo_{false};
    std::thread hilo_;
    std::mutex mx_;
    Muestra m_;
    int intervalo_ = 1000;
    FILE* tegra_ = nullptr;
    double prev_t_ = 0;
    long prev_ticks_ = -1;
    std::vector<std::pair<long long, long long>> prev_cpu_;
    void parse_tegra(const std::string& l);
    void leer_proc();
    void proceso();
    void bucle();
};

std::string perfil_energia(const std::string& nombre);
