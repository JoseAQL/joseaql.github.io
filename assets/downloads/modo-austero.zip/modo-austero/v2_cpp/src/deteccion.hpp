// deteccion.hpp - lo que regresa cualquier modelo, en pixeles de la imagen de proceso.
#pragma once

#include <cmath>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "util.hpp"

struct Det {
    std::string clase;
    float conf = 1.f;
    cv::Rect caja;
    std::vector<cv::Point> contorno;   // vacio si el modelo solo da caja
    float angulo = -1.f;               // grados; -1 = no se sabe
};

inline json det_json(const Det& d) {
    json j = {{"clase", d.clase}, {"conf", std::round(d.conf * 100) / 100.0},
              {"caja", {d.caja.x, d.caja.y, d.caja.x + d.caja.width, d.caja.y + d.caja.height}}};
    j["angulo"] = d.angulo >= 0 ? json(std::round(d.angulo * 10) / 10.0) : json(nullptr);
    return j;
}

// lo que los modelos pueden consultar del nucleo
class Memoria;
struct Contexto {
    cv::Mat fondo;          // mesa vacia (imagen de proceso)
    cv::Mat mascara_proy;   // donde el proyector esta pintando (se ignora)
    Memoria* memoria = nullptr;
};

// regiones distintas al fondo: contornos con area >= area_min
std::vector<std::vector<cv::Point>> segmentar_fondo(const cv::Mat& img, const cv::Mat& fondo, double umbral,
                                                    double area_min, const cv::Mat& ignorar);
