#include "modelos.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>

#include <opencv2/dnn.hpp>
#include <opencv2/imgproc.hpp>

#include "memoria.hpp"

#ifdef CON_TENSORRT
#include <NvInfer.h>
#include <cuda_runtime_api.h>
#endif

#ifdef CON_JETSON_INFERENCE
#include <jetson-inference/detectNet.h>
#include <jetson-inference/poseNet.h>
#include <jetson-utils/cudaMappedMemory.h>
#if __has_include(<jetson-inference/backgroundNet.h>)
#include <jetson-inference/backgroundNet.h>
#define CON_BACKGROUNDNET 1
#endif
#endif

using util::fmt;
using util::log;

bool hay_jetson_inference() {
#ifdef CON_JETSON_INFERENCE
    return true;
#else
    return false;
#endif
}
bool hay_tensorrt() {
#ifdef CON_TENSORRT
    return true;
#else
    return false;
#endif
}

static std::string dir_modelos() { return util::ruta("modelos"); }

// ====================================================================== motores
#ifdef CON_TENSORRT
class LoggerTRT : public nvinfer1::ILogger {
    void log(Severity s, const char* m) noexcept override {
        if (s <= Severity::kWARNING) util::log(std::string("TensorRT: ") + m);
    }
};
static LoggerTRT g_trt_log;

class MotorTRT : public Motor {
public:
    explicit MotorTRT(const std::string& archivo) {
        std::ifstream f(archivo, std::ios::binary);
        std::vector<char> datos((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        if (datos.empty()) throw std::runtime_error("no pude leer " + archivo);
        rt_ = nvinfer1::createInferRuntime(g_trt_log);
        eng_ = rt_->deserializeCudaEngine(datos.data(), datos.size());
        if (!eng_) throw std::runtime_error("engine invalido (se hizo con otra version de TensorRT?): " + archivo);
        ctx_ = eng_->createExecutionContext();
        int nb = eng_->getNbBindings();
        bind_.resize(nb, nullptr);
        for (int i = 0; i < nb; i++) {
            nvinfer1::Dims d = eng_->getBindingDimensions(i);
            std::vector<int> forma(d.d, d.d + d.nbDims);
            size_t n = 1;
            for (int v : forma) n *= (size_t)std::max(1, v);
            bool fp16 = eng_->getBindingDataType(i) == nvinfer1::DataType::kHALF;
            if (fp16) throw std::runtime_error("el engine tiene entradas/salidas FP16; usa trtexec sin --inputIOFormats");
            cudaMalloc(&bind_[i], n * sizeof(float));
            if (eng_->bindingIsInput(i)) {
                forma_entrada = forma;
                ent_ = i;
            } else {
                salidas_.push_back({i, forma, n});
            }
        }
        cudaStreamCreate(&st_);
        nombre = "TensorRT";
    }
    ~MotorTRT() override {
        for (void* b : bind_) cudaFree(b);
        cudaStreamDestroy(st_);
        delete ctx_;
        delete eng_;
        delete rt_;
    }
    std::vector<cv::Mat> correr(const cv::Mat& blob) override {
        cudaMemcpyAsync(bind_[ent_], blob.ptr<float>(), blob.total() * sizeof(float), cudaMemcpyHostToDevice, st_);
        ctx_->enqueueV2(bind_.data(), st_, nullptr);
        std::vector<cv::Mat> out;
        for (auto& s : salidas_) {
            cv::Mat m((int)s.forma.size(), s.forma.data(), CV_32F);
            cudaMemcpyAsync(m.ptr<float>(), bind_[s.i], s.n * sizeof(float), cudaMemcpyDeviceToHost, st_);
            out.push_back(m);
        }
        cudaStreamSynchronize(st_);
        return out;
    }

private:
    struct Sal {
        int i;
        std::vector<int> forma;
        size_t n;
    };
    nvinfer1::IRuntime* rt_ = nullptr;
    nvinfer1::ICudaEngine* eng_ = nullptr;
    nvinfer1::IExecutionContext* ctx_ = nullptr;
    std::vector<void*> bind_;
    std::vector<Sal> salidas_;
    int ent_ = 0;
    cudaStream_t st_;
};
#endif

class MotorCV : public Motor {
public:
    MotorCV(const std::string& onnx, const std::vector<int>& forma) {
        net_ = cv::dnn::readNetFromONNX(onnx);
        forma_entrada = forma;
        nombre = "OpenCV DNN (CPU)";
    }
    std::vector<cv::Mat> correr(const cv::Mat& blob) override {
        net_.setInput(blob);
        std::vector<cv::Mat> out;
        net_.forward(out, net_.getUnconnectedOutLayersNames());
        return out;
    }

private:
    cv::dnn::Net net_;
};

std::unique_ptr<Motor> abrir_motor(const std::string& base, const std::vector<int>& forma_def, std::string& error) {
    error.clear();
#ifdef CON_TENSORRT
    if (util::existe(base + ".engine")) {
        try {
            return std::unique_ptr<Motor>(new MotorTRT(base + ".engine"));
        } catch (const std::exception& e) {
            error += std::string("TRT: ") + e.what() + "; ";
        }
    }
#endif
    if (util::existe(base + ".onnx")) {
        try {
            return std::unique_ptr<Motor>(new MotorCV(base + ".onnx", forma_def));
        } catch (const std::exception& e) {
            error += std::string("OpenCV DNN: ") + e.what();
        }
    }
    if (error.empty()) error = "no existe " + base + ".engine ni .onnx";
    return nullptr;
}

// ====================================================================== base
bool Modelo::poner(const std::string& k, double v) {
    if (!p.count(k)) return false;
    p[k] = v;
    return true;
}
json Modelo::params_json() const {
    json j = json::object();
    for (auto& kv : p) j[kv.first] = kv.second;
    return j;
}

static std::vector<int> nms(const std::vector<cv::Rect>& cajas, const std::vector<float>& confs, double iou) {
    std::vector<int> idx;
    if (!cajas.empty()) cv::dnn::NMSBoxes(cajas, confs, 0.f, (float)iou, idx);
    return idx;
}

// ====================================================================== 1 fondo
class Fondo : public Modelo {
public:
    explicit Fondo(Contexto& c) : Modelo(c) { p = {{"umbral", 30}, {"area_min", 400}, {"nms", 0.45}}; }
    std::string id() const override { return "fondo"; }
    std::string nombre() const override { return "Resta de fondo (OpenCV)"; }
    std::string licencia() const override { return "propio"; }
    std::vector<Det> procesar(const cv::Mat& img) override {
        std::vector<Det> r;
        for (auto& c : segmentar_fondo(img, ctx.fondo, p["umbral"], p["area_min"], ctx.mascara_proy)) {
            Det d;
            d.clase = "objeto";
            d.caja = cv::boundingRect(c);
            d.contorno = c;
            cv::RotatedRect rr = cv::minAreaRect(c);
            d.angulo = (float)std::fmod(rr.angle + (rr.size.width < rr.size.height ? 90 : 0) + 360.0, 180.0);
            r.push_back(d);
        }
        return r;
    }
};

// ====================================================================== jetson-inference: buffer CUDA compartido
#ifdef CON_JETSON_INFERENCE
struct BufCuda {
    void* ptr = nullptr;
    int w = 0, h = 0, canales = 3;
    ~BufCuda() {
        if (ptr) cudaFreeHost(ptr);
    }
    // copia BGR -> RGB (o RGBA) a memoria mapeada (CPU y GPU la ven sin copiar en la Jetson)
    void* subir(const cv::Mat& bgr, int ch = 3) {
        if (!ptr || w != bgr.cols || h != bgr.rows || canales != ch) {
            if (ptr) cudaFreeHost(ptr);
            ptr = nullptr;
            w = bgr.cols;
            h = bgr.rows;
            canales = ch;
            if (!cudaAllocMapped(&ptr, (size_t)w * h * ch)) throw std::runtime_error("cudaAllocMapped fallo");
        }
        cv::Mat dst(h, w, ch == 3 ? CV_8UC3 : CV_8UC4, ptr);
        cv::cvtColor(bgr, dst, ch == 3 ? cv::COLOR_BGR2RGB : cv::COLOR_BGR2RGBA);
        return ptr;
    }
};

static std::vector<char*> argv_de(std::vector<std::string>& a) {
    std::vector<char*> r;
    for (auto& s : a) r.push_back(&s[0]);
    return r;
}
#endif

// ====================================================================== 2/3 detectNet SSD
class SSD : public Modelo {
public:
    SSD(Contexto& c, bool propio) : Modelo(c), propio_(propio) { p = {{"umbral", 0.4}, {"nms", 0.45}}; }
    std::string id() const override { return propio_ ? "ssd_propio" : "ssd_general"; }
    std::string nombre() const override {
        return propio_ ? "detectNet SSD-MobileNet re-entrenado (tuyo)" : "detectNet SSD-MobileNet-v2 (COCO)";
    }
    std::string licencia() const override { return propio_ ? "tuyo" : "MIT (jetson-inference)"; }
    std::string onnx() const { return dir_modelos() + "/ssd_instrumental/ssd-mobilenet.onnx"; }
    bool disponible(std::string& w) override {
        if (!hay_jetson_inference()) {
            w = "falta jetson-inference (compila en la Jetson con instalar.sh)";
            return false;
        }
        if (propio_ && !util::existe(onnx())) {
            w = "falta modelos/ssd_instrumental/ssd-mobilenet.onnx (re-entrena con colab/)";
            return false;
        }
        return true;
    }
#ifdef CON_JETSON_INFERENCE
    bool cargar() override {
        std::vector<std::string> a = {"austero"};
        if (propio_) {
            std::string d = util::dir_de(onnx());
            a.insert(a.end(), {"--model=" + onnx(), "--labels=" + d + "/labels.txt", "--input-blob=input_0",
                               "--output-cvg=scores", "--output-bbox=boxes"});
        } else {
            a.push_back("--network=ssd-mobilenet-v2");
        }
        a.push_back(fmt("--threshold=%.2f", p["umbral"]));
        auto av = argv_de(a);
        net_ = detectNet::Create((int)av.size(), av.data());
        if (!net_) {
            error = "detectNet no cargo (revisa el log)";
            return false;
        }
        motor = "TensorRT (detectNet)";
        return ok = true;
    }
    void liberar() override {
        delete net_;
        net_ = nullptr;
        ok = false;
    }
    bool poner(const std::string& k, double v) override {
        bool r = Modelo::poner(k, v);
        if (r && k == "umbral" && net_) net_->SetConfidenceThreshold((float)v);
        return r;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        std::vector<Det> r;
        detectNet::Detection* d = nullptr;
        int n = net_->Detect((uchar3*)buf_.subir(img), img.cols, img.rows, &d, detectNet::OVERLAY_NONE);
        std::vector<cv::Rect> cajas;
        std::vector<float> confs;
        for (int i = 0; i < n; i++) {
            Det x;
            x.clase = net_->GetClassDesc(d[i].ClassID);
            x.conf = d[i].Confidence;
            x.caja = cv::Rect(cv::Point((int)d[i].Left, (int)d[i].Top), cv::Point((int)d[i].Right, (int)d[i].Bottom));
            r.push_back(x);
        }
        return r;
    }
    ~SSD() override { liberar(); }

private:
    detectNet* net_ = nullptr;
    BufCuda buf_;
#else
    std::vector<Det> procesar(const cv::Mat&) override { return {}; }
#endif
    bool propio_;
};

// ====================================================================== 4/5/9 YOLO
static cv::Mat letterbox(const cv::Mat& img, int lado, double& r, int& dx, int& dy) {
    r = std::min(lado / (double)img.cols, lado / (double)img.rows);
    int nw = (int)std::round(img.cols * r), nh = (int)std::round(img.rows * r);
    dx = (lado - nw) / 2;
    dy = (lado - nh) / 2;
    cv::Mat lienzo(lado, lado, CV_8UC3, cv::Scalar(114, 114, 114)), t;
    cv::resize(img, t, cv::Size(nw, nh));
    t.copyTo(lienzo(cv::Rect(dx, dy, nw, nh)));
    return lienzo;
}

// imagen BGR -> blob 1x3xHxW RGB 0..1, sin copias extra (cada canal se escribe directo al blob)
static cv::Mat a_blob(const cv::Mat& bgr) {
    int sz[] = {1, 3, bgr.rows, bgr.cols};
    cv::Mat blob(4, sz, CV_32F);
    std::vector<cv::Mat> planos;
    for (int c = 0; c < 3; c++) planos.push_back(cv::Mat(bgr.rows, bgr.cols, CV_32F, blob.ptr<float>(0, c)));
    std::vector<cv::Mat> ch;
    cv::split(bgr, ch);
    for (int c = 0; c < 3; c++) ch[2 - c].convertTo(planos[c], CV_32F, 1.0 / 255);   // BGR -> RGB
    return blob;
}

class Yolo : public Modelo {
public:
    Yolo(Contexto& c, const std::string& id, const std::string& nom, const std::string& lic, const std::string& carpeta,
         bool v5, std::vector<std::string> clases, int entrada)
        : Modelo(c), id_(id), nom_(nom), lic_(lic), carpeta_(carpeta), v5_(v5), clases_(clases) {
        p = {{"umbral", 0.35}, {"nms", 0.45}, {"entrada", (double)entrada}};
    }
    std::string id() const override { return id_; }
    std::string nombre() const override { return nom_; }
    std::string licencia() const override { return lic_; }
    std::string dir() const { return dir_modelos() + "/" + carpeta_; }
    std::vector<int> tamanos() override {
        std::vector<int> r;
        for (auto& f : util::listar(dir())) {
            if (f.compare(0, 7, "modelo_") != 0) continue;
            size_t k = f.find('.');
            std::string ext = f.substr(k);
            if (ext != ".onnx" && ext != ".engine") continue;
            int v = std::atoi(f.substr(7, k - 7).c_str());
            if (v > 0 && std::find(r.begin(), r.end(), v) == r.end()) r.push_back(v);
        }
        std::sort(r.begin(), r.end());
        return r;
    }
    bool disponible(std::string& w) override {
        if (tamanos().empty()) {
            w = "faltan modelos/" + carpeta_ + "/modelo_*.onnx (corre herramientas/descargar_modelos.sh)";
            return false;
        }
        return true;
    }
    bool cargar() override {
        auto t = tamanos();
        if (t.empty()) return false;
        int e = (int)p["entrada"];
        if (std::find(t.begin(), t.end(), e) == t.end()) {
            e = *std::min_element(t.begin(), t.end(), [&](int a, int b) { return std::abs(a - e) < std::abs(b - e); });
            p["entrada"] = e;
        }
        auto cl = util::leer_lineas(dir() + "/clases.txt");
        if (!cl.empty()) clases_ = cl;
        m_ = abrir_motor(dir() + fmt("/modelo_%d", e), {1, 3, e, e}, error);
        if (!m_) return false;
        motor = m_->nombre;
        return ok = true;
    }
    void liberar() override {
        m_.reset();
        ok = false;
    }
    bool poner(const std::string& k, double v) override {
        bool r = Modelo::poner(k, v);
        if (r && k == "entrada" && ok) {   // otro tamano = otro archivo
            liberar();
            cargar();
        }
        return r;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        int lado = (int)p["entrada"];
        double r;
        int dx, dy;
        cv::Mat blob = a_blob(letterbox(img, lado, r, dx, dy));
        cv::Mat out = m_->correr(blob)[0];
        // v8/v11: [1, 4+nc, N]   v5: [1, N, 5+nc]
        int a = out.size[1], b = out.size[2];
        cv::Mat o2(a, b, CV_32F, out.ptr<float>());
        cv::Mat filas = v5_ ? o2 : (a < b ? cv::Mat(o2.t()) : o2);
        int nc = filas.cols - (v5_ ? 5 : 4);
        std::vector<cv::Rect> cajas;
        std::vector<float> confs;
        std::vector<int> cids;
        float um = (float)p["umbral"];
        for (int i = 0; i < filas.rows; i++) {
            const float* f = filas.ptr<float>(i);
            const float* sc = f + (v5_ ? 5 : 4);
            int c = (int)(std::max_element(sc, sc + nc) - sc);
            float conf = sc[c] * (v5_ ? f[4] : 1.f);
            if (conf < um) continue;
            float x1 = (float)((f[0] - f[2] / 2 - dx) / r), y1 = (float)((f[1] - f[3] / 2 - dy) / r);
            float x2 = (float)((f[0] + f[2] / 2 - dx) / r), y2 = (float)((f[1] + f[3] / 2 - dy) / r);
            cajas.push_back(cv::Rect(cv::Point((int)x1, (int)y1), cv::Point((int)x2, (int)y2)));
            confs.push_back(conf);
            cids.push_back(c);
        }
        std::vector<Det> res;
        for (int i : nms(cajas, confs, p["nms"])) {
            Det d;
            d.clase = cids[i] < (int)clases_.size() ? clases_[cids[i]] : std::to_string(cids[i]);
            d.conf = confs[i];
            d.caja = cajas[i];
            res.push_back(d);
        }
        return res;
    }

private:
    std::string id_, nom_, lic_, carpeta_;
    bool v5_;
    std::vector<std::string> clases_;
    std::unique_ptr<Motor> m_;
};

// ====================================================================== 6 orientacion
class Orientacion : public Modelo {
public:
    explicit Orientacion(Contexto& c) : Modelo(c) { p = {{"umbral", 30}, {"area_min", 400}, {"nms", 0.45}}; }
    std::string id() const override { return "orientacion"; }
    std::string nombre() const override { return "Orientacion 0-357 grados (DocCheck Rona)"; }
    std::string licencia() const override { return "CC BY-NC 4.0 (sin uso comercial)"; }
    std::string base() const { return dir_modelos() + "/orientacion/modelo"; }
    bool disponible(std::string& w) override {
        if (util::existe(base() + ".onnx") || util::existe(base() + ".engine")) return true;
        w = "falta modelos/orientacion/modelo.onnx (convierte con colab/convertir_doccheck.ipynb)";
        return false;
    }
    bool cargar() override {
        m_ = abrir_motor(base(), {1, 1, 128, 128}, error);
        if (!m_) return false;
        motor = m_->nombre;
        return ok = true;
    }
    void liberar() override {
        m_.reset();
        ok = false;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        cv::Mat g;
        cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
        int med = (int)cv::mean(g)[0];
        std::vector<Det> r;
        auto cs = segmentar_fondo(img, ctx.fondo, p["umbral"], p["area_min"], ctx.mascara_proy);
        if (cs.size() > 6) cs.resize(6);
        for (auto& c : cs) {
            cv::Rect bb = cv::boundingRect(c);
            float cx = bb.x + bb.width / 2.f, cy = bb.y + bb.height / 2.f;
            int lado = (int)(std::hypot(bb.width, bb.height) * 1.05) + 4;
            cv::Mat M = (cv::Mat_<double>(2, 3) << 1, 0, lado / 2.0 - cx, 0, 1, lado / 2.0 - cy);
            cv::Mat rec;
            cv::warpAffine(g, rec, M, cv::Size(lado, lado), cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(med));
            cv::resize(rec, rec, cv::Size(144, 144));
            rec = rec(cv::Rect(8, 8, 128, 128));
            int sz[] = {1, 1, 128, 128};
            cv::Mat blob(4, sz, CV_32F);
            cv::Mat pl(128, 128, CV_32F, blob.ptr<float>());
            rec.convertTo(pl, CV_32F, 1.0 / 255);
            cv::Mat o = m_->correr(blob)[0].reshape(1, 1);
            cv::Point mx;
            double vmax;
            cv::minMaxLoc(o, nullptr, &vmax, nullptr, &mx);
            cv::Mat e;
            cv::exp(o - vmax, e);
            Det d;
            d.angulo = (float)mx.x;
            d.conf = (float)(1.0 / cv::sum(e)[0]);
            d.clase = fmt("%d grados", mx.x);
            d.caja = bb;
            d.contorno = c;
            r.push_back(d);
        }
        return r;
    }

private:
    std::unique_ptr<Motor> m_;
};

// ====================================================================== 7 ejemplos
class Ejemplos : public Modelo {
public:
    explicit Ejemplos(Contexto& c) : Modelo(c) { p = {{"umbral", 0.55}, {"dif", 30}, {"area_min", 400}, {"nms", 0.45}}; }
    std::string id() const override { return "ejemplos"; }
    std::string nombre() const override { return "Ejemplos ensenados (Terminator)"; }
    std::string licencia() const override { return "propio"; }
    bool disponible(std::string& w) override {
        if (ctx.memoria && !ctx.memoria->vacia()) return true;
        w = "aun no le ensenas nada (tecla e)";
        return false;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        return ctx.memoria->buscar(img, ctx.fondo, ctx.mascara_proy, p["umbral"], p["dif"], p["area_min"]);
    }
};

// ====================================================================== 8 backgroundNet
class FondoIA : public Modelo {
public:
    explicit FondoIA(Contexto& c) : Modelo(c) { p = {{"umbral", 0.5}, {"area_min", 400}, {"nms", 0.45}}; }
    std::string id() const override { return "fondo_ia"; }
    std::string nombre() const override { return "backgroundNet U2-Net (jetson-inference)"; }
    std::string licencia() const override { return "MIT (jetson-inference)"; }
    bool disponible(std::string& w) override {
#ifdef CON_BACKGROUNDNET
        return true;
#else
        w = "falta jetson-inference con backgroundNet (version 2023 o mas nueva)";
        return false;
#endif
    }
#ifdef CON_BACKGROUNDNET
    bool cargar() override {
        std::vector<std::string> a = {"austero", "--network=u2net"};
        auto av = argv_de(a);
        net_ = backgroundNet::Create((int)av.size(), av.data());
        if (!net_) return false;
        motor = "TensorRT (backgroundNet)";
        return ok = true;
    }
    void liberar() override {
        delete net_;
        net_ = nullptr;
        ok = false;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        uchar4* p4 = (uchar4*)buf_.subir(img, 4);
        net_->Process(p4, img.cols, img.rows, FILTER_LINEAR, true);
        cudaDeviceSynchronize();
        cv::Mat rgba(img.rows, img.cols, CV_8UC4, buf_.ptr), alfa, m;
        cv::extractChannel(rgba, alfa, 3);
        cv::threshold(alfa, m, 255 * p["umbral"], 255, cv::THRESH_BINARY);
        std::vector<std::vector<cv::Point>> cs;
        cv::findContours(m, cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
        std::vector<Det> r;
        for (auto& c : cs)
            if (cv::contourArea(c) >= p["area_min"]) {
                Det d;
                d.clase = "objeto";
                d.caja = cv::boundingRect(c);
                d.contorno = c;
                r.push_back(d);
            }
        return r;
    }
    ~FondoIA() override { liberar(); }

private:
    backgroundNet* net_ = nullptr;
    BufCuda buf_;
#else
    std::vector<Det> procesar(const cv::Mat&) override { return {}; }
#endif
};

// ====================================================================== catalogo
std::vector<InfoModelo> catalogo() {
    return {{"1", "fondo", "Resta de fondo (OpenCV)"},
            {"2", "ssd_general", "detectNet SSD-MobileNet-v2 (COCO)"},
            {"3", "ssd_propio", "detectNet SSD re-entrenado (tuyo)"},
            {"4", "yolo_mit4", "YOLO11-L 4 instrumentos (MIT)"},
            {"5", "yolo_doccheck12", "YOLOv5-L 12 instrumentos (DocCheck)"},
            {"6", "orientacion", "Orientacion 0-357 (DocCheck)"},
            {"7", "ejemplos", "Ejemplos ensenados (Terminator)"},
            {"8", "fondo_ia", "backgroundNet U2-Net"},
            {"9", "yolo_alumno", "YOLO nano alumno (tuyo)"}};
}

std::unique_ptr<Modelo> crear_modelo(const std::string& x, Contexto& c) {
    std::string id = x;
    for (auto& m : catalogo())
        if (m.tecla == x) id = m.id;
    Modelo* m = nullptr;
    if (id == "fondo") m = new Fondo(c);
    else if (id == "ssd_general") m = new SSD(c, false);
    else if (id == "ssd_propio") m = new SSD(c, true);
    else if (id == "yolo_mit4")
        m = new Yolo(c, id, "YOLO11-L 4 instrumentos (MIT)", "MIT", "yolo_mit4", false,
                     {"Bisturi", "Pinza diseccion recta", "Tijera Mayo recta", "Tijera Mayo curva"}, 416);
    else if (id == "yolo_doccheck12")
        m = new Yolo(c, id, "YOLOv5-L 12 instrumentos (DocCheck Rona)", "CC BY-NC 4.0 (sin uso comercial)",
                     "yolo_doccheck12", true,
                     {"Pinza anatomica estandar", "Pinza anatomica delgada", "Pinza quirurgica", "Pinza de astillas",
                      "Mango bisturi n3", "Mango bisturi n4", "Hoja bisturi abombada", "Hoja bisturi delgada",
                      "Tijera quirurgica punta/punta", "Tijera quirurgica punta/roma", "Tijera de diseccion",
                      "Aguja de diseccion"},
                     640);
    else if (id == "orientacion") m = new Orientacion(c);
    else if (id == "ejemplos") m = new Ejemplos(c);
    else if (id == "fondo_ia") m = new FondoIA(c);
    else if (id == "yolo_alumno")
        m = new Yolo(c, id, "YOLO nano alumno (entrenado con tus ejemplos)", "tuyo", "yolo_alumno", false, {}, 320);
    return std::unique_ptr<Modelo>(m);
}

// ====================================================================== manos
struct Manos::Impl {
#ifdef CON_JETSON_INFERENCE
    poseNet* net = nullptr;
    BufCuda buf;
#endif
};
Manos::Manos() : impl_(new Impl()) {}
Manos::~Manos() {
    liberar();
    delete impl_;
}
bool Manos::cargar() {
#ifdef CON_JETSON_INFERENCE
    std::vector<std::string> a = {"austero", "--network=resnet18-hand", fmt("--threshold=%.3f", umbral)};
    auto av = argv_de(a);
    impl_->net = poseNet::Create((int)av.size(), av.data());
    if (!impl_->net) {
        error = "poseNet resnet18-hand no cargo (corre download-models.sh de jetson-inference)";
        return false;
    }
    motor = "poseNet (TensorRT)";
    return ok = true;
#else
    error = "manos necesita jetson-inference (en la Jetson)";
    return false;
#endif
}
void Manos::liberar() {
#ifdef CON_JETSON_INFERENCE
    delete impl_->net;
    impl_->net = nullptr;
#endif
    ok = false;
}
std::vector<Mano> Manos::procesar(const cv::Mat& img) {
    std::vector<Mano> r;
#ifdef CON_JETSON_INFERENCE
    std::vector<poseNet::ObjectPose> poses;
    if (!impl_->net->Process((uchar3*)impl_->buf.subir(img), img.cols, img.rows, poses, poseNet::OVERLAY_NONE)) return r;
    for (auto& p : poses) {
        Mano m;
        m.puntos.assign(21, cv::Point2f(-1, -1));
        for (auto& k : p.Keypoints)
            if (k.ID < 21) m.puntos[k.ID] = cv::Point2f(k.x, k.y);
        r.push_back(m);
    }
#else
    (void)img;
#endif
    return r;
}
