#include "camara.hpp"

#include <fcntl.h>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <cmath>

#include <opencv2/imgproc.hpp>

using util::log;
using util::fmt;

// ====================================================================== V4L2 por ioctl (sin procesos extra)
static const std::map<std::string, std::vector<unsigned>> CIDS = {
    {"exposicion_auto", {V4L2_CID_EXPOSURE_AUTO}},
    {"exposicion", {V4L2_CID_EXPOSURE_ABSOLUTE}},
    {"ganancia", {V4L2_CID_GAIN}},
    {"blancos_auto", {V4L2_CID_AUTO_WHITE_BALANCE}},
    {"blancos", {V4L2_CID_WHITE_BALANCE_TEMPERATURE}},
    {"brillo", {V4L2_CID_BRIGHTNESS}},
    {"contraste", {V4L2_CID_CONTRAST}},
};

ControlesV4L2::ControlesV4L2(const std::string& dev) {
    fd = ::open(dev.c_str(), O_RDWR | O_NONBLOCK);
    if (fd < 0) return;
    for (auto& kv : CIDS) {
        for (unsigned id : kv.second) {
            v4l2_queryctrl q{};
            q.id = id;
            if (ioctl(fd, VIDIOC_QUERYCTRL, &q) == 0 && !(q.flags & V4L2_CTRL_FLAG_DISABLED)) {
                ids[kv.first] = id;
                break;
            }
        }
    }
}
ControlesV4L2::~ControlesV4L2() {
    if (fd >= 0) ::close(fd);
}
bool ControlesV4L2::tiene(const std::string& n) { return ids.count(n) > 0; }
bool ControlesV4L2::rango(const std::string& n, int& mn, int& mx) {
    if (!tiene(n)) return false;
    v4l2_queryctrl q{};
    q.id = ids[n];
    if (ioctl(fd, VIDIOC_QUERYCTRL, &q) != 0) return false;
    mn = q.minimum;
    mx = q.maximum;
    return true;
}
int ControlesV4L2::leer(const std::string& n) {
    if (!tiene(n)) return 0;
    v4l2_control c{};
    c.id = ids[n];
    if (ioctl(fd, VIDIOC_G_CTRL, &c) != 0) return 0;
    return c.value;
}
bool ControlesV4L2::poner(const std::string& n, int v) {
    if (!tiene(n)) return false;
    v4l2_control c{};
    c.id = ids[n];
    c.value = v;
    return ioctl(fd, VIDIOC_S_CTRL, &c) == 0;
}

ControlesSim::ControlesSim() {
    v["exposicion_auto"] = {0, 3, 3};
    v["exposicion"] = {3, 2047, 1500};
    v["ganancia"] = {0, 255, 0};
}
bool ControlesSim::rango(const std::string& n, int& mn, int& mx) {
    if (!tiene(n)) return false;
    mn = v[n][0];
    mx = v[n][1];
    return true;
}
bool ControlesSim::poner(const std::string& n, int x) {
    if (!tiene(n)) return false;
    v[n][2] = std::max(v[n][0], std::min(v[n][1], x));
    return true;
}
double ControlesSim::factor() { return (v["exposicion"][2] / 300.0) * (1.0 + v["ganancia"][2] / 64.0); }

// ====================================================================== mesa simulada
EscenaSim::EscenaSim(int w_, int h_) : w(w_), h(h_), rng(3) {
    mesa = cv::Mat(h, w, CV_32FC3, cv::Scalar(70, 75, 72));
    cv::Mat ruido(h / 8, w / 8, CV_32F);
    rng.fill(ruido, cv::RNG::NORMAL, 0, 4);
    cv::resize(ruido, ruido, cv::Size(w, h));
    cv::Mat r3;
    cv::merge(std::vector<cv::Mat>{ruido, ruido, ruido}, r3);
    mesa += r3;
    double m = 0.08;
    esq_proy_en_cam = {{(float)(w * m), (float)(h * (m + 0.02))}, {(float)(w * (1 - m * 0.7)), (float)(h * m)},
                       {(float)(w * (1 - m)), (float)(h * (1 - m))}, {(float)(w * m * 1.2), (float)(h * (1 - m * 1.1))}};
    revolver(2);
}
void EscenaSim::revolver(int n) {
    std::lock_guard<std::mutex> lk(mx);
    const char* tipos[] = {"tijera", "bisturi", "pinza"};
    objetos.clear();
    for (int i = 0; i < n; i++)
        objetos.push_back({tipos[i % 3], rng.uniform(0.25, 0.75) * w, rng.uniform(0.3, 0.7) * h, rng.uniform(0.0, 180.0)});
}
void EscenaSim::pieza(const std::string& tipo) {
    std::lock_guard<std::mutex> lk(mx);
    objetos = {{tipo, rng.uniform(0.3, 0.7) * w, rng.uniform(0.35, 0.65) * h, rng.uniform(0.0, 180.0)}};
}
void EscenaSim::dibujar_objeto(cv::Mat& img, const ObjetoSim& o) {
    double a = o.ang * CV_PI / 180.0, c = std::cos(a), s = std::sin(a);
    auto P = [&](double dx, double dy) { return cv::Point((int)(o.x + dx * c - dy * s), (int)(o.y + dx * s + dy * c)); };
    cv::Scalar col(205, 205, 210);
    if (o.tipo == "tijera") {
        cv::line(img, P(-90, -14), P(60, 10), col, 7);
        cv::line(img, P(-90, 14), P(60, -10), col, 7);
        cv::circle(img, P(-105, -20), 15, col, 5);
        cv::circle(img, P(-105, 20), 15, col, 5);
    } else if (o.tipo == "bisturi") {
        cv::line(img, P(-90, 0), P(40, 0), col, 10);
        std::vector<cv::Point> pts = {P(40, -6), P(85, 0), P(40, 7)};
        cv::fillPoly(img, std::vector<std::vector<cv::Point>>{pts}, cv::Scalar(225, 225, 230));
    } else {
        cv::line(img, P(-80, -3), P(70, -16), col, 6);
        cv::line(img, P(-80, 3), P(70, 16), col, 6);
    }
}
cv::Mat EscenaSim::render(const cv::Mat& proy, double factor) {
    cv::Mat img = mesa.clone();
    cv::Mat luz;
    if (!proy.empty()) {
        cv::Mat p;
        cv::resize(proy, p, cv::Size(960, 960 * proy.rows / proy.cols), 0, 0, cv::INTER_AREA);
        std::vector<cv::Point2f> src = {{0, 0}, {(float)p.cols, 0}, {(float)p.cols, (float)p.rows}, {0, (float)p.rows}};
        cv::Mat H = cv::getPerspectiveTransform(src, esq_proy_en_cam);
        cv::Mat pw;
        cv::warpPerspective(p, pw, H, cv::Size(w, h));
        pw.convertTo(luz, CV_32FC3, 1.3 / 255.0, 0.55);
    } else {
        luz = cv::Mat(h, w, CV_32FC3, cv::Scalar(0.55, 0.55, 0.55));
    }
    cv::Mat objs = cv::Mat::zeros(h, w, CV_8UC3);
    {
        std::lock_guard<std::mutex> lk(mx);
        for (auto& o : objetos) dibujar_objeto(objs, o);
        if (!marcador.empty()) {
            cv::Rect r(marcador_pos, marcador.size());
            marcador.copyTo(objs(r));
            img(r).setTo(cv::Scalar(0, 0, 0));
        }
    }
    cv::Mat msk;
    cv::cvtColor(objs, msk, cv::COLOR_BGR2GRAY);
    msk = msk > 0;
    cv::Mat of;
    objs.convertTo(of, CV_32FC3, 0.85);
    of.copyTo(img, msk);
    if (!marcador.empty()) {   // el papel blanco del marcador
    }
    img = img.mul(luz) * factor;
    cv::Mat ruido(h, w, CV_32FC3);
    rng.fill(ruido, cv::RNG::NORMAL, 0, 2.0);
    img += ruido;
    cv::Mat out;
    img.convertTo(out, CV_8UC3);
    return out;
}

// ====================================================================== camara
Camara::Camara(const json& cfg) : cfg_(cfg) {
    tipo = cfg.value("tipo", "usb");
    ancho = cfg.value("ancho", 1280);
    alto = cfg.value("alto", 720);
    abrir();
}
Camara::~Camara() { detener(); }

void Camara::abrir() {
    int idx = cfg_.value("indice", 0);
    int fps = cfg_.value("fps", 30);
    if (tipo == "sim") {
        escena.reset(new EscenaSim(ancho, alto));
        ctl.reset(new ControlesSim());
        ok = true;
        return;
    }
    std::string dev = fmt("/dev/video%d", idx);
    if (tipo == "csi") {
        std::string p = fmt("nvarguscamerasrc sensor-id=%d ! video/x-raw(memory:NVMM),width=%d,height=%d,framerate=%d/1 ! "
                            "nvvidconv ! video/x-raw,format=BGRx ! videoconvert ! video/x-raw,format=BGR ! "
                            "appsink drop=1 max-buffers=1 sync=false", idx, ancho, alto, fps);
        cap_.open(p, cv::CAP_GSTREAMER);
    } else if (tipo == "usb_hw") {
        // JPEG -> decodificador por hardware de la Jetson (libera CPU)
        std::string p = fmt("v4l2src device=%s io-mode=2 ! image/jpeg,width=%d,height=%d,framerate=%d/1 ! "
                            "nvv4l2decoder mjpeg=1 ! nvvidconv ! video/x-raw,format=BGRx ! videoconvert ! "
                            "video/x-raw,format=BGR ! appsink drop=1 max-buffers=1 sync=false",
                            dev.c_str(), ancho, alto, fps);
        cap_.open(p, cv::CAP_GSTREAMER);
        ctl.reset(new ControlesV4L2(dev));
    } else {
        cap_.open(idx, cv::CAP_V4L2);
        if (cfg_.value("mjpg", true)) cap_.set(cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'));
        cap_.set(cv::CAP_PROP_FRAME_WIDTH, ancho);
        cap_.set(cv::CAP_PROP_FRAME_HEIGHT, alto);
        cap_.set(cv::CAP_PROP_FPS, fps);
        cap_.set(cv::CAP_PROP_BUFFERSIZE, 1);
        ctl.reset(new ControlesV4L2(dev));
    }
    ok = cap_.isOpened();
    if (!ok) error = "no abre la camara " + tipo + " " + dev;
    if (!ctl) ctl.reset(new ControlesSim());   // CSI: sin controles V4L2
}

bool Camara::leer_uno(cv::Mat& out) {
    if (tipo == "sim") {
        util::dormir(1.0 / 20);
        cv::Mat p = imagen_proyector ? imagen_proyector() : cv::Mat();
        out = escena->render(p, static_cast<ControlesSim*>(ctl.get())->factor());
        return true;
    }
    return cap_.read(out) && !out.empty();
}

void Camara::bucle() {
    double t0 = util::ahora();
    int k = 0;
    while (vivo) {
        cv::Mat img;   // nuevo cada vez: quien lo leyo antes conserva el suyo
        if (!leer_uno(img)) {
            util::dormir(0.05);
            continue;
        }
        if (img.cols != ancho || img.rows != alto) {
            ancho = img.cols;
            alto = img.rows;
        }
        {
            std::lock_guard<std::mutex> lk(mx_);
            cuadro_ = img;
            n_++;
        }
        k++;
        double t = util::ahora();
        if (t - t0 >= 1.0) {
            fps_cap = k / (t - t0);
            t0 = t;
            k = 0;
        }
    }
}

bool Camara::iniciar() {
    if (!ok) {
        log("camara: " + error);
        return false;
    }
    vivo = true;
    hilo_ = std::thread(&Camara::bucle, this);
    return true;
}
void Camara::detener() {
    if (vivo) {
        vivo = false;
        if (hilo_.joinable()) hilo_.join();
    }
    if (cap_.isOpened()) cap_.release();
}
bool Camara::leer(cv::Mat& img, long& n) {
    std::lock_guard<std::mutex> lk(mx_);
    img = cuadro_;
    n = n_;
    return !img.empty();
}
bool Camara::esperar_nuevo(long n_ant, cv::Mat& img, long& n, double timeout) {
    double t = util::ahora();
    while (util::ahora() - t < timeout) {
        if (leer(img, n) && n > n_ant) return true;
        util::dormir(0.003);
    }
    return leer(img, n);
}
cv::Mat Camara::promedio(int cuantos, double espera) {
    util::dormir(espera);
    cv::Mat img, acc;
    long n;
    leer(img, n);
    int k = 0;
    for (int i = 0; i < cuantos; i++) {
        if (!esperar_nuevo(n, img, n, 1.5) || img.empty()) continue;
        cv::Mat f;
        img.convertTo(f, CV_32FC3);
        if (acc.empty()) acc = f;
        else acc += f;
        k++;
    }
    if (!k) return cv::Mat();
    cv::Mat out;
    acc.convertTo(out, CV_8UC3, 1.0 / k);
    return out;
}

// ====================================================================== filtros
Filtros::Filtros(const json& p) {
    gamma_ = p.value("gamma", 1.0);
    clahe_ = p.value("clahe", 0.0);
    suavizado_ = p.value("suavizado", 0);
    nitidez_ = p.value("nitidez", 0.0);
    rehacer();
}
bool Filtros::poner(const std::string& k, double v) {
    if (k == "gamma") gamma_ = std::max(0.1, v);
    else if (k == "clahe") clahe_ = std::max(0.0, v);
    else if (k == "nitidez") nitidez_ = std::max(0.0, v);
    else if (k == "suavizado") {
        int x = (int)v;
        suavizado_ = x < 3 ? 0 : std::min(15, x | 1);
    } else return false;
    rehacer();
    return true;
}
double Filtros::get(const std::string& k) const {
    if (k == "gamma") return gamma_;
    if (k == "clahe") return clahe_;
    if (k == "nitidez") return nitidez_;
    if (k == "suavizado") return suavizado_;
    return 0;
}
json Filtros::params() const {
    return {{"gamma", gamma_}, {"clahe", clahe_}, {"suavizado", suavizado_}, {"nitidez", nitidez_}};
}
void Filtros::rehacer() {
    if (std::fabs(gamma_ - 1.0) < 0.01) {
        lut_.release();
    } else {
        lut_.create(1, 256, CV_8U);
        for (int i = 0; i < 256; i++) lut_.at<uchar>(i) = cv::saturate_cast<uchar>(std::pow(i / 255.0, 1.0 / gamma_) * 255.0);
    }
}
void Filtros::aplicar(cv::Mat& img) const {
    if (!lut_.empty()) cv::LUT(img, lut_, img);
    if (clahe_ > 0.05) {
        static thread_local cv::Ptr<cv::CLAHE> cl;
        static thread_local double cl_v = -1;
        if (!cl || cl_v != clahe_) {
            cl = cv::createCLAHE(clahe_, cv::Size(8, 8));
            cl_v = clahe_;
        }
        cv::Mat lab;
        cv::cvtColor(img, lab, cv::COLOR_BGR2Lab);
        std::vector<cv::Mat> ch;
        cv::split(lab, ch);
        cl->apply(ch[0], ch[0]);
        cv::merge(ch, lab);
        cv::cvtColor(lab, img, cv::COLOR_Lab2BGR);
    }
    if (suavizado_ >= 3) cv::GaussianBlur(img, img, cv::Size(suavizado_, suavizado_), 0);
    if (nitidez_ > 0.01) {
        cv::Mat bl;
        cv::GaussianBlur(img, bl, cv::Size(0, 0), 2.0);
        cv::addWeighted(img, 1.0 + nitidez_, bl, -nitidez_, 0, img);
    }
}

// ====================================================================== auto-ajuste
static bool medir(Camara& cam, double& m, double& sat, double& sd) {
    cv::Mat img = cam.promedio(3, 0.35);
    if (img.empty()) return false;
    cv::Mat g;
    cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
    cv::Rect c(g.cols / 6, g.rows / 6, g.cols * 2 / 3, g.rows * 2 / 3);
    cv::Scalar mu, s;
    cv::meanStdDev(g(c), mu, s);
    m = mu[0];
    sd = s[0];
    sat = cv::countNonZero(g >= 250) / (double)g.total();
    return true;
}

std::string autoajuste(Camara& cam, Filtros& f, double objetivo, double max_sat) {
    Controles* ctl = cam.ctl.get();
    std::vector<std::string> rep;
    double m, sat, sd;
    if (ctl && ctl->tiene("exposicion")) {
        if (ctl->tiene("exposicion_auto")) ctl->poner("exposicion_auto", ctl->valor_manual_exposicion());
        int lo, hi;
        ctl->rango("exposicion", lo, hi);
        lo = std::max(lo, 1);
        double a = std::log((double)lo), b = std::log((double)std::max(hi, lo + 1));
        double mejor_err = 1e9;
        int mejor_e = -1;
        double mejor_m = 0;
        for (int it = 0; it < 9; it++) {
            int e = (int)std::exp((a + b) / 2);
            ctl->poner("exposicion", e);
            if (!medir(cam, m, sat, sd)) break;
            double err = std::fabs(m - objetivo) + (sat > max_sat ? 400 * (sat - max_sat) : 0);
            if (err < mejor_err) {
                mejor_err = err;
                mejor_e = e;
                mejor_m = m;
            }
            log(fmt("auto-ajuste: exp=%d brillo=%.0f saturados=%.1f%%", e, m, sat * 100));
            if (std::fabs(m - objetivo) < 6 && sat <= max_sat) break;
            if (m < objetivo && sat <= max_sat) a = std::log((double)e);
            else b = std::log((double)e);
        }
        if (mejor_e > 0) {
            ctl->poner("exposicion", mejor_e);
            rep.push_back(fmt("exposicion=%d", mejor_e));
            if (mejor_m < objetivo - 20 && ctl->tiene("ganancia")) {
                int glo, ghi;
                ctl->rango("ganancia", glo, ghi);
                for (int i = 1; i <= 5; i++) {
                    ctl->poner("ganancia", glo + (ghi - glo) * i / 5);
                    if (!medir(cam, m, sat, sd) || m >= objetivo - 8 || sat > max_sat) break;
                }
                rep.push_back(fmt("ganancia=%d", ctl->leer("ganancia")));
            }
        }
    }
    if (ctl && ctl->tiene("blancos_auto") && ctl->tiene("blancos")) {
        ctl->poner("blancos_auto", 1);
        util::dormir(1.2);
        int v = ctl->leer("blancos");
        ctl->poner("blancos_auto", 0);
        if (v) {
            ctl->poner("blancos", v);
            rep.push_back(fmt("blancos=%d", v));
        }
    }
    f.poner("gamma", 1.0);
    f.poner("clahe", 0.0);
    if (medir(cam, m, sat, sd)) {
        if (std::fabs(m - objetivo) > 15 && m > 5 && m < 250) {
            double g = std::log(m / 255.0) / std::log(objetivo / 255.0);
            g = std::max(0.6, std::min(1.8, g));
            f.poner("gamma", std::round(g * 100) / 100);
            rep.push_back(fmt("gamma=%.2f", g));
        }
        if (sd < 35) {
            f.poner("clahe", 2.0);
            rep.push_back("clahe=2.0 (poco contraste)");
        }
        rep.push_back(fmt("brillo=%.0f", m));
    }
    std::string t = "auto-ajuste listo:";
    for (auto& r : rep) t += " " + r;
    if (rep.empty()) t = "auto-ajuste: la camara no tiene controles";
    log(t);
    return t;
}
