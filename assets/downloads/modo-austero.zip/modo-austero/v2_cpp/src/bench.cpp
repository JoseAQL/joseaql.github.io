#include "bench.hpp"

#include <algorithm>
#include <cmath>
#include <functional>
#include <numeric>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "nucleo.hpp"

using util::fmt;
using util::log;

static double iou(const cv::Rect& a, const cv::Rect& b) {
    double i = (a & b).area(), u = a.area() + b.area() - i;
    return u > 0 ? i / u : 0;
}

struct Verdad {
    cv::Mat img;
    std::vector<cv::Rect> cajas;
};

static std::vector<Verdad> cargar_verdad(Nucleo& n, size_t maximo = 30) {
    std::vector<Verdad> r;
    std::string di = util::ruta("dataset/images"), dl = util::ruta("dataset/labels");
    auto fs = util::listar(di);
    if (fs.size() > maximo) fs.erase(fs.begin(), fs.end() - maximo);
    for (auto& f : fs) {
        if (f.size() < 5) continue;
        std::string lab = dl + "/" + f.substr(0, f.size() - 4) + ".txt";
        if (!util::existe(lab)) continue;
        cv::Mat img = cv::imread(di + "/" + f);
        if (img.empty()) continue;
        cv::resize(img, img, cv::Size(n.ancho_proc, n.alto_proc));
        Verdad v;
        v.img = img;
        double W = n.ancho_proc, H = n.alto_proc;
        for (auto& l : util::leer_lineas(lab)) {
            int c;
            double cx, cy, w, h;
            if (sscanf(l.c_str(), "%d %lf %lf %lf %lf", &c, &cx, &cy, &w, &h) == 5)
                v.cajas.push_back(cv::Rect(cv::Point((int)((cx - w / 2) * W), (int)((cy - h / 2) * H)),
                                           cv::Point((int)((cx + w / 2) * W), (int)((cy + h / 2) * H))));
        }
        r.push_back(v);
    }
    return r;
}

static const std::vector<std::pair<std::string, std::string>> COLS = {
    {"modelo", "Modelo"}, {"fps", "FPS"}, {"lat_p50", "ms p50"}, {"lat_p95", "ms p95"}, {"cpu", "CPU%"},
    {"cpu_proc", "Proc%"}, {"gpu", "GPU%"}, {"ram_extra_mb", "+RAM MB"}, {"temp_max", "Temp C"},
    {"potencia_mw", "mW"}, {"det_por_cuadro", "Det/cuadro"}, {"aciertos", "Aciertos"}, {"carga_s", "Carga s"},
    {"motor", "Motor"}};

static std::string val(const json& f, const std::string& k) {
    if (!f.contains(k) || f[k].is_null()) return "-";
    if (f[k].is_string()) return f[k];
    if (f[k].is_number_float()) return fmt("%.1f", f[k].get<double>());
    return f[k].dump();
}

std::string tabla_texto(const json& filas) {
    std::vector<size_t> an;
    for (auto& c : COLS) {
        size_t a = c.second.size();
        for (auto& f : filas) a = std::max(a, val(f, c.first).size());
        an.push_back(a);
    }
    auto pad = [](std::string s, size_t n) { return s + std::string(n > s.size() ? n - s.size() : 0, ' '); };
    std::string t;
    for (size_t i = 0; i < COLS.size(); i++) t += pad(COLS[i].second, an[i]) + (i + 1 < COLS.size() ? " | " : "\n");
    for (size_t i = 0; i < COLS.size(); i++) t += std::string(an[i], '-') + (i + 1 < COLS.size() ? "-+-" : "\n");
    for (auto& f : filas) {
        if (f.contains("nota")) {
            t += pad(f.value("modelo", ""), an[0]) + " | " + f.value("nota", "") + "\n";
            continue;
        }
        for (size_t i = 0; i < COLS.size(); i++) t += pad(val(f, COLS[i].first), an[i]) + (i + 1 < COLS.size() ? " | " : "\n");
    }
    return t;
}

static std::string escribir(const json& filas) {
    std::string base = util::ruta("bench/bench_" + util::fecha_archivo());
    std::string csv, md = "# Benchmark Modo Austero (C++) " + util::fecha_archivo() + "\n\n|";
    for (auto& c : COLS) {
        csv += c.first + ",";
        md += " " + c.second + " |";
    }
    csv += "nota\n";
    md += "\n|";
    for (size_t i = 0; i < COLS.size(); i++) md += "---|";
    md += "\n";
    for (auto& f : filas) {
        md += "|";
        for (auto& c : COLS) {
            std::string v = val(f, c.first);
            csv += "\"" + v + "\",";
            md += " " + (c.first == "modelo" || !f.contains("nota") ? v : (c.first == "fps" ? f.value("nota", "") : "")) + " |";
        }
        csv += "\"" + f.value("nota", "") + "\"\n";
        md += "\n";
    }
    util::escribir_texto(base + ".csv", csv);
    util::escribir_texto(base + ".md", md);
    return base + ".md";
}

json correr_bench(Nucleo& n, std::vector<std::string> ids, double segundos) {
    json cfg = n.cfg.value("bench", json::object());
    if (ids.empty() || (ids.size() == 1 && ids[0] == "todos"))
        for (auto& c : catalogo()) ids.push_back(c.id);
    std::string previo = n.modelo ? n.modelo->id() : "";
    if (n.modelo) n.modelo->liberar();
    n.modelo.reset();
    // clip: los mismos cuadros para todos
    std::vector<cv::Mat> clip;
    cv::Mat img;
    long k = 0;
    n.cam->leer(img, k);
    for (int i = 0; i < cfg.value("frames_clip", 60); i++)
        if (n.cam->esperar_nuevo(k, img, k, 1.0) && !img.empty()) clip.push_back(n.procesar_cuadro(img));
    if (clip.empty()) return {{"ok", false}, {"msg", "bench: sin camara"}};
    auto verdad = cargar_verdad(n);
    bool necesita_fondo = false;
    for (auto& i : ids) necesita_fondo |= i == "fondo" || i == "1" || i == "orientacion" || i == "6" || i == "ejemplos" || i == "7";
    if (necesita_fondo && n.ctx.fondo.empty()) n.cmd({{"cmd", "fondo"}});
    log(fmt("bench: %d modelos x %.0f s, clip de %d cuadros, %d fotos con etiqueta", (int)ids.size(), segundos,
            (int)clip.size(), (int)verdad.size()));
    json filas = json::array();
    for (auto& id : ids) {
        auto m = crear_modelo(id, n.ctx);
        if (!m) continue;
        json f = {{"modelo", m->id()}, {"nombre", m->nombre()}, {"licencia", m->licencia()}};
        std::string w;
        if (!m->disponible(w)) {
            f["nota"] = "no disponible: " + w;
            filas.push_back(f);
            log("bench " + m->id() + ": " + f.value("nota", ""));
            continue;
        }
        int ram0 = n.stats.foto().ram_mb;
        util::Crono cc;
        if (!m->cargar()) {
            f["nota"] = "no cargo: " + m->error;
            filas.push_back(f);
            continue;
        }
        f["carga_s"] = std::round(cc.s() * 10) / 10;
        f["motor"] = m->motor;
        n.ocupado = "bench " + m->id();
        log(fmt("bench %s: cargado en %.1f s (%s)", m->id().c_str(), cc.s(), m->motor.c_str()));
        for (int i = 0; i < cfg.value("calentamiento", 10); i++) m->procesar(clip[i % clip.size()]);
        std::vector<double> lat;
        std::vector<int> nd;
        std::vector<Muestra> mu;
        util::Crono t0;
        double tm = util::ahora();
        size_t i = 0;
        while (t0.s() < segundos) {
            util::Crono c1;
            nd.push_back((int)m->procesar(clip[i % clip.size()]).size());
            lat.push_back(c1.ms());
            i++;
            if (util::ahora() - tm >= 1.0) {
                mu.push_back(n.stats.foto());
                tm = util::ahora();
                n.proy->actualizar();
            }
        }
        double dur = t0.s();
        std::vector<double> ls = lat;
        std::sort(ls.begin(), ls.end());
        f["fps"] = std::round(i / dur * 10) / 10;
        f["lat_p50"] = std::round(ls[ls.size() / 2] * 10) / 10;
        f["lat_p95"] = std::round(ls[(size_t)(0.95 * (ls.size() - 1))] * 10) / 10;
        f["det_por_cuadro"] = std::round(std::accumulate(nd.begin(), nd.end(), 0.0) / nd.size() * 100) / 100;
        auto prom = [&](std::function<double(const Muestra&)> g) -> json {
            std::vector<double> v;
            for (auto& s : mu) {
                double x = g(s);
                if (x >= 0) v.push_back(x);
            }
            if (v.empty()) return nullptr;
            return std::round(std::accumulate(v.begin(), v.end(), 0.0) / v.size() * 10) / 10;
        };
        f["cpu"] = prom([](const Muestra& s) { return s.cpu_prom; });
        f["cpu_proc"] = prom([](const Muestra& s) { return s.proc_cpu; });
        f["gpu"] = prom([](const Muestra& s) { return (double)s.gpu; });
        f["ram_mb"] = prom([](const Muestra& s) { return (double)s.ram_mb; });
        f["ram_extra_mb"] = f["ram_mb"].is_null() ? json(nullptr) : json(std::round(f["ram_mb"].get<double>() - ram0));
        f["ram_proc_mb"] = prom([](const Muestra& s) { return s.proc_ram_mb; });
        f["potencia_mw"] = prom([](const Muestra& s) { return (double)s.potencia_mw; });
        double tmax = -1;
        for (auto& s : mu) tmax = std::max(tmax, s.temp_max());
        f["temp_max"] = tmax >= 0 ? json(std::round(tmax * 10) / 10) : json(nullptr);
        if (!verdad.empty()) {
            int total = 0, hall = 0;
            for (auto& v : verdad) {
                auto d = m->procesar(v.img);
                for (auto& c : v.cajas) {
                    total++;
                    for (auto& x : d)
                        if (iou(c, x.caja) >= 0.3) {
                            hall++;
                            break;
                        }
                }
            }
            f["aciertos"] = fmt("%d/%d", hall, total);
            f["aciertos_pct"] = std::round(1000.0 * hall / std::max(1, total)) / 10;
        }
        m->liberar();
        m.reset();
        filas.push_back(f);
        log(fmt("bench %s: %.1f fps, %.0f ms, aciertos %s", f.value("modelo", "").c_str(), f["fps"].get<double>(),
                f["lat_p50"].get<double>(), f.value("aciertos", "-").c_str()));
        util::dormir(1.5);   // que baje la RAM y la temperatura antes del siguiente
    }
    n.ocupado.clear();
    std::string arch = escribir(filas);
    if (!previo.empty()) n.cmd({{"cmd", "modelo"}, {"id", previo}});
    return {{"ok", true}, {"msg", "bench listo: " + arch.substr(util::base().size() + 1)}, {"tabla", tabla_texto(filas)},
            {"filas", filas}};
}
