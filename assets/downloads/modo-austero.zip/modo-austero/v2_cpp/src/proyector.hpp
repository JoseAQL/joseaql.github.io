// proyector.hpp - ventana a pantalla completa en el HDMI. Solo redibuja cuando algo cambia.
// Capas: patron (calibracion, tapa todo) | sombra (para ensenar) | marcas (detecciones) | mensaje
#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "util.hpp"

struct Sombra {
    int x = 0, y = 0, w = 0, h = 0;
    std::string texto;
    bool activa = false;
};

struct Marca {
    std::vector<cv::Point> pts;
    cv::Scalar color;
    std::string texto;
};

class Proyector {
public:
    Proyector(const json& cfg, bool simulado);
    bool encender();
    void apagar();
    void poner_patron(const cv::Mat& img);   // vacio = quitar
    void quitar_patron() { poner_patron(cv::Mat()); }
    bool hay_patron();
    void poner_sombra(const Sombra& s);
    void poner_marcas(const std::vector<Marca>& m);
    void poner_mensaje(const std::string& t);
    void actualizar();                       // llamar en el lazo principal
    cv::Mat imagen_actual();                 // lo que sale ahorita (la camara simulada lo usa)
    long version() const { return version_; }

    int w, h;
    bool simulado;
    std::atomic<bool> encendido{false};
    int relleno = 0;

private:
    json cfg_;
    std::mutex mx_;
    cv::Mat patron_, img_;
    Sombra sombra_;
    std::vector<Marca> marcas_;
    std::string mensaje_, firma_;
    bool sucio_ = true, ventana_ = false;
    std::atomic<long> version_{0};
    cv::Mat componer();
};
