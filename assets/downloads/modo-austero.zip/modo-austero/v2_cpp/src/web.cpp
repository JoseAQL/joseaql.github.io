#include "web.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstring>

#include <opencv2/imgcodecs.hpp>

#include "nucleo.hpp"

static const char* PAGINA = R"HTML(<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Modo Austero</title>
<style>
:root{--f:#0d1014;--c:#151a20;--t:#d7dde4;--g:#7b8794;--v:#5bd68a;--a:#f5c451;--r:#ef6b6b}
body{margin:0;background:var(--f);color:var(--t);font:14px/1.4 ui-monospace,Menlo,Consolas,monospace}
main{max-width:1100px;margin:auto;padding:12px 16px;display:grid;gap:12px;grid-template-columns:minmax(0,2fr) minmax(0,1fr)}
@media(max-width:800px){main{grid-template-columns:1fr}}
section{background:var(--c);border-radius:8px;padding:10px}
img{width:100%;border-radius:6px;background:#000;display:block}
button{background:#222a33;color:var(--t);border:1px solid #2f3a46;border-radius:6px;padding:6px 9px;margin:2px;cursor:pointer;font:inherit}
button:hover{border-color:var(--v)} .on{color:var(--v)} .off{color:var(--g)}
h1{font-size:15px;margin:0 0 6px} .bar{height:8px;background:#222a33;border-radius:4px;overflow:hidden;margin:2px 0 6px}
.bar i{display:block;height:100%} pre{white-space:pre-wrap;margin:0;color:var(--g);font-size:12px}
</style></head><body><main>
<section><img src="/stream.mjpg" alt="camara"><div id="dets"></div></section>
<section><h1>MODO AUSTERO <span style="color:var(--g)">C++</span></h1><div id="st"></div><div id="botones"></div>
<div><button onclick="c('autoajuste')">auto-ajuste</button><button onclick="c('calibrar',{metodo:'aruco'})">calibrar aruco</button>
<button onclick="c('calibrar',{metodo:'puntos'})">puntos</button><button onclick="c('calibrar',{metodo:'esquinas'})">esquinas</button>
<button onclick="c('calibrar',{metodo:'graycode'})">graycode</button><button onclick="c('verificar')">verificar</button>
<button onclick="c('fondo')">fondo</button><button onclick="c('manos')">manos</button><button onclick="c('buscar')">buscar</button>
<button onclick="c('proyector')">proyector</button><button onclick="ens()">enseñar…</button>
<button onclick="c('ensenar',{accion:'auto'})">propuesta</button><button onclick="c('ensenar',{accion:'guardar'})">guardar ejemplo</button>
<button onclick="c('ensenar',{accion:'cancelar'})">terminar</button><button onclick="c('web',{on:false})">apagar web</button></div>
<pre id="log"></pre></section></main>
<script>
function c(cmd,x){x=x||{};x.cmd=cmd;fetch('/cmd',{method:'POST',body:JSON.stringify(x)}).then(r=>r.json()).then(r=>{if(r.msg)document.getElementById('log').textContent='» '+r.msg})}
function ens(){var n=prompt('¿Qué pieza?');if(n)c('ensenar',{accion:'inicio',clase:n})}
function b(p){p=Math.max(0,Math.min(100,p||0));return '<div class="bar"><i style="width:'+p+'%;background:'+(p<60?'var(--v)':p<85?'var(--a)':'var(--r)')+'"></i></div>'}
document.addEventListener('keydown',e=>{var m={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[e.key];if(m){c('ensenar',{accion:'mover',dx:m[0],dy:m[1]});e.preventDefault()}
 if(e.key=='Enter')c('ensenar',{accion:'guardar'});if(e.key=='+')c('ensenar',{accion:'tam',dw:1,dh:1});if(e.key=='-')c('ensenar',{accion:'tam',dw:-1,dh:-1})});
function t(){fetch('/estado').then(r=>r.json()).then(e=>{var s=e.stats||{};
 document.getElementById('st').innerHTML='modelo <b>'+(e.modelo||'ninguno')+'</b> '+(e.motor||'')+'<br>'+e.fps+' fps · '+e.lat_ms+' ms<br>CPU '+Math.round(s.cpu_prom||0)+'%'+b(s.cpu_prom)+'GPU '+(s.gpu==null?'-':s.gpu)+'%'+b(s.gpu)+'RAM '+s.ram_mb+'/'+s.ram_total_mb+' MB'+b(100*s.ram_mb/(s.ram_total_mb||1))+
 'temp '+Object.entries(s.temp||{}).map(k=>k[0]+' '+Math.round(k[1])+'°').join(' ')+(s.potencia_mw?' · '+(s.potencia_mw/1000).toFixed(1)+' W':'')+'<br>calibración '+(e.calib.lista?e.calib.metodo+' '+e.calib.error_px+' px':'NO');
 document.getElementById('botones').innerHTML=(e.catalogo||[]).map(m=>'<button class="'+(m.id==e.modelo?'on':'off')+'" onclick="c(\'modelo\',{id:\''+m.id+'\'})">'+m.tecla+' '+m.id+'</button>').join('')+'<button onclick="c(\'modelo\',{id:\'0\'})">0 ninguno</button>';
 document.getElementById('dets').textContent=(e.dets||[]).map(d=>d.clase+' '+Math.round(d.conf*100)+'%').join('  ');
 if(!document.getElementById('log').textContent.startsWith('»'))document.getElementById('log').textContent=(e.log||[]).join('\n')}).catch(()=>{})}
setInterval(t,1000);t();
</script></body></html>)HTML";

static bool enviar_todo(int c, const void* d, size_t n) {
    const char* p = (const char*)d;
    while (n) {
        ssize_t k = send(c, p, n, MSG_NOSIGNAL);
        if (k <= 0) return false;
        p += k;
        n -= k;
    }
    return true;
}
static void responder(int c, const std::string& tipo, const std::string& cuerpo) {
    std::string h = "HTTP/1.1 200 OK\r\nContent-Type: " + tipo + "\r\nContent-Length: " + std::to_string(cuerpo.size()) +
                    "\r\nConnection: close\r\n\r\n";
    enviar_todo(c, h.data(), h.size());
    enviar_todo(c, cuerpo.data(), cuerpo.size());
}

ServidorWeb::ServidorWeb(Nucleo& n, int puerto) : n_(n), puerto_(puerto) {
    std::string ip = "0.0.0.0";
    int s = socket(AF_INET, SOCK_DGRAM, 0);   // IP de Tailscale si existe
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_port = htons(80);
    inet_pton(AF_INET, "100.100.100.100", &a.sin_addr);
    if (s >= 0 && connect(s, (sockaddr*)&a, sizeof a) == 0) {
        sockaddr_in l{};
        socklen_t ll = sizeof l;
        getsockname(s, (sockaddr*)&l, &ll);
        char b[64];
        inet_ntop(AF_INET, &l.sin_addr, b, sizeof b);
        ip = b;
    }
    if (s >= 0) close(s);
    url = "http://" + ip + ":" + std::to_string(puerto);
}
ServidorWeb::~ServidorWeb() { detener(); }

bool ServidorWeb::iniciar() {
    fd_ = socket(AF_INET, SOCK_STREAM, 0);
    int uno = 1;
    setsockopt(fd_, SOL_SOCKET, SO_REUSEADDR, &uno, sizeof uno);
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_port = htons(puerto_);
    a.sin_addr.s_addr = INADDR_ANY;
    if (bind(fd_, (sockaddr*)&a, sizeof a) != 0 || listen(fd_, 8) != 0) {
        close(fd_);
        fd_ = -1;
        return false;
    }
    vivo_ = true;
    hilo_ = std::thread([this]() {
        while (vivo_) {
            int c = accept(fd_, nullptr, nullptr);
            if (c < 0) {
                if (!vivo_) break;
                util::dormir(0.05);
                continue;
            }
            std::thread(&ServidorWeb::atender, this, c).detach();
        }
    });
    return true;
}

void ServidorWeb::detener() {
    if (!vivo_) return;
    vivo_ = false;
    shutdown(fd_, SHUT_RDWR);
    close(fd_);
    if (hilo_.joinable()) hilo_.join();
}

void ServidorWeb::atender(int c) {
    std::string req;
    char buf[8192];
    size_t fin = std::string::npos;
    while ((fin = req.find("\r\n\r\n")) == std::string::npos) {
        ssize_t k = recv(c, buf, sizeof buf, 0);
        if (k <= 0) break;
        req.append(buf, k);
    }
    if (fin == std::string::npos) {
        close(c);
        return;
    }
    std::string linea = req.substr(0, req.find("\r\n"));
    bool post = linea.compare(0, 4, "POST") == 0;
    std::string ruta = linea.substr(linea.find(' ') + 1);
    ruta = ruta.substr(0, ruta.find(' '));
    try {
        if (post) {
            size_t cl = 0, k = req.find("Content-Length:");
            if (k == std::string::npos) k = req.find("content-length:");
            if (k != std::string::npos) cl = std::stoul(req.substr(k + 15));
            std::string cuerpo = req.substr(fin + 4);
            while (cuerpo.size() < cl) {
                ssize_t r = recv(c, buf, sizeof buf, 0);
                if (r <= 0) break;
                cuerpo.append(buf, r);
            }
            json r = n_.atender(json::parse(cuerpo.empty() ? "{}" : cuerpo));
            responder(c, "application/json", r.dump(-1, ' ', false, json::error_handler_t::replace));
        } else if (ruta.compare(0, 7, "/estado") == 0) {
            responder(c, "application/json", n_.estado().dump(-1, ' ', false, json::error_handler_t::replace));
        } else if (ruta.compare(0, 12, "/stream.mjpg") == 0) {
            std::string h = "HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=f\r\nConnection: close\r\n\r\n";
            enviar_todo(c, h.data(), h.size());
            double fps = n_.cfg["web"].value("fps_stream", 5.0);
            while (vivo_) {
                n_.t_web = util::ahora();
                cv::Mat img;
                {
                    std::lock_guard<std::mutex> lk(n_.vista_mx);
                    img = n_.anotada;
                }
                if (!img.empty()) {
                    std::vector<uchar> j;
                    cv::imencode(".jpg", img, j, {cv::IMWRITE_JPEG_QUALITY, 70});
                    std::string p = "--f\r\nContent-Type: image/jpeg\r\nContent-Length: " + std::to_string(j.size()) + "\r\n\r\n";
                    if (!enviar_todo(c, p.data(), p.size()) || !enviar_todo(c, j.data(), j.size()) || !enviar_todo(c, "\r\n", 2))
                        break;
                }
                util::dormir(1.0 / fps);
            }
        } else {
            responder(c, "text/html; charset=utf-8", PAGINA);
        }
    } catch (...) {
    }
    close(c);
}
