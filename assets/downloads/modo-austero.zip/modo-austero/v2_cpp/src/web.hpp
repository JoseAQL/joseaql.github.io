// web.hpp - pagina web OPCIONAL (apagada por defecto): austero web on
// Servidor HTTP minimo con sockets POSIX: video MJPEG a pocos fps, estadisticas y botones.
#pragma once

#include <atomic>
#include <string>
#include <thread>

class Nucleo;

class ServidorWeb {
public:
    ServidorWeb(Nucleo& n, int puerto);
    ~ServidorWeb();
    bool iniciar();
    void detener();
    std::string url;

private:
    Nucleo& n_;
    int puerto_, fd_ = -1;
    std::atomic<bool> vivo_{false};
    std::thread hilo_;
    void atender(int c);
};
