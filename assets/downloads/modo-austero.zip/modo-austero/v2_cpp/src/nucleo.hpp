// nucleo.hpp - el proceso de fondo del Modo Austero (C++).
// camara -> filtros -> modelo activo (uno) -> salida al proyector (solo si cambia).
// Nada visual corre si no lo pides: sin ventana, sin web y sin vista. Se controla por /tmp/austero.sock.
#pragma once

#include <atomic>
#include <condition_variable>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "calibracion.hpp"
#include "camara.hpp"
#include "memoria.hpp"
#include "modelos.hpp"
#include "proyector.hpp"
#include "stats.hpp"

class ServidorWeb;

struct Ensenando {
    bool activo = false;
    std::string clase;
    Sombra sombra;
    bool propuesta = false;
};

class Nucleo {
public:
    Nucleo();
    ~Nucleo();
    void iniciar();
    void correr();
    void cerrar();
    json atender(const json& msg);   // desde cualquier hilo
    json estado();
    cv::Mat anotar(const cv::Mat& img);

    std::atomic<bool> vivo{true};
    json cfg;
    std::unique_ptr<Camara> cam;
    std::unique_ptr<Proyector> proy;
    std::unique_ptr<Filtros> filtros;
    std::unique_ptr<Calibracion> calib;
    Memoria memoria;
    Estadisticas stats;
    Contexto ctx;
    std::unique_ptr<Modelo> modelo;
    std::unique_ptr<Manos> manos;
    std::vector<Mano> manos_res;
    std::vector<Det> dets;
    std::mutex dets_mx;
    int ancho_proc, alto_proc;
    double escala;
    bool buscar = false, marcas_proy = true;
    Ensenando ens;
    std::string ocupado;
    double fps = 0, lat_ms = 0;
    std::deque<double> lat_hist;
    cv::Mat ultimo_proc;
    // vista de terminal y web: solo se dibuja si alguien la pidio hace < 3 s
    std::atomic<double> t_vista{0}, t_web{0};
    int vista_w = 80, vista_h = 40;
    std::mutex vista_mx;
    cv::Mat vista_buf, anotada;
    std::unique_ptr<ServidorWeb> web;

    // utilidades para bench
    cv::Mat procesar_cuadro(const cv::Mat& img);   // resize + filtros
    json cmd(const json& m);                        // ejecuta en el hilo principal (ya estando en el)

private:
    struct Pedido {
        json msg, resp;
        bool listo = false;
    };
    std::mutex cola_mx_;
    std::condition_variable cola_cv_;
    std::deque<std::shared_ptr<Pedido>> cola_;
    int srv_fd_ = -1;
    long proy_version_ = -1;
    double t_verif_ = 0;
    std::string fuente_ultimo_;
    void servidor();
    void procesar_cola();
    void lazo();
    void actualizar_mascara();
    void salida_proyector();
    void salidas_visuales(const cv::Mat& proc);
    void verificacion_periodica();
    cv::Rect sombra_en_cam();
    json auto_sombra();
};
