// camara.hpp - captura en un hilo (siempre el cuadro mas nuevo), controles V4L2, filtros y auto-ajuste.
//   tipo "usb"    -> V4L2 con MJPG decodificado por CPU (OpenCV)
//   tipo "usb_hw" -> V4L2 + decodificador JPEG por HARDWARE de la Jetson (GStreamer nvv4l2decoder)
//   tipo "csi"    -> camara CSI (nvarguscamerasrc)
//   tipo "sim"    -> mesa simulada + lo que proyecta el proyector (para probar sin Jetson)
#pragma once

#include <atomic>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>

#include "util.hpp"

// ------------------------------------------------------------ controles de la camara
// nombres: exposicion_auto, exposicion, ganancia, blancos_auto, blancos, brillo, contraste
struct Controles {
    virtual ~Controles() {}
    virtual bool tiene(const std::string& n) = 0;
    virtual bool rango(const std::string& n, int& mn, int& mx) = 0;
    virtual int leer(const std::string& n) = 0;
    virtual bool poner(const std::string& n, int v) = 0;
    virtual int valor_manual_exposicion() { return 1; }
};

struct ControlesV4L2 : Controles {
    int fd = -1;
    std::map<std::string, unsigned> ids;
    explicit ControlesV4L2(const std::string& dev);
    ~ControlesV4L2();
    bool tiene(const std::string& n) override;
    bool rango(const std::string& n, int& mn, int& mx) override;
    int leer(const std::string& n) override;
    bool poner(const std::string& n, int v) override;
};

struct ControlesSim : Controles {
    std::map<std::string, cv::Vec3i> v;  // min, max, valor
    ControlesSim();
    bool tiene(const std::string& n) override { return v.count(n) > 0; }
    bool rango(const std::string& n, int& mn, int& mx) override;
    int leer(const std::string& n) override { return v.count(n) ? v[n][2] : 0; }
    bool poner(const std::string& n, int x) override;
    double factor();
};

// ------------------------------------------------------------ mesa simulada
struct ObjetoSim {
    std::string tipo;
    double x, y, ang;
};

struct EscenaSim {
    int w, h;
    cv::Mat mesa;                    // CV_32FC3
    std::vector<cv::Point2f> esq_proy_en_cam;   // homografia "real" que el programa no conoce
    std::vector<ObjetoSim> objetos;
    cv::Mat marcador;                // ArUco impreso (opcional)
    cv::Point marcador_pos{60, 60};
    double mm_por_px = 0.75;
    cv::RNG rng;
    std::mutex mx;
    EscenaSim(int w, int h);
    void revolver(int n);
    void pieza(const std::string& tipo);
    static void dibujar_objeto(cv::Mat& img, const ObjetoSim& o);
    cv::Mat render(const cv::Mat& proy, double factor);
};

// ------------------------------------------------------------ camara
class Camara {
public:
    explicit Camara(const json& cfg);
    ~Camara();
    bool iniciar();
    void detener();
    // cuadro mas nuevo (copia barata: cv::Mat comparte memoria; el hilo siempre escribe uno nuevo)
    bool leer(cv::Mat& img, long& n);
    bool esperar_nuevo(long n_anterior, cv::Mat& img, long& n, double timeout = 1.0);
    cv::Mat promedio(int cuantos = 3, double espera = 0.25);

    int ancho, alto;
    std::string tipo;
    bool ok = false;
    std::string error;
    std::atomic<double> fps_cap{0};
    std::atomic<bool> vivo{false};
    std::unique_ptr<Controles> ctl;
    std::unique_ptr<EscenaSim> escena;
    std::function<cv::Mat()> imagen_proyector;   // solo para la simulada

private:
    json cfg_;
    cv::VideoCapture cap_;
    std::thread hilo_;
    std::mutex mx_;
    cv::Mat cuadro_;
    long n_ = 0;
    void abrir();
    bool leer_uno(cv::Mat& out);
    void bucle();
};

// ------------------------------------------------------------ filtros de software
class Filtros {
public:
    explicit Filtros(const json& p);
    bool poner(const std::string& k, double v);
    double get(const std::string& k) const;
    json params() const;
    void aplicar(cv::Mat& img) const;   // en el lugar; si todo esta neutro no gasta nada

private:
    double gamma_ = 1.0, clahe_ = 0.0, nitidez_ = 0.0;
    int suavizado_ = 0;
    cv::Mat lut_;
    void rehacer();
};

std::string autoajuste(Camara& cam, Filtros& f, double objetivo, double max_sat);
