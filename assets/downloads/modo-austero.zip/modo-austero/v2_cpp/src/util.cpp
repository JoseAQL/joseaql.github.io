#include "util.hpp"

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <iostream>
#include <sstream>
#include <thread>

namespace util {

static std::string g_base = ".";
static std::mutex g_log_mx;
static std::deque<std::string> g_log;

void fijar_base(const std::string& b) { g_base = b; }
const std::string& base() { return g_base; }
std::string ruta(const std::string& rel) { return g_base + "/" + rel; }

std::string socket_path() {
    const char* s = getenv("AUSTERO_SOCKET");
    return s ? s : "/tmp/austero.sock";
}

double ahora() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
double epoch() {
    using namespace std::chrono;
    return duration<double>(system_clock::now().time_since_epoch()).count();
}
static std::string strtime(const char* f) {
    time_t t = time(nullptr);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char b[64];
    strftime(b, sizeof b, f, &tmv);
    return b;
}
std::string hora() { return strtime("%H:%M:%S"); }
std::string fecha_archivo() { return strtime("%Y%m%d_%H%M%S"); }
void dormir(double s) {
    if (s > 0) std::this_thread::sleep_for(std::chrono::microseconds((long long)(s * 1e6)));
}

void log(const std::string& msg) {
    std::string l = hora() + " " + msg;
    {
        std::lock_guard<std::mutex> lk(g_log_mx);
        g_log.push_back(l);
        while (g_log.size() > 200) g_log.pop_front();
    }
    std::cout << l << std::endl;
}

std::vector<std::string> ultimos_log(size_t n) {
    std::lock_guard<std::mutex> lk(g_log_mx);
    std::vector<std::string> r;
    size_t i0 = g_log.size() > n ? g_log.size() - n : 0;
    for (size_t i = i0; i < g_log.size(); i++) r.push_back(g_log[i]);
    return r;
}

std::string fmt(const char* f, ...) {
    char b[2048];
    va_list ap;
    va_start(ap, f);
    vsnprintf(b, sizeof b, f, ap);
    va_end(ap);
    return b;
}

bool existe(const std::string& p) {
    struct stat s;
    return stat(p.c_str(), &s) == 0;
}
bool es_dir(const std::string& p) {
    struct stat s;
    return stat(p.c_str(), &s) == 0 && S_ISDIR(s.st_mode);
}
bool crear_dirs(const std::string& p) {
    if (p.empty() || es_dir(p)) return true;
    size_t k = p.find_last_of('/');
    if (k != std::string::npos && k > 0) crear_dirs(p.substr(0, k));
    return mkdir(p.c_str(), 0775) == 0 || es_dir(p);
}
std::vector<std::string> listar(const std::string& dir) {
    std::vector<std::string> r;
    DIR* d = opendir(dir.c_str());
    if (!d) return r;
    while (struct dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n != "." && n != "..") r.push_back(n);
    }
    closedir(d);
    std::sort(r.begin(), r.end());
    return r;
}
std::string leer_texto(const std::string& p) {
    std::ifstream f(p);
    if (!f) return "";
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}
bool escribir_texto(const std::string& p, const std::string& t) {
    crear_dirs(dir_de(p));
    std::string tmp = p + ".tmp";
    {
        std::ofstream f(tmp);
        if (!f) return false;
        f << t;
    }
    return rename(tmp.c_str(), p.c_str()) == 0;
}
std::string dir_de(const std::string& p) {
    size_t k = p.find_last_of('/');
    return k == std::string::npos ? "." : p.substr(0, k);
}
std::vector<std::string> leer_lineas(const std::string& p) {
    std::vector<std::string> r;
    std::ifstream f(p);
    std::string l;
    while (std::getline(f, l)) {
        while (!l.empty() && (l.back() == '\r' || l.back() == ' ')) l.pop_back();
        if (!l.empty()) r.push_back(l);
    }
    return r;
}

json cargar_json(const std::string& p, const json& defecto) {
    std::string t = leer_texto(p);
    if (t.empty()) return defecto;
    try {
        return json::parse(t);
    } catch (...) {
        log("JSON con error: " + p);
        return defecto;
    }
}
bool guardar_json(const std::string& p, const json& j) { return escribir_texto(p, j.dump(1)); }

void fusionar(json& a, const json& b) {
    if (!b.is_object()) return;
    for (auto it = b.begin(); it != b.end(); ++it) {
        if (it.value().is_object() && a.contains(it.key()) && a[it.key()].is_object())
            fusionar(a[it.key()], it.value());
        else
            a[it.key()] = it.value();
    }
}

json cargar_config() {
    json c = cargar_json(ruta("config.json"));
    fusionar(c, cargar_json(ruta("config_local.json")));   // tus cambios, no se pisan al actualizar
    const char* sim = getenv("AUSTERO_SIM");
    if (sim && std::string(sim) == "1") {
        c["camara"]["tipo"] = "sim";
        c["proyector"]["simulado"] = true;
    }
    return c;
}

bool en_jetson() { return existe("/etc/nv_tegra_release"); }

void preparar_display(const std::string& disp) {
    if (!getenv("DISPLAY")) setenv("DISPLAY", disp.c_str(), 1);
    if (!getenv("XAUTHORITY")) {
        const char* h = getenv("HOME");
        if (h) {
            std::string xa = std::string(h) + "/.Xauthority";
            if (existe(xa)) setenv("XAUTHORITY", xa.c_str(), 1);
        }
    }
}

std::string slug(const std::string& s) {
    std::string r;
    for (unsigned char ch : s) {
        if (std::isalnum(ch)) r += (char)std::tolower(ch);
        else if (ch >= 0x80) r += (char)ch;      // acentos y ñ se quedan
        else r += '_';
    }
    while (!r.empty() && r.back() == '_') r.pop_back();
    while (!r.empty() && r.front() == '_') r.erase(0, 1);
    return r.empty() ? "pieza" : r;
}

}  // namespace util
