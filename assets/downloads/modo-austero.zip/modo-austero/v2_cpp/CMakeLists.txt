# Modo Austero v2 (C++) - Jetson Nano (JetPack 4.6: gcc 7.5, OpenCV 4.1.1, TensorRT 8, CUDA 10.2)
# En una PC normal compila en "modo simulacion" (sin TensorRT ni jetson-inference).
cmake_minimum_required(VERSION 3.10)
project(modo_austero CXX)

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")
if(CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64")
  set(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS_RELEASE} -mcpu=cortex-a57")   # CPU de la Nano
endif()

option(USAR_TENSORRT "TensorRT para YOLO y orientacion" ON)
option(USAR_JETSON_INFERENCE "detectNet/poseNet/backgroundNet de jetson-inference" ON)

find_package(OpenCV REQUIRED COMPONENTS core imgproc imgcodecs videoio highgui calib3d features2d dnn)
find_package(Threads REQUIRED)

# --- ArUco: el OpenCV 4.1.1 de JetPack NO trae el modulo aruco (es de opencv_contrib).
#     Si tu OpenCV ya lo tiene se usa ese; si no, se compila la copia de terceros/aruco (BSD, OpenCV 4.1.1).
find_package(OpenCV QUIET COMPONENTS aruco)
if(OpenCV_aruco_FOUND OR TARGET opencv_aruco)
  message(STATUS "ArUco: el de tu OpenCV")
  set(ARUCO_LIB opencv_aruco)
else()
  message(STATUS "ArUco: copia incluida en terceros/aruco")
  file(GLOB ARUCO_SRC terceros/aruco/src/*.cpp)
  add_library(aruco_austero STATIC ${ARUCO_SRC})
  target_include_directories(aruco_austero PUBLIC terceros/aruco/include PRIVATE terceros/aruco/src ${OpenCV_INCLUDE_DIRS})
  target_link_libraries(aruco_austero PUBLIC opencv_core opencv_imgproc opencv_calib3d)
  set_property(TARGET aruco_austero PROPERTY POSITION_INDEPENDENT_CODE ON)
  set(ARUCO_LIB aruco_austero)
endif()

set(EXTRA_DEFS "")
set(EXTRA_LIBS "")
set(EXTRA_INC "")

# --- CUDA + TensorRT (JetPack)
if(USAR_TENSORRT)
  find_path(TRT_INC NvInfer.h PATHS /usr/include/aarch64-linux-gnu /usr/include /usr/local/TensorRT/include)
  find_library(TRT_LIB nvinfer PATHS /usr/lib/aarch64-linux-gnu /usr/lib /usr/local/TensorRT/lib)
  find_path(CUDA_INC cuda_runtime_api.h PATHS /usr/local/cuda/include)
  find_library(CUDART_LIB cudart PATHS /usr/local/cuda/lib64)
  if(TRT_INC AND TRT_LIB AND CUDA_INC AND CUDART_LIB)
    message(STATUS "TensorRT: si (${TRT_LIB})")
    list(APPEND EXTRA_DEFS CON_TENSORRT)
    list(APPEND EXTRA_INC ${TRT_INC} ${CUDA_INC})
    list(APPEND EXTRA_LIBS ${TRT_LIB} ${CUDART_LIB})
  else()
    message(STATUS "TensorRT: no (YOLO usara OpenCV DNN en CPU)")
  endif()
endif()

# --- jetson-inference (detectNet, poseNet, backgroundNet)
if(USAR_JETSON_INFERENCE)
  find_path(JI_INC jetson-inference/detectNet.h PATHS /usr/local/include /usr/include)
  find_library(JI_LIB jetson-inference PATHS /usr/local/lib /usr/lib)
  find_library(JU_LIB jetson-utils PATHS /usr/local/lib /usr/lib)
  if(JI_INC AND JI_LIB AND JU_LIB AND CUDA_INC)
    message(STATUS "jetson-inference: si (${JI_LIB})")
    list(APPEND EXTRA_DEFS CON_JETSON_INFERENCE)
    list(APPEND EXTRA_INC ${JI_INC} ${CUDA_INC})
    list(APPEND EXTRA_LIBS ${JI_LIB} ${JU_LIB} ${CUDART_LIB})
  else()
    message(STATUS "jetson-inference: no (ssd, manos y fondo_ia no estaran)")
  endif()
endif()

include_directories(src terceros/json ${OpenCV_INCLUDE_DIRS} ${EXTRA_INC})

add_executable(austero-nucleo src/nucleo.cpp src/util.cpp src/camara.cpp src/proyector.cpp src/calibracion.cpp
               src/stats.cpp src/memoria.cpp src/modelos.cpp src/bench.cpp src/web.cpp)
target_compile_definitions(austero-nucleo PRIVATE ${EXTRA_DEFS})
target_link_libraries(austero-nucleo ${OpenCV_LIBS} ${ARUCO_LIB} ${EXTRA_LIBS} Threads::Threads)

# cliente: muy chico, sin OpenCV
add_executable(austero-cli src/cliente.cpp src/util.cpp)
target_link_libraries(austero-cli Threads::Threads)
