# Modo Austero (Jetson Nano) — en construcción

Modo nuevo y separado del Asesor y de la Estación: corre por terminal (SSH/Tailscale), gasta lo mínimo
y se prende y apaga con un comando.

| Versión | Carpeta | Estado |
|---|---|---|
| v1 | [`v1_python/`](v1_python/) | Python. Probada en simulación (cámara y proyector simulados). |
| v2 | [`v2_cpp/`](v2_cpp/) | C++ con las mismas funciones que v1 (para comparar). Escrita, sin compilar. |
| **v3** | [`v3_optimo/`](v3_optimo/) | **C++ optimizado desde cero (la buena).** Un hilo, el modelo solo corre si hay movimiento, reposo, complementos .so que se cargan al activarlos, salida por framebuffer, web y tablero aparte. Compilada y probada en simulación. Ver [LEEME](v3_optimo/LEEME.md). |

Funciones: calibración proyector–cámara automática (ArUco por defecto, también puntos, esquinas y Gray code),
verificación en lazo cerrado, escala en mm con ArUco impreso, auto-ajuste de cámara, filtros con kernel
ajustable, banco de modelos (uno a la vez), modo "enseñar y buscar", benchmark tipo overclock, vista de
cámara en la terminal y página web opcional.

Pendiente: primera prueba de v3 en la Jetson real.
