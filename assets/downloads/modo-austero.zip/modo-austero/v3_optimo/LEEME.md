# Modo Austero v3 (optimizado) — Jetson Nano

Versión hecha desde cero para gastar lo mínimo. Todo se maneja desde la terminal (local o por SSH/Tailscale).
Lo que no prendes **no existe**: ni hilos, ni memoria, ni librerías cargadas.

## Cómo gasta poco

| Qué | Cómo |
|---|---|
| Un solo hilo | Duerme en `select()` hasta que llega un cuadro o un comando. |
| Cámara | V4L2 directo en YUYV 640×480 a 15 fps: el gris sale gratis (canal Y), sin descomprimir JPEG. |
| Modelo | **Solo corre si algo se mueve** en la mesa (comparación de grises de 160×120), con tope de inferencias por segundo. Quieto = GPU en 0 %. |
| Reposo | Tras `reposo.min` minutos sin movimiento suelta el modelo y la memoria de la GPU; regresa solo al ver movimiento. |
| Complementos | TensorRT, CUDA, jetson-inference y la ventana X son `.so` que se cargan **solo al activarlos**. Sin modelo de GPU no se crea el contexto CUDA (150–300 MB). |
| Proyector | Framebuffer directo (`/dev/fb0`), sin escritorio. Lienzo de 1280×720 y solo se redibuja si algo cambió. |
| Web y tablero | Programas aparte: si no los abres, no corren. La imagen solo se genera cuando alguien la pide. |
| Estadísticas | Se leen de `/proc` y `/sys` solo cuando las pides (sin `tegrastats` corriendo). |
| Sistema | `herramientas/optimizar_jetson.sh` quita el escritorio y servicios que no usas (se puede deshacer). |

En simulación el núcleo arranca con unos **50 MB de RAM**.

## Instalar (mañana en la Jetson)

1. Copia la carpeta `v3_optimo` a la Jetson (o `git clone https://github.com/joseantonioquirozluna/Pruebas-` y entra a `modo-austero/v3_optimo`).
2. Copia también `modelos_yolo_mit4.zip` dentro de `v3_optimo/` y descomprímelo:
   ```
   cd v3_optimo
   unzip modelos_yolo_mit4.zip          # crea modelos/yolo_mit4/
   ```
3. Instala y compila (convierte los modelos a TensorRT; cada uno tarda varios minutos):
   ```
   ./instalar.sh
   ```
   Para los modelos de jetson-inference (SSD, manos, fondo_ia): `./instalar.sh --jetson-inference` (tarda ~1 hora).
4. Prueba:
   ```
   austero start        # arranca (calibra solo con ArUco si hay proyector)
   austero ver          # tablero (q sale, Q apaga)
   austero stop
   ```
5. Cuando todo funcione, para ahorrar al máximo:
   ```
   sudo ./herramientas/optimizar_jetson.sh      # quita el escritorio y servicios; luego: sudo reboot
   sudo ./herramientas/optimizar_jetson.sh --deshacer   # para regresar todo
   ```

## Uso

| Comando | Qué hace |
|---|---|
| `austero start [--sim]` / `stop` / `restart` | Prender / apagar (con `--sim`: cámara y proyector simulados). |
| `austero ver` | Tablero: CPU por núcleo y MHz, GPU, RAM, temperaturas, watts, detecciones y vista de la cámara (tecla `i`). |
| `austero status` / `log` | Estado rápido / últimos mensajes. |
| `austero modelo 4` | Cargar un modelo (`0` = ninguno, libera la GPU). |
| `austero param umbral 0.4` | Ajustar el modelo en vivo (`umbral`, `nms`, `entrada` = tamaño YOLO). |
| `austero conf modelo.fps_max 5` | Cambiar cualquier ajuste de `austero.conf` en vivo. |
| `austero calibrar [aruco\|puntos\|esquinas\|graycode]` | Calibrar proyector–cámara (ArUco por defecto). |
| `austero verificar` / `mm` | Revisar la calibración / medir escala con el ArUco impreso (`perfiles/marcador_mm.png`). |
| `austero fondo` | Foto de la mesa vacía (lo usan resta de fondo, orientación y enseñar). |
| `austero ensenar "tijera mayo"` | Modo Terminator: mueves la sombra con las flechas (en `austero ver`), Enter guarda; `x` = la cámara propone dónde está. |
| `austero buscar on` | Buscar lo enseñado mientras corre otro modelo. |
| `austero manos on` | Manos (poseNet), solo si lo pides. |
| `austero bench [teclas] [--seg 15]` | Comparar modelos con los mismos cuadros: FPS, ms, CPU, GPU, +RAM, temperatura, watts y aciertos contra tus fotos enseñadas. Incluye la línea "(sin modelo)" para comparar antes contra después. |
| `austero perfil max\|normal\|5w` | Energía de la Jetson (nvpmodel / jetson_clocks). |
| `austero web on\|off` | Página web opcional (proceso aparte). |

## Elegir qué arranca al prender la Jetson

| Comando | Qué hace |
|---|---|
| `austero al-prender austero` | Al prender arranca el Modo Austero (el proyecto anterior ya no arranca solo) |
| `austero al-prender anterior` | Regresa a como estaba: arranca el menú del proyector anterior |
| `austero al-prender nada` | No arranca ninguno |
| `austero al-prender` | Muestra cuál está elegido |
| `austero cambiar` | Ahora mismo: apaga el proyecto anterior y prende el Modo Austero |
| `austero anterior` | Ahora mismo: apaga el Modo Austero y prende el proyecto anterior |

## Laboratorio (filtros, kernels y cámara en vivo)

Para ajustar fino y ver cómo responde. Solo gasta mientras lo estás viendo.

- **Terminal:** en `austero ver` presiona `L`. Flechas ↑↓ eligen el ajuste, ←→ lo cambian, Enter escribe un valor exacto,
  `1`-`5` cambian la vista (1 cámara, 2 lo que ve la red, 3 máscara, 4 bordes y esquinas, 5 las 4 juntas).
- **Web:** `austero web on` y abre `http://IP:8091/lab`: las 4 vistas y deslizadores para todo.
- **Comandos:** `austero filtro` (lista), `austero filtro morf_k 11`, `austero filtro gamma +`, `austero filtro reset`,
  `austero cam` (lista), `austero cam exposicion 300`, `austero cam linea_electrica 2`.

| Grupo | Ajustes |
|---|---|
| Cámara (V4L2) | exposición automática/manual, exposición, prioridad, ganancia, línea eléctrica 50/60 Hz, balance de blancos, brillo, contraste, saturación, nitidez, gamma, contraluz, enfoque (los que tenga tu cámara) |
| Lo que ve la red | gamma, CLAHE, suavizado (gauss, mediana, bilateral) con kernel de 3 a 21, nitidez, kernel de convolución (enfocar, relieve, laplaciano, sobel X/Y o el tuyo en `perfiles/kernel.txt`) y cuánto se mezcla |
| Máscara | umbral contra el fondo, área mínima, morfología (abrir, cerrar, dilatar, erosionar, gradiente) con kernel rectángulo/elipse/cruz y limpieza de puntitos |
| Bordes | Canny bajo/alto, esquinas (cantidad y calidad) |

Lo que ajustas aquí lo usan de verdad la resta de fondo, los ejemplos enseñados y los modelos. Se guarda en
`perfiles/filtros.conf` y `perfiles/camara.conf`, y se carga solo al arrancar.

Ejemplo de `perfiles/kernel.txt` (kernel 6):
```
-1 -1 -1
-1  9 -1
-1 -1 -1
```

## Instrumental Quest: escenarios tipo videojuego

Rutinas proyectadas sobre la mesa como niveles de un juego: **escenario** (nivel) → **tareas** 1, 2, 3… → **FINAL** (revisa todo).
Cada pieza va sobre su **silueta**; si se pone otra pieza, sale en rojo ("Esa no es la tijera: es pinza") y cuenta como error.
Al terminar: tiempo, errores, faltas y de 1 a 3 estrellas; el siguiente escenario se desbloquea.

**Crear un escenario grabándolo (lo más fácil):**
```
austero fondo                                   # mesa vacía
austero escenario grabar "Charola cirugia menor"
#  pon la 1a pieza en su lugar y quita la mano  -> "tarea 1 grabada: tijera en L1"
#  pon la 2a pieza ...                          -> "tarea 2 grabada: pinza en L2"
austero escenario listo                          # agrega la tarea FINAL
```
**Zonas prohibidas** (campo estéril, charola ya revisada): si una mano entra o cruza la raya, parpadea en rojo,
sale "RETIRA LA MANO", la tarea no avanza y cuenta como falta.
```
austero escenario prohibida 1 "campo esteril" 900 420 300 200   # x y ancho alto (píxeles del proyector)
austero escenario linea 1 borde 80 640 1200 640                 # raya que no se cruza
```
**Jugar:** `austero escenario jugar 1` (o tecla `j` en `austero ver`). Teclas: `k` ok, `n` siguiente, `p` pausa, `J` parar,
`g` grabar, `G` listo. Para ver lo que se proyecta: `austero foto 6` o la vista "6 lo que se proyecta" en `/lab`.

Los escenarios son archivos de texto en `escenarios/*.esc` y se pueden editar a mano:
```
nombre = Charola cirugia menor
zona L1 = 218 173 277 116
prohibida campo esteril = 900 420 300 200
linea borde = 80 640 1200 640
[tarea]
nombre = Coloca tijera en L1
instruccion = Coloca la tijera sobre su silueta (L1)
pasa = pieza tijera L1          # también: vacio L2 | conteo pinza 2 | espera 5 | confirmar
```

## Página web de Instrumental Quest (`/quest`)

`austero web on` y abre `http://IP:8091/quest` (PC o celular). Es un solo archivo, `web/quest.html` (se edita sin recompilar,
sin librerías ni internet). Solo trabaja mientras la pestaña está visible.

| Pantalla | Para qué |
|---|---|
| **Mapa** | Los escenarios como niveles: completado (estrellas, récord), actual y bloqueado. Jugar, Editar, Duplicar, Borrar, Nuevo. |
| **Editor** | Camino de tareas (se reordena arrastrando). Mesa con la foto real vista desde el proyector: zonas, zonas prohibidas, líneas y siluetas se arrastran y cambian de tamaño. Torres que se arrastran a la mesa (Zona, Verificador, Contador, Guía, Temporizador, Muro, Línea). Panel de la tarea con sus condiciones. Deshacer/rehacer (Ctrl+Z), Guardar (Ctrl+S), **Grabar haciendo** y **Probar desde esta tarea**. |
| **Jugando** | Lo que se proyecta, en vivo; tarea, tiempo, errores, faltas y alertas ("MANO EN ZONA PROHIBIDA"); OK, Siguiente, Pausa, Parar. |
| **Gemelo** | Lo real contra lo esperado: cada lugar correcto / pieza equivocada / falta. |
| **Resultados** | Récords por escenario y las últimas partidas (`escenarios/historial.txt`). |

Colores iguales a los del proyector: cian = actual, verde = hecho, rojo = error o prohibido, ámbar = instrucción.

## Jetson Nano y Raspberry Pi 4B

`./instalar.sh` detecta la plataforma. La página y los escenarios son idénticos en las dos.

| | Jetson Nano | Raspberry Pi 4B (OS 64 bits) |
|---|---|---|
| Piezas | YOLO por TensorRT + formas | formas (modelo 1), todo en CPU |
| Manos | poseNet (`austero manos on`) | MediaPipe en un programa aparte (`austero manos-mp on`), o por piel/orilla |
| Proyector | framebuffer / ventana | framebuffer del HDMI (prende el proyector antes que la Pi) |
| Energía | `austero perfil max\|normal\|5w` | no aplica |

**Estado de la Raspberry:** el código compila sin GPU y el puente de manos se probó con una mano de prueba
(`herramientas/manos_mediapipe.py --probar`), pero todavía **no se ha corrido en una Raspberry real** ni con MediaPipe de verdad.

## Reconocer por forma (sin red neuronal)

Con la foto de la mesa vacía (`austero fondo`), cada pieza se mide como con una regla: largo/ancho, de qué lado está la
punta, las **orejas** (aros de la tijera), si es más ancha al centro (pinza) o pareja (bisturí), si tiene dos brazos y si
es piel (mano). Lo que es grande y entra por la orilla de la imagen es un brazo.
- Con el modelo 1 (fondo) cada pieza sale con su nombre: Tijera, Bisturi, Pinza, mano.
- Con YOLO (4, 9…) se **fusionan**: la forma confirma o corrige a la red, y lo que la red ve donde no hay nada distinto
  al fondo (orillas del paño, marcos del proyector) se descarta.
- Ajustes en el laboratorio: `formas`, `formas_peso`, `formas_exigir`, `formas_umbral`, `oreja_min`, `mano_piel`.
- Simulación para medirlo sin cámara: `build/austero-prueba-formas --n 300` (mesa verde con pliegues, metal que refleja
  el paño, tijeras con aros, pinzas abiertas, manos, cambios de luz). Hoy: tijera 99 %, pinza 92 %, bisturí 83 %,
  mano 100 % en simulación. En la mesa real hay que comprobarlo; si algo falla, manda una `austero foto`.

## Modelos

| Tecla | id | Dónde corre | Licencia |
|---|---|---|---|
| 1 | fondo | núcleo, CPU | propio |
| 2 | ssd_general | jetson-inference | MIT |
| 3 | ssd_propio | jetson-inference (tu ONNX re-entrenado) | tuyo |
| 4 | yolo_mit4 | TensorRT (YOLO11-L, 4 instrumentos) | MIT |
| 5 | yolo_doccheck12 | TensorRT (YOLOv5-L, 12 instrumentos) | CC BY-NC 4.0 |
| 6 | orientacion | TensorRT (ángulo 0–357°) | CC BY-NC 4.0 |
| 7 | ejemplos | núcleo, CPU (lo que enseñaste) | propio |
| 8 | fondo_ia | jetson-inference (backgroundNet) | MIT |
| 9 | yolo_alumno | TensorRT (tu YOLO nano) | tuyo |

- `modelos_yolo_mit4.zip` trae el YOLO11-L del MIT ya convertido a ONNX opset 12 (320 y 416), lo que acepta el TensorRT de JetPack 4.6.
- Los de DocCheck se convierten con `colab/convertir_modelos.py` en Google Colab (deja `modelos_austero.zip`).
- El "alumno" (YOLO nano entrenado con lo que enseñaste) se entrena con `colab/entrenar_alumno.py`. Es el que más rinde en la Nano.

## Archivos

```
austero               comando principal
austero.conf          ajustes de fabrica (lo que cambias en vivo va a perfiles/ajustes.conf)
instalar.sh           instalador desde cero
herramientas/optimizar_jetson.sh
colab/                conversion de modelos y entrenamiento del alumno
src/                  codigo C++ (nucleo, camara, salida, calibracion, memoria, modelos, stats, cliente, web)
src/complementos/     trt, ji, cvdnn, ventana (.so que se cargan al activarlos)
src/aruco/            modulo ArUco de OpenCV 4.1.1 (el OpenCV de JetPack no lo trae)
```

## Estado

- **Probado en simulación** (PC): compila sin errores; funcionan la calibración (los 4 métodos, error de 0.5 a 1.5 px), la verificación, la escala en mm, enseñar/buscar, la detección de movimiento, el reposo, el benchmark, el tablero y la web.
- Los complementos de **TensorRT y jetson-inference** se revisaron contra sus encabezados oficiales (TensorRT 8.2, jetson-inference actual), pero **todavía no se han corrido en una Jetson**: la primera prueba real será la tuya.
- En una PC, el YOLO11 no corre con OpenCV DNN (le faltan operaciones); en la Jetson va por TensorRT.
