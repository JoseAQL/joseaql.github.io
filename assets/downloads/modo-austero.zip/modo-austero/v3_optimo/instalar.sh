#!/bin/bash
# instalar.sh - Modo Austero v3 desde cero. Detecta solo la plataforma:
#   Jetson Nano (JetPack 4.6)      -> OpenCV de NVIDIA, TensorRT, perfiles de energia
#   Raspberry Pi 4B (OS 64 bits)   -> OpenCV de apt (con ArUco), sin GPU: formas + escenarios + web; manos con MediaPipe
#   PC                             -> para simular (./austero start --sim)
#   ./instalar.sh                 dependencias + compilar (+ convertir modelos a TensorRT en la Jetson)
#   ./instalar.sh --solo-compilar
#   ./instalar.sh --jetson-inference   ademas compila jetson-inference (para ssd, manos y fondo_ia; ~1 hora)
set -e
DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
cd "$DIR"
paso() { echo; echo "==== $*"; }

PLAT=pc
[ -f /etc/nv_tegra_release ] && PLAT=jetson
grep -qi "raspberry pi" /proc/device-tree/model 2>/dev/null && PLAT=raspberry
echo "Plataforma: $PLAT"
[ "$PLAT" = pc ] && echo "AVISO: ni Jetson ni Raspberry. Compilo igual (modo simulacion: ./austero start --sim)."

if [ "$1" != "--solo-compilar" ]; then
  paso "1/5 Dependencias (sudo)"
  sudo apt-get update
  sudo apt-get install -y build-essential cmake pkg-config v4l-utils
  # OpenCV de JetPack (4.1.1) con sus encabezados; en una PC: libopencv-dev
  if [ "$PLAT" = jetson ]; then sudo apt-get install -y nvidia-opencv-dev || sudo apt-get install -y libopencv-dev
  else sudo apt-get install -y libopencv-dev; sudo apt-get install -y libopencv-contrib-dev || true; fi   # contrib trae ArUco
  if [ "$PLAT" = raspberry ]; then
    # manos con MediaPipe (opcional; si no se instala, las manos se ven por color de piel y por la orilla)
    python3 -c "import mediapipe" 2>/dev/null || pip3 install --user --break-system-packages mediapipe 2>/dev/null || \
      pip3 install --user mediapipe 2>/dev/null || echo "AVISO: no pude instalar mediapipe (las manos iran por forma/piel)"
  fi
  paso "2/5 Permisos: camara, framebuffer y consola (grupo video)"
  sudo usermod -aG video "$USER" || true
fi

if [ "$1" = "--jetson-inference" ] || [ "$2" = "--jetson-inference" ]; then
  paso "Extra: jetson-inference (detectNet, poseNet, backgroundNet)"
  if [ ! -f /usr/local/include/jetson-inference/detectNet.h ]; then
    sudo apt-get install -y git libpython3-dev python3-numpy
    cd ~ && [ -d jetson-inference ] || git clone --recursive --depth=1 https://github.com/dusty-nv/jetson-inference
    mkdir -p ~/jetson-inference/build && cd ~/jetson-inference/build
    cmake ../ && make -j"$(nproc)" && sudo make install && sudo ldconfig
    cd "$DIR"
  fi
  echo "Modelos de jetson-inference: corre  ~/jetson-inference/tools/download-models.sh"
  echo "y marca SSD-Mobilenet-v2 y Hand Pose (resnet18-hand)."
fi

paso "3/5 Compilar"
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j"$(nproc)"
cd "$DIR"
ls -la build/austero-* build/lib*.so 2>/dev/null

paso "4/5 Modelos a TensorRT (FP16)"
TRTEXEC=/usr/src/tensorrt/bin/trtexec
if [ "$PLAT" != jetson ]; then
  echo "sin GPU de NVIDIA: se usa el reconocimiento por forma (modelo 1). No hace falta convertir nada."
elif [ -x "$TRTEXEC" ]; then
  for onnx in modelos/*/modelo*.onnx; do
    [ -f "$onnx" ] || continue
    eng="${onnx%.onnx}.engine"
    if [ -f "$eng" ]; then echo "ya existe $eng"; continue; fi
    echo "convirtiendo $onnx (tarda varios minutos por modelo; la Jetson se calienta, es normal)..."
    "$TRTEXEC" --onnx="$onnx" --saveEngine="$eng" --fp16 --workspace=256 > "${eng}.log" 2>&1 \
      && echo "  listo: $eng" || echo "  fallo (ver ${eng}.log); el nucleo intentara construirlo al usarlo"
  done
else
  echo "sin trtexec: los .engine se construyen solos la primera vez que uses cada modelo"
fi
[ "$PLAT" = jetson ] && [ -z "$(ls modelos/*/modelo*.onnx 2>/dev/null)" ] && echo "AVISO: no hay modelos en modelos/. Copia modelos_yolo_mit4.zip y descomprimelo aqui (ver LEEME.md)."

paso "5/5 Comando 'austero'"
chmod +x austero herramientas/*.sh herramientas/*.py 2>/dev/null || true
mkdir -p ~/.local/bin && ln -sf "$DIR/austero" ~/.local/bin/austero
grep -q '.local/bin' ~/.bashrc || echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
echo
echo "LISTO. Abre otra terminal (o: source ~/.bashrc) y prueba:"
echo "   austero start        # arranca"
echo "   austero ver          # tablero"
echo "   austero stop         # apaga"
echo "   austero web on       # pagina: http://IP:8091/quest  (Instrumental Quest)"
[ "$PLAT" = jetson ] && echo "Para ahorrar al maximo (quitar escritorio y servicios):  sudo ./herramientas/optimizar_jetson.sh"
[ "$PLAT" = raspberry ] && echo "Raspberry: prende el proyector ANTES que la Pi. Manos con MediaPipe:  austero manos-mp on"
echo "Si es la primera vez que te agregue al grupo video, cierra sesion y vuelve a entrar."
