#include "salida.hpp"

#include <fcntl.h>
#include <linux/fb.h>
#include <linux/kd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

#include <cstdlib>
#include <cstring>

#include <dlfcn.h>

#include <opencv2/imgproc.hpp>

using aus::fmt;
using aus::log;

Salida::~Salida() { cerrar(); }

bool Salida::abrir(const aus::Conf& c) {
    w = c.i("salida.ancho", 1280);
    h = c.i("salida.alto", 720);
    tipo = c.s("salida.tipo", "auto");
    if (tipo == "auto") {
        // solo cuenta el escritorio de la propia Jetson (:0); el DISPLAY que pone MobaXterm por SSH
        // (localhost:10.0) mandaria la imagen a la PC en lugar del proyector
        bool hay_x = aus::existe("/tmp/.X11-unix/X0");
        tipo = hay_x ? "x" : "fb";
    }
    ultimo_ = cv::Mat::zeros(h, w, CV_8UC3);
    if (tipo == "sim" || tipo == "ninguna") {
        abierta_ = true;
        return true;
    }
    if (tipo == "fb") {
        abierta_ = abrir_fb(c.s("salida.fb", "/dev/fb0"));
        if (abierta_) return true;
        log("salida fb no disponible; pruebo con ventana X");
        tipo = "x";
    }
    abierta_ = abrir_ventana(c);
    return abierta_;
}

bool Salida::abrir_ventana(const aus::Conf& c) {
    setenv("DISPLAY", c.s("salida.display", ":0").c_str(), 1);   // siempre el HDMI de la Jetson
    const char* d = getenv("AUSTERO_LIB");
    std::string ruta = std::string(d ? d : aus::ruta("build")) + "/libaustero_ventana.so";
    so_ = dlopen(ruta.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!so_) {
        log(std::string("salida: sin ventana (") + dlerror() + ")");
        return false;
    }
    auto abrir = (bool (*)(int, int, const char*))dlsym(so_, "austero_ventana_abrir");
    v_mostrar_ = (void (*)(const cv::Mat*))dlsym(so_, "austero_ventana_mostrar");
    v_eventos_ = (void (*)())dlsym(so_, "austero_ventana_eventos");
    v_cerrar_ = (void (*)())dlsym(so_, "austero_ventana_cerrar");
    if (!abrir || !v_mostrar_ || !abrir(c.i("salida.x", 0), c.i("salida.y", 0), c.s("salida.display", ":0").c_str())) {
        dlclose(so_);
        so_ = nullptr;
        return false;
    }
    log(fmt("salida ventana X (lienzo %dx%d)", w, h));
    return true;
}

bool Salida::abrir_fb(const std::string& dev) {
    fb_ = ::open(dev.c_str(), O_RDWR);
    if (fb_ < 0) return false;
    fb_var_screeninfo v{};
    fb_fix_screeninfo f{};
    if (ioctl(fb_, FBIOGET_VSCREENINFO, &v) < 0 || ioctl(fb_, FBIOGET_FSCREENINFO, &f) < 0) {
        ::close(fb_);
        fb_ = -1;
        return false;
    }
    fw_ = v.xres;
    fh_ = v.yres;
    bpp_ = v.bits_per_pixel;
    linea_ = f.line_length;
    roff_ = v.red.offset;
    goff_ = v.green.offset;
    boff_ = v.blue.offset;
    largo_ = f.smem_len;
    mem_ = (unsigned char*)mmap(nullptr, largo_, PROT_READ | PROT_WRITE, MAP_SHARED, fb_, 0);
    if (mem_ == MAP_FAILED || (bpp_ != 32 && bpp_ != 16)) {
        if (mem_ != MAP_FAILED) munmap(mem_, largo_);
        mem_ = nullptr;
        ::close(fb_);
        fb_ = -1;
        return false;
    }
    // que la consola de texto no pinte encima ni muestre el cursor
    tty_ = ::open("/dev/tty1", O_RDWR);
    if (tty_ >= 0) {
        ioctl(tty_, KDSETMODE, KD_GRAPHICS);
        (void)!write(tty_, "\033[?25l", 6);
    }
    log(fmt("salida framebuffer %dx%d %d bits (lienzo %dx%d)", fw_, fh_, bpp_, w, h));
    return true;
}

void Salida::escribir_fb(const cv::Mat& bgr) {
    cv::Mat img = bgr;
    if (img.cols != fw_ || img.rows != fh_) cv::resize(img, img, cv::Size(fw_, fh_), 0, 0, cv::INTER_NEAREST);
    if (bpp_ == 32) {
        cv::Mat bgra;
        if (boff_ == 0 && goff_ == 8 && roff_ == 16) cv::cvtColor(img, bgra, cv::COLOR_BGR2BGRA);
        else cv::cvtColor(img, bgra, cv::COLOR_BGR2RGBA);
        for (int y = 0; y < fh_; y++) memcpy(mem_ + (size_t)y * linea_, bgra.ptr(y), (size_t)fw_ * 4);
    } else {
        cv::Mat b565;
        cv::cvtColor(img, b565, cv::COLOR_BGR2BGR565);
        for (int y = 0; y < fh_; y++) memcpy(mem_ + (size_t)y * linea_, b565.ptr(y), (size_t)fw_ * 2);
    }
}

void Salida::mostrar(const cv::Mat& l) {
    cv::Mat img = l;
    if (img.channels() == 1) cv::cvtColor(img, img, cv::COLOR_GRAY2BGR);
    if (img.cols != w || img.rows != h) cv::resize(img, img, cv::Size(w, h), 0, 0, cv::INTER_NEAREST);
    ultimo_ = img;
    if (!abierta_) return;
    if (tipo == "fb" && mem_) escribir_fb(img);
    else if (tipo == "x" && so_) v_mostrar_(&img);
}

void Salida::eventos() {
    if (tipo != "x" || !abierta_) return;
    double t = aus::ahora();
    if (t - t_ev_ < 0.5) return;   // la ventana casi no cambia: atenderla 2 veces por segundo basta
    t_ev_ = t;
    if (so_ && v_eventos_) v_eventos_();
}

void Salida::cerrar() {
    if (mem_) {
        memset(mem_, 0, largo_);
        munmap(mem_, largo_);
        mem_ = nullptr;
    }
    if (fb_ >= 0) ::close(fb_);
    fb_ = -1;
    if (tty_ >= 0) {
        ioctl(tty_, KDSETMODE, KD_TEXT);
        (void)!write(tty_, "\033[?25h", 6);
        ::close(tty_);
        tty_ = -1;
    }
    if (so_) {
        if (v_cerrar_) v_cerrar_();
        dlclose(so_);
        so_ = nullptr;
    }
    abierta_ = false;
}
