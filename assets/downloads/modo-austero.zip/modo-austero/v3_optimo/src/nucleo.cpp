// nucleo.cpp - austero-nucleo: el proceso de fondo del Modo Austero v3 (optimizado).
//
// UN solo hilo. Duerme en select() hasta que llega un cuadro de la camara o un comando.
//   cuadro -> movimiento (gris chico, casi gratis) -> SOLO si algo se mueve: modelo -> proyector (si cambio)
// Lo pesado (TensorRT, CUDA, jetson-inference, ventana X) son complementos .so que se cargan al activarlos.
// Despues de reposo.min minutos sin movimiento, suelta el modelo y la GPU; regresa al ver movimiento.
// Control: socket /tmp/austero.sock, una linea de texto por conexion ("modelo 4", "calibrar aruco"...).
#include <fcntl.h>
#include <malloc.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

#include <algorithm>
#include <cmath>
#include <deque>
#include <numeric>
#include <sstream>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "base.hpp"
#include "calibracion.hpp"
#include "camara.hpp"
#include "escenarios.hpp"
#include "filtros.hpp"
#include "formas.hpp"
#include "memoria.hpp"
#include "modelos.hpp"
#include "salida.hpp"
#include "stats.hpp"

using aus::fmt;
using aus::log;

static volatile sig_atomic_t g_vivo = 1;
static void senal(int) { g_vivo = 0; }

static const cv::Scalar COLORES[] = {{0, 220, 255}, {80, 255, 80}, {255, 160, 60}, {255, 80, 200}, {60, 120, 255}, {200, 255, 255}};
static cv::Scalar color_de(const std::string& s) {
    unsigned h = 0;
    for (unsigned char c : s) h += c;
    return COLORES[h % 6];
}

struct Resp {
    bool ok = true;
    std::string msg, extra;   // extra: lineas adicionales (estado, tabla del bench)
    std::vector<uchar> bin;   // vista / jpeg
};
static Resp R(bool ok, const std::string& m = "") {
    Resp r;
    r.ok = ok;
    r.msg = m;
    return r;
}

// ---------------------------------------------------------------------- argumentos con comillas
static std::vector<std::string> partir(const std::string& l) {
    std::vector<std::string> r;
    std::string a;
    bool q = false, hay = false;
    for (char c : l) {
        if (c == '"') {
            q = !q;
            hay = true;
        } else if (!q && (c == ' ' || c == '\t' || c == '\n' || c == '\r')) {
            if (hay || !a.empty()) r.push_back(a);
            a.clear();
            hay = false;
        } else {
            a += c;
        }
    }
    if (hay || !a.empty()) r.push_back(a);
    return r;
}
static std::string juntar(const std::vector<std::string>& v, size_t i) {
    std::string s;
    for (; i < v.size(); i++) s += (s.empty() ? "" : " ") + v[i];
    return s;
}

// ======================================================================
class Nucleo {
public:
    aus::Conf c;
    Camara cam;
    Salida sal;
    Calibracion cal;
    Memoria* mem = nullptr;   // se crea al usarla
    Banco banco;
    Contexto ctx;
    Estadisticas est;
    Filtros fil;              // laboratorio: filtros y kernels (perfiles/filtros.conf)
    cv::Mat fondo_crudo;      // mesa vacia sin filtros; ctx.fondo = fil.aplicar(fondo_crudo)
    Modelo* modelo = nullptr;
    Manos* manos = nullptr;
    std::string modelo_id, manos_err;
    bool manos_on = false, buscar = false, marcas_on = true;
    std::vector<Det> dets;
    quest::Juego juego;                  // Instrumental Quest: escenarios tipo videojuego
    std::vector<quest::PiezaP> piezas_p;   // dets + manos en coordenadas del proyector
    std::vector<Mano> manos_res;
    Cuadro ult;   // ultimo cuadro (crudo, sin convertir)
    // movimiento
    cv::Mat mov_ref, mov_masc;
    double t_mov = 0, t_proy = 0, t_infer = 0, t_verif = 0;
    bool moviendo = false, en_reposo = false;
    long n_mov = 0, n_infer = 0, n_cuadros = 0;
    // rendimiento
    double fps = 0, lat_ms = 0, t_fps = 0;
    int k_fps = 0;
    std::deque<double> lats;
    // ensenar
    struct {
        bool activo = false, propuesta = false;
        std::string clase;
        cv::Rect s;   // en el lienzo si hay calibracion; si no, en la camara
    } ens;
    // lienzo del proyector
    std::string firma;
    cv::Mat patron;
    long version = 0, version_masc = -1;
    int srv = -1;

    // ---------------------------------------------------------------- arranque
    bool iniciar() {
        c.cargar();
        g_filtros = &fil;
        fil.cargar();
        afinidad();
        if (!cam.abrir(c)) log("camara: " + cam.error + " (sigo; revisa camara.* en austero.conf)");
        if (!sal.abrir(c)) log("salida: sin proyector");
        cam.proyectado = [this]() { return sal.actual(); };
        cal.cargar();
        juego.cargar(aus::ruta("escenarios"));
        juego.quieto_s = c.d("escenario.quieto_s", 1.0);
        abrir_socket();
        log(fmt("austero v3 listo: camara %s %dx%d@%d, salida %s %dx%d, RAM %.0f MB", cam.tipo.c_str(), cam.w, cam.h, cam.fps,
                sal.tipo.c_str(), sal.w, sal.h, est.leer().proc_ram_mb));
        if (c.b("autoajuste.al_iniciar", false)) cmd({"autoajuste"});
        if (sal.abierta() && c.b("calibracion.al_iniciar", true)) cmd({"calibrar"});
        std::string m = c.s("inicio.modelo", "");
        if (!m.empty() && m != "0") log(cmd({"modelo", m}).msg);
        if (c.b("inicio.manos", false)) cmd({"manos", "on"});
        if (c.b("inicio.buscar", false)) cmd({"buscar", "on"});
        std::string png = aus::ruta("perfiles/marcador_mm.png");
        if (!aus::existe(png)) guardar_marcador_impreso(png, c.i("calibracion.marcador_id", 49), c.i("calibracion.marcador_mm", 50));
        t_mov = t_verif = aus::ahora();
        dibujar(true);
        return true;
    }

    void afinidad() {
        int n = c.i("cpu.nucleo", -1);   // fijar el hilo a un nucleo (los otros quedan para el sistema)
        if (n >= 0) {
            cpu_set_t s;
            CPU_ZERO(&s);
            CPU_SET(n, &s);
            if (pthread_setaffinity_np(pthread_self(), sizeof s, &s) == 0) log(fmt("hilo fijado al nucleo %d", n));
        }
        int prio = c.i("cpu.nice", 0);
        if (prio) (void)!nice(prio);
    }

    void cerrar() {
        log("apagando...");
        soltar_modelo();
        soltar_manos();
        delete mem;
        mem = nullptr;
        sal.cerrar();
        cam.cerrar();
        if (srv >= 0) close(srv);
        unlink(sock().c_str());
    }

    static std::string sock() {
        const char* s = getenv("AUSTERO_SOCKET");
        return s ? s : "/tmp/austero.sock";
    }
    void abrir_socket() {
        unlink(sock().c_str());
        srv = socket(AF_UNIX, SOCK_STREAM, 0);
        sockaddr_un a{};
        a.sun_family = AF_UNIX;
        strncpy(a.sun_path, sock().c_str(), sizeof(a.sun_path) - 1);
        if (bind(srv, (sockaddr*)&a, sizeof a) != 0 || listen(srv, 8) != 0) {
            log("no pude abrir el socket " + sock());
            close(srv);
            srv = -1;
            return;
        }
        chmod(sock().c_str(), 0660);
        fcntl(srv, F_SETFL, O_NONBLOCK);
    }

    Memoria& memoria() {
        if (!mem) {
            mem = new Memoria();
            ctx.memoria = mem;
        }
        return *mem;
    }

    // ---------------------------------------------------------------- lazo
    void correr() {
        double periodo_sim = 1.0 / std::max(1, cam.fps);
        double t_sim = 0;
        while (g_vivo) {
            fd_set fs;
            FD_ZERO(&fs);
            int mx = -1;
            if (srv >= 0) {
                FD_SET(srv, &fs);
                mx = std::max(mx, srv);
            }
            if (cam.fd() >= 0) {
                FD_SET(cam.fd(), &fs);
                mx = std::max(mx, cam.fd());
            }
            double espera = 0.5;
            if (cam.sim) espera = std::max(0.0, t_sim + periodo_sim - aus::ahora());
            timeval tv{(long)espera, (long)((espera - (long)espera) * 1e6)};
            int k = select(mx + 1, &fs, nullptr, nullptr, &tv);
            if (k < 0) continue;
            if (srv >= 0 && FD_ISSET(srv, &fs)) atender();
            bool hay = false;
            if (cam.fd() >= 0 && FD_ISSET(cam.fd(), &fs)) hay = cam.tomar(ult);
            if (cam.sim && aus::ahora() - t_sim >= periodo_sim) {
                t_sim = aus::ahora();
                hay = cam.tomar(ult);
            }
            if (hay) cuadro();
            periodicas();
        }
    }

    void periodicas() {
        double t = aus::ahora();
        sal.eventos();
        if (juego.activo() || juego.grabando) {
            std::string av;
            bool cambio = juego.evaluar(piezas_p, !moviendo, t);
            if (juego.grabar_evaluar(piezas_p, !moviendo, t, av)) log(av);
            for (auto& m : juego.avisos) log(m);
            juego.avisos.clear();
            if (cambio || juego.firma(t) != firma_juego) dibujar();
        } else if (!firma_juego.empty()) dibujar();
        // reposo: nadie se mueve hace rato -> soltar modelo y GPU
        double rep = c.d("reposo.min", 5) * 60;
        if (rep > 0 && !en_reposo && (modelo || manos) && t - t_mov > rep) {
            log("reposo: sin movimiento, suelto el modelo y la GPU");
            en_reposo = true;
            soltar_modelo(true);
            soltar_manos(true);
            if (c.b("reposo.energia", false)) log(perfil_energia("5w"));
        }
        // verificacion periodica de la calibracion (lazo cerrado)
        double cada = c.d("calibracion.verificar_cada_s", 0);
        if (cada > 0 && cal.lista() && sal.abierta() && !ens.activo && !moviendo && t - t_verif > cada) {
            t_verif = t;
            Herramientas h = herramientas();
            double e = verificar(cal, h);
            dibujar(true);
            if (e > c.d("calibracion.tolerancia_px", 6) && c.b("calibracion.recalibrar", true)) {
                log(fmt("se movio la camara o el proyector (%.1f px): recalibrando", e));
                cmd({"calibrar"});
            }
        }
    }

    // gris chico (1/4) para detectar movimiento: en YUYV es solo tomar el canal Y salteado
    cv::Mat gris_chico(const Cuadro& q) {
        int f = std::max(1, c.i("movimiento.reduccion", 4));
        cv::Mat g;
        if (q.formato == 0) {
            cv::Mat t;
            cv::resize(q.crudo, t, cv::Size(q.w / f, q.h / f), 0, 0, cv::INTER_NEAREST);
            cv::extractChannel(t, g, 0);
        } else if (q.formato == 1) {
            g = cv::imdecode(q.crudo, f >= 8 ? cv::IMREAD_REDUCED_GRAYSCALE_8 : (f >= 4 ? cv::IMREAD_REDUCED_GRAYSCALE_4 : cv::IMREAD_REDUCED_GRAYSCALE_2));
        } else {
            cv::Mat t;
            cv::resize(q.crudo, t, cv::Size(q.w / f, q.h / f), 0, 0, cv::INTER_NEAREST);
            cv::cvtColor(t, g, cv::COLOR_BGR2GRAY);
        }
        return g;
    }

    void cuadro() {
        double t = aus::ahora();
        n_cuadros++;
        // ---- movimiento
        cv::Mat g = gris_chico(ult);
        bool mov = false;
        if (!mov_ref.empty() && mov_ref.size() == g.size()) {
            cv::Mat d;
            cv::absdiff(g, mov_ref, d);
            cv::threshold(d, d, c.d("movimiento.umbral", 18), 255, cv::THRESH_BINARY);
            if (!mov_masc.empty() && mov_masc.size() == d.size()) d.setTo(0, mov_masc);
            double frac = cv::countNonZero(d) / (double)d.total();
            // ignorar el cambio que causa el propio proyector al redibujar
            mov = frac > c.d("movimiento.fraccion", 0.004) && t - t_proy > c.d("movimiento.ignorar_proyector_s", 0.35);
        }
        mov_ref = g;
        if (mov) {
            t_mov = t;
            n_mov++;
            if (en_reposo) despertar();
        }
        moviendo = t - t_mov < c.d("movimiento.seguir_s", 1.5);
        bool siempre = c.b("movimiento.siempre", false);
        bool hay_trabajo = modelo || (manos && manos_on) || (buscar && mem && !mem->vacia()) ||
                           ((juego.activo() || juego.grabando) && !ctx.fondo.empty());
        double tope = c.d("modelo.fps_max", 8);
        // jugando o grabando: ademas una revision cada 1.5 s aunque nada se mueva (piezas delgadas casi no "mueven" la imagen)
        bool vigilia = (juego.activo() || juego.grabando) && t - t_infer > c.d("escenario.revisar_s", 1.5);
        bool toca = hay_trabajo && (moviendo || siempre || dets_pendiente || vigilia) && (tope <= 0 || t - t_infer >= 1.0 / tope);
        if (toca) {
            aus::Crono cr;
            t_infer = t;
            n_infer++;
            cv::Mat bgr = fil.aplicar(ult.bgr());   // "lo que ve la red"
            std::vector<Det> d;
            if (modelo && modelo->ok) {
                try {
                    d = modelo->procesar(bgr);
                } catch (const std::exception& e) {
                    log("modelo " + modelo_id + " fallo: " + e.what());
                    modelo->ok = false;
                }
            }
            // forma (orejas, punta, largo/ancho) sobre la resta de fondo: confirma o corrige a la red y quita
            // lo que la red ve donde no hay nada (orillas del pano, marcos del proyector)
            ctx.px_por_mm = cal.px_por_mm;
            if (fil.v("formas") > 0.5 && !ctx.fondo.empty()) {
                if (modelo && modelo->ok && modelo_id != "fondo" && modelo_id != "ejemplos" && modelo_id != "orientacion")
                    d = aplicar_formas(bgr, ctx, &d);
                else if (!modelo && (juego.activo() || juego.grabando))
                    d = aplicar_formas(bgr, ctx, nullptr);
            }
            if (buscar && mem && !mem->vacia() && modelo_id != "ejemplos") {
                auto b = mem->buscar(bgr, ctx.fondo, ctx.mascara);
                d.insert(d.end(), b.begin(), b.end());
            }
            dets = d;
            if (manos && manos_on) manos_res = manos->procesar(bgr);
            {
                std::vector<Mano> ms = manos_res;
                if (t - t_manos_ext < 1.5) ms.insert(ms.end(), manos_ext.begin(), manos_ext.end());
                piezas_p = a_proyector(dets, ms);
            }
            dets_pendiente = moviendo;   // una pasada mas al detenerse, para la posicion final
            double l = cr.ms();
            lat_ms = lat_ms > 0 ? 0.8 * lat_ms + 0.2 * l : l;
            lats.push_back(l);
            if (lats.size() > 100) lats.pop_front();
            k_fps++;
            dibujar();
        }
        if (t - t_fps >= 1.0) {
            fps = k_fps / (t - t_fps);
            t_fps = t;
            k_fps = 0;
        }
    }
    bool dets_pendiente = false;
    std::string firma_juego;
    // manos que manda un programa de fuera (MediaPipe en la Raspberry): "manos_ext w h x,y;x,y;...|x,y;..."
    std::vector<Mano> manos_ext;
    double t_manos_ext = -10;
    static std::string plataforma() {
        static std::string p;
        if (!p.empty()) return p;
        p = "pc";
        if (aus::existe("/etc/nv_tegra_release")) p = "jetson";
        else
            for (auto& l : aus::lineas("/proc/device-tree/model"))
                if (l.find("Raspberry Pi") != std::string::npos) p = "raspberry";
        return p;
    }
    // de la camara al proyector (sin calibrar: solo se escala)
    std::vector<cv::Point2f> c2p(const std::vector<cv::Point2f>& v) {
        if (cal.lista()) return cal.c2p(v);
        std::vector<cv::Point2f> r;
        for (auto& p : v) r.push_back(cv::Point2f(p.x * sal.w / std::max(1, cam.w), p.y * sal.h / std::max(1, cam.h)));
        return r;
    }
    std::vector<quest::PiezaP> a_proyector(const std::vector<Det>& ds, const std::vector<Mano>& ms) {
        std::vector<quest::PiezaP> r;
        for (auto& d : ds) {
            quest::PiezaP p;
            p.clase = d.clase;
            p.tipo = quest::tipo_pieza(d.clase);
            std::vector<cv::Point2f> v;
            if (!d.contorno.empty()) {
                std::vector<cv::Point> s;
                cv::approxPolyDP(d.contorno, s, 1.5, true);
                for (auto& q : s) v.push_back(q);
            } else
                v = {d.caja.tl(), cv::Point2f((float)d.caja.br().x, (float)d.caja.y), d.caja.br(), cv::Point2f((float)d.caja.x, (float)d.caja.br().y)};
            cv::Point2f m(0, 0);
            for (auto& q : c2p(v)) p.poli.push_back(q), m += q;
            p.centro = m * (1.f / std::max<size_t>(1, p.poli.size()));
            r.push_back(p);
        }
        for (auto& h : ms) {   // manos de poseNet: el casco de sus puntos
            std::vector<cv::Point2f> v;
            for (auto& q : h.puntos)
                if (q.x >= 0) v.push_back(q);
            if (v.size() < 3) continue;
            quest::PiezaP p;
            p.tipo = p.clase = "mano";
            std::vector<cv::Point2f> hu;
            cv::convexHull(v, hu);
            cv::Point2f m(0, 0);
            for (auto& q : c2p(hu)) p.poli.push_back(q), m += q;
            p.centro = m * (1.f / p.poli.size());
            r.push_back(p);
        }
        return r;
    }
    // ---------------------------------------------------------------- proyector
    void dibujar(bool forzar = false) {
        if (!sal.abierta() || !patron.empty()) return;
        std::vector<std::pair<std::vector<cv::Point>, std::string>> marcas;
        std::string f;
        double tj = aus::ahora();
        bool jugando = juego.activo();
        firma_juego = juego.firma(tj) + (juego.grabando ? "G" + juego.grab_id : "");
        f += firma_juego;
        if (cal.lista() && marcas_on && !jugando) {
            for (size_t i = 0; i < dets.size() && i < 12; i++) {
                const Det& d = dets[i];
                // marco con margen ALREDEDOR de la pieza: la luz del proyector no cae sobre ella
                // (asi no cambia su apariencia ni confunde la resta de fondo)
                float mg = (float)c.d("salida.margen_px", 10);
                cv::RotatedRect rr = d.contorno.empty() ? cv::RotatedRect((d.caja.tl() + d.caja.br()) * 0.5,
                                                                          cv::Size2f((float)d.caja.width, (float)d.caja.height), 0)
                                                        : cv::minAreaRect(d.contorno);
                rr.size.width += 2 * mg;
                rr.size.height += 2 * mg;
                cv::Point2f q4[4];
                rr.points(q4);
                std::vector<cv::Point2f> pts(q4, q4 + 4);
                std::vector<cv::Point> pp;
                for (auto& q : cal.c2p(pts)) pp.push_back(cv::Point((int)std::lround(q.x / 6) * 6, (int)std::lround(q.y / 6) * 6));
                std::string txt = d.conf < 0.999f ? fmt("%s %.0f%%", d.clase.c_str(), d.conf * 100) : d.clase;
                marcas.push_back({pp, txt});
                f += txt;
                for (auto& p : pp) f += fmt("%d,%d;", p.x, p.y);
            }
        }
        if (ens.activo) f += fmt("S%d,%d,%d,%d,%d", ens.s.x, ens.s.y, ens.s.width, ens.s.height, (int)ens.propuesta);
        if (!forzar && f == firma) return;   // nada cambio: no se toca el proyector
        firma = f;
        cv::Mat l = cv::Mat::zeros(sal.h, sal.w, CV_8UC3);
        for (auto& m : marcas) {
            cv::Scalar col = color_de(m.second);
            cv::polylines(l, std::vector<std::vector<cv::Point>>{m.first}, true, col, 3);
            cv::Rect r = cv::boundingRect(m.first);
            cv::putText(l, m.second, cv::Point(r.x, std::max(24, r.y - 8)), cv::FONT_HERSHEY_SIMPLEX, 0.8, col, 2);
        }
        if (jugando) juego.dibujar(l, tj);
        if (juego.grabando) cv::putText(l, "GRABANDO: " + quest::sin_acentos(juego.grab_id) + " (pon cada pieza en su lugar y quita la mano)",
                                        cv::Point(20, sal.h - 20), cv::FONT_HERSHEY_DUPLEX, 0.7, cv::Scalar(60, 60, 255), 2);
        if (ens.activo && cal.lista()) {
            cv::Scalar a(0, 220, 255);
            cv::rectangle(l, ens.s, a, 3);
            cv::putText(l, (ens.propuesta ? "? " + ens.clase + " (Enter = si)" : ens.clase), cv::Point(ens.s.x, std::max(28, ens.s.y - 10)),
                        cv::FONT_HERSHEY_SIMPLEX, 0.9, a, 2);
        }
        mostrar(l);
    }
    void mostrar(const cv::Mat& img) {
        sal.mostrar(img);
        t_proy = aus::ahora();
        version++;
        actualizar_mascara();
    }
    // zona donde el proyector pinta, en la camara: se ignora al buscar piezas y al medir movimiento
    void actualizar_mascara() {
        if (!cal.lista() || version_masc == version) return;
        version_masc = version;
        cv::Mat g;
        cv::cvtColor(sal.actual(), g, cv::COLOR_BGR2GRAY);
        double mx;
        cv::minMaxLoc(g, nullptr, &mx);
        if (mx < 10) {
            ctx.mascara.release();
            mov_masc.release();
            return;
        }
        cv::Mat m;
        cv::warpPerspective(g > 10, m, cal.H_p2c, cv::Size(cam.w, cam.h), cv::INTER_NEAREST);
        int dm = std::max(1, c.i("salida.margen_mascara", 11)) | 1;   // el proyector "derrama" luz alrededor de lo que dibuja
        cv::dilate(m, ctx.mascara, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(dm, dm)));
        int f = std::max(1, c.i("movimiento.reduccion", 4));
        cv::resize(ctx.mascara, mov_masc, cv::Size(cam.w / f, cam.h / f), 0, 0, cv::INTER_NEAREST);
    }

    // ---------------------------------------------------------------- utilidades de captura sincronica
    bool nuevo(Cuadro& q, double timeout = 1.0) {
        double t0 = aus::ahora();
        while (aus::ahora() - t0 < timeout) {
            if (cam.sim) {
                aus::dormir(1.0 / std::max(1, cam.fps));
                return cam.tomar(q);
            }
            if (cam.fd() < 0) return false;
            fd_set fs;
            FD_ZERO(&fs);
            FD_SET(cam.fd(), &fs);
            timeval tv{0, 200000};
            if (select(cam.fd() + 1, &fs, nullptr, nullptr, &tv) > 0 && cam.tomar(q)) return true;
        }
        return false;
    }
    cv::Mat promedio(int n, double espera, bool color) {
        double t0 = aus::ahora();
        Cuadro q;
        while (aus::ahora() - t0 < espera) nuevo(q, 0.3);   // vaciar mientras el proyector cambia
        cv::Mat acc;
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (!nuevo(q)) continue;
            cv::Mat f;
            (color ? q.bgr() : q.gris()).convertTo(f, color ? CV_32FC3 : CV_32F);
            if (acc.empty()) acc = f;
            else acc += f;
            k++;
        }
        if (!k) return cv::Mat();
        cv::Mat o;
        acc.convertTo(o, color ? CV_8UC3 : CV_8U, 1.0 / k);
        return o;
    }
    Herramientas herramientas() {
        Herramientas h;
        h.pw = sal.w;
        h.ph = sal.h;
        h.proyectar = [this](const cv::Mat& p) {
            if (p.empty()) {
                patron.release();
                dibujar(true);
            } else {
                patron = p;
                mostrar(p);
            }
        };
        h.foto = [this](int n, double e) { return promedio(n, e, false); };
        return h;
    }

    // ---------------------------------------------------------------- modelos
    void soltar_modelo(bool recordar = false) {
        if (modelo) {
            banco.soltar(modelo);
            malloc_trim(0);   // devolver al sistema la RAM que dejo el modelo
        }
        modelo = nullptr;
        if (!recordar) modelo_id.clear();
        dets.clear();
    }
    void soltar_manos(bool recordar = false) {
        if (manos) banco.soltar(manos);
        manos = nullptr;
        manos_res.clear();
        malloc_trim(0);
        if (!recordar) manos_on = false;
    }
    void despertar() {
        en_reposo = false;
        log("movimiento: salgo del reposo");
        if (c.b("reposo.energia", false)) log(perfil_energia("normal"));
        if (!modelo_id.empty()) {
            std::string id = modelo_id;
            log(cmd({"modelo", id}).msg);
        }
        if (manos_on) cmd({"manos", "on"});
    }

    // crea el modelo con los parametros que guardaste la ultima vez
    Modelo* nuevo_modelo(const std::string& x, std::string& err) {
        if (x == "7" || x == "ejemplos") memoria();
        Modelo* m = banco.crear(x, ctx, err);
        if (!m) return nullptr;
        for (auto& kv : aus::lineas(aus::ruta("perfiles/params_" + m->id() + ".conf"))) {
            size_t e = kv.find('=');
            if (e != std::string::npos) m->poner(kv.substr(0, e), std::atof(kv.c_str() + e + 1));
        }
        return m;
    }

    Resp cargar_modelo(const std::string& x) {
        soltar_modelo();
        if (x.empty() || x == "0" || x == "ninguno") return R(true, "sin modelo (solo camara)");
        std::string err;
        Modelo* m = nuevo_modelo(x, err);
        if (!m) return R(false, err);
        std::string id = m->id();
        std::string w;
        if (!m->disponible(w)) {
            banco.soltar(m);
            return R(false, id + " no disponible: " + w);
        }
        if (id == "ejemplos") memoria();
        aus::Crono cr;
        if (!m->cargar()) {
            std::string e = m->error;
            banco.soltar(m);
            return R(false, id + " no cargo: " + e);
        }
        modelo = m;
        modelo_id = id;
        dets_pendiente = true;
        t_mov = aus::ahora();   // el reposo cuenta desde que lo cargas
        if ((id == "fondo" || id == "orientacion" || id == "ejemplos") && ctx.fondo.empty()) cmd({"fondo"});
        return R(true, fmt("modelo %s listo en %.1f s (%s)", id.c_str(), cr.s(), m->motor.empty() ? "CPU" : m->motor.c_str()));
    }

    // ---------------------------------------------------------------- estado
    std::string estado() {
        Muestra s = est.leer();
        std::vector<double> v(lats.begin(), lats.end());
        std::sort(v.begin(), v.end());
        double p95 = v.empty() ? 0 : v[(size_t)(0.95 * (v.size() - 1))];
        std::string mem_t;
        if (mem)
            for (auto& kv : mem->resumen()) mem_t += (mem_t.empty() ? "" : ",") + kv.first + ":" + std::to_string(kv.second);
        std::string d;
        for (size_t i = 0; i < dets.size() && i < 8; i++)
            d += (d.empty() ? "" : "|") + dets[i].clase + fmt(":%.0f", dets[i].conf * 100) +
                 (dets[i].angulo >= 0 ? fmt(":%.0f", dets[i].angulo) : "");
        std::string cat;
        for (auto& m : catalogo()) cat += (cat.empty() ? "" : ",") + m.tecla + ":" + m.id;
        std::string t;
        t += fmt("fps=%.1f\nlat_ms=%.1f\nlat_p95=%.1f\n", fps, lat_ms, p95);
        t += fmt("cuadros=%ld\ninferencias=%ld\nmovimiento=%d\nreposo=%d\n", n_cuadros, n_infer, (int)moviendo, (int)en_reposo);
        t += "modelo=" + (modelo_id.empty() ? std::string("ninguno") : modelo_id) + (en_reposo && !modelo_id.empty() ? " (dormido)" : "") + "\n";
        t += "motor=" + (modelo ? modelo->motor : std::string("-")) + "\n";
        t += "params=" + (modelo ? modelo->params_texto() : std::string("")) + "\n";
        t += "modelo_error=" + (modelo ? modelo->error : std::string("")) + "\n";
        t += "complementos=" + banco.cargados() + "\n";
        t += fmt("manos=%d\nbuscar=%d\nfondo=%d\nmarcas=%d\n", (int)(manos != nullptr), (int)buscar, (int)!ctx.fondo.empty(), (int)marcas_on);
        t += fmt("camara=%s %dx%d@%d\nsalida=%s %dx%d\n", cam.tipo.c_str(), cam.w, cam.h, cam.fps, sal.tipo.c_str(), sal.w, sal.h);
        t += fmt("calib=%s\ncalib_error=%.2f\npx_por_mm=%.3f\n", cal.lista() ? cal.metodo.c_str() : "NO", cal.error_px, cal.px_por_mm);
        t += fmt("filtro_gamma=%.2f\n", c.d("filtros.gamma", 1));
        if (ens.activo) t += fmt("ensenando=%s\n", ens.clase.c_str());
        t += juego.estado();
        t += "plataforma=" + plataforma() + fmt("\nlienzo=%dx%d\n", sal.w, sal.h);
        t += "memoria=" + mem_t + "\ndets=" + d + "\ncatalogo=" + cat + "\n";
        t += s.texto();
        for (auto& l : aus::ultimos_log(5)) t += "log=" + l + "\n";
        return t;
    }

    void actualizar_fondo() {
        if (!fondo_crudo.empty()) ctx.fondo = fil.aplicar(fondo_crudo).clone();
        dets_pendiente = true;
    }

    // vista para la terminal o la web: SOLO se calcula cuando alguien la pide
    cv::Mat anotada() { return panel(0); }
    cv::Mat dibujar_dets(cv::Mat img) {
        for (auto& d : dets) {
            cv::Scalar col = color_de(d.clase);
            if (!d.contorno.empty()) cv::drawContours(img, std::vector<std::vector<cv::Point>>{d.contorno}, -1, col, 2);
            else cv::rectangle(img, d.caja, col, 2);
            cv::putText(img, d.clase, cv::Point(d.caja.x, std::max(12, d.caja.y - 4)), cv::FONT_HERSHEY_SIMPLEX, 0.45, col, 1);
        }
        for (auto& m : manos_res)
            for (auto& p : m.puntos)
                if (p.x >= 0) cv::circle(img, p, 3, cv::Scalar(0, 255, 0), -1);
        if (ens.activo) cv::rectangle(img, sombra_cam(), cv::Scalar(0, 220, 255), 2);
        return img;
    }
    // ---- LABORATORIO: 0 = lo que ve la red con detecciones | 1 camara | 2 lo que ve la red | 3 mascara
    //                   4 bordes y esquinas | 5 las 4 juntas.  lab_info dice cuanto tardo y que encontro.
    std::string lab_info;
    cv::Mat panel(int n) {
        if (ult.crudo.empty()) return cv::Mat();
        aus::Crono cr;
        cv::Mat cruda = ult.bgr();
        if (n == 1) {
            lab_info = "camara";
            return cruda.clone();
        }
        if (n == 7) {   // la camara vista DESDE el proyector (para dibujar zonas encima en la web)
            lab_info = "camara en coordenadas del proyector";
            cv::Mat o;
            if (cal.lista()) cv::warpPerspective(cruda, o, cal.H_c2p, cv::Size(sal.w, sal.h));
            else cv::resize(cruda, o, cv::Size(sal.w, sal.h));
            return o;
        }
        if (n == 6) {   // lo que esta proyectando (para ver el juego desde la web o MobaXterm)
            lab_info = "proyector";
            cv::Mat p = sal.actual();
            return p.empty() ? cv::Mat::zeros(sal.h, sal.w, CV_8UC3) : p.clone();
        }
        cv::Mat f = fil.aplicar(cruda);
        if (f.data == cruda.data) f = cruda.clone();
        if (n == 0 || n == 2) {
            lab_info = fmt("filtros %.1f ms", cr.ms());
            return dibujar_dets(f);
        }
        if (n == 3) {
            cv::Mat m = fil.mascara(f, ctx.fondo, ctx.mascara), out;
            if (m.empty()) {
                out = cv::Mat::zeros(f.size(), CV_8UC3);
                cv::putText(out, "sin fondo: austero fondo (mesa vacia)", cv::Point(10, out.rows / 2), cv::FONT_HERSHEY_SIMPLEX, 0.6,
                            cv::Scalar(180, 180, 180), 1);
                lab_info = "sin fondo";
                return out;
            }
            out = cv::Mat::zeros(f.size(), CV_8UC3);
            out.setTo(cv::Scalar(90, 255, 120), m);
            std::vector<std::vector<cv::Point>> cs;
            cv::findContours(m.clone(), cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
            int piezas = 0;
            for (auto& q : cs)
                if (cv::contourArea(q) >= fil.v("mascara_area")) {
                    cv::rectangle(out, cv::boundingRect(q), cv::Scalar(0, 200, 255), 2);
                    piezas++;
                }
            lab_info = fmt("mascara %.1f%%, %d piezas, %.1f ms", 100.0 * cv::countNonZero(m) / m.total(), piezas, cr.ms());
            return out;
        }
        if (n == 4) {
            int ne = 0;
            cv::Mat b = fil.bordes(f, &ne);
            lab_info = fmt("%d esquinas, %.1f ms", ne, cr.ms());
            return b;
        }
        // 5: mosaico 2x2
        int w = cruda.cols / 2, h = cruda.rows / 2;
        cv::Mat mos(h * 2, w * 2, CV_8UC3, cv::Scalar(20, 20, 20));
        const char* tit[] = {"1 CAMARA", "2 LO QUE VE LA RED", "3 MASCARA", "4 BORDES Y ESQUINAS"};
        std::string infos;
        for (int k = 1; k <= 4; k++) {
            cv::Mat p = panel(k), r;
            if (p.empty()) continue;
            cv::resize(p, r, cv::Size(w, h), 0, 0, cv::INTER_AREA);
            cv::rectangle(r, cv::Rect(0, 0, w, 18), cv::Scalar(0, 0, 0), -1);
            cv::putText(r, tit[k - 1], cv::Point(4, 13), cv::FONT_HERSHEY_SIMPLEX, 0.42, cv::Scalar(120, 200, 255), 1);
            r.copyTo(mos(cv::Rect(((k - 1) % 2) * w, ((k - 1) / 2) * h, w, h)));
            if (k >= 3) infos += (infos.empty() ? "" : " | ") + lab_info;
        }
        lab_info = infos + fmt(" | total %.1f ms", cr.ms());
        return mos;
    }

    cv::Rect sombra_cam() {
        if (!cal.lista()) return ens.s;
        auto p = cal.p2c({cv::Point2f((float)ens.s.x, (float)ens.s.y), cv::Point2f((float)ens.s.br().x, (float)ens.s.y),
                          cv::Point2f((float)ens.s.br().x, (float)ens.s.br().y), cv::Point2f((float)ens.s.x, (float)ens.s.br().y)});
        return cv::boundingRect(p);
    }

    // ---------------------------------------------------------------- comandos
    Resp cmd(const std::vector<std::string>& a) {
        if (a.empty()) return R(false, "comando vacio");
        const std::string& k = a[0];
        auto arg = [&](size_t i, const std::string& d = "") { return a.size() > i ? a[i] : d; };
        auto onoff = [&](bool actual) {
            std::string v = arg(1);
            if (v.empty()) return !actual;
            return v == "on" || v == "1" || v == "si" || v == "prender";
        };
        if (k == "estado" || k == "status") {
            Resp r;
            r.extra = estado();
            return r;
        }
        if (k == "log") {
            Resp r;
            for (auto& l : aus::ultimos_log(std::atoi(arg(1, "30").c_str()))) r.extra += l + "\n";
            return r;
        }
        if (k == "apagar") {
            g_vivo = 0;
            return R(true, "apagado");
        }
        if (k == "modelo") return cargar_modelo(arg(1, "0"));
        if (k == "param") {
            if (!modelo) return R(false, "no hay modelo activo");
            std::string n = arg(1);
            if (!modelo->p.count(n)) return R(false, "parametros de " + modelo_id + ": " + modelo->params_texto());
            std::string v = arg(2);
            double x;
            if (!v.empty() && (v[0] == '+' || v[0] == '-') && n == "entrada") {   // siguiente/anterior tamano
                auto t = modelo->tamanos();
                if (t.empty()) return R(false, "este modelo no cambia de tamano");
                auto it = std::find(t.begin(), t.end(), (int)modelo->p[n]);
                int i = std::max(0, std::min((int)t.size() - 1, (int)(it - t.begin()) + (v[0] == '+' ? 1 : -1)));
                x = t[i];
            } else if (!v.empty() && (v[0] == '+' || v[0] == '-') && v.size() > 1 && a.size() > 3 && a[3] == "rel") {
                x = modelo->p[n] + std::atof(v.c_str());
            } else {
                x = std::atof(v.c_str());
            }
            modelo->poner(n, x);
            std::string t;
            for (auto& kv : modelo->p) t += kv.first + "=" + fmt("%g", kv.second) + "\n";
            aus::escribir(aus::ruta("perfiles/params_" + modelo_id + ".conf"), t);
            dets_pendiente = true;
            return R(true, fmt("%s.%s = %g", modelo_id.c_str(), n.c_str(), modelo->p[n]));
        }
        if (k == "conf") {   // ver o cambiar cualquier ajuste en vivo: conf movimiento.umbral 20
            if (a.size() < 3) {
                Resp r;
                r.extra = c.todo();
                return r;
            }
            c.poner(a[1], a[2]);
            return R(true, a[1] + " = " + a[2]);
        }
        if (k == "filtro" || k == "filtros") {   // filtro | filtro <nombre> <valor|+|-> | filtro reset
            if (arg(1) == "reset") {
                fil.reset();
                actualizar_fondo();
                return R(true, "filtros de fabrica");
            }
            if (a.size() < 3) {
                Resp r;
                r.extra = fil.lista();
                return r;
            }
            if (!fil.poner(a[1], a[2])) return R(false, "no existe el filtro '" + a[1] + "' (austero filtro para ver la lista)");
            actualizar_fondo();
            return R(true, fmt("%s = %g", a[1].c_str(), fil.v(a[1])));
        }
        if (k == "cam") {   // cam | cam <nombre> <valor|+|->
            if (a.size() < 3) {
                Resp r;
                r.extra = cam.ctl_lista();
                return r;
            }
            if (!cam.ctl_hay(a[1])) return R(false, "la camara no tiene '" + a[1] + "' (austero cam para ver la lista)");
            int v;
            if (a[2] == "+" || a[2] == "-") {
                int mn = 0, mx = 0, paso = 1;
                cam.ctl_rango(a[1], mn, mx);
                std::string ls = cam.ctl_lista();   // paso del control
                size_t q = ls.find(a[1] + "|");
                if (q != std::string::npos) {
                    std::vector<std::string> cs;
                    std::string lin = ls.substr(q, ls.find('\n', q) - q), x;
                    std::stringstream ss(lin);
                    while (std::getline(ss, x, '|')) cs.push_back(x);
                    if (cs.size() > 4) paso = std::max(1, std::atoi(cs[4].c_str()));
                }
                int pasos = std::max(1, (mx - mn) / 40 / paso);   // ~40 pasos en todo el rango
                v = cam.ctl_leer(a[1]) + (a[2] == "+" ? 1 : -1) * paso * pasos;
                v = std::max(mn, std::min(mx, v));
            } else {
                v = std::atoi(a[2].c_str());
            }
            if (a[1] == "exposicion" && cam.ctl_hay("exposicion_auto")) cam.ctl_poner("exposicion_auto", 1);   // manual
            if (a[1] == "blancos" && cam.ctl_hay("blancos_auto")) cam.ctl_poner("blancos_auto", 0);
            if (a[1] == "enfoque" && cam.ctl_hay("enfoque_auto")) cam.ctl_poner("enfoque_auto", 0);
            bool ok = cam.ctl_poner(a[1], v);
            cam.ctl_guardar();
            return R(ok, fmt("%s = %d", a[1].c_str(), cam.ctl_leer(a[1])) + (ok ? "" : " (la camara no acepto ese valor)"));
        }
        if (k == "ajustes") {   // todo lo ajustable, para el tablero y la web: tipo|nombre|valor|min|max|paso|desc
            Resp r;
            std::stringstream f(fil.lista()), cm(cam.ctl_lista());
            std::string l;
            while (std::getline(f, l))
                if (!l.empty()) r.extra += "f|" + l + "\n";
            while (std::getline(cm, l))
                if (!l.empty()) r.extra += "c|" + l + "\n";
            if (modelo)
                for (auto& kv : modelo->p) {
                    double mx = kv.first == "entrada" ? 1280 : (kv.second <= 1.0 ? 1.0 : kv.second * 4);
                    double paso = kv.first == "entrada" ? 32 : (kv.second <= 1.0 ? 0.05 : 1);
                    r.extra += fmt("m|%s|%g|0|%g|%g|parametro del modelo %s\n", kv.first.c_str(), kv.second, mx, paso, modelo_id.c_str());
                }
            return r;
        }
        if (k == "autoajuste") {
            double g;
            std::string t = autoajuste(cam, [this]() { return promedio(2, 0.35, false); }, c.d("autoajuste.brillo", 115),
                                       c.d("autoajuste.max_saturados", 0.01), g);
            fil.poner("gamma", fmt("%.2f", g));
            actualizar_fondo();
            cam.ctl_guardar();
            return R(true, t);
        }
        if (k == "calibrar") {
            if (!sal.abierta()) return R(false, "no hay salida al proyector");
            std::string m = arg(1, c.s("calibracion.metodo", "aruco"));
            Herramientas h = herramientas();
            // el blanco del proyector satura la camara: calibrar con la exposicion baja y regresarla despues
            int exp0 = cam.ctl_hay("exposicion") ? cam.ctl_leer("exposicion") : -1;
            int gan0 = cam.ctl_hay("ganancia") ? cam.ctl_leer("ganancia") : -1;
            if (exp0 > 0 && c.d("calibracion.brillo", 45) > 0) {
                double g;
                h.proyectar(cv::Mat(sal.h, sal.w, CV_8U, cv::Scalar(255)));
                log(autoajuste(cam, [this]() { return promedio(2, 0.35, false); }, c.d("calibracion.brillo", 45) * 2.5,
                               0.002, g));
            }
            bool ok = calibrar(cal, h, m, c);
            if (exp0 > 0) {
                cam.ctl_poner("exposicion", exp0);
                if (gan0 >= 0) cam.ctl_poner("ganancia", gan0);
            }
            version_masc = -1;
            dibujar(true);
            return R(ok, "calibracion " + m + (ok ? fmt(": lista (%.2f px)", cal.error_px) : ": fallo"));
        }
        if (k == "verificar") {
            Herramientas h = herramientas();
            double e = verificar(cal, h);
            return R(e >= 0, e >= 0 ? fmt("error %.1f px", e) : "no se pudo verificar");
        }
        if (k == "mm") {
            Herramientas h = herramientas();
            bool ok = medir_mm(cal, h, c);
            if (ok) cal.guardar();
            return R(ok, ok ? fmt("%.3f px por mm", cal.px_por_mm) : "no vi el marcador impreso");
        }
        if (k == "fondo") {   // mesa VACIA con el proyector en negro
            Herramientas h = herramientas();
            if (sal.abierta()) h.proyectar(cv::Mat::zeros(sal.h, sal.w, CV_8U));
            cv::Mat f = promedio(4, 0.35, true);
            if (sal.abierta()) h.proyectar(cv::Mat());
            if (f.empty()) return R(false, "sin imagen para el fondo");
            fondo_crudo = f;
            actualizar_fondo();
            cv::imwrite(aus::ruta("perfiles/fondo.jpg"), f);
            dets_pendiente = true;
            return R(true, "fondo guardado (la mesa debe estar vacia)");
        }
        if (k == "manos") {
            bool on = onoff(manos != nullptr);
            soltar_manos();
            if (!on) return R(true, "manos apagadas");
            std::string err;
            manos = banco.crear_manos(err);
            if (!manos) return R(false, "manos: " + err);
            if (!manos->cargar((float)c.d("manos.umbral", 0.15))) {
                err = manos->error;
                soltar_manos();
                return R(false, "manos: " + err);
            }
            manos_on = true;
            return R(true, "manos encendidas (" + manos->motor + ")");
        }
        if (k == "buscar") {
            buscar = onoff(buscar);
            if (buscar) {
                memoria();
                if (ctx.fondo.empty()) cmd({"fondo"});
            }
            dets_pendiente = true;
            return R(true, std::string("buscar piezas ensenadas: ") + (buscar ? "on" : "off"));
        }
        if (k == "marcas") {
            marcas_on = onoff(marcas_on);
            dibujar(true);
            return R(true, std::string("marcas en el proyector: ") + (marcas_on ? "on" : "off"));
        }
        if (k == "ensenar") {
            std::string acc = arg(1);
            int paso = cal.lista() ? 30 : 8;
            if (acc == "mover" || acc == "tam" || acc == "auto" || acc == "guardar" || acc == "cancelar") {
                if (!ens.activo) return R(false, "primero: austero ensenar \"nombre de la pieza\"");
                if (acc == "mover") {
                    ens.s.x += std::atoi(arg(2, "0").c_str()) * paso;
                    ens.s.y += std::atoi(arg(3, "0").c_str()) * paso;
                    ens.propuesta = false;
                } else if (acc == "tam") {
                    int dw = std::atoi(arg(2, "0").c_str()) * paso, dh = std::atoi(arg(3, "0").c_str()) * paso;
                    ens.s = cv::Rect(ens.s.x - dw / 2, ens.s.y - dh / 2, std::max(paso, ens.s.width + dw), std::max(paso, ens.s.height + dh));
                } else if (acc == "cancelar") {
                    ens.activo = false;
                } else if (acc == "auto") {
                    cv::Mat bgr = ult.bgr();
                    auto cs = memoria().candidatos(bgr, ctx.fondo, ctx.mascara);
                    if (cs.empty()) return R(false, "no veo nada nuevo en la mesa (toma el fondo vacio: austero fondo)");
                    auto it = std::max_element(cs.begin(), cs.end(), [](const std::vector<cv::Point>& x, const std::vector<cv::Point>& y) {
                        return cv::contourArea(x) < cv::contourArea(y);
                    });
                    cv::Rect r = cv::boundingRect(*it);
                    r = cv::Rect(r.x - 10, r.y - 10, r.width + 20, r.height + 20);
                    if (cal.lista())
                        r = cv::boundingRect(cal.c2p({cv::Point2f((float)r.x, (float)r.y), cv::Point2f((float)r.br().x, (float)r.y),
                                                      cv::Point2f((float)r.br().x, (float)r.br().y), cv::Point2f((float)r.x, (float)r.br().y)}));
                    ens.s = r;
                    ens.propuesta = true;
                    dibujar();
                    return R(true, "propuesta: ¿es ahi? Enter = guardar, flechas = corregir");
                } else if (acc == "guardar") {
                    cv::Mat bgr = ult.bgr();
                    Det d;
                    std::string msg;
                    double mmpx = cal.px_por_mm > 0 ? 1.0 / cal.px_por_mm : 0;
                    bool ok = memoria().ensenar(bgr, sombra_cam(), ens.clase, ctx.fondo, ctx.mascara, mmpx, d, msg);
                    ens.propuesta = false;
                    if (ok) dets = {d};
                    dibujar();
                    return R(ok, msg);
                }
                dibujar();
                return R(true);
            }
            std::string cl = juntar(a, 1);
            if (cl.empty()) return R(false, "uso: austero ensenar \"tijera mayo\"");
            ens.activo = true;
            ens.propuesta = false;
            ens.clase = cl;
            ens.s = cal.lista() ? cv::Rect(sal.w / 2 - 150, sal.h / 2 - 100, 300, 200) : cv::Rect(cam.w / 2 - 60, cam.h / 2 - 40, 120, 80);
            memoria();
            if (ctx.fondo.empty()) cmd({"fondo"});
            dibujar();
            return R(true, "ensenando '" + cl + "': flechas mueven la sombra, +/- tamano, Enter guarda, x = la camara propone");
        }
        if (k == "confirmar") {
            if (ult.crudo.empty()) return R(false, "sin imagen");
            int n = memoria().confirmar(ult.bgr(), dets);
            return R(true, fmt("foto + %d etiquetas guardadas en dataset/", n));
        }
        if (k == "olvidar") {
            bool ok = memoria().olvidar(juntar(a, 1));
            return R(ok, ok ? "olvidada" : "no existe esa pieza");
        }
        if (k == "perfil") return R(true, perfil_energia(arg(1)));
        if (k == "foto") {   // foto [panel: 0 camara con detecciones | 6 lo que se proyecta] [nombre]
            cv::Mat img = arg(1).empty() ? anotada() : panel(std::atoi(arg(1).c_str()));
            if (img.empty()) return R(false, "sin imagen");
            std::string p = "perfiles/" + (arg(2).empty() ? "foto_" + aus::fecha() : aus::slug(arg(2))) + ".jpg";
            cv::imwrite(aus::ruta(p), img);
            return R(true, "foto: " + p);
        }
        if (k == "vista") {   // BGR crudo chico para el tablero de terminal: vista w h [panel 0-5]
            cv::Mat img = panel(std::atoi(arg(3, "0").c_str()));
            if (img.empty()) return R(false, "sin imagen");
            int w = std::atoi(arg(1, "80").c_str()), h = std::atoi(arg(2, "40").c_str());
            cv::resize(img, img, cv::Size(std::max(8, w), std::max(8, h * 2)), 0, 0, cv::INTER_AREA);
            Resp r;
            r.msg = fmt("%d %d ", img.cols, img.rows) + lab_info;
            r.bin.assign(img.datastart, img.dataend);
            return r;
        }
        if (k == "jpeg") {   // para la pagina web: jpeg calidad ancho [panel 0-5]
            cv::Mat img = panel(std::atoi(arg(3, "0").c_str()));
            int wmax = std::atoi(arg(2, "640").c_str());
            if (!img.empty() && img.cols > wmax) cv::resize(img, img, cv::Size(wmax, img.rows * wmax / img.cols), 0, 0, cv::INTER_AREA);
            if (img.empty()) return R(false, "sin imagen");
            Resp r;
            cv::imencode(".jpg", img, r.bin, {cv::IMWRITE_JPEG_QUALITY, std::atoi(arg(1, "70").c_str())});
            r.msg = lab_info;
            return r;
        }
        if (k == "bench") return bench(a);
        if (k == "escenario" || k == "escenarios") return cmd_escenario(a);
        if (k == "manos_ext") {   // manos_ext <ancho> <alto> <mano>|<mano>   mano = x,y;x,y;... (pixeles de la imagen que se le dio)
            double w = std::atof(arg(1, "0").c_str()), h = std::atof(arg(2, "0").c_str());
            manos_ext.clear();
            if (w > 0 && h > 0 && a.size() > 3) {
                std::string todo = a[3];
                size_t p0 = 0;
                while (p0 <= todo.size()) {
                    size_t e = todo.find('|', p0);
                    std::string m = todo.substr(p0, e == std::string::npos ? std::string::npos : e - p0);
                    Mano mano;
                    size_t q0 = 0;
                    while (q0 < m.size()) {
                        size_t f = m.find(';', q0);
                        float x, y;
                        if (std::sscanf(m.substr(q0, f == std::string::npos ? std::string::npos : f - q0).c_str(), "%f,%f", &x, &y) == 2)
                            mano.puntos.push_back(cv::Point2f((float)(x * cam.w / w), (float)(y * cam.h / h)));
                        if (f == std::string::npos) break;
                        q0 = f + 1;
                    }
                    if (mano.puntos.size() >= 3) manos_ext.push_back(mano);
                    if (e == std::string::npos) break;
                    p0 = e + 1;
                }
            }
            t_manos_ext = aus::ahora();
            // que el juego se entere aunque nada mas se mueva
            std::vector<Mano> ms = manos_res;
            ms.insert(ms.end(), manos_ext.begin(), manos_ext.end());
            piezas_p = a_proyector(dets, ms);
            return Resp();
        }
        if (k == "sim") {
            if (!cam.sim) return R(false, "solo con camara simulada (austero start --sim)");
            std::string acc = arg(1, "revolver");
            if (acc == "revolver") cam.sim->revolver(std::atoi(arg(2, "3").c_str()));
            else if (acc == "pieza") cam.sim->pieza(arg(2, "tijera"));
            else if (acc == "vaciar") cam.sim->objs.clear();
            else if (acc == "poner") {   // sim poner <tipo> x y angulo [apertura]   (px de camara)
                Simulada::Obj o{arg(2, "tijera"), std::atof(arg(3, "320").c_str()), std::atof(arg(4, "240").c_str()), std::atof(arg(5, "0").c_str())};
                o.apertura = std::atof(arg(6, "0").c_str());
                cam.sim->objs.push_back(o);
            } else if (acc == "quitar") {
                std::string t = arg(2);
                for (size_t i = cam.sim->objs.size(); i-- > 0;)
                    if (t.empty() || cam.sim->objs[i].tipo == t) {
                        cam.sim->objs.erase(cam.sim->objs.begin() + i);
                        break;
                    }
            }
            else if (acc == "marcador") cam.sim->marcador = dibujar_marcador(c.i("calibracion.marcador_id", 49), (int)(c.d("calibracion.marcador_mm", 50) / 1.4));
            else if (acc == "mover_proyector")
                for (auto& p : cam.sim->esq) p += cv::Point2f(5, 3);
            return R(true, "sim " + acc);
        }
        return R(false, "comando desconocido: " + k + " (austero ayuda)");
    }

    // ---------------------------------------------------------------- Instrumental Quest (escenarios)
    Resp cmd_escenario(const std::vector<std::string>& a) {
        auto arg = [&](size_t i, const std::string& d = "") { return a.size() > i ? a[i] : d; };
        std::string s = arg(1, "lista");
        double t = aus::ahora();
        auto redibuja = [&](Resp r) { dibujar(true); return r; };
        if (s == "lista" || s == "ls") {
            Resp r;
            int i = 1;
            for (auto& e : juego.lista) {
                auto it = juego.records.find(e.id);
                std::string est = juego.bloqueado(e) ? "bloqueado" : "";
                if (it != juego.records.end() && it->second.completos)
                    est = fmt("%s  record %d:%02d", std::string(it->second.estrellas, '*').c_str(), (int)it->second.mejor / 60, (int)it->second.mejor % 60);
                r.extra += fmt("%d. %-28s %2d tareas  %d zonas  %d prohibidas  %s\n", i++, e.nombre.c_str(), (int)e.tareas.size(),
                               (int)e.zonas.size(), (int)e.prohibidas.size(), est.c_str());
            }
            if (juego.lista.empty()) r.extra = "no hay escenarios. Crea uno: austero escenario grabar \"Charola cirugia menor\"\n";
            return r;
        }
        if (s == "recargar") {
            juego.cargar(aus::ruta("escenarios"));
            return R(true, fmt("%d escenarios", (int)juego.lista.size()));
        }
        if (s == "jugar") {
            if (ctx.fondo.empty()) return R(false, "primero la foto de la mesa vacia: austero fondo");
            std::string m;
            bool ok = juego.empezar(arg(2, "1"), m, arg(3) == "forzar");
            if (ok && !modelo && !(fil.v("formas") > 0.5)) m += " (aviso: sin modelo y con formas apagado no vere piezas)";
            if (ok) dets_pendiente = true;
            // con zonas prohibidas conviene ver bien las manos (poseNet en la GPU de la Jetson)
            quest::Escenario* e = juego.buscar(arg(2, "1"));
            if (ok && e && !e->prohibidas.empty() && !manos && c.b("escenario.manos_auto", true)) {
                Resp rm = cmd({"manos", "on"});
                m += rm.ok ? " (manos encendidas para las zonas prohibidas)" : " (manos de poseNet no disponibles: se usan las formas)";
            }
            return redibuja(R(ok, m));
        }
        if (s == "parar" || s == "salir") {
            juego.parar();
            return redibuja(R(true, "escenario detenido"));
        }
        if (s == "ok" || s == "confirmar") {
            juego.confirmar();
            return R(true, "confirmado");
        }
        if (s == "sig" || s == "siguiente") return juego.saltar(1), redibuja(R(true, "siguiente tarea"));
        if (s == "atras") return juego.saltar(-1), redibuja(R(true, "tarea anterior"));
        if (s == "pausa") return juego.pausa(true), redibuja(R(true, "pausa"));
        if (s == "seguir") return juego.pausa(false), redibuja(R(true, "seguimos"));
        if (s == "nuevo") {
            if (arg(2).empty()) return R(false, "uso: austero escenario nuevo \"Charola cirugia menor\"");
            auto& e = juego.nuevo(arg(2));
            return R(true, "creado escenarios/" + e.id + ".esc (graba sus tareas: austero escenario grabar " + e.id + ")");
        }
        if (s == "grabar") {
            if (arg(2).empty()) return R(false, "uso: austero escenario grabar \"Nombre\"   (con la mesa vacia)");
            quest::Escenario* e = juego.buscar(arg(2));
            if (!e) e = &juego.nuevo(arg(2));
            if (ctx.fondo.empty()) cmd({"fondo"});
            juego.parar();
            juego.grabar_empezar(*e, piezas_p);
            dets_pendiente = true;
            return redibuja(R(true, "GRABANDO '" + e->nombre + "': pon cada pieza en su lugar, una por una, y quita la mano. "
                                    "Al terminar: austero escenario listo"));
        }
        if (s == "listo" || s == "terminar") {
            std::string m = juego.grabar_terminar();
            return redibuja(R(true, m));
        }
        // ---- editar zonas: zona | prohibida | linea | quitar
        if (s == "zona" || s == "prohibida" || s == "linea" || s == "quitar") {
            quest::Escenario* e = juego.buscar(arg(2));
            std::string nom = arg(3);
            if (!e || nom.empty())
                return R(false, "uso: austero escenario " + s + " <escenario> <nombre> " +
                                    (s == "linea" ? "x1 y1 x2 y2" : s == "quitar" ? "" : "[x y ancho alto]  (sin numeros: donde esta la pieza ahora)"));
            if (s == "quitar") {
                size_t n0 = e->zonas.size() + e->prohibidas.size();
                e->zonas.erase(std::remove_if(e->zonas.begin(), e->zonas.end(), [&](const std::pair<std::string, cv::Rect>& z) { return z.first == nom; }),
                               e->zonas.end());
                e->prohibidas.erase(std::remove_if(e->prohibidas.begin(), e->prohibidas.end(), [&](const quest::Prohibida& z) { return z.nombre == nom; }),
                                    e->prohibidas.end());
                if (n0 == e->zonas.size() + e->prohibidas.size()) return R(false, "no existe " + nom);
                juego.guardar(*e);
                return redibuja(R(true, "quitada " + nom));
            }
            std::vector<int> v;
            for (size_t i = 4; i < a.size(); i++) v.push_back(std::atoi(a[i].c_str()));
            cv::Rect r;
            if (s == "linea") {
                if (v.size() != 4) return R(false, "uso: austero escenario linea <escenario> <nombre> x1 y1 x2 y2  (pixeles del proyector)");
            } else if (v.size() == 4) r = cv::Rect(v[0], v[1], v[2], v[3]);
            else {   // donde esta la pieza mas grande (no mano) ahora
                double mejor = 0;
                for (auto& p : piezas_p)
                    if (p.tipo != "mano" && cv::contourArea(p.poli) > mejor) mejor = cv::contourArea(p.poli), r = cv::boundingRect(p.poli);
                if (mejor <= 0) return R(false, "no veo ninguna pieza: pon algo donde va la zona, o da x y ancho alto");
                r.x -= 30, r.y -= 30, r.width += 60, r.height += 60;
            }
            std::string que;
            if (s == "zona") {
                bool hay = false;
                for (auto& z : e->zonas)
                    if (z.first == nom) z.second = r, hay = true;
                if (!hay) e->zonas.push_back({nom, r});
                que = fmt("zona %s = %d %d %d %d", nom.c_str(), r.x, r.y, r.width, r.height);
            } else {
                quest::Prohibida pr;
                pr.nombre = nom;
                pr.linea = s == "linea";
                if (pr.linea) pr.a = {v[0], v[1]}, pr.b = {v[2], v[3]};
                else pr.r = r;
                e->prohibidas.erase(std::remove_if(e->prohibidas.begin(), e->prohibidas.end(), [&](const quest::Prohibida& z) { return z.nombre == nom; }),
                                    e->prohibidas.end());
                e->prohibidas.push_back(pr);
                que = pr.linea ? fmt("linea %s (no cruzar)", nom.c_str()) : fmt("prohibida %s = %d %d %d %d", nom.c_str(), r.x, r.y, r.width, r.height);
            }
            juego.guardar(*e);
            return redibuja(R(true, que + "  -> escenarios/" + e->id + ".esc"));
        }
        // ---- para la pagina web /quest (responden en "extra", sin llenar el registro)
        if (s == "json") {
            Resp r;
            if (arg(2).empty()) r.extra = juego.json_lista();
            else if (arg(2) == "juego") r.extra = juego.json_juego();
            else {
                quest::Escenario* e = juego.buscar(arg(2));
                if (!e) return R(false, "no existe");
                r.extra = juego.json(*e);
            }
            return r;
        }
        if (s == "piezas") {   // lo que se ve ahora, en coordenadas del proyector
            Resp r;
            r.extra = "[";
            for (size_t i = 0; i < piezas_p.size(); i++) {
                auto& p = piezas_p[i];
                r.extra += fmt("%s{\"tipo\":\"%s\",\"cx\":%.0f,\"cy\":%.0f,\"pts\":[", i ? "," : "", p.tipo.c_str(), p.centro.x, p.centro.y);
                for (size_t q = 0; q < p.poli.size(); q++) r.extra += fmt("%s[%d,%d]", q ? "," : "", p.poli[q].x, p.poli[q].y);
                r.extra += "]}";
            }
            r.extra += "]";
            return r;
        }
        if (s == "historial") {
            Resp r;
            r.extra = juego.historial(std::atoi(arg(2, "50").c_str()));
            return r;
        }
        if (s == "escribir") {   // escenario escribir <id> <texto .esc en hexadecimal>
            std::string hx = arg(3), txt, m;
            for (size_t i = 0; i + 1 < hx.size(); i += 2) txt += (char)std::strtol(hx.substr(i, 2).c_str(), nullptr, 16);
            bool ok = juego.escribir(arg(2), txt, sal.w, sal.h, m);
            return redibuja(R(ok, m));
        }
        if (s == "borrar") {
            std::string m;
            bool ok = juego.borrar(arg(2), m);
            return redibuja(R(ok, m));
        }
        if (s == "duplicar") {
            std::string m;
            bool ok = juego.duplicar(arg(2), arg(3), m);
            return R(ok, m);
        }
        if (s == "desde") {   // escenario desde <id> <tarea>: jugar empezando en esa tarea (para probar)
            Resp r = cmd({"escenario", "jugar", arg(2, "1"), "forzar"});
            if (r.ok) juego.saltar(std::max(0, std::atoi(arg(3, "1").c_str()) - 1));
            return redibuja(r);
        }
        if (s == "ver") {
            quest::Escenario* e = juego.buscar(arg(2, "1"));
            if (!e) return R(false, "no existe");
            Resp r;
            for (auto& l : aus::lineas(e->archivo)) r.extra += l + "\n";
            return r;
        }
        (void)t;
        return R(false, "escenario: lista | jugar <n> | parar | ok | sig | atras | pausa | seguir | grabar \"Nombre\" | listo | "
                        "zona/prohibida <esc> <nombre> [x y w h] | linea <esc> <nombre> x1 y1 x2 y2 | quitar <esc> <nombre> | ver <n> | nuevo \"Nombre\"");
    }

    // ---------------------------------------------------------------- benchmark
    Resp bench(const std::vector<std::string>& a) {
        double seg = c.d("bench.segundos", 15);
        std::vector<std::string> ids;
        for (size_t i = 1; i < a.size(); i++) {
            if (a[i] == "--seg" && i + 1 < a.size()) seg = std::atof(a[++i].c_str());
            else ids.push_back(a[i]);
        }
        if (ids.empty())
            for (auto& m : catalogo()) ids.push_back(m.id);
        std::string previo = modelo_id;
        soltar_modelo();
        std::vector<cv::Mat> clip;
        Cuadro q;
        for (int i = 0; i < c.i("bench.cuadros", 40); i++)
            if (nuevo(q)) clip.push_back(q.bgr().clone());
        if (clip.empty()) return R(false, "bench: sin camara");
        if (ctx.fondo.empty()) cmd({"fondo"});
        // verdad: fotos que guardaste al ensenar
        std::vector<std::pair<cv::Mat, std::vector<cv::Rect>>> verdad;
        auto fs = aus::listar(aus::ruta("dataset/images"));
        if (fs.size() > 30) fs.erase(fs.begin(), fs.end() - 30);
        for (auto& f : fs) {
            cv::Mat img = cv::imread(aus::ruta("dataset/images/" + f));
            if (img.empty()) continue;
            if (img.size() != cv::Size(cam.w, cam.h)) cv::resize(img, img, cv::Size(cam.w, cam.h));
            std::vector<cv::Rect> cj;
            for (auto& l : aus::lineas(aus::ruta("dataset/labels/" + f.substr(0, f.size() - 4) + ".txt"))) {
                int ci;
                double cx, cy, w, h;
                if (sscanf(l.c_str(), "%d %lf %lf %lf %lf", &ci, &cx, &cy, &w, &h) == 5)
                    cj.push_back(cv::Rect(cv::Point((int)((cx - w / 2) * cam.w), (int)((cy - h / 2) * cam.h)),
                                          cv::Point((int)((cx + w / 2) * cam.w), (int)((cy + h / 2) * cam.h))));
            }
            if (!cj.empty()) verdad.push_back({img, cj});
        }
        // linea base: el nucleo sin modelo (para comparar "antes contra despues")
        est.leer();
        aus::dormir(1.0);
        Muestra base = est.leer();
        std::string tabla = fmt("%-16s %6s %7s %7s %5s %5s %7s %6s %6s %9s %7s  %s\n", "modelo", "fps", "ms_p50", "ms_p95", "CPU%",
                                "GPU%", "+RAM_MB", "temp", "W", "aciertos", "carga_s", "motor");
        tabla += fmt("%-16s %6s %7s %7s %5.0f %5d %7s %6.1f %6.2f %9s %7s  %s\n", "(sin modelo)", "-", "-", "-", base.cpu_prom, base.gpu,
                     "0", base.temp_max(), base.potencia_mw / 1000.0, "-", "-", "nucleo solo");
        std::string csv = "modelo,fps,ms_p50,ms_p95,cpu,gpu,ram_extra_mb,temp_max,w,aciertos,carga_s,motor,nota\n";
        csv += fmt("sin_modelo,,,,%.0f,%d,0,%.1f,%.2f,,,nucleo,\n", base.cpu_prom, base.gpu, base.temp_max(), base.potencia_mw / 1000.0);
        log(fmt("bench: %d modelos x %.0f s, %d cuadros, %d fotos con etiqueta", (int)ids.size(), seg, (int)clip.size(), (int)verdad.size()));
        for (auto& id : ids) {
            std::string err;
            Modelo* m = nuevo_modelo(id, err);
            if (!m) {
                tabla += fmt("%-16s %s\n", id.c_str(), err.c_str());
                continue;
            }
            std::string nid = m->id(), w;
            if (!m->disponible(w)) {
                tabla += fmt("%-16s no disponible: %s\n", nid.c_str(), w.c_str());
                csv += nid + ",,,,,,,,,,,,\"" + w + "\"\n";
                banco.soltar(m);
                continue;
            }
            try {
                if (nid == "ejemplos") memoria();
                aus::Crono cc;
                if (!m->cargar()) {
                    tabla += fmt("%-16s no cargo: %s\n", nid.c_str(), m->error.c_str());
                    banco.soltar(m);
                    continue;
                }
                double carga = cc.s();
                for (int i = 0; i < c.i("bench.calentamiento", 5); i++) m->procesar(clip[i % clip.size()]);
                std::vector<double> lat;
                std::vector<Muestra> mu;
                est.leer();
                aus::Crono t0;
                double tm = aus::ahora();
                size_t i = 0;
                while (t0.s() < seg) {
                    aus::Crono c1;
                    m->procesar(clip[i++ % clip.size()]);
                    lat.push_back(c1.ms());
                    if (aus::ahora() - tm >= 1.0) {
                        mu.push_back(est.leer());
                        tm = aus::ahora();
                    }
                }
                double dur = t0.s();
                std::sort(lat.begin(), lat.end());
                auto prom = [&](std::function<double(const Muestra&)> f) {
                    double s = 0;
                    int k = 0;
                    for (auto& x : mu)
                        if (f(x) >= 0) {
                            s += f(x);
                            k++;
                        }
                    return k ? s / k : -1.0;
                };
                double cpu = prom([](const Muestra& x) { return x.cpu_prom; }), gpu = prom([](const Muestra& x) { return (double)x.gpu; });
                double ram = prom([](const Muestra& x) { return (double)x.ram_mb; }) - base.ram_mb;
                double pot = prom([](const Muestra& x) { return x.potencia_mw / 1000.0; });
                double tmax = -1;
                for (auto& x : mu) tmax = std::max(tmax, x.temp_max());
                int tot = 0, hall = 0;
                for (auto& v : verdad) {
                    auto d = m->procesar(v.first);
                    for (auto& r : v.second) {
                        tot++;
                        for (auto& x : d) {
                            double in = (r & x.caja).area(), un = r.area() + x.caja.area() - in;
                            if (un > 0 && in / un >= 0.3) {
                                hall++;
                                break;
                            }
                        }
                    }
                }
                std::string ac = tot ? fmt("%d/%d", hall, tot) : "-";
                tabla += fmt("%-16s %6.1f %7.1f %7.1f %5.0f %5.0f %7.0f %6.1f %6.2f %9s %7.1f  %s\n", nid.c_str(), i / dur, lat[lat.size() / 2],
                             lat[(size_t)(0.95 * (lat.size() - 1))], cpu, gpu, ram, tmax, pot, ac.c_str(), carga, m->motor.c_str());
                csv += fmt("%s,%.1f,%.1f,%.1f,%.0f,%.0f,%.0f,%.1f,%.2f,%s,%.1f,%s,\n", nid.c_str(), i / dur, lat[lat.size() / 2],
                           lat[(size_t)(0.95 * (lat.size() - 1))], cpu, gpu, ram, tmax, pot, ac.c_str(), carga, m->motor.c_str());
                log(fmt("bench %s: %.1f fps, %.0f ms", nid.c_str(), i / dur, lat[lat.size() / 2]));
            } catch (const std::exception& ex) {
                tabla += fmt("%-16s fallo: %s\n", nid.c_str(), std::string(ex.what()).substr(0, 120).c_str());
                csv += nid + ",,,,,,,,,,,,\"fallo\"\n";
                log("bench " + nid + " fallo: " + ex.what());
            }
            banco.soltar(m);   // suelta tambien el complemento y la GPU
            aus::dormir(1.5);
        }
        std::string base_arch = aus::ruta("bench/bench_" + aus::fecha());
        aus::escribir(base_arch + ".txt", tabla);
        aus::escribir(base_arch + ".csv", csv);
        if (!previo.empty()) cargar_modelo(previo);
        Resp r = R(true, "bench listo: bench/" + base_arch.substr(base_arch.rfind('/') + 1) + ".txt");
        r.extra = tabla;
        return r;
    }

    // ---------------------------------------------------------------- socket
    void atender() {
        while (true) {
            int k = accept(srv, nullptr, nullptr);
            if (k < 0) return;
            timeval tv{2, 0};
            setsockopt(k, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
            setsockopt(k, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
            std::string l;
            char b[4096];
            while (l.find('\n') == std::string::npos) {
                ssize_t n = recv(k, b, sizeof b, 0);
                if (n <= 0) break;
                l.append(b, n);
            }
            Resp r;
            try {
                r = cmd(partir(l.substr(0, l.find('\n'))));
            } catch (const std::exception& e) {
                r = R(false, e.what());
            }
            if (!r.msg.empty() && r.bin.empty() && l.compare(0, 6, "estado") != 0) log(r.msg);
            // respuesta: "ok|error <msg>\n" [+ "bin <n>\n" + bytes] [+ lineas extra]
            std::string cab = (r.ok ? "ok " : "error ") + r.msg + "\n";
            if (!r.bin.empty()) cab += fmt("bin %d\n", (int)r.bin.size());
            std::string todo = cab;
            todo.append((const char*)r.bin.data(), r.bin.size());
            todo += r.extra;
            size_t env = 0;
            while (env < todo.size()) {
                ssize_t n = send(k, todo.data() + env, todo.size() - env, MSG_NOSIGNAL);
                if (n <= 0) break;
                env += n;
            }
            close(k);
        }
    }
};

int main() {
    std::string base;
    if (getenv("AUSTERO_DIR")) base = getenv("AUSTERO_DIR");
    else {
        char b[4096];
        ssize_t k = readlink("/proc/self/exe", b, sizeof b - 1);
        b[k > 0 ? k : 0] = 0;
        std::string e = b;
        base = e.substr(0, e.rfind('/'));
        base = base.substr(0, base.rfind('/'));   // build/.. = carpeta del proyecto
    }
    aus::fijar_base(base);
    aus::crear_dirs(aus::ruta("perfiles"));
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, senal);
    signal(SIGINT, senal);
    Nucleo n;
    n.iniciar();
    n.correr();
    n.cerrar();
    return 0;
}
