// prueba_formas.cpp - simulacion para medir que tan bien reconoce por forma (sin camara ni Jetson).
//   austero-prueba-formas [--n 300] [--ppm 0.5] [--ruido 2.5] [--mano 0.3] [--escala] [--guardar carpeta] [--semilla 1]
// Cada prueba: foto de la mesa vacia (fondo) + otra con 1-4 piezas al azar (tijera recta/curva, bisturi, pinza
// abierta o cerrada), a veces una mano, otra luz y ruido. Se compara lo que dice el clasificador con la verdad.
#include <cstdio>
#include <cstdlib>
#include <map>
#include <string>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "base.hpp"
#include "escena.hpp"
#include "filtros.hpp"
#include "formas.hpp"

static std::string tipo_gt(const std::string& t) { return t == "tijera_curva" ? "tijera" : t; }

int main(int argc, char** argv) {
    int N = 300, W = 640, H = 480, guardar_n = 12, semilla = 1;
    double ppm = -1, ruido = 2.5, p_mano = 0.3;
    bool escala = false, detalle = false;
    std::string dir, solo;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto sig = [&]() { return i + 1 < argc ? std::string(argv[++i]) : std::string(); };
        if (a == "--n") N = std::atoi(sig().c_str());
        else if (a == "--ppm") ppm = std::atof(sig().c_str());
        else if (a == "--ruido") ruido = std::atof(sig().c_str());
        else if (a == "--mano") p_mano = std::atof(sig().c_str());
        else if (a == "--escala") escala = true;
        else if (a == "--detalle") detalle = true;
        else if (a == "--tipo") solo = sig();
        else if (a == "--guardar") dir = sig();
        else if (a == "--cuantas") guardar_n = std::atoi(sig().c_str());
        else if (a == "--semilla") semilla = std::atoi(sig().c_str());
        else if (a == "--ancho") W = std::atoi(sig().c_str());
        else if (a == "--alto") H = std::atoi(sig().c_str());
        else if (a == "--filtro") {   // --filtro nombre=valor
            std::string kv = sig();
            size_t e = kv.find('=');
            static Filtros tmp;
            if (!g_filtros) g_filtros = &tmp;
            if (e != std::string::npos)
                for (auto& x : g_filtros->p)
                    if (x.nombre == kv.substr(0, e)) x.valor = std::atof(kv.substr(e + 1).c_str());
        } else {
            std::printf("uso: austero-prueba-formas [--n 300] [--ppm 0.5] [--ruido 2.5] [--mano 0.3] [--escala] [--guardar dir] [--filtro k=v]\n");
            return 0;
        }
    }
    static Filtros fil;
    if (!g_filtros) g_filtros = &fil;
    if (!dir.empty()) aus::crear_dirs(dir);
    const char* tipos[] = {"tijera", "tijera_curva", "bisturi", "pinza"};
    std::vector<std::string> filas = {"tijera", "bisturi", "pinza", "mano"};
    std::vector<std::string> cols = {"tijera", "bisturi", "pinza", "mano", "objeto", "(nada)"};
    std::map<std::string, std::map<std::string, int>> conf;
    int fantasmas = 0, total_ok = 0, total = 0;
    double ms = 0;
    for (int it = 0; it < N; it++) {
        cv::RNG rng((uint64)(semilla * 100003 + it * 7919 + 17));
        double k = ppm > 0 ? ppm : rng.uniform(0.4, 0.75);
        cv::Mat r0 = escena::mesa(W, H, rng);
        cv::Mat fondo = escena::camara(r0, escena::luz_pareja(W, H, 0.55, 0.3, 0), 5, ruido, rng);
        int n = rng.uniform(1, 5);
        std::vector<escena::Obj> os;
        for (int t = 0; t < 200 && (int)os.size() < n; t++) {
            escena::Obj o = escena::al_azar(solo.empty() ? tipos[rng.uniform(0, 4)] : solo, W, H, rng);
            double rad = escena::largo_mm(o.tipo) * k / 2 + 6;
            bool choca = false;
            for (auto& q : os) choca |= std::hypot(q.x - o.x, q.y - o.y) < rad + escena::largo_mm(q.tipo) * k / 2 + 6;
            if (!choca) os.push_back(o);
        }
        if (rng.uniform(0., 1.) < p_mano) {   // mano entrando por una orilla, hacia adentro
            escena::Obj m;
            m.tipo = "mano";
            int lado = rng.uniform(0, 4);
            double u = rng.uniform(0.25, 0.75), d = rng.uniform(45., 75.) * k;
            if (lado == 0) m.x = d, m.y = u * H, m.a = 0;
            if (lado == 1) m.x = W - d, m.y = u * H, m.a = 180;
            if (lado == 2) m.x = u * W, m.y = d, m.a = 90;
            if (lado == 3) m.x = u * W, m.y = H - d, m.a = 270;
            m.a += rng.uniform(-30., 30.);
            bool choca = false;
            for (auto& q : os) choca |= std::hypot(q.x - m.x, q.y - m.y) < 130 * k + escena::largo_mm(q.tipo) * k / 2;
            if (!choca) os.push_back(m);
        }
        cv::Mat r = r0.clone(), et = cv::Mat::zeros(H, W, CV_8U);
        for (size_t i = 0; i < os.size(); i++) escena::pintar(r, os[i], k, rng, &et, (int)i + 1);
        cv::Mat img = escena::camara(r, escena::luz_pareja(W, H, 0.55 * rng.uniform(0.95, 1.05), 0.3, rng.uniform(-0.04, 0.04)), 5,
                                     ruido, rng);
        Contexto ctx;
        ctx.fondo = fondo;
        ctx.px_por_mm = escala ? k : 0;
        aus::Crono cr;
        auto ds = aplicar_formas(img, ctx, nullptr);
        ms += cr.ms();
        // emparejar
        std::vector<std::string> pred(os.size(), "(nada)");
        std::vector<int> mejor(os.size(), 0);
        for (auto& d : ds) {
            cv::Mat m = cv::Mat::zeros(H, W, CV_8U);
            cv::drawContours(m, std::vector<std::vector<cv::Point>>{d.contorno}, 0, cv::Scalar(255), cv::FILLED);
            std::vector<int> c(os.size() + 1, 0);
            for (int y = 0; y < H; y++)
                for (int x = 0; x < W; x++)
                    if (m.at<uchar>(y, x)) c[et.at<uchar>(y, x)]++;
            int b = 0;
            for (size_t i = 1; i < c.size(); i++)
                if (c[i] > 0 && (b == 0 || c[i] > c[b])) b = (int)i;
            if (b == 0 || c[b] < 10) {
                fantasmas++;
                continue;
            }
            std::string cl = tipo_de(d.clase);
            if (cl.empty()) cl = "objeto";
            if (c[b] > mejor[b - 1]) mejor[b - 1] = c[b], pred[b - 1] = cl;
            if (detalle && tipo_gt(os[b - 1].tipo) != cl)
                std::printf("[%d] verdad %-12s dice %-8s %3.0f%%  ap %.1f br %.2f  %s\n", it, os[b - 1].tipo.c_str(), cl.c_str(), d.conf * 100,
                            os[b - 1].apertura, os[b - 1].brillo, d.info.c_str());
        }
        for (size_t i = 0; i < os.size(); i++) {
            std::string g = tipo_gt(os[i].tipo);
            conf[g][pred[i]]++;
            total++;
            if (pred[i] == g) total_ok++;
        }
        if (!dir.empty() && it < guardar_n) {
            cv::Mat v = img.clone();
            for (auto& d : ds) {
                std::string t = tipo_de(d.clase);
                cv::Scalar col = t == "tijera" ? cv::Scalar(0, 140, 255) : t == "bisturi" ? cv::Scalar(255, 80, 0)
                               : t == "pinza" ? cv::Scalar(200, 0, 200) : t == "mano" ? cv::Scalar(0, 200, 255) : cv::Scalar(0, 0, 255);
                cv::drawContours(v, std::vector<std::vector<cv::Point>>{d.contorno}, 0, col, 1);
                cv::putText(v, aus::fmt("%s %.0f%%", d.clase.c_str(), d.conf * 100), d.caja.tl() + cv::Point(0, -3),
                            cv::FONT_HERSHEY_SIMPLEX, 0.38, col, 1);
            }
            for (auto& o : os)
                cv::putText(v, tipo_gt(o.tipo), cv::Point((int)o.x, (int)o.y), cv::FONT_HERSHEY_PLAIN, 0.8, cv::Scalar(255, 255, 255), 1);
            cv::Mat fina, f3, dos;
            separar_piezas(img, fondo, cv::Mat(), g_filtros->v("mascara_dif"), 50, &fina);
            cv::cvtColor(fina, f3, cv::COLOR_GRAY2BGR);
            cv::hconcat(f3, v, dos);
            cv::imwrite(aus::fmt("%s/prueba_%03d.jpg", dir.c_str(), it), dos);
        }
    }
    std::printf("\nSimulacion de formas: %d escenas, %d piezas, escala %s, ruido %.1f\n", N, total,
                ppm > 0 ? aus::fmt("%.2f px/mm", ppm).c_str() : "0.40-0.75 px/mm", ruido);
    std::printf("%-9s", "verdad");
    for (auto& c : cols) std::printf("%9s", c.c_str());
    std::printf("   acierto\n");
    for (auto& f : filas) {
        int s = 0;
        for (auto& c : cols) s += conf[f][c];
        if (!s) continue;
        std::printf("%-9s", f.c_str());
        for (auto& c : cols) std::printf("%9d", conf[f][c]);
        std::printf("   %5.1f%%\n", 100.0 * conf[f][f] / s);
    }
    std::printf("total: %.1f%% bien  | piezas fantasma: %d | %.1f ms por cuadro\n", 100.0 * total_ok / std::max(1, total), fantasmas,
                ms / std::max(1, N));
    return 0;
}
