#include "escenarios.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <sstream>

#include <opencv2/imgproc.hpp>

#include "base.hpp"
#include "formas.hpp"

using aus::fmt;

namespace quest {

// ====================================================================== utilidades
static std::string minus(std::string s) {
    for (auto& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}
static std::string recortar(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r"), b = s.find_last_not_of(" \t\r");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}
static std::vector<std::string> palabras(const std::string& s) {
    std::vector<std::string> v;
    std::istringstream is(s);
    std::string w;
    while (is >> w) v.push_back(w);
    return v;
}

std::string sin_acentos(const std::string& s) {
    static const char* de[] = {"á", "é", "í", "ó", "ú", "Á", "É", "Í", "Ó", "Ú", "ñ", "Ñ", "ü", "Ü", "¿", "¡"};
    static const char* a[] = {"a", "e", "i", "o", "u", "A", "E", "I", "O", "U", "n", "N", "u", "U", "", ""};
    std::string r = s;
    for (int i = 0; i < 16; i++) {
        size_t p;
        while ((p = r.find(de[i])) != std::string::npos) r.replace(p, std::string(de[i]).size(), a[i]);
    }
    return r;
}

std::string tipo_pieza(const std::string& clase) {
    std::string t = tipo_de(clase);
    if (!t.empty()) return t;
    std::string m = minus(sin_acentos(clase));
    size_t p = m.find_last_of(' ');
    if (p != std::string::npos && m.find('%') != std::string::npos) m = m.substr(0, p);
    return recortar(m);
}

static bool coincide(const PiezaP& p, const std::string& tipo) {
    if (p.tipo == tipo) return true;
    std::string c = minus(sin_acentos(p.clase));
    return c.find(tipo) != std::string::npos;
}

std::string Cond::texto() const {
    std::string z;
    for (auto& x : zonas) z += " " + x;
    if (tipo == "pieza") return "pieza " + pieza + z;
    if (tipo == "vacio") return "vacio" + z;
    if (tipo == "conteo") return fmt("conteo %s %d", pieza.c_str(), (int)n) + z;
    if (tipo == "espera") return fmt("espera %g", n);
    return tipo;
}

const cv::Rect* Escenario::zona(const std::string& z) const {
    for (auto& kv : zonas)
        if (minus(kv.first) == minus(z)) return &kv.second;
    return nullptr;
}

// ====================================================================== archivos
static Escenario leer(const std::string& archivo) {
    Escenario e;
    e.archivo = archivo;
    std::string base = archivo.substr(archivo.find_last_of('/') + 1);
    e.id = base.substr(0, base.size() - 4);
    e.nombre = e.id;
    Tarea* t = nullptr;
    for (auto& l0 : aus::lineas(archivo)) {
        std::string l = recortar(l0);
        if (l.empty() || l[0] == '#') continue;
        if (l == "[tarea]") {
            e.tareas.push_back(Tarea());
            t = &e.tareas.back();
            continue;
        }
        size_t q = l.find('=');
        if (q == std::string::npos) continue;
        std::string k = recortar(l.substr(0, q)), v = recortar(l.substr(q + 1));
        if (!t) {
            if (k == "nombre") e.nombre = v;
            else if (k == "orden") e.orden = std::atoi(v.c_str());
            else if (k == "estrellas") {
                auto w = palabras(v);
                if (w.size() >= 1) e.estrellas3 = std::atof(w[0].c_str());
                if (w.size() >= 2) e.estrellas2 = std::atof(w[1].c_str());
            } else if (k.compare(0, 10, "prohibida ") == 0 || k.compare(0, 6, "linea ") == 0) {
                auto w = palabras(v);
                Prohibida pr;
                pr.linea = k[0] == 'l';
                pr.nombre = recortar(k.substr(pr.linea ? 6 : 10));
                if (w.size() != 4) continue;
                int q4[4];
                for (int i = 0; i < 4; i++) q4[i] = std::atoi(w[i].c_str());
                if (pr.linea) pr.a = {q4[0], q4[1]}, pr.b = {q4[2], q4[3]};
                else pr.r = cv::Rect(q4[0], q4[1], q4[2], q4[3]);
                e.prohibidas.push_back(pr);
            } else if (k.compare(0, 5, "zona ") == 0) {
                auto w = palabras(v);
                if (w.size() == 4)
                    e.zonas.push_back({recortar(k.substr(5)), cv::Rect(std::atoi(w[0].c_str()), std::atoi(w[1].c_str()),
                                                                       std::atoi(w[2].c_str()), std::atoi(w[3].c_str()))});
            }
        } else {
            if (k == "nombre") t->nombre = v;
            else if (k == "instruccion") t->instruccion = v;
            else if (k == "tiempo") t->tiempo_max = std::atof(v.c_str());
            else if (k == "silueta") {
                auto w = palabras(v);
                if (!w.empty()) t->silueta_tipo = w[0];
                for (size_t i = 1; i < w.size(); i++) {
                    int x, y;
                    if (std::sscanf(w[i].c_str(), "%d,%d", &x, &y) == 2) t->silueta.push_back({x, y});
                }
            } else if (k == "pasa") {
                auto w = palabras(minus(v));
                if (w.empty()) continue;
                Cond c;
                c.tipo = w[0];
                if (c.tipo == "pieza" && w.size() >= 2) {
                    c.pieza = w[1];
                    c.zonas.assign(w.begin() + 2, w.end());
                } else if (c.tipo == "vacio") c.zonas.assign(w.begin() + 1, w.end());
                else if (c.tipo == "conteo" && w.size() >= 3) {
                    c.pieza = w[1];
                    c.n = std::atof(w[2].c_str());
                    c.zonas.assign(w.begin() + 3, w.end());
                } else if (c.tipo == "espera" && w.size() >= 2) c.n = std::atof(w[1].c_str());
                else if (c.tipo != "confirmar") continue;
                // las zonas se guardan con su nombre original
                for (auto& z : c.zonas)
                    for (auto& kv : e.zonas)
                        if (minus(kv.first) == z) z = kv.first;
                t->pasa.push_back(c);
            }
        }
    }
    return e;
}

bool Juego::guardar(const Escenario& e) const {
    std::string s = "# Escenario de Instrumental Quest (Modo Austero). Se puede editar a mano.\n"
                    "# zona <nombre> = x y ancho alto   (pixeles del proyector)\n"
                    "# pasa = pieza <tipo> <zona> | vacio <zonas> | conteo <tipo> <n> [zona] | espera <s> | confirmar\n"
                    "# prohibida <nombre> = x y ancho alto   |   linea <nombre> = x1 y1 x2 y2   (la mano no debe entrar / cruzar)\n";
    s += "nombre = " + e.nombre + "\n";
    s += fmt("orden = %d\n", e.orden);
    if (e.estrellas3 > 0) s += fmt("estrellas = %g %g\n", e.estrellas3, e.estrellas2);
    for (auto& z : e.zonas) s += fmt("zona %s = %d %d %d %d\n", z.first.c_str(), z.second.x, z.second.y, z.second.width, z.second.height);
    for (auto& p : e.prohibidas)
        if (p.linea) s += fmt("linea %s = %d %d %d %d\n", p.nombre.c_str(), p.a.x, p.a.y, p.b.x, p.b.y);
        else s += fmt("prohibida %s = %d %d %d %d\n", p.nombre.c_str(), p.r.x, p.r.y, p.r.width, p.r.height);
    for (auto& t : e.tareas) {
        s += "\n[tarea]\nnombre = " + t.nombre + "\n";
        if (!t.instruccion.empty()) s += "instruccion = " + t.instruccion + "\n";
        for (auto& c : t.pasa) s += "pasa = " + c.texto() + "\n";
        if (t.tiempo_max > 0) s += fmt("tiempo = %g\n", t.tiempo_max);
        if (!t.silueta.empty()) {
            s += "silueta = " + (t.silueta_tipo.empty() ? std::string("pieza") : t.silueta_tipo);
            for (auto& p : t.silueta) s += fmt(" %d,%d", p.x, p.y);
            s += "\n";
        }
    }
    aus::crear_dirs(dir);
    return aus::escribir(e.archivo, s);
}

void Juego::cargar(const std::string& d) {
    dir = d;
    aus::crear_dirs(dir);
    std::string actual = esc ? esc->id : "";
    lista.clear();
    for (auto& f : aus::listar(dir))
        if (f.size() > 4 && f.substr(f.size() - 4) == ".esc") lista.push_back(leer(dir + "/" + f));
    std::sort(lista.begin(), lista.end(), [](const Escenario& a, const Escenario& b) {
        return a.orden != b.orden ? a.orden < b.orden : a.id < b.id;
    });
    esc = nullptr;
    if (!actual.empty()) esc = buscar(actual);
    if (jugando && (!esc || k >= (int)esc->tareas.size())) jugando = false;
    cargar_records();
}

Escenario* Juego::buscar(const std::string& q) {
    if (q.empty()) return nullptr;
    bool num = std::all_of(q.begin(), q.end(), ::isdigit);
    if (num) {
        int n = std::atoi(q.c_str());
        if (n >= 1 && n <= (int)lista.size()) return &lista[n - 1];
    }
    std::string m = minus(q), s = aus::slug(q);
    for (auto& e : lista)
        if (e.id == q || e.id == s || minus(e.nombre) == m) return &e;
    for (auto& e : lista)
        if (minus(e.nombre).find(m) != std::string::npos) return &e;
    return nullptr;
}

bool Juego::bloqueado(const Escenario& e) const {
    // se desbloquea al completar el escenario anterior (por orden)
    const Escenario* prev = nullptr;
    for (auto& x : lista) {
        if (&x == &e) break;
        prev = &x;
    }
    if (!prev) return false;
    auto it = records.find(prev->id);
    return it == records.end() || it->second.completos == 0;
}

Escenario& Juego::nuevo(const std::string& nombre) {
    Escenario e;
    e.nombre = nombre;
    e.id = aus::slug(nombre);
    if (e.id.empty()) e.id = "escenario";
    std::string base = e.id;
    for (int i = 2; buscar(e.id) && buscar(e.id)->id == e.id; i++) e.id = base + fmt("_%d", i);
    e.archivo = dir + "/" + e.id + ".esc";
    for (auto& x : lista) e.orden = std::max(e.orden, x.orden);
    e.orden++;
    guardar(e);
    std::string id = e.id;
    cargar(dir);
    return *buscar(id);
}

void Juego::cargar_records() {
    records.clear();
    for (auto& l : aus::lineas(dir + "/records.txt")) {
        auto w = palabras(l);
        if (w.size() < 5) continue;
        Record r;
        r.mejor = std::atof(w[1].c_str());
        r.estrellas = std::atoi(w[2].c_str());
        r.intentos = std::atoi(w[3].c_str());
        r.completos = std::atoi(w[4].c_str());
        records[w[0]] = r;
    }
}
void Juego::guardar_records() const {
    std::string s;
    for (auto& kv : records)
        s += fmt("%s %.1f %d %d %d\n", kv.first.c_str(), kv.second.mejor, kv.second.estrellas, kv.second.intentos, kv.second.completos);
    aus::escribir(dir + "/records.txt", s);
}

// ====================================================================== jugar
bool Juego::empezar(const std::string& id, std::string& msg, bool forzar) {
    Escenario* e = buscar(id);
    if (!e) {
        msg = "no existe ese escenario (austero escenario lista)";
        return false;
    }
    if (e->tareas.empty()) {
        msg = "ese escenario no tiene tareas: grabalo con 'austero escenario grabar " + e->id + "'";
        return false;
    }
    if (bloqueado(*e) && !forzar) {
        msg = "bloqueado: primero completa el escenario anterior (o: austero escenario jugar " + e->id + " forzar)";
        return false;
    }
    esc = e;
    jugando = true;
    pausado = fin = en_error = confirmado = false;
    k = errores = faltas = 0;
    invadidas.clear();
    t0 = t_tarea = t_quieto0 = aus::ahora();
    t_bien = t_fin = -10;
    records[e->id].intentos++;
    guardar_records();
    msg = fmt("jugando '%s': %d tareas", e->nombre.c_str(), (int)e->tareas.size());
    return true;
}

void Juego::parar(const std::string& porque) {
    if (jugando && !porque.empty()) avisos.push_back(porque);
    jugando = false;
}

void Juego::saltar(int d) {
    if (!jugando || fin || !esc) return;
    k = std::max(0, std::min((int)esc->tareas.size() - 1, k + d));
    t_tarea = aus::ahora();
    en_error = confirmado = false;
}

void Juego::pausa(bool p) {
    double t = aus::ahora();
    if (p && !pausado) t_pausa = t;
    if (!p && pausado) {
        double dt = t - t_pausa;
        t0 += dt;
        t_tarea += dt;
    }
    pausado = p;
}

bool Juego::evaluar(const std::vector<PiezaP>& ps, bool quieto, double t) {
    if (!jugando || !esc) return false;
    if (fin) {
        if (t - t_fin > 10) jugando = false;
        return false;
    }
    if (pausado) return false;
    ult = ps;
    const Tarea& ta = esc->tareas[k];
    hecho_cond.assign(ta.pasa.size(), false);
    bool todas = true, hay_error = false;
    std::string m_err, z_err;
    bool manos = false;
    for (auto& p : ps)
        if (p.tipo == "mano") manos = true;
    auto dentro = [&](const PiezaP& p, const std::vector<std::string>& zs) {
        if (zs.empty()) return true;
        for (auto& z : zs) {
            const cv::Rect* r = esc->zona(z);
            if (r && r->contains(cv::Point((int)p.centro.x, (int)p.centro.y))) return true;
        }
        return false;
    };
    for (size_t i = 0; i < ta.pasa.size(); i++) {
        const Cond& c = ta.pasa[i];
        bool ok = false;
        if (c.tipo == "pieza") {
            for (auto& p : ps)
                if (p.tipo != "mano" && coincide(p, c.pieza) && dentro(p, c.zonas)) ok = true;
            if (!ok)
                for (auto& p : ps)
                    if (p.tipo != "mano" && !c.zonas.empty() && dentro(p, c.zonas)) {
                        hay_error = true;
                        m_err = "Esa no es la " + c.pieza + ": es " + (p.tipo == "objeto" ? std::string("otra pieza") : p.tipo);
                        z_err = c.zonas[0];
                    }
        } else if (c.tipo == "vacio") {
            ok = true;
            for (auto& p : ps)
                if (p.tipo != "mano" && dentro(p, c.zonas)) ok = false;
        } else if (c.tipo == "conteo") {
            int n = 0;
            for (auto& p : ps)
                if (p.tipo != "mano" && coincide(p, c.pieza) && dentro(p, c.zonas)) n++;
            ok = n == (int)c.n;
        } else if (c.tipo == "espera") ok = t - t_tarea >= c.n;
        else if (c.tipo == "confirmar") ok = confirmado;
        hecho_cond[i] = ok;
        todas = todas && ok;
    }
    // ---- zonas prohibidas: la mano no entra / no cruza la linea
    std::vector<std::string> inv;
    for (auto& pr : esc->prohibidas)
        for (auto& p : ps) {
            if (p.tipo != "mano" || p.poli.empty()) continue;
            bool toca = false;
            if (!pr.linea) {
                for (auto& q : p.poli)
                    if (pr.r.contains(q)) toca = true;
                if (!toca && cv::pointPolygonTest(p.poli, (pr.r.tl() + pr.r.br()) * 0.5, false) >= 0) toca = true;
            } else {
                auto cruza = [](cv::Point2f a, cv::Point2f b, cv::Point2f c, cv::Point2f d) {
                    auto cr = [](cv::Point2f o, cv::Point2f u, cv::Point2f v) { return (u - o).cross(v - o); };
                    return cr(a, b, c) * cr(a, b, d) < 0 && cr(c, d, a) * cr(c, d, b) < 0;
                };
                size_t n = p.poli.size();
                for (size_t i = 0; i < n && !toca; i++) toca = cruza(pr.a, pr.b, p.poli[i], p.poli[(i + 1) % n]);
                if (!toca) toca = cv::pointPolygonTest(p.poli, pr.a, false) >= 0 || cv::pointPolygonTest(p.poli, pr.b, false) >= 0;
            }
            if (toca) {
                inv.push_back(pr.nombre);
                break;
            }
        }
    for (auto& z : inv)
        if (std::find(invadidas.begin(), invadidas.end(), z) == invadidas.end()) {
            faltas++;
            t_falta = t;
            avisos.push_back("FALTA: mano en zona prohibida '" + z + "'");
        }
    invadidas = inv;
    bool calma = quieto && !manos;
    if (!calma) t_quieto0 = t;
    bool estable = calma && t - t_quieto0 >= quieto_s;
    // error: otra pieza se quedo en el lugar
    if (hay_error && estable) {
        if (!en_error) {
            errores++;
            avisos.push_back("error en '" + ta.nombre + "': " + m_err);
        }
        en_error = true;
        msg_error = m_err;
        zona_error = z_err;
    } else if (!hay_error) en_error = false;
    // paso la tarea
    if (!invadidas.empty()) return false;   // con una mano en zona prohibida nada avanza
    if (todas && (estable || ta.pasa.empty() == false && std::all_of(ta.pasa.begin(), ta.pasa.end(), [](const Cond& c) {
                      return c.tipo == "confirmar" || c.tipo == "espera";
                  }))) {
        t_bien = t;
        avisos.push_back(fmt("tarea %d/%d lista: %s (%.0f s)", k + 1, (int)esc->tareas.size(), ta.nombre.c_str(), t - t_tarea));
        k++;
        t_tarea = t;
        confirmado = en_error = false;
        if (k >= (int)esc->tareas.size()) {
            k = (int)esc->tareas.size() - 1;
            fin = true;
            t_fin = t;
            tiempo_fin = t - t0;
            int n = (int)esc->tareas.size();
            double e3 = esc->estrellas3 > 0 ? esc->estrellas3 : 25.0 * n, e2 = esc->estrellas2 > 0 ? esc->estrellas2 : 45.0 * n;
            int mal = errores + faltas;
            estrellas_fin = (tiempo_fin <= e3 && mal == 0) ? 3 : (tiempo_fin <= e2 && mal <= 1) ? 2 : 1;
            Record& r = records[esc->id];
            record_nuevo = r.completos == 0 || tiempo_fin < r.mejor;
            if (record_nuevo) r.mejor = tiempo_fin;
            r.estrellas = std::max(r.estrellas, estrellas_fin);
            r.completos++;
            guardar_records();
            {
                std::string h;
                for (auto& l : aus::lineas(dir + "/historial.txt")) h += l + "\n";
                h += fmt("%s|%s|%.1f|%d|%d|%d\n", aus::fecha().c_str(), esc->id.c_str(), tiempo_fin, estrellas_fin, errores, faltas);
                aus::escribir(dir + "/historial.txt", h);
            }
            avisos.push_back(fmt("ESCENARIO COMPLETO '%s': %d:%02d, %d estrellas, %d errores%s", esc->nombre.c_str(), (int)tiempo_fin / 60,
                                 (int)tiempo_fin % 60, estrellas_fin, errores, record_nuevo ? " (nuevo record)" : ""));
        }
        return true;
    }
    return false;
}

std::string Juego::firma(double t) const {
    if (!jugando || !esc) return "";
    std::string f = fmt("J%s|%d|%d|%d|%d|%d|%d|", esc->id.c_str(), k, (int)en_error, (int)fin, (int)pausado, (int)(t - t_bien < 1.2),
                        invadidas.empty() ? 0 : 1 + (int)(std::fmod(t, 0.8) < 0.4));   // parpadea mientras haya mano
    for (bool b : hecho_cond) f += b ? '1' : '0';
    if (!fin) f += fmt("|%d", (int)((t - t0) / 5));   // el reloj se redibuja cada 5 s (el proyector no parpadea)
    return f;
}

std::string Juego::estado() const {
    std::string s;
    if (grabando) s += "escenario_grabando=" + grab_id + "\n";
    if (!jugando || !esc) return s;
    double t = aus::ahora();
    const Tarea& ta = esc->tareas[k];
    s += fmt("escenario=%s\nescenario_tarea=%d/%d %s\nescenario_tiempo=%.0f\nescenario_errores=%d\n", esc->nombre.c_str(), k + 1,
             (int)esc->tareas.size(), ta.nombre.c_str(), fin ? tiempo_fin : (pausado ? t_pausa : t) - t0, errores);
    if (en_error) s += "escenario_error=" + msg_error + "\n";
    if (faltas) s += fmt("escenario_faltas=%d\n", faltas);
    for (auto& z : invadidas) s += "escenario_prohibida=" + z + "\n";
    if (fin) s += fmt("escenario_fin=%d estrellas\n", estrellas_fin);
    s += fmt("escenario_id=%s\nescenario_k=%d\nescenario_n=%d\nescenario_pausa=%d\n", esc->id.c_str(), k, (int)esc->tareas.size(), (int)pausado);
    return s;
}

// ====================================================================== dibujar (proyector)
static void punteada(cv::Mat& l, const std::vector<cv::Point>& p, const cv::Scalar& col, int g, bool cerrada = true) {
    size_t n = p.size();
    for (size_t i = 0; i < (cerrada ? n : n - 1); i++) {
        cv::Point2f a = p[i], b = p[(i + 1) % n];
        double L = cv::norm(b - a);
        for (double s = 0; s < L; s += 18) {
            double e = std::min(L, s + 10);
            cv::line(l, a + (b - a) * (float)(s / L), a + (b - a) * (float)(e / L), col, g, cv::LINE_AA);
        }
    }
}
static void estrella(cv::Mat& l, cv::Point c, int r, bool llena, const cv::Scalar& col) {
    std::vector<cv::Point> p;
    for (int i = 0; i < 10; i++) {
        double a = -CV_PI / 2 + i * CV_PI / 5, rr = i % 2 ? r * 0.45 : r;
        p.push_back(c + cv::Point((int)(rr * std::cos(a)), (int)(rr * std::sin(a))));
    }
    if (llena) cv::fillPoly(l, std::vector<std::vector<cv::Point>>{p}, col, cv::LINE_AA);
    else cv::polylines(l, std::vector<std::vector<cv::Point>>{p}, true, col, 2, cv::LINE_AA);
}
static void texto(cv::Mat& l, const std::string& s, cv::Point p, double esc, const cv::Scalar& col, int g = 2) {
    cv::putText(l, sin_acentos(s), p, cv::FONT_HERSHEY_DUPLEX, esc, col, g, cv::LINE_AA);
}
// parte un texto en lineas que quepan en 'ancho'
static std::vector<std::string> envolver(const std::string& s, double esc, int ancho) {
    std::vector<std::string> r;
    std::string l;
    for (auto& w : palabras(sin_acentos(s))) {
        std::string c = l.empty() ? w : l + " " + w;
        int bl;
        if (cv::getTextSize(c, cv::FONT_HERSHEY_DUPLEX, esc, 2, &bl).width > ancho && !l.empty()) {
            r.push_back(l);
            l = w;
        } else l = c;
    }
    if (!l.empty()) r.push_back(l);
    return r;
}
// silueta agrandada un margen: la luz cae ALREDEDOR de la pieza, no encima (no estorba a la camara)
static std::vector<cv::Point> agrandar(const std::vector<cv::Point>& p, int m, cv::Size tam) {
    if (p.size() < 3) return p;
    cv::Rect r = cv::boundingRect(p);
    cv::Mat k = cv::Mat::zeros(r.height + 4 * m, r.width + 4 * m, CV_8U);
    std::vector<cv::Point> q;
    for (auto& x : p) q.push_back(x - r.tl() + cv::Point(2 * m, 2 * m));
    cv::fillPoly(k, std::vector<std::vector<cv::Point>>{q}, cv::Scalar(255));
    cv::dilate(k, k, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(2 * m + 1, 2 * m + 1)));
    std::vector<std::vector<cv::Point>> cs;
    cv::findContours(k, cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    if (cs.empty()) return p;
    std::vector<cv::Point> o;
    cv::approxPolyDP(cs[0], o, 2, true);
    for (auto& x : o) x += r.tl() - cv::Point(2 * m, 2 * m);
    (void)tam;
    return o;
}

void Juego::dibujar(cv::Mat& l, double t) const {
    if (!jugando || !esc) return;
    const cv::Scalar BL(255, 255, 255), CY(255, 230, 0), VE(80, 255, 80), RO(60, 60, 255), GR(130, 130, 130), AM(0, 210, 255);
    int W = l.cols, H = l.rows, n = (int)esc->tareas.size();
    // ---- banda de arriba: nivel, camino de tareas, reloj y estrellas
    texto(l, esc->nombre, cv::Point(20, 38), 0.85, BL);
    int x0 = std::min(W / 2 - 40, 30 + cv::getTextSize(sin_acentos(esc->nombre), cv::FONT_HERSHEY_DUPLEX, 0.85, 2, nullptr).width + 30);
    int sw = std::max(30, std::min(90, (W - x0 - 260) / std::max(1, n) - 8));
    for (int i = 0; i < n; i++) {
        cv::Rect s(x0 + i * (sw + 8), 20, sw, 18);
        if (i < k || fin) cv::rectangle(l, s, VE, cv::FILLED);
        else if (i == k) cv::rectangle(l, s, CY, 3);
        else cv::rectangle(l, s, GR, 1);
    }
    texto(l, fmt("TAREA %d/%d", k + 1, n), cv::Point(x0, 64), 0.6, BL, 1);
    double tt = fin ? tiempo_fin : (pausado ? t_pausa : t) - t0;
    if (!fin) tt = std::floor(tt / 5) * 5;
    const Tarea& ta = esc->tareas[k];
    bool tarde = ta.tiempo_max > 0 && !fin && (t - t_tarea) > ta.tiempo_max;
    texto(l, fmt("%d:%02d", (int)tt / 60, (int)tt % 60), cv::Point(W - 210, 42), 1.0, tarde ? RO : BL);
    if (errores || faltas) texto(l, fmt("errores %d  faltas %d", errores, faltas), cv::Point(W - 210, 66), 0.55, RO, 1);
    cv::line(l, cv::Point(0, 78), cv::Point(W, 78), GR, 1);

    // ---- zonas
    std::vector<std::string> activas;
    for (size_t i = 0; i < ta.pasa.size(); i++)
        for (auto& z : ta.pasa[i].zonas) activas.push_back(z);
    for (auto& z : esc->zonas) {
        bool act = std::find(activas.begin(), activas.end(), z.first) != activas.end();
        bool ok = false;
        for (size_t i = 0; i < ta.pasa.size() && i < hecho_cond.size(); i++)
            if (hecho_cond[i] && std::find(ta.pasa[i].zonas.begin(), ta.pasa[i].zonas.end(), z.first) != ta.pasa[i].zonas.end()) ok = true;
        cv::Scalar col = en_error && z.first == zona_error ? RO : ok ? VE : act ? CY : GR;
        int g = en_error && z.first == zona_error ? 6 : act ? 3 : 1;
        cv::rectangle(l, z.second, col, g);
        texto(l, z.first, z.second.tl() + cv::Point(6, 24), 0.7, col, act ? 2 : 1);
    }
    // ---- zonas prohibidas: rayadas; en rojo parpadeando si hay una mano
    for (auto& pr : esc->prohibidas) {
        bool hay = std::find(invadidas.begin(), invadidas.end(), pr.nombre) != invadidas.end();
        bool on = !hay || std::fmod(t, 0.8) < 0.4;
        cv::Scalar col = hay ? RO : cv::Scalar(40, 40, 200);
        if (!on) continue;
        if (pr.linea) {
            cv::line(l, pr.a, pr.b, col, hay ? 9 : 5, cv::LINE_AA);
            cv::Point2f d = pr.b - pr.a;
            double L = std::max(1.0, cv::norm(d));
            cv::Point2f nn(-d.y / (float)L, d.x / (float)L);
            for (double s2 = 0; s2 < L; s2 += 26) {
                cv::Point2f q = cv::Point2f(pr.a) + d * (float)(s2 / L);
                cv::line(l, q - nn * 10.f, q + nn * 10.f, col, 2, cv::LINE_AA);
            }
            texto(l, "NO CRUZAR", (pr.a + pr.b) / 2 + cv::Point(10, -14), 0.6, col, 1);
        } else {
            // solo contorno y esquinas (un rayado encima taparia la mano a la camara)
            cv::rectangle(l, pr.r, col, hay ? 7 : 2);
            int e = std::min(40, std::min(pr.r.width, pr.r.height) / 3);
            for (auto c : {pr.r.tl(), cv::Point(pr.r.br().x, pr.r.y), pr.r.br(), cv::Point(pr.r.x, pr.r.br().y)}) {
                int sx = c.x == pr.r.x ? 1 : -1, sy = c.y == pr.r.y ? 1 : -1;
                cv::line(l, c, c + cv::Point(sx * e, sy * e), col, 3, cv::LINE_AA);
            }
            texto(l, "PROHIBIDO: " + pr.nombre, pr.r.tl() + cv::Point(6, 22), 0.6, col, 1);
        }
    }
    // ---- siluetas: las de tareas pasadas en verde, la actual punteada
    for (int i = 0; i <= k && i < n; i++) {
        const Tarea& x = esc->tareas[i];
        if (x.silueta.size() < 3) continue;
        auto s = agrandar(x.silueta, 10, l.size());
        if (i < k || fin) cv::polylines(l, std::vector<std::vector<cv::Point>>{s}, true, VE, 2, cv::LINE_AA);
        else punteada(l, s, en_error ? RO : CY, 3);
    }
    // ---- instruccion (abajo)
    if (!fin) {
        cv::line(l, cv::Point(0, H - 110), cv::Point(W, H - 110), GR, 1);
        std::string ins = ta.instruccion.empty() ? ta.nombre : ta.instruccion;
        auto ls = envolver(ins, 1.1, W - 60);
        for (size_t i = 0; i < ls.size() && i < 2; i++) texto(l, ls[i], cv::Point(30, H - 66 + (int)i * 44), 1.1, AM);
        if (!invadidas.empty()) texto(l, "RETIRA LA MANO: zona prohibida (" + invadidas[0] + ")", cv::Point(30, H - 124), 0.95, RO);
        else if (en_error) texto(l, msg_error, cv::Point(30, H - 124), 0.9, RO);
        else {
            std::string falta;
            for (size_t i = 0; i < ta.pasa.size() && i < hecho_cond.size(); i++)
                if (ta.pasa[i].tipo == "confirmar" && !hecho_cond[i]) falta = "cuando termines: austero escenario ok";
            if (!falta.empty()) texto(l, falta, cv::Point(30, H - 124), 0.6, GR, 1);
        }
    }
    if (pausado) texto(l, "PAUSA", cv::Point(W / 2 - 90, H / 2), 2.0, AM, 4);
    // ---- "bien" al pasar una tarea
    if (!fin && t - t_bien < 1.2) texto(l, "BIEN", cv::Point(W / 2 - 80, H / 2 + 20), 2.2, VE, 5);
    // ---- fin del nivel
    if (fin) {
        cv::Rect c(W / 2 - 330, H / 2 - 150, 660, 300);
        cv::rectangle(l, c, cv::Scalar(0, 0, 0), cv::FILLED);
        cv::rectangle(l, c, VE, 4);
        texto(l, "ESCENARIO COMPLETO", c.tl() + cv::Point(80, 70), 1.3, VE, 3);
        for (int i = 0; i < 3; i++) estrella(l, c.tl() + cv::Point(230 + i * 100, 140), 38, i < estrellas_fin, AM);
        texto(l, fmt("tiempo %d:%02d   errores %d   faltas %d", (int)tiempo_fin / 60, (int)tiempo_fin % 60, errores, faltas), c.tl() + cv::Point(90, 230), 0.9, BL);
        if (record_nuevo) texto(l, "NUEVO RECORD", c.tl() + cv::Point(230, 275), 0.9, AM);
    }
}

// ====================================================================== grabar haciendo
void Juego::grabar_empezar(Escenario& e, const std::vector<PiezaP>& ps) {
    grabando = true;
    grab_id = e.id;
    grab_base.clear();
    for (auto& p : ps)
        if (p.tipo != "mano") grab_base.push_back(p);
    grab_mov = false;
    t_quieto0 = aus::ahora();
}

bool Juego::grabar_evaluar(const std::vector<PiezaP>& ps, bool quieto, double t, std::string& aviso) {
    if (!grabando) return false;
    Escenario* e = buscar(grab_id);
    if (!e) {
        grabando = false;
        return false;
    }
    bool manos = false;
    for (auto& p : ps)
        if (p.tipo == "mano") manos = true;
    if (!quieto || manos) {
        t_quieto0 = t;
        grab_cand.clear();
        return false;
    }
    if (t - t_quieto0 < quieto_s) return false;
    // piezas NUEVAS respecto a lo ya grabado
    std::vector<PiezaP> nuevas;
    for (auto& p : ps) {
        if (p.tipo == "mano") continue;
        bool ya = false;
        for (auto& b : grab_base)
            if (cv::norm(b.centro - p.centro) < 40) ya = true;
        if (!ya) nuevas.push_back(p);
    }
    if (nuevas.empty()) {
        grab_cand.clear();
        return false;
    }
    // la pieza nueva debe verse igual dos revisiones seguidas (que no sea un parpadeo de la deteccion)
    bool igual = grab_cand.size() == nuevas.size();
    for (size_t i = 0; igual && i < nuevas.size(); i++) {
        bool hay = false;
        for (auto& c : grab_cand)
            if (cv::norm(c.centro - nuevas[i].centro) < 20 && c.tipo == nuevas[i].tipo) hay = true;
        igual = hay;
    }
    if (!igual) {
        grab_cand = nuevas;
        grab_t_cand = t;
        return false;
    }
    if (t - grab_t_cand < 1.2) return false;
    grab_cand.clear();
    for (auto& p : nuevas) grab_base.push_back(p);
    if (nuevas.empty()) return false;
    for (auto& p : nuevas) {
        std::string z = fmt("L%d", (int)e->zonas.size() + 1);
        cv::Rect r = cv::boundingRect(p.poli);
        r.x -= 30, r.y -= 30, r.width += 60, r.height += 60;
        e->zonas.push_back({z, r});
        Tarea ta;
        std::string tp = p.tipo == "objeto" ? std::string("pieza") : p.tipo;
        ta.nombre = "Coloca " + tp + " en " + z;
        ta.instruccion = "Coloca la " + tp + " sobre su silueta (" + z + ")";
        Cond c;
        c.tipo = "pieza";
        c.pieza = p.tipo;
        c.zonas = {z};
        ta.pasa.push_back(c);
        ta.silueta_tipo = p.tipo;
        cv::approxPolyDP(p.poli, ta.silueta, 2.5, true);
        e->tareas.push_back(ta);
        aviso += (aviso.empty() ? "" : "; ") + fmt("tarea %d grabada: %s en %s", (int)e->tareas.size(), tp.c_str(), z.c_str());
    }
    guardar(*e);
    return true;
}

std::string Juego::grabar_terminar() {
    if (!grabando) return "no estaba grabando";
    grabando = false;
    Escenario* e = buscar(grab_id);
    if (!e) return "escenario perdido";
    // tarea FINAL: revisar que todo siga en su lugar
    std::vector<Cond> todo;
    for (auto& t : e->tareas)
        for (auto& c : t.pasa)
            if (c.tipo == "pieza") todo.push_back(c);
    if (todo.size() >= 2) {
        Tarea f;
        f.nombre = "FINAL: revisar la charola";
        f.instruccion = "Revisa: cada pieza en su lugar y quita las manos";
        f.pasa = todo;
        e->tareas.push_back(f);
    }
    guardar(*e);
    std::string id = e->id;
    int n = (int)e->tareas.size();
    cargar(dir);
    return fmt("grabacion lista: '%s' con %d tareas (escenarios/%s.esc). Para jugarlo: austero escenario jugar %s", id.c_str(), n, id.c_str(),
               id.c_str());
}

// ====================================================================== para la pagina web
static std::string jesc(const std::string& s) {
    std::string r;
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') r += '\\', r += (char)c;
        else if (c == '\n') r += "\\n";
        else if (c < 0x20) r += ' ';
        else r += (char)c;
    }
    return r;
}

std::string Juego::json(const Escenario& e) const {
    std::string j = "{\"id\":\"" + jesc(e.id) + "\",\"nombre\":\"" + jesc(e.nombre) + "\"" + fmt(",\"orden\":%d,\"estrellas\":[%g,%g]", e.orden, e.estrellas3, e.estrellas2);
    j += fmt(",\"bloqueado\":%s", bloqueado(e) ? "true" : "false");
    j += ",\"zonas\":[";
    for (size_t i = 0; i < e.zonas.size(); i++)
        j += fmt("%s{\"n\":\"%s\",\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d}", i ? "," : "", jesc(e.zonas[i].first).c_str(), e.zonas[i].second.x,
                 e.zonas[i].second.y, e.zonas[i].second.width, e.zonas[i].second.height);
    j += "],\"prohibidas\":[";
    for (size_t i = 0; i < e.prohibidas.size(); i++) {
        auto& p = e.prohibidas[i];
        if (p.linea) j += fmt("%s{\"n\":\"%s\",\"linea\":true,\"x1\":%d,\"y1\":%d,\"x2\":%d,\"y2\":%d}", i ? "," : "", jesc(p.nombre).c_str(), p.a.x, p.a.y, p.b.x, p.b.y);
        else j += fmt("%s{\"n\":\"%s\",\"linea\":false,\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d}", i ? "," : "", jesc(p.nombre).c_str(), p.r.x, p.r.y, p.r.width, p.r.height);
    }
    j += "],\"tareas\":[";
    for (size_t i = 0; i < e.tareas.size(); i++) {
        auto& t = e.tareas[i];
        j += std::string(i ? "," : "") + "{\"nombre\":\"" + jesc(t.nombre) + "\",\"instruccion\":\"" + jesc(t.instruccion) + "\"" + fmt(",\"tiempo\":%g,\"pasa\":[", t.tiempo_max);
        for (size_t c = 0; c < t.pasa.size(); c++) {
            auto& q = t.pasa[c];
            j += std::string(c ? "," : "") + "{\"tipo\":\"" + q.tipo + "\",\"pieza\":\"" + jesc(q.pieza) + "\"" + fmt(",\"n\":%g,\"zonas\":[", q.n);
            for (size_t z = 0; z < q.zonas.size(); z++) j += std::string(z ? "," : "") + "\"" + jesc(q.zonas[z]) + "\"";
            j += "]}";
        }
        j += "],\"silueta\":{\"tipo\":\"" + jesc(t.silueta_tipo) + "\",\"pts\":[";
        for (size_t k2 = 0; k2 < t.silueta.size(); k2++) j += fmt("%s[%d,%d]", k2 ? "," : "", t.silueta[k2].x, t.silueta[k2].y);
        j += "]}}";
    }
    return j + "]}";
}

std::string Juego::json_lista() const {
    std::string j = "[";
    for (size_t i = 0; i < lista.size(); i++) {
        auto& e = lista[i];
        Record r;
        auto it = records.find(e.id);
        if (it != records.end()) r = it->second;
        j += std::string(i ? "," : "") + "{\"id\":\"" + jesc(e.id) + "\",\"nombre\":\"" + jesc(e.nombre) + "\"" +
             fmt(",\"orden\":%d,\"tareas\":%d,\"zonas\":%d,\"prohibidas\":%d,\"bloqueado\":%s,\"mejor\":%.1f,\"estrellas\":%d,\"intentos\":%d,\"completos\":%d",
                 e.orden, (int)e.tareas.size(), (int)e.zonas.size(), (int)e.prohibidas.size(), bloqueado(e) ? "true" : "false", r.mejor,
                 r.estrellas, r.intentos, r.completos) +
             ",\"nombres\":[";
        for (size_t t = 0; t < e.tareas.size(); t++) j += std::string(t ? "," : "") + "\"" + jesc(e.tareas[t].nombre) + "\"";
        j += "]}";
    }
    return j + "]";
}

std::string Juego::json_juego() const {
    if (!jugando || !esc) return "{\"activo\":false}";
    double t = aus::ahora();
    std::string j = fmt("{\"activo\":true,\"id\":\"%s\",\"k\":%d,\"n\":%d,\"fin\":%s,\"pausa\":%s,\"error\":%s,\"errores\":%d,\"faltas\":%d,\"tiempo\":%.1f,\"estrellas\":%d,\"hecho\":[",
                        jesc(esc->id).c_str(), k, (int)esc->tareas.size(), fin ? "true" : "false", pausado ? "true" : "false",
                        en_error ? "true" : "false", errores, faltas, fin ? tiempo_fin : (pausado ? t_pausa : t) - t0, fin ? estrellas_fin : 0);
    for (size_t i = 0; i < hecho_cond.size(); i++) j += std::string(i ? "," : "") + (hecho_cond[i] ? "true" : "false");
    j += "],\"invadidas\":[";
    for (size_t i = 0; i < invadidas.size(); i++) j += std::string(i ? "," : "") + "\"" + jesc(invadidas[i]) + "\"";
    return j + "],\"msg\":\"" + jesc(en_error ? msg_error : "") + "\"}";
}

bool Juego::escribir(const std::string& id, const std::string& texto, int W, int H, std::string& msg) {
    if (id.empty() || id.size() > 60 || id != aus::slug(id)) {
        msg = "nombre de archivo no valido (solo letras, numeros y _)";
        return false;
    }
    if (texto.size() > 200000) {
        msg = "escenario demasiado grande";
        return false;
    }
    std::string tmp = dir + "/." + id + ".tmp";
    aus::crear_dirs(dir);
    if (!aus::escribir(tmp, texto)) {
        msg = "no pude escribir en " + dir;
        return false;
    }
    Escenario e = leer(tmp);
    std::remove(tmp.c_str());
    e.id = id;
    e.archivo = dir + "/" + id + ".esc";
    if (e.nombre.empty() || e.nombre == "." + id) e.nombre = id;
    // todo dentro del lienzo del proyector
    auto rec = [&](cv::Rect& r) {
        r.width = std::max(20, std::min(W, r.width));
        r.height = std::max(20, std::min(H, r.height));
        r.x = std::max(0, std::min(W - r.width, r.x));
        r.y = std::max(0, std::min(H - r.height, r.y));
    };
    auto pto = [&](cv::Point& p) {
        p.x = std::max(0, std::min(W - 1, p.x));
        p.y = std::max(0, std::min(H - 1, p.y));
    };
    for (auto& z : e.zonas) rec(z.second);
    for (auto& p : e.prohibidas) {
        if (p.linea) pto(p.a), pto(p.b);
        else rec(p.r);
    }
    for (size_t i = 0; i < e.tareas.size(); i++) {
        Tarea& t = e.tareas[i];
        if (t.nombre.empty()) t.nombre = fmt("Tarea %d", (int)i + 1);
        for (auto& p : t.silueta) pto(p);
        for (auto& c : t.pasa)
            for (auto& z : c.zonas)
                if (!e.zona(z)) {
                    msg = "la tarea '" + t.nombre + "' usa la zona '" + z + "', que no existe";
                    return false;
                }
    }
    if (!guardar(e)) {
        msg = "no pude guardar";
        return false;
    }
    cargar(dir);
    msg = fmt("guardado escenarios/%s.esc (%d tareas)", id.c_str(), (int)e.tareas.size());
    return true;
}

bool Juego::borrar(const std::string& id, std::string& msg) {
    Escenario* e = buscar(id);
    if (!e) {
        msg = "no existe";
        return false;
    }
    if (jugando && esc == e) jugando = false;
    std::string a = e->archivo;
    if (std::rename(a.c_str(), (a + ".borrado").c_str()) != 0) {
        msg = "no pude borrar";
        return false;
    }
    msg = "borrado (queda una copia: " + e->id + ".esc.borrado)";
    esc = nullptr;
    jugando = false;
    cargar(dir);
    return true;
}

bool Juego::duplicar(const std::string& id, const std::string& nombre, std::string& msg) {
    Escenario* e = buscar(id);
    if (!e) {
        msg = "no existe";
        return false;
    }
    Escenario c = *e;
    Escenario& n = nuevo(nombre.empty() ? c.nombre + " copia" : nombre);
    c.id = n.id, c.archivo = n.archivo, c.nombre = n.nombre, c.orden = n.orden;
    guardar(c);
    std::string nid = c.id;
    cargar(dir);
    msg = "duplicado como " + nid;
    return true;
}

std::string Juego::historial(int n) const {
    auto ls = aus::lineas(dir + "/historial.txt");
    std::string r;
    for (size_t i = ls.size() > (size_t)n ? ls.size() - n : 0; i < ls.size(); i++) r += ls[i] + "\n";
    return r;
}

}  // namespace quest
