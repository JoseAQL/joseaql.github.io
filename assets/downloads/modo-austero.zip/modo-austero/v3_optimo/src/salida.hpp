// salida.hpp - lo que sale por el proyector.
//   fb   escribe directo al framebuffer /dev/fb0 (sin escritorio, sin X: casi cero recursos)
//   x    ventana a pantalla completa (si hay escritorio); va en libaustero_ventana.so y solo se carga si la usas
//   sim  solo en memoria (para la camara simulada)
//   auto fb si no hay escritorio, x si lo hay
// Se dibuja en un "lienzo" chico (salida.ancho x salida.alto, p. ej. 1280x720) y solo cuando algo cambia.
#pragma once

#include <string>

#include <opencv2/core.hpp>

#include "base.hpp"

class Salida {
public:
    ~Salida();
    bool abrir(const aus::Conf& c);
    void cerrar();
    void mostrar(const cv::Mat& lienzo);   // BGR o gris, tamano w x h
    void eventos();                        // solo X: atender la ventana (barato)
    cv::Mat actual() const { return ultimo_; }
    bool abierta() const { return abierta_; }

    int w = 1280, h = 720;
    std::string tipo;

private:
    bool abierta_ = false;
    cv::Mat ultimo_;
    // framebuffer
    int fb_ = -1, tty_ = -1;
    unsigned char* mem_ = nullptr;
    size_t largo_ = 0;
    int fw_ = 0, fh_ = 0, bpp_ = 0, linea_ = 0, roff_ = 16, goff_ = 8, boff_ = 0;
    bool abrir_fb(const std::string& dev);
    void escribir_fb(const cv::Mat& bgr);
    double t_ev_ = 0;
    // ventana X (complemento)
    void* so_ = nullptr;
    void (*v_mostrar_)(const cv::Mat*) = nullptr;
    void (*v_eventos_)() = nullptr;
    void (*v_cerrar_)() = nullptr;
    bool abrir_ventana(const aus::Conf& c);
};
