// filtros.hpp - Laboratorio: filtros de imagen y kernels que se ajustan en vivo (terminal o web).
//
// Cadena (solo lo que no este en neutro gasta CPU):
//   camara -> gamma -> CLAHE -> suavizado (gauss | mediana | bilateral, kernel k) -> nitidez
//          -> kernel de convolucion (enfocar, relieve, laplaciano, sobel x/y o el tuyo en perfiles/kernel.txt)
//          = "lo que ve la red"  (entra a todos los modelos)
//   mascara: resta contra el fondo (umbral) -> morfologia (abrir, cerrar, dilatar, erosionar, gradiente;
//            kernel rect/elipse/cruz de tamano k) -> piezas de area >= area_min
//   bordes:  Canny (bajo/alto) + esquinas (Shi-Tomasi)
// Todo se guarda en perfiles/filtros.conf.
#pragma once

#include <string>
#include <vector>

#include <opencv2/core.hpp>

struct Param {
    std::string nombre;
    double valor, def, min, max, paso;
    std::string desc;   // con opciones: "0 nada | 1 gauss | ..."
};

class Filtros {
public:
    Filtros();
    void cargar();
    void guardar() const;
    void reset();
    bool poner(const std::string& k, const std::string& v);   // v: numero, "+" o "-" (un paso)
    double v(const std::string& k) const;
    int i(const std::string& k) const { return (int)(v(k) + 0.5); }
    std::string lista() const;   // "nombre|valor|min|max|paso|descripcion" por linea
    bool neutro() const;         // nada que hacer sobre la imagen
    cv::Mat aplicar(const cv::Mat& bgr) const;   // devuelve la misma Mat si todo esta en neutro
    void morfologia(cv::Mat& mascara) const;
    cv::Mat mascara(const cv::Mat& bgr_filtrada, const cv::Mat& fondo_filtrado, const cv::Mat& ignorar) const;
    cv::Mat bordes(const cv::Mat& bgr_filtrada, int* n_esquinas = nullptr) const;   // BGR para ver
    std::vector<Param> p;

private:
    Param* buscar(const std::string& k);
    const Param* buscar(const std::string& k) const;
    mutable cv::Mat lut_;
    mutable double lut_g_ = -1;
    mutable cv::Mat kernel_propio_;
    mutable double kernel_t_ = -1;
};

extern Filtros* g_filtros;   // lo usan segmentar_fondo y la memoria (morfologia y umbral comunes)
