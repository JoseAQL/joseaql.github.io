#include "modelos.hpp"
#include "formas.hpp"

#include <dlfcn.h>

#include <cmath>

#include <opencv2/imgproc.hpp>

#include "filtros.hpp"
#include "memoria.hpp"

using aus::fmt;
using aus::log;

std::string Modelo::params_texto() const {
    std::string t;
    for (auto& kv : p) t += (t.empty() ? "" : " ") + kv.first + "=" + fmt("%g", kv.second);
    return t;
}

// ====================================================================== modelos del nucleo (CPU)
class Fondo : public Modelo {
public:
    explicit Fondo(Contexto& c) : Modelo(c) {}   // umbral, area y morfologia: los del laboratorio (austero filtro)
    std::string id() const override { return "fondo"; }
    std::string nombre() const override { return "Resta de fondo (OpenCV)"; }
    std::string licencia() const override { return "propio"; }
    std::vector<Det> procesar(const cv::Mat& img) override {
        std::vector<Det> r;
        // con "formas" (laboratorio) cada pieza sale con su nombre: tijera, bisturi, pinza, mano
        if (g_filtros && g_filtros->v("formas") > 0.5) return aplicar_formas(img, ctx, nullptr);
        for (auto& c : segmentar_fondo(img, ctx.fondo, g_filtros->v("mascara_dif"), g_filtros->v("mascara_area"), ctx.mascara)) {
            Det d;
            d.clase = "objeto";
            d.caja = cv::boundingRect(c);
            d.contorno = c;
            cv::RotatedRect rr = cv::minAreaRect(c);
            d.angulo = (float)std::fmod(rr.angle + (rr.size.width < rr.size.height ? 90 : 0) + 360.0, 180.0);
            r.push_back(d);
        }
        return r;
    }
};

class Ejemplos : public Modelo {
public:
    explicit Ejemplos(Contexto& c) : Modelo(c) { p = {{"umbral", 0.55}}; }   // umbral = parecido minimo
    std::string id() const override { return "ejemplos"; }
    std::string nombre() const override { return "Ejemplos ensenados (Terminator)"; }
    std::string licencia() const override { return "propio"; }
    bool disponible(std::string& w) override {
        if (ctx.memoria && !ctx.memoria->vacia()) return true;
        w = "aun no le ensenas nada (tecla e)";
        return false;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        return ctx.memoria->buscar(img, ctx.fondo, ctx.mascara, p["umbral"], g_filtros->v("mascara_dif"), g_filtros->v("mascara_area"));
    }
};

// ====================================================================== catalogo
std::vector<InfoModelo> catalogo() {
    return {{"1", "fondo", "Resta de fondo (OpenCV)", ""},
            {"2", "ssd_general", "detectNet SSD-MobileNet-v2 (COCO)", "ji"},
            {"3", "ssd_propio", "detectNet SSD re-entrenado (tuyo)", "ji"},
            {"4", "yolo_mit4", "YOLO11-L 4 instrumentos (MIT)", "red"},
            {"5", "yolo_doccheck12", "YOLOv5-L 12 instrumentos (DocCheck)", "red"},
            {"6", "orientacion", "Orientacion 0-357 (DocCheck)", "red"},
            {"7", "ejemplos", "Ejemplos ensenados (Terminator)", ""},
            {"8", "fondo_ia", "backgroundNet U2-Net", "ji"},
            {"9", "yolo_alumno", "YOLO nano alumno (tuyo)", "red"}};
}

static std::string dir_complementos() {
    const char* d = getenv("AUSTERO_LIB");
    return d ? d : aus::ruta("build");
}

// "red" = trt si existe el .so de TensorRT; si no, cvdnn (CPU)
static std::string resolver(const std::string& donde) {
    if (donde != "red") return donde;
    return aus::existe(dir_complementos() + "/libaustero_trt.so") ? "trt" : "cvdnn";
}

std::string complemento_de(const std::string& id) {
    for (auto& m : catalogo())
        if (m.id == id) return resolver(m.donde);
    return "";
}

// ====================================================================== Banco
Banco::~Banco() {
    for (auto& kv : so_)
        if (kv.second.h) {
            kv.second.c->cerrar(kv.second.c->usa_cuda);
            dlclose(kv.second.h);
        }
}

Banco::So* Banco::abrir(const std::string& n, std::string& error) {
    So& s = so_[n];
    if (s.h) return &s;
    std::string ruta = dir_complementos() + "/libaustero_" + n + ".so";
    aus::Crono cr;
    s.h = dlopen(ruta.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!s.h) {
        error = std::string("no pude cargar el complemento ") + n + ": " + dlerror();
        so_.erase(n);
        return nullptr;
    }
    auto f = (Complemento * (*)()) dlsym(s.h, "austero_complemento");
    s.c = f ? f() : nullptr;
    if (!s.c || s.c->version != AUSTERO_COMPLEMENTO_VERSION) {
        error = "complemento " + n + " de otra version: recompila (./instalar.sh)";
        dlclose(s.h);
        so_.erase(n);
        return nullptr;
    }
    log(fmt("complemento %s cargado (%.0f ms)", n.c_str(), cr.ms()));
    return &s;
}

void Banco::quizas_cerrar(const std::string& n) {
    auto it = so_.find(n);
    if (it == so_.end() || it->second.usos > 0) return;
    // reiniciar CUDA solo si ningun otro complemento con CUDA sigue cargado
    bool otro_cuda = false;
    for (auto& kv : so_)
        if (kv.first != n && kv.second.c && kv.second.c->usa_cuda) otro_cuda = true;
    // Se suelta todo lo que pesa (modelos, buffers y el contexto CUDA), pero la .so se queda mapeada:
    // OpenCV DNN, TensorRT y jetson-inference no aguantan bien descargarse y volverse a cargar en el mismo
    // proceso, y el codigo de una .so ya cargada casi no ocupa RAM (se lee del disco al usarse).
    it->second.c->cerrar(it->second.c->usa_cuda && !otro_cuda);
    log("complemento " + n + " en pausa" + (it->second.c->usa_cuda && !otro_cuda ? " (memoria de GPU liberada)" : ""));
}

Modelo* Banco::crear(const std::string& x, Contexto& ctx, std::string& error) {
    std::string id = x;
    for (auto& m : catalogo())
        if (m.tecla == x) id = m.id;
    if (id == "fondo") return new Fondo(ctx);
    if (id == "ejemplos") return new Ejemplos(ctx);
    std::string n = complemento_de(id);
    if (n.empty()) {
        error = "no existe el modelo '" + id + "'";
        return nullptr;
    }
    So* s = abrir(n, error);
    if (!s) return nullptr;
    Modelo* m = s->c->crear_modelo ? s->c->crear_modelo(id.c_str(), &ctx) : nullptr;
    if (!m) {
        error = "el complemento " + n + " no tiene '" + id + "'";
        quizas_cerrar(n);
        return nullptr;
    }
    s->usos++;
    de_[m] = n;
    return m;
}

Manos* Banco::crear_manos(std::string& error) {
    So* s = abrir("ji", error);
    if (!s) return nullptr;
    Manos* m = s->c->crear_manos ? s->c->crear_manos() : nullptr;
    if (!m) {
        error = "el complemento ji no tiene manos";
        quizas_cerrar("ji");
        return nullptr;
    }
    s->usos++;
    de_[m] = "ji";
    return m;
}

void Banco::soltar(Modelo* m) {
    if (!m) return;
    auto it = de_.find(m);
    std::string n = it == de_.end() ? "" : it->second;
    delete m;   // el destructor vive en el .so: borrar ANTES de descargarlo
    if (n.empty()) return;
    de_.erase(it);
    so_[n].usos--;
    quizas_cerrar(n);
}
void Banco::soltar(Manos* m) {
    if (!m) return;
    auto it = de_.find(m);
    std::string n = it == de_.end() ? "" : it->second;
    delete m;
    if (n.empty()) return;
    de_.erase(it);
    so_[n].usos--;
    quizas_cerrar(n);
}
std::string Banco::cargados() const {
    std::string t;
    for (auto& kv : so_)
        if (kv.second.usos > 0) t += (t.empty() ? "" : ",") + kv.first;
    return t.empty() ? "ninguno" : t;
}
