// camara.hpp - captura V4L2 directa (mmap), sin hilos ni OpenCV videoio.
// El lazo principal espera con select() a que haya cuadro: sin cuadro, la CPU duerme.
// YUYV: el gris sale GRATIS (es el canal Y); el color solo se convierte si alguien lo pide.
// MJPG: se decodifica solo lo necesario (gris reducido para movimiento; color al detectar).
#pragma once

#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "base.hpp"

struct Cuadro {
    cv::Mat crudo;     // YUYV (CV_8UC2) o JPEG (bytes) o BGR (simulada)
    int formato = 0;   // 0 YUYV, 1 MJPG, 2 BGR
    int w = 0, h = 0;
    long n = 0;
    cv::Mat gris() const;   // a resolucion completa
    cv::Mat bgr() const;
};

// mesa simulada para probar sin Jetson: lo que "proyecta" la salida cae sobre la mesa con una
// homografia que el programa no conoce (la calibracion la tiene que descubrir)
struct Simulada {
    int w, h;
    cv::Mat mesa;
    std::vector<cv::Point2f> esq;
    struct Obj {
        std::string tipo;    // tijera | tijera_curva | bisturi | pinza | mano
        double x, y, a;      // px de camara, grados (hacia la punta)
        double apertura = 0, brillo = 0.7;
    };
    double px_por_mm = 0.55;
    std::vector<Obj> objs;
    cv::Mat marcador;
    double exposicion = 1500, ganancia = 0;
    cv::RNG rng{3};
    Simulada(int w, int h);
    void revolver(int n);
    void pieza(const std::string& t);
    cv::Mat render(const cv::Mat& proyectado);
};

class Camara {
public:
    ~Camara();
    bool abrir(const aus::Conf& c);
    void cerrar();
    int fd() const { return fd_; }               // para select(); -1 en simulada
    bool tomar(Cuadro& c);                        // el cuadro mas nuevo (descarta los viejos)
    // controles: exposicion_auto, exposicion, ganancia, blancos_auto, blancos
    bool ctl_hay(const std::string& n);
    bool ctl_rango(const std::string& n, int& mn, int& mx);
    int ctl_leer(const std::string& n);
    bool ctl_poner(const std::string& n, int v);
    std::string ctl_lista();                 // "nombre|valor|min|max|paso|descripcion" por linea
    void ctl_guardar();                      // perfiles/camara.conf
    void ctl_cargar();

    int w = 0, h = 0, fps = 30;
    std::string tipo, error;
    std::unique_ptr<Simulada> sim;
    std::function<cv::Mat()> proyectado;          // solo simulada

private:
    int fd_ = -1, formato_ = 0;
    long n_ = 0;
    struct Buf {
        void* p;
        size_t len;
    };
    std::vector<Buf> bufs_;
    std::map<std::string, unsigned> ctl_;
};

// promedio de n cuadros nuevos en gris o color (para calibrar); espera_s deja que el proyector cambie
class Lazo;
std::string autoajuste(Camara& cam, std::function<cv::Mat()> gris_nuevo, double objetivo, double max_sat,
                       double& gamma_sugerida);
