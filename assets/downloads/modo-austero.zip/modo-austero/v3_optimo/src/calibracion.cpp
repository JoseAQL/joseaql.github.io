#include "calibracion.hpp"

#include <cmath>
#include <fstream>
#include <map>
#include <numeric>

#include <opencv2/aruco.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

using aus::fmt;
using aus::log;

// ====================================================================== ArUco (copia de OpenCV 4.1.1 contrib en src/aruco)
static cv::Ptr<cv::aruco::Dictionary> dic() { return cv::aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_50); }
cv::Mat dibujar_marcador(int id, int lado) {
    cv::Mat m;
    cv::aruco::drawMarker(dic(), id, lado, m);
    return m;
}
static void detectar(const cv::Mat& g, std::vector<std::vector<cv::Point2f>>& e, std::vector<int>& ids) {
    cv::aruco::detectMarkers(g, dic(), e, ids, cv::aruco::DetectorParameters::create());
}
void guardar_marcador_impreso(const std::string& png, int id, int lado_mm) {
    int lado = (int)(lado_mm / 25.4 * 300), b = lado / 4;
    cv::Mat img(lado + 2 * b, lado + 2 * b, CV_8U, cv::Scalar(255));
    dibujar_marcador(id, lado).copyTo(img(cv::Rect(b, b, lado, lado)));
    cv::putText(img, fmt("ID %d - %d mm - imprimir al 100%%", id, lado_mm), cv::Point(b, b / 2), cv::FONT_HERSHEY_SIMPLEX,
                1.2, cv::Scalar(0), 2);
    cv::imwrite(png, img);
}

// ====================================================================== Calibracion
static std::vector<cv::Point2f> tr(const cv::Mat& H, const std::vector<cv::Point2f>& p) {
    std::vector<cv::Point2f> r;
    if (!p.empty() && !H.empty()) cv::perspectiveTransform(p, r, H);
    return r;
}
std::vector<cv::Point2f> Calibracion::c2p(const std::vector<cv::Point2f>& p) const { return tr(H_c2p, p); }
std::vector<cv::Point2f> Calibracion::p2c(const std::vector<cv::Point2f>& p) const { return tr(H_p2c, p); }

static void leer_mat(std::istream& f, cv::Mat& H) {
    H = cv::Mat(3, 3, CV_64F);
    for (int i = 0; i < 9; i++) f >> H.at<double>(i / 3, i % 3);
}
bool Calibracion::cargar() {
    std::ifstream f(aus::ruta("perfiles/calibracion.txt"));
    std::string k;
    while (f >> k) {
        if (k == "H_c2p") leer_mat(f, H_c2p);
        else if (k == "H_c2mm") leer_mat(f, H_c2mm);
        else if (k == "px_por_mm") f >> px_por_mm;
        else if (k == "error_px") f >> error_px;
        else if (k == "metodo") f >> metodo;
    }
    if (!H_c2p.empty()) H_p2c = H_c2p.inv();
    return lista();
}
void Calibracion::guardar() const {
    auto m = [](const char* n, const cv::Mat& H) {
        if (H.empty()) return std::string();
        std::string s = n;
        for (int i = 0; i < 9; i++) s += fmt(" %.10g", H.at<double>(i / 3, i % 3));
        return s + "\n";
    };
    aus::escribir(aus::ruta("perfiles/calibracion.txt"),
                  m("H_c2p", H_c2p) + m("H_c2mm", H_c2mm) + fmt("px_por_mm %g\nerror_px %g\nmetodo %s\n", px_por_mm,
                                                                 error_px, metodo.c_str()));
}

// ====================================================================== utilidades
static bool centro_blob(const cv::Mat& dif, cv::Point2f& c) {
    cv::Mat b, et, st, cen;
    cv::threshold(dif, b, 40, 255, cv::THRESH_BINARY);
    int n = cv::connectedComponentsWithStats(b, et, st, cen);
    if (n <= 1) return false;
    int m = 1;
    for (int i = 2; i < n; i++)
        if (st.at<int>(i, cv::CC_STAT_AREA) > st.at<int>(m, cv::CC_STAT_AREA)) m = i;
    if (st.at<int>(m, cv::CC_STAT_AREA) < 6) return false;
    cv::Mat solo = cv::Mat::zeros(dif.size(), CV_8U);
    dif.copyTo(solo, et == m);                       // centroide pesado por brillo
    cv::Moments mo = cv::moments(solo, false);
    if (mo.m00 <= 0) return false;
    c = cv::Point2f((float)(mo.m10 / mo.m00), (float)(mo.m01 / mo.m00));
    return true;
}

static bool ajustar(const std::vector<cv::Point2f>& cam, const std::vector<cv::Point2f>& pro, bool ransac, cv::Mat& H,
                    double& err, int& n) {
    if (cam.size() < 4) return false;
    if (cam.size() == 4) {
        H = cv::getPerspectiveTransform(cam, pro);
        err = 0;
        n = 4;
        return true;
    }
    cv::Mat msk;
    H = cv::findHomography(cam, pro, ransac ? cv::RANSAC : 0, 6.0, msk);
    if (H.empty()) return false;
    std::vector<cv::Point2f> pc, cc;
    for (size_t i = 0; i < cam.size(); i++)
        if (msk.empty() || msk.at<uchar>((int)i)) {
            pc.push_back(pro[i]);
            cc.push_back(cam[i]);
        }
    auto b = tr(H.inv(), pc);
    double s = 0;
    for (size_t i = 0; i < b.size(); i++) s += cv::norm(b[i] - cc[i]);
    err = b.empty() ? 0 : s / b.size();   // en pixeles de camara
    n = (int)cc.size();
    return true;
}

// ====================================================================== metodos
static bool m_aruco(Herramientas& h, cv::Mat& H, double& err, int& n) {
    int lado = (int)(h.ph / 5.2), cols = 6, filas = 3;
    cv::Mat img(h.ph, h.pw, CV_8U, cv::Scalar(255));
    std::map<int, std::vector<cv::Point2f>> pos;
    double mx = (h.pw - cols * lado) / (cols + 1.0), my = (h.ph - filas * lado) / (filas + 1.0);
    int k = 0;
    for (int f = 0; f < filas; f++)
        for (int c = 0; c < cols; c++, k++) {
            int x = (int)(mx + c * (lado + mx)), y = (int)(my + f * (lado + my));
            dibujar_marcador(k, lado).copyTo(img(cv::Rect(x, y, lado, lado)));
            pos[k] = {{(float)x, (float)y}, {(float)(x + lado), (float)y}, {(float)(x + lado), (float)(y + lado)}, {(float)x, (float)(y + lado)}};
        }
    h.proyectar(img);
    cv::Mat g = h.foto(2, 0.35);
    if (g.empty()) return false;
    std::vector<std::vector<cv::Point2f>> e;
    std::vector<int> ids;
    detectar(g, e, ids);
    std::vector<cv::Point2f> cam, pro;
    for (size_t i = 0; i < ids.size(); i++)
        if (pos.count(ids[i]))
            for (int j = 0; j < 4; j++) {
                cam.push_back(e[i][j]);
                pro.push_back(pos[ids[i]][j]);
            }
    log(fmt("aruco: vi %d de %d marcadores", (int)cam.size() / 4, (int)pos.size()));
    return cam.size() >= 8 && ajustar(cam, pro, true, H, err, n);
}

static bool m_puntos(Herramientas& h, cv::Mat& H, double& err, int& n) {
    int cols = 10, filas = 6, r = std::max(6, std::min(h.pw, h.ph) / 60);
    cv::Mat img = cv::Mat::zeros(h.ph, h.pw, CV_8U);
    std::vector<cv::Point2f> pro;
    for (int f = 0; f < filas; f++)
        for (int c = 0; c < cols; c++) {
            cv::Point2f p((float)(h.pw * (0.1 + 0.8 * c / (cols - 1))), (float)(h.ph * (0.1 + 0.8 * f / (filas - 1))));
            cv::circle(img, p, (f == 0 && c == 0) ? (int)(r * 1.6) : r, cv::Scalar(255), -1);
            pro.push_back(p);
        }
    h.proyectar(cv::Mat::zeros(h.ph, h.pw, CV_8U));
    cv::Mat ng = h.foto(2, 0.35);
    h.proyectar(img);
    cv::Mat fo = h.foto(2, 0.35);
    if (ng.empty() || fo.empty()) return false;
    cv::Mat dif, b, et, st, cen;
    cv::subtract(fo, ng, dif);
    cv::GaussianBlur(dif, dif, cv::Size(3, 3), 0);
    cv::threshold(dif, b, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);
    int nb = cv::connectedComponentsWithStats(b, et, st, cen);
    std::vector<std::pair<int, cv::Point2f>> bl;
    for (int i = 1; i < nb; i++)
        if (st.at<int>(i, cv::CC_STAT_AREA) >= 4)
            bl.push_back({st.at<int>(i, cv::CC_STAT_AREA), cv::Point2f((float)cen.at<double>(i, 0), (float)cen.at<double>(i, 1))});
    if ((int)bl.size() < cols * filas) {
        log(fmt("puntos: vi %d de %d circulos", (int)bl.size(), cols * filas));
        return false;
    }
    std::sort(bl.begin(), bl.end(), [](const std::pair<int, cv::Point2f>& a, const std::pair<int, cv::Point2f>& b) { return a.first > b.first; });
    bl.resize(cols * filas);
    cv::Point2f grande = bl[0].second;
    cv::Mat lim = cv::Mat::zeros(b.size(), CV_8U);
    for (auto& x : bl) cv::circle(lim, x.second, 3, cv::Scalar(255), -1);
    cv::SimpleBlobDetector::Params pr;
    pr.filterByColor = true;
    pr.blobColor = 255;
    pr.minArea = 5;
    pr.filterByInertia = pr.filterByConvexity = pr.filterByCircularity = false;
    std::vector<cv::Point2f> g;
    if (!cv::findCirclesGrid(lim, cv::Size(cols, filas), g, cv::CALIB_CB_SYMMETRIC_GRID, cv::SimpleBlobDetector::create(pr))) {
        log("puntos: no pude ordenar la rejilla");
        return false;
    }
    std::vector<cv::Point2f> inv(g.rbegin(), g.rend());
    if (cv::norm(inv[0] - grande) < cv::norm(g[0] - grande)) g = inv;
    return ajustar(g, pro, true, H, err, n);
}

static bool m_esquinas(Herramientas& h, cv::Mat& H, double& err, int& n) {
    double m = 0.12;
    std::vector<cv::Point2f> obj = {{(float)(h.pw * m), (float)(h.ph * m)}, {(float)(h.pw * (1 - m)), (float)(h.ph * m)},
                                    {(float)(h.pw * (1 - m)), (float)(h.ph * (1 - m))}, {(float)(h.pw * m), (float)(h.ph * (1 - m))}};
    h.proyectar(cv::Mat::zeros(h.ph, h.pw, CV_8U));
    cv::Mat ng = h.foto(2, 0.35);
    std::vector<cv::Point2f> cam;
    for (size_t i = 0; i < obj.size(); i++) {
        cv::Mat img = cv::Mat::zeros(h.ph, h.pw, CV_8U), dif;
        cv::circle(img, obj[i], h.ph / 30, cv::Scalar(255), -1);
        h.proyectar(img);
        cv::subtract(h.foto(2, 0.35), ng, dif);
        cv::Point2f p;
        if (!centro_blob(dif, p)) {
            log(fmt("esquinas: no vi el punto %d", (int)i + 1));
            return false;
        }
        cam.push_back(p);
    }
    return ajustar(cam, obj, false, H, err, n);
}

static bool m_graycode(Herramientas& h, cv::Mat& H, double& err, int& n) {
    const int paso = 8;
    int cw = h.pw / paso, ch = h.ph / paso;
    int bx = (int)std::ceil(std::log2((double)cw)), by = (int)std::ceil(std::log2((double)ch));
    h.proyectar(cv::Mat::zeros(h.ph, h.pw, CV_8U));
    cv::Mat ng = h.foto(2, 0.35);
    h.proyectar(cv::Mat(h.ph, h.pw, CV_8U, cv::Scalar(255)));
    cv::Mat bl = h.foto(2, 0.35);
    cv::Mat d16;
    cv::subtract(bl, ng, d16, cv::noArray(), CV_16S);
    cv::Mat valido = d16 > 25;
    log(fmt("graycode: %d fotos...", 2 * (bx + by) + 2));
    auto leer = [&](int nb, bool col) {
        cv::Mat val = cv::Mat::zeros(valido.size(), CV_32S);
        for (int b = nb - 1; b >= 0; b--) {
            cv::Mat pat(ch, cw, CV_8U);
            for (int y = 0; y < ch; y++)
                for (int x = 0; x < cw; x++) {
                    int v = col ? x : y, g = v ^ (v >> 1);
                    pat.at<uchar>(y, x) = ((g >> b) & 1) ? 255 : 0;
                }
            cv::resize(pat, pat, cv::Size(h.pw, h.ph), 0, 0, cv::INTER_NEAREST);
            h.proyectar(pat);
            cv::Mat a = h.foto(1, 0.25);
            h.proyectar(255 - pat);
            cv::Mat in = h.foto(1, 0.25), dd;
            cv::absdiff(a, in, dd);
            valido &= dd > 8;
            cv::Mat bit = a > in;
            for (int y = 0; y < val.rows; y++) {
                int* v = val.ptr<int>(y);
                const uchar* q = bit.ptr<uchar>(y);
                for (int x = 0; x < val.cols; x++) v[x] = (v[x] << 1) | (q[x] ? 1 : 0);
            }
        }
        for (int y = 0; y < val.rows; y++) {
            int* v = val.ptr<int>(y);
            for (int x = 0; x < val.cols; x++) {
                int r = v[x];
                for (int s = v[x] >> 1; s; s >>= 1) r ^= s;
                v[x] = r;
            }
        }
        return val;
    };
    cv::Mat col = leer(bx, true), fil = leer(by, false);
    std::vector<cv::Point2f> cam, pro;
    int tot = cv::countNonZero(valido), salto = std::max(1, tot / 3000), k = 0;
    for (int y = 0; y < valido.rows; y++)
        for (int x = 0; x < valido.cols; x++)
            if (valido.at<uchar>(y, x) && (k++ % salto == 0)) {
                cam.push_back(cv::Point2f((float)x, (float)y));
                pro.push_back(cv::Point2f(col.at<int>(y, x) * paso + paso / 2.f, fil.at<int>(y, x) * paso + paso / 2.f));
            }
    return cam.size() >= 50 && ajustar(cam, pro, true, H, err, n);
}

bool calibrar(Calibracion& cal, Herramientas& h, const std::string& met, const aus::Conf& c) {
    double t0 = aus::ahora();
    cv::Mat H;
    double err = 0;
    int n = 0;
    bool ok = false;
    try {
        if (met == "aruco") ok = m_aruco(h, H, err, n);
        else if (met == "puntos") ok = m_puntos(h, H, err, n);
        else if (met == "esquinas") ok = m_esquinas(h, H, err, n);
        else if (met == "graycode") ok = m_graycode(h, H, err, n);
        else log("metodo desconocido: " + met + " (aruco|puntos|esquinas|graycode)");
    } catch (const std::exception& e) {
        log(std::string("calibracion: ") + e.what());
    }
    h.proyectar(cv::Mat());   // quitar el patron
    if (!ok) {
        log("calibracion " + met + ": FALLO");
        return false;
    }
    cal.H_c2p = H;
    cal.H_p2c = H.inv();
    cal.metodo = met;
    cal.error_px = std::round(err * 100) / 100;
    log(fmt("calibracion %s OK: %d puntos, error %.2f px, %.1f s", met.c_str(), n, err, aus::ahora() - t0));
    if (c.b("calibracion.medir_mm", true)) medir_mm(cal, h, c);
    cal.guardar();
    return true;
}

double verificar(Calibracion& cal, Herramientas& h, int n) {
    if (!cal.lista()) return -1;
    cv::RNG rng((uint64)cv::getTickCount());
    h.proyectar(cv::Mat::zeros(h.ph, h.pw, CV_8U));
    cv::Mat ng = h.foto(2, 0.35);
    std::vector<double> e;
    for (int i = 0; i < n; i++) {
        cv::Point2f p((float)(rng.uniform(0.2, 0.8) * h.pw), (float)(rng.uniform(0.2, 0.8) * h.ph)), q;
        cv::Mat img = cv::Mat::zeros(h.ph, h.pw, CV_8U), dif;
        cv::circle(img, p, h.ph / 40, cv::Scalar(255), -1);
        h.proyectar(img);
        cv::subtract(h.foto(2, 0.35), ng, dif);
        if (centro_blob(dif, q)) e.push_back(cv::norm(cal.p2c({p})[0] - q));
    }
    h.proyectar(cv::Mat());
    if (e.empty()) {
        log("verificar: no vi los puntos de prueba");
        return -1;
    }
    double m = std::accumulate(e.begin(), e.end(), 0.0) / e.size();
    cal.error_px = std::round(m * 100) / 100;
    log(fmt("verificar: error %.1f px", m));
    return m;
}

bool medir_mm(Calibracion& cal, Herramientas& h, const aus::Conf& c) {
    double mm = c.d("calibracion.marcador_mm", 50);
    int id = c.i("calibracion.marcador_id", 49);
    h.proyectar(cv::Mat(h.ph, h.pw, CV_8U, cv::Scalar(200)));
    cv::Mat g = h.foto(2, 0.3);
    h.proyectar(cv::Mat());
    if (g.empty()) return false;
    std::vector<std::vector<cv::Point2f>> e;
    std::vector<int> ids;
    detectar(g, e, ids);
    for (size_t i = 0; i < ids.size(); i++)
        if (ids[i] == id) {
            std::vector<cv::Point2f> d = {{0, 0}, {(float)mm, 0}, {(float)mm, (float)mm}, {0, (float)mm}};
            cal.H_c2mm = cv::getPerspectiveTransform(e[i], d);
            double s = 0;
            for (int j = 0; j < 4; j++) s += cv::norm(e[i][j] - e[i][(j + 1) % 4]);
            cal.px_por_mm = std::round(s / 4 / mm * 10000) / 10000;
            log(fmt("mm: %.3f px por mm", cal.px_por_mm));
            return true;
        }
    log(fmt("mm: no vi el marcador impreso ID %d (opcional; perfiles/marcador_mm.png)", id));
    return false;
}
