#include "stats.hpp"

#include <unistd.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

#include "base.hpp"

static std::string leer1(const std::string& p) {
    std::ifstream f(p);
    std::string s;
    std::getline(f, s);
    return s;
}

double Muestra::temp_max() const {
    double m = -1;
    for (auto& kv : temp)
        if (kv.first.find("PMIC") == std::string::npos && kv.first.find("thermal") == std::string::npos)
            m = std::max(m, kv.second);
    return m;
}

std::string Muestra::texto() const {
    std::string c, mhz, t;
    for (size_t i = 0; i < cpu.size(); i++) c += (i ? "," : "") + std::to_string(cpu[i]);
    for (size_t i = 0; i < cpu_mhz.size(); i++) mhz += (i ? "," : "") + std::to_string(cpu_mhz[i]);
    for (auto& kv : temp) t += (t.empty() ? "" : ",") + kv.first + ":" + aus::fmt("%.1f", kv.second);
    return aus::fmt("cpu_prom=%.0f\ncpu=%s\ncpu_mhz=%s\ngpu=%d\ngpu_mhz=%d\nram_mb=%d\nram_total_mb=%d\nswap_mb=%d\n"
                    "potencia_mw=%d\nproc_cpu=%.1f\nproc_ram_mb=%.1f\ntemp=%s\n",
                    cpu_prom, c.c_str(), mhz.c_str(), gpu, gpu_mhz, ram_mb, ram_total_mb, swap_mb, potencia_mw, proc_cpu,
                    proc_ram_mb, t.c_str());
}

Muestra Estadisticas::leer() {
    Muestra m;
    // ---- CPU por nucleo
    std::ifstream st("/proc/stat");
    std::string l;
    std::vector<std::pair<long long, long long>> act;
    while (std::getline(st, l)) {
        if (l.compare(0, 3, "cpu") != 0 || l.size() < 4 || l[3] == ' ') continue;
        std::stringstream ss(l);
        std::string n;
        ss >> n;
        long long v, tot = 0, idle = 0;
        for (int i = 0; ss >> v; i++) {
            tot += v;
            if (i == 3 || i == 4) idle += v;
        }
        act.push_back({tot, idle});
    }
    if (prev_cpu_.size() == act.size()) {
        double s = 0;
        for (size_t i = 0; i < act.size(); i++) {
            long long dt = std::max(1LL, act[i].first - prev_cpu_[i].first);
            int p = (int)std::lround(100.0 * (1.0 - (double)(act[i].second - prev_cpu_[i].second) / dt));
            m.cpu.push_back(std::max(0, std::min(100, p)));
            s += m.cpu.back();
        }
        m.cpu_prom = act.empty() ? 0 : s / act.size();
    }
    prev_cpu_ = act;
    for (size_t i = 0; i < act.size(); i++) {
        std::string f = leer1(aus::fmt("/sys/devices/system/cpu/cpu%d/cpufreq/scaling_cur_freq", (int)i));
        m.cpu_mhz.push_back(f.empty() ? 0 : std::atoi(f.c_str()) / 1000);
    }
    // ---- RAM
    std::ifstream mi("/proc/meminfo");
    long tot = 0, disp = 0, st_ = 0, sf = 0;
    while (std::getline(mi, l)) {
        long v = std::atol(l.c_str() + l.find(':') + 1) / 1024;
        if (!l.compare(0, 9, "MemTotal:")) tot = v;
        else if (!l.compare(0, 13, "MemAvailable:")) disp = v;
        else if (!l.compare(0, 10, "SwapTotal:")) st_ = v;
        else if (!l.compare(0, 9, "SwapFree:")) sf = v;
    }
    m.ram_total_mb = (int)tot;
    m.ram_mb = (int)(tot - disp);
    m.swap_mb = (int)(st_ - sf);
    // ---- GPU (Jetson)
    std::string g = leer1("/sys/devices/gpu.0/load");
    if (!g.empty()) m.gpu = std::atoi(g.c_str()) / 10;
    for (auto& d : {"/sys/devices/57000000.gpu/devfreq/57000000.gpu/cur_freq", "/sys/devices/gpu.0/devfreq/57000000.gpu/cur_freq"}) {
        std::string f = leer1(d);
        if (!f.empty()) {
            m.gpu_mhz = (int)(std::atol(f.c_str()) / 1000000);
            break;
        }
    }
    // ---- temperaturas
    for (auto& z : aus::listar("/sys/class/thermal")) {
        if (z.compare(0, 12, "thermal_zone") != 0) continue;
        std::string tipo = leer1("/sys/class/thermal/" + z + "/type"), t = leer1("/sys/class/thermal/" + z + "/temp");
        if (!t.empty() && tipo.find("PMIC") == std::string::npos) m.temp[tipo.substr(0, 10)] = std::atof(t.c_str()) / 1000.0;
    }
    // ---- consumo (INA3221 de la Nano: canal 0 = entrada total)
    if (!buscada_) {
        buscada_ = true;
        for (auto& b : {"/sys/bus/i2c/drivers/ina3221x/6-0040/iio:device0/in_power0_input",
                        "/sys/bus/i2c/drivers/ina3221x/7-0040/iio:device0/in_power0_input"})
            if (aus::existe(b)) ruta_potencia_ = b;
    }
    if (!ruta_potencia_.empty()) m.potencia_mw = std::atoi(leer1(ruta_potencia_).c_str());
    // ---- este proceso
    std::string s = aus::fmt("%s", "");
    {
        std::ifstream f("/proc/self/stat");
        std::getline(f, s);
    }
    size_t k = s.rfind(')');
    if (k != std::string::npos) {
        std::stringstream ss(s.substr(k + 2));
        std::vector<std::string> c;
        std::string x;
        while (ss >> x) c.push_back(x);
        if (c.size() > 13) {
            long ticks = std::atol(c[11].c_str()) + std::atol(c[12].c_str());
            double t = aus::ahora();
            if (prev_ticks_ >= 0) m.proc_cpu = 100.0 * (ticks - prev_ticks_) / sysconf(_SC_CLK_TCK) / std::max(1e-3, t - prev_t_);
            prev_ticks_ = ticks;
            prev_t_ = t;
        }
    }
    std::ifstream ps("/proc/self/status");
    while (std::getline(ps, l))
        if (!l.compare(0, 6, "VmRSS:")) m.proc_ram_mb = std::atof(l.c_str() + 6) / 1024.0;
    return m;
}

std::string perfil_energia(const std::string& n) {
    if (!aus::existe("/etc/nv_tegra_release")) return "los perfiles de energia (nvpmodel) son solo de la Jetson; aqui no aplican";
    std::vector<std::string> c;
    if (n == "max") c = {"nvpmodel -m 0", "jetson_clocks"};
    else if (n == "normal") c = {"jetson_clocks --restore", "nvpmodel -m 0"};
    else if (n == "5w") c = {"jetson_clocks --restore", "nvpmodel -m 1"};
    else return "perfiles: max (10 W + relojes al maximo) | normal (10 W) | 5w (ahorro)";
    std::string r;
    bool mal = false;
    for (auto& x : c) {
        int k = system(("sudo -n " + x + " >/dev/null 2>&1").c_str());
        r += x + (k == 0 ? " -> ok; " : " -> error; ");
        mal |= k != 0;
    }
    if (mal) r += "(sin permiso: corre 'sudo ./herramientas/optimizar_jetson.sh --sudoers')";
    return r;
}
