// web.cpp - austero-web: pagina web OPCIONAL, en su propio proceso.
// Si no la arrancas (austero web on), no existe. Pide estado y JPEG al nucleo por el socket solo mientras
// alguien tiene la pagina abierta. Sin OpenCV ni librerias: sockets POSIX.
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <cstring>
#include <vector>
#include <string>
#include <thread>

#include "base.hpp"

static std::string sock() {
    const char* s = getenv("AUSTERO_SOCKET");
    return s ? s : "/tmp/austero.sock";
}

// pide al nucleo; devuelve cabecera ("ok ..."), binario y extra
static bool pedir(const std::string& l, std::string& cab, std::string& bin, std::string& extra) {
    int s = socket(AF_UNIX, SOCK_STREAM, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, sock().c_str(), sizeof(a.sun_path) - 1);
    if (connect(s, (sockaddr*)&a, sizeof a) != 0) {
        close(s);
        return false;
    }
    timeval tv{20, 0};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    std::string q = l + "\n";
    send(s, q.data(), q.size(), MSG_NOSIGNAL);
    std::string t;
    char b[65536];
    ssize_t n;
    while ((n = recv(s, b, sizeof b, 0)) > 0) t.append(b, n);
    close(s);
    size_t e = t.find('\n');
    if (e == std::string::npos) return false;
    cab = t.substr(0, e);
    std::string r = t.substr(e + 1);
    bin.clear();
    if (r.compare(0, 4, "bin ") == 0) {
        size_t e2 = r.find('\n');
        size_t nb = std::stoul(r.substr(4, e2 - 4));
        bin = r.substr(e2 + 1, nb);
        r = r.substr(e2 + 1 + nb);
    }
    extra = r;
    return true;
}

static bool enviar_todo(int c, const std::string& d) {
    size_t k = 0;
    while (k < d.size()) {
        ssize_t n = send(c, d.data() + k, d.size() - k, MSG_NOSIGNAL);
        if (n <= 0) return false;
        k += n;
    }
    return true;
}
static void responder(int c, const std::string& tipo, const std::string& cuerpo) {
    enviar_todo(c, "HTTP/1.1 200 OK\r\nContent-Type: " + tipo + "\r\nContent-Length: " + std::to_string(cuerpo.size()) +
                       "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" + cuerpo);
}
static std::string json_esc(const std::string& s) {
    std::string r;
    for (char ch : s) {
        if (ch == '"' || ch == '\\') r += '\\';
        if (ch == '\n') {
            r += "\\n";
            continue;
        }
        if ((unsigned char)ch < 0x20) continue;
        r += ch;
    }
    return r;
}
static std::string url_dec(const std::string& s) {
    std::string r;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '%' && i + 2 < s.size()) {
            r += (char)std::stoi(s.substr(i + 1, 2), nullptr, 16);
            i += 2;
        } else r += s[i] == '+' ? ' ' : s[i];
    }
    return r;
}

static const char* PAGINA = R"HTML(<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Modo Austero</title>
<style>
:root{--f:#0d1014;--c:#151a20;--t:#d7dde4;--g:#7b8794;--v:#5bd68a;--a:#f5c451;--r:#ef6b6b}
body{margin:0;background:var(--f);color:var(--t);font:14px/1.45 ui-monospace,Menlo,Consolas,monospace}
main{max-width:1100px;margin:auto;padding:12px 16px;display:grid;gap:12px;grid-template-columns:minmax(0,2fr) minmax(0,1fr)}
@media(max-width:800px){main{grid-template-columns:1fr}}
section{background:var(--c);border-radius:8px;padding:10px;min-width:0}
img{width:100%;border-radius:6px;background:#000;display:block;min-height:120px}
button{background:#222a33;color:var(--t);border:1px solid #2f3a46;border-radius:6px;padding:6px 9px;margin:2px;cursor:pointer;font:inherit}
button:hover{border-color:var(--v)} .on{color:var(--v);border-color:var(--v)}
h1{font-size:15px;margin:0 0 6px} pre{white-space:pre-wrap;margin:6px 0 0;color:var(--g);font-size:12px}
.bar{height:7px;background:#222a33;border-radius:4px;overflow:hidden;margin:2px 0 6px}.bar i{display:block;height:100%}
</style></head><body><main>
<section><img id="v" alt="cámara"><div id="d"></div><label><input type="checkbox" id="ver" checked> ver cámara (gasta un poco)</label></section>
<section><h1>MODO AUSTERO v3 · <a href="/lab" style="color:#f08a4b">Laboratorio de filtros →</a> · <a href="/quest" style="color:#22d3ee">Instrumental Quest →</a></h1><div id="s"></div><div id="m"></div>
<div><button onclick="c('autoajuste')">auto-ajuste</button><button onclick="c('calibrar')">calibrar</button>
<button onclick="c('calibrar puntos')">puntos</button><button onclick="c('calibrar esquinas')">esquinas</button>
<button onclick="c('calibrar graycode')">graycode</button><button onclick="c('verificar')">verificar</button>
<button onclick="c('fondo')">fondo</button><button onclick="c('manos')">manos</button><button onclick="c('buscar')">buscar</button>
<button onclick="e()">enseñar…</button><button onclick="c('ensenar auto')">propuesta</button>
<button onclick="c('ensenar guardar')">guardar ejemplo</button><button onclick="c('ensenar cancelar')">terminar</button></div>
<pre id="l"></pre></section></main>
<script>
const $=i=>document.getElementById(i);
function c(x){fetch('/cmd?c='+encodeURIComponent(x)).then(r=>r.json()).then(r=>{$('l').textContent='» '+r.msg})}
function e(){var n=prompt('¿Qué pieza?');if(n)c('ensenar "'+n+'"')}
function b(p){p=Math.max(0,Math.min(100,+p||0));return '<div class="bar"><i style="width:'+p+'%;background:'+(p<60?'var(--v)':p<85?'var(--a)':'var(--r)')+'"></i></div>'}
document.addEventListener('keydown',k=>{var m={ArrowUp:'0 -1',ArrowDown:'0 1',ArrowLeft:'-1 0',ArrowRight:'1 0'}[k.key];
 if(m){c('ensenar mover '+m);k.preventDefault()} if(k.key=='Enter')c('ensenar guardar');if(k.key=='+')c('ensenar tam 1 1');if(k.key=='-')c('ensenar tam -1 -1')});
function foto(){if(!$('ver').checked){setTimeout(foto,1000);return}
 var i=new Image();i.onload=()=>{$('v').src=i.src;setTimeout(foto,250)};i.onerror=()=>setTimeout(foto,1500);i.src='/foto.jpg?'+Date.now()}
function t(){fetch('/estado').then(r=>r.json()).then(s=>{
 $('s').innerHTML='modelo <b>'+s.modelo+'</b> '+(s.motor||'')+'<br>'+s.fps+' inf/s · '+s.lat_ms+' ms · '+(s.reposo=='1'?'reposo':s.movimiento=='1'?'movimiento':'quieto')+
 '<br>CPU '+Math.round(s.cpu_prom)+'%'+b(s.cpu_prom)+'GPU '+s.gpu+'%'+b(s.gpu)+'RAM '+s.ram_mb+'/'+s.ram_total_mb+' MB'+b(100*s.ram_mb/s.ram_total_mb)+
 'núcleo '+s.proc_ram_mb+' MB · '+(s.potencia_mw>0?(s.potencia_mw/1000).toFixed(2)+' W · ':'')+'calibración '+s.calib+'<br>'+(s.temp||'');
 $('m').innerHTML=(s.catalogo||'').split(',').map(x=>{var p=x.split(':');return '<button class="'+(s.modelo.startsWith(p[1])?'on':'')+'" onclick="c(\'modelo '+p[0]+'\')">'+x+'</button>'}).join('')+'<button onclick="c(\'modelo 0\')">0 ninguno</button>';
 $('d').textContent=(s.dets||'').split('|').join('   ');
 if(!$('l').textContent.startsWith('»'))$('l').textContent=s.log||''}).catch(()=>{})}
setInterval(t,1500);t();foto();
</script></body></html>)HTML";

static const char* LAB = R"HTML(<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Laboratorio</title>
<style>
:root{--f:#0d1014;--c:#151a20;--t:#d7dde4;--g:#7b8794;--v:#5bd68a;--a:#f5c451;--n:#f08a4b}
body{margin:0;background:var(--f);color:var(--t);font:13px/1.4 ui-monospace,Menlo,Consolas,monospace}
header{padding:8px 16px;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
header b{color:var(--n)} header a{color:var(--g)}
main{display:grid;gap:12px;padding:0 16px 16px;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr)}
@media(max-width:900px){main{grid-template-columns:1fr}}
section{background:var(--c);border-radius:8px;padding:10px;min-width:0}
img{width:100%;border-radius:6px;background:#000;display:block}
.vis button{background:#222a33;color:var(--t);border:1px solid #2f3a46;border-radius:6px;padding:4px 8px;margin:2px;cursor:pointer;font:inherit}
.vis button.on{border-color:var(--n);color:var(--n)}
h2{font-size:13px;margin:10px 0 4px;color:var(--n)}
.p{display:grid;grid-template-columns:minmax(0,9em) minmax(0,1fr) 5em;gap:6px;align-items:center;padding:3px 0;border-bottom:1px solid #1e252d}
.p span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.p input[type=range]{width:100%;accent-color:var(--n)}
.p input[type=number]{width:100%;background:#0d1014;color:var(--t);border:1px solid #2f3a46;border-radius:4px;font:inherit}
.d{grid-column:1/4;color:var(--g);font-size:11px;margin-top:-2px}
#info{color:var(--a)} .scroll{max-height:80vh;overflow:auto}
</style></head><body>
<header><b>LABORATORIO</b><a href="/">← panel</a><span id="info"></span>
<label><input type="checkbox" id="ver" checked> ver imagen</label>
<button onclick="c('filtro reset')">filtros de fábrica</button><button onclick="c('autoajuste')">auto-ajuste</button><button onclick="c('fondo')">tomar fondo</button></header>
<main><section><div class="vis" id="vis"></div><img id="v" alt="laboratorio"></section>
<section class="scroll"><div id="aj"></div></section></main>
<script>
const $=i=>document.getElementById(i);let P=5,T={};
const N=["con detecciones","1 cámara","2 lo que ve la red","3 máscara","4 bordes y esquinas","5 las 4 juntas","6 lo que se proyecta"];
$('vis').innerHTML=N.map((n,i)=>'<button id="b'+i+'" onclick="P='+i+';marca()">'+n+'</button>').join('');
function marca(){N.forEach((n,i)=>$('b'+i).className=i==P?'on':'')}marca();
function c(x){return fetch('/cmd?c='+encodeURIComponent(x)).then(r=>r.json()).then(r=>{$('info').textContent=r.msg;return r})}
function foto(){if(!$('ver').checked){setTimeout(foto,800);return}
 var i=new Image(),t0=Date.now();i.onload=()=>{$('v').src=i.src;setTimeout(foto,Math.max(80,300-(Date.now()-t0)))};
 i.onerror=()=>setTimeout(foto,1200);i.src='/foto.jpg?p='+P+'&w='+(P==5?960:720)+'&t='+t0}
function cambia(t,n,v){clearTimeout(T[n]);T[n]=setTimeout(()=>{c((t=='f'?'filtro ':t=='c'?'cam ':'param ')+n+' '+v).then(()=>carga(false))},120)}
function carga(todo){fetch('/ajustes').then(r=>r.json()).then(a=>{
 if(!todo){a.forEach(x=>{var r=$('r_'+x.n),q=$('n_'+x.n);if(r&&document.activeElement!==r)r.value=x.v;if(q&&document.activeElement!==q)q.value=x.v});return}
 var g={f:'Filtros y kernels (lo que ve la red, máscara y bordes)',c:'Cámara',m:'Modelo activo'},h='';
 ['c','f','m'].forEach(t=>{var l=a.filter(x=>x.t==t);if(!l.length)return;h+='<h2>'+g[t]+'</h2>';
  l.forEach(x=>{h+='<div class="p"><span title="'+x.n+'">'+x.n+'</span><input id="r_'+x.n+'" type="range" min="'+x.min+'" max="'+x.max+'" step="'+x.paso+'" value="'+x.v+'" oninput="$(\'n_'+x.n+'\').value=this.value;cambia(\''+t+'\',\''+x.n+'\',this.value)">'+
  '<input id="n_'+x.n+'" type="number" step="'+x.paso+'" value="'+x.v+'" onchange="$(\'r_'+x.n+'\').value=this.value;cambia(\''+t+'\',\''+x.n+'\',this.value)"><div class="d">'+x.d+'</div></div>'})});
 $('aj').innerHTML=h})}
carga(true);setInterval(()=>carga(false),3000);foto();
</script></body></html>)HTML";

static std::string query(const std::string& ruta, const std::string& k, const std::string& def) {
    size_t q = ruta.find('?');
    if (q == std::string::npos) return def;
    std::string s = "&" + ruta.substr(q + 1);
    size_t a = s.find("&" + k + "=");
    if (a == std::string::npos) return def;
    a += k.size() + 2;
    return s.substr(a, s.find('&', a) - a);
}

static void atender(int c) {
    std::string req;
    char b[8192];
    while (req.find("\r\n\r\n") == std::string::npos) {
        ssize_t n = recv(c, b, sizeof b, 0);
        if (n <= 0) break;
        req.append(b, n);
    }
    std::string l = req.substr(0, req.find("\r\n"));
    size_t a = l.find(' '), z = l.find(' ', a + 1);
    std::string ruta = a == std::string::npos ? "/" : l.substr(a + 1, z - a - 1);
    std::string cab, bin, extra;
    // ---- Instrumental Quest: la pagina vive en web/quest.html (se edita sin recompilar)
    if (ruta == "/quest" || ruta.compare(0, 7, "/quest?") == 0) {
        std::string html;
        FILE* f = fopen(aus::ruta("web/quest.html").c_str(), "rb");
        if (f) {
            char t[65536];
            size_t n;
            while ((n = fread(t, 1, sizeof t, f)) > 0) html.append(t, n);
            fclose(f);
        }
        responder(c, "text/html; charset=utf-8", html.empty() ? "falta web/quest.html" : html);
        close(c);
        return;
    }
    if (l.compare(0, 5, "POST ") == 0 && ruta.compare(0, 10, "/escenario") == 0) {   // guardar un escenario desde el editor
        size_t fin = req.find("\r\n\r\n");
        std::string cuerpo = fin == std::string::npos ? "" : req.substr(fin + 4);
        size_t largo = 0, cl = std::string::npos;
        for (const char* h : {"Content-Length:", "content-length:"})
            if (cl == std::string::npos) cl = req.find(h);
        if (cl != std::string::npos) largo = std::strtoul(req.c_str() + cl + 15, nullptr, 10);
        if (largo > 300000) largo = 0;
        while (cuerpo.size() < largo) {
            ssize_t n = recv(c, b, sizeof b, 0);
            if (n <= 0) break;
            cuerpo.append(b, n);
        }
        std::string id = query(ruta, "id", ""), hx;
        static const char* H = "0123456789abcdef";
        for (unsigned char ch : cuerpo) hx += H[ch >> 4], hx += H[ch & 15];
        bool ok = false;
        std::string msg = "sin nucleo";
        bool limpio = !id.empty();
        for (char ch : id)
            if (!(isalnum((unsigned char)ch) || ch == '_' || ch == '-')) limpio = false;
        if (!limpio) msg = "id no valido";
        else if (pedir("escenario escribir " + id + " " + hx, cab, bin, extra)) {
            ok = cab.compare(0, 3, "ok ") == 0 || cab == "ok";
            msg = cab.substr(cab.find(' ') == std::string::npos ? cab.size() : cab.find(' ') + 1);
        }
        responder(c, "application/json", std::string("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" + json_esc(msg) + "\"}");
        close(c);
        return;
    }
    if (ruta.compare(0, 7, "/estado") == 0) {
        std::string j = "{";
        if (pedir("estado", cab, bin, extra)) {
            size_t p = 0;
            std::string logs;
            while (p < extra.size()) {
                size_t e = extra.find('\n', p);
                std::string ln = extra.substr(p, e - p);
                p = e == std::string::npos ? extra.size() : e + 1;
                size_t q = ln.find('=');
                if (q == std::string::npos) continue;
                std::string k = ln.substr(0, q), v = ln.substr(q + 1);
                if (k == "log") logs += v + "\n";
                else j += "\"" + k + "\":\"" + json_esc(v) + "\",";
            }
            j += "\"log\":\"" + json_esc(logs) + "\"";
        }
        responder(c, "application/json", j + "}");
    } else if (ruta.compare(0, 9, "/foto.jpg") == 0) {
        std::string pl = "jpeg 70 " + query(ruta, "w", "640") + " " + query(ruta, "p", "0");
        if (pedir(pl, cab, bin, extra) && !bin.empty()) responder(c, "image/jpeg", bin);
        else responder(c, "text/plain", "sin imagen");
    } else if (ruta.compare(0, 8, "/ajustes") == 0) {
        std::string j = "[";
        if (pedir("ajustes", cab, bin, extra)) {
            size_t pos = 0;
            while (pos < extra.size()) {
                size_t e = extra.find('\n', pos);
                std::string l = extra.substr(pos, e - pos);
                pos = e == std::string::npos ? extra.size() : e + 1;
                std::vector<std::string> f;
                size_t a0 = 0, b0;
                while ((b0 = l.find('|', a0)) != std::string::npos && f.size() < 6) {
                    f.push_back(l.substr(a0, b0 - a0));
                    a0 = b0 + 1;
                }
                f.push_back(l.substr(a0));
                if (f.size() < 7) continue;
                j += std::string(j.size() > 1 ? "," : "") + "{\"t\":\"" + f[0] + "\",\"n\":\"" + json_esc(f[1]) + "\",\"v\":" + f[2] +
                     ",\"min\":" + f[3] + ",\"max\":" + f[4] + ",\"paso\":" + f[5] + ",\"d\":\"" + json_esc(f[6]) + "\"}";
            }
        }
        responder(c, "application/json", j + "]");
    } else if (ruta.compare(0, 4, "/lab") == 0) {
        responder(c, "text/html; charset=utf-8", LAB);
    } else if (ruta.compare(0, 7, "/cmd?c=") == 0) {
        std::string q = url_dec(ruta.substr(7));
        bool ok = pedir(q, cab, bin, extra);
        std::string msg = ok ? cab.substr(cab.find(' ') == std::string::npos ? cab.size() : cab.find(' ') + 1) : "sin nucleo";
        bool bien = ok && (cab.compare(0, 3, "ok ") == 0 || cab == "ok");
        responder(c, "application/json", std::string("{\"ok\":") + (bien ? "true" : "false") + ",\"msg\":\"" + json_esc(msg) + "\",\"extra\":\"" +
                                             json_esc(extra) + "\"}");
    } else {
        responder(c, "text/html; charset=utf-8", PAGINA);
    }
    close(c);
}

int main(int argc, char** argv) {
    int puerto = argc > 1 ? std::atoi(argv[1]) : 8091;
    if (getenv("AUSTERO_DIR")) aus::fijar_base(getenv("AUSTERO_DIR"));
    signal(SIGPIPE, SIG_IGN);
    int s = socket(AF_INET, SOCK_STREAM, 0), uno = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &uno, sizeof uno);
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_port = htons(puerto);
    a.sin_addr.s_addr = INADDR_ANY;
    if (bind(s, (sockaddr*)&a, sizeof a) != 0 || listen(s, 8) != 0) {
        fprintf(stderr, "no pude abrir el puerto %d\n", puerto);
        return 1;
    }
    fprintf(stdout, "austero-web en el puerto %d\n", puerto);
    fflush(stdout);
    while (true) {
        int c = accept(s, nullptr, nullptr);
        if (c < 0) continue;
        timeval tv{5, 0};
        setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
        std::thread(atender, c).detach();
    }
}
