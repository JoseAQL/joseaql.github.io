// escena.hpp - mesa simulada "como la de verdad", para probar sin camara (austero start --sim) y para la prueba
// de formas (austero-prueba-formas): pano verde-gris con pliegues y textura, instrumental de metal que REFLEJA el
// pano (poco contraste, como en tus fotos), aros con hueco, sombra, mano de color piel entrando por la orilla,
// vineta, cambios de luz y ruido de camara. Las medidas van en mm (tijera Mayo 170, bisturi 160, pinza 145).
#pragma once

#include <string>
#include <vector>

#include <opencv2/core.hpp>

namespace escena {

struct Obj {
    std::string tipo;        // tijera | tijera_curva | bisturi | pinza | mano
    double x = 0, y = 0, a = 0;   // centro (px de camara) y angulo (grados, hacia la punta)
    double apertura = 0;     // tijera: grados; pinza: mm entre puntas
    double brillo = 0.65;    // metal: que tanto refleja (0.4 oscuro .. 1.1 brillante)
};

cv::Mat mesa(int w, int h, cv::RNG& rng);   // reflectancia CV_32FC3 (~60-75)
// pinta el objeto sobre la reflectancia. etiqueta (CV_8U) opcional: escribe 'id' donde quedo el objeto
void pintar(cv::Mat& refl, const Obj& o, double px_por_mm, cv::RNG& rng, cv::Mat* etiqueta = nullptr, int id = 0);
// luz -> imagen de camara de 8 bits (con desenfoque leve y ruido)
cv::Mat camara(const cv::Mat& refl, const cv::Mat& luz, double ganancia, double ruido, cv::RNG& rng);
cv::Mat luz_pareja(int w, int h, double nivel, double vineta, double inclinacion);
Obj al_azar(const std::string& tipo, int w, int h, cv::RNG& rng);
double largo_mm(const std::string& tipo);

}  // namespace escena
