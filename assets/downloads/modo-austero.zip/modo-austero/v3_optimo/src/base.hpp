// base.hpp - lo minimo comun: tiempo, registro, archivos y configuracion clave=valor.
// Sin librerias externas. C++14 (gcc 7.5 de JetPack 4.6).
#pragma once

#include <map>
#include <string>
#include <vector>

namespace aus {

// carpeta del proyecto (la de austero.conf)
void fijar_base(const std::string& b);
std::string ruta(const std::string& rel);

double ahora();                  // segundos, reloj monotono
std::string hora();              // HH:MM:SS
std::string fecha();             // YYYYmmdd_HHMMSS
void dormir(double s);
std::string fmt(const char* f, ...);

void log(const std::string& m);
std::vector<std::string> ultimos_log(size_t n);

bool existe(const std::string& p);
bool crear_dirs(const std::string& p);
std::vector<std::string> listar(const std::string& dir);
std::vector<std::string> lineas(const std::string& p);
bool escribir(const std::string& p, const std::string& t);   // atomico (tmp + rename)
std::string slug(const std::string& s);

// ---------------------------------------------------------------- configuracion
// austero.conf (de fabrica) + perfiles/ajustes.conf (lo que cambias en vivo; tiene prioridad)
class Conf {
public:
    void cargar();
    std::string s(const std::string& k, const std::string& d = "") const;
    double d(const std::string& k, double def = 0) const;
    int i(const std::string& k, int def = 0) const;
    bool b(const std::string& k, bool def = false) const;
    void poner(const std::string& k, const std::string& v);   // guarda en ajustes.conf
    std::string todo() const;

private:
    std::map<std::string, std::string> v_, propios_;
    static void leer(const std::string& p, std::map<std::string, std::string>& m);
};

struct Crono {
    double t0;
    Crono() : t0(ahora()) {}
    double ms() const { return (ahora() - t0) * 1000.0; }
    double s() const { return ahora() - t0; }
};

}  // namespace aus
