#include "escena.hpp"

#include <algorithm>
#include <cmath>

#include <opencv2/imgproc.hpp>

namespace escena {

namespace {
struct Prim {
    std::vector<cv::Point2d> p;   // mm, coordenadas de la pieza (x hacia la punta)
    float tono;                    // 1 = normal; >1 brilla; <1 mas oscuro
    bool hueco;                    // borra (aros)
};
std::vector<cv::Point2d> elipse(double cx, double cy, double rx, double ry, double rot = 0, int n = 28) {
    std::vector<cv::Point2d> v;
    double c = std::cos(rot), s = std::sin(rot);
    for (int i = 0; i < n; i++) {
        double t = 2 * CV_PI * i / n, x = rx * std::cos(t), y = ry * std::sin(t);
        v.push_back({cx + x * c - y * s, cy + x * s + y * c});
    }
    return v;
}
// tira con ancho variable a lo largo de una linea central (x0..x1), y(x) y medio ancho(x)
template <class FY, class FW>
std::vector<cv::Point2d> tira(double x0, double x1, FY fy, FW fw, int n = 24) {
    std::vector<cv::Point2d> a, b;
    for (int i = 0; i <= n; i++) {
        double x = x0 + (x1 - x0) * i / n;
        a.push_back({x, fy(x) - fw(x)});
        b.push_back({x, fy(x) + fw(x)});
    }
    std::reverse(b.begin(), b.end());
    a.insert(a.end(), b.begin(), b.end());
    return a;
}
std::vector<cv::Point2d> girar(std::vector<cv::Point2d> v, cv::Point2d c, double ang) {
    double cs = std::cos(ang), sn = std::sin(ang);
    for (auto& p : v) {
        double x = p.x - c.x, y = p.y - c.y;
        p = {c.x + x * cs - y * sn, c.y + x * sn + y * cs};
    }
    return v;
}
double lerp(double a, double b, double t) { return a + (b - a) * std::max(0.0, std::min(1.0, t)); }

std::vector<Prim> partes(const Obj& o, cv::RNG& rng) {
    std::vector<Prim> r;
    if (o.tipo == "tijera" || o.tipo == "tijera_curva") {
        // Mayo 170 mm: punta en +85, perno en +15, aros en -62
        bool curva = o.tipo == "tijera_curva";
        cv::Point2d piv(15, 0);
        double ap = o.apertura * CV_PI / 180;
        for (int sg = -1; sg <= 1; sg += 2) {
            double rot = sg * ap / 2;
            auto fy = [&](double x) { return (curva ? 7.0 * std::pow((x - 15) / 70.0, 2) : 0.0) + sg * 0.6; };
            auto fw = [&](double x) { return lerp(3.6, 0.7, (x - 15) / 70.0); };
            r.push_back({girar(tira(13, 85, fy, fw), piv, rot), sg > 0 ? 1.15f : 0.95f, false});
            // brazo hasta el aro
            auto fy2 = [&](double x) { return sg * lerp(0.5, 9.0, (15 - x) / 63.0); };
            auto fw2 = [&](double x) { return lerp(3.0, 2.2, (15 - x) / 63.0); };
            r.push_back({girar(tira(-50, 17, fy2, fw2), piv, rot), 0.95f, false});
            // aro (oreja): por fuera 13x11, por dentro 9x7
            r.push_back({girar(elipse(-62, sg * 13.0, 13, 11, sg * 0.25), piv, rot), 1.0f, false});
            r.push_back({girar(elipse(-62, sg * 13.0, 9, 6.8, sg * 0.25), piv, rot), 1.0f, true});
        }
        r.push_back({elipse(15, 0, 5, 5), 1.25f, false});   // perno
    } else if (o.tipo == "bisturi") {
        // mango No.4 (120 mm) + hoja No.22 (40 mm)
        r.push_back({{{-80, -4.6}, {28, -4.6}, {34, -3.0}, {44, -3.0}, {44, 3.0}, {34, 3.0}, {28, 4.6}, {-80, 4.6}, {-82, 3}, {-82, -3}}, 0.9f, false});
        r.push_back({{{40, -3.0}, {46, -4.4}, {58, -4.9}, {69, -3.8}, {77, -1.6}, {81, 0.6}, {72, 2.4}, {56, 3.0}, {40, 3.0}}, 1.45f, false});
    } else if (o.tipo == "pinza") {
        // diseccion 145 mm: union atras en -72, puntas en +73 separadas 'apertura' mm
        double ap = o.apertura;
        r.push_back({elipse(-67, 0, 6, 4.4), 1.0f, false});
        for (int sg = -1; sg <= 1; sg += 2) {
            auto g = [&](double x) { return ap * (x + 64) / 137.0; };
            auto fw = [&](double x) { return x < 15 ? lerp(2.1, 2.6, (x + 64) / 79.0) : lerp(2.6, 0.5, (x - 15) / 58.0); };
            auto fy = [&](double x) { return sg * (g(x) / 2 + fw(x)); };
            r.push_back({tira(-68, 73, fy, fw), sg > 0 ? 1.1f : 0.9f, false});
        }
    } else if (o.tipo == "mano") {
        // palma + 4 dedos + pulgar + antebrazo que sale de la imagen (x hacia los dedos)
        r.push_back({elipse(0, 0, 48, 42), 1.0f, false});
        double L[4] = {62, 72, 68, 54}, Y[4] = {-27, -9, 9, 26};
        double abre = rng.uniform(-0.1, 0.25);
        for (int i = 0; i < 4; i++) {
            double ang = (Y[i] / 30.0) * abre;
            auto f = tira(30, 30 + L[i], [&](double) { return Y[i]; }, [&](double x) { return lerp(9.0, 7.0, (x - 30) / L[i]); });
            f = girar(f, {30, Y[i]}, ang);
            auto u = elipse(30 + L[i] * std::cos(ang), Y[i] + L[i] * std::sin(ang), 7, 7);
            r.push_back({f, 1.0f, false});
            r.push_back({u, 1.0f, false});
        }
        auto pul = tira(0, 58, [](double) { return 0.0; }, [](double) { return 9.5; });
        r.push_back({girar(pul, {0, 0}, 1.0), 1.0f, false});
        for (auto& p : r.back().p) p += cv::Point2d(5, 32);
        r.push_back({tira(-400, -20, [](double) { return 0.0; }, [](double x) { return lerp(34, 38, (-x - 20) / 380); }), 0.92f, false});
    }
    return r;
}
}  // namespace

double largo_mm(const std::string& t) {
    if (t.find("tijera") == 0) return 170;
    if (t == "bisturi") return 160;
    if (t == "pinza") return 145;
    return 200;
}

cv::Mat mesa(int w, int h, cv::RNG& rng) {
    cv::Vec3f base(rng.uniform(56.f, 64.f), rng.uniform(67.f, 74.f), rng.uniform(58.f, 65.f));   // verde-gris
    cv::Mat m(h, w, CV_32FC3, cv::Scalar(base[0], base[1], base[2]));
    // manchas grandes
    cv::Mat r(h / 16 + 1, w / 16 + 1, CV_32F);
    rng.fill(r, cv::RNG::NORMAL, 0, 2.5);
    cv::resize(r, r, cv::Size(w, h), 0, 0, cv::INTER_CUBIC);
    // pliegues: bandas suaves (un lado oscuro, el otro claro)
    cv::Mat pl = cv::Mat::zeros(h, w, CV_32F);
    int np = rng.uniform(3, 8);
    for (int k = 0; k < np; k++) {
        double px = rng.uniform(0, w), py = rng.uniform(0, h), an = rng.uniform(0., CV_PI), sg = rng.uniform(5., 16.),
               A = rng.uniform(3., 9.);
        double nx = -std::sin(an), ny = std::cos(an);
        for (int y = 0; y < h; y++) {
            float* q = pl.ptr<float>(y);
            for (int x = 0; x < w; x++) {
                double d = (x - px) * nx + (y - py) * ny;
                if (std::fabs(d) < 4 * sg) q[x] += (float)(-A * d / sg * std::exp(-d * d / (2 * sg * sg)));
            }
        }
    }
    // tejido (fino)
    cv::Mat t(h, w, CV_32F);
    rng.fill(t, cv::RNG::NORMAL, 0, 1.2);
    cv::Mat s = r + pl + t, s3;
    cv::merge(std::vector<cv::Mat>{s, s, s}, s3);
    m += s3;
    return m;
}

cv::Mat luz_pareja(int w, int h, double nivel, double vineta, double incl) {
    cv::Mat l(h, w, CV_32FC3);
    for (int y = 0; y < h; y++) {
        cv::Vec3f* q = l.ptr<cv::Vec3f>(y);
        for (int x = 0; x < w; x++) {
            double dx = (x - w / 2.0) / (w / 2.0), dy = (y - h / 2.0) / (h / 2.0);
            float v = (float)(nivel * (1 - vineta * (dx * dx + dy * dy) / 2) * (1 + incl * dx));
            q[x] = cv::Vec3f(v, v, v);
        }
    }
    return l;
}

void pintar(cv::Mat& refl, const Obj& o, double ppm, cv::RNG& rng, cv::Mat* et, int id) {
    auto ps = partes(o, rng);
    if (ps.empty()) return;
    double a = o.a * CV_PI / 180, c = std::cos(a), s = std::sin(a);
    const int SS = 4;
    double x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (auto& p : ps)
        for (auto& q : p.p) {
            double X = o.x + ppm * (q.x * c - q.y * s), Y = o.y + ppm * (q.x * s + q.y * c);
            q = {X, Y};
            x0 = std::min(x0, X), y0 = std::min(y0, Y), x1 = std::max(x1, X), y1 = std::max(y1, Y);
        }
    cv::Rect R((int)std::floor(x0) - 4, (int)std::floor(y0) - 4, 0, 0);
    R.width = (int)std::ceil(x1) + 4 - R.x;
    R.height = (int)std::ceil(y1) + 4 - R.y;
    cv::Rect img(0, 0, refl.cols, refl.rows), Ri = R & img;
    if (Ri.area() <= 0) return;
    R = Ri;
    cv::Mat al = cv::Mat::zeros(R.height * SS, R.width * SS, CV_8U), to = cv::Mat::zeros(al.size(), CV_8U);
    for (auto& p : ps) {
        std::vector<cv::Point> v;
        for (auto& q : p.p) v.push_back(cv::Point((int)std::lround((q.x - R.x) * SS), (int)std::lround((q.y - R.y) * SS)));
        std::vector<std::vector<cv::Point>> vv{v};
        cv::fillPoly(al, vv, cv::Scalar(p.hueco ? 0 : 255), cv::LINE_AA);
        if (!p.hueco) cv::fillPoly(to, vv, cv::Scalar(std::min(255.f, p.tono * 100)), cv::LINE_8);
    }
    cv::Mat A, T;
    cv::resize(al, A, R.size(), 0, 0, cv::INTER_AREA);
    cv::resize(to, T, R.size(), 0, 0, cv::INTER_AREA);
    A.convertTo(A, CV_32F, 1 / 255.0);
    T.convertTo(T, CV_32F, 1 / 100.0);
    bool mano = o.tipo == "mano";
    // sombra suave desplazada (la luz viene de arriba-izquierda)
    cv::Mat sh;
    cv::GaussianBlur(A, sh, cv::Size(0, 0), mano ? 4 : 1.6);
    cv::Mat roi = refl(R);
    int dx = mano ? 5 : 2, dy = mano ? 6 : 2;
    for (int y = 0; y < R.height; y++)
        for (int x = 0; x < R.width; x++) {
            int sy = y - dy, sx = x - dx;
            if (sy < 0 || sx < 0) continue;
            float k = sh.at<float>(sy, sx) * (mano ? 0.35f : 0.22f);
            roi.at<cv::Vec3f>(y, x) *= (1 - k);
        }
    // metal: refleja el pano (tinte verde) + gris propio; mano: piel
    cv::Vec3f piel(rng.uniform(40.f, 50.f), rng.uniform(50.f, 58.f), rng.uniform(66.f, 76.f));
    float gris = 58;
    for (int y = 0; y < R.height; y++)
        for (int x = 0; x < R.width; x++) {
            float al_ = A.at<float>(y, x);
            if (al_ <= 0.002f) continue;
            float t = T.at<float>(y, x) / std::max(al_, 0.05f);
            cv::Vec3f& p = roi.at<cv::Vec3f>(y, x);
            cv::Vec3f col;
            if (mano) col = piel * (0.9f + 0.1f * t);
            else {
                cv::Vec3f g(gris, gris, gris);
                col = (p * 0.55f + g * 0.45f) * (float)o.brillo * t;
            }
            p = p * (1 - al_) + col * al_;
            if (et && al_ > 0.5f) et->at<uchar>(R.y + y, R.x + x) = (uchar)id;
        }
}

cv::Mat camara(const cv::Mat& refl, const cv::Mat& luz, double g, double ruido, cv::RNG& rng) {
    cv::Mat img = refl.mul(luz) * g;
    cv::GaussianBlur(img, img, cv::Size(0, 0), 0.6);
    cv::Mat n(img.size(), CV_32FC3);
    rng.fill(n, cv::RNG::NORMAL, 0, ruido);
    img += n;
    cv::Mat o;
    img.convertTo(o, CV_8UC3);
    return o;
}

Obj al_azar(const std::string& tipo, int w, int h, cv::RNG& rng) {
    Obj o;
    o.tipo = tipo;
    o.x = rng.uniform(0.18, 0.82) * w;
    o.y = rng.uniform(0.2, 0.8) * h;
    o.a = rng.uniform(0., 360.);
    o.brillo = rng.uniform(0.45, 1.05);
    if (tipo.find("tijera") == 0) o.apertura = rng.uniform(0., 1.) < 0.6 ? rng.uniform(0., 3.) : rng.uniform(3., 22.);
    if (tipo == "pinza") o.apertura = rng.uniform(0., 1.) < 0.15 ? rng.uniform(0., 2.) : rng.uniform(4., 13.);   // en reposo abre 5-12 mm
    return o;
}

}  // namespace escena
