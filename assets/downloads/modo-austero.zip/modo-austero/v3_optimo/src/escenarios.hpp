// escenarios.hpp - "Instrumental Quest": rutinas tipo videojuego proyectadas sobre la mesa.
//
//   Escenario (nivel)  = una rutina completa, p. ej. "Charola de cirugia menor"   -> escenarios/<id>.esc
//   Tareas 1..N        = el camino del nivel; la ultima suele ser la FINAL (revisa todo)
//   Zonas              = lugares de la mesa (L1, L2...) en pixeles del proyector
//   Silueta            = donde va la pieza (se graba poniendo la pieza real: "grabar haciendo")
//
// Cada tarea pasa cuando TODAS sus condiciones se cumplen con la mesa quieta un momento:
//   pieza <tipo> <zona>      una pieza de ese tipo (tijera, bisturi, pinza... o el nombre que ensenaste) en la zona
//   vacio <zona> [zona...]   no hay piezas ahi
//   conteo <tipo> <n> [zona] exactamente n piezas de ese tipo
//   espera <s>               pasan s segundos
//   confirmar                alguien escribe "austero escenario ok" (o tecla en el tablero)
// Si en la zona de una "pieza" queda OTRA pieza -> error (se proyecta en rojo y se cuenta).
//
// Zonas PROHIBIDAS (campo esteril, charola ya revisada...): si una mano entra, la zona parpadea en rojo,
// sale "RETIRA LA MANO", la tarea no avanza y cuenta como falta (baja estrellas):
//   prohibida <nombre> = x y ancho alto      rectangulo
//   linea <nombre> = x1 y1 x2 y2             raya que la mano no debe cruzar
#pragma once

#include <map>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

namespace quest {

struct Cond {
    std::string tipo;                 // pieza | vacio | conteo | espera | confirmar
    std::string pieza;                // tipo de pieza (minusculas)
    std::vector<std::string> zonas;
    double n = 0;
    std::string texto() const;
};

struct Tarea {
    std::string nombre, instruccion;
    std::vector<Cond> pasa;
    std::string silueta_tipo;
    std::vector<cv::Point> silueta;   // proyector
    double tiempo_max = 0;            // 0 = sin limite
};

struct Prohibida {
    std::string nombre;
    cv::Rect r;                // si es zona
    cv::Point a, b;            // si es linea
    bool linea = false;
};

struct Escenario {
    std::string id, nombre, archivo;
    int orden = 0;
    double estrellas3 = 0, estrellas2 = 0;   // segundos totales para 3 y 2 estrellas (0 = automatico)
    std::vector<std::pair<std::string, cv::Rect>> zonas;
    std::vector<Tarea> tareas;
    std::vector<Prohibida> prohibidas;
    const cv::Rect* zona(const std::string& z) const;
};

// lo que ve la camara, ya pasado a coordenadas del proyector
struct PiezaP {
    std::string tipo;    // tijera | bisturi | pinza | mano | objeto | (nombre ensenado en minusculas)
    std::string clase;   // como la nombra el modelo
    std::vector<cv::Point> poli;
    cv::Point2f centro;
};

struct Record {
    double mejor = 0;
    int estrellas = 0, intentos = 0, completos = 0;
};

class Juego {
public:
    // ---- archivos
    void cargar(const std::string& dir);   // lee todos los .esc
    bool guardar(const Escenario& e) const;
    std::vector<Escenario> lista;
    std::map<std::string, Record> records;
    Escenario* buscar(const std::string& id_o_numero);
    bool bloqueado(const Escenario& e) const;
    Escenario& nuevo(const std::string& nombre);
    // ---- para la pagina web (/quest)
    std::string json(const Escenario& e) const;   // un escenario completo
    std::string json_lista() const;               // todos, resumidos (mapa de niveles)
    std::string json_juego() const;               // estado fino del juego en curso
    // recibe el texto .esc que arma el editor, lo valida y lo guarda con el formato de siempre
    bool escribir(const std::string& id, const std::string& texto, int ancho, int alto, std::string& msg);
    bool borrar(const std::string& id, std::string& msg);          // lo renombra a .borrado (no se pierde)
    bool duplicar(const std::string& id, const std::string& nombre, std::string& msg);
    std::string historial(int n = 50) const;      // ultimas partidas: fecha|id|tiempo|estrellas|errores|faltas

    // ---- jugar
    bool activo() const { return jugando; }
    bool empezar(const std::string& id, std::string& msg, bool forzar = false);
    void parar(const std::string& porque = "");
    void saltar(int d);
    void confirmar() { confirmado = true; }
    void pausa(bool p);
    // cada cuadro (o cada vuelta del lazo): piezas en el proyector, si la mesa esta quieta, tiempo
    // devuelve true si cambio algo que haya que redibujar
    bool evaluar(const std::vector<PiezaP>& ps, bool quieto, double t);
    void dibujar(cv::Mat& lienzo, double t) const;
    std::string firma(double t) const;
    std::string estado() const;   // lineas clave=valor para el tablero / web

    // ---- grabar haciendo: cada vez que la mesa se queda quieta con una pieza NUEVA, se vuelve una tarea
    bool grabando = false;
    std::string grab_id;
    void grabar_empezar(Escenario& e, const std::vector<PiezaP>& ps);
    bool grabar_evaluar(const std::vector<PiezaP>& ps, bool quieto, double t, std::string& aviso);
    std::string grabar_terminar();

    std::string dir;
    double quieto_s = 1.0;   // la mesa debe estar quieta esto para dar por buena una tarea
    std::vector<std::string> avisos;   // para el log del nucleo

private:
    bool jugando = false, pausado = false, confirmado = false;
    Escenario* esc = nullptr;
    int k = 0, errores = 0, faltas = 0;
    std::vector<std::string> invadidas;   // prohibidas con mano encima ahora
    double t_falta = -10;
    double t0 = 0, t_tarea = 0, t_ok = 0, t_bien = -10, t_fin = -10, t_pausa = 0, t_quieto0 = 0;
    bool cumple = false, en_error = false, fin = false;
    int estrellas_fin = 0;
    double tiempo_fin = 0;
    bool record_nuevo = false;
    std::string msg_error, zona_error;
    std::vector<bool> hecho_cond;   // por condicion de la tarea actual (para pintar en verde)
    std::vector<PiezaP> ult;
    // grabacion
    std::vector<PiezaP> grab_base, grab_cand;
    bool grab_mov = false;
    double grab_t_cand = 0;
    void guardar_records() const;
    void cargar_records();
};

std::string tipo_pieza(const std::string& clase);   // "Tijera Mayo 80%" -> "tijera"
std::string sin_acentos(const std::string& s);

}  // namespace quest
