// cliente.cpp - austero-cli: manda comandos al nucleo y trae el tablero de terminal (austero ver).
// Programa aparte y chico (sin OpenCV): si no lo abres, no gasta nada. Salir con q NO apaga el nucleo.
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <termios.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <mutex>
#include <sstream>
#include <thread>

#include "base.hpp"

using aus::fmt;

struct Respuesta {
    bool ok = false;
    std::string msg, extra;
    std::string bin;
};

static std::string sock() {
    const char* s = getenv("AUSTERO_SOCKET");
    return s ? s : "/tmp/austero.sock";
}

static Respuesta enviar(const std::string& linea, int timeout = 900) {
    int s = socket(AF_UNIX, SOCK_STREAM, 0);
    sockaddr_un a{};
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, sock().c_str(), sizeof(a.sun_path) - 1);
    if (connect(s, (sockaddr*)&a, sizeof a) != 0) {
        close(s);
        throw std::runtime_error("el nucleo no esta corriendo (austero start)");
    }
    timeval tv{timeout, 0};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    std::string l = linea + "\n";
    send(s, l.data(), l.size(), MSG_NOSIGNAL);
    std::string t;
    char b[65536];
    ssize_t n;
    while ((n = recv(s, b, sizeof b, 0)) > 0) t.append(b, n);
    close(s);
    Respuesta r;
    size_t e = t.find('\n');
    if (e == std::string::npos) throw std::runtime_error("respuesta vacia del nucleo");
    std::string cab = t.substr(0, e);
    r.ok = cab.compare(0, 2, "ok") == 0;
    r.msg = cab.substr(cab.find(' ') == std::string::npos ? cab.size() : cab.find(' ') + 1);
    std::string resto = t.substr(e + 1);
    if (resto.compare(0, 4, "bin ") == 0) {
        size_t e2 = resto.find('\n');
        size_t nb = std::stoul(resto.substr(4, e2 - 4));
        r.bin = resto.substr(e2 + 1, nb);
        resto = resto.substr(e2 + 1 + nb);
    }
    r.extra = resto;
    return r;
}

static std::map<std::string, std::string> claves(const std::string& t) {
    std::map<std::string, std::string> m;
    std::stringstream ss(t);
    std::string l;
    while (std::getline(ss, l)) {
        size_t e = l.find('=');
        if (e == std::string::npos) continue;
        std::string k = l.substr(0, e);
        if (k == "log") m["log"] += l.substr(e + 1) + "\n";
        else m[k] = l.substr(e + 1);
    }
    return m;
}
static std::vector<std::string> partir(const std::string& s, char sep) {
    std::vector<std::string> r;
    std::stringstream ss(s);
    std::string x;
    while (std::getline(ss, x, sep))
        if (!x.empty()) r.push_back(x);
    return r;
}

// ====================================================================== tablero
static std::string col(int c) { return fmt("\x1b[38;5;%dm", c); }
static const std::string RESET = "\x1b[0m", NEG = "\x1b[1m", TEN = "\x1b[2m";
static const std::string VERDE = col(82), AMAR = col(220), ROJO = col(196), CIAN = col(45), GRIS = col(244), MAG = col(207);

static std::string barra(double p, int an = 12) {
    if (p < 0) return GRIS + std::string(an, '.') + RESET;
    p = std::max(0.0, std::min(100.0, p));
    int n = (int)std::lround(p / 100 * an);
    std::string s = p < 60 ? VERDE : (p < 85 ? AMAR : ROJO);
    for (int i = 0; i < an; i++) s += i < n ? "█" : (i == n ? GRIS + "░" : "░");
    return s + RESET;
}
static std::string onoff(const std::string& v) { return v == "1" ? VERDE + "on" + RESET : GRIS + "off" + RESET; }

static const std::string VERDE_J = "\x1b[32m", ROJO_J = "\x1b[31m";
static const char* AYUDA[] = {
    "q salir  Q apagar núcleo  1-9 modelo  0 ninguno  a auto-ajuste  c calibrar  C método  v verificar  m mm",
    "h manos  i vista  b buscar  f fondo  o marcas  e enseñar  t guardar al dataset  s foto  w web  B benchmark  L LABORATORIO",
    "[ ] umbral  ( ) nms  { } tamaño YOLO  P perfil de energía (max/normal/5w)",
    "ESCENARIOS: j jugar  J parar  g grabar  G listo  k ok (confirmar)  n siguiente tarea  p pausa/seguir"};

struct Tablero {
    std::atomic<bool> vivo{true}, vista{false}, ocupado{false}, lab{false};
    bool pausado_juego = false;
    // laboratorio
    struct Ajuste {
        std::string tipo, nombre, desc;
        double valor, min, max, paso;
    };
    std::vector<Ajuste> ajustes;
    int sel = 0, lab_panel = 5;
    std::string lab_info;
    std::mutex mx;
    std::map<std::string, std::string> e;
    std::string mensaje, tabla, err, vbuf;
    int vw = 0, vh = 0;
    termios viejo{};
    bool truecolor = false;

    void mandar(const std::string& l) {
        std::thread([this, l]() {
            ocupado = true;
            try {
                Respuesta r = enviar(l);
                std::lock_guard<std::mutex> k(mx);
                mensaje = r.msg.empty() ? (r.ok ? "ok" : "error") : r.msg;
                if (l.compare(0, 5, "bench") == 0) tabla = r.extra;
            } catch (const std::exception& x) {
                std::lock_guard<std::mutex> k(mx);
                mensaje = std::string("error: ") + x.what();
            }
            ocupado = false;
        }).detach();
    }
    void crudo() {
        termios t = viejo;
        t.c_lflag &= ~(ICANON | ECHO);
        t.c_cc[VMIN] = 0;
        t.c_cc[VTIME] = 0;
        tcsetattr(0, TCSADRAIN, &t);
    }
    std::string preguntar(const std::string& t) {
        tcsetattr(0, TCSADRAIN, &viejo);
        std::cout << "\x1b[?25h\n" << NEG << t << RESET << std::flush;
        std::string r;
        std::getline(std::cin, r);
        crudo();
        std::cout << "\x1b[?25l";
        return r;
    }
    std::string tecla() {
        fd_set f;
        FD_ZERO(&f);
        FD_SET(0, &f);
        timeval tv{0, 250000};
        if (select(1, &f, nullptr, nullptr, &tv) <= 0) return "";
        char ch;
        if (read(0, &ch, 1) != 1) return "";
        if (ch != 0x1b) return std::string(1, ch);
        FD_ZERO(&f);
        FD_SET(0, &f);
        timeval t2{0, 30000};
        char s[2] = {0, 0};
        if (select(1, &f, nullptr, nullptr, &t2) > 0 && read(0, s, 2) == 2 && s[0] == '[') {
            if (s[1] == 'A') return "ARRIBA";
            if (s[1] == 'B') return "ABAJO";
            if (s[1] == 'C') return "DER";
            if (s[1] == 'D') return "IZQ";
        }
        return "ESC";
    }

    void atender(const std::string& k) {
        bool ens;
        {
            std::lock_guard<std::mutex> g(mx);
            ens = e.count("ensenando") > 0;
        }
        if (ens) {
            if (k == "ARRIBA") return mandar("ensenar mover 0 -1");
            if (k == "ABAJO") return mandar("ensenar mover 0 1");
            if (k == "IZQ") return mandar("ensenar mover -1 0");
            if (k == "DER") return mandar("ensenar mover 1 0");
            if (k == "+" || k == "=") return mandar("ensenar tam 1 1");
            if (k == "-") return mandar("ensenar tam -1 -1");
            if (k == "*") return mandar("ensenar tam 1 0");
            if (k == "/") return mandar("ensenar tam -1 0");
            if (k == "\n" || k == "\r") return mandar("ensenar guardar");
            if (k == "x") return mandar("ensenar auto");
            if (k == "ESC") return mandar("ensenar cancelar");
        }
        if (lab) {
            std::lock_guard<std::mutex> g(mx);
            int n = (int)ajustes.size();
            if (k == "ARRIBA" && n) sel = (sel + n - 1) % n;
            else if (k == "ABAJO" && n) sel = (sel + 1) % n;
            else if ((k == "IZQ" || k == "DER" || k == "-" || k == "+") && n) {
                const Ajuste& a = ajustes[sel];
                std::string sg = (k == "DER" || k == "+") ? "+" : "-";
                if (a.tipo == "f") mandar("filtro " + a.nombre + " " + sg);
                else if (a.tipo == "c") mandar("cam " + a.nombre + " " + sg);
                else {
                    double v = a.valor + (sg == "+" ? a.paso : -a.paso);
                    mandar(a.nombre == "entrada" ? "param entrada " + sg : fmt("param %s %g", a.nombre.c_str(), std::max(a.min, std::min(a.max, v))));
                }
            } else if (k.size() == 1 && k[0] >= '1' && k[0] <= '5') lab_panel = k[0] - '0';
            else if (k == "\n" || k == "\r") {
                if (n) {
                    Ajuste a = ajustes[sel];
                    mx.unlock();
                    std::string v = preguntar("Valor para " + a.nombre + fmt(" (%g a %g): ", a.min, a.max));
                    mx.lock();
                    if (!v.empty()) mandar((a.tipo == "f" ? "filtro " : (a.tipo == "c" ? "cam " : "param ")) + a.nombre + " " + v);
                }
            } else if (k == "R") mandar("filtro reset");
            else if (k == "a") mandar("autoajuste");
            else if (k == "f") mandar("fondo");
            else if (k == "L" || k == "ESC" || k == "q") lab = false;
            return;
        }
        if (k == "q") vivo = false;
        else if (k == "L") {
            lab = true;
            mensaje = "LABORATORIO: flechas arriba/abajo eligen, izquierda/derecha cambian, 1-5 vista, Enter = escribir valor";
        } else if (k == "Q") {
            mandar("apagar");
            aus::dormir(0.3);
            vivo = false;
        } else if (k.size() == 1 && isdigit((unsigned char)k[0])) mandar("modelo " + k);
        else if (k == "a") mandar("autoajuste");
        else if (k == "c") mandar("calibrar");
        else if (k == "C") mandar("calibrar " + preguntar("Método [aruco|puntos|esquinas|graycode]: "));
        else if (k == "v") mandar("verificar");
        else if (k == "m") mandar("mm");
        else if (k == "h") mandar("manos");
        else if (k == "b") mandar("buscar");
        else if (k == "o") mandar("marcas");
        else if (k == "f") mandar("fondo");
        else if (k == "t") mandar("confirmar");
        else if (k == "j") {
            mandar("escenario lista");
            std::string n = preguntar("Escenario a jugar (numero o nombre): ");
            if (!n.empty()) mandar("escenario jugar \"" + n + "\"");
        } else if (k == "J") mandar("escenario parar");
        else if (k == "g") {
            std::string n = preguntar("Nombre del escenario a grabar (mesa vacia): ");
            if (!n.empty()) mandar("escenario grabar \"" + n + "\"");
        } else if (k == "G") mandar("escenario listo");
        else if (k == "k") mandar("escenario ok");
        else if (k == "n") mandar("escenario sig");
        else if (k == "p") {
            pausado_juego = !pausado_juego;
            mandar(pausado_juego ? "escenario pausa" : "escenario seguir");
        }
        else if (k == "s") mandar("foto");
        else if (k == "i") vista = !vista;
        else if (k == "w") {
            // prender la web con el script de la carpeta del proyecto (no depende del PATH)
            const char* d = getenv("AUSTERO_DIR");
            std::string cmd = std::string(d ? d : ".") + "/austero web on 2>&1";
            FILE* f = popen(cmd.c_str(), "r");
            std::string sal;
            char b[256];
            while (f && fgets(b, sizeof b, f)) sal += b;
            if (f) pclose(f);
            while (!sal.empty() && (sal.back() == '\n' || sal.back() == ' ')) sal.pop_back();
            mensaje = sal.empty() ? "no pude prender la web: sal con q y escribe  austero web on" : sal + "   (laboratorio: /lab)";
        } else if (k == "e") {
            std::string n = preguntar("¿Qué pieza le vas a enseñar? (ej. tijera mayo): ");
            if (!n.empty()) mandar("ensenar \"" + n + "\"");
        } else if (k == "[" || k == "]") mandar(std::string("param umbral ") + (k == "[" ? "-0.05" : "+0.05") + " rel");
        else if (k == "(" || k == ")") mandar(std::string("param nms ") + (k == "(" ? "-0.05" : "+0.05") + " rel");
        else if (k == "{" || k == "}") mandar(std::string("param entrada ") + (k == "{" ? "-" : "+"));
        else if (k == "B") {
            std::string s = preguntar("Segundos por modelo [15]: ");
            std::string ids = preguntar("Modelos (teclas o ids separados por espacio; Enter = todos): ");
            {
                std::lock_guard<std::mutex> g(mx);
                tabla.clear();
            }
            mandar("bench " + ids + (s.empty() ? "" : " --seg " + s));
        } else if (k == "P") {
            std::string p = preguntar("Perfil de energía [max|normal|5w]: ");
            if (!p.empty()) mandar("perfil " + p);
        }
    }

    void pedir() {
        while (vivo) {
            try {
                auto m = claves(enviar("estado", 3).extra);
                std::string vb;
                int w = 0, h = 0;
                std::vector<Ajuste> aj;
                std::string info;
                if (lab) {
                    std::stringstream ss(enviar("ajustes", 3).extra);
                    std::string l;
                    while (std::getline(ss, l)) {
                        std::vector<std::string> c;
                        std::stringstream q(l);
                        std::string x;
                        while (std::getline(q, x, '|')) c.push_back(x);
                        if (c.size() >= 7)
                            aj.push_back({c[0], c[1], c[6], std::atof(c[2].c_str()), std::atof(c[3].c_str()), std::atof(c[4].c_str()),
                                          std::atof(c[5].c_str())});
                    }
                }
                if (vista || lab) {
                    winsize ws{};
                    ioctl(1, TIOCGWINSZ, &ws);
                    int cols = ws.ws_col ? ws.ws_col : 100, filas = ws.ws_row ? ws.ws_row : 40;
                    int aw = lab ? std::max(30, std::min(cols - 58, 100)) : std::min(cols - 2, 110);
                    int ah = lab ? std::max(8, std::min(filas - 8, aw * 3 / 8)) : std::max(6, std::min(filas - 20, aw * 3 / 8));
                    Respuesta r = enviar(fmt("vista %d %d %d", aw, ah, lab ? lab_panel : 0), 3);
                    if (r.ok && sscanf(r.msg.c_str(), "%d %d", &w, &h) == 2) {
                        vb = r.bin;
                        size_t p2 = r.msg.find(' ', r.msg.find(' ') + 1);
                        info = p2 == std::string::npos ? "" : r.msg.substr(p2 + 1);
                    }
                }
                std::lock_guard<std::mutex> g(mx);
                e = m;
                err.clear();
                if (lab) {
                    ajustes = aj;
                    if (sel >= (int)ajustes.size()) sel = 0;
                    lab_info = info;
                }
                if (!vb.empty()) {
                    vbuf = vb;
                    vw = w;
                    vh = h;
                }
            } catch (const std::exception& x) {
                std::lock_guard<std::mutex> g(mx);
                err = x.what();
            }
            aus::dormir(lab ? 0.3 : (vista ? 0.4 : 1.0));
        }
    }

    static int c256(int r, int g, int b) {
        if (std::abs(r - g) < 10 && std::abs(g - b) < 10) return 232 + std::min(23, r * 24 / 256);
        return 16 + 36 * (r * 6 / 256) + 6 * (g * 6 / 256) + (b * 6 / 256);
    }

    std::vector<std::string> lineas_vista() {
        std::vector<std::string> out;
        for (int y = 0; y + 1 < vh && (int)vbuf.size() >= vw * vh * 3; y += 2) {
            std::string f = " ";
            for (int x = 0; x < vw; x++) {
                const unsigned char* a = (const unsigned char*)&vbuf[(y * vw + x) * 3];
                const unsigned char* b = (const unsigned char*)&vbuf[((y + 1) * vw + x) * 3];
                if (truecolor) f += fmt("\x1b[38;2;%d;%d;%dm\x1b[48;2;%d;%d;%dm▀", a[2], a[1], a[0], b[2], b[1], b[0]);
                else f += fmt("\x1b[38;5;%dm\x1b[48;5;%dm▀", c256(a[2], a[1], a[0]), c256(b[2], b[1], b[0]));
            }
            out.push_back(f + RESET);
        }
        return out;
    }

    void dibujar_lab(int cols, int filas) {
        std::vector<std::string> L;
        auto v = [&](const char* k) { return e.count(k) ? e[k] : std::string(); };
        const char* nom[] = {"lo que ve la red", "1 camara", "2 lo que ve la red", "3 mascara", "4 bordes y esquinas", "5 las 4 juntas"};
        L.push_back(NEG + CIAN + " LABORATORIO " + RESET + GRIS + "vista: " + RESET + nom[lab_panel] + GRIS + "   modelo " + RESET + v("modelo") +
                    GRIS + fmt("  CPU %s%%  GPU %s%%  núcleo %s MB", v("cpu_prom").c_str(), v("gpu").c_str(), v("proc_ram_mb").c_str()) + RESET);
        L.push_back(" " + AMAR + lab_info.substr(0, cols - 2) + RESET);
        std::vector<std::string> izq = lineas_vista();
        if (izq.empty()) izq.push_back(GRIS + "  (esperando imagen...)" + RESET);
        // lista de ajustes con ventana alrededor del elegido
        int alto = std::max((int)izq.size(), std::min(filas - 7, (int)ajustes.size()));
        int ini = std::max(0, std::min(sel - alto / 2, (int)ajustes.size() - alto));
        std::vector<std::string> der;
        std::string grupo;
        for (int i2 = ini; i2 < (int)ajustes.size() && (int)der.size() < alto; i2++) {
            const Ajuste& a = ajustes[i2];
            double fr = a.max > a.min ? (a.valor - a.min) / (a.max - a.min) : 0;
            int n = (int)std::lround(std::max(0.0, std::min(1.0, fr)) * 10);
            std::string barra_ = std::string(n, '#') + std::string(10 - n, '.');
            std::string t = a.tipo == "f" ? "filtro" : (a.tipo == "c" ? "camara" : "modelo");
            std::string lin = fmt("%-6s %-18s %8g [%s]", t.c_str(), a.nombre.substr(0, 18).c_str(), a.valor, barra_.c_str());
            der.push_back(i2 == sel ? NEG + AMAR + "> " + lin + RESET : "  " + GRIS + lin + RESET);
        }
        size_t filas_t = std::max(izq.size(), der.size());
        for (size_t r = 0; r < filas_t; r++) {
            std::string a = r < izq.size() ? izq[r] : std::string(vw + 1, ' ');
            if (r >= izq.size()) a = std::string(vw + 1, ' ');
            L.push_back(a + "  " + (r < der.size() ? der[r] : ""));
        }
        if (sel < (int)ajustes.size()) L.push_back(" " + CIAN + ajustes[sel].nombre + ": " + RESET + ajustes[sel].desc.substr(0, cols - 4));
        if (!mensaje.empty()) L.push_back(" " + AMAR + "» " + mensaje.substr(0, cols - 4) + RESET);
        L.push_back(" " + GRIS + "flechas ↑↓ elegir  ←→ cambiar  Enter escribir valor  1-5 vista  a auto-ajuste  f fondo  R filtros de fabrica  L/q salir" + RESET);
        std::string out = "\x1b[H";
        for (auto& l : L) out += l + "\x1b[K\n";
        std::cout << out << "\x1b[J" << std::flush;
    }

    void dibujar() {
        winsize ws{};
        ioctl(1, TIOCGWINSZ, &ws);
        int cols = ws.ws_col ? ws.ws_col : 100;
        std::vector<std::string> L;
        std::lock_guard<std::mutex> g(mx);
        if (lab && err.empty() && !e.empty()) {
            dibujar_lab(cols, ws.ws_row ? ws.ws_row : 40);
            return;
        }
        auto v = [&](const char* k) { return e.count(k) ? e[k] : std::string(); };
        auto d = [&](const char* k) { return e.count(k) && !e[k].empty() ? std::atof(e[k].c_str()) : -1.0; };
        if (!err.empty()) {
            L.push_back(ROJO + "Sin conexión con el núcleo: " + err + RESET);
            L.push_back("Arráncalo con:  austero start");
        } else if (e.empty()) {
            L.push_back("conectando...");
        } else {
            L.push_back(NEG + CIAN + " MODO AUSTERO v3 " + RESET + "modelo " + NEG + v("modelo") + RESET + GRIS + " (" + v("motor") + ")" +
                        RESET + "  " + VERDE + fmt("%.1f inf/s", d("fps")) + RESET + fmt("  %.0f ms", d("lat_ms")) + GRIS +
                        fmt(" (p95 %.0f)", d("lat_p95")) + RESET + "  " +
                        (v("reposo") == "1" ? MAG + "💤 reposo" : (v("movimiento") == "1" ? AMAR + "● movimiento" : GRIS + "○ quieto")) +
                        RESET + (ocupado ? AMAR + "  ⏳" + RESET : ""));
            std::string cores;
            auto cp = partir(v("cpu"), ',');
            auto mz = partir(v("cpu_mhz"), ',');
            for (size_t i = 0; i < cp.size(); i++) cores += barra(std::atof(cp[i].c_str()), 4) + (i < mz.size() ? GRIS + mz[i] + RESET : "") + " ";
            L.push_back(" CPU " + barra(d("cpu_prom")) + fmt(" %3.0f%%  ", d("cpu_prom")) + cores);
            L.push_back(" GPU " + barra(d("gpu")) + fmt(" %3.0f%%  %s MHz", d("gpu"), v("gpu_mhz").c_str()) +
                        (d("potencia_mw") > 0 ? "   " + MAG + fmt("%.2f W", d("potencia_mw") / 1000) + RESET : ""));
            double rt = std::max(1.0, d("ram_total_mb"));
            L.push_back(" RAM " + barra(100 * d("ram_mb") / rt) + fmt(" %.0f/%.0f MB  swap %.0f   núcleo: %.1f%% CPU  %.0f MB", d("ram_mb"), rt,
                                                                     d("swap_mb"), d("proc_cpu"), d("proc_ram_mb")));
            std::string tt = " TEMP ";
            for (auto& x : partir(v("temp"), ',')) {
                size_t p = x.find(':');
                double t = std::atof(x.c_str() + p + 1);
                tt += x.substr(0, p) + " " + (t < 55 ? VERDE : (t < 70 ? AMAR : ROJO)) + fmt("%.0f°", t) + RESET + "  ";
            }
            L.push_back(tt);
            L.push_back(" " + GRIS + "cámara " + RESET + v("camara") + GRIS + "  salida " + RESET + v("salida") + GRIS + "  calibración " +
                        RESET + (v("calib") == "NO" ? ROJO + "NO" + RESET : VERDE + v("calib") + fmt(" %.1f px", d("calib_error")) + RESET) +
                        (d("px_por_mm") > 0 ? fmt(" %.2f px/mm", d("px_por_mm")) : ""));
            L.push_back(" " + GRIS + "manos " + RESET + onoff(v("manos")) + GRIS + "  buscar " + RESET + onoff(v("buscar")) + GRIS +
                        "  fondo " + RESET + onoff(v("fondo")) + GRIS + "  marcas " + RESET + onoff(v("marcas")) + GRIS +
                        "  complementos " + RESET + v("complementos") + GRIS + fmt("  inferencias %s/%s cuadros", v("inferencias").c_str(), v("cuadros").c_str()) + RESET);
            if (!v("params").empty()) L.push_back(" " + GRIS + "params " + RESET + v("params"));
            std::string mods = " " + GRIS + "modelos " + RESET;
            for (auto& x : partir(v("catalogo"), ',')) {
                std::string id = x.substr(x.find(':') + 1);
                mods += (v("modelo").compare(0, id.size(), id) == 0 ? NEG + VERDE : GRIS) + x + RESET + " ";
            }
            L.push_back(mods);
            if (!v("memoria").empty()) L.push_back(" " + GRIS + "memoria " + RESET + v("memoria"));
            if (!v("dets").empty()) {
                std::string s = " " + GRIS + "ve: " + RESET;
                for (auto& x : partir(v("dets"), '|')) {
                    auto p = partir(x, ':');
                    s += p[0] + (p.size() > 1 ? " " + p[1] + "%" : "") + (p.size() > 2 ? " " + p[2] + "°" : "") + "  ";
                }
                L.push_back(s);
            }
            if (!v("modelo_error").empty()) L.push_back(" " + ROJO + v("modelo_error") + RESET);
            if (vista) {
                if (vbuf.empty()) L.push_back(GRIS + "  (esperando vista...)" + RESET);
                for (int y = 0; y + 1 < vh && (int)vbuf.size() >= vw * vh * 3; y += 2) {
                    std::string f = " ";
                    for (int x = 0; x < vw; x++) {
                        const unsigned char* a = (const unsigned char*)&vbuf[(y * vw + x) * 3];
                        const unsigned char* b = (const unsigned char*)&vbuf[((y + 1) * vw + x) * 3];
                        if (truecolor) f += fmt("\x1b[38;2;%d;%d;%dm\x1b[48;2;%d;%d;%dm▀", a[2], a[1], a[0], b[2], b[1], b[0]);
                        else f += fmt("\x1b[38;5;%dm\x1b[48;5;%dm▀", c256(a[2], a[1], a[0]), c256(b[2], b[1], b[0]));
                    }
                    L.push_back(f + RESET);
                }
            }
            for (auto& l : partir(tabla, '\n')) L.push_back(" " + l);
            L.push_back(GRIS + std::string(std::min(cols, 100), '-') + RESET);
            for (auto& l : partir(v("log"), '\n')) L.push_back(" " + TEN + l.substr(0, cols - 2) + RESET);
            if (!mensaje.empty()) L.push_back(" " + AMAR + "» " + mensaje.substr(0, cols - 4) + RESET);
            if (e.count("escenario")) {
                std::string l = " " + NEG + VERDE_J + "▶ " + v("escenario") + "  ·  tarea " + v("escenario_tarea") + "  ·  " +
                                v("escenario_tiempo") + " s  ·  errores " + v("escenario_errores") +
                                (e.count("escenario_faltas") ? "  ·  faltas " + v("escenario_faltas") : "") + RESET;
                L.push_back(l);
                if (e.count("escenario_prohibida")) L.push_back(" " + NEG + ROJO_J + "MANO EN ZONA PROHIBIDA: " + v("escenario_prohibida") + RESET);
                if (e.count("escenario_error")) L.push_back(" " + ROJO_J + v("escenario_error") + RESET);
                if (e.count("escenario_fin")) L.push_back(" " + NEG + AMAR + "ESCENARIO COMPLETO: " + v("escenario_fin") + RESET);
            }
            if (e.count("escenario_grabando"))
                L.push_back(" " + NEG + ROJO_J + "● GRABANDO '" + v("escenario_grabando") + "': pon cada pieza y quita la mano · G = listo" + RESET);
            if (e.count("ensenando"))
                L.push_back(" " + NEG + AMAR + "ENSEÑANDO '" + v("ensenando") +
                            "': flechas mover  + - tamaño  * / ancho  Enter guardar  x propone la cámara  Esc terminar" + RESET);
            for (auto a : AYUDA) L.push_back(" " + GRIS + a + RESET);
        }
        std::string out = "\x1b[H";
        for (auto& l : L) out += l + "\x1b[K\n";
        std::cout << out << "\x1b[J" << std::flush;
    }

    int correr() {
        const char* ct = getenv("COLORTERM");
        truecolor = (ct && (std::string(ct) == "truecolor" || std::string(ct) == "24bit")) || getenv("WT_SESSION") ||
                    getenv("AUSTERO_TRUECOLOR");
        tcgetattr(0, &viejo);
        crudo();
        std::cout << "\x1b[?25l\x1b[2J" << std::flush;
        std::thread t(&Tablero::pedir, this);
        while (vivo) {
            std::string k = tecla();
            if (!k.empty()) atender(k);
            dibujar();
        }
        tcsetattr(0, TCSADRAIN, &viejo);
        std::cout << RESET << "\x1b[?25h\n" << std::flush;
        t.join();
        return 0;
    }
};

static const char* AYUDA_CLI = R"(uso: austero <comando>
  start [--sim] | stop | restart | ver | logs | web on|off
  status | log [n]                      estado y ultimos mensajes
  modelo <1-9|id|0>                     cargar un modelo (0 = ninguno; libera la GPU)
  param <nombre> <valor>                umbral, nms, entrada (tamano YOLO), area_min, dif
  conf [clave valor]                    ver o cambiar ajustes en vivo (p.ej. conf modelo.fps_max 5)
  autoajuste                            ajustar la camara sola
  calibrar [aruco|puntos|esquinas|graycode]
  verificar | mm                        revisar la calibracion / escala en mm
  manos|buscar|marcas [on|off]
  fondo                                 foto de la mesa vacia
  ensenar "<pieza>" | ensenar auto|guardar|cancelar
  confirmar                             guardar foto + detecciones en dataset/
  olvidar "<pieza>"
  bench [ids o teclas] [--seg N]         comparar modelos (todos si no dices cuales)
  perfil max|normal|5w                  energia de la Jetson
  foto
  sim revolver|vaciar|pieza <tipo>|poner <tipo> x y ang [apertura]|quitar [tipo]|marcador|mover_proyector   (solo --sim)

ESCENARIOS (Instrumental Quest: rutinas tipo videojuego proyectadas en la mesa)
  escenario lista                       niveles, tareas y records
  escenario grabar "Nombre"             con la mesa vacia: pon cada pieza en su lugar, una por una (cada una = una tarea)
  escenario listo                       termina de grabar (agrega la tarea FINAL que revisa todo)
  escenario jugar <n> [forzar]          jugar (forzar = aunque este bloqueado)
  escenario ok | sig | atras | pausa | seguir | parar
  escenario zona <n> <nombre> [x y w h]       lugar de una pieza (sin numeros: donde esta la pieza ahora)
  escenario prohibida <n> <nombre> [x y w h]  zona donde NO debe entrar la mano
  escenario linea <n> <nombre> x1 y1 x2 y2    raya que la mano NO debe cruzar
  escenario quitar <n> <nombre> | ver <n> | nuevo "Nombre" | recargar
  (archivos en escenarios/*.esc, se pueden editar a mano; coordenadas en pixeles del proyector)
  foto 6 [nombre]                      guarda lo que se esta proyectando)";

int main(int argc, char** argv) {
    std::vector<std::string> a(argv + 1, argv + argc);
    if (a.empty() || a[0] == "-h" || a[0] == "--help" || a[0] == "ayuda") {
        std::cout << AYUDA_CLI << std::endl;
        return 0;
    }
    if (a[0] == "ver" || a[0] == "tablero") return Tablero().correr();
    std::string l;
    for (auto& x : a) l += (l.empty() ? "" : " ") + (x.find(' ') != std::string::npos ? "\"" + x + "\"" : x);
    try {
        Respuesta r = enviar(l);
        if (a[0] == "status" || a[0] == "estado") {
            auto m = claves(r.extra);
            const char* orden[] = {"escenario", "escenario_tarea", "escenario_tiempo", "escenario_errores", "escenario_faltas",
                                   "escenario_prohibida", "escenario_error", "escenario_fin", "escenario_grabando", "modelo", "motor", "params", "fps", "lat_ms", "lat_p95", "movimiento", "reposo", "inferencias", "cuadros",
                                   "complementos", "camara", "salida", "calib", "calib_error", "px_por_mm", "manos", "buscar", "fondo",
                                   "memoria", "dets", "cpu_prom", "cpu", "cpu_mhz", "gpu", "gpu_mhz", "ram_mb", "ram_total_mb", "swap_mb",
                                   "potencia_mw", "temp", "proc_cpu", "proc_ram_mb", "modelo_error"};
            for (auto k : orden)
                if (m.count(k) && !m[k].empty()) std::cout << fmt("%-14s %s\n", k, m[k].c_str());
        } else {
            if (!r.extra.empty()) std::cout << r.extra;
            if (!r.msg.empty()) std::cout << r.msg << "\n";
            else if (r.extra.empty()) std::cout << (r.ok ? "ok" : "error") << "\n";
        }
        return r.ok ? 0 : 1;
    } catch (const std::exception& e) {
        std::cout << e.what() << std::endl;
        return 2;
    }
}
