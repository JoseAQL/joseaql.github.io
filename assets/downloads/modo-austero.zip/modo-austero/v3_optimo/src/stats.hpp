// stats.hpp - estadisticas tipo overclock leidas de /proc y /sys SOLO cuando alguien las pide.
// Sin hilos y sin tegrastats corriendo: si nadie mira, no gasta nada.
//   CPU por nucleo y frecuencia, GPU (carga y MHz), RAM, swap, temperaturas, consumo (INA3221 de la Nano)
//   y lo que gasta el propio proceso.
#pragma once

#include <map>
#include <string>
#include <vector>

struct Muestra {
    std::vector<int> cpu;          // % por nucleo
    std::vector<int> cpu_mhz;
    double cpu_prom = 0;
    int gpu = -1, gpu_mhz = -1;
    int ram_mb = 0, ram_total_mb = 0, swap_mb = 0;
    std::map<std::string, double> temp;
    int potencia_mw = -1;          // entrada total (VDD_IN / POM_5V_IN)
    double proc_cpu = 0, proc_ram_mb = 0;
    double temp_max() const;
    std::string texto() const;     // clave=valor, una por linea
};

class Estadisticas {
public:
    Muestra leer();   // compara contra la lectura anterior para sacar % de CPU

private:
    std::vector<std::pair<long long, long long>> prev_cpu_;
    long prev_ticks_ = -1;
    double prev_t_ = 0;
    std::string ruta_potencia_;
    bool buscada_ = false;
};

std::string perfil_energia(const std::string& nombre);
