// red_comun.hpp - YOLO (v5/v8/v11) y orientacion, iguales para TensorRT y para OpenCV DNN.
// Solo cambia el "Motor" que corre la red. Lo incluyen libaustero_trt.so y libaustero_cvdnn.so.
#pragma once

#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>

#include <opencv2/imgproc.hpp>

#include "modelos.hpp"

class Motor {
public:
    virtual ~Motor() {}
    virtual const std::vector<cv::Mat>& correr(const cv::Mat& blob) = 0;   // blob NCHW float32
    std::string nombre;
};
// base = ruta sin extension (.engine o .onnx segun el motor)
using FabricaMotor = std::function<std::unique_ptr<Motor>(const std::string& base, int lado, int canales, std::string& err)>;

// NMS propio (asi el complemento de TensorRT no carga opencv_dnn)
static std::vector<int> nms(const std::vector<cv::Rect>& c, const std::vector<float>& s, float iou) {
    std::vector<int> o(c.size()), r;
    for (size_t i = 0; i < o.size(); i++) o[i] = (int)i;
    std::sort(o.begin(), o.end(), [&](int a, int b) { return s[a] > s[b]; });
    std::vector<bool> fuera(c.size(), false);
    for (size_t i = 0; i < o.size(); i++) {
        int a = o[i];
        if (fuera[a]) continue;
        r.push_back(a);
        for (size_t j = i + 1; j < o.size(); j++) {
            int b = o[j];
            if (fuera[b]) continue;
            double in = (c[a] & c[b]).area(), un = c[a].area() + c[b].area() - in;
            if (un > 0 && in / un > iou) fuera[b] = true;
        }
    }
    return r;
}

static std::string dir_modelos() { return aus::ruta("modelos"); }

// letterbox directo al blob: un solo resize y una sola conversion a float, sin imagenes intermedias grandes
static void preparar_blob(const cv::Mat& bgr, int lado, cv::Mat& blob, double& r, int& dx, int& dy) {
    r = std::min(lado / (double)bgr.cols, lado / (double)bgr.rows);
    int nw = (int)std::lround(bgr.cols * r), nh = (int)std::lround(bgr.rows * r);
    dx = (lado - nw) / 2;
    dy = (lado - nh) / 2;
    int sz[] = {1, 3, lado, lado};
    if (blob.empty() || blob.size[2] != lado) blob.create(4, sz, CV_32F);
    blob.setTo(114.0 / 255);
    cv::Mat t;
    cv::resize(bgr, t, cv::Size(nw, nh), 0, 0, cv::INTER_LINEAR);
    std::vector<cv::Mat> ch(3);
    cv::split(t, ch);
    for (int c = 0; c < 3; c++) {   // BGR -> RGB, 0..1, directo en el plano del blob
        cv::Mat plano(lado, lado, CV_32F, blob.ptr<float>(0, c));
        ch[2 - c].convertTo(plano(cv::Rect(dx, dy, nw, nh)), CV_32F, 1.0 / 255);
    }
}

class YoloRed : public Modelo {
public:
    YoloRed(Contexto& c, FabricaMotor f, std::string id, std::string nom, std::string lic, std::string carpeta, bool v5,
            std::vector<std::string> clases, int entrada)
        : Modelo(c), f_(f), id_(id), nom_(nom), lic_(lic), carpeta_(carpeta), v5_(v5), clases_(clases) {
        p = {{"umbral", 0.35}, {"nms", 0.45}, {"entrada", (double)entrada}};
    }
    std::string id() const override { return id_; }
    std::string nombre() const override { return nom_; }
    std::string licencia() const override { return lic_; }
    std::string dir() const { return dir_modelos() + "/" + carpeta_; }
    std::vector<int> tamanos() override {
        std::vector<int> r;
        for (auto& f : aus::listar(dir())) {
            if (f.compare(0, 7, "modelo_") != 0) continue;
            size_t k = f.find('.');
            if (k == std::string::npos) continue;
            std::string ext = f.substr(k);
            if (ext != ".onnx" && ext != ".engine") continue;
            int v = std::atoi(f.substr(7, k - 7).c_str());
            if (v > 0 && std::find(r.begin(), r.end(), v) == r.end()) r.push_back(v);
        }
        std::sort(r.begin(), r.end());
        return r;
    }
    bool disponible(std::string& w) override {
        if (!tamanos().empty()) return true;
        w = "faltan modelos/" + carpeta_ + "/modelo_*.onnx (colab/convertir_modelos.py; ver LEEME.md)";
        return false;
    }
    bool cargar() override {
        auto t = tamanos();
        if (t.empty()) return false;
        int e = (int)p["entrada"];
        if (std::find(t.begin(), t.end(), e) == t.end()) {
            e = *std::min_element(t.begin(), t.end(), [&](int a, int b) { return std::abs(a - e) < std::abs(b - e); });
            p["entrada"] = e;
        }
        auto cl = aus::lineas(dir() + "/clases.txt");
        if (!cl.empty()) clases_ = cl;
        m_ = f_(dir() + aus::fmt("/modelo_%d", e), e, 3, error);
        if (!m_) return false;
        motor = m_->nombre;
        return ok = true;
    }
    bool poner(const std::string& k, double v) override {
        bool r = Modelo::poner(k, v);
        if (r && k == "entrada" && ok) {   // otro tamano = otro archivo
            m_.reset();
            ok = false;
            cargar();
        }
        return r;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        int lado = (int)p["entrada"];
        double r;
        int dx, dy;
        preparar_blob(img, lado, blob_, r, dx, dy);
        const cv::Mat& out = m_->correr(blob_)[0];
        int a = out.size[1], b = out.size[2];
        cv::Mat o2(a, b, CV_32F, (void*)out.ptr<float>());
        // v8/v11: [1, 4+nc, N] (se transpone)   v5: [1, N, 5+nc]
        cv::Mat filas = v5_ ? o2 : (a < b ? cv::Mat(o2.t()) : o2);
        int off = v5_ ? 5 : 4, nc = filas.cols - off;
        float um = (float)p["umbral"];
        std::vector<cv::Rect> cajas;
        std::vector<float> confs;
        std::vector<int> cids;
        for (int i = 0; i < filas.rows; i++) {
            const float* f = filas.ptr<float>(i);
            if (v5_ && f[4] < um) continue;   // descarte rapido por objetividad
            const float* sc = f + off;
            int c = (int)(std::max_element(sc, sc + nc) - sc);
            float conf = sc[c] * (v5_ ? f[4] : 1.f);
            if (conf < um) continue;
            cajas.push_back(cv::Rect(cv::Point((int)((f[0] - f[2] / 2 - dx) / r), (int)((f[1] - f[3] / 2 - dy) / r)),
                                     cv::Point((int)((f[0] + f[2] / 2 - dx) / r), (int)((f[1] + f[3] / 2 - dy) / r))));
            confs.push_back(conf);
            cids.push_back(c);
        }
        std::vector<int> idx = nms(cajas, confs, (float)p["nms"]);
        std::vector<Det> res;
        for (int i : idx) {
            Det d;
            d.clase = cids[i] < (int)clases_.size() ? clases_[cids[i]] : std::to_string(cids[i]);
            d.conf = confs[i];
            d.caja = cajas[i];
            res.push_back(d);
        }
        return res;
    }

private:
    FabricaMotor f_;
    std::string id_, nom_, lic_, carpeta_;
    bool v5_;
    std::vector<std::string> clases_;
    std::unique_ptr<Motor> m_;
    cv::Mat blob_;
};

class OrientacionRed : public Modelo {
public:
    OrientacionRed(Contexto& c, FabricaMotor f) : Modelo(c), f_(f) { p = {{"umbral", 30}, {"area_min", 250}}; }
    std::string id() const override { return "orientacion"; }
    std::string nombre() const override { return "Orientacion 0-357 grados (DocCheck Rona)"; }
    std::string licencia() const override { return "CC BY-NC 4.0 (sin uso comercial)"; }
    std::string base() const { return dir_modelos() + "/orientacion/modelo"; }
    bool disponible(std::string& w) override {
        if (aus::existe(base() + ".onnx") || aus::existe(base() + ".engine")) return true;
        w = "falta modelos/orientacion/modelo.onnx (colab/convertir_modelos.py; ver LEEME.md)";
        return false;
    }
    bool cargar() override {
        m_ = f_(base(), 128, 1, error);
        if (!m_) return false;
        motor = m_->nombre;
        return ok = true;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        cv::Mat g;
        cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
        int med = (int)cv::mean(g)[0];
        auto cs = segmentar_fondo(img, ctx.fondo, p["umbral"], p["area_min"], ctx.mascara);
        if (cs.size() > 6) cs.resize(6);
        std::vector<Det> r;
        int sz[] = {1, 1, 128, 128};
        cv::Mat blob(4, sz, CV_32F);
        for (auto& c : cs) {
            cv::Rect bb = cv::boundingRect(c);
            float cx = bb.x + bb.width / 2.f, cy = bb.y + bb.height / 2.f;
            int lado = (int)(std::hypot(bb.width, bb.height) * 1.05) + 4;
            cv::Mat M = (cv::Mat_<double>(2, 3) << 1, 0, lado / 2.0 - cx, 0, 1, lado / 2.0 - cy), rec;
            cv::warpAffine(g, rec, M, cv::Size(lado, lado), cv::INTER_LINEAR, cv::BORDER_CONSTANT, cv::Scalar(med));
            cv::resize(rec, rec, cv::Size(144, 144));
            cv::Mat pl(128, 128, CV_32F, blob.ptr<float>());
            rec(cv::Rect(8, 8, 128, 128)).convertTo(pl, CV_32F, 1.0 / 255);
            cv::Mat o = m_->correr(blob)[0].reshape(1, 1);
            double vmax;
            cv::Point mx;
            cv::minMaxLoc(o, nullptr, &vmax, nullptr, &mx);
            cv::Mat e;
            cv::exp(o - vmax, e);
            Det d;
            d.angulo = (float)mx.x;
            d.conf = (float)(1.0 / cv::sum(e)[0]);
            d.clase = aus::fmt("%d grados", mx.x);
            d.caja = bb;
            d.contorno = c;
            r.push_back(d);
        }
        return r;
    }

private:
    FabricaMotor f_;
    std::unique_ptr<Motor> m_;
};

static Modelo* crear_red(const char* id_c, Contexto* ctx, FabricaMotor f) {
    std::string id = id_c;
    if (id == "yolo_mit4")
        return new YoloRed(*ctx, f, id, "YOLO11-L 4 instrumentos (MIT)", "MIT", "yolo_mit4", false,
                           {"Bisturi", "Pinza diseccion recta", "Tijera Mayo recta", "Tijera Mayo curva"}, 416);
    if (id == "yolo_doccheck12")
        return new YoloRed(*ctx, f, id, "YOLOv5-L 12 instrumentos (DocCheck Rona)", "CC BY-NC 4.0 (sin uso comercial)",
                           "yolo_doccheck12", true,
                           {"Pinza anatomica estandar", "Pinza anatomica delgada", "Pinza quirurgica", "Pinza de astillas",
                            "Mango bisturi n3", "Mango bisturi n4", "Hoja bisturi abombada", "Hoja bisturi delgada",
                            "Tijera quirurgica punta/punta", "Tijera quirurgica punta/roma", "Tijera de diseccion",
                            "Aguja de diseccion"},
                           640);
    if (id == "yolo_alumno")
        return new YoloRed(*ctx, f, id, "YOLO nano alumno (entrenado con tus ejemplos)", "tuyo", "yolo_alumno", false, {}, 320);
    if (id == "orientacion") return new OrientacionRed(*ctx, f);
    return nullptr;
}
