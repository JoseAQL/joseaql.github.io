// libaustero_trt.so - YOLO y orientacion con TensorRT (FP16) en la GPU de la Jetson.
// Si no hay .engine, lo construye UNA vez desde el .onnx (tarda minutos) y lo guarda junto al .onnx.
#include <NvInfer.h>
#include <NvOnnxParser.h>
#include <cuda_runtime_api.h>

#include <fstream>
#include <iterator>

#include "red_comun.hpp"

class LogTRT : public nvinfer1::ILogger {
    void log(Severity s, const char* m) noexcept override {
        if (s <= Severity::kWARNING) aus::log(std::string("TensorRT: ") + m);
    }
};
static LogTRT g_log;

// ONNX -> engine FP16 (igual que trtexec --fp16), para no depender de otra herramienta
static bool construir_engine(const std::string& onnx, const std::string& engine, std::string& err) {
    aus::log("TensorRT: construyendo " + engine + " (solo la primera vez; puede tardar 5-15 min)...");
    aus::Crono cr;
    auto b = nvinfer1::createInferBuilder(g_log);
    const auto flag = 1U << static_cast<uint32_t>(nvinfer1::NetworkDefinitionCreationFlag::kEXPLICIT_BATCH);
    auto red = b->createNetworkV2(flag);
    auto par = nvonnxparser::createParser(*red, g_log);
    bool ok = par->parseFromFile(onnx.c_str(), (int)nvinfer1::ILogger::Severity::kWARNING);
    if (ok) {
        auto cfg = b->createBuilderConfig();
        cfg->setMaxWorkspaceSize(256ULL << 20);   // 256 MB: la Nano no tiene mas
        if (b->platformHasFastFp16()) cfg->setFlag(nvinfer1::BuilderFlag::kFP16);
        nvinfer1::IHostMemory* ser = b->buildSerializedNetwork(*red, *cfg);
        if (ser) {
            std::ofstream f(engine, std::ios::binary);
            f.write((const char*)ser->data(), ser->size());
            delete ser;
        } else {
            ok = false;
        }
        delete cfg;
    }
    delete par;
    delete red;
    delete b;
    if (!ok) err = "no pude construir el engine desde " + onnx;
    else aus::log(aus::fmt("TensorRT: engine listo en %.0f s", cr.s()));
    return ok;
}

class MotorTRT : public Motor {
public:
    explicit MotorTRT(const std::string& archivo) {
        std::ifstream f(archivo, std::ios::binary);
        std::vector<char> d((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        if (d.empty()) throw std::runtime_error("no pude leer " + archivo);
        rt_ = nvinfer1::createInferRuntime(g_log);
        eng_ = rt_->deserializeCudaEngine(d.data(), d.size());
        if (!eng_) throw std::runtime_error("engine invalido (otra version de TensorRT?): borra el .engine");
        ctx_ = eng_->createExecutionContext();
        cudaStreamCreate(&st_);
        int nb = eng_->getNbBindings();
        bind_.assign(nb, nullptr);
        for (int i = 0; i < nb; i++) {
            nvinfer1::Dims dm = eng_->getBindingDimensions(i);
            std::vector<int> forma(dm.d, dm.d + dm.nbDims);
            size_t n = 1;
            for (int v : forma) n *= (size_t)std::max(1, v);
            if (eng_->getBindingDataType(i) != nvinfer1::DataType::kFLOAT)
                throw std::runtime_error("el engine debe tener entradas/salidas float32");
            // memoria "pinned" del lado CPU: copias mas rapidas y sin bloquear
            cudaMalloc(&bind_[i], n * sizeof(float));
            if (eng_->bindingIsInput(i)) {
                ent_ = i;
                ent_n_ = n;
            } else {
                float* h = nullptr;
                cudaMallocHost((void**)&h, n * sizeof(float));
                sal_.push_back({i, n, h});
                outs_.push_back(cv::Mat((int)forma.size(), forma.data(), CV_32F, h));
            }
        }
        nombre = "TensorRT FP16";
    }
    ~MotorTRT() override {
        cudaStreamSynchronize(st_);
        for (auto& s : sal_) cudaFreeHost(s.h);
        for (void* b : bind_) cudaFree(b);
        cudaStreamDestroy(st_);
        delete ctx_;
        delete eng_;
        delete rt_;
    }
    const std::vector<cv::Mat>& correr(const cv::Mat& blob) override {
        cudaMemcpyAsync(bind_[ent_], blob.ptr<float>(), ent_n_ * sizeof(float), cudaMemcpyHostToDevice, st_);
        ctx_->enqueueV2(bind_.data(), st_, nullptr);
        for (auto& s : sal_) cudaMemcpyAsync(s.h, bind_[s.i], s.n * sizeof(float), cudaMemcpyDeviceToHost, st_);
        cudaStreamSynchronize(st_);
        return outs_;
    }

private:
    struct Sal {
        int i;
        size_t n;
        float* h;
    };
    nvinfer1::IRuntime* rt_ = nullptr;
    nvinfer1::ICudaEngine* eng_ = nullptr;
    nvinfer1::IExecutionContext* ctx_ = nullptr;
    cudaStream_t st_{};
    std::vector<void*> bind_;
    std::vector<Sal> sal_;
    std::vector<cv::Mat> outs_;
    int ent_ = 0;
    size_t ent_n_ = 0;
};

static std::unique_ptr<Motor> fabrica(const std::string& base, int, int, std::string& err) {
    std::string eng = base + ".engine";
    if (!aus::existe(eng)) {
        if (!aus::existe(base + ".onnx")) {
            err = "no existe " + base + ".engine ni .onnx";
            return nullptr;
        }
        if (!construir_engine(base + ".onnx", eng, err)) return nullptr;
    }
    try {
        return std::unique_ptr<Motor>(new MotorTRT(eng));
    } catch (const std::exception& e) {
        err = std::string("TensorRT: ") + e.what();
        return nullptr;
    }
}

static Modelo* crear(const char* id, Contexto* ctx) { return crear_red(id, ctx, fabrica); }
static void cerrar(bool reiniciar) {
    if (reiniciar) cudaDeviceReset();   // suelta el contexto CUDA completo
}

extern "C" Complemento* austero_complemento() {
    static Complemento c{AUSTERO_COMPLEMENTO_VERSION, "trt", true, crear, nullptr, cerrar};
    return &c;
}
