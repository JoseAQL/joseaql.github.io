// libaustero_ji.so - modelos de jetson-inference: detectNet (SSD), backgroundNet (U2-Net) y poseNet (manos).
// La imagen va a memoria "mapeada" (CPU y GPU la ven sin copiar en la Jetson).
#include <cuda_runtime_api.h>
#include <jetson-inference/detectNet.h>
#include <jetson-inference/poseNet.h>
#include <jetson-utils/cudaMappedMemory.h>
#if __has_include(<jetson-inference/backgroundNet.h>)
#include <jetson-inference/backgroundNet.h>
#define CON_BACKGROUNDNET 1
#endif

#include <opencv2/imgproc.hpp>

#include "modelos.hpp"

struct BufCuda {
    void* ptr = nullptr;
    int w = 0, h = 0, ch = 0;
    ~BufCuda() {
        if (ptr) cudaFreeHost(ptr);
    }
    void* subir(const cv::Mat& bgr, int canales) {
        if (!ptr || w != bgr.cols || h != bgr.rows || ch != canales) {
            if (ptr) cudaFreeHost(ptr);
            ptr = nullptr;
            w = bgr.cols;
            h = bgr.rows;
            ch = canales;
            if (!cudaAllocMapped(&ptr, (size_t)w * h * ch)) throw std::runtime_error("cudaAllocMapped fallo");
        }
        cv::Mat dst(h, w, ch == 3 ? CV_8UC3 : CV_8UC4, ptr);
        cv::cvtColor(bgr, dst, ch == 3 ? cv::COLOR_BGR2RGB : cv::COLOR_BGR2RGBA);
        return ptr;
    }
};

static std::vector<char*> argv_de(std::vector<std::string>& a) {
    std::vector<char*> r;
    for (auto& s : a) r.push_back(&s[0]);
    return r;
}

// ====================================================================== detectNet
class SSD : public Modelo {
public:
    SSD(Contexto& c, bool propio) : Modelo(c), propio_(propio) { p = {{"umbral", 0.4}}; }
    ~SSD() override { delete net_; }
    std::string id() const override { return propio_ ? "ssd_propio" : "ssd_general"; }
    std::string nombre() const override {
        return propio_ ? "detectNet SSD-MobileNet re-entrenado (tuyo)" : "detectNet SSD-MobileNet-v2 (COCO)";
    }
    std::string licencia() const override { return propio_ ? "tuyo" : "MIT (jetson-inference)"; }
    std::string onnx() const { return aus::ruta("modelos/ssd_instrumental/ssd-mobilenet.onnx"); }
    bool disponible(std::string& w) override {
        if (propio_ && !aus::existe(onnx())) {
            w = "falta modelos/ssd_instrumental/ssd-mobilenet.onnx (re-entrena con train_ssd.py de jetson-inference)";
            return false;
        }
        return true;
    }
    bool cargar() override {
        std::vector<std::string> a = {"austero"};
        if (propio_) {
            std::string d = aus::ruta("modelos/ssd_instrumental");
            a.insert(a.end(), {"--model=" + onnx(), "--labels=" + d + "/labels.txt", "--input-blob=input_0",
                               "--output-cvg=scores", "--output-bbox=boxes"});
        } else {
            a.push_back("--network=ssd-mobilenet-v2");
        }
        a.push_back(aus::fmt("--threshold=%.2f", p["umbral"]));
        auto av = argv_de(a);
        net_ = detectNet::Create((int)av.size(), av.data());
        if (!net_) {
            error = "detectNet no cargo (corre download-models.sh de jetson-inference)";
            return false;
        }
        motor = "TensorRT (detectNet)";
        return ok = true;
    }
    bool poner(const std::string& k, double v) override {
        bool r = Modelo::poner(k, v);
        if (r && k == "umbral" && net_) net_->SetConfidenceThreshold((float)v);
        return r;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        detectNet::Detection* d = nullptr;
        int n = net_->Detect((uchar3*)buf_.subir(img, 3), img.cols, img.rows, &d, detectNet::OVERLAY_NONE);
        std::vector<Det> r;
        for (int i = 0; i < n; i++) {
            Det x;
            x.clase = net_->GetClassDesc(d[i].ClassID);
            x.conf = d[i].Confidence;
            x.caja = cv::Rect(cv::Point((int)d[i].Left, (int)d[i].Top), cv::Point((int)d[i].Right, (int)d[i].Bottom));
            r.push_back(x);
        }
        return r;
    }

private:
    bool propio_;
    detectNet* net_ = nullptr;
    BufCuda buf_;
};

// ====================================================================== backgroundNet
#ifdef CON_BACKGROUNDNET
class FondoIA : public Modelo {
public:
    explicit FondoIA(Contexto& c) : Modelo(c) { p = {{"umbral", 0.5}, {"area_min", 250}}; }
    ~FondoIA() override { delete net_; }
    std::string id() const override { return "fondo_ia"; }
    std::string nombre() const override { return "backgroundNet U2-Net (jetson-inference)"; }
    std::string licencia() const override { return "MIT (jetson-inference)"; }
    bool cargar() override {
        std::vector<std::string> a = {"austero", "--network=u2net"};
        auto av = argv_de(a);
        net_ = backgroundNet::Create((int)av.size(), av.data());
        if (!net_) {
            error = "backgroundNet no cargo";
            return false;
        }
        motor = "TensorRT (backgroundNet)";
        return ok = true;
    }
    std::vector<Det> procesar(const cv::Mat& img) override {
        uchar4* p4 = (uchar4*)buf_.subir(img, 4);
        net_->Process(p4, img.cols, img.rows, FILTER_LINEAR, true);
        cudaDeviceSynchronize();
        cv::Mat rgba(img.rows, img.cols, CV_8UC4, buf_.ptr), a, m;
        cv::extractChannel(rgba, a, 3);
        cv::threshold(a, m, 255 * p["umbral"], 255, cv::THRESH_BINARY);
        std::vector<std::vector<cv::Point>> cs;
        cv::findContours(m, cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
        std::vector<Det> r;
        for (auto& c : cs)
            if (cv::contourArea(c) >= p["area_min"]) {
                Det d;
                d.clase = "objeto";
                d.caja = cv::boundingRect(c);
                d.contorno = c;
                r.push_back(d);
            }
        return r;
    }

private:
    backgroundNet* net_ = nullptr;
    BufCuda buf_;
};
#endif

// ====================================================================== poseNet manos
class ManosJI : public Manos {
public:
    ~ManosJI() override { delete net_; }
    bool cargar(float umbral) override {
        std::vector<std::string> a = {"austero", "--network=resnet18-hand", aus::fmt("--threshold=%.3f", umbral)};
        auto av = argv_de(a);
        net_ = poseNet::Create((int)av.size(), av.data());
        if (!net_) {
            error = "poseNet resnet18-hand no cargo (corre download-models.sh de jetson-inference)";
            return false;
        }
        motor = "poseNet (TensorRT)";
        return true;
    }
    std::vector<Mano> procesar(const cv::Mat& img) override {
        std::vector<poseNet::ObjectPose> poses;
        std::vector<Mano> r;
        if (!net_->Process((uchar3*)buf_.subir(img, 3), img.cols, img.rows, poses, poseNet::OVERLAY_NONE)) return r;
        for (auto& p : poses) {
            Mano m;
            m.puntos.assign(21, cv::Point2f(-1, -1));
            for (auto& k : p.Keypoints)
                if (k.ID < 21) m.puntos[k.ID] = cv::Point2f(k.x, k.y);
            r.push_back(m);
        }
        return r;
    }

private:
    poseNet* net_ = nullptr;
    BufCuda buf_;
};

// ====================================================================== entrada
static Modelo* crear(const char* id_c, Contexto* ctx) {
    std::string id = id_c;
    if (id == "ssd_general") return new SSD(*ctx, false);
    if (id == "ssd_propio") return new SSD(*ctx, true);
#ifdef CON_BACKGROUNDNET
    if (id == "fondo_ia") return new FondoIA(*ctx);
#endif
    return nullptr;
}
static Manos* crear_manos() { return new ManosJI(); }
static void cerrar(bool reiniciar) {
    if (reiniciar) cudaDeviceReset();
}

extern "C" Complemento* austero_complemento() {
    static Complemento c{AUSTERO_COMPLEMENTO_VERSION, "ji", true, crear, crear_manos, cerrar};
    return &c;
}
