// libaustero_ventana.so - salida al proyector en una ventana X (solo si usas escritorio).
// Va aparte para que el nucleo no cargue GTK/highgui cuando sale por framebuffer.
#include <cstdlib>

#include <opencv2/highgui.hpp>

#include "base.hpp"

static const char* V = "austero";

extern "C" bool austero_ventana_abrir(int x, int y, const char* display) {
    if (!getenv("DISPLAY")) setenv("DISPLAY", display, 1);
    if (!getenv("XAUTHORITY")) {
        std::string xa = std::string(getenv("HOME") ? getenv("HOME") : "") + "/.Xauthority";
        if (aus::existe(xa)) setenv("XAUTHORITY", xa.c_str(), 1);
    }
    try {
        cv::namedWindow(V, cv::WINDOW_NORMAL);
        cv::moveWindow(V, x, y);
        cv::setWindowProperty(V, cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN);
        return true;
    } catch (const std::exception& e) {
        aus::log(std::string("ventana: ") + e.what());
        return false;
    }
}
extern "C" void austero_ventana_mostrar(const cv::Mat* img) {
    cv::imshow(V, *img);
    cv::waitKey(1);
}
extern "C" void austero_ventana_eventos() { cv::waitKey(1); }
extern "C" void austero_ventana_cerrar() {
    try {
        cv::destroyAllWindows();
        cv::waitKey(1);
    } catch (...) {
    }
}
