// libaustero_cvdnn.so - YOLO y orientacion con OpenCV DNN en CPU (para PC o si no hay TensorRT).
#include <opencv2/dnn.hpp>

#include "red_comun.hpp"

class MotorCV : public Motor {
public:
    explicit MotorCV(const std::string& onnx) {
        net_ = cv::dnn::readNetFromONNX(onnx);
        nombre = "OpenCV DNN (CPU)";
    }
    const std::vector<cv::Mat>& correr(const cv::Mat& blob) override {
        net_.setInput(blob);
        try {
            net_.forward(out_, net_.getUnconnectedOutLayersNames());
        } catch (const cv::Exception&) {
            throw std::runtime_error("OpenCV DNN no puede correr este modelo (YOLO11 necesita TensorRT: en la Jetson si funciona)");
        }
        return out_;
    }

private:
    cv::dnn::Net net_;
    std::vector<cv::Mat> out_;
};

static std::unique_ptr<Motor> fabrica(const std::string& base, int, int, std::string& err) {
    if (!aus::existe(base + ".onnx")) {
        err = "no existe " + base + ".onnx";
        return nullptr;
    }
    try {
        return std::unique_ptr<Motor>(new MotorCV(base + ".onnx"));
    } catch (const std::exception& e) {
        err = std::string("OpenCV DNN: ") + e.what();
        return nullptr;
    }
}

static Modelo* crear(const char* id, Contexto* ctx) { return crear_red(id, ctx, fabrica); }
static void cerrar(bool) {}

extern "C" Complemento* austero_complemento() {
    static Complemento c{AUSTERO_COMPLEMENTO_VERSION, "cvdnn", false, crear, nullptr, cerrar};
    return &c;
}
