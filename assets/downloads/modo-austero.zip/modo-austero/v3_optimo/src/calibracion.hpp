// calibracion.hpp - proyector <-> camara (homografia de la mesa) y escala en mm. Se usa SOLO al calibrar.
//   aruco    (por defecto) 18 marcadores con ID; una foto; aguanta que tapes algunos
//   puntos   rejilla 10x6 de circulos (el primero mas grande marca la orientacion)
//   esquinas 4 puntos uno por uno (respaldo)
//   graycode franjas binarias (mas preciso, mas lento)
// verificar(): proyecta puntos al azar y mide el error (lazo cerrado).
#pragma once

#include <functional>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "base.hpp"

struct Calibracion {
    cv::Mat H_c2p, H_p2c, H_c2mm;   // CV_64F
    double px_por_mm = 0, error_px = -1;
    std::string metodo;

    bool lista() const { return !H_c2p.empty(); }
    bool cargar();
    void guardar() const;
    std::vector<cv::Point2f> c2p(const std::vector<cv::Point2f>& p) const;
    std::vector<cv::Point2f> p2c(const std::vector<cv::Point2f>& p) const;
};

// lo que la calibracion necesita del nucleo (asi no depende de nada mas)
struct Herramientas {
    int pw, ph;                                                // tamano del lienzo del proyector
    std::function<void(const cv::Mat&)> proyectar;            // mostrar un patron (gris)
    std::function<cv::Mat(int n, double espera)> foto;        // promedio de n cuadros nuevos (gris)
};

bool calibrar(Calibracion& cal, Herramientas& h, const std::string& metodo, const aus::Conf& c);
double verificar(Calibracion& cal, Herramientas& h, int n = 3);
bool medir_mm(Calibracion& cal, Herramientas& h, const aus::Conf& c);

cv::Mat dibujar_marcador(int id, int lado);
void guardar_marcador_impreso(const std::string& png, int id, int lado_mm);
