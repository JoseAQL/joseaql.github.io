// modelos.hpp - banco de modelos. Solo UNO activo a la vez.
//
// Los que no usan GPU viven en el nucleo. Los pesados viven en COMPLEMENTOS (.so) que se cargan con dlopen
// solo al activarlos. Al apagarlos se sueltan los modelos y el contexto CUDA (150-300 MB en la Nano).
//
// Tecla  id               donde                que es
//   1    fondo            nucleo (CPU)         resta de fondo; casi no gasta
//   2    ssd_general      complemento ji       detectNet SSD-MobileNet-v2 COCO (jetson-inference, MIT)
//   3    ssd_propio       complemento ji       detectNet con tu ONNX re-entrenado
//   4    yolo_mit4        complemento trt      YOLO11-L 4 instrumentos (MIT)
//   5    yolo_doccheck12  complemento trt      YOLOv5-L 12 instrumentos (DocCheck, CC BY-NC 4.0)
//   6    orientacion      complemento trt      angulo 0-357 (DocCheck, CC BY-NC 4.0)
//   7    ejemplos         nucleo (CPU)         "Terminator": lo que le ensenaste
//   8    fondo_ia         complemento ji       backgroundNet U2-Net
//   9    yolo_alumno      complemento trt      tu YOLO nano (Colab)
//   h    manos            complemento ji       poseNet resnet18-hand
// Sin TensorRT (en una PC) los de "trt" usan el complemento cvdnn (OpenCV DNN en CPU).
#pragma once

#include <map>
#include <memory>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "deteccion.hpp"

#define AUSTERO_COMPLEMENTO_VERSION 4

class Modelo {
public:
    explicit Modelo(Contexto& c) : ctx(c) {}
    virtual ~Modelo() {}
    virtual std::string id() const = 0;
    virtual std::string nombre() const = 0;
    virtual std::string licencia() const { return ""; }
    virtual bool disponible(std::string& por_que) { return true; }
    virtual bool cargar() { return ok = true; }
    virtual std::vector<Det> procesar(const cv::Mat& bgr) = 0;   // pixeles de la camara
    virtual bool poner(const std::string& k, double v) {
        if (!p.count(k)) return false;
        p[k] = v;
        return true;
    }
    virtual std::vector<int> tamanos() { return {}; }
    std::string params_texto() const;

    bool ok = false;
    std::string error, motor;
    std::map<std::string, double> p;
    Contexto& ctx;
};

struct Mano {
    std::vector<cv::Point2f> puntos;   // 21; (-1,-1) si no se vio
};
class Manos {
public:
    virtual ~Manos() {}
    virtual bool cargar(float umbral) = 0;
    virtual std::vector<Mano> procesar(const cv::Mat& bgr) = 0;
    std::string error, motor;
};

// ---- ABI de los complementos (mismo compilador; se compilan junto con el nucleo)
struct Complemento {
    int version;
    const char* nombre;
    bool usa_cuda;
    Modelo* (*crear_modelo)(const char* id, Contexto* ctx);   // nullptr si no lo tiene
    Manos* (*crear_manos)();                                  // nullptr si no tiene
    void (*cerrar)(bool reiniciar_cuda);                      // al descargarlo
};
extern "C" Complemento* austero_complemento();   // lo exporta cada .so

// ---- lo que usa el nucleo
struct InfoModelo {
    std::string tecla, id, nombre, donde;
};
std::vector<InfoModelo> catalogo();
std::string complemento_de(const std::string& id);   // "" = nucleo

// Administra los .so: los carga al pedir un modelo y los descarga cuando nadie los usa.
class Banco {
public:
    ~Banco();
    // crea (sin cargar) el modelo id o tecla. Si viene de un complemento, lo carga.
    Modelo* crear(const std::string& id_o_tecla, Contexto& ctx, std::string& error);
    Manos* crear_manos(std::string& error);
    void soltar(Modelo* m);          // borra el modelo y descarga su complemento si ya nadie lo usa
    void soltar(Manos* m);
    std::string cargados() const;    // para el estado

private:
    struct So {
        void* h = nullptr;
        Complemento* c = nullptr;
        int usos = 0;
    };
    std::map<std::string, So> so_;
    std::map<void*, std::string> de_;   // objeto -> complemento
    So* abrir(const std::string& nombre, std::string& error);
    void quizas_cerrar(const std::string& nombre);
};
