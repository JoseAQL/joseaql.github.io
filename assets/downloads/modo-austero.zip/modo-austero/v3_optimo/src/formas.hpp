// formas.hpp - reconocer el instrumental por su FORMA (sin red neuronal), sobre la resta de fondo.
//
//  1) Antes / despues: la foto de la mesa vacia (austero fondo) contra el cuadro actual. Se corrige el brillo
//     general (si la luz cambio un poco) y se usa histeresis: un pixel muy distinto "siembra" la pieza y los
//     vecinos medio distintos la completan (asi no se pierden las partes delgadas del metal: aros, puntas).
//  2) Cada pieza se mide a lo largo de su eje (como una regla): largo, ancho en 24 tramos, de que lado esta la
//     punta (el extremo que se adelgaza), cuanto mide la punta respecto al largo, huecos cerrados ("orejas"
//     = los aros de los dedos), muescas (la V de una pinza abierta), solidez y color de piel.
//  3) Reglas:
//       tijera  = 2 orejas (o 1) del lado ancho, el lado de los aros mucho mas ancho que la punta
//       bisturi = barra larga y angosta de ancho parejo (mango) con una punta corta, sin huecos
//       pinza   = dos brazos: V o hueco largo entre ellos, o "panza" al centro y las dos puntas delgadas
//       mano    = color de piel (o grande, con dedos)
//  4) Con una red (YOLO/SSD) se FUSIONAN: la red propone, la forma confirma o corrige, y lo que la red ve donde
//     no hay nada distinto al fondo (orillas del pano, marcos del proyector) se descarta.
// Los ajustes viven en el laboratorio (austero filtro ...): formas, formas_peso, formas_exigir, formas_umbral,
// oreja_min, mano_piel.
#pragma once

#include <map>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "deteccion.hpp"

struct Pieza {
    std::vector<cv::Point> contorno;   // exterior (camara)
    cv::Rect caja;
    cv::Mat m;                          // mascara fina dentro de la caja (CON huecos)
    cv::Mat lleno;                      // mascara llena dentro de la caja
    cv::Mat dif;                        // que tan distinto al fondo (0-255) dentro de la caja
};

struct Medidas {
    double area = 0, largo = 0, ancho = 0;   // ancho = mediana del ancho (px)
    double alargamiento = 1;                 // largo / ancho
    double ancho_max_rel = 0;                // ancho maximo / largo
    double pos_max = 0.5;                    // donde esta lo mas ancho: 0 = punta, 1 = el otro extremo
    double punta_rel = 0;                    // largo de la punta (hasta llegar a media anchura) / largo
    double conicidad = 1;                    // ancho cerca de la punta / ancho del otro extremo
    double variacion = 0;                    // que tan parejo es el ancho en el cuerpo (0 = parejo)
    double panza = 1;                        // ancho del centro / ancho de los extremos
    double solidez = 1;                      // area / area del casco convexo
    double muesca = 0;                       // la muesca mas honda / largo (V entre brazos)
    double muesca_pos = 0.5;                 // donde esta la muesca (0 = punta)
    double brazos = 0;                       // fraccion del largo con DOS tiras de metal separadas (pinza, tijera abierta)
    int orejas = 0;                          // huecos redondos del lado de los aros
    int huecos_largos = 0;                   // huecos alargados (entre brazos)
    double piel = 0;                         // fraccion con color de piel
    double largo_mm = 0;                     // si hay escala
    cv::Point2f punta, cola, centro;
    float angulo = -1;                       // 0-360, de la cola hacia la punta
    std::vector<float> perfil;               // 24 anchos relativos al largo (desde la punta)
};

struct Forma {
    std::string clase = "objeto";   // tijera | bisturi | pinza | mano | objeto
    float conf = 0;
    std::map<std::string, float> puntajes;
    std::string razon;
};

// pasos sueltos (los usa la prueba de simulacion)
std::vector<Pieza> separar_piezas(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& ignorar, double dif,
                                  double area_min, cv::Mat* mascara = nullptr);
Medidas medir(const Pieza& p, const cv::Mat& img, double px_por_mm, int oreja_min);
Forma clasificar(const Medidas& md, double umbral);

// tipo generico de una clase de la red ("Tijera Mayo curva" -> tijera); "" si no es instrumental conocido
std::string tipo_de(const std::string& clase_red);
std::string nombre_tipo(const std::string& tipo);   // "tijera" -> "Tijera"

// todo junto. red = detecciones de la red (nullptr = solo formas)
std::vector<Det> aplicar_formas(const cv::Mat& img, const Contexto& ctx, const std::vector<Det>* red);
