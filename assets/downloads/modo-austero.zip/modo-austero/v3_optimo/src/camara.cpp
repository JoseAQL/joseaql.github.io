#include "camara.hpp"
#include "escena.hpp"

#include <fcntl.h>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

#include <cerrno>
#include <cmath>
#include <cstring>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

using aus::fmt;
using aus::log;

static int xioctl(int fd, unsigned long r, void* a) {
    int k;
    do k = ioctl(fd, r, a);
    while (k == -1 && errno == EINTR);
    return k;
}

// ====================================================================== controles que se pueden ajustar
struct CtlInfo {
    const char* nombre;
    unsigned id;
    const char* desc;
};
static const std::vector<CtlInfo>& controles_v4l2() {
    static const std::vector<CtlInfo> v = {
        {"exposicion_auto", V4L2_CID_EXPOSURE_AUTO, "1 manual | 3 automatica"},
        {"exposicion", V4L2_CID_EXPOSURE_ABSOLUTE, "tiempo de exposicion (x100 us)"},
        {"exposicion_prioridad", V4L2_CID_EXPOSURE_AUTO_PRIORITY, "0 = fps fijos | 1 = baja fps si falta luz"},
        {"ganancia", V4L2_CID_GAIN, "amplificacion (mas = mas ruido)"},
        {"linea_electrica", V4L2_CID_POWER_LINE_FREQUENCY, "0 apagado | 1 50 Hz | 2 60 Hz (Mexico): quita parpadeo"},
        {"blancos_auto", V4L2_CID_AUTO_WHITE_BALANCE, "0 fijo | 1 automatico"},
        {"blancos", V4L2_CID_WHITE_BALANCE_TEMPERATURE, "balance de blancos (K)"},
        {"brillo", V4L2_CID_BRIGHTNESS, "brillo de la camara"},
        {"contraste", V4L2_CID_CONTRAST, "contraste de la camara"},
        {"saturacion", V4L2_CID_SATURATION, "saturacion de color"},
        {"nitidez_cam", V4L2_CID_SHARPNESS, "nitidez interna de la camara"},
        {"gamma_cam", V4L2_CID_GAMMA, "gamma interna de la camara"},
        {"contraluz", V4L2_CID_BACKLIGHT_COMPENSATION, "compensar contraluz"},
        {"enfoque_auto", V4L2_CID_FOCUS_AUTO, "0 manual | 1 automatico"},
        {"enfoque", V4L2_CID_FOCUS_ABSOLUTE, "enfoque manual"},
    };
    return v;
}

// ====================================================================== Cuadro
cv::Mat Cuadro::gris() const {
    cv::Mat g;
    if (formato == 0) cv::extractChannel(crudo, g, 0);                       // canal Y: gratis
    else if (formato == 1) g = cv::imdecode(crudo, cv::IMREAD_GRAYSCALE);
    else cv::cvtColor(crudo, g, cv::COLOR_BGR2GRAY);
    return g;
}
cv::Mat Cuadro::bgr() const {
    cv::Mat c;
    if (formato == 0) cv::cvtColor(crudo, c, cv::COLOR_YUV2BGR_YUYV);
    else if (formato == 1) c = cv::imdecode(crudo, cv::IMREAD_COLOR);
    else c = crudo;
    return c;
}

// ====================================================================== simulada
Simulada::Simulada(int w_, int h_) : w(w_), h(h_) {
    mesa = escena::mesa(w, h, rng);   // pano verde-gris con pliegues, como la mesa real
    esq = {{w * .08f, h * .10f}, {w * .944f, h * .08f}, {w * .92f, h * .92f}, {w * .096f, h * .912f}};
    px_por_mm = 0.55 * w / 640.0;
    revolver(2);
}
void Simulada::revolver(int n) {
    const char* t[] = {"tijera", "bisturi", "pinza"};
    objs.clear();
    for (int i = 0; i < n; i++) {
        escena::Obj o = escena::al_azar(t[i % 3], w, h, rng);
        objs.push_back({o.tipo, o.x, o.y, o.a, o.apertura, o.brillo});
    }
}
void Simulada::pieza(const std::string& t) {
    escena::Obj o = escena::al_azar(t, w, h, rng);
    objs = {{o.tipo, o.x, o.y, o.a, o.apertura, o.brillo}};
}

cv::Mat Simulada::render(const cv::Mat& pr) {
    cv::Mat img = mesa.clone(), luz;
    if (!pr.empty()) {
        cv::Mat p;
        cv::resize(pr, p, cv::Size(640, 640 * pr.rows / pr.cols), 0, 0, cv::INTER_AREA);
        if (p.channels() == 1) cv::cvtColor(p, p, cv::COLOR_GRAY2BGR);
        std::vector<cv::Point2f> s = {{0, 0}, {(float)p.cols, 0}, {(float)p.cols, (float)p.rows}, {0, (float)p.rows}};
        cv::warpPerspective(p, luz, cv::getPerspectiveTransform(s, esq), cv::Size(w, h));
        luz.convertTo(luz, CV_32FC3, 1.3 / 255, 0.55);
    } else {
        luz = cv::Mat(h, w, CV_32FC3, cv::Scalar::all(0.55));
    }
    for (size_t i = 0; i < objs.size(); i++) {
        auto& b = objs[i];
        escena::Obj o;
        o.tipo = b.tipo;
        o.x = b.x, o.y = b.y, o.a = b.a, o.apertura = b.apertura, o.brillo = b.brillo;
        cv::RNG r((uint64)(i * 7919 + 13));   // misma mano/tono en cada cuadro
        escena::pintar(img, o, px_por_mm, r);
    }
    if (!marcador.empty()) {
        cv::Rect r(40, 40, marcador.cols, marcador.rows);
        cv::Mat m3, mf;
        cv::cvtColor(marcador, m3, cv::COLOR_GRAY2BGR);
        m3.convertTo(mf, CV_32FC3, 0.33);
        mf.copyTo(img(r));
    }
    double f = exposicion / 300.0 * (1 + ganancia / 64.0);
    img = img.mul(luz) * f;
    cv::Mat ruido(h, w, CV_32FC3);
    rng.fill(ruido, cv::RNG::NORMAL, 0, 2);
    img += ruido;
    cv::Mat out;
    img.convertTo(out, CV_8UC3);
    return out;
}

// ====================================================================== camara V4L2
Camara::~Camara() { cerrar(); }

bool Camara::abrir(const aus::Conf& c) {
    tipo = c.s("camara.tipo", "usb");
    w = c.i("camara.ancho", 640);
    h = c.i("camara.alto", 480);
    fps = c.i("camara.fps", 15);
    if (tipo == "sim") {
        sim.reset(new Simulada(w, h));
        return true;
    }
    std::string dev = c.s("camara.dispositivo", "/dev/video0");
    fd_ = ::open(dev.c_str(), O_RDWR | O_NONBLOCK);
    if (fd_ < 0) {
        error = "no abre " + dev;
        return false;
    }
    std::string f = c.s("camara.formato", "yuyv");
    v4l2_format vf{};
    vf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    vf.fmt.pix.width = w;
    vf.fmt.pix.height = h;
    vf.fmt.pix.pixelformat = f == "mjpg" ? V4L2_PIX_FMT_MJPEG : V4L2_PIX_FMT_YUYV;
    vf.fmt.pix.field = V4L2_FIELD_ANY;
    if (xioctl(fd_, VIDIOC_S_FMT, &vf) < 0) {
        error = "la camara no acepta " + f + fmt(" %dx%d", w, h);
        cerrar();
        return false;
    }
    w = vf.fmt.pix.width;
    h = vf.fmt.pix.height;
    formato_ = vf.fmt.pix.pixelformat == V4L2_PIX_FMT_MJPEG ? 1 : 0;
    v4l2_streamparm sp{};
    sp.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    sp.parm.capture.timeperframe.numerator = 1;
    sp.parm.capture.timeperframe.denominator = fps;
    xioctl(fd_, VIDIOC_S_PARM, &sp);
    v4l2_requestbuffers rb{};
    rb.count = 3;
    rb.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    rb.memory = V4L2_MEMORY_MMAP;
    if (xioctl(fd_, VIDIOC_REQBUFS, &rb) < 0 || rb.count < 2) {
        error = "REQBUFS fallo";
        cerrar();
        return false;
    }
    for (unsigned i = 0; i < rb.count; i++) {
        v4l2_buffer b{};
        b.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        b.memory = V4L2_MEMORY_MMAP;
        b.index = i;
        xioctl(fd_, VIDIOC_QUERYBUF, &b);
        void* p = mmap(nullptr, b.length, PROT_READ | PROT_WRITE, MAP_SHARED, fd_, b.m.offset);
        bufs_.push_back({p, b.length});
        xioctl(fd_, VIDIOC_QBUF, &b);
    }
    v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (xioctl(fd_, VIDIOC_STREAMON, &t) < 0) {
        error = "STREAMON fallo";
        cerrar();
        return false;
    }
    // controles disponibles
    for (auto& kv : controles_v4l2()) {
        v4l2_queryctrl q{};
        q.id = kv.id;
        if (xioctl(fd_, VIDIOC_QUERYCTRL, &q) == 0 && !(q.flags & V4L2_CTRL_FLAG_DISABLED)) ctl_[kv.nombre] = kv.id;
    }
    ctl_cargar();
    log(fmt("camara %s %dx%d %s @%d", dev.c_str(), w, h, formato_ ? "MJPG" : "YUYV", fps));
    return true;
}

void Camara::cerrar() {
    if (fd_ >= 0) {
        v4l2_buf_type t = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        xioctl(fd_, VIDIOC_STREAMOFF, &t);
        for (auto& b : bufs_) munmap(b.p, b.len);
        bufs_.clear();
        ::close(fd_);
        fd_ = -1;
    }
}

bool Camara::tomar(Cuadro& c) {
    if (sim) {
        c.crudo = sim->render(proyectado ? proyectado() : cv::Mat());
        c.formato = 2;
        c.w = w;
        c.h = h;
        c.n = ++n_;
        return true;
    }
    if (fd_ < 0) return false;
    // vaciar la cola y quedarnos con el MAS NUEVO (los viejos se devuelven sin copiar)
    v4l2_buffer ult{};
    bool hay = false;
    while (true) {
        v4l2_buffer b{};
        b.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        b.memory = V4L2_MEMORY_MMAP;
        if (xioctl(fd_, VIDIOC_DQBUF, &b) < 0) break;
        if (hay) xioctl(fd_, VIDIOC_QBUF, &ult);
        ult = b;
        hay = true;
    }
    if (!hay) return false;
    const Buf& bf = bufs_[ult.index];
    if (formato_ == 0) cv::Mat(h, w, CV_8UC2, bf.p).copyTo(c.crudo);
    else cv::Mat(1, (int)ult.bytesused, CV_8U, bf.p).copyTo(c.crudo);
    xioctl(fd_, VIDIOC_QBUF, &ult);
    c.formato = formato_;
    c.w = w;
    c.h = h;
    c.n = ++n_;
    return true;
}

bool Camara::ctl_hay(const std::string& n) {
    if (sim) return n == "exposicion" || n == "ganancia";
    return ctl_.count(n) > 0;
}
bool Camara::ctl_rango(const std::string& n, int& mn, int& mx) {
    if (sim) {
        mn = n == "exposicion" ? 3 : 0;
        mx = n == "exposicion" ? 2047 : 255;
        return true;
    }
    if (!ctl_hay(n)) return false;
    v4l2_queryctrl q{};
    q.id = ctl_[n];
    if (xioctl(fd_, VIDIOC_QUERYCTRL, &q) < 0) return false;
    mn = q.minimum;
    mx = q.maximum;
    return true;
}
int Camara::ctl_leer(const std::string& n) {
    if (sim) return (int)(n == "exposicion" ? sim->exposicion : sim->ganancia);
    if (!ctl_hay(n)) return 0;
    v4l2_control c{};
    c.id = ctl_[n];
    xioctl(fd_, VIDIOC_G_CTRL, &c);
    return c.value;
}
bool Camara::ctl_poner(const std::string& n, int v) {
    if (sim) {
        if (n == "exposicion") sim->exposicion = std::max(3, std::min(2047, v));
        else if (n == "ganancia") sim->ganancia = std::max(0, std::min(255, v));
        return true;
    }
    if (!ctl_hay(n)) return false;
    v4l2_control c{};
    c.id = ctl_[n];
    c.value = v;
    return xioctl(fd_, VIDIOC_S_CTRL, &c) == 0;
}

std::string Camara::ctl_lista() {
    std::string t;
    if (sim) {
        t += aus::fmt("exposicion|%d|3|2047|10|tiempo de exposicion (simulada)\n", (int)sim->exposicion);
        t += aus::fmt("ganancia|%d|0|255|1|amplificacion (simulada)\n", (int)sim->ganancia);
        return t;
    }
    for (auto& c : controles_v4l2()) {
        if (!ctl_.count(c.nombre)) continue;
        v4l2_queryctrl q{};
        q.id = c.id;
        if (xioctl(fd_, VIDIOC_QUERYCTRL, &q) < 0) continue;
        t += aus::fmt("%s|%d|%d|%d|%d|%s\n", c.nombre, ctl_leer(c.nombre), q.minimum, q.maximum, std::max(1, q.step), c.desc);
    }
    return t;
}
void Camara::ctl_guardar() {
    std::string t = "# controles de la camara (austero cam <nombre> <valor>)\n";
    for (auto& c : controles_v4l2())
        if (ctl_hay(c.nombre)) t += aus::fmt("%s=%d\n", c.nombre, ctl_leer(c.nombre));
    aus::escribir(aus::ruta("perfiles/camara.conf"), t);
}
void Camara::ctl_cargar() {
    // primero los "auto" (si no, la camara ignora el valor manual)
    auto ls = aus::lineas(aus::ruta("perfiles/camara.conf"));
    for (int pasada = 0; pasada < 2; pasada++)
        for (auto& l : ls) {
            size_t e = l.find('=');
            if (e == std::string::npos || l[0] == '#') continue;
            std::string n = l.substr(0, e);
            bool es_auto = n.find("_auto") != std::string::npos;
            if ((pasada == 0) == es_auto) ctl_poner(n, std::atoi(l.c_str() + e + 1));
        }
}

// ====================================================================== auto-ajuste
std::string autoajuste(Camara& cam, std::function<cv::Mat()> gris_nuevo, double obj, double max_sat, double& gamma) {
    gamma = 1.0;
    auto medir = [&](double& m, double& sat) {
        cv::Mat g = gris_nuevo();
        if (g.empty()) return false;
        cv::Rect c(g.cols / 6, g.rows / 6, g.cols * 2 / 3, g.rows * 2 / 3);
        m = cv::mean(g(c))[0];
        sat = cv::countNonZero(g >= 250) / (double)g.total();
        return true;
    };
    std::string r;
    double m = 0, sat = 0;
    if (cam.ctl_hay("exposicion")) {
        if (cam.ctl_hay("exposicion_auto")) cam.ctl_poner("exposicion_auto", 1);   // manual
        int lo, hi;
        cam.ctl_rango("exposicion", lo, hi);
        double a = std::log(std::max(lo, 1)), b = std::log(std::max(hi, lo + 2));
        double me = 1e9;
        int be = -1;
        double bm = 0;
        for (int it = 0; it < 9; it++) {
            int e = (int)std::exp((a + b) / 2);
            cam.ctl_poner("exposicion", e);
            if (!medir(m, sat)) break;
            double err = std::fabs(m - obj) + (sat > max_sat ? 400 * (sat - max_sat) : 0);
            if (err < me) {
                me = err;
                be = e;
                bm = m;
            }
            if (std::fabs(m - obj) < 6 && sat <= max_sat) break;
            (m < obj && sat <= max_sat ? a : b) = std::log(e);
        }
        if (be > 0) {
            cam.ctl_poner("exposicion", be);
            r += fmt(" exposicion=%d", be);
            if (bm < obj - 20 && cam.ctl_hay("ganancia")) {
                int g0, g1;
                cam.ctl_rango("ganancia", g0, g1);
                for (int i = 1; i <= 5; i++) {
                    cam.ctl_poner("ganancia", g0 + (g1 - g0) * i / 5);
                    if (!medir(m, sat) || m >= obj - 8 || sat > max_sat) break;
                }
                r += fmt(" ganancia=%d", cam.ctl_leer("ganancia"));
            }
        }
    }
    if (cam.ctl_hay("blancos_auto") && cam.ctl_hay("blancos")) {
        cam.ctl_poner("blancos_auto", 1);
        aus::dormir(1.2);
        int v = cam.ctl_leer("blancos");
        cam.ctl_poner("blancos_auto", 0);
        cam.ctl_poner("blancos", v);
        r += fmt(" blancos=%d", v);
    }
    if (medir(m, sat)) {
        if (std::fabs(m - obj) > 15 && m > 5 && m < 250) {
            gamma = std::max(0.6, std::min(1.8, std::log(m / 255) / std::log(obj / 255)));
            r += fmt(" gamma=%.2f", gamma);
        }
        r += fmt(" brillo=%.0f", m);
    }
    return r.empty() ? "auto-ajuste: la camara no tiene controles" : "auto-ajuste listo:" + r;
}
