// deteccion.hpp - lo que regresa cualquier detector (pixeles de la camara).
#pragma once

#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "base.hpp"

struct Det {
    std::string clase;
    float conf = 1.f;
    cv::Rect caja;
    std::vector<cv::Point> contorno;   // vacio si el modelo solo da caja
    float angulo = -1.f;               // grados; -1 = no se sabe
    std::string info;                  // por que (formas): "2 orejas, largo/ancho 4.1"
};

class Memoria;
struct Contexto {
    cv::Mat fondo;          // mesa vacia (BGR)
    cv::Mat mascara;        // donde el proyector pinta (se ignora)
    Memoria* memoria = nullptr;
    double px_por_mm = 0;   // escala de la mesa (0 = no se sabe)
};

std::vector<std::vector<cv::Point>> segmentar_fondo(const cv::Mat& img, const cv::Mat& fondo, double umbral,
                                                    double area_min, const cv::Mat& ignorar);
