#include "base.hpp"

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <mutex>
#include <sstream>
#include <thread>

namespace aus {

static std::string g_base = ".";
static std::mutex g_mx;
static std::deque<std::string> g_log;

void fijar_base(const std::string& b) { g_base = b; }
std::string ruta(const std::string& rel) { return g_base + "/" + rel; }

double ahora() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
static std::string strf(const char* f) {
    time_t t = time(nullptr);
    struct tm m;
    localtime_r(&t, &m);
    char b[48];
    strftime(b, sizeof b, f, &m);
    return b;
}
std::string hora() { return strf("%H:%M:%S"); }
std::string fecha() { return strf("%Y%m%d_%H%M%S"); }
void dormir(double s) {
    if (s > 0) std::this_thread::sleep_for(std::chrono::microseconds((long long)(s * 1e6)));
}
std::string fmt(const char* f, ...) {
    char b[1024];
    va_list a;
    va_start(a, f);
    vsnprintf(b, sizeof b, f, a);
    va_end(a);
    return b;
}

void log(const std::string& m) {
    std::string l = hora() + " " + m;
    {
        std::lock_guard<std::mutex> k(g_mx);
        g_log.push_back(l);
        if (g_log.size() > 100) g_log.pop_front();
    }
    fprintf(stdout, "%s\n", l.c_str());
    fflush(stdout);
}
std::vector<std::string> ultimos_log(size_t n) {
    std::lock_guard<std::mutex> k(g_mx);
    size_t i0 = g_log.size() > n ? g_log.size() - n : 0;
    return std::vector<std::string>(g_log.begin() + i0, g_log.end());
}

bool existe(const std::string& p) {
    struct stat s;
    return stat(p.c_str(), &s) == 0;
}
bool crear_dirs(const std::string& p) {
    if (p.empty() || existe(p)) return true;
    size_t k = p.find_last_of('/');
    if (k != std::string::npos && k > 0) crear_dirs(p.substr(0, k));
    return mkdir(p.c_str(), 0775) == 0;
}
std::vector<std::string> listar(const std::string& dir) {
    std::vector<std::string> r;
    if (DIR* d = opendir(dir.c_str())) {
        while (dirent* e = readdir(d))
            if (e->d_name[0] != '.') r.push_back(e->d_name);
        closedir(d);
    }
    std::sort(r.begin(), r.end());
    return r;
}
std::vector<std::string> lineas(const std::string& p) {
    std::vector<std::string> r;
    std::ifstream f(p);
    std::string l;
    while (std::getline(f, l)) {
        while (!l.empty() && (l.back() == '\r' || l.back() == ' ')) l.pop_back();
        if (!l.empty()) r.push_back(l);
    }
    return r;
}
bool escribir(const std::string& p, const std::string& t) {
    size_t k = p.find_last_of('/');
    if (k != std::string::npos) crear_dirs(p.substr(0, k));
    std::string tmp = p + ".tmp";
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return false;
    fwrite(t.data(), 1, t.size(), f);
    fclose(f);
    return rename(tmp.c_str(), p.c_str()) == 0;
}
std::string slug(const std::string& s) {
    std::string r;
    for (unsigned char c : s) r += (std::isalnum(c) || c >= 0x80) ? (char)std::tolower(c) : '_';
    while (!r.empty() && r.back() == '_') r.pop_back();
    while (!r.empty() && r[0] == '_') r.erase(0, 1);
    return r.empty() ? "pieza" : r;
}

// ---------------------------------------------------------------- Conf
void Conf::leer(const std::string& p, std::map<std::string, std::string>& m) {
    for (auto& l : lineas(p)) {
        size_t h = l.find('#');
        std::string x = h == std::string::npos ? l : l.substr(0, h);
        size_t e = x.find('=');
        if (e == std::string::npos) continue;
        auto lim = [](std::string s) {
            while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back();
            while (!s.empty() && isspace((unsigned char)s[0])) s.erase(0, 1);
            return s;
        };
        m[lim(x.substr(0, e))] = lim(x.substr(e + 1));
    }
}
void Conf::cargar() {
    v_.clear();
    propios_.clear();
    leer(ruta("austero.conf"), v_);
    leer(ruta("perfiles/ajustes.conf"), propios_);
    for (auto& kv : propios_) v_[kv.first] = kv.second;
    const char* sim = getenv("AUSTERO_SIM");
    if (sim && std::string(sim) == "1") {
        v_["camara.tipo"] = "sim";
        v_["salida.tipo"] = "sim";
    }
}
std::string Conf::s(const std::string& k, const std::string& d) const {
    auto it = v_.find(k);
    return it == v_.end() ? d : it->second;
}
double Conf::d(const std::string& k, double def) const {
    auto it = v_.find(k);
    return it == v_.end() || it->second.empty() ? def : std::atof(it->second.c_str());
}
int Conf::i(const std::string& k, int def) const { return (int)d(k, def); }
bool Conf::b(const std::string& k, bool def) const {
    auto it = v_.find(k);
    if (it == v_.end()) return def;
    const std::string& x = it->second;
    return x == "1" || x == "si" || x == "sí" || x == "on" || x == "true";
}
void Conf::poner(const std::string& k, const std::string& v) {
    v_[k] = v;
    propios_[k] = v;
    std::string t = "# cambios hechos en vivo (tienen prioridad sobre austero.conf)\n";
    for (auto& kv : propios_) t += kv.first + " = " + kv.second + "\n";
    escribir(ruta("perfiles/ajustes.conf"), t);
}
std::string Conf::todo() const {
    std::string t;
    for (auto& kv : v_) t += kv.first + "=" + kv.second + "\n";
    return t;
}

}  // namespace aus
