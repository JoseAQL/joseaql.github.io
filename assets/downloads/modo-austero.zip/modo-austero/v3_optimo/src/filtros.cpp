#include "filtros.hpp"

#include <sys/stat.h>

#include <cmath>
#include <cstdlib>
#include <sstream>

#include <opencv2/imgproc.hpp>

#include "base.hpp"

Filtros* g_filtros = nullptr;

Filtros::Filtros() {
    p = {
        {"gamma", 1.0, 1.0, 0.3, 3.0, 0.05, ">1 aclara sombras, <1 oscurece"},
        {"clahe", 0, 0, 0, 8, 0.5, "contraste local (0 = apagado)"},
        {"suavizado", 0, 0, 0, 3, 1, "0 nada | 1 gauss | 2 mediana | 3 bilateral"},
        {"suavizado_k", 5, 5, 3, 21, 2, "tamano del kernel de suavizado (impar)"},
        {"nitidez", 0, 0, 0, 3, 0.1, "realce de detalles (unsharp mask)"},
        {"kernel", 0, 0, 0, 6, 1, "0 nada | 1 enfocar | 2 relieve | 3 laplaciano | 4 sobel x | 5 sobel y | 6 el tuyo (perfiles/kernel.txt)"},
        {"kernel_mezcla", 1.0, 1.0, 0, 1, 0.05, "cuanto del kernel se mezcla con la imagen"},
        {"mascara_dif", 30, 30, 3, 150, 1, "cuanto debe cambiar un pixel contra el fondo para ser pieza"},
        {"mascara_area", 120, 120, 10, 20000, 10, "area minima de una pieza (pixeles)"},
        {"morf", 2, 2, 0, 5, 1, "0 nada | 1 abrir | 2 cerrar | 3 dilatar | 4 erosionar | 5 gradiente"},
        {"morf_k", 9, 9, 1, 31, 2, "tamano del kernel de morfologia (impar)"},
        {"morf_forma", 0, 0, 0, 2, 1, "0 rectangulo | 1 elipse | 2 cruz"},
        {"morf_limpiar", 3, 3, 0, 15, 2, "abrir chico extra para quitar puntitos (0 = no)"},
        {"canny_bajo", 40, 40, 0, 255, 5, "umbral bajo de bordes"},
        {"canny_alto", 110, 110, 0, 255, 5, "umbral alto de bordes"},
        {"esquinas", 40, 40, 0, 300, 5, "esquinas maximas a marcar (0 = no)"},
        {"esquinas_calidad", 0.05, 0.05, 0.005, 0.5, 0.005, "calidad minima de una esquina"},
        {"formas", 1, 1, 0, 1, 1, "reconocer por forma (orejas, punta, largo/ancho) sobre la resta de fondo: 0 no | 1 si"},
        {"formas_peso", 0.5, 0.5, 0, 1, 0.05, "al fusionar: cuanto pesa la red (1) contra la forma (0)"},
        {"formas_exigir", 1, 1, 0, 1, 1, "1 = lo que la red ve donde no hay nada distinto al fondo se descarta"},
        {"formas_umbral", 0.4, 0.4, 0.1, 0.9, 0.05, "puntaje minimo para nombrar una pieza solo por su forma"},
        {"formas_histeresis", 0.5, 0.5, 0.2, 1, 0.05, "vecinos con esta fraccion del umbral completan la pieza (metal delgado)"},
        {"oreja_min", 4, 4, 1, 200, 1, "area minima (px) de un hueco para contarlo como oreja/aro"},
        {"mano_piel", 0.25, 0.25, 0.05, 0.9, 0.05, "fraccion de color piel para decir que es una mano"},
    };
}

Param* Filtros::buscar(const std::string& k) {
    for (auto& x : p)
        if (x.nombre == k) return &x;
    return nullptr;
}
const Param* Filtros::buscar(const std::string& k) const {
    for (auto& x : p)
        if (x.nombre == k) return &x;
    return nullptr;
}
double Filtros::v(const std::string& k) const {
    const Param* x = buscar(k);
    return x ? x->valor : 0;
}

bool Filtros::poner(const std::string& k, const std::string& val) {
    Param* x = buscar(k);
    if (!x || val.empty()) return false;
    double n;
    if (val == "+") n = x->valor + x->paso;
    else if (val == "-") n = x->valor - x->paso;
    else n = std::atof(val.c_str());
    n = std::max(x->min, std::min(x->max, n));
    if (x->nombre == "suavizado_k" || x->nombre == "morf_k") {   // kernels impares
        int e = (int)std::lround(n);
        if (e % 2 == 0) e += (val == "-" ? -1 : 1);
        n = std::max(x->min, std::min(x->max, (double)e));
    }
    if (x->nombre == "morf_limpiar") {
        int e = (int)std::lround(n);
        if (e > 0 && e % 2 == 0) e += (val == "-" ? -1 : 1);
        n = std::max(0.0, std::min(x->max, (double)e));
    }
    bool impar = x->nombre == "suavizado_k" || x->nombre == "morf_k" || x->nombre == "morf_limpiar";
    x->valor = impar ? n : std::round(n / x->paso) * x->paso;
    guardar();
    return true;
}

void Filtros::reset() {
    for (auto& x : p) x.valor = x.def;
    guardar();
}

void Filtros::cargar() {
    for (auto& l : aus::lineas(aus::ruta("perfiles/filtros.conf"))) {
        size_t e = l.find('=');
        if (e == std::string::npos || l[0] == '#') continue;
        Param* x = buscar(l.substr(0, e));
        if (x) x->valor = std::max(x->min, std::min(x->max, std::atof(l.c_str() + e + 1)));
    }
}
void Filtros::guardar() const {
    std::string t = "# filtros del laboratorio (austero filtro <nombre> <valor>)\n";
    for (auto& x : p) t += x.nombre + "=" + aus::fmt("%g", x.valor) + "\n";
    aus::escribir(aus::ruta("perfiles/filtros.conf"), t);
}

std::string Filtros::lista() const {
    std::string t;
    for (auto& x : p) t += aus::fmt("%s|%g|%g|%g|%g|", x.nombre.c_str(), x.valor, x.min, x.max, x.paso) + x.desc + "\n";
    return t;
}

bool Filtros::neutro() const {
    return std::fabs(v("gamma") - 1) < 0.01 && v("clahe") < 0.05 && i("suavizado") == 0 && v("nitidez") < 0.01 &&
           (i("kernel") == 0 || v("kernel_mezcla") < 0.01);
}

static cv::Mat kernel_fijo(int k) {
    switch (k) {
    case 1: return (cv::Mat_<float>(3, 3) << 0, -1, 0, -1, 5, -1, 0, -1, 0);
    case 2: return (cv::Mat_<float>(3, 3) << -2, -1, 0, -1, 1, 1, 0, 1, 2);
    case 3: return (cv::Mat_<float>(3, 3) << 0, 1, 0, 1, -4, 1, 0, 1, 0);
    case 4: return (cv::Mat_<float>(3, 3) << -1, 0, 1, -2, 0, 2, -1, 0, 1);
    case 5: return (cv::Mat_<float>(3, 3) << -1, -2, -1, 0, 0, 0, 1, 2, 1);
    }
    return cv::Mat();
}

cv::Mat Filtros::aplicar(const cv::Mat& bgr) const {
    if (bgr.empty() || neutro()) return bgr;
    cv::Mat img = bgr.clone();
    double g = v("gamma");
    if (std::fabs(g - 1) >= 0.01) {
        if (g != lut_g_) {
            lut_.create(1, 256, CV_8U);
            for (int k = 0; k < 256; k++) lut_.at<uchar>(k) = cv::saturate_cast<uchar>(std::pow(k / 255.0, 1.0 / g) * 255.0);
            lut_g_ = g;
        }
        cv::LUT(img, lut_, img);
    }
    if (v("clahe") >= 0.05) {
        cv::Mat lab;
        cv::cvtColor(img, lab, cv::COLOR_BGR2Lab);
        std::vector<cv::Mat> ch;
        cv::split(lab, ch);
        cv::createCLAHE(v("clahe"), cv::Size(8, 8))->apply(ch[0], ch[0]);
        cv::merge(ch, lab);
        cv::cvtColor(lab, img, cv::COLOR_Lab2BGR);
    }
    int s = i("suavizado"), k = i("suavizado_k") | 1;
    if (s == 1) cv::GaussianBlur(img, img, cv::Size(k, k), 0);
    else if (s == 2) cv::medianBlur(img, img, std::min(k, 15));
    else if (s == 3) {
        cv::Mat t;
        cv::bilateralFilter(img, t, std::min(k, 15), 50, 50);
        img = t;
    }
    if (v("nitidez") >= 0.01) {
        cv::Mat bl;
        cv::GaussianBlur(img, bl, cv::Size(0, 0), 2.0);
        cv::addWeighted(img, 1.0 + v("nitidez"), bl, -v("nitidez"), 0, img);
    }
    int kk = i("kernel");
    double mz = v("kernel_mezcla");
    if (kk > 0 && mz >= 0.01) {
        cv::Mat K;
        if (kk == 6) {   // el tuyo: numeros separados por espacios, una fila por linea (3x3, 5x5, ...)
            struct stat st;
            std::string ruta = aus::ruta("perfiles/kernel.txt");
            double t = stat(ruta.c_str(), &st) == 0 ? (double)st.st_mtime : 0;
            if (t != kernel_t_) {
                std::vector<std::vector<float>> filas;
                for (auto& l : aus::lineas(ruta)) {
                    if (l[0] == '#') continue;
                    std::stringstream ss(l);
                    std::vector<float> f;
                    float x;
                    while (ss >> x) f.push_back(x);
                    if (!f.empty()) filas.push_back(f);
                }
                kernel_propio_.release();
                if (!filas.empty()) {
                    kernel_propio_ = cv::Mat((int)filas.size(), (int)filas[0].size(), CV_32F, cv::Scalar(0));
                    for (size_t r = 0; r < filas.size(); r++)
                        for (size_t q = 0; q < filas[r].size() && q < filas[0].size(); q++) kernel_propio_.at<float>((int)r, (int)q) = filas[r][q];
                }
                kernel_t_ = t;
            }
            K = kernel_propio_;
        } else {
            K = kernel_fijo(kk);
        }
        if (!K.empty()) {
            cv::Mat f;
            bool deriv = kk >= 3 && kk <= 5;   // laplaciano y sobel: se ve mejor en gris absoluto
            if (deriv) {
                cv::Mat gr, d;
                cv::cvtColor(img, gr, cv::COLOR_BGR2GRAY);
                cv::filter2D(gr, d, CV_16S, K);
                cv::convertScaleAbs(d, d);
                cv::cvtColor(d, f, cv::COLOR_GRAY2BGR);
            } else {
                cv::filter2D(img, f, -1, K);
            }
            if (mz >= 0.99) img = f;
            else cv::addWeighted(f, mz, img, 1 - mz, 0, img);
        }
    }
    return img;
}

void Filtros::morfologia(cv::Mat& m) const {
    int op = i("morf"), k = std::max(1, i("morf_k") | 1);
    int forma = i("morf_forma") == 1 ? cv::MORPH_ELLIPSE : (i("morf_forma") == 2 ? cv::MORPH_CROSS : cv::MORPH_RECT);
    if (op > 0 && k > 1) {
        cv::Mat K = cv::getStructuringElement(forma, cv::Size(k, k));
        static const int ops[] = {0, cv::MORPH_OPEN, cv::MORPH_CLOSE, cv::MORPH_DILATE, cv::MORPH_ERODE, cv::MORPH_GRADIENT};
        cv::morphologyEx(m, m, ops[std::min(op, 5)], K);
    }
    int l = i("morf_limpiar");
    if (l >= 3) cv::morphologyEx(m, m, cv::MORPH_OPEN, cv::getStructuringElement(forma, cv::Size(l | 1, l | 1)));
}

cv::Mat Filtros::mascara(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& ignorar) const {
    if (fondo.empty() || fondo.size() != img.size()) return cv::Mat();
    cv::Mat a, b, dc, m;
    cv::GaussianBlur(img, a, cv::Size(5, 5), 0);
    cv::GaussianBlur(fondo, b, cv::Size(5, 5), 0);
    cv::absdiff(a, b, dc);
    std::vector<cv::Mat> ch;
    cv::split(dc, ch);
    cv::threshold(cv::max(cv::max(ch[0], ch[1]), ch[2]), m, v("mascara_dif"), 255, cv::THRESH_BINARY);
    if (!ignorar.empty() && ignorar.size() == m.size()) m.setTo(0, ignorar);
    morfologia(m);
    return m;
}

cv::Mat Filtros::bordes(const cv::Mat& img, int* n_esq) const {
    cv::Mat g, e, out;
    cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
    cv::Canny(g, e, v("canny_bajo"), std::max(v("canny_bajo") + 1, v("canny_alto")));
    cv::cvtColor(e, out, cv::COLOR_GRAY2BGR);
    int n = 0;
    if (i("esquinas") > 0) {
        std::vector<cv::Point2f> pts;
        cv::goodFeaturesToTrack(g, pts, i("esquinas"), v("esquinas_calidad"), 8);
        for (auto& q : pts) cv::circle(out, q, 4, cv::Scalar(60, 120, 255), 2);
        n = (int)pts.size();
    }
    if (n_esq) *n_esq = n;
    return out;
}
