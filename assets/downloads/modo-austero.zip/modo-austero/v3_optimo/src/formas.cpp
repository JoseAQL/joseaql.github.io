#include "formas.hpp"

#include <algorithm>
#include <cmath>

#include <opencv2/imgproc.hpp>

#include "base.hpp"
#include "filtros.hpp"

using aus::fmt;

static double fv(const char* k, double def) { return g_filtros ? g_filtros->v(k) : def; }

// ====================================================================== 1) antes / despues
std::vector<Pieza> separar_piezas(const cv::Mat& img, const cv::Mat& fondo, const cv::Mat& ignorar, double dif,
                                  double area_min, cv::Mat* salida) {
    std::vector<Pieza> res;
    if (fondo.empty() || fondo.size() != img.size()) return res;
    cv::Mat a, b;
    cv::GaussianBlur(img, a, cv::Size(3, 3), 0);
    cv::GaussianBlur(fondo, b, cv::Size(3, 3), 0);
    // la luz cambio un poco (nube, proyector, auto-exposicion): igualar el brillo general antes de comparar
    {
        cv::Mat ga, gb, sa, sb;
        cv::cvtColor(a, ga, cv::COLOR_BGR2GRAY);
        cv::cvtColor(b, gb, cv::COLOR_BGR2GRAY);
        cv::resize(ga, sa, cv::Size(), 0.25, 0.25, cv::INTER_NEAREST);
        cv::resize(gb, sb, cv::Size(), 0.25, 0.25, cv::INTER_NEAREST);
        std::vector<uchar> va(sa.begin<uchar>(), sa.end<uchar>()), vb(sb.begin<uchar>(), sb.end<uchar>());
        std::nth_element(va.begin(), va.begin() + va.size() / 2, va.end());
        std::nth_element(vb.begin(), vb.begin() + vb.size() / 2, vb.end());
        double g = vb[vb.size() / 2] > 8 ? va[va.size() / 2] / (double)vb[vb.size() / 2] : 1.0;
        if (g > 0.7 && g < 1.4 && std::fabs(g - 1) > 0.01) b.convertTo(b, -1, g);
    }
    cv::Mat dc, d;
    cv::absdiff(a, b, dc);
    std::vector<cv::Mat> ch;
    cv::split(dc, ch);
    d = cv::max(cv::max(ch[0], ch[1]), ch[2]);
    // histeresis: semillas (muy distinto) + vecinos medio distintos conectados
    cv::Mat fuerte = d >= dif, debil = d >= std::max(4.0, dif * fv("formas_histeresis", 0.5));
    if (!ignorar.empty() && ignorar.size() == d.size()) {
        fuerte.setTo(0, ignorar);
        debil.setTo(0, ignorar);
    }
    cv::Mat et, st, cen;
    int n = cv::connectedComponentsWithStats(debil, et, st, cen, 8, CV_32S);
    std::vector<uchar> vale(n, 0);
    for (int y = 0; y < fuerte.rows; y++) {
        const uchar* f = fuerte.ptr<uchar>(y);
        const int* e = et.ptr<int>(y);
        for (int x = 0; x < fuerte.cols; x++)
            if (f[x]) vale[e[x]] = 1;
    }
    cv::Mat m = cv::Mat::zeros(d.size(), CV_8U);
    for (int y = 0; y < m.rows; y++) {
        uchar* o = m.ptr<uchar>(y);
        const int* e = et.ptr<int>(y);
        for (int x = 0; x < m.cols; x++)
            if (e[x] > 0 && vale[e[x]] && st.at<int>(e[x], cv::CC_STAT_AREA) >= 6) o[x] = 255;
    }
    // fina: solo se cierran grietas de 1-2 px (los aros de la tijera NO se tapan)
    cv::morphologyEx(m, m, cv::MORPH_CLOSE, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3, 3)));
    // grupos: la morfologia del laboratorio junta los pedazos de una misma pieza
    cv::Mat g = m.clone();
    if (g_filtros) g_filtros->morfologia(g);
    else cv::morphologyEx(g, g, cv::MORPH_CLOSE, cv::Mat::ones(9, 9, CV_8U));
    g |= m;
    if (salida) *salida = m;
    std::vector<std::vector<cv::Point>> cs;
    cv::findContours(g.clone(), cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);
    for (auto& c : cs) {
        if (cv::contourArea(c) < area_min) continue;
        Pieza p;
        p.contorno = c;
        p.caja = cv::boundingRect(c) & cv::Rect(0, 0, img.cols, img.rows);
        p.lleno = cv::Mat::zeros(p.caja.size(), CV_8U);
        cv::drawContours(p.lleno, std::vector<std::vector<cv::Point>>{c}, 0, cv::Scalar(255), cv::FILLED, 8, cv::noArray(), INT_MAX,
                         -p.caja.tl());
        p.m = m(p.caja) & p.lleno;
        p.dif = d(p.caja).clone();
        res.push_back(std::move(p));
    }
    std::sort(res.begin(), res.end(), [](const Pieza& x, const Pieza& y) { return x.caja.area() > y.caja.area(); });
    return res;
}

// ====================================================================== 2) medir
static double media(const std::vector<float>& v, int a, int b) {
    double s = 0;
    int k = 0;
    for (int i = std::max(0, a); i <= std::min((int)v.size() - 1, b); i++)
        if (v[i] > 0) s += v[i], k++;
    return k ? s / k : 0;
}

Medidas medir(const Pieza& p, const cv::Mat& img, double px_por_mm, int oreja_min) {
    Medidas md;
    cv::Moments mo = cv::moments(p.lleno, true);
    if (mo.m00 < 3) return md;
    md.area = mo.m00;
    double cx = mo.m10 / mo.m00, cy = mo.m01 / mo.m00;
    double th = 0.5 * std::atan2(2 * mo.mu11, mo.mu20 - mo.mu02);
    double ex = std::cos(th), ey = std::sin(th);
    // coordenadas a lo largo (t) y a lo ancho (s)
    double tmin = 1e9, tmax = -1e9;
    std::vector<cv::Point3f> pts;
    pts.reserve((size_t)md.area);
    for (int y = 0; y < p.lleno.rows; y++) {
        const uchar* r = p.lleno.ptr<uchar>(y);
        for (int x = 0; x < p.lleno.cols; x++)
            if (r[x]) {
                double dx = x - cx, dy = y - cy;
                float t = (float)(dx * ex + dy * ey), s = (float)(-dx * ey + dy * ex);
                pts.push_back(cv::Point3f(t, s, 0));
                tmin = std::min(tmin, (double)t);
                tmax = std::max(tmax, (double)t);
            }
    }
    const int NB = 24;
    md.largo = tmax - tmin + 1;
    std::vector<float> smin(NB, 1e9f), smax(NB, -1e9f), cnt(NB, 0);
    for (auto& q : pts) {
        int b = std::min(NB - 1, (int)((q.x - tmin) / md.largo * NB));
        smin[b] = std::min(smin[b], q.y);
        smax[b] = std::max(smax[b], q.y);
        cnt[b] += 1;
    }
    std::vector<float> ext(NB, 0), rel(NB, 0);
    double bl = md.largo / NB;
    for (int b = 0; b < NB; b++)
        if (cnt[b] > 0) {
            ext[b] = smax[b] - smin[b] + 1;
            rel[b] = (float)std::min(1.0, cnt[b] / (ext[b] * bl));
        }
    // la punta = el extremo que se adelgaza
    bool al_reves = media(ext, NB - 4, NB - 1) < media(ext, 0, 3);
    if (al_reves) {
        std::reverse(ext.begin(), ext.end());
        std::reverse(rel.begin(), rel.end());
    }
    double sgn = al_reves ? 1 : -1;   // la punta esta hacia +t si al_reves
    md.punta = cv::Point2f((float)(p.caja.x + cx + ex * (sgn > 0 ? tmax : tmin)), (float)(p.caja.y + cy + ey * (sgn > 0 ? tmax : tmin)));
    md.cola = cv::Point2f((float)(p.caja.x + cx + ex * (sgn > 0 ? tmin : tmax)), (float)(p.caja.y + cy + ey * (sgn > 0 ? tmin : tmax)));
    md.centro = cv::Point2f((float)(p.caja.x + cx), (float)(p.caja.y + cy));
    double ang = std::atan2(md.punta.y - md.cola.y, md.punta.x - md.cola.x) * 180 / CV_PI;
    md.angulo = (float)std::fmod(ang + 360.0, 360.0);

    std::vector<float> cuerpo;
    for (int b = 2; b < NB - 2; b++)
        if (ext[b] > 0) cuerpo.push_back(ext[b]);
    if (cuerpo.empty()) cuerpo.push_back(1);
    std::vector<float> o = cuerpo;
    std::nth_element(o.begin(), o.begin() + o.size() / 2, o.end());
    md.ancho = std::max(1.0f, o[o.size() / 2]);
    md.alargamiento = md.largo / md.ancho;
    int im = (int)(std::max_element(ext.begin(), ext.end()) - ext.begin());
    md.ancho_max_rel = ext[im] / md.largo;
    md.pos_max = im / (double)(NB - 1);
    md.conicidad = media(ext, 0, 2) / std::max(1.0, media(ext, NB - 3, NB - 1));
    int b50 = 0;
    while (b50 < NB && ext[b50] < 0.5 * md.ancho) b50++;
    md.punta_rel = b50 / (double)NB;
    {
        double s = 0, s2 = 0;
        int k = 0;
        for (int b = 6; b <= NB - 4; b++)
            if (ext[b] > 0) s += ext[b], s2 += ext[b] * ext[b], k++;
        if (k > 1) {
            double mu = s / k;
            md.variacion = std::sqrt(std::max(0.0, s2 / k - mu * mu)) / mu;
        }
    }
    md.panza = media(ext, 9, 14) / std::max(1.0, 0.5 * (media(ext, 1, 3) + media(ext, NB - 4, NB - 2)));
    md.perfil.resize(NB);
    for (int b = 0; b < NB; b++) md.perfil[b] = (float)(ext[b] / md.largo);
    // dos brazos: en cada corte transversal, el perfil de "que tan distinto al fondo" tiene DOS picos con un
    // valle entre ellos (aunque la sombra y el desenfoque llenen la mascara)
    if (!p.dif.empty()) {
        double smn = 1e9, smx = -1e9;
        for (int b = 0; b < NB; b++)
            if (cnt[b] > 0) smn = std::min(smn, (double)smin[b]), smx = std::max(smx, (double)smax[b]);
        int ns = std::max(1, (int)(smx - smn) + 5);
        std::vector<std::vector<float>> pr(NB, std::vector<float>(ns, 0.f));
        cv::Mat lld;
        cv::dilate(p.lleno, lld, cv::Mat::ones(3, 3, CV_8U));
        for (int y = 0; y < p.dif.rows; y++) {
            const uchar* r = p.dif.ptr<uchar>(y);
            const uchar* l = lld.ptr<uchar>(y);
            for (int x = 0; x < p.dif.cols; x++)
                if (l[x]) {
                    double dx = x - cx, dy = y - cy;
                    double t = dx * ex + dy * ey, sv = -dx * ey + dy * ex;
                    int b = std::min(NB - 1, std::max(0, (int)((t - tmin) / md.largo * NB)));
                    int k = (int)std::lround(sv - smn) + 2;
                    if (k >= 0 && k < ns) pr[b][k] = std::max(pr[b][k], (float)r[x]);
                }
        }
        int dos = 0, val = 0;
        for (int b = 1; b < NB - 1; b++) {
            auto& v = pr[b];
            float mx = *std::max_element(v.begin(), v.end());
            if (mx < 8 || ext[al_reves ? NB - 1 - b : b] < 3) continue;
            val++;
            // izquierda->derecha: el pico mas alto visto, el valle mas bajo despues de el, y otro pico
            float p1 = 0, valle = 1e9f;
            bool ok = false;
            for (float x : v) {
                if (p1 >= 0.45f * mx && x < valle) valle = std::min(valle, x);
                if (p1 < 0.45f * mx) p1 = std::max(p1, x);
                else if (x >= 0.45f * mx && valle < 0.6f * std::min(p1, x)) ok = true;
                if (x > p1 && valle > 1e8f) p1 = x;
            }
            if (ok) dos++;
        }
        md.brazos = val ? dos / (double)val : 0;
    }
    // solidez y muesca (V entre los brazos)
    std::vector<cv::Point> c;
    {
        std::vector<std::vector<cv::Point>> cs;
        cv::findContours(p.lleno.clone(), cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);
        for (auto& x : cs)
            if (x.size() > c.size()) c = x;
    }
    if (c.size() >= 5) {
        std::vector<cv::Point> h;
        cv::convexHull(c, h);
        double ah = cv::contourArea(h);
        md.solidez = ah > 0 ? std::min(1.0, md.area / ah) : 1;
        std::vector<int> hi;
        cv::convexHull(c, hi, false, false);
        if (hi.size() > 3) {
            std::vector<cv::Vec4i> df;
            try {
                cv::convexityDefects(c, hi, df);
            } catch (...) {
            }
            for (auto& v : df) {
                double dep = v[3] / 256.0;
                // largo de la muesca: distancia entre sus dos orillas a lo largo del eje
                cv::Point a = c[v[0]], z = c[v[1]], f = c[v[2]];
                double lm = std::fabs(((a.x + z.x) * 0.5 - f.x) * ex + ((a.y + z.y) * 0.5 - f.y) * ey);
                double prof = std::max(dep, lm) / md.largo;
                if (dep >= 1.5 && prof > md.muesca) {
                    md.muesca = prof;
                    double tf = (f.x - cx) * ex + (f.y - cy) * ey;
                    double u = (tf - tmin) / md.largo;
                    md.muesca_pos = al_reves ? 1 - u : u;
                }
            }
        }
    }
    // huecos (orejas = aros de los dedos)
    {
        cv::Mat lf = cv::Mat::zeros(p.m.size(), CV_8U);
        std::vector<std::vector<cv::Point>> cs;
        cv::findContours(p.m.clone(), cs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);
        cv::drawContours(lf, cs, -1, cv::Scalar(255), cv::FILLED);
        cv::Mat hu = lf & ~p.m;
        std::vector<std::vector<cv::Point>> hs;
        cv::findContours(hu, hs, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);
        for (auto& x : hs) {
            double a = cv::contourArea(x) + x.size() * 0.5;   // los huecos chicos: contar su orilla
            if (a < oreja_min || a > 0.4 * md.area) continue;
            cv::RotatedRect rr = cv::minAreaRect(x);
            double L = std::max(rr.size.width, rr.size.height), W = std::max(1.f, std::min(rr.size.width, rr.size.height));
            double tc = (rr.center.x - cx) * ex + (rr.center.y - cy) * ey;
            double u = (tc - tmin) / md.largo;
            if (al_reves) u = 1 - u;
            if (L / W < 3.2 && u >= 0.4) md.orejas++;
            else if (L / W >= 3.2) md.huecos_largos++;
        }
    }
    // piel (YCrCb): el pano verde y el metal gris no caen aqui
    {
        cv::Mat roi = img(p.caja), y;
        cv::cvtColor(roi, y, cv::COLOR_BGR2YCrCb);
        int k = 0, n = 0;
        for (int r = 0; r < y.rows; r++) {
            const cv::Vec3b* q = y.ptr<cv::Vec3b>(r);
            const uchar* l = p.lleno.ptr<uchar>(r);
            for (int x = 0; x < y.cols; x++)
                if (l[x]) {
                    n++;
                    if (q[x][0] > 40 && q[x][1] >= 138 && q[x][1] <= 180 && q[x][2] >= 75 && q[x][2] <= 128) k++;
                }
        }
        md.piel = n ? k / (double)n : 0;
    }
    if (px_por_mm > 0) md.largo_mm = md.largo / px_por_mm;
    return md;
}

// ====================================================================== 3) reglas
static double trap(double x, double a, double b, double c, double d) {
    if (x <= a || x >= d) return 0;
    if (x < b) return (x - a) / (b - a);
    if (x <= c) return 1;
    return (d - x) / (d - c);
}

Forma clasificar(const Medidas& md, double umbral) {
    Forma f;
    if (md.area <= 0) return f;
    double o = md.orejas >= 2 ? 1 : md.orejas == 1 ? 0.65 : 0;
    double V = std::max({md.huecos_largos > 0 ? 1.0 : 0.0, trap(md.muesca, 0.06, 0.15, 2, 3) * trap(md.muesca_pos, -1, 0, 0.55, 0.75),
                         trap(md.brazos, 0.12, 0.3, 1, 1.1)});
    // tijera: los aros (orejas) hacen un extremo MUCHO mas ancho que el centro (sin "panza", al reves)
    double extremo = std::max(trap(md.pos_max, -1, 0, 0.15, 0.3), trap(md.pos_max, 0.7, 0.85, 1, 1.01));
    double tij = 0.45 * o + 0.2 * trap(md.ancho_max_rel, 0.13, 0.19, 0.6, 0.8) + 0.15 * extremo + 0.2 * trap(md.panza, -1, 0, 0.75, 0.95);
    if (md.orejas == 0) tij *= 0.85;
    // barra larga sin aros: bisturi o pinza. La pinza es mas ancha al centro (agarre) que en sus extremos, mas
    // ancha en general y de ancho menos parejo; el bisturi es un mango parejo. Pesos ajustados con la simulacion
    // (austero-prueba-formas, ~90 % de acierto entre las dos); dos brazos separados = pinza segura.
    double barra = trap(md.alargamiento, 4, 5.5, 30, 40) * trap(md.ancho_max_rel, 0.02, 0.04, 0.2, 0.28) * trap(md.panza, 0.7, 0.95, 9, 10) *
                   (md.orejas >= 2 ? 0.3 : md.orejas == 1 ? 0.6 : 1);
    double z = 8.38 * md.panza - 0.233 * md.alargamiento + 60.6 * md.ancho_max_rel + 83.2 * md.variacion + 3.74 * md.brazos - 20.38;
    double q = std::max(1 / (1 + std::exp(-z)), V);
    double bis = barra * (1 - q);
    double pin = barra * q;
    double man = md.piel >= fv("mano_piel", 0.25) ? 0.6 + 0.4 * std::min(1.0, md.piel / 0.6) : 0;
    if (md.largo_mm > 0 && (md.largo_mm < 50 || md.largo_mm > 300)) tij *= 0.5, bis *= 0.5, pin *= 0.5;
    f.puntajes = {{"tijera", (float)tij}, {"bisturi", (float)bis}, {"pinza", (float)pin}, {"mano", (float)man}};
    for (auto& kv : f.puntajes)
        if (kv.second > f.conf) f.conf = kv.second, f.clase = kv.first;
    if (f.conf < umbral && f.clase != "mano") f.clase = "objeto";
    f.razon = fmt("orejas %d, largo/ancho %.1f, ancho max %.2f, panza %.2f, punta %.0f%%%s%s", md.orejas, md.alargamiento, md.ancho_max_rel, md.panza,
                  md.punta_rel * 100, V > 0.5 ? fmt(", 2 brazos %.0f%%", md.brazos * 100).c_str() : "", md.piel > 0.1 ? fmt(", piel %.0f%%", md.piel * 100).c_str() : "");
    if (md.largo_mm > 0) f.razon += fmt(", %.0f mm", md.largo_mm);
    return f;
}

std::string tipo_de(const std::string& c) {
    std::string s;
    for (char ch : c) s += (char)std::tolower((unsigned char)ch);
    if (s.find("tijer") != std::string::npos || s.find("scissor") != std::string::npos) return "tijera";
    if (s.find("bistur") != std::string::npos || s.find("scalpel") != std::string::npos || s.find("escalpelo") != std::string::npos)
        return "bisturi";
    if (s.find("pinza") != std::string::npos || s.find("forcep") != std::string::npos || s.find("tweez") != std::string::npos)
        return "pinza";
    if (s.find("mano") != std::string::npos || s.find("hand") != std::string::npos) return "mano";
    return "";
}
std::string nombre_tipo(const std::string& t) {
    if (t == "tijera") return "Tijera";
    if (t == "bisturi") return "Bisturi";
    if (t == "pinza") return "Pinza";
    if (t == "mano") return "mano";
    return "objeto";
}

// ====================================================================== 4) todo junto
static Det det_de(const Pieza& p, const Medidas& md) {
    Det d;
    d.caja = p.caja;
    d.contorno = p.contorno;
    d.angulo = md.angulo;
    return d;
}

std::vector<Det> aplicar_formas(const cv::Mat& img, const Contexto& ctx, const std::vector<Det>* red) {
    std::vector<Det> r;
    if (ctx.fondo.empty() || ctx.fondo.size() != img.size()) return red ? *red : r;
    double umbral = fv("formas_umbral", 0.4), peso = fv("formas_peso", 0.5);
    bool exigir = fv("formas_exigir", 1) > 0.5;
    auto ps = separar_piezas(img, ctx.fondo, ctx.mascara, fv("mascara_dif", 30), fv("mascara_area", 120));
    if (ps.size() > 25) ps.resize(25);
    std::vector<bool> usada(red ? red->size() : 0, false);
    for (auto& p : ps) {
        Medidas md = medir(p, img, ctx.px_por_mm, (int)fv("oreja_min", 4));
        Forma fm = clasificar(md, umbral);
        Det d = det_de(p, md);
        // la deteccion de la red que cae sobre esta pieza
        int j = -1;
        if (red)
            for (size_t k = 0; k < red->size(); k++) {
                cv::Rect in = (*red)[k].caja & p.caja;
                double s = in.area() / (double)std::max(1, std::min((*red)[k].caja.area(), p.caja.area()));
                if (s > 0.4) {
                    usada[k] = true;
                    if (j < 0 || (*red)[k].conf > (*red)[j].conf) j = (int)k;
                }
            }
        std::string t = j >= 0 ? tipo_de((*red)[j].clase) : "";
        // un brazo siempre entra por la orilla de la imagen: algo grande que toca la orilla es una mano
        bool orilla = p.caja.x <= 2 || p.caja.y <= 2 || p.caja.br().x >= img.cols - 2 || p.caja.br().y >= img.rows - 2;
        if (fm.clase != "mano" && orilla && md.area > 6 * fv("mascara_area", 120) && md.ancho_max_rel > 0.12) {
            fm.clase = "mano";
            fm.conf = std::max(fm.conf, 0.6f);
            fm.razon += ", entra por la orilla";
        }
        if (fm.clase == "mano") {
            d.clase = "mano";
            d.conf = fm.conf;
        } else if (j >= 0 && !t.empty() && t != "mano") {
            std::string mejor;
            float mc = -1;
            for (auto& kv : fm.puntajes) {
                if (kv.first == "mano") continue;
                float v = (float)((1 - peso) * kv.second + peso * (kv.first == t ? (*red)[j].conf : 0.0));
                if (v > mc) mc = v, mejor = kv.first;
            }
            d.clase = mejor == t ? (*red)[j].clase : nombre_tipo(mejor);
            d.conf = std::min(1.f, mc + (mejor == t ? 0.25f * fm.puntajes[t] : 0.f));
            d.info = fm.razon + fmt(" | red: %s %.0f%%", (*red)[j].clase.c_str(), (*red)[j].conf * 100);
        } else {
            if (red && fm.clase == "objeto") continue;   // con red: lo que nadie reconoce no se marca
            d.clase = nombre_tipo(fm.clase);
            d.conf = fm.conf;
        }
        if (d.info.empty()) d.info = fm.razon;
        r.push_back(d);
    }
    if (red && !exigir)
        for (size_t k = 0; k < red->size(); k++)
            if (!usada[k]) r.push_back((*red)[k]);
    return r;
}
