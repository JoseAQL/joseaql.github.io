# entrenar_alumno.py - para Google Colab (con GPU). Entrena el "alumno": un YOLO11 nano con las fotos que
# guardaste al ENSENAR piezas (carpeta dataset/ de la Jetson). Es el modelo chico que si corre rapido en la Nano.
#
# 1. En la Jetson:   cd v3_optimo && zip -r dataset.zip dataset
# 2. Sube dataset.zip y este archivo a Colab (Entorno de ejecucion -> GPU T4)
# 3. En una celda:   !pip -q install ultralytics onnx onnxslim
#                    !python entrenar_alumno.py
# 4. Baja alumno.zip, copialo a la Jetson y descomprimelo dentro de v3_optimo/ (crea modelos/yolo_alumno/)
# 5. En la Jetson:   ./instalar.sh --solo-compilar   (convierte a TensorRT)   y luego   austero modelo 9
import os
import random
import shutil
import zipfile

from ultralytics import YOLO

if not os.path.isdir("dataset"):
    zipfile.ZipFile("dataset.zip").extractall(".")
clases = [l.strip() for l in open("dataset/clases.txt") if l.strip()]
fotos = sorted(f for f in os.listdir("dataset/images") if f.endswith(".jpg"))
print(len(fotos), "fotos,", len(clases), "clases:", clases)

# separar 85 % entrenamiento / 15 % validacion
random.seed(42)
random.shuffle(fotos)
corte = max(1, int(len(fotos) * 0.15))
for parte, lista in (("val", fotos[:corte]), ("train", fotos[corte:])):
    for sub in ("images", "labels"):
        os.makedirs("ds/%s/%s" % (sub, parte), exist_ok=True)
    for f in lista:
        shutil.copy("dataset/images/" + f, "ds/images/%s/%s" % (parte, f))
        lab = "dataset/labels/" + f[:-4] + ".txt"
        if os.path.exists(lab):
            shutil.copy(lab, "ds/labels/%s/%s" % (parte, f[:-4] + ".txt"))
with open("ds/data.yaml", "w") as y:
    y.write("path: %s\ntrain: images/train\nval: images/val\nnames:\n" % os.path.abspath("ds"))
    for i, c in enumerate(clases):
        y.write("  %d: %s\n" % (i, c))

# pocas fotos -> mucho aumento de datos (giros, brillo, mosaico)
m = YOLO("yolo11n.pt")
m.train(data="ds/data.yaml", imgsz=320, epochs=120, batch=32, degrees=180, flipud=0.5, fliplr=0.5,
        hsv_v=0.5, mosaic=1.0, patience=30, project="alumno", name="run", exist_ok=True)

mejor = YOLO("alumno/run/weights/best.pt")
f = mejor.export(format="onnx", imgsz=320, opset=12, simplify=True, dynamic=False, batch=1)
os.makedirs("modelos/yolo_alumno", exist_ok=True)
shutil.copy(f, "modelos/yolo_alumno/modelo_320.onnx")
open("modelos/yolo_alumno/clases.txt", "w").write("\n".join(clases) + "\n")
shutil.make_archive("alumno", "zip", ".", "modelos")
print("Listo: alumno.zip")
try:
    from google.colab import files
    files.download("alumno.zip")
except Exception:
    pass
