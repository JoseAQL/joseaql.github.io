# convertir_modelos.py - para Google Colab (o una PC con Python). Baja los modelos libres de instrumental y los
# convierte a ONNX opset 12 (el maximo que acepta el TensorRT de JetPack 4.6). Al final deja modelos_austero.zip:
# copialo a la Jetson y descomprimelo dentro de v3_optimo/ (crea modelos/...). Luego: ./instalar.sh --solo-compilar
#
# En Colab, en una celda:
#   !pip -q install ultralytics onnx onnxslim huggingface_hub
#   !python convertir_modelos.py            (sube antes este archivo)
#
# Licencias: yolo_mit4 = MIT.  yolo_doccheck12 y orientacion = CC BY-NC 4.0 (sin uso comercial; escuela OK).
import os
import shutil
import subprocess
import sys
import urllib.request

OUT = "modelos"
os.makedirs(OUT, exist_ok=True)


def bajar(url, dest):
    if not os.path.exists(dest):
        print("bajando", url)
        urllib.request.urlretrieve(url, dest)
    return dest


# ------------------------------------------------------------------ 1) YOLO11-L MIT (4 clases)
def mit():
    from ultralytics import YOLO
    pt = bajar("https://raw.githubusercontent.com/amirrezamortazavifard/Surgical-Instrument-Detector/main/"
               "Python/YOLO_Result/weights/best.pt", "mit_best.pt")
    d = os.path.join(OUT, "yolo_mit4")
    os.makedirs(d, exist_ok=True)
    m = YOLO(pt)
    for lado in (320, 416):
        f = m.export(format="onnx", imgsz=lado, opset=12, simplify=True, dynamic=False, batch=1)
        shutil.move(f, os.path.join(d, "modelo_%d.onnx" % lado))
    open(os.path.join(d, "clases.txt"), "w").write("Bisturi\nPinza diseccion recta\nTijera Mayo recta\nTijera Mayo curva\n")
    print("ok yolo_mit4")


# ------------------------------------------------------------------ 2) YOLOv5-L DocCheck (12 clases)
def doccheck():
    from huggingface_hub import hf_hub_download
    pt = hf_hub_download("DocCheck/medical-instrument-detection", "instrument_detector_model.pt")
    if not os.path.isdir("yolov5"):
        subprocess.check_call(["git", "clone", "--depth", "1", "https://github.com/ultralytics/yolov5"])
    subprocess.check_call([sys.executable, "-m", "pip", "-q", "install", "-r", "yolov5/requirements.txt"])
    d = os.path.join(OUT, "yolo_doccheck12")
    os.makedirs(d, exist_ok=True)
    for lado in (416, 640):
        subprocess.check_call([sys.executable, "yolov5/export.py", "--weights", pt, "--include", "onnx",
                               "--opset", "12", "--imgsz", str(lado), "--simplify"])
        shutil.move(pt.replace(".pt", ".onnx"), os.path.join(d, "modelo_%d.onnx" % lado))
    print("ok yolo_doccheck12")


# ------------------------------------------------------------------ 3) orientacion DocCheck (AlexNet, 128x128 gris)
def orientacion():
    import torch
    from huggingface_hub import hf_hub_download
    pt = hf_hub_download("DocCheck/medical-instrument-orientation-estimation", "orientation_estimation_model.pt")
    if not os.path.isdir("Instrument-Orientation-Estimator"):
        subprocess.check_call(["git", "clone", "--depth", "1", "https://github.com/DocCheck/Instrument-Orientation-Estimator"])
    sys.path.insert(0, "Instrument-Orientation-Estimator")
    import model as M  # noqa: E402  (para que torch.load encuentre la clase AlexNet)
    obj = torch.load(pt, map_location="cpu", weights_only=False)
    if isinstance(obj, dict):   # si guardaron solo los pesos
        sd = obj.get("state_dict", obj)
        n = [v for k, v in sd.items() if k.endswith("weight")][-1].shape[0]
        red = M.AlexNet(num_classes=n)
        red.load_state_dict(sd)
    else:
        red = obj
    red.eval()
    d = os.path.join(OUT, "orientacion")
    os.makedirs(d, exist_ok=True)
    torch.onnx.export(red, torch.zeros(1, 1, 128, 128), os.path.join(d, "modelo.onnx"), opset_version=12,
                      input_names=["entrada"], output_names=["angulos"])
    print("ok orientacion")


for nombre, f in (("yolo_mit4", mit), ("yolo_doccheck12", doccheck), ("orientacion", orientacion)):
    try:
        f()
    except Exception as e:  # que un modelo que falle no tumbe a los demas
        print("FALLO", nombre, ":", e)

shutil.make_archive("modelos_austero", "zip", ".", OUT)
print("\nListo: modelos_austero.zip  -> copialo a la Jetson y descomprimelo dentro de v3_optimo/")
try:
    from google.colab import files
    files.download("modelos_austero.zip")
except Exception:
    pass
