#!/bin/bash
# optimizar_jetson.sh - deja la Jetson Nano lo mas ligera posible para el Modo Austero. Todo se puede deshacer.
#   sudo ./herramientas/optimizar_jetson.sh             aplicar
#   sudo ./herramientas/optimizar_jetson.sh --deshacer  regresar todo como estaba
#   sudo ./herramientas/optimizar_jetson.sh --sudoers   solo permitir 'austero perfil' sin contrasena
#   sudo ./herramientas/optimizar_jetson.sh --sin-docker   ademas apagar docker
#
# Que hace (y cuanto ahorra, aprox.):
#   - arrancar sin escritorio (multi-user.target)                      ~500-800 MB de RAM y CPU
#   - apagar servicios que no usas (impresoras, bluetooth, modem, reportes, actualizaciones automaticas)
#   - consola tty1 sin login para que el proyector (framebuffer) quede limpio
#   - permiso para que el grupo video use /dev/tty1 (apagar el texto de la consola)
#   - nvpmodel/jetson_clocks sin contrasena para 'austero perfil' y el reposo
# SSH y Tailscale NO se tocan.
set -e
[ "$(id -u)" = 0 ] || { echo "corre con sudo"; exit 1; }
USUARIO="${SUDO_USER:-$USER}"
ESTADO=/var/lib/austero/estado_previo
mkdir -p /var/lib/austero
SERVICIOS="cups cups-browsed bluetooth ModemManager whoopsie kerneloops unattended-upgrades apt-daily.timer apt-daily-upgrade.timer avahi-daemon"
[ "$1" = "--sin-docker" ] && SERVICIOS="$SERVICIOS docker containerd"

sudoers() {
  cat > /etc/sudoers.d/austero <<EOF
$USUARIO ALL=(root) NOPASSWD: /usr/sbin/nvpmodel, /usr/bin/jetson_clocks
EOF
  chmod 440 /etc/sudoers.d/austero
  visudo -cf /etc/sudoers.d/austero >/dev/null && echo "sudoers: $USUARIO puede usar nvpmodel y jetson_clocks sin contrasena"
}

if [ "$1" = "--sudoers" ]; then sudoers; exit 0; fi

if [ "$1" = "--deshacer" ]; then
  [ -f "$ESTADO" ] || { echo "no hay nada que deshacer"; exit 0; }
  . "$ESTADO"
  systemctl set-default "${OBJETIVO:-graphical.target}"
  for s in $ACTIVOS; do systemctl enable "$s" 2>/dev/null && echo "  reactivado $s"; done
  systemctl unmask getty@tty1.service 2>/dev/null || true
  rm -f /etc/udev/rules.d/99-austero-tty.rules /etc/sudoers.d/austero
  udevadm control --reload-rules || true
  rm -f "$ESTADO"
  echo "Listo: todo como antes. Reinicia: sudo reboot"
  exit 0
fi

# ---- guardar como estaba (para --deshacer)
if [ ! -f "$ESTADO" ]; then
  ACT=""
  for s in $SERVICIOS; do systemctl is-enabled "$s" >/dev/null 2>&1 && ACT="$ACT $s"; done
  echo "OBJETIVO=$(systemctl get-default)" > "$ESTADO"
  echo "ACTIVOS=\"$ACT\"" >> "$ESTADO"
fi

echo "== sin escritorio al arrancar"
systemctl set-default multi-user.target

echo "== servicios que no se usan"
for s in $SERVICIOS; do
  if systemctl is-enabled "$s" >/dev/null 2>&1; then
    systemctl disable --now "$s" >/dev/null 2>&1 && echo "  apagado $s"
  fi
done

echo "== consola limpia para el proyector"
systemctl mask getty@tty1.service >/dev/null 2>&1 || true
echo 'KERNEL=="tty1", GROUP="video", MODE="0660"' > /etc/udev/rules.d/99-austero-tty.rules
udevadm control --reload-rules && udevadm trigger || true

sudoers
nvpmodel -m 0 >/dev/null 2>&1 || true

echo
echo "Listo. Reinicia (sudo reboot). Despues entra por SSH/Tailscale y usa:  austero start"
echo "Para regresar el escritorio y todo lo demas:  sudo $0 --deshacer"
echo "Para usar el escritorio solo una vez sin deshacer:  sudo systemctl start gdm3"
