@echo off
chcp 65001 >nul
rem ==== Actualizar el Modo Austero en la Jetson (no borra tus ajustes, calibracion ni ejemplos) ====
set JETSON=jetson@100.120.239.19
cd /d "%~dp0"
echo [1/2] Copiando la version nueva... escribe la contrasena de la Jetson.
scp modo-austero-v3.zip %JETSON%:~/
if errorlevel 1 ( echo No se pudo copiar. & pause & exit /b )
echo [2/2] Compilando y reiniciando... escribe la contrasena otra vez.
echo No des clic dentro de esta ventana (se congela). Si dice "Seleccionar", presiona Esc.
ssh -t %JETSON% "cd ~/modo_austero && python3 -m zipfile -e ~/modo-austero-v3.zip . && cd v3_optimo && chmod +x austero instalar.sh herramientas/*.sh && ./instalar.sh --solo-compilar && ./austero restart"
echo.
echo Listo. En MobaXterm:  austero ver   y presiona L para el Laboratorio
echo Pagina web:  austero web on   y abre http://100.120.239.19:8091/lab
pause
