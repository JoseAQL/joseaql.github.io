@echo off
chcp 65001 >nul
set JETSON=jetson@100.120.239.19
echo Apagando el Modo Austero... escribe la contrasena cuando la pida.
ssh -t %JETSON% "~/modo_austero/v3_optimo/austero stop"
pause
