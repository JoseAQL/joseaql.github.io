@echo off
chcp 65001 >nul
rem ==== Apagar el proyecto anterior, reiniciar el Modo Austero y abrir el tablero ====
set JETSON=jetson@100.120.239.19
echo Conectando con la Jetson... escribe la contrasena cuando la pida (y otra vez para sudo).
echo No des clic dentro de esta ventana: se congela. Si el titulo dice "Seleccionar", presiona Esc.
echo En el tablero: i = ver camara, 4 = YOLO, 1 = fondo, c = calibrar, q = salir del tablero, Q = apagar
ssh -t %JETSON% "python3 ~/inicio/inicio.py detener >/dev/null 2>&1; sudo systemctl stop inicio-proyector 2>/dev/null; ~/modo_austero/v3_optimo/austero restart; sleep 3; ~/modo_austero/v3_optimo/austero ver"
pause
