@echo off
chcp 65001 >nul
rem ==== Modo Austero v3: copiar e instalar en la Jetson desde Windows, con un clic ====
rem Pon este .bat en la MISMA carpeta que modo-austero-v3.zip y modelos_yolo_mit4.zip
rem Si estas en la red de tu casa sin Tailscale, cambia la IP de abajo.
set JETSON=jetson@100.120.239.19
cd /d "%~dp0"

if not exist modo-austero-v3.zip (
  echo Falta modo-austero-v3.zip en esta carpeta.
  pause & exit /b
)
set MODELO=
if exist modelos_yolo_mit4.zip set MODELO=modelos_yolo_mit4.zip

echo.
echo [1/2] Copiando a la Jetson... escribe la contrasena de la Jetson cuando la pida.
scp modo-austero-v3.zip %MODELO% %JETSON%:~/
if errorlevel 1 (
  echo No se pudo copiar. Revisa que la Jetson este prendida y con Tailscale.
  pause & exit /b
)

echo.
echo [2/2] Instalando... pide la contrasena otra vez y luego la de sudo.
ssh -t %JETSON% "mkdir -p ~/modo_austero && cd ~/modo_austero && python3 -m zipfile -e ~/modo-austero-v3.zip . && cd v3_optimo && (test -f ~/modelos_yolo_mit4.zip && python3 -m zipfile -e ~/modelos_yolo_mit4.zip . || true) && chmod +x austero instalar.sh herramientas/*.sh && ./instalar.sh"

echo.
echo Listo. Entra con MobaXterm y escribe:  austero start   y luego   austero ver
pause
