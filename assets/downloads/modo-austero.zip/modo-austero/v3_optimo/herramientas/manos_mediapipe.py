#!/usr/bin/env python3
"""manos_mediapipe.py - manos para el Modo Austero donde no hay GPU de NVIDIA (Raspberry Pi 4B, PC).

Programa APARTE (si no lo prendes, no gasta nada):  austero manos-mp on | off
Le pide al nucleo una imagen chica de la camara por el socket, busca manos con MediaPipe y le manda
los 21 puntos de cada mano con el comando "manos_ext". El nucleo las usa igual que las de poseNet:
zonas prohibidas, "quita la mano", grabar haciendo.

  --ancho 320     tamano de la imagen que se analiza (mas chico = mas rapido)
  --fps 6         cuantas veces por segundo (en la Pi 4: 5-7 es lo normal)
"""
import argparse
import os
import socket
import sys
import time

SOCK = os.environ.get("AUSTERO_SOCKET", "/tmp/austero.sock")


def pedir(linea):
    """Manda un comando al nucleo. Devuelve (cabecera, binario)."""
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(5)
    s.connect(SOCK)
    s.sendall((linea + "\n").encode())
    datos = b""
    while True:
        b = s.recv(65536)
        if not b:
            break
        datos += b
    s.close()
    cab, _, resto = datos.partition(b"\n")
    binario = b""
    if resto.startswith(b"bin "):
        n, _, r2 = resto.partition(b"\n")
        binario = r2[: int(n[4:])]
    return cab.decode(errors="replace"), binario


def texto_manos(manos, w, h):
    """[[(x,y)...], ...] en pixeles -> 'x,y;x,y|x,y;...'"""
    return "|".join(";".join("%d,%d" % (x, y) for x, y in m) for m in manos)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ancho", type=int, default=320)
    ap.add_argument("--fps", type=float, default=6)
    ap.add_argument("--probar", action="store_true", help="manda una mano falsa (para probar sin mediapipe)")
    a = ap.parse_args()

    if a.probar:
        w, h = 320, 240
        mano = [(200 + i * 3, 150 + (i % 5) * 6) for i in range(21)]
        print(pedir("manos_ext %d %d %s" % (w, h, texto_manos([mano], w, h)))[0])
        return

    import cv2
    import numpy as np
    import mediapipe as mp

    det = mp.solutions.hands.Hands(static_image_mode=False, max_num_hands=2, model_complexity=0,
                                   min_detection_confidence=0.5, min_tracking_confidence=0.5)
    periodo = 1.0 / max(0.5, a.fps)
    habia = False
    while True:
        t0 = time.time()
        try:
            _, jpg = pedir("jpeg 75 %d 1" % a.ancho)   # panel 1 = camara sin dibujos
            if jpg:
                img = cv2.imdecode(np.frombuffer(jpg, np.uint8), cv2.IMREAD_COLOR)
                h, w = img.shape[:2]
                r = det.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
                manos = []
                for m in (r.multi_hand_landmarks or []):
                    manos.append([(int(p.x * w), int(p.y * h)) for p in m.landmark])
                if manos or habia:   # si no hay manos se avisa una sola vez (para borrar las viejas)
                    pedir("manos_ext %d %d %s" % (w, h, texto_manos(manos, w, h)))
                habia = bool(manos)
        except (OSError, socket.error):
            time.sleep(2)   # el nucleo esta apagado: esperar sin gastar
        except Exception as e:   # noqa
            print("error:", e, file=sys.stderr)
            time.sleep(1)
        time.sleep(max(0.0, periodo - (time.time() - t0)))


if __name__ == "__main__":
    main()
