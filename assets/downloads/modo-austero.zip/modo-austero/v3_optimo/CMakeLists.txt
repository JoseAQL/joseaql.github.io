# Modo Austero v3 (optimizado) - Jetson Nano, JetPack 4.6 (gcc 7.5, OpenCV 4.1.1, TensorRT 8, CUDA 10.2)
# En una PC compila igual (sin TensorRT ni jetson-inference) para probar con camara y proyector simulados.
#
#   austero-nucleo          el proceso de fondo (un hilo; solo OpenCV core/imgproc/imgcodecs/calib3d/features2d)
#   austero-cli             comandos y tablero de terminal (sin OpenCV)
#   austero-web             pagina web opcional (sin OpenCV)
#   libaustero_trt.so       YOLO/orientacion con TensorRT          } se cargan con dlopen SOLO al activarlos
#   libaustero_ji.so        detectNet, poseNet, backgroundNet      } y se descargan al apagarlos
#   libaustero_cvdnn.so     YOLO/orientacion en CPU (PC)           }
#   libaustero_ventana.so   salida en ventana X (si usas escritorio)
cmake_minimum_required(VERSION 3.10)
project(modo_austero_v3 CXX)

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")
if(CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64")
  set(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS_RELEASE} -mcpu=cortex-a57")   # CPU de la Nano
endif()
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR})
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR})

option(ARUCO_INCLUIDO "usar siempre la copia de ArUco incluida" OFF)

find_package(Threads REQUIRED)
find_package(OpenCV REQUIRED COMPONENTS core imgproc imgcodecs calib3d features2d)
include_directories(src)

# ---------------------------------------------------------------- ArUco
# El OpenCV 4.1.1 de JetPack NO trae aruco (es de opencv_contrib): se compila la copia de src/aruco (BSD).
if(NOT ARUCO_INCLUIDO)
  find_package(OpenCV QUIET COMPONENTS aruco)
endif()
if(NOT ARUCO_INCLUIDO AND OpenCV_aruco_FOUND)
  message(STATUS "ArUco: el de tu OpenCV")
  set(ARUCO_LIB opencv_aruco)
else()
  message(STATUS "ArUco: copia incluida (src/aruco)")
  file(GLOB ARUCO_SRC src/aruco/src/*.cpp)
  add_library(aruco_austero STATIC ${ARUCO_SRC})
  set_property(TARGET aruco_austero PROPERTY POSITION_INDEPENDENT_CODE ON)
  target_include_directories(aruco_austero PUBLIC src/aruco/include PRIVATE src/aruco/src ${OpenCV_INCLUDE_DIRS})
  target_link_libraries(aruco_austero PUBLIC opencv_core opencv_imgproc opencv_calib3d)
  set(ARUCO_LIB aruco_austero)
endif()

# ---------------------------------------------------------------- nucleo
add_executable(austero-nucleo src/nucleo.cpp src/base.cpp src/camara.cpp src/salida.cpp src/calibracion.cpp
               src/memoria.cpp src/stats.cpp src/modelos.cpp src/filtros.cpp
               src/formas.cpp src/escena.cpp src/escenarios.cpp)
target_include_directories(austero-nucleo PRIVATE ${OpenCV_INCLUDE_DIRS})
target_link_libraries(austero-nucleo opencv_core opencv_imgproc opencv_imgcodecs opencv_calib3d opencv_features2d
                      ${ARUCO_LIB} ${CMAKE_DL_LIBS} Threads::Threads)
set_property(TARGET austero-nucleo PROPERTY ENABLE_EXPORTS ON)   # los complementos usan sus funciones

# ---------------------------------------------------------------- simulacion de formas (prueba sin camara)
add_executable(austero-prueba-formas src/prueba_formas.cpp src/formas.cpp src/escena.cpp src/filtros.cpp src/base.cpp)
target_include_directories(austero-prueba-formas PRIVATE ${OpenCV_INCLUDE_DIRS})
target_link_libraries(austero-prueba-formas opencv_core opencv_imgproc opencv_imgcodecs Threads::Threads)

# ---------------------------------------------------------------- programas chicos (sin OpenCV)
add_executable(austero-cli src/cliente.cpp src/base.cpp)
target_link_libraries(austero-cli Threads::Threads)
add_executable(austero-web src/web.cpp src/base.cpp)
target_link_libraries(austero-web Threads::Threads)

# ---------------------------------------------------------------- complementos
function(complemento nombre)
  add_library(austero_${nombre} MODULE ${ARGN})
  target_include_directories(austero_${nombre} PRIVATE ${OpenCV_INCLUDE_DIRS})
  set_target_properties(austero_${nombre} PROPERTIES PREFIX "lib")
endfunction()

find_package(OpenCV QUIET COMPONENTS dnn)
if(OpenCV_dnn_FOUND OR TARGET opencv_dnn)
  complemento(cvdnn src/complementos/cvdnn.cpp)
  target_link_libraries(austero_cvdnn opencv_dnn opencv_imgproc opencv_core)
endif()

find_package(OpenCV QUIET COMPONENTS highgui)
if(OpenCV_highgui_FOUND OR TARGET opencv_highgui)
  complemento(ventana src/complementos/ventana.cpp)
  target_link_libraries(austero_ventana opencv_highgui opencv_core)
endif()

# CUDA + TensorRT
find_path(CUDA_INC cuda_runtime_api.h PATHS /usr/local/cuda/include)
find_library(CUDART_LIB cudart PATHS /usr/local/cuda/lib64)
find_path(TRT_INC NvInfer.h PATHS /usr/include/aarch64-linux-gnu /usr/include /usr/local/TensorRT/include)
find_library(TRT_LIB nvinfer PATHS /usr/lib/aarch64-linux-gnu /usr/lib /usr/local/TensorRT/lib)
find_library(TRT_ONNX_LIB nvonnxparser PATHS /usr/lib/aarch64-linux-gnu /usr/lib /usr/local/TensorRT/lib)
if(CUDA_INC AND CUDART_LIB AND TRT_INC AND TRT_LIB AND TRT_ONNX_LIB)
  message(STATUS "TensorRT: si")
  complemento(trt src/complementos/trt.cpp)
  target_include_directories(austero_trt PRIVATE ${CUDA_INC} ${TRT_INC})
  target_link_libraries(austero_trt ${TRT_LIB} ${TRT_ONNX_LIB} ${CUDART_LIB} opencv_imgproc opencv_core)
else()
  message(STATUS "TensorRT: no (los YOLO usaran el complemento cvdnn en CPU)")
endif()

# jetson-inference
find_path(JI_INC jetson-inference/detectNet.h PATHS /usr/local/include /usr/include)
find_library(JI_LIB jetson-inference PATHS /usr/local/lib /usr/lib)
find_library(JU_LIB jetson-utils PATHS /usr/local/lib /usr/lib)
if(JI_INC AND JI_LIB AND JU_LIB AND CUDA_INC AND TRT_INC)
  message(STATUS "jetson-inference: si")
  complemento(ji src/complementos/ji.cpp)
  target_include_directories(austero_ji PRIVATE ${JI_INC} ${CUDA_INC} ${TRT_INC})
  target_link_libraries(austero_ji ${JI_LIB} ${JU_LIB} ${CUDART_LIB} opencv_imgproc opencv_core)
else()
  message(STATUS "jetson-inference: no (ssd, fondo_ia y manos no estaran)")
endif()
