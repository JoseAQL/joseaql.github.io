#!/bin/bash
# Instala el menú NOMAD y las apps en Raspberry Pi OS Lite (sin escritorio).
# Uso:  sudo bash instalar-menu.sh
CARPETA="$(cd "$(dirname "$0")" && pwd)"

if [ "$EUID" -ne 0 ]; then
  echo "Ejecuta con sudo: sudo bash instalar-menu.sh"; exit 1
fi

echo "==> 1/4 Base: SSH con gráficos (X11), menú y herramientas de texto"
apt update
# xauth es OBLIGATORIO para que ssh -X funcione en la versión Lite
apt install -y openssh-server xauth whiptail \
  mc htop ncdu micro w3m qalc minicom

# Activa el reenvío de gráficos en SSH
sed -i 's/^#\?X11Forwarding.*/X11Forwarding yes/' /etc/ssh/sshd_config
grep -q '^X11Forwarding yes' /etc/ssh/sshd_config || echo 'X11Forwarding yes' >> /etc/ssh/sshd_config
systemctl restart ssh

echo "==> 2/4 Apps de electrónica (una por una; si alguna no existe, se salta)"
APPS="kicad fritzing gerbv xschem qucs-s ngspice arduino thonny geany \
      gtkwave magic iverilog verilator yosys nextpnr-ice40 fpga-icestorm \
      pulseview sigrok-cli cutecom avrdude dfu-util esptool openocd gcc-arm-none-eabi \
      freecad openscad prusa-slicer octave inkscape libreoffice"
FALLARON=""
for app in $APPS; do
  echo "--- $app"
  apt install -y --no-install-recommends "$app" || FALLARON="$FALLARON $app"
done

echo "==> 3/4 Copiando el menú"
mkdir -p /etc/nomad
install -m 755 "$CARPETA/nomad-menu" /usr/local/bin/nomad-menu
ln -sf /usr/local/bin/nomad-menu /usr/local/bin/menu
[ -f /etc/nomad/apps.conf ] || cp "$CARPETA/apps.conf" /etc/nomad/apps.conf

echo "==> 4/4 El menú se abrirá solo al entrar por SSH"
cat > /etc/profile.d/nomad-menu.sh <<'EOF'
# Abre el menú NOMAD al entrar por SSH (no en scripts ni en scp)
if [ -n "$SSH_TTY" ] && [ -z "$NOMAD_MENU" ] && [ -x /usr/local/bin/nomad-menu ]; then
  /usr/local/bin/nomad-menu
  [ $? -eq 10 ] && exit
fi
EOF

echo ""
echo "✅ Listo. Desde tu PC entra con:   ssh -X $SUDO_USER@nomad.lan"
[ -n "$FALLARON" ] && echo "⚠️  No se pudieron instalar:$FALLARON  (pásale esta lista a Claude)"
echo "Para editar la lista de apps:      sudo nano /etc/nomad/apps.conf"
