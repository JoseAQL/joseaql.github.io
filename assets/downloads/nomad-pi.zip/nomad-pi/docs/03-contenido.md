# 3. Contenido offline

[⬅ Volver al índice](../README.md)

## Cómo funciona Kiwix

Kiwix lee archivos **`.zim`**: cada uno es un sitio web completo comprimido (Wikipedia, WikiMed, iFixit…).
El instalador base dejó Kiwix sirviendo **todos** los `.zim` que pongas en:
```
/srv/nomad/zim/
```
y se ven en **http://nomad.lan:8080**.

## Descargar contenido (con internet)

1. Entra en **https://download.kiwix.org/zim/** desde tu PC y busca el archivo más reciente que quieras.
2. En la Pi:
   ```bash
   cd /srv/nomad/zim
   sudo wget -c https://download.kiwix.org/zim/wikipedia/NOMBRE_EXACTO.zim
   sudo systemctl restart kiwix
   ```
   `-c` permite **continuar** la descarga si se corta.

### Qué descargar (tamaños aproximados)

| Contenido | Carpeta en download.kiwix.org | Tamaño aprox. |
|---|---|---|
| Wikipedia español **sin imágenes** (`wikipedia_es_all_nopic`) | `wikipedia/` | ~12–15 GB |
| Wikipedia español **con imágenes** (`wikipedia_es_all_maxi`) | `wikipedia/` | ~35–45 GB |
| Wikipedia español solo artículos principales (`top` / `mini`) | `wikipedia/` | pocos GB, para pruebas |
| **WikiMed** español (medicina y primeros auxilios) | `wikipedia/` (busca `medicine`) | 1–10 GB |
| **iFixit** (guías de reparación) | `ifixit/` | unos GB |
| **Electronics StackExchange** | `stack_exchange/` | ~4–5 GB |
| StackExchange de cocina, bricolaje (DIY)… | `stack_exchange/` | variable |
| **Wikiviajes** / **Wikilibros** español | `wikivoyage/`, `wikibooks/` | ~1–3 GB |
| **Proyecto Gutenberg** (libros) | `gutenberg/` | 5–70 GB según idioma |
| **TED Talks** | `ted/` | variable |

Los tamaños cambian con cada versión; revisa el tamaño en la página antes de descargar.

## 💾 ¿Cuánto cabe? (ejemplo con disco de 125 GB)

De 125 GB, en la práctica se pueden usar unos **115 GB**. Deja siempre **10–15 GB libres**.

### Reparto recomendado (con apps de electrónica)
| Qué | Espacio |
|---|---|
| Sistema Lite | ~3 GB |
| Apps de electrónica (KiCad, FreeCAD…) | ~15 GB |
| Apps diarias y servicios web | ~4 GB |
| Wikipedia español sin imágenes | ~15 GB |
| WikiMed, iFixit, Electronics StackExchange | ~10 GB |
| Wikiviajes, Wikilibros, Gutenberg español | ~8 GB |
| Mapas de tu país | ~5 GB |
| **Total** | **~60 GB** |
| **Libre para mangas, juegos, música, películas** | **~50 GB** |

### Si no quieres apps de electrónica
| Plan A: Wikipedia con imágenes | Plan B: más cursos y archivos |
|---|---|
| Sistema ~10 GB | Sistema ~10 GB |
| Wikipedia con imágenes ~40 GB | Wikipedia sin imágenes ~15 GB |
| WikiMed ~2 GB, mapas ~5 GB, Wikilibros/viajes ~3 GB | WikiMed, mapas y Wikilibros ~10 GB |
| Cursos ~20 GB | Cursos Khan Academy ~40 GB |
| Archivos ~15 GB | Archivos/música/películas ~25 GB |
| Libre ~20 GB | Libre ~15 GB |

### Otros tamaños de referencia
| Qué | Tamaño |
|---|---|
| Mangas | 30–80 MB por tomo |
| Juegos retro 8/16 bits | 1–2 GB para cientos de juegos |
| Juegos PS1 | 300–700 MB cada uno |
| Películas MP4 | 1–4 GB cada una |

Ver espacio:
```bash
df -h          # libre en disco
sudo ncdu /    # qué ocupa más (navega con flechas)
```

---

## Cursos: Kolibri (opcional)

Plataforma educativa offline (Khan Academy en español, CK-12 y más). Instálalo siguiendo **learningequality.org/kolibri** y configúralo en el **puerto 8083** para que coincida con la tarjeta de la página.

## Mapas

- Guarda mapas en PDF o imagen en `/var/www/html/mapas/`.
- Para mapas navegables offline, una opción es descargar los mapas de tu país para **OsmAnd** u **Organic Maps** (apps de celular) y compartirlos desde la sección Archivos.

## Archivos: File Browser (opcional)

Para subir y bajar archivos desde el navegador (puerto 8082, como espera la página):
```bash
curl -fsSL https://raw.githubusercontent.com/filebrowser/get/master/get.sh | bash
sudo mkdir -p /srv/nomad/archivos && sudo chown $USER: /srv/nomad/archivos
cd ~ && filebrowser -r /srv/nomad/archivos -a 0.0.0.0 -p 8082
```
El usuario es `admin`. Las versiones nuevas muestran una contraseña aleatoria en pantalla la primera vez (anótala); las antiguas usan `admin`/`admin`. Cámbiala al entrar.
Para que arranque solo al encender, conviene crearle un servicio systemd igual que el de Kiwix (`/etc/systemd/system/kiwix.service` sirve de ejemplo).

[⬅ Instalación base](02-instalacion-base.md) · [Siguiente: Menú y apps ➡](04-menu-y-apps.md)
