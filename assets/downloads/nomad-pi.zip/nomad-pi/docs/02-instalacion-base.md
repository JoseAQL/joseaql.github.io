# 2. Instalación base

[⬅ Volver al índice](../README.md)

Al final de esta guía tendrás:
- La Pi emitiendo una red WiFi **NOMAD**
- Una página principal en **http://nomad.lan**
- Kiwix listo para la Wikipedia offline (puerto 8080)

---

## Paso 1: Grabar el sistema

1. En tu PC instala **Raspberry Pi Imager** (raspberrypi.com/software).
2. Elige:
   - Dispositivo: **Raspberry Pi 4**
   - Sistema: **Raspberry Pi OS Lite (64-bit)**. Lite = sin escritorio, más ligero; para el menú de apps no hace falta escritorio.
   - Almacenamiento: tu SSD o microSD
3. En **Editar ajustes** (el engranaje):
   - Nombre del equipo: `raspberrypi` (o `nomad`)
   - Usuario y contraseña
   - Tu WiFi de casa (para la primera conexión)
   - Pestaña Servicios: **Activar SSH**
4. Graba, conecta el disco a la Pi y enciéndela. Espera ~2 minutos.

> Usa la versión de **64 bits**. Kavita y RomM la necesitan.

## Paso 2: Conectarte por SSH

Desde tu PC (en Windows: PowerShell o MobaXterm):
```bash
ssh tu_usuario@raspberrypi.local
```
Si no la encuentra, mira la IP de la Pi en la página de tu router y usa `ssh tu_usuario@192.168.X.X`.

Actualiza el sistema:
```bash
sudo apt update && sudo apt upgrade -y
```

## Paso 3: Descargar este proyecto

```bash
sudo apt install -y git
git clone https://github.com/joseantonioquirozluna-crypto/Pruebas-.git
cd Pruebas-/nomad-pi
```

## Paso 4: Elegir la clave del WiFi

```bash
nano instalar.sh
```
Cambia estas líneas si quieres:
```bash
SSID="NOMAD"          # nombre de la red
CLAVE="nomad12345"    # tu clave (mínimo 8 caracteres)
```
Guarda con `Ctrl+O`, Enter, y sal con `Ctrl+X`.

## Paso 5: Ejecutar el instalador

⚠️ **Conecta la Pi al router por cable de red.** Al final, el WiFi de la Pi deja de conectarse a tu casa y pasa a ser el hotspot, así que:
- Con cable, la Pi sigue teniendo internet y no pierdes el SSH.
- Sin cable, el SSH se cortará al final. Es normal: conéctate a la red NOMAD y entra con `ssh tu_usuario@10.42.0.1`.

```bash
sudo bash instalar.sh wlan0     # WiFi interno
# o
sudo bash instalar.sh wlan1     # adaptador USB (ALFA, etc.)
```

El script hace esto:
1. Instala **Nginx** (servidor web) y **kiwix-tools**
2. Copia la página `web/index.html` y crea las carpetas `/mapas/` y `/guias/`
3. Crea el servicio **kiwix** (Wikipedia en el puerto 8080, arranca solo)
4. Configura el nombre **nomad.lan**
5. Crea el **hotspot** y lo deja activo al encender

## Paso 6: Probar

1. En tu celular busca la red **NOMAD** y conéctate.
2. Abre **http://nomad.lan** (o **http://10.42.0.1**).
3. Verás la página con tarjetas. Casi todas dirán "apagado" hasta que añadas contenido y servicios.

---

## Personalizar la página

```bash
sudo nano /var/www/html/index.html
```
- **Avisos**: busca `<li>Bienvenido...` y escribe tus mensajes.
- **Tarjetas de servicios**: busca `const SERVICIOS = [`. Cada línea es una tarjeta:
  ```js
  { icono: "📚", nombre: "Wikipedia", desc: "Enciclopedia offline.", puerto: 8080 },
  { icono: "🗺️", nombre: "Mapas",     desc: "Mapas de la zona.",    ruta: "/mapas/" },
  ```
  `puerto` es un servicio en la Pi; `ruta` es una carpeta dentro de `/var/www/html/`.
- La página revisa sola qué servicios responden y les pone **en línea** o **apagado**.
- No usa nada de internet: funciona 100% offline, y tiene modo oscuro automático.

Para poner PDFs o imágenes en Mapas o Primeros auxilios, cópialos a `/var/www/html/mapas/` y `/var/www/html/guias/`.

## Comandos útiles del hotspot

```bash
nmcli connection show                 # ver conexiones
sudo nmcli connection down Hotspot    # apagar hotspot (vuelve a tu WiFi de casa)
sudo nmcli connection up Hotspot      # encenderlo
hostname -I                           # ver IPs de la Pi
```

---

## Alternativa todo-en-uno: Internet-in-a-Box

Si prefieres algo ya hecho en lugar de este proyecto, **Internet-in-a-Box** instala hotspot, página, Kiwix, Kolibri y mapas con un solo comando:
```bash
curl d.iiab.io/install.txt | sudo bash
```
Luego se entra en `http://box.lan`. No lo mezcles con este proyecto en la misma Pi: usa uno u otro.

[⬅ Hardware](01-hardware.md) · [Siguiente: Contenido offline ➡](03-contenido.md)
