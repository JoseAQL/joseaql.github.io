# 7. Más ideas para tu red de casa

[⬅ Volver al índice](../README.md)

Servicios que puedes ir añadiendo. Casi todos se instalan con Docker, igual que Kavita y RomM. Para cada uno, añade una tarjeta en `/var/www/html/index.html` con su puerto.

## 🌐 Servicios web para todos

| App | Para qué | Peso en la Pi |
|---|---|---|
| **File Browser** | Subir, bajar y compartir archivos | Muy ligero |
| **Calibre-Web** | Biblioteca de libros y PDFs para el celular | Ligero |
| **Navidrome** | Tu propio "Spotify" con tu música | Ligero |
| **Jellyfin** | Tu propio "Netflix" | Medio |
| **Audiobookshelf** | Audiolibros y podcasts | Ligero |
| **CyberChef** | Conversiones: base64, hex, binario, hashes… | Muy ligero (una página) |
| **Excalidraw** | Pizarra para diagramas, entre varios | Muy ligero |
| **HedgeDoc** / **Etherpad** | Notas compartidas en tiempo real | Ligero |
| **Mumble** | Walkie-talkie por WiFi: voz entre los conectados | Muy ligero |
| **Stirling-PDF** | Unir, cortar, comprimir y convertir PDFs | Medio |
| **Mealie** | Recetario | Ligero |
| **Kolibri** | Cursos educativos offline | Medio |

## 🏠 Para la casa

| App | Para qué |
|---|---|
| **Home Assistant** | Domótica: focos, sensores, enchufes (ideal con ESP32) |
| **Pi-hole** | Bloquear anuncios en toda la red (cuando hay internet) |
| **Syncthing** | Sincronizar carpetas entre PC, celular y Pi sin nube |
| **Immich** | Respaldo automático de fotos del celular (pesado; mejor con 8 GB) |
| **Grocy** | Inventario de despensa y lista del súper |
| **Uptime Kuma** | Avisa si algún servicio se cae |
| **Homepage** / **Homarr** | Panel bonito con todos los servicios |
| **Servidor de Minecraft** | 2–5 jugadores con la Pi 4 |

## 📚 Contenido Kiwix curioso
- **iFixit**: guías de reparación paso a paso
- **WikiMed**: medicina y primeros auxilios
- **Wikiviajes**, **Wikilibros**
- **Proyecto Gutenberg**: libros clásicos
- **TED Talks**
- **StackExchange**: electrónica, cocina, bricolaje (DIY)

## 📡 Proyectos con radio
- **Sensores con nRF24 + Arduino/ESP32** que envían datos a la Pi y se muestran en la página (por ejemplo con Node-RED)
- **Red Meshtastic (LoRa)** para mensajes de texto a varios km sin señal celular
- **Enlace punto a punto** para llevar NOMAD a otra casa

Más detalles en la [guía de hardware](01-hardware.md).

## 🥇 Orden recomendado
1. Servidor base + Wikipedia + WikiMed + iFixit
2. File Browser + Kavita + RomM
3. Menú de apps de electrónica
4. Mumble (voz sin señal)
5. Respaldo en disco exFAT (¡no lo dejes para después!)
6. Lo demás según lo que uses

[⬅ Respaldo y migración](06-respaldo.md) · [Volver al índice](../README.md)
