# 4. Menú de texto y apps de electrónica

[⬅ Volver al índice](../README.md)

## La idea

La Pi **no tiene escritorio** (no gasta recursos en gráficos). Tú te conectas desde tu PC por SSH y:

1. Aparece un **menú de texto** con todas las apps por categoría.
2. Eliges una, por ejemplo **KiCad**.
3. **La ventana de KiCad se abre en tu PC**, aunque el programa corre en la Pi.

Esto se llama **X11 forwarding** (`ssh -X`).

```
┌──────────── Servidor NOMAD ────────────┐
│ Bienvenido, jose.  Gráficos: ACTIVADOS │
│   PCB            4 apps                │
│   Simulacion     3 apps                │
│   Programacion   5 apps                │
│   FPGA           2 apps                │
│   Instrumentos   3 apps                │
│   Mecanica       3 apps                │
│   Calculo        3 apps                │
│   Oficina        2 apps                │
│   Sistema        4 apps                │
│   Terminal       Salir a la línea...   │
│   Salir          Cerrar la sesión      │
└────────────────────────────────────────┘
```

---

## Instalación (en la Pi, con internet)

```bash
cd ~/Pruebas-/nomad-pi
sudo bash menu/instalar-menu.sh
```

El script:
1. Instala `xauth` (**obligatorio** para `ssh -X` en la versión Lite), `whiptail` y herramientas de texto.
2. Activa `X11Forwarding yes` en SSH.
3. Instala ~30 apps **una por una**: si alguna no existe para la Pi, la salta y al final te dice cuáles fallaron.
4. Copia el menú a `/usr/local/bin/nomad-menu` (también se abre escribiendo `menu`) y la lista a `/etc/nomad/apps.conf`.
5. Hace que el menú se abra solo al entrar por SSH.

Tarda bastante (KiCad y FreeCAD son grandes).

## Conectarte desde tu PC

| Tu PC | Qué necesitas | Cómo entrar |
|---|---|---|
| **Windows** | **MobaXterm** (gratis, trae servidor X) | Session → SSH → host `nomad.lan`, usuario, **X11-forwarding** activado |
| **Windows 11 + WSL** | Nada extra (WSLg) | En WSL: `ssh -X usuario@nomad.lan` |
| **Linux** | Nada extra | `ssh -X usuario@nomad.lan` |
| **Mac** | **XQuartz** | `ssh -X usuario@nomad.lan` |

Si entras **sin** `-X`, el menú funciona igual, pero las apps de ventana te avisarán de que necesitan gráficos.

## Usar el menú

- Flechas y Enter para elegir; Esc para volver.
- **[ventana]**: la app se abre en tu PC y el menú sigue disponible para abrir más.
- **[texto]**: la app corre dentro de la terminal; al salir vuelves al menú.
- **Terminal**: sales a la línea de comandos. Escribe `menu` para volver.

## Añadir o quitar apps

```bash
sudo nano /etc/nomad/apps.conf
```
Formato: `categoría|nombre|comando|tipo|descripción`
```
PCB|KiCad|kicad|gui|Esquemáticos, PCB y Gerbers
Calculo|Calculadora|qalc|tui|Calculadora con unidades
```
`gui` = ventana, `tui` = texto. Las categorías nuevas aparecen solas.

---

## ⚠️ Rendimiento y consejos para KiCad

- Con **4 GB** de RAM, 1–2 personas a la vez usando apps pesadas; con 8 GB, unas 3.
- Usa conexión **por cable o WiFi 5 GHz**; por WiFi lento las ventanas se arrastran.
- Si el editor de PCB se ve **negro o muy lento**, cambia a **gráficos de respaldo** ("Fallback graphics", en **Ver** o en **Preferencias → Opciones de pantalla**, según la versión).
- Evita el **visor 3D** por SSH.
- Alternativa más rápida: **Xpra** (comprime mejor y la app sigue abierta si se corta el WiFi):
  ```bash
  sudo apt install -y xpra
  xpra start :100 --start=kicad --bind-tcp=0.0.0.0:14500 --html=on
  ```
  Luego abre `http://nomad.lan:14500` en el navegador y verás KiCad ahí.
- Truco: guarda también en Archivos los **instaladores offline** de KiCad, Arduino, etc. para Windows/Mac/Linux, para que cada quien instale en su laptop y use la Pi para librerías, proyectos y datasheets.

---

## 📋 Lista de apps de electrónica (30)

🖥️ = ventana (ssh -X) · ⌨️ = texto/comandos · 🌐 = en el navegador

### Diseño de PCB y esquemáticos
1. 🖥️ **KiCad**: esquemáticos, PCB, Gerbers, 3D
2. 🖥️ **Fritzing**: protoboard visual, ideal para enseñar
3. 🖥️ **Gerbv**: visor de Gerbers
4. 🖥️ **Xschem**: esquemáticos para simulación y circuitos integrados

### Simulación
5. ⌨️ **ngspice**: simulador SPICE (KiCad lo usa por dentro)
6. 🖥️ **Qucs-S**: simulador gráfico, parecido a LTspice
7. 🌐 **CircuitJS (Falstad)**: simulador animado en el navegador (descárgalo como página y cópialo a `/var/www/html/circuitjs/`)
8. 🖥️ **Logisim-evolution**: circuitos digitales (no viene en apt: es un `.jar` de Java)
9. 🖥️ **Digital**: alternativa a Logisim que exporta a Verilog/VHDL (`.jar`)

### Programación de microcontroladores
10. 🌐 **code-server**: VS Code en el navegador, para varias personas
11. 🌐 **PlatformIO** (dentro de code-server): ESP32, STM32, AVR, RP2040
12. 🖥️ **Arduino IDE**
13. 🖥️ **Thonny**: MicroPython / Raspberry Pi Pico
14. ⌨️ **arduino-cli**
15. ⌨️ **gcc-arm-none-eabi** + **OpenOCD**: compilar y depurar ARM/STM32
16. ⌨️ **avrdude**, **esptool**, **dfu-util**: grabar firmware

### FPGA y diseño digital
17. ⌨️ **Yosys**: síntesis Verilog
18. ⌨️ **nextpnr** + **IceStorm**: FPGAs Lattice iCE40
19. ⌨️ **Icarus Verilog**: simulador Verilog
20. ⌨️ **Verilator**: simulador Verilog rápido
21. 🖥️ **GTKWave**: formas de onda
22. 🖥️ **Magic VLSI**: layout de chips

### Instrumentos
23. 🖥️ **PulseView (sigrok)**: analizador lógico (los USB baratos de 8 canales)
24. 🖥️ **CuteCom** / ⌨️ **Minicom**: puerto serie

### Mecánica
25. 🖥️ **FreeCAD**: CAD 3D (pesado)
26. 🖥️ **OpenSCAD**: CAD 3D por código
27. 🖥️ **PrusaSlicer**: impresión 3D

### Cálculo y automatización
28. 🌐 **JupyterLab**: Python en el navegador
29. 🖥️ **GNU Octave**: alternativa a MATLAB
30. 🌐 **Node-RED**: automatización e IoT con bloques

### Instalar las apps web (opcional)
```bash
# VS Code en el navegador
curl -fsSL https://code-server.dev/install.sh | sh

# JupyterLab
sudo apt install -y python3-pip python3-venv
python3 -m venv ~/jupyter && ~/jupyter/bin/pip install jupyterlab

# Node-RED (script oficial)
bash <(curl -sL https://github.com/node-red/linux-installers/releases/latest/download/update-nodejs-and-nodered-deb)
```

---

## ⌨️ Apps de uso diario y curiosas (para el menú)

Instálalas con `sudo apt install -y <nombre>` y añádelas a `apps.conf`.

**Útiles**
- `calcurse`: agenda y calendario
- `taskwarrior`: lista de tareas (comando `task`)
- `ranger`: explorador de archivos con vista previa
- `btop`: monitor del sistema bonito
- `units`: conversor (`units "5 V / 220 ohm" mA`)
- `espeak-ng`: la Pi habla (`espeak-ng -v es "Hola"`)
- `qrencode`: QR en la terminal. **QR para conectarse al WiFi:**
  ```bash
  qrencode -t ansiutf8 "WIFI:T:WPA;S:NOMAD;P:nomad12345;;"
  ```

**Divertidas** 😄
- `cmatrix`: lluvia de Matrix
- `sl`: un tren cuando escribes mal `ls`
- `fortune-mod` + `fortunes-es` + `cowsay`: frases en español con una vaca
- `figlet` / `toilet`: letras gigantes
- Juegos: `bastet` (Tetris), `nsnake`, `ninvaders`, `moon-buggy`, `gnuchess`, `bsdgames`

**Con ventana (ssh -X)**
- `stellarium`: planetario
- `gcompris-qt`: 100+ juegos educativos para niños
- `tuxpaint`: dibujo para niños
- `gimp`, `audacity`, `supertux`

[⬅ Contenido offline](03-contenido.md) · [Siguiente: Mangas, juegos y películas ➡](05-mangas-y-juegos.md)
