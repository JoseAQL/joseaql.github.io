# 1. Hardware y compras

[⬅ Volver al índice](../README.md)

## Lo básico

| Pieza | Recomendación | Notas |
|---|---|---|
| **Raspberry Pi 4B** | **4 GB** (bien) u **8 GB** (sobrado) | La RAM no se puede ampliar después. 2 GB alcanza solo para página + Wikipedia. |
| **Almacenamiento** | **SSD por USB 3.0** de 128–512 GB | Más rápido y duradero que la microSD. La Pi 4B puede arrancar desde el SSD. |
| **Fuente** | Oficial **5V / 3A USB-C** | Las fuentes malas causan reinicios y fallos raros. |
| **Disipador / ventilador** | Caja con ventilador o disipadores | Con muchos usuarios o conversiones de video se calienta. |
| **Cable de red** | Uno cualquiera | Muy útil durante la instalación. |

### RAM según uso

| Uso | RAM |
|---|---|
| Página + Wikipedia | 2 GB |
| + cursos, archivos, películas, mangas, juegos | 4 GB |
| + IA local (Ollama) | 8 GB (y aun así lenta). No se incluye en este proyecto. |

Comprobar en la Pi:
```bash
free -h   # RAM
df -h     # disco
```

---

## 📶 Hotspot: dar WiFi a más gente

El WiFi interno de la Pi alcanza **~10–20 m y pocas personas**. Para más:

### Opción A: Adaptador WiFi USB con antena (recomendado)
Lo importante es el **chip**, que debe soportar **modo AP** en Linux sin drivers raros:

| Modelo | Chip | Banda | Nota |
|---|---|---|---|
| **ALFA AWUS036ACM** | MediaTek MT7612U | 2.4 + 5 GHz | Muy recomendado |
| **ALFA AWUS036ACHM** | MediaTek MT7610U | 2.4 + 5 GHz | Buen alcance |
| **ALFA AWUS036AXML** | MediaTek MT7921AU | WiFi 6 | Más nuevo |
| Genéricos **RT5370** | Ralink | Solo 2.4 GHz | Baratos, para pruebas |

⚠️ Evita chips **Realtek** (RTL8812AU, RTL88x2BU…): suelen necesitar drivers aparte.

Comprobar que soporta hotspot (debe aparecer **AP**):
```bash
ip link                                   # el adaptador aparece como wlan1
iw list | grep -A 10 "Supported interface modes"
```
Luego instala con `sudo bash instalar.sh wlan1`.
Truco: `wlan0` (interno) puede seguir conectado a internet mientras `wlan1` da la red NOMAD.

### Opción B: Router de viaje (GL.iNet Mango / Beryl / Slate)
Conectado a la Pi **por cable**: él hace el WiFi y la Pi sirve las páginas. Más estable y aguanta más usuarios.

### Opción C: Módulo 4G/LTE (SIM7600, Quectel EC25, módem USB Huawei)
Solo si quieres que la red tenga **internet** cuando haya señal celular.

### ESP32 / ESP8266
Pueden hacer hotspot, pero aguantan pocas personas (unas 4–10) y son lentos. No sirven para este servidor.

---

## 📡 Antenas y radios: qué sirve para qué

### nRF24L01: NO sirve para dar red a celulares
- Usa 2.4 GHz pero **no es WiFi**: los celulares no lo ven.
- Muy lento (2 Mbps, paquetes de 32 bytes).
- **Sí sirve** para comunicar tus aparatos: sensores con Arduino/ESP32 que mandan datos a la Pi, o mensajes cortos con RF24Network/RF24Mesh. La versión **PA+LNA** alcanza cientos de metros.
- Conexión a la Pi por **SPI** (CE, CSN, SCK, MOSI, MISO). **Alimentar a 3.3V, nunca 5V**, con un capacitor de 10–100 µF entre VCC y GND.

### Enlace punto a punto (otra casa a varios km)
Par de antenas WiFi exteriores (TP-Link CPE210/510, Ubiquiti NanoStation/LiteBeam). Con línea de vista: **5–15 km**, con velocidad de sobra para compartir NOMAD.

### LoRa / Meshtastic: mensajes a muchos km ⭐
- Nodos baratos (Heltec, LilyGO T-Beam) que se conectan al **celular por Bluetooth** con la app Meshtastic.
- Mensajes de texto y GPS a **varios km**; los nodos repiten la señal entre ellos.
- Solo texto, no páginas web.

### Esquema completo
```
         [Pi NOMAD] ──cable── [Access Point exterior] ))) celulares y laptops
             │
             ├── nRF24 ))) sensores Arduino/ESP32
             ├── LoRa/Meshtastic ))) mensajes de texto a km
             │
      [Antena punto a punto] ))))))))) [otra casa / otro AP]
```

⚠️ Revisa la normativa de tu país sobre potencia y antenas (2.4 GHz; LoRa usa 915 MHz en América y 868 MHz en Europa).

---

## 🛒 Compra recomendada para empezar
- Raspberry Pi 4B de **4 GB**
- **SSD de 256 GB** + adaptador USB 3.0 (o lo que tengas, por ejemplo 125 GB)
- Fuente oficial 5V/3A
- Caja con ventilador
- (Opcional) **ALFA AWUS036ACM** para más alcance WiFi

[Siguiente: Instalación base ➡](02-instalacion-base.md)
