# 6. Respaldo y migración (sin internet)

[⬅ Volver al índice](../README.md)

Dos métodos complementarios. **Usa los dos.**

| Método | Sirve para | Velocidad para volver a funcionar |
|---|---|---|
| **1. Copia exacta del disco** | Pi → Pi idéntica | ⚡ Inmediata: conectas el disco y enciendes |
| **2. Carpeta NOMAD-PORTABLE** | Cualquier equipo: otra Pi, Windows, Linux, Mac | Leer: inmediato. Montar servidor: un script |

---

## ⚠️ Antes de nada: formato del disco

Formatea el disco o USB de respaldo en **exFAT**, no FAT32.
FAT32 no admite archivos de más de 4 GB, y la Wikipedia es un solo archivo de ~15 GB o más.
exFAT funciona en Windows, Linux, Mac y Raspberry.

---

## Método 1: Copia exacta del disco (Pi → Pi)

### Con rpi-clone (la Pi encendida)
rpi-clone es un script que copia el sistema en marcha a otro disco USB. Busca su repositorio en GitHub (hay versiones mantenidas por la comunidad), instálalo según sus instrucciones y ejecuta:
```bash
lsblk                     # identifica el disco destino, por ejemplo sdb
sudo rpi-clone sdb        # copia todo el sistema a sdb
```
⚠️ **Borra todo lo que haya en el disco destino.** Asegúrate de elegir el disco correcto.

### Con una imagen `.img`
Desde un PC con Linux, con el disco de la Pi conectado (y la Pi apagada):
```bash
sudo dd if=/dev/sdX of=nomad.img bs=4M status=progress   # cambia sdX
```
Esa imagen se graba en un disco nuevo con **Raspberry Pi Imager** → "Use custom". Herramientas como **PiShrink** reducen el tamaño de la imagen.

---

## Método 2: Carpeta NOMAD-PORTABLE

### Exportar
Conecta el disco a la Pi y busca su ruta con `lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT`.

```bash
cd ~/Pruebas-/nomad-pi
sudo bash respaldo/nomad-exportar.sh /media/tu_usuario/MIDISCO --paquetes
```
- `--paquetes` descarga y guarda **todos los programas** para reinstalarlos **sin internet**. Hazlo **con internet**, al menos una vez.
- Volver a ejecutarlo solo copia lo nuevo o cambiado, así que actualizar el respaldo es rápido.

### Qué se crea
```
NOMAD-PORTABLE/
├── LEEME.html              ← ábrelo en cualquier PC: instrucciones
├── contenido/              ← todo /srv/nomad (Wikipedia, mangas, juegos, archivos…)
├── servidor/
│   ├── nomad-pi/           ← este proyecto completo (scripts + tutorial)
│   ├── pagina-web/         ← tu página personalizada
│   ├── config/             ← tu lista de apps del menú
│   ├── docker/             ← configuración de Kavita y RomM
│   ├── restaurar.sh        ← restaura todo en una Pi nueva
│   ├── paquetes-instalados.txt
│   └── sistema.txt         ← versión del sistema (para instalar la misma)
└── programas/
    ├── raspberry/paquetes/ ← programas .deb para instalar sin internet
    ├── windows/            ← pon aquí instaladores de Windows
    └── linux/              ← y de Linux
```

### Restaurar en una Raspberry nueva
1. Instala **Raspberry Pi OS 64-bit, misma versión** que dice `servidor/sistema.txt`.
2. Conecta el disco y ejecuta:
   ```bash
   sudo bash /media/tu_usuario/MIDISCO/NOMAD-PORTABLE/servidor/restaurar.sh wlan0
   ```
3. Kavita y RomM: sus datos se restauran, pero las apps de Docker necesitan **internet una vez** para volver a descargarse:
   ```bash
   sudo bash /media/.../NOMAD-PORTABLE/servidor/nomad-pi/mangas-juegos/instalar-kavita-romm.sh
   ```
   Si nunca vas a tener internet, usa el **Método 1** (copia exacta), que sí incluye todo.

### Usar el contenido en Windows / Linux / Mac
- **Solo leer**: abre los `.zim` con **Kiwix Desktop**; libros, música y videos se abren normalmente.
- **Windows como servidor**: usa `kiwix-serve.exe` con los `.zim` y activa *Configuración → Red → Zona con cobertura inalámbrica móvil* para que otros se conecten.
- **Linux como servidor**: `sudo apt install kiwix-tools` y `kiwix-serve --port 8080 contenido/zim/*.zim`.

---

## 📥 Descárgalo AHORA, mientras tienes internet

Guarda en `programas/windows/` y `programas/linux/`:
- **Kiwix Desktop** (Windows y Linux) y **kiwix-serve.exe**
- **KiCad** (instalador de Windows y AppImage/Flatpak de Linux)
- **Arduino IDE**
- **Raspberry Pi Imager**
- **MobaXterm** (portable)
- **VLC**
- La **imagen de Raspberry Pi OS Lite 64-bit** (`.img.xz`)
- Este repositorio: GitHub → **Code → Download ZIP**

Sin internet no podrás conseguirlos después.

[⬅ Mangas y juegos](05-mangas-y-juegos.md) · [Siguiente: Más ideas ➡](07-ideas.md)
