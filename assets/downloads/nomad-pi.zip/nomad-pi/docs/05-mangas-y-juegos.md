# 5. Mangas, juegos retro y películas

[⬅ Volver al índice](../README.md)

## Instalación de Kavita y RomM

| App | Para qué | Dirección |
|---|---|---|
| 📖 **Kavita** | Mangas y cómics (`.cbz`, `.cbr`, `.zip`, PDF, EPUB) en el navegador; recuerda dónde te quedaste | http://nomad.lan:5000 |
| 🎮 **RomM** | Biblioteca de juegos retro con botón **▶ Jugar** en el navegador (NES, SNES, GBA, PS1…) | http://nomad.lan:8085 |

Requisitos: **Raspberry Pi OS 64-bit** e **internet solo durante la instalación**.

```bash
cd ~/Pruebas-/nomad-pi
sudo bash mangas-juegos/instalar-kavita-romm.sh
```

El script:
1. Instala **Docker** si no está (las apps corren aisladas del resto del sistema).
2. Crea `/srv/nomad/mangas` y `/srv/nomad/juegos/roms/<consola>`.
3. Genera contraseñas internas seguras en `/opt/nomad-docker/.env`.
4. Arranca Kavita, RomM y su base de datos; se inician solos al encender la Pi.
5. Añade las tarjetas 📖 Mangas y 🎮 Juegos retro a la página NOMAD.

La primera vez tarda **10–20 minutos** (descarga las apps). Cada app te pide crear un **usuario administrador** la primera vez que la abres.

Comandos útiles:
```bash
cd /opt/nomad-docker
sudo docker compose ps          # ver si están corriendo
sudo docker compose logs romm   # ver errores de RomM
sudo docker compose restart     # reiniciar
sudo docker compose pull && sudo docker compose up -d   # actualizar (con internet)
```

Usan ~1–1.5 GB de RAM entre las dos.

---

## 📖 Mangas con Kavita

1. Copia tus mangas, **una carpeta por serie**:
   ```
   /srv/nomad/mangas/
   ├── One Piece/
   │   ├── One Piece v01.cbz
   │   └── One Piece v02.cbz
   └── Dragon Ball/
   ```
2. En Kavita: **Ajustes → Bibliotecas → Añadir**, tipo **Manga**, carpeta **`/mangas`**.
3. Lee desde el celular o la PC.

Notas:
- **Tachiyomi** cerró en 2024; su sucesor es **Mihon** (app de Android).
- Alternativa: **Komga**, que se puede conectar con Mihon para leer tu biblioteca desde la app.

---

## 🎮 Juegos retro con RomM

### Estructura de carpetas
```
/srv/nomad/juegos/
├── roms/
│   ├── nes/   snes/   gb/   gbc/   gba/
│   ├── n64/   psx/    megadrive/   mastersystem/   arcade/
└── bios/
    ├── psx/   (scph1001.bin, etc.)
    └── gba/   (gba_bios.bin)
```
RomM reconoce los nombres de carpeta de Batocera, RetroBat y ES-DE, que son casi los mismos que usa el R36S.

### Jugar
1. Copia los juegos a su carpeta y en RomM pulsa **Scan**.
2. Entra a un juego y pulsa **▶ Jugar**. En el celular aparecen controles táctiles; en la PC puedes usar teclado o un control USB.

### ¿Necesita internet?
- **Jugar: NO.** El emulador (EmulatorJS) viene incluido dentro de RomM.
- **Portadas e información: SÍ.** Sin internet los juegos aparecen sin portada. Si haces un Scan un día con internet, se descargan y quedan guardadas.

### Rendimiento en el navegador
NES, SNES, GBA y Genesis van fluidos. PS1 va bien en PC y puede ir lento en celulares viejos. N64 es irregular.

---

## 🕹️ Pasar los juegos del R36S (aunque tenga la pantalla rota)

Los juegos están en la **microSD**, no en la consola.

1. Apaga el R36S y saca la **microSD**. Algunos modelos tienen **dos ranuras** (TF1 y TF2): revisa ambas.
2. Conéctala a la Pi con un lector USB.
3. Busca la partición **EASYROMS**:
   ```bash
   lsblk -o NAME,SIZE,LABEL,MOUNTPOINT
   ```
   Si no tiene ruta (MOUNTPOINT vacío), móntala:
   ```bash
   sudo mount /dev/sda3 /mnt      # cambia sda3 por la partición EASYROMS
   ```
4. Importa:
   ```bash
   sudo bash mangas-juegos/importar-r36s.sh /mnt
   ```
   El script:
   - Copia cada carpeta de consola (gba, snes, psx…) a `roms/`
   - Pone las **partidas guardadas** (`.srm`, `.sav`, `.state`) en `/srv/nomad/juegos/partidas-r36s/`
   - Coloca los BIOS de PS1 y GBA en su carpeta, y guarda copia de todos en `bios/r36s-original/`
   - **No borra ni modifica nada** de la microSD
5. En RomM pulsa **Scan**.
6. Para seguir tus partidas: entra al juego en RomM y sube su `.srm` desde `partidas-r36s/`.
7. Desmonta la tarjeta: `sudo umount /mnt`.

En Windows también puedes ver la unidad **EASYROMS** y copiar las carpetas a mano. Si Windows te pide **formatear** alguna otra partición, **dile que NO**: son particiones de Linux.

Una pantalla de repuesto para el R36S suele ser barata; búscala por el modelo exacto.

---

## 📺 Jugar en la tele: Batocera / RetroPie

- Usa una **microSD aparte con Batocera** (batocera.org): conectas la Pi por HDMI, pones un control USB o Bluetooth y tienes una consola. Para volver al servidor, cambias la tarjeta.
- Pi 4: NES, SNES, GBA, Genesis, arcade y PS1 perfectos; N64, PSP y Dreamcast con varios juegos. Todo lo del R36S corre en la Pi.

---

## 🎬 Convertir películas a MP4

| Herramienta | Para qué |
|---|---|
| **HandBrake** (`handbrake` / `handbrake-cli`) | Convertir DVDs y videos a MP4 (tiene ventana para el menú `ssh -X`) |
| **MakeMKV** | Sacar la película de DVD/Blu-ray a `.mkv` |
| **ffmpeg** | Convertir cualquier video con un comando |
| **Tdarr** | Convierte automáticamente lo que metas en una carpeta |

```bash
sudo apt install -y ffmpeg
ffmpeg -i pelicula.avi -c:v libx264 -crf 22 -c:a aac pelicula.mp4
```

- La Pi 4 convierte **lento**: un DVD tarda aproximadamente lo que dura la película o más, y un Blu-ray 1080p varias horas. Déjalo de noche.
- El lector DVD USB necesita **alimentación propia** o un hub USB con corriente.
- **Jellyfin** (puerto 8096) reproduce casi cualquier formato, así que no siempre hace falta convertir.

---

## ⚖️ Nota legal
Haz copias de **discos y juegos que tengas**. Saltarse la protección anticopia puede no estar permitido según el país.

[⬅ Menú y apps](04-menu-y-apps.md) · [Siguiente: Respaldo y migración ➡](06-respaldo.md)
