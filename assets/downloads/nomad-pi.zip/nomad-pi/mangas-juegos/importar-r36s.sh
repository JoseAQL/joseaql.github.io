#!/bin/bash
# Copia los juegos de la microSD del R36S (partición EASYROMS) al servidor NOMAD para RomM.
# Uso:  sudo bash importar-r36s.sh /media/tu_usuario/EASYROMS
#
# - Las carpetas de consola (gba, snes, psx...) van a /srv/nomad/juegos/roms/
# - Las partidas guardadas (.srm .sav .state) van aparte, para subirlas después en RomM
# - Los BIOS más comunes se colocan en la carpeta de su consola
# No borra ni modifica nada de la microSD.

ORIGEN="$1"
JUEGOS=/srv/nomad/juegos

if [ -z "$ORIGEN" ] || [ ! -d "$ORIGEN" ]; then
  echo "Uso: sudo bash importar-r36s.sh /ruta/a/EASYROMS"
  echo "Discos conectados:"; lsblk -o NAME,SIZE,LABEL,MOUNTPOINT | grep -v loop
  exit 1
fi
command -v rsync >/dev/null || apt install -y rsync

# Carpetas de la SD que no son consolas
NO_CONSOLAS="bios themes tools backup backups videos screenshots savestates saves ports_scripts"

mkdir -p "$JUEGOS"/{roms,bios,partidas-r36s}
for dir in "$ORIGEN"/*/; do
  c=$(basename "$dir")
  case " $NO_CONSOLAS " in *" $c "*) continue ;; esac
  n=$(find "$dir" -type f ! -name '*.srm' ! -name '*.sav' ! -name '*.state*' | wc -l)
  [ "$n" -eq 0 ] && continue
  echo "🎮 $c: $n archivos"
  rsync -rt --ignore-existing --exclude='*.srm' --exclude='*.sav' --exclude='*.state*' \
        "$dir" "$JUEGOS/roms/$c/"
  rsync -rt --ignore-existing --include='*/' --include='*.srm' --include='*.sav' --include='*.state*' \
        --exclude='*' --prune-empty-dirs "$dir" "$JUEGOS/partidas-r36s/$c/"
done

if [ -d "$ORIGEN/bios" ]; then
  echo "🧩 Copiando BIOS..."
  rsync -rt --ignore-existing "$ORIGEN/bios/" "$JUEGOS/bios/r36s-original/"
  mkdir -p "$JUEGOS/bios/psx" "$JUEGOS/bios/gba"
  find "$ORIGEN/bios" -maxdepth 1 -iname 'scph*.bin' -exec rsync -t --ignore-existing {} "$JUEGOS/bios/psx/" \;
  find "$ORIGEN/bios" -maxdepth 1 -iname 'gba_bios.bin' -exec rsync -t --ignore-existing {} "$JUEGOS/bios/gba/" \;
fi

[ -n "$SUDO_USER" ] && chown -R "$SUDO_USER": "$JUEGOS"
echo ""
echo "✅ Listo. Ahora abre RomM y pulsa 'Scan' para que aparezcan los juegos."
echo "   Tus partidas guardadas están en: $JUEGOS/partidas-r36s/"
