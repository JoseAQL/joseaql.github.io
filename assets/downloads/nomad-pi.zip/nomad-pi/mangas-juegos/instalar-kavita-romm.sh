#!/bin/bash
# Instala Kavita (mangas y cómics) y RomM (juegos retro en el navegador) en el servidor NOMAD.
# Necesita internet SOLO durante la instalación. Después funciona sin internet.
# Uso:  sudo bash instalar-kavita-romm.sh
set -e

BASE=/opt/nomad-docker          # configuración de las apps
MANGAS=/srv/nomad/mangas        # aquí van tus mangas (.cbz .cbr .zip .pdf .epub)
JUEGOS=/srv/nomad/juegos        # aquí van roms/<consola>/ y bios/<consola>/
PUERTO_KAVITA=5000
PUERTO_ROMM=8085

if [ "$EUID" -ne 0 ]; then echo "Ejecuta con sudo: sudo bash instalar-kavita-romm.sh"; exit 1; fi
if [ "$(uname -m)" != "aarch64" ]; then
  echo "⚠️  Necesitas Raspberry Pi OS de 64 bits (aarch64). Tienes: $(uname -m)"; exit 1
fi

echo "==> 1/5 Instalando Docker (si no está)..."
if ! command -v docker >/dev/null; then
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker
[ -n "$SUDO_USER" ] && usermod -aG docker "$SUDO_USER"

echo "==> 2/5 Creando carpetas..."
mkdir -p "$BASE"/kavita "$BASE"/romm/{assets,config} "$MANGAS" "$JUEGOS"/{roms,bios}
for c in nes snes gb gbc gba n64 psx megadrive mastersystem arcade; do mkdir -p "$JUEGOS/roms/$c"; done
[ -n "$SUDO_USER" ] && chown -R "$SUDO_USER": "$MANGAS" "$JUEGOS"

echo "==> 3/5 Generando contraseñas internas (solo la primera vez)..."
if [ ! -f "$BASE/.env" ]; then
  cat > "$BASE/.env" <<EOF
DB_PASSWD=$(openssl rand -hex 16)
DB_ROOT_PASSWD=$(openssl rand -hex 16)
ROMM_AUTH_SECRET_KEY=$(openssl rand -hex 32)
EOF
  chmod 600 "$BASE/.env"
fi

echo "==> 4/5 Escribiendo docker-compose.yml..."
cat > "$BASE/docker-compose.yml" <<EOF
services:
  kavita:
    image: jvmilazz0/kavita:latest
    container_name: kavita
    restart: unless-stopped
    environment:
      - TZ=America/Mexico_City
    volumes:
      - $BASE/kavita:/kavita/config
      - $MANGAS:/mangas
    ports:
      - $PUERTO_KAVITA:5000

  romm:
    image: rommapp/romm:latest
    container_name: romm
    restart: unless-stopped
    environment:
      - DB_HOST=romm-db
      - DB_NAME=romm
      - DB_USER=romm-user
      - DB_PASSWD=\${DB_PASSWD}
      - ROMM_AUTH_SECRET_KEY=\${ROMM_AUTH_SECRET_KEY}
      - HASHEOUS_API_ENABLED=true
      - SCAN_WORKERS=1             # bajo para no saturar la Pi
      - WEB_SERVER_CONCURRENCY=2
    volumes:
      - romm_resources:/romm/resources
      - romm_redis_data:/redis-data
      - $JUEGOS:/romm/library
      - $BASE/romm/assets:/romm/assets
      - $BASE/romm/config:/romm/config
    ports:
      - $PUERTO_ROMM:8080
    depends_on:
      romm-db:
        condition: service_healthy
        restart: true

  romm-db:
    image: mariadb:latest
    container_name: romm-db
    restart: unless-stopped
    environment:
      - MARIADB_ROOT_PASSWORD=\${DB_ROOT_PASSWD}
      - MARIADB_DATABASE=romm
      - MARIADB_USER=romm-user
      - MARIADB_PASSWORD=\${DB_PASSWD}
    volumes:
      - mysql_data:/var/lib/mysql
    healthcheck:
      test: ["CMD", "healthcheck.sh", "--connect", "--innodb_initialized"]
      start_period: 30s
      start_interval: 10s
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  mysql_data:
  romm_resources:
  romm_redis_data:
EOF

echo "==> 5/5 Descargando y arrancando (la primera vez tarda varios minutos)..."
cd "$BASE"
docker compose pull
docker compose up -d

# Añade las tarjetas a la página NOMAD (si existe y aún no las tiene)
PAGINA=/var/www/html/index.html
if [ -f "$PAGINA" ] && ! grep -q "puerto: $PUERTO_KAVITA" "$PAGINA"; then
  sed -i "/const SERVICIOS = \[/a\\
    { icono: \"📖\", nombre: \"Mangas\", desc: \"Mangas y cómics para leer en el navegador (Kavita).\", puerto: $PUERTO_KAVITA },\\
    { icono: \"🎮\", nombre: \"Juegos retro\", desc: \"NES, SNES, GBA, PS1… juega en el navegador (RomM).\", puerto: $PUERTO_ROMM }," "$PAGINA"
fi

IP=$(hostname -I | awk '{print $1}')
echo ""
echo "✅ Listo. Abre en el navegador (espera 1–2 minutos a que arranquen):"
echo "   📖 Mangas (Kavita):  http://nomad.lan:$PUERTO_KAVITA   o  http://$IP:$PUERTO_KAVITA"
echo "   🎮 Juegos (RomM):    http://nomad.lan:$PUERTO_ROMM   o  http://$IP:$PUERTO_ROMM"
echo ""
echo "   La primera vez cada app te pide crear un usuario administrador."
echo "   Mangas  → copia tus carpetas a $MANGAS  y en Kavita añade la biblioteca '/mangas'"
echo "   Juegos  → copia tus ROMs a $JUEGOS/roms/<consola>/  y en RomM pulsa 'Scan'"
