# 🧭 NOMAD Pi: servidor offline en una Raspberry Pi 4B

Convierte una **Raspberry Pi 4B** en un servidor que **funciona sin internet**:
emite su propia red WiFi, y cualquiera que se conecte (celular, laptop, PC) puede usar:

- 📚 **Wikipedia, WikiMed, iFixit** y más, sin conexión (Kiwix)
- 📖 **Mangas y cómics** en el navegador (Kavita)
- 🎮 **Juegos retro** que se juegan en el navegador (RomM)
- 🛠️ **Apps de electrónica** (KiCad, Arduino, simuladores, FPGA…) desde tu PC, con un **menú de texto** por SSH
- 📁 Archivos, mapas, guías, música y películas
- 💾 **Respaldo portable** para pasar todo a otra Pi o PC sin internet

> **Estado:** los scripts están revisados y probados en simulación, pero **todavía no en una Raspberry real**.
> Si algún paso falla, anota el mensaje de error completo para poder corregirlo.

---

## 🚀 Inicio rápido

```bash
# 1. En la Raspberry (con Raspberry Pi OS 64-bit e internet por cable):
sudo apt update && sudo apt install -y git
git clone https://github.com/joseantonioquirozluna-crypto/Pruebas-.git
cd Pruebas-/nomad-pi

# 2. Servidor base: página web, Wikipedia offline, hotspot WiFi "NOMAD"
nano instalar.sh                      # cambia CLAVE="nomad12345" por tu clave
sudo bash instalar.sh wlan0           # o wlan1 si usas antena WiFi USB

# 3. Menú de texto y apps de electrónica (opcional)
sudo bash menu/instalar-menu.sh

# 4. Mangas y juegos retro (opcional)
sudo bash mangas-juegos/instalar-kavita-romm.sh
```

Después, conéctate a la red WiFi **NOMAD** y abre **http://nomad.lan**

---

## 📘 Tutorial completo (paso a paso)

| # | Guía | Qué aprendes |
|---|---|---|
| 1 | [Hardware y compras](docs/01-hardware.md) | Qué Raspberry, disco, antenas y módulos comprar |
| 2 | [Instalación base](docs/02-instalacion-base.md) | Sistema, hotspot WiFi, página web y nombre `nomad.lan` |
| 3 | [Contenido offline](docs/03-contenido.md) | Wikipedia, WikiMed, iFixit, mapas, libros; cuánto ocupa cada cosa |
| 4 | [Menú y apps de electrónica](docs/04-menu-y-apps.md) | Usar KiCad y más desde tu PC con `ssh -X`, y la lista de apps |
| 5 | [Mangas, juegos y películas](docs/05-mangas-y-juegos.md) | Kavita, RomM, sacar juegos del R36S, convertir videos |
| 6 | [Respaldo y migración](docs/06-respaldo.md) | Pasar todo a otra Pi o PC sin internet |
| 7 | [Más ideas](docs/07-ideas.md) | Servicios útiles y curiosos para tu red de casa |

---

## 📂 Qué hay en esta carpeta

```
nomad-pi/
├── README.md                     ← estás aquí
├── instalar.sh                   ← servidor base (Nginx, Kiwix, hotspot, nomad.lan)
├── web/index.html                ← página principal que ven todos
├── menu/
│   ├── instalar-menu.sh          ← instala el menú y ~30 apps de electrónica
│   ├── nomad-menu                ← el menú de texto que aparece al entrar por SSH
│   └── apps.conf                 ← lista de apps del menú (edítala a tu gusto)
├── mangas-juegos/
│   ├── instalar-kavita-romm.sh   ← Kavita (mangas) y RomM (juegos) con Docker
│   └── importar-r36s.sh          ← copia los juegos de la microSD del R36S
├── respaldo/
│   └── nomad-exportar.sh         ← exporta todo a un disco/USB (y crea restaurar.sh)
└── docs/                         ← el tutorial completo
```

## 🌐 Direcciones y puertos

| Servicio | Dirección |
|---|---|
| Página principal | http://nomad.lan (o http://10.42.0.1) |
| Wikipedia (Kiwix) | http://nomad.lan:8080 |
| Archivos (File Browser, opcional) | http://nomad.lan:8082 |
| Cursos (Kolibri, opcional) | http://nomad.lan:8083 |
| Mangas (Kavita) | http://nomad.lan:5000 |
| Juegos retro (RomM) | http://nomad.lan:8085 |
| Películas (Jellyfin, opcional) | http://nomad.lan:8096 |
| Menú de apps | `ssh -X usuario@nomad.lan` |

## 🆘 Problemas comunes

| Problema | Solución |
|---|---|
| Se cortó el SSH al instalar | Normal: el WiFi pasó a ser hotspot. Conéctate a la red **NOMAD** o usa cable de red. |
| `nomad.lan` no abre | Usa `http://10.42.0.1`. Algunos celulares ignoran nombres `.lan`. |
| Una tarjeta dice "apagado" | Ese servicio no está instalado o está arrancando. Revisa con `systemctl status kiwix` o `docker ps`. |
| Kiwix no arranca | Falta un archivo `.zim` en `/srv/nomad/zim/`. Ver [guía 3](docs/03-contenido.md). |
| Las apps del menú no abren ventana | Entra con `ssh -X` (en Windows, MobaXterm con X11 activado). Ver [guía 4](docs/04-menu-y-apps.md). |
| `apt` no encuentra un paquete | Ese programa no existe para la Pi con ese nombre. El instalador lo salta y te lo lista al final. |
| Disco lleno | `df -h` para ver el espacio, `ncdu /` para ver qué ocupa más. |
