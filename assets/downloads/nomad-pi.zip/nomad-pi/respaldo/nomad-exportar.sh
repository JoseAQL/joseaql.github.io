#!/bin/bash
# Exporta el servidor NOMAD a un disco duro o USB grande.
# El resultado se puede abrir en Windows, Linux, Mac o en una Raspberry nueva.
#
# Uso:
#   sudo bash nomad-exportar.sh /media/usuario/MIDISCO              (contenido y configuración)
#   sudo bash nomad-exportar.sh /media/usuario/MIDISCO --paquetes   (además guarda los programas
#                                                                    para reinstalar SIN internet;
#                                                                    necesita internet al exportar)
#
# IMPORTANTE: formatea el disco en exFAT. FAT32 no admite archivos de más de 4 GB
# y la Wikipedia ocupa mucho más.

set -e
DESTINO="$1"
OPCION="$2"

if [ "$EUID" -ne 0 ]; then echo "Ejecuta con sudo."; exit 1; fi
if [ -z "$DESTINO" ] || [ ! -d "$DESTINO" ]; then
  echo "Uso: sudo bash nomad-exportar.sh /ruta/del/disco [--paquetes]"
  echo "Discos conectados:"; lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT | grep -v loop
  exit 1
fi

P="$DESTINO/NOMAD-PORTABLE"
CARPETA="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$P"/{contenido,servidor,programas/{windows,linux,raspberry}}

copiar() {  # copiar ORIGEN DESTINO  (solo copia lo nuevo o cambiado)
  [ -e "$1" ] || return 0
  mkdir -p "$2"
  if command -v rsync >/dev/null; then
    rsync -rt --info=progress2 --modify-window=2 "$1"/ "$2"/
  else
    cp -r "$1"/. "$2"/
  fi
}

echo "==> 1/4 Contenido (Wikipedia, libros, mapas, archivos)..."
copiar /srv/nomad                "$P/contenido"
copiar /var/www/html             "$P/servidor/pagina-web"

echo "==> 2/4 Configuración y scripts..."
copiar /etc/nomad                "$P/servidor/config"
copiar "$CARPETA/.."              "$P/servidor/nomad-pi"   # todos los scripts y el tutorial
copiar /opt/nomad-docker         "$P/servidor/docker"     # Kavita y RomM (si están instalados)
cp /etc/systemd/system/kiwix.service "$P/servidor/" 2>/dev/null || true
dpkg-query -W -f='${Package}\n' > "$P/servidor/paquetes-instalados.txt"
grep '^ID\|^VERSION' /etc/os-release > "$P/servidor/sistema.txt"; uname -m >> "$P/servidor/sistema.txt"

if [ "$OPCION" = "--paquetes" ]; then
  echo "==> 3/4 Descargando los programas para reinstalar sin internet (tarda)..."
  D="$P/programas/raspberry/paquetes"; mkdir -p "$D"; cd "$D"
  APPS=$(grep -v '^#' "$P/servidor/config/apps.conf" 2>/dev/null | cut -d'|' -f3 | awk '{print $1}' | sort -u)
  EXTRA="nginx kiwix-tools xauth whiptail mc htop ncdu micro w3m qalc minicom rsync"
  LISTA=$(apt-cache depends --recurse --no-recommends --no-suggests --no-conflicts \
          --no-breaks --no-replaces --no-enhances $APPS $EXTRA 2>/dev/null | grep '^\w' | sort -u)
  for pk in $LISTA; do apt-get download "$pk" >/dev/null 2>&1 || true; done
  chown -R _apt "$D" 2>/dev/null || true
  echo "    $(ls "$D" | wc -l) paquetes guardados."
else
  echo "==> 3/4 (Programas no incluidos. Usa --paquetes para guardarlos.)"
fi

echo "==> 4/4 Creando instrucciones y script de restauración..."
cat > "$P/servidor/restaurar.sh" <<'EOF'
#!/bin/bash
# Restaura NOMAD en una Raspberry nueva (Raspberry Pi OS 64-bit, misma versión).
# Uso: sudo bash restaurar.sh
set -e
P="$(cd "$(dirname "$0")/.." && pwd)"
if ls "$P/programas/raspberry/paquetes/"*.deb >/dev/null 2>&1; then
  echo "Instalando programas desde el disco (sin internet)..."
  apt install -y "$P"/programas/raspberry/paquetes/*.deb || echo "Algunos paquetes fallaron."
fi
mkdir -p /srv/nomad /etc/nomad
cp -r "$P/contenido/." /srv/nomad/
cp -r "$P/servidor/config/." /etc/nomad/ 2>/dev/null || true
cd "$P/servidor/nomad-pi"
bash instalar.sh "${1:-wlan0}"
bash menu/instalar-menu.sh
cp -r "$P/servidor/config/." /etc/nomad/ 2>/dev/null || true   # tu lista de apps personalizada
cp -r "$P/servidor/pagina-web/." /var/www/html/ 2>/dev/null || true  # tu página personalizada
if [ -d "$P/servidor/docker" ]; then
  mkdir -p /opt/nomad-docker && cp -r "$P/servidor/docker/." /opt/nomad-docker/
  echo "Kavita y RomM: con internet ejecuta  sudo bash mangas-juegos/instalar-kavita-romm.sh"
fi
echo "✅ NOMAD restaurado."
EOF

TAM=$(du -sh "$P" | cut -f1)
cat > "$P/LEEME.html" <<EOF
<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>NOMAD Portable</title>
<style>body{font-family:system-ui,sans-serif;max-width:760px;margin:auto;padding:16px;line-height:1.55;background:#f4f1ea;color:#1f2421}
code{background:#e2efe7;padding:2px 6px;border-radius:4px}h2{margin-top:28px}</style></head><body>
<h1>📦 NOMAD Portable</h1>
<p>Exportado el $(date '+%d/%m/%Y %H:%M') · Tamaño: $TAM</p>

<h2>📚 Solo quiero LEER el contenido (cualquier PC)</h2>
<ul>
<li><b>Wikipedia, WikiMed, iFixit…</b> (archivos <code>.zim</code> en <code>contenido/zim</code>): ábrelos con <b>Kiwix</b>.
  Su instalador para Windows/Linux debería estar en <code>programas/</code>.</li>
<li><b>Libros, PDFs, música, videos</b>: están en <code>contenido/</code>, ábrelos normalmente.</li>
</ul>

<h2>🍓 Raspberry Pi nueva</h2>
<ol>
<li>Instala Raspberry Pi OS 64-bit (misma versión: mira <code>servidor/sistema.txt</code>).</li>
<li>Conecta este disco y ejecuta: <code>sudo bash servidor/restaurar.sh</code></li>
<li>El tutorial completo está en <code>servidor/nomad-pi/README.md</code>.</li>
</ol>

<h2>🐧 PC con Linux como servidor</h2>
<p>Instala <code>kiwix-tools</code> y ejecuta <code>kiwix-serve --port 8080 contenido/zim/*.zim</code>.
Abre <code>http://localhost:8080</code>.</p>

<h2>🪟 PC con Windows como servidor</h2>
<p>Usa <b>kiwix-serve.exe</b> (en <code>programas/windows</code>) con los <code>.zim</code>, y activa
<i>Configuración → Red → Zona con cobertura inalámbrica móvil</i> para que otros se conecten.</p>
</body></html>
EOF

sync
echo ""
echo "✅ Exportado en: $P  ($TAM)"
echo "   Abre LEEME.html en cualquier PC para ver las instrucciones."
