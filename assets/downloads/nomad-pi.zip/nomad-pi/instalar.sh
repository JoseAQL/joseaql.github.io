#!/bin/bash
# Instalador del servidor NOMAD para Raspberry Pi (Raspberry Pi OS Bookworm)
# Uso:  sudo bash instalar.sh [interfaz_wifi]
#   Ejemplo con el WiFi interno:      sudo bash instalar.sh wlan0
#   Ejemplo con adaptador USB (ALFA): sudo bash instalar.sh wlan1
set -e

IFACE="${1:-wlan0}"
SSID="NOMAD"
CLAVE="nomad12345"        # Cámbiala (mínimo 8 caracteres)
IP="10.42.0.1"
CARPETA="$(cd "$(dirname "$0")" && pwd)"

if [ "$EUID" -ne 0 ]; then
  echo "Ejecuta este script con sudo: sudo bash instalar.sh"
  exit 1
fi

echo "==> 1/5 Actualizando e instalando paquetes (nginx, kiwix)..."
apt update
apt install -y nginx kiwix-tools

echo "==> 2/5 Copiando la página web..."
if [ -f "$CARPETA/web/index.html" ]; then cp "$CARPETA/web/index.html" /var/www/html/index.html
else cp "$CARPETA/index.html" /var/www/html/index.html; fi
mkdir -p /var/www/html/mapas /var/www/html/guias
for d in mapas guias; do
  if [ ! -f /var/www/html/$d/index.html ]; then
    echo "<meta charset='utf-8'><h1>Sección $d</h1><p>Aún no hay contenido. Copia aquí tus archivos.</p><a href='/'>Volver</a>" \
      > /var/www/html/$d/index.html
  fi
done
systemctl enable --now nginx

echo "==> 3/5 Configurando Wikipedia offline (Kiwix en el puerto 8080)..."
mkdir -p /srv/nomad/zim
cat > /etc/systemd/system/kiwix.service <<'EOF'
[Unit]
Description=Kiwix (Wikipedia offline)
After=network.target

[Service]
ExecStart=/bin/sh -c 'exec /usr/bin/kiwix-serve --port 8080 /srv/nomad/zim/*.zim'
Restart=on-failure
RestartSec=30

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable kiwix
if ls /srv/nomad/zim/*.zim >/dev/null 2>&1; then
  systemctl restart kiwix
else
  echo "    (Aún no hay archivos .zim en /srv/nomad/zim. Kiwix arrancará cuando los copies.)"
fi

echo "==> 4/5 Nombre fácil: http://nomad.lan"
mkdir -p /etc/NetworkManager/dnsmasq-shared.d
echo "address=/nomad.lan/$IP" > /etc/NetworkManager/dnsmasq-shared.d/nomad.conf

echo "==> 5/5 Creando el hotspot '$SSID' en $IFACE..."
echo "    OJO: si estás conectado por SSH a través de $IFACE, se cortará la conexión."
if nmcli -t -f NAME connection show | grep -qx "Hotspot"; then
  echo "    El hotspot ya existía, solo lo reactivo."
  nmcli connection up Hotspot || true
else
  nmcli device wifi hotspot ssid "$SSID" password "$CLAVE" ifname "$IFACE"
fi
nmcli connection modify Hotspot connection.autoconnect yes ipv4.addresses "$IP/24"
systemctl restart NetworkManager

echo ""
echo "✅ ¡Listo!"
echo "   Red WiFi:   $SSID   (clave: $CLAVE)"
echo "   Página:     http://nomad.lan   o   http://$IP"
