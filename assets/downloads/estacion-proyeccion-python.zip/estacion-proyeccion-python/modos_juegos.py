# -*- coding: utf-8 -*-
"""
modos_juegos.py - Juegos proyectados sobre la mesa.

  PianoTiles  bajan fichas por carriles; toca el carril cuando la ficha llega a la ZONA de abajo.
              Si hay musica, las fichas salen con los bombos; si no, a ritmo fijo que va subiendo.
  PianoLibre  teclas proyectadas; al tocarlas suenan y salen notas de colores.
"""
import random

import cv2
import numpy as np

import modos_base as B

MELODIA = ["E5", "D5", "C5", "D5", "E5", "E5", "E5", "D5", "D5", "D5", "E5", "G5", "G5",
           "E5", "D5", "C5", "D5", "E5", "E5", "E5", "E5", "D5", "D5", "E5", "D5", "C5"]
COLORES_CARRIL = [(255, 80, 255), (255, 220, 0), (80, 255, 120), (0, 170, 255)]


class PianoTiles(B.Modo):
    nombre = "Piano Tiles"
    descripcion = "Toca cuando la ficha llegue"
    CARRILES = 4

    def entrar(self):
        self.reiniciar()

    def reiniciar(self):
        w, h = self.w, self.h
        self.margen = 30
        self.ancho = (w - 2 * self.margen) / float(self.CARRILES)
        self.zona = (h - 150, h - 40)               # donde se toca
        self.fichas = []                            # [carril, y, alto, estado]  estado: 0 viene, 1 tocada, 2 fallada
        self.puntos, self.racha, self.vidas = 0, 0, 3
        self.vel = 95.0
        self.t_ultima, self.intervalo = 0.0, 1.1
        self.i_nota = 0
        self.flash = [0.0] * self.CARRILES
        self.chispas = []                           # [x, y, vx, vy, vida, color]
        self.fin = False
        self.t_inicio = None
        self.toques = B.Toques(0.15)

    def rect_carril(self, i):
        x0 = int(self.margen + i * self.ancho)
        return x0, int(x0 + self.ancho)

    def _chispas(self, x, y, col):
        for _ in range(18):
            a = random.random() * 6.283
            v = 60 + random.random() * 180
            self.chispas.append([x, y, np.cos(a) * v, np.sin(a) * v - 80, 0.8, col])

    def actualizar(self, ctx):
        w, h = self.w, self.h
        img = np.zeros((h, w, 3), np.uint8)
        t, dt = ctx.t, ctx.dt
        if self.t_inicio is None:
            self.t_inicio = t
        zy0, zy1 = self.zona
        rects = {i: (self.rect_carril(i)[0], zy0 - 30, self.rect_carril(i)[1], zy1 + 20) for i in range(self.CARRILES)}
        tocadas, ocupadas = self.toques.revisar(ctx.puntas, rects, t)

        if self.fin:
            B.texto(img, "FIN DEL JUEGO", w / 2, 170, 1.3, B.ROJO, True, 3)
            B.texto(img, "Puntos: %d" % self.puntos, w / 2, 230, 1.0, B.BLANCO, True)
            bx0, by0, bx1, by1 = w // 2 - 110, 280, w // 2 + 110, 350
            cv2.rectangle(img, (bx0, by0), (bx1, by1), B.VERDE, 3)
            B.texto(img, "OTRA VEZ", w / 2, 325, 0.9, B.VERDE, True)
            if any(bx0 <= x <= bx1 and by0 <= y <= by1 for x, y in ctx.puntas):
                self.t_otra = getattr(self, "t_otra", t)
                p = min(1.0, (t - self.t_otra) / 1.0)
                cv2.rectangle(img, (bx0, by1 + 6), (int(bx0 + (bx1 - bx0) * p), by1 + 12), B.VERDE, -1)
                if p >= 1:
                    self.reiniciar()
                    del self.t_otra
            elif hasattr(self, "t_otra"):
                del self.t_otra
            return img

        # --- generar fichas: con la musica (bombos) o a ritmo fijo
        A = ctx.A
        hay_musica = A is not None and A["nivel"] > 0.15
        espera = 2.0 if t - self.t_inicio < 2.0 else 0
        if not espera and ((hay_musica and A["kick"] and t - self.t_ultima > 0.45) or
                           (t - self.t_ultima > self.intervalo)):
            libres = [c for c in range(self.CARRILES) if not any(f[0] == c and f[1] < 120 for f in self.fichas)]
            if libres:
                self.fichas.append([random.choice(libres), -110.0, 110.0, 0])
                self.t_ultima = t
        # --- mover
        for f in self.fichas:
            f[1] += self.vel * dt
        # --- toques
        for c in tocadas:
            candidatas = [f for f in self.fichas if f[0] == c and f[3] == 0 and f[1] + f[2] > zy0 - 40 and f[1] < zy1 + 20]
            x0, x1 = self.rect_carril(c)
            if candidatas:
                f = max(candidatas, key=lambda f: f[1])
                f[3] = 1
                self.puntos += 1 + self.racha // 5
                self.racha += 1
                self.flash[c] = 1.0
                self.app.sonido.tocar(MELODIA[self.i_nota % len(MELODIA)])
                self.i_nota += 1
                self._chispas((x0 + x1) / 2, (zy0 + zy1) / 2, COLORES_CARRIL[c])
                self.vel = min(320, self.vel + 3)
                self.intervalo = max(0.45, self.intervalo - 0.015)
            else:
                self.racha = 0
        # --- fichas que se pasaron
        for f in self.fichas:
            if f[3] == 0 and f[1] > zy1 + 10:
                f[3] = 2
                self.vidas -= 1
                self.racha = 0
                self.app.sonido.tocar("FALLA")
                if self.vidas <= 0:
                    self.fin = True
        self.fichas = [f for f in self.fichas if f[1] < h + 20 and not (f[3] == 1 and f[1] > h)]

        # --- dibujo: carriles
        for i in range(self.CARRILES):
            x0, x1 = self.rect_carril(i)
            cv2.line(img, (x0, 0), (x0, h), (40, 40, 40), 1)
            col = COLORES_CARRIL[i]
            proxima = any(f[0] == i and f[3] == 0 and f[1] + f[2] > zy0 - 160 for f in self.fichas)
            fl = self.flash[i]
            # zona de toque: se ilumina cuando viene una ficha
            base = 0.25 + (0.45 if proxima else 0) + 0.3 * (1 if i in ocupadas else 0)
            relleno = tuple(int(c * min(1.0, base * 0.5 + fl)) for c in col)
            cv2.rectangle(img, (x0 + 6, zy0), (x1 - 6, zy1), relleno, -1)
            cv2.rectangle(img, (x0 + 6, zy0), (x1 - 6, zy1), col, 3 if proxima else 1)
            if proxima:   # flecha: aqui vas a tocar
                cx = (x0 + x1) // 2
                cv2.arrowedLine(img, (cx, zy0 - 45), (cx, zy0 - 8), col, 3, cv2.LINE_AA, tipLength=0.4)
            B.texto(img, "TOCA", (x0 + x1) / 2, zy1 - 22, 0.5, B.BLANCO, True, 1)
            self.flash[i] = max(0.0, fl - dt * 3)
        cv2.line(img, (self.margen, self.margen // 2 + self.margen), (w, self.margen // 2 + self.margen), (30, 30, 30), 1)
        # --- fichas
        for c, y, alto, est in self.fichas:
            x0, x1 = self.rect_carril(c)
            col = COLORES_CARRIL[c] if est == 0 else ((60, 60, 60) if est == 1 else (40, 40, 200))
            y0, y1 = int(y), int(y + alto)
            cv2.rectangle(img, (x0 + 10, y0), (x1 - 10, y1), col, -1 if est == 0 else 2)
            if est == 0:
                cv2.rectangle(img, (x0 + 10, y0), (x1 - 10, y1), B.BLANCO, 1)
        # --- chispas
        vivas = []
        for s in self.chispas:
            s[0] += s[2] * dt
            s[1] += s[3] * dt
            s[3] += 300 * dt
            s[4] -= dt
            if s[4] > 0:
                cv2.circle(img, (int(s[0]), int(s[1])), 3, tuple(int(c * s[4] / 0.8) for c in s[5]), -1)
                vivas.append(s)
        self.chispas = vivas
        img = B.brillo(img, 4, 0.6)
        # --- marcador
        B.texto(img, "%d" % self.puntos, w - 20, 40, 1.1, B.BLANCO, False)
        for k in range(3):
            cv2.circle(img, (w - 60 + k * 16 - 40, 60), 6, B.ROJO if k < self.vidas else (50, 50, 50), -1)
        if self.racha >= 5:
            B.texto(img, "x%d" % (1 + self.racha // 5), w - 90, 95, 0.7, B.AMARILLO)
        if espera:
            B.texto(img, "Prepara la mano: toca la ZONA de abajo cuando llegue la ficha", w / 2, h / 2, 0.55, B.BLANCO, True)
        return img

    @staticmethod
    def icono(img, x, y, w, h, t):
        cw = w // 5
        for i in range(4):
            x0 = x + cw // 2 + i * cw
            cv2.rectangle(img, (x0, y + 10), (x0 + cw - 4, y + h - 10), (60, 60, 60), 1)
            yy = int(y + 10 + ((t * 40 + i * 37) % (h - 40)))
            cv2.rectangle(img, (x0 + 2, yy), (x0 + cw - 6, yy + 18), COLORES_CARRIL[i], -1)
        cv2.rectangle(img, (x + cw // 2, y + h - 26), (x + cw // 2 + 4 * cw - 4, y + h - 12), (200, 200, 200), 1)


class PianoLibre(B.Modo):
    nombre = "Piano libre"
    descripcion = "Toca las teclas"
    NOTAS = ["C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5", "D5", "E5"]

    def entrar(self):
        self.toques = B.Toques(0.2)
        self.luz = [0.0] * len(self.NOTAS)
        self.notas_vuelo = []    # [x, y, vida, color, radio]
        self.lut = B.colormap_lut("COLORMAP_TURBO")

    def actualizar(self, ctx):
        w, h = self.w, self.h
        img = np.zeros((h, w, 3), np.uint8)
        n = len(self.NOTAS)
        m = 20
        ancho = (w - 2 * m) / float(n)
        y0, y1 = int(h * 0.5), h - 20
        rects = {i: (int(m + i * ancho), y0, int(m + (i + 1) * ancho), y1) for i in range(n)}
        tocadas, ocupadas = self.toques.revisar(ctx.puntas, rects, ctx.t)
        for i in tocadas:
            self.app.sonido.tocar(self.NOTAS[i])
            self.luz[i] = 1.0
            x0, _, x1, _ = rects[i]
            self.notas_vuelo.append([(x0 + x1) / 2.0, float(y0), 1.0, B.color_de(self.lut, i / float(n - 1)), 18])
        # golpe de bombo de la musica: tecla al azar brilla
        if ctx.A is not None and ctx.A["kick"]:
            self.luz[random.randrange(n)] = max(0.5, self.luz[random.randrange(n)])
        for i, (x0, ya, x1, yb) in rects.items():
            col = B.color_de(self.lut, i / float(n - 1))
            lv = self.luz[i]
            relleno = tuple(int(c * (0.12 + 0.88 * lv)) for c in col)
            cv2.rectangle(img, (x0 + 3, ya), (x1 - 3, yb), relleno, -1)
            cv2.rectangle(img, (x0 + 3, ya), (x1 - 3, yb), col if i in ocupadas else (180, 180, 180), 2)
            B.texto(img, self.NOTAS[i][0], (x0 + x1) / 2, yb - 15, 0.6, B.BLANCO, True, 1)
            self.luz[i] = max(0.0, lv - ctx.dt * 2.5)
        vivas = []
        for nv in self.notas_vuelo:
            nv[1] -= 120 * ctx.dt
            nv[2] -= ctx.dt * 0.6
            if nv[2] > 0:
                c = tuple(int(v * nv[2]) for v in nv[3])
                cv2.circle(img, (int(nv[0]), int(nv[1])), int(nv[4] * (1.5 - nv[2] * 0.5)), c, 2, cv2.LINE_AA)
                cv2.line(img, (int(nv[0] + 10), int(nv[1])), (int(nv[0] + 10), int(nv[1] - 30)), c, 2)
                vivas.append(nv)
        self.notas_vuelo = vivas[-60:]
        B.texto(img, "PIANO: toca las teclas", w / 2, 60, 0.8, B.BLANCO, True)
        return B.brillo(img, 5, 0.7)

    @staticmethod
    def icono(img, x, y, w, h, t):
        n = 7
        kw = (w - 20) / n
        for i in range(n):
            x0 = int(x + 10 + i * kw)
            on = int(t * 2) % n == i
            cv2.rectangle(img, (x0, y + 20), (int(x0 + kw - 3), y + h - 15), (0, 220, 255) if on else (200, 200, 200), -1 if on else 1)
