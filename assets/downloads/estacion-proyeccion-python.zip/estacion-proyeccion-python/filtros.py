# -*- coding: utf-8 -*-
"""
filtros.py - Ajustes de imagen para que el detector vea bien las manos con poca luz.

Se ajustan en vivo con ajustar_camara.py y se guardan en filtros.json; estacion.py los usa solo.
  Camara (por v4l2-ctl): exposicion, ganancia, brillo, contraste
  Software:              gamma, CLAHE (contraste local), saturacion, suavizado, recorte a la proyeccion
  Detector:              umbral y puntos minimos por mano
  Proyeccion:            luz de relleno (gris en vez de negro para iluminar la mano)
"""
from __future__ import print_function

import json
import os
import re
import subprocess

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO = os.path.join(BASE, "filtros.json")
ARCHIVO_CALIB = os.path.join(BASE, "calib_hdmi.json")

DEFECTO = {
    "camara": {},          # {"exposure_auto": 1, "exposure_absolute": 200, "gain": 40, ...} (solo lo que se cambio)
    "gamma": 1.0,          # >1 aclara las sombras
    "clahe": 0.0,          # 0 = apagado; 1..6 = fuerza del contraste local
    "saturacion": 1.0,     # 1 = normal, 0 = gris
    "suavizado": 0,        # 0, 3, 5, 7, 9 (tamano del filtro)
    "recorte": 0.0,        # 0 = imagen completa, 1 = solo la zona proyectada
    "umbral": 0.15,        # umbral del detector poseNet (menos = ve mas, con mas errores)
    "min_puntos": 8,       # puntos minimos (de 21) para aceptar una mano
    "relleno": 0,          # 0..120: gris minimo que se proyecta para iluminar la mano
}


def cargar():
    cfg = json.loads(json.dumps(DEFECTO))
    try:
        cfg.update(json.load(open(ARCHIVO)))
    except Exception:
        pass
    return cfg


def guardar(cfg):
    with open(ARCHIVO, "w") as f:
        json.dump(cfg, f, indent=1)


# ====================================================================== controles de la camara (V4L2)
def dispositivo(fuente):
    s = str(fuente)
    if s.isdigit():
        return "/dev/video" + s
    return s if s.startswith("/dev/") else None


def controles(dev):
    """{nombre: {"tipo", "min", "max", "step", "default", "value"}} segun v4l2-ctl --list-ctrls."""
    if not dev:
        return {}
    try:
        sal = subprocess.check_output(["v4l2-ctl", "-d", dev, "--list-ctrls"],
                                      stderr=subprocess.DEVNULL).decode("utf-8", "ignore")
    except Exception:
        return {}
    res = {}
    for linea in sal.splitlines():
        m = re.match(r"\s*(\w+)\s+0x[0-9a-f]+\s+\((\w+)\)\s*:\s*(.*)", linea)
        if not m:
            continue
        d = {"tipo": m.group(2)}
        for k, v in re.findall(r"(\w+)=(-?\d+)", m.group(3)):
            d[k] = int(v)
        res[m.group(1)] = d
    return res


def poner(dev, nombre, valor):
    if not dev:
        return False
    try:
        return subprocess.call(["v4l2-ctl", "-d", dev, "-c", "%s=%d" % (nombre, int(valor))],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0
    except Exception:
        return False


def nombres_exposicion(ctrls):
    """(control de modo automatico, control de exposicion, valor 'manual', valor 'auto') segun el kernel."""
    auto = "exposure_auto" if "exposure_auto" in ctrls else ("auto_exposure" if "auto_exposure" in ctrls else None)
    expo = "exposure_absolute" if "exposure_absolute" in ctrls else \
        ("exposure_time_absolute" if "exposure_time_absolute" in ctrls else None)
    return auto, expo, 1, 3


def camara_automatica(fuente):
    """Exposicion automatica y ganancia de fabrica: para CALIBRAR (con exposicion larga el blanco se quema
    y los marcadores no se ven). Despues se aplican los ajustes de manos con aplicar_camara()."""
    dev = dispositivo(fuente)
    ctrls = controles(dev)
    if not ctrls:
        return
    auto, expo, _, v_auto = nombres_exposicion(ctrls)
    if auto:
        poner(dev, auto, v_auto)
    if "gain" in ctrls and "default" in ctrls["gain"]:
        poner(dev, "gain", ctrls["gain"]["default"])


def aplicar_camara(fuente, cfg):
    """Aplica a la camara los controles guardados (primero el modo de exposicion)."""
    dev = dispositivo(fuente)
    cam = cfg.get("camara") or {}
    if not dev or not cam:
        return
    orden = sorted(cam, key=lambda n: 0 if "auto" in n else 1)
    for n in orden:
        poner(dev, n, cam[n])


# ====================================================================== zona proyectada en la imagen de camara
def zona_proyeccion(tam_frame):
    """Rectangulo (x0, y0, x1, y1) de la proyeccion en pixeles de camara, segun calib_hdmi.json. None si no hay."""
    try:
        c = json.load(open(ARCHIVO_CALIB))
        H = np.array(c["H"], np.float64)
        w, h = c["hdmi"]
        cw0, ch0 = c.get("cam", [1280, 720])
    except Exception:
        return None
    esq = np.float32([[0, 0], [w, 0], [w, h], [0, h]])[:, None]
    cam = cv2.perspectiveTransform(esq, np.linalg.inv(H))[:, 0]
    fw, fh = tam_frame
    cam *= np.float32([fw / float(cw0), fh / float(ch0)])
    x0, y0 = cam.min(axis=0)
    x1, y1 = cam.max(axis=0)
    mx, my = 0.05 * (x1 - x0), 0.05 * (y1 - y0)
    return (max(0, int(x0 - mx)), max(0, int(y0 - my)), min(fw, int(x1 + mx)), min(fh, int(y1 + my)))


# ====================================================================== preproceso
class Preproceso(object):
    """pre(bgr) -> (imagen para el detector, (dx, dy)); sumar (dx, dy) a los puntos que regrese el detector."""

    def __init__(self, cfg):
        self.cfg = dict(cfg)
        self._lut_gamma = None
        self._clahe = None
        self._zona = None
        self._tam = None
        self.actualizar(cfg)

    def actualizar(self, cfg):
        self.cfg = dict(cfg)
        g = max(0.1, float(self.cfg.get("gamma", 1.0)))
        self._lut_gamma = None if abs(g - 1.0) < 1e-3 else \
            np.clip(((np.arange(256) / 255.0) ** (1.0 / g)) * 255.0, 0, 255).astype(np.uint8)
        c = float(self.cfg.get("clahe", 0.0))
        self._clahe = cv2.createCLAHE(clipLimit=c, tileGridSize=(8, 8)) if c > 0 else None
        self._tam = None   # recalcular la zona de recorte

    def recorte(self, w, h):
        if self._tam != (w, h):
            self._tam = (w, h)
            self._zona = zona_proyeccion((w, h))
        p = float(self.cfg.get("recorte", 0.0))
        if p <= 0:
            return 0, 0, w, h
        z = self._zona or (int(w * 0.1), int(h * 0.1), int(w * 0.9), int(h * 0.9))
        x0, y0 = int(z[0] * p), int(z[1] * p)
        x1, y1 = int(w + (z[2] - w) * p), int(h + (z[3] - h) * p)
        if x1 - x0 < 64 or y1 - y0 < 64:
            return 0, 0, w, h
        return x0, y0, x1, y1

    def __call__(self, bgr):
        h, w = bgr.shape[:2]
        x0, y0, x1, y1 = self.recorte(w, h)
        img = bgr[y0:y1, x0:x1]
        k = int(self.cfg.get("suavizado", 0))
        if k >= 3:
            img = cv2.GaussianBlur(img, (k | 1, k | 1), 0)
        if self._lut_gamma is not None:
            img = cv2.LUT(img, self._lut_gamma)
        if self._clahe is not None:
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            lab[:, :, 0] = self._clahe.apply(lab[:, :, 0])
            img = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        s = float(self.cfg.get("saturacion", 1.0))
        if s <= 0.01:
            img = cv2.cvtColor(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2BGR)
        elif abs(s - 1.0) > 0.01:
            hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            hsv[:, :, 1] = np.clip(hsv[:, :, 1].astype(np.float32) * s, 0, 255).astype(np.uint8)
            img = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
        return np.ascontiguousarray(img), (x0, y0)
