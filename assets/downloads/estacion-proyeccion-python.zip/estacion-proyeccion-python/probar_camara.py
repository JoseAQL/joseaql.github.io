#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
probar_camara.py - Revisa la camara antes de calibrar.

  python3 probar_camara.py            -> busca camaras, mide FPS, guarda una foto y busca marcadores
  python3 probar_camara.py --indice 2 -> prueba una camara en particular
  python3 probar_camara.py --ver 20   -> ademas muestra la imagen 20 s en una ventana
                                         (por MobaXterm la ventana sale en tu PC)
Guarda registros/prueba_camara.jpg con los marcadores ArUco detectados dibujados.
"""
from __future__ import print_function

import argparse
import glob
import os
import time

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))


def abrir(indice, ancho, alto):
    cap = cv2.VideoCapture(indice, cv2.CAP_V4L2)
    if not cap.isOpened():
        return None
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, ancho)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, alto)
    ok, f = cap.read()
    if not ok or f is None:
        cap.release()
        return None
    return cap


def detector():
    if not hasattr(cv2, "aruco"):
        return None
    a = cv2.aruco
    d = a.getPredefinedDictionary(0) if hasattr(a, "getPredefinedDictionary") else a.Dictionary_get(0)
    if hasattr(a, "ArucoDetector"):
        det = a.ArucoDetector(d, a.DetectorParameters())
        return lambda g: det.detectMarkers(g)
    p = a.DetectorParameters_create()
    return lambda g: a.detectMarkers(g, d, parameters=p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--indice", type=int, default=None)
    ap.add_argument("--ancho", type=int, default=1280)
    ap.add_argument("--alto", type=int, default=720)
    ap.add_argument("--ver", type=float, default=0, help="segundos mostrando la imagen en una ventana")
    args = ap.parse_args()

    print("OpenCV", cv2.__version__, "| ArUco:", "si" if hasattr(cv2, "aruco") else "NO")
    dispositivos = sorted(glob.glob("/dev/video*"), key=lambda s: int(s.replace("/dev/video", "") or 0))
    print("Dispositivos de video:", " ".join(dispositivos) or "ninguno")
    indices = [args.indice] if args.indice is not None else [int(d.replace("/dev/video", "")) for d in dispositivos]

    cap, usado = None, None
    for i in indices:
        cap = abrir(i, args.ancho, args.alto)
        if cap is not None:
            usado = i
            break
        print("  /dev/video%d no entrega imagen (normal: muchas camaras crean 2 dispositivos)" % i)
    if cap is None:
        print("\n!! Ninguna camara entrego imagen.")
        print("   - Revisa el cable USB y prueba otro puerto (los azules son USB 3).")
        print("   - Si es Pi Camera (cinta), dime: necesita otro tipo de conexion en el codigo.")
        return 1

    t0, n, f = time.time(), 0, None
    while n < 40:
        ok, fr = cap.read()
        if ok:
            f, n = fr, n + 1
    fps = n / (time.time() - t0)
    h, w = f.shape[:2]
    print("\nCamara OK: /dev/video%d  %dx%d  %.1f FPS" % (usado, w, h, fps))

    det = detector()
    vis = f.copy()
    ids_txt = "sin ArUco"
    if det:
        esq, ids, _ = det(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
        if ids is not None:
            cv2.aruco.drawDetectedMarkers(vis, esq, ids)
            ids_txt = "marcadores vistos: " + ", ".join(str(int(i)) for i in sorted(ids.flatten()))
        else:
            ids_txt = "no se ven marcadores"
    print(ids_txt)
    faltan = [m for m in (40, 41, 42, 43) if det and ("%d" % m) not in ids_txt]
    if det and faltan:
        print("Para calibrar deben verse los marcadores 40, 41, 42 y 43 (faltan: %s)." % ", ".join(map(str, faltan)))
    brillo = float(np.mean(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)))
    print("Brillo promedio: %.0f / 255 %s" % (brillo, "(muy oscuro)" if brillo < 50 else "(muy claro)" if brillo > 210 else ""))

    os.makedirs(os.path.join(BASE, "registros"), exist_ok=True)
    salida = os.path.join(BASE, "registros", "prueba_camara.jpg")
    cv2.putText(vis, "/dev/video%d %dx%d %.0f FPS | %s" % (usado, w, h, fps, ids_txt), (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
    cv2.imwrite(salida, vis)
    print("Foto guardada:", salida)

    cfg_path = os.path.join(BASE, "config.json")
    if os.path.exists(cfg_path):
        import json
        with open(cfg_path, encoding="utf-8") as fh:
            cfg = json.load(fh)
        if cfg["camara"].get("indice") != usado or cfg["camara"].get("ancho") != w:
            cfg["camara"].update({"indice": usado, "ancho": w, "alto": h, "tipo": "usb"})
            with open(cfg_path, "w", encoding="utf-8") as fh:
                json.dump(cfg, fh, indent=2, ensure_ascii=False)
            print("config.json actualizado: camara indice %d, %dx%d" % (usado, w, h))

    if args.ver > 0:
        if not os.environ.get("DISPLAY"):
            print("No hay pantalla (DISPLAY vacio): no puedo mostrar la ventana.")
        else:
            print("Mostrando %.0f s (tecla q para cerrar)..." % args.ver)
            t_fin = time.time() + args.ver
            while time.time() < t_fin:
                ok, fr = cap.read()
                if not ok:
                    continue
                if det:
                    esq, ids, _ = det(cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY))
                    if ids is not None:
                        cv2.aruco.drawDetectedMarkers(fr, esq, ids)
                cv2.imshow("Camara del Asesor", cv2.resize(fr, (w // 2, h // 2)))
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            cv2.destroyAllWindows()
    cap.release()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
