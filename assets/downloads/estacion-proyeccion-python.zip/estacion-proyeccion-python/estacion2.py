#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
estacion2.py - Version de PRUEBAS. No cambia estacion.py: lo usa y le agrega:
  1. Ventana por SSH (MobaXterm) con la camara, las manos y el MENU DE AJUSTES (igual que
     ajustar_camara.py) para mover contraste, exposicion, gamma... EN VIVO mientras corre la estacion.
     Haz clic en la ventana y usa las teclas (fila de arriba = SUBIR, fila de abajo = BAJAR):
       Q/A exposicion   W/S ganancia   E/D brillo   R/F contraste   T/G gamma   Y/H CLAHE
       U/J saturacion   I/K suavizado  O/L recorte  P/N umbral      X/Z puntos  V/C luz de relleno
       1 = exposicion automatica   B = cambiar vista   M = guardar   0 = restaurar todo
     Al salir (Ctrl+C) los ajustes se guardan solos en filtros.json.
  2. Audio con pasa-bajas (ignora el chillido agudo del proyector) y sin el ruido constante.
  3. Regresar al menu SOLO con la punta del dedo INDICE sobre el boton MENU (1 s).
     El puno ya no saca del modo (si lo quieres de vuelta: --puno-menu).
     Si un modo falla, ya no te avienta al menu: avisa y sigues ahi.
  4. Barra MIC en el menu para ver si el microfono oye.

  python3 estacion2.py --salida fb --ahorro
  python3 estacion2.py --salida fb --ahorro --corte-audio 3000   (quita mas agudos)
  python3 estacion2.py --salida fb --ahorro --ganancia-audio 3   (microfono muy bajito)
  python3 estacion2.py --salida fb --ahorro --menu-der           (boton MENU a la derecha)
  python3 estacion2.py --salida fb --ahorro --sin-ver            (sin ventana por SSH)
Salir: Ctrl+C
"""
from __future__ import print_function

import os

if os.path.exists("/etc/nv_tegra_release"):
    os.environ.setdefault("OPENBLAS_CORETYPE", "ARMV8")

import argparse
import json
import multiprocessing as mp
import queue
import time
import traceback

import cv2
import numpy as np

import estacion as E
import filtros as FI
import hdmi_manos as HM
import hdmi_reactivo as R
import modos_base as B
import plataforma as P

log = E.log
AudioBase = R.Audio
MENU_DEDO = 1.0     # segundos con el dedo indice sobre MENU
CADA_VER = 0.3      # segundos entre cuadros de la ventana SSH
VENTANA = "Estacion 2 - camara y ajustes (SSH)"
GAMMAS = [0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.3, 2.6, 3.0]
CLAHES = [0, 1, 1.5, 2, 3, 4, 6]
SATS = [round(0.1 * i, 1) for i in range(16)]
SUAV = [0, 3, 5, 7, 9]
RECORTES = [round(0.1 * i, 1) for i in range(11)]
UMBRALES = [round(0.05 + 0.025 * i, 3) for i in range(19)]
MINPTS = list(range(4, 17))
RELLENOS = list(range(0, 160, 10))


def paso(valor, lista, signo):
    i = min(range(len(lista)), key=lambda k: abs(lista[k] - valor))
    return lista[max(0, min(len(lista) - 1, i + signo))]


def copia(cfg):
    return json.loads(json.dumps(cfg))


def letrero(img, s, x, y, esc=0.45, col=(230, 230, 230)):
    cv2.putText(img, str(s), (int(x), int(y)), cv2.FONT_HERSHEY_SIMPLEX, esc, col, 1, cv2.LINE_AA)


# ====================================================================== vision (proceso aparte)
def proceso_vision2(fuente, res, motor, cola, parar, fps_max=0, max_manos=2, cola_cfg=None):
    """Igual que el de estacion.py, pero recibe los ajustes en vivo y manda lo que ve el detector."""
    import sys

    def logv(*a):
        print(time.strftime("[%H:%M:%S]"), *a, file=sys.stderr)
        sys.stderr.flush()

    cv2.setNumThreads(1)
    cfg = FI.cargar()
    cap = None
    for intento in range(5):
        try:
            cap = P.Camara(fuente, res)
            if cap.read()[0]:
                break
            cap.release()
        except Exception as e:
            logv("Vision: no abre la camara %s (%s)" % (fuente, e))
        cap = None
        time.sleep(2)
    if cap is None:
        logv("Vision: sin camara, no hay manos")
        return
    FI.aplicar_camara(fuente, cfg)
    dev = FI.dispositivo(fuente)
    pre = FI.Preproceso(cfg)
    manos = P.DetectorManos(motor, max_manos=max_manos, log=logv, umbral=cfg["umbral"],
                            min_puntos=cfg["min_puntos"])
    if manos.motor == "posenet":
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)
    n, t0, fps = 0, time.time(), 0.0
    while not parar.is_set():
        nuevo = None
        while cola_cfg is not None:      # ajustes que llegan de la ventana SSH
            try:
                nuevo = cola_cfg.get_nowait()
            except queue.Empty:
                break
        if nuevo is not None:
            viejo = cfg.get("camara") or {}
            cam = nuevo.get("camara") or {}
            for nom in sorted(cam, key=lambda x: 0 if "auto" in x else 1):
                if viejo.get(nom) != cam[nom]:
                    FI.poner(dev, nom, cam[nom])
            cfg = nuevo
            pre.actualizar(cfg)
            manos.set_umbral(cfg["umbral"])
            manos.min_puntos = int(cfg["min_puntos"])
        t_cuadro = time.time()
        ok, f = cap.read()
        if not ok:
            time.sleep(0.01)
            continue
        ch, cw = f.shape[:2]
        entrada, (dx, dy) = pre(f)
        res = manos.procesar(entrada)
        if dx or dy:
            res = [(p + np.float32([dx, dy]), g) for p, g in res]
        chico = det = None
        if n % 3 == 0:
            chico = cv2.resize(f, (320, 180))
            eh, ew = entrada.shape[:2]
            det = (cv2.resize(entrada, (320, max(1, int(320 * eh / float(ew))))),
                   dx, dy, ew, eh, float(entrada.mean()))
        n += 1
        if time.time() - t0 > 2:
            fps, t0, n = n / (time.time() - t0), time.time(), 0
        msg = (time.time(), res, chico, fps, (cw, ch), manos.motor or "ninguno", det)
        if fps_max > 0:
            time.sleep(max(0.0, 1.0 / fps_max - (time.time() - t_cuadro)))
        try:
            cola.put_nowait(msg)
        except queue.Full:
            try:
                cola.get_nowait()
            except queue.Empty:
                pass
            try:
                cola.put_nowait(msg)
            except queue.Full:
                pass
    cap.release()


# ====================================================================== audio con filtro
class Audio2(AudioBase):
    CORTE = 4000.0
    GANANCIA = 1.0

    def __init__(self, dispositivo):
        self.corte2 = float(min(max(self.CORTE, 1000), self.SR / 2 - 100))
        self.ganancia2 = float(self.GANANCIA)
        self.rms = self.crudo = 0.0
        self.n_golpes, self.t_kick, self.ultimo = 0, 0.0, None
        AudioBase.__init__(self, dispositivo)

    def _loop(self):
        f = np.fft.rfftfreq(self.N, 1.0 / self.SR)
        corte = self.corte2
        paso_f = ((f >= 30) & (f <= corte)).astype(np.float32)
        medio = min(2000.0, corte * 0.5)
        bandas = [(f >= 30) & (f < 180), (f >= 180) & (f < medio), (f >= medio) & (f < corte)]
        bordes = np.geomspace(40, corte * 0.95, 33)
        idx = [np.where((f >= bordes[i]) & (f < bordes[i + 1]))[0] for i in range(32)]
        idx = [ix if len(ix) else np.array([int(np.argmin(np.abs(f - bordes[i])))])
               for i, ix in enumerate(idx)]
        caja_banda = (f >= 1500) & (f < min(5000.0, corte))
        piso_e, max_e = None, np.full(32, 1e-3)
        prom_caja, t_caja = 0.0, -1.0
        maximos = np.array([1e-3, 1e-3, 1e-3, 1e-3])
        piso = None
        prom_graves, t_golpe, t_audio = 0.0, -1.0, 0.0
        ventana = np.hanning(self.N)
        while True:
            datos = self.p.stdout.read(self.N * 2)
            if not datos or len(datos) < self.N * 2:
                err = self.p.stderr.read().decode("utf-8", "ignore").strip()
                log("Audio: el microfono dejo de enviar datos. %s" % err[:120])
                self.ok = False
                return
            t_audio += self.N / float(self.SR)
            x = np.frombuffer(datos, np.int16).astype(np.float32) / 32768.0 * self.ganancia2
            crudo = float(np.sqrt(np.mean(x ** 2)))
            x = np.fft.irfft(np.fft.rfft(x) * paso_f, self.N).astype(np.float32)
            rms = float(np.sqrt(np.mean(x ** 2)))
            esp = np.abs(np.fft.rfft(x * ventana))
            vals = np.array([rms] + [float(esp[b].mean()) for b in bandas])
            if piso is None:
                piso = vals.copy()
            piso = np.minimum(piso * 1.0004 + 1e-7, vals)
            util = np.maximum(vals - piso * 1.05, 0)
            util[0] = max(vals[0] - piso[0] * 0.85, 0.0)
            maximos = np.maximum(maximos * 0.998, util)
            maximos[0] = max(maximos[0], 0.006)
            norm = np.clip(util / (maximos + 1e-9), 0, 1)
            if rms < 0.002 or util[0] < 0.0015:
                norm[:] = 0
            ebandas = np.array([esp[ix].mean() for ix in idx], np.float32)
            if piso_e is None:
                piso_e = ebandas.copy()
            piso_e = np.minimum(piso_e * 1.0008 + 1e-7, ebandas)
            ut = np.maximum(ebandas - piso_e * 0.6, 0)
            max_e = np.maximum(max_e * 0.997, ut)
            if rms >= 0.002:
                espectro = np.clip(ut / (max_e + 1e-9), 0, 1)
            else:
                espectro = np.zeros(32, np.float32)
            ec = float(esp[caja_banda].mean())
            caja = (prom_caja > 0 and ec > prom_caja * 2.0 and rms >= 0.004
                    and t_audio - t_caja > 0.15)
            prom_caja = ec if prom_caja == 0 else prom_caja * 0.93 + ec * 0.07
            if caja:
                t_caja = t_audio
            e = vals[1]
            golpe = (prom_graves > 0 and e > prom_graves * 1.8 and rms >= 0.004
                     and t_audio - t_golpe > 0.22)
            prom_graves = e if prom_graves == 0 else prom_graves * 0.95 + e * 0.05
            with self.lock:
                self.rms, self.crudo = rms, crudo
                self.nivel = self.nivel * 0.6 + norm[0] * 0.4
                self.graves = self.graves * 0.5 + norm[1] * 0.5
                self.medios = self.medios * 0.6 + norm[2] * 0.4
                self.agudos = self.agudos * 0.6 + norm[3] * 0.4
                if golpe:
                    self.golpes += 1
                    self.n_golpes += 1
                    t_golpe = t_audio
                if caja:
                    self.cajas += 1
                self.espectro = self.espectro * 0.45 + espectro.astype(np.float32) * 0.55
                self.onda = x[-512:].copy()

    def leer_todo(self):
        A = AudioBase.leer_todo(self)
        A["rms"], A["crudo"] = self.rms, self.crudo
        if A["kick"]:
            self.t_kick = time.time()
        self.ultimo = A
        return A


# ====================================================================== menu con barra MIC
class Menu2(E.Menu):
    def actualizar(self, ctx):
        img = E.Menu.actualizar(self, ctx)
        if ctx.A is not None:
            x1 = self.w - 14
            nivel = min(1.0, ctx.A["nivel"]) if ctx.A.get("rms", 1) >= 0.002 else 0.0
            cv2.rectangle(img, (x1 - 90, 42), (x1, 52), (70, 70, 70), 1)
            cv2.rectangle(img, (x1 - 90, 42), (x1 - 90 + int(90 * nivel), 52), B.VERDE, -1)
            B.texto(img, "MIC", x1 - 126, 52, 0.4, B.GRIS, False, 1)
        return img


# ====================================================================== aplicacion
class App2(E.App):
    def __init__(self, args):
        self.cfg = FI.cargar()          # ajustes de camara y filtros (se mueven en vivo)
        self.cola_cfg = None
        self.det = None                 # lo que ve el detector (imagen chica, dx, dy, ancho, alto, luz)
        E.App.__init__(self, args)
        self.cfg["relleno"] = int(self.relleno)
        viejo = self.menu
        self.menu = Menu2(self)
        if self.modo is viejo:
            self.modo = self.menu
            self.menu.entrar()
        self.dev = FI.dispositivo(args.camara)
        self.ctrls = FI.controles(self.dev)
        self.auto, self.expo, self.v_manual, self.v_auto = FI.nombres_exposicion(self.ctrls)
        self.vista, self.msg, self.t_msg, self.ventana_lista = 0, "", 0.0, False
        x11 = getattr(HM, "VentanaX11", ())
        self.ver = (bool(os.environ.get("DISPLAY")) and not args.sin_ver
                    and not isinstance(self.salida, x11))
        if self.ver:
            log("Ventana de camara y ajustes por SSH: activada (--sin-ver para quitarla)")
        elif not args.sin_ver:
            log("Sin ventana SSH: conecta con X11 activado (MobaXterm lo trae por defecto)")
        self.t_ver, self.t_log2, self.golpes_log = 0.0, time.time(), 0
        self._mostrar_base = self.salida.mostrar
        self.salida.mostrar = self._mostrar2

    # ---------- vision con ajustes en vivo
    def iniciar_vision(self):
        ctx = mp.get_context("spawn" if P.tipo() == "jetson" else "fork")
        self.cola = ctx.Queue(maxsize=2)
        self.parar = ctx.Event()
        self.cola_cfg = ctx.Queue()
        a = self.args
        self.proc = ctx.Process(target=proceso_vision2, daemon=True,
                                args=(a.camara, a.res, a.manos, self.cola, self.parar,
                                      10 if a.ahorro else 0, 1 if a.ahorro else 2, self.cola_cfg))
        self.proc.start()
        self.cola_cfg.put(copia(self.cfg))
        self.t_vision, self.vision_lista = time.time(), False
        log("Vision iniciada en proceso aparte (pid %d)" % self.proc.pid)

    def _leer_vision(self):
        while True:
            try:
                m = self.cola.get_nowait()
            except queue.Empty:
                break
            tv, res, chico, fps, tam, motor = m[:6]
            self.manos_cam, self.fps_vision, self.tam_cam = res, fps, tam
            if not self.vision_lista:
                self.vision_lista = True
                log("Manos listas: detector %s (%.0f s en cargar)" % (motor, time.time() - self.t_vision))
            if chico is not None:
                self.frame = chico
            if len(m) > 6 and m[6] is not None:
                self.det = m[6]

    # ---------- ajustes con teclas (como ajustar_camara.py)
    def _aviso(self, t):
        self.msg, self.t_msg = t, time.time()
        log("Ajuste: " + t)

    def _enviar(self):
        if self.cola_cfg is not None:
            self.cola_cfg.put(copia(self.cfg))

    def _ctrl(self, nombre, signo, etiqueta):
        c = self.ctrls.get(nombre)
        if not c or "min" not in c:
            self._aviso("Tu camara no tiene '%s'" % etiqueta)
            return
        actual = self.cfg["camara"].get(nombre, c.get("value", c.get("default", 0)))
        pasito = max(c.get("step", 1), (c["max"] - c["min"]) // 16 or 1)
        self.cfg["camara"][nombre] = int(max(c["min"], min(c["max"], actual + signo * pasito)))
        self._enviar()
        self._aviso("%s: %d" % (etiqueta, self.cfg["camara"][nombre]))

    def _exposicion(self, signo):
        if not self.expo:
            self._aviso("Tu camara no deja cambiar la exposicion")
            return
        c = self.ctrls[self.expo]
        if self.auto:
            self.cfg["camara"][self.auto] = self.v_manual
        actual = self.cfg["camara"].get(self.expo, c.get("value", c.get("default", 100)))
        nuevo = actual * 1.4 if signo > 0 else actual / 1.4
        nuevo = int(max(c.get("min", 1), min(c.get("max", 10000), round(nuevo))))
        if nuevo == actual:
            nuevo = int(max(c.get("min", 1), min(c.get("max", 10000), actual + signo)))
        self.cfg["camara"][self.expo] = nuevo
        self._enviar()
        self._aviso("Exposicion manual: %d" % nuevo)

    def _expo_auto(self):
        if self.auto:
            self.cfg["camara"][self.auto] = self.v_auto
        self.cfg["camara"].pop(self.expo, None)
        self._enviar()
        self._aviso("Exposicion automatica")

    def _soft(self, clave, lista, signo, etiqueta):
        self.cfg[clave] = paso(self.cfg[clave], lista, signo)
        if clave == "relleno":
            self.relleno = int(self.cfg[clave])
        self._enviar()
        self._aviso("%s: %s" % (etiqueta, self.cfg[clave]))

    def _restaurar(self):
        cam = {}
        for n in list(self.cfg["camara"]):
            if "default" in self.ctrls.get(n, {}):
                cam[n] = self.ctrls[n]["default"]
        self.cfg.update({k: v for k, v in FI.DEFECTO.items() if k != "camara"})
        self.cfg["camara"] = cam
        self.relleno = 0
        self._enviar()
        self._aviso("Todo como venia (M para guardar)")

    def _tecla(self, k):
        if 65 <= k <= 90:
            k += 32
        mapa = {
            "q": lambda: self._exposicion(+1), "a": lambda: self._exposicion(-1),
            "w": lambda: self._ctrl("gain", +1, "Ganancia"),
            "s": lambda: self._ctrl("gain", -1, "Ganancia"),
            "e": lambda: self._ctrl("brightness", +1, "Brillo"),
            "d": lambda: self._ctrl("brightness", -1, "Brillo"),
            "r": lambda: self._ctrl("contrast", +1, "Contraste"),
            "f": lambda: self._ctrl("contrast", -1, "Contraste"),
            "t": lambda: self._soft("gamma", GAMMAS, +1, "Gamma"),
            "g": lambda: self._soft("gamma", GAMMAS, -1, "Gamma"),
            "y": lambda: self._soft("clahe", CLAHES, +1, "CLAHE"),
            "h": lambda: self._soft("clahe", CLAHES, -1, "CLAHE"),
            "u": lambda: self._soft("saturacion", SATS, +1, "Saturacion"),
            "j": lambda: self._soft("saturacion", SATS, -1, "Saturacion"),
            "i": lambda: self._soft("suavizado", SUAV, +1, "Suavizado"),
            "k": lambda: self._soft("suavizado", SUAV, -1, "Suavizado"),
            "o": lambda: self._soft("recorte", RECORTES, +1, "Recorte"),
            "l": lambda: self._soft("recorte", RECORTES, -1, "Recorte"),
            "p": lambda: self._soft("umbral", UMBRALES, +1, "Umbral"),
            "n": lambda: self._soft("umbral", UMBRALES, -1, "Umbral"),
            "x": lambda: self._soft("min_puntos", MINPTS, +1, "Puntos minimos"),
            "z": lambda: self._soft("min_puntos", MINPTS, -1, "Puntos minimos"),
            "v": lambda: self._soft("relleno", RELLENOS, +1, "Luz de relleno"),
            "c": lambda: self._soft("relleno", RELLENOS, -1, "Luz de relleno"),
            "1": self._expo_auto, "0": self._restaurar,
        }
        ch = "n" if k == 241 else (chr(k) if 32 <= k < 127 else "")
        if ch in mapa:
            mapa[ch]()
        elif ch == "b":
            self.vista = 1 - self.vista
            self._aviso(["Vista: lo que ve el detector", "Vista: camara original"][self.vista])
        elif ch == "m":
            FI.guardar(self.cfg)
            self._aviso("Guardado en filtros.json")

    # ---------- si un modo falla, se queda en el modo (antes regresaba al menu)
    def abrir(self, cls):
        E.App.abrir(self, cls)
        m = self.modo
        if m is self.menu or getattr(m, "_envuelto", False):
            return
        orig = m.actualizar

        def actualizar(ctx):
            try:
                return orig(ctx)
            except Exception as e:
                if time.time() - getattr(m, "_t_err", 0) > 3:
                    m._t_err = time.time()
                    log("Error en modo %s (sigo en el modo): %s" % (m.nombre, e))
                    traceback.print_exc()
                img = np.zeros((self.h, self.w, 3), np.uint8)
                B.texto(img, "Error en el modo (ver terminal). Usa MENU",
                        self.w / 2, self.h / 2, 0.6, B.ROJO, True)
                return img
        m.actualizar = actualizar
        m._envuelto = True

    # ---------- boton MENU: solo la punta del indice
    def _rect_menu(self):
        bw, bh = max(110, int(self.w * 0.18)), max(70, int(self.h * 0.17))
        if self.args.menu_der:
            return self.w - bw, 0, self.w, bh
        return 0, 0, bw, bh

    def _boton_menu(self, img, ctx):
        x0, y0, x1, y1 = self._rect_menu()
        t = ctx.t
        sobre = any(x0 <= x <= x1 and y0 <= y <= y1 for x, y in ctx.indices)
        if sobre:
            self.t_menu_visto = t
            self.t_menu = self.t_menu or t
        elif self.t_menu is not None and t - self.t_menu_visto > E.GRACIA:
            self.t_menu = None
        prog = min(1.0, (t - self.t_menu) / MENU_DEDO) if self.t_menu else 0.0
        sub = img[y0:y1, x0:x1]
        sub[:] = (sub * 0.25).astype(np.uint8)
        col = B.AMARILLO if self.t_menu else (200, 200, 200)
        if prog > 0:
            cv2.rectangle(img, (x0, y0), (int(x0 + (x1 - x0) * prog), y1), (0, 120, 160), -1)
        cv2.rectangle(img, (x0 + 1, y0 + 1), (x1 - 1, y1), col, 3)
        cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
        for k in range(3):
            yy = cy - 22 + k * 9
            cv2.line(img, (cx - 16, yy), (cx + 16, yy), col, 3, cv2.LINE_AA)
        B.texto(img, "MENU", cx, cy + 22, 0.75, col, True, 2)
        if prog >= 1:
            self._volver_menu("dedo indice en MENU")
            return img
        for p, g in (ctx.manos if self.args.puno_menu else []):
            if g == "puno":
                self.t_puno_visto, self.pos_puno = t, (int(p[9][0]), int(p[9][1]))
                self.t_puno = self.t_puno or t
        if self.t_puno is not None and t - self.t_puno_visto > 0.4:
            self.t_puno = None
        if self.t_puno is not None:
            dur = t - self.t_puno
            avance = min(1.0, dur / E.MENU_PUNO)
            if dur > 0.3:
                px, py = self.pos_puno
                cv2.circle(img, (px, py), 38, (60, 60, 60), 4, cv2.LINE_AA)
                cv2.ellipse(img, (px, py), (38, 38), -90, 0, int(360 * avance),
                            B.AMARILLO, 6, cv2.LINE_AA)
            if avance >= 1:
                self._volver_menu("puno")
                return img
        if t - self.t_modo < 5:
            txt = "Volver al menu: dedo indice sobre MENU"
            if self.args.puno_menu:
                txt += "  o  puno 2 s"
            B.texto(img, txt, self.w / 2, self.h - 14, 0.5, B.AMARILLO, True, 1)
        return img

    # ---------- cada cuadro proyectado: ventana SSH, teclas y aviso del audio
    def _mostrar2(self, img):
        self._mostrar_base(img)
        t = time.time()
        if self.ver:
            if t - self.t_ver > CADA_VER:
                self.t_ver = t
                self._ventana_ssh()
            if self.ventana_lista:
                try:
                    k = cv2.waitKey(1) & 0xFF
                except Exception:
                    k = 255
                if k != 255:
                    self._tecla(k)
        if t - self.t_log2 > 5:
            self.t_log2 = t
            self._log_audio()

    def _log_audio(self):
        a = getattr(self, "audio", None)
        if a is None:
            log("Audio: sin microfono")
            return
        if not a.ok:
            log("Audio: el microfono se cayo (revisa el adaptador USB)")
            return
        golpes, self.golpes_log = a.n_golpes - self.golpes_log, a.n_golpes
        if a.nivel > 0.05:
            estado = "OYE MUSICA"
        elif a.crudo < 0.001:
            estado = "casi nada: sube el volumen del mic (alsamixer) o --ganancia-audio 3"
        else:
            estado = "solo ruido de fondo"
        log("Audio: mic %.4f | filtrado %.4f | nivel %.2f graves %.2f medios %.2f "
            "agudos %.2f | golpes %d | %s" % (a.crudo, a.rms, a.nivel, a.graves, a.medios,
                                            a.agudos, golpes, estado))

    def _imagen_camara(self, ancho):
        cw, ch = self.tam_cam
        if self.vista == 0 and self.det is not None:
            img, dx, dy, ew, eh, luz = self.det
            k = ancho / float(ew)
            v = cv2.resize(img, (ancho, max(1, int(eh * k))))
            off = np.float32([dx, dy])
        elif self.frame is not None:
            k = ancho / float(cw)
            v = cv2.resize(self.frame, (ancho, max(1, int(ch * k))))
            off = np.float32([0, 0])
            if self.det is not None and float(self.cfg.get("recorte", 0)) > 0:
                img, dx, dy, ew, eh, luz = self.det
                cv2.rectangle(v, (int(dx * k), int(dy * k)), (int((dx + ew) * k) - 1,
                              int((dy + eh) * k) - 1), (0, 200, 255), 2)
        else:
            v = np.zeros((int(ancho * ch / float(cw)), ancho, 3), np.uint8)
            B.texto(v, "Sin imagen de camara todavia", ancho / 2, v.shape[0] / 2, 0.6, B.GRIS,
                    True, 1)
            return v
        for cam, g in self.manos_cam:
            q = ((cam - off) * k).astype(np.int32)
            for a, b in B.CONEX:
                cv2.line(v, tuple(q[a]), tuple(q[b]), (255, 60, 220), 2, cv2.LINE_AA)
            for i in B.PUNTAS:
                cv2.circle(v, tuple(q[i]), 5, (0, 255, 255), -1, cv2.LINE_AA)
            B.texto(v, g or "mano", q[0][0], q[0][1] + 20, 0.6, B.VERDE, True, 1)
        nombre = ["DETECTOR (B cambia)", "CAMARA (B cambia)"][self.vista]
        B.texto(v, nombre, 8, 20, 0.5, B.AMARILLO, False, 1)
        return v

    def _valor_ctrl(self, nombre):
        c = self.ctrls.get(nombre)
        if not c:
            return "no disponible"
        v = self.cfg["camara"].get(nombre, c.get("value", "?"))
        return "%s  (%s..%s)" % (v, c.get("min", "?"), c.get("max", "?"))

    def _panel(self, alto):
        p = np.full((alto, 330, 3), 28, np.uint8)
        c = self.cfg
        if self.expo:
            v_auto = c["camara"].get(self.auto, self.ctrls.get(self.auto, {}).get("value"))
            if self.auto and v_auto != self.v_manual:
                expo = "auto"
            else:
                expo = str(c["camara"].get(self.expo, self.ctrls[self.expo].get("value")))
        else:
            expo = "no disponible"
        luz = self.det[5] if self.det is not None else 0.0
        letrero(p, "%s | manos %d | %.1f FPS | luz %.0f" % (self.modo.nombre[:13],
                len(self.manos_cam), self.fps_vision, luz), 10, 22, 0.45, (0, 255, 255))
        filas = [("Q/A", "Exposicion", expo), ("W/S", "Ganancia", self._valor_ctrl("gain")),
                 ("E/D", "Brillo", self._valor_ctrl("brightness")),
                 ("R/F", "Contraste", self._valor_ctrl("contrast")),
                 ("T/G", "Gamma", c["gamma"]), ("Y/H", "CLAHE", c["clahe"]),
                 ("U/J", "Saturacion", c["saturacion"]), ("I/K", "Suavizado", c["suavizado"]),
                 ("O/L", "Recorte", "%d %%" % int(c["recorte"] * 100)),
                 ("P/N", "Umbral", c["umbral"]), ("X/Z", "Puntos min", c["min_puntos"]),
                 ("V/C", "Relleno", c["relleno"])]
        y = 48
        for tec, nom, val in filas:
            letrero(p, tec, 10, y, 0.5, (0, 200, 255))
            letrero(p, "%s: %s" % (nom, val), 60, y, 0.47)
            y += 22
        letrero(p, "1 expo auto   B vista   M guardar", 10, y + 4, 0.43, (150, 150, 150))
        letrero(p, "0 restaurar   (clic aqui y teclas)", 10, y + 22, 0.43, (150, 150, 150))
        if time.time() - self.t_msg < 4:
            letrero(p, self.msg[:38], 10, y + 44, 0.45, (80, 255, 80))
        # ----- audio
        y0 = y + 62
        cv2.line(p, (10, y0 - 12), (320, y0 - 12), (70, 70, 70), 1)
        a = getattr(self, "audio", None)
        A = a.ultimo if a is not None else None
        if a is None or A is None:
            letrero(p, "AUDIO: sin microfono", 10, y0 + 6, 0.47, B.ROJO)
            return p
        if not a.ok:
            letrero(p, "AUDIO: el mic se cayo", 10, y0 + 6, 0.47, B.ROJO)
            return p
        oye = A["nivel"] > 0.05
        letrero(p, "AUDIO: %s" % ("OYE" if oye else "silencio / ruido"), 10, y0 + 6, 0.47,
                B.VERDE if oye else (150, 150, 150))
        letrero(p, "mic %.4f  filtrado %.4f" % (A["crudo"], A["rms"]), 10, y0 + 24, 0.4)
        if time.time() - a.t_kick < 0.35:
            cv2.circle(p, (305, y0 + 2), 10, (0, 0, 255), -1)
        barras = (("nivel", A["nivel"]), ("graves", A["graves"]), ("medios", A["medios"]),
                  ("agudos", A["agudos"]))
        for i, (nom, val) in enumerate(barras):
            yb = y0 + 34 + i * 17
            letrero(p, nom, 10, yb + 10, 0.4)
            cv2.rectangle(p, (70, yb), (70 + int(240 * min(1.0, val)), yb + 11), (0, 200, 255), -1)
            cv2.rectangle(p, (70, yb), (310, yb + 11), (90, 90, 90), 1)
        ys = min(alto - 6, y0 + 34 + 4 * 17 + 60)
        for i, e in enumerate(A["espectro"]):
            x = 10 + i * 9
            cv2.rectangle(p, (x, ys), (x + 7, ys - int(55 * min(1.0, e))), (255, 120, 60), -1)
        return p

    def _ventana_ssh(self):
        try:
            v = self._imagen_camara(560)
            alto = max(v.shape[0], 560)
            if v.shape[0] < alto:
                v = cv2.copyMakeBorder(v, 0, alto - v.shape[0], 0, 0, cv2.BORDER_CONSTANT)
            todo = np.hstack([v, self._panel(alto)])
            if not self.ventana_lista:
                cv2.namedWindow(VENTANA, cv2.WINDOW_NORMAL | cv2.WINDOW_GUI_NORMAL)
                cv2.resizeWindow(VENTANA, todo.shape[1], todo.shape[0])
                self.ventana_lista = True
            cv2.imshow(VENTANA, todo)
        except Exception as e:
            log("Ventana SSH desactivada (%s)" % e)
            self.ver = False

    def cerrar(self):
        try:
            FI.guardar(self.cfg)
            log("Ajustes guardados en filtros.json")
        except Exception as e:
            log("No pude guardar filtros.json (%s)" % e)
        E.App.cerrar(self)
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass


def main2():
    ap = argparse.ArgumentParser(description="Estacion (version de pruebas 2)")
    ap.add_argument("--camara", default="0")
    ap.add_argument("--salida", default="auto", choices=["auto", "fb", "x11"])
    ap.add_argument("--alto", type=int, default=E.ALTO_DIBUJO)
    ap.add_argument("--manos", default="auto", choices=["auto", "posenet", "mediapipe", "ninguno"])
    ap.add_argument("--relleno", type=int, default=None)
    ap.add_argument("--ahorro", action="store_true")
    ap.add_argument("--res", default=E.RES_CAM)
    ap.add_argument("--mic", default="auto")
    ap.add_argument("--sin-audio", dest="sin_audio", action="store_true")
    ap.add_argument("--salida-audio", dest="salida_audio", default="auto")
    ap.add_argument("--sin-sonido", dest="sin_sonido", action="store_true")
    ap.add_argument("--modo", default="", help="abrir directo: " + ", ".join(sorted(E.ALIAS)))
    ap.add_argument("--x11", action="store_true")
    # nuevas
    ap.add_argument("--sin-ver", dest="sin_ver", action="store_true", help="sin ventana por SSH")
    ap.add_argument("--puno-menu", dest="puno_menu", action="store_true",
                    help="tambien regresar al menu con el puno cerrado 2 s")
    ap.add_argument("--menu-der", dest="menu_der", action="store_true",
                    help="boton MENU en la esquina superior derecha")
    ap.add_argument("--corte-audio", dest="corte_audio", type=float, default=4000,
                    help="Hz: el sonido arriba de esto se ignora (chillido del proyector)")
    ap.add_argument("--ganancia-audio", dest="ganancia_audio", type=float, default=1.0,
                    help="multiplica el sonido del mic (si esta muy bajito: 2, 3, 5)")
    args = ap.parse_args()
    if args.ahorro:
        args.alto = min(args.alto, 360)
        if args.res == E.RES_CAM:
            args.res = "640x480"
        log("Modo ahorro: dibujo a %d px, camara %s, manos 10 veces/s" % (args.alto, args.res))
    Audio2.CORTE, Audio2.GANANCIA = args.corte_audio, args.ganancia_audio
    R.Audio = Audio2
    log("Audio: pasa-bajas %d Hz, ganancia %.1f" % (args.corte_audio, args.ganancia_audio))
    log("MENU: solo dedo indice%s" % (" o puno 2 s" if args.puno_menu else ""))
    app = App2(args)
    try:
        app.correr()
    except KeyboardInterrupt:
        log("Saliendo")
    finally:
        app.cerrar()


if __name__ == "__main__":
    main2()
