#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hdmi_manos.py - Dibuja en la salida HDMI de la Raspberry (sin escritorio), se calibra solo
con 4 marcadores proyectados en las esquinas y luego proyecta las landmarks de la mano encima de ella.

  python3 hdmi_manos.py               -> calibra (si no hay calibracion) y muestra manos
  python3 hdmi_manos.py --recalibrar  -> fuerza calibracion
  python3 hdmi_manos.py --ver         -> ademas abre una ventana (por MobaXterm) con lo que ve la camara
Salir: Ctrl+C

Funciona en modo consola escribiendo directo a /dev/fb0 (el usuario debe estar en el grupo video).
Si hay escritorio (DISPLAY=:0) tambien sirve: usa --x11.
"""
from __future__ import print_function

import argparse
import json
import os
import time

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ARCHIVO_CALIB = os.path.join(BASE, "calib_hdmi.json")
CONEX = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10), (10, 11), (11, 12),
         (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]
PUNTAS = (4, 8, 12, 16, 20)
COL_PUNTAS = [(255, 80, 255), (0, 230, 255), (0, 255, 160), (255, 200, 0), (120, 120, 255)]


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a, flush=True)


# ------------------------------------------------------------------ salida HDMI
def tam_render(W, H, alto):
    """Tamano en que se dibuja: 'alto' pixeles de alto con la misma proporcion que la pantalla real."""
    if not alto or alto >= H:
        return W, H
    return int(round(alto * W / float(H) / 8.0)) * 8, int(alto)


class Framebuffer(object):
    """Escribe directo a /dev/fb0 (modo consola, sin escritorio). Raspberry y Jetson.
    alto: se dibuja a esa altura y se escala a la resolucion real (None = dibujar a resolucion real)."""

    def __init__(self, dev="/dev/fb0", alto=None):
        s = "/sys/class/graphics/" + os.path.basename(dev)
        self.f = open(dev, "r+b", buffering=0)
        self.W, self.H = [int(v) for v in open(s + "/virtual_size").read().strip().split(",")]
        self.bpp = int(open(s + "/bits_per_pixel").read().strip())
        self.stride = int(open(s + "/stride").read().strip())
        self.offset, self.rgba, filas = 0, False, self.H
        try:  # resolucion visible real y orden de colores (la Jetson puede tener virtual_size doble)
            import fcntl
            import struct
            buf = fcntl.ioctl(self.f.fileno(), 0x4600, b"\0" * 160)   # FBIOGET_VSCREENINFO
            v = struct.unpack_from("8I12I", buf)
            xres, yres, yvirt, xoff, yoff, bpp, rojo = v[0], v[1], v[3], v[4], v[5], v[6], v[8]
            if xres > 0 and yres > 0:
                self.W, self.H, self.bpp = xres, yres, bpp
                self.offset = yoff * self.stride + xoff * (bpp // 8)
                self.rgba = (bpp == 32 and rojo == 0)
                filas = max(yvirt, yoff + yres)
        except Exception:
            pass
        self._mapear(filas)
        self.t_despertar = 0.0
        self.despertar()
        self.w, self.h = tam_render(self.W, self.H, alto)
        log("HDMI (framebuffer): %dx%d, %d bits%s" % (self.W, self.H, self.bpp,
                                                     "" if (self.w, self.h) == (self.W, self.H)
                                                     else "; dibujo a %dx%d" % (self.w, self.h)))

    def despertar(self):
        """Prende la salida HDMI si la consola la apago por inactividad (FBIOBLANK = sin apagar).
        Sin esto, en modo consola la pantalla se va a negro / "sin senal" a los ~10 minutos."""
        self.t_despertar = time.time()
        try:
            import fcntl
            fcntl.ioctl(self.f.fileno(), 0x4611, 0)   # FBIOBLANK, FB_BLANK_UNBLANK
        except Exception:
            pass

    def _mapear(self, filas):
        """Memoria del framebuffer como arreglo de numpy (mas rapido que write); si no se puede, se usa write."""
        self.vista = None
        try:
            import mmap
            self.mm = mmap.mmap(self.f.fileno(), self.stride * filas, mmap.MAP_SHARED,
                                mmap.PROT_READ | mmap.PROT_WRITE)
            self.vista = np.ndarray((self.H, self.stride), np.uint8, buffer=self.mm, offset=self.offset)
        except Exception:
            self.vista = None

    def _pixeles(self, img):
        """Imagen BGR (cualquier tamano) -> bytes del formato del framebuffer, H x (W * bytes)."""
        if self.bpp == 16:
            if img.shape[1] != self.W or img.shape[0] != self.H:
                img = cv2.resize(img, (self.W, self.H), interpolation=cv2.INTER_LINEAR)
            b = (img[:, :, 0] >> 3).astype(np.uint16)
            g = (img[:, :, 1] >> 2).astype(np.uint16)
            r = (img[:, :, 2] >> 3).astype(np.uint16)
            px = (r << 11) | (g << 5) | b
            return px.view(np.uint8).reshape(self.H, self.W * 2)
        # 32 bits: se convierte a 4 canales en chico y despues se escala (menos trabajo)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGBA if self.rgba else cv2.COLOR_BGR2BGRA)
        if img.shape[1] != self.W or img.shape[0] != self.H:
            img = cv2.resize(img, (self.W, self.H), interpolation=cv2.INTER_LINEAR)
        return img.reshape(self.H, self.W * 4)

    def mostrar(self, img):
        if time.time() - self.t_despertar > 10:
            self.despertar()
        fila = self._pixeles(img)
        if self.vista is not None:
            self.vista[:, :fila.shape[1]] = fila
            return
        if fila.shape[1] < self.stride:
            fila = np.hstack([fila, np.zeros((self.H, self.stride - fila.shape[1]), np.uint8)])
        self.f.seek(self.offset)
        self.f.write(np.ascontiguousarray(fila).tobytes())

    def cerrar(self):
        self.mostrar(np.zeros((self.h, self.w, 3), np.uint8))
        self.vista = None
        try:
            self.mm.close()
        except Exception:
            pass
        self.f.close()


def tam_pantalla_x11():
    """Resolucion de la pantalla principal del escritorio (xrandr)."""
    import re
    import subprocess
    try:
        sal = subprocess.check_output(["xrandr", "--current"], stderr=subprocess.DEVNULL).decode("utf-8", "ignore")
    except Exception:
        return None
    conectadas = re.findall(r"^\S+ connected( primary)? (\d+)x(\d+)\+\d+\+\d+", sal, re.M)
    for prim, w, h in conectadas:
        if prim:
            return int(w), int(h)
    if conectadas:
        return int(conectadas[0][1]), int(conectadas[0][2])
    m = re.search(r"current (\d+) x (\d+)", sal)
    return (int(m.group(1)), int(m.group(2))) if m else None


class VentanaX11(object):
    """Ventana a pantalla completa en el escritorio (DISPLAY :0). Jetson con escritorio, o --x11.
    Si ancho=0 se usa la proporcion de la pantalla real con 'alto' pixeles de alto."""

    def __init__(self, ancho=0, alto=480):
        os.environ["DISPLAY"] = ":0"   # siempre la pantalla del HDMI (aunque se lance por SSH con X11)
        if not os.environ.get("XAUTHORITY"):
            for ruta in ("/run/user/%d/gdm/Xauthority" % os.getuid(), os.path.expanduser("~/.Xauthority")):
                if os.path.exists(ruta):
                    os.environ["XAUTHORITY"] = ruta
                    break
        self.W, self.H = tam_pantalla_x11() or (ancho or 640, alto)
        if ancho:
            self.w, self.h = ancho, alto
        else:
            self.w, self.h = tam_render(self.W, self.H, alto)
        cv2.namedWindow("HDMI", cv2.WINDOW_NORMAL)
        cv2.setWindowProperty("HDMI", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        log("HDMI (escritorio %s): pantalla %dx%d, dibujo a %dx%d" % (os.environ["DISPLAY"], self.W, self.H,
                                                                     self.w, self.h))

    def mostrar(self, img):
        if img.shape[1] != self.W or img.shape[0] != self.H:
            img = cv2.resize(img, (self.W, self.H), interpolation=cv2.INTER_LINEAR)
        cv2.imshow("HDMI", img)
        cv2.waitKey(1)

    def cerrar(self):
        cv2.destroyWindow("HDMI")


def abrir_salida(modo="auto", alto=480):
    """auto: Raspberry -> framebuffer; Jetson/PC -> ventana a pantalla completa si hay escritorio, si no framebuffer."""
    import plataforma as P
    if modo == "auto":
        if P.tipo() == "raspberry" or not P.hay_escritorio():
            modo = "fb" if os.path.exists("/dev/fb0") else "x11"
        else:
            modo = "x11"
    return VentanaX11(0, alto) if modo == "x11" else Framebuffer(alto=alto)


def cargar_calib(w, h, cam_wh=None):
    """Calibracion guardada para una salida de w x h, ajustada al tamano de camara actual. None si no sirve."""
    if not os.path.exists(ARCHIVO_CALIB):
        return None, {}
    c = json.load(open(ARCHIVO_CALIB))
    if c.get("hdmi") != [w, h]:
        return None, c
    H = np.array(c["H"])
    cw0, ch0 = c.get("cam", [1280, 720])   # las calibraciones viejas eran a 1280x720
    if cam_wh and (int(cam_wh[0]), int(cam_wh[1])) != (cw0, ch0):
        H = H.dot(np.diag([cw0 / float(cam_wh[0]), ch0 / float(cam_wh[1]), 1.0]))
    return H, c


# ------------------------------------------------------------------ marcadores
def _params_aruco(a, ajustados):
    p = a.DetectorParameters() if hasattr(a, "DetectorParameters") and not hasattr(a, "DetectorParameters_create") \
        else a.DetectorParameters_create()
    if ajustados:
        # para marcadores grandes, borrosos o sobre tela arrugada (proyector + webcam barata)
        p.adaptiveThreshWinSizeMin = 3
        p.adaptiveThreshWinSizeMax = 103
        p.adaptiveThreshWinSizeStep = 10
        p.adaptiveThreshConstant = 7
        p.polygonalApproxAccuracyRate = 0.08
        p.errorCorrectionRate = 1.0
    return p


def aruco():
    """detectar(gris) -> (esquinas, ids, rechazados) como cv2.aruco.detectMarkers.
    Prueba varios ajustes y escalas y junta lo que encuentre (mas robusto con proyector y webcam)."""
    a = cv2.aruco
    d = a.getPredefinedDictionary(0) if hasattr(a, "getPredefinedDictionary") else a.Dictionary_get(0)
    if hasattr(a, "ArucoDetector"):
        dets = [a.ArucoDetector(d, _params_aruco(a, False)), a.ArucoDetector(d, _params_aruco(a, True))]
        uno = lambda g, k: dets[k].detectMarkers(g)
    else:
        ps = [_params_aruco(a, False), _params_aruco(a, True)]
        uno = lambda g, k: a.detectMarkers(g, d, parameters=ps[k])
    pasadas = [(0, 1.0), (1, 0.75), (1, 0.5)]   # (ajuste, escala)

    def detectar(g):
        vistos, esq, rech = {}, [], []
        for k, esc in pasadas:
            img = g if esc == 1.0 else cv2.resize(g, None, fx=esc, fy=esc, interpolation=cv2.INTER_AREA)
            c, ids, r = uno(img, k)
            if ids is None:
                continue
            for cc, i in zip(c, ids.flatten()):
                i = int(i)
                if i not in vistos:
                    vistos[i] = len(esq)
                    esq.append((np.asarray(cc, np.float32) / esc).reshape(1, 4, 2))
        if not esq:
            return [], None, rech
        ids = np.array([[i] for i, _ in sorted(vistos.items(), key=lambda t: t[1])], np.int32)
        return esq, ids, rech

    gen = (lambda i, n: a.generateImageMarker(d, i, n)) if hasattr(a, "generateImageMarker") else \
        (lambda i, n: a.drawMarker(d, i, n))
    return detectar, gen


def lienzo_marcadores(w, h, gen, fondo_blanco=True, escala=0.30, margen=None):
    """4 marcadores (IDs 0-3) en las esquinas. Regresa imagen y esquinas de cada marcador en pixeles HDMI.
    margen: separacion de la orilla como fraccion del alto (None = pegados a la orilla). Si la camara no
    alcanza a ver las orillas de la proyeccion, marcadores mas chicos y hacia adentro si se ven."""
    img = np.full((h, w, 3), 255 if fondo_blanco else 0, np.uint8)
    lado = int(min(w, h) * escala)
    m = max(6, int(lado * 0.18)) if margen is None else max(6, int(min(w, h) * margen))
    pos = {0: (m, m), 1: (w - m - lado, m), 2: (w - m - lado, h - m - lado), 3: (m, h - m - lado)}
    esquinas = {}
    for i, (x, y) in pos.items():
        if not fondo_blanco:  # borde blanco para que se puedan detectar sobre fondo negro
            q = int(lado * 0.2)
            img[y - q:y + lado + q, x - q:x + lado + q] = 255
        img[y:y + lado, x:x + lado] = cv2.cvtColor(gen(i, lado), cv2.COLOR_GRAY2BGR)
        esquinas[i] = np.float32([[x, y], [x + lado, y], [x + lado, y + lado], [x, y + lado]]) - 0.5
    return img, esquinas


def texto(img, t, y, esc=0.6, col=(255, 255, 255), centro=True):
    (tw, th), _ = cv2.getTextSize(t, cv2.FONT_HERSHEY_SIMPLEX, esc, 2)
    x = (img.shape[1] - tw) // 2 if centro else 10
    cv2.putText(img, t, (x, y), cv2.FONT_HERSHEY_SIMPLEX, esc, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(img, t, (x, y), cv2.FONT_HERSHEY_SIMPLEX, esc, col, 2, cv2.LINE_AA)


def calibrar(cam, salida, detectar, gen, ver=False, tope=40.0, escala=0.30, margen=None):
    w, h = salida.w, salida.h
    img, esq_hdmi = lienzo_marcadores(w, h, gen, escala=escala, margen=margen)
    texto(img, "Calibrando... no tape las esquinas", h // 2, 0.6, (0, 0, 200))
    salida.mostrar(img)
    time.sleep(1.0)
    acum, t0, t_log, tam = {}, time.time(), 0, None
    while time.time() - t0 < tope:
        ok, f = cam.read()
        if not ok:
            time.sleep(0.01)
            continue
        tam = [int(f.shape[1]), int(f.shape[0])]
        esq, ids, _ = detectar(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
        vistos = []
        if ids is not None:
            for c, i in zip(esq, ids.flatten()):
                i = int(i)
                if i in esq_hdmi:
                    acum.setdefault(i, []).append(c.reshape(4, 2))
                    vistos.append(i)
        if ver:
            v = f.copy()
            if ids is not None:
                cv2.aruco.drawDetectedMarkers(v, esq, ids)
            cv2.imshow("Camara", cv2.resize(v, (640, 360)))
            cv2.waitKey(1)
        if time.time() - t_log > 1.0:
            t_log = time.time()
            log("Marcadores proyectados vistos ahora:", sorted(vistos) or "ninguno")
        if all(len(acum.get(i, [])) >= 8 for i in esq_hdmi):
            break
        if time.time() - t0 > 8 and sum(len(acum.get(i, [])) >= 8 for i in esq_hdmi) >= 3:
            break  # a los 8 s, con 3 esquinas solidas basta
    usados = [i for i in sorted(esq_hdmi) if len(acum.get(i, [])) >= 3]
    faltan = [i for i in esq_hdmi if i not in usados]
    if len(usados) < 3:
        log("Solo se vieron %s. Se necesitan al menos 3 esquinas: revisa que la camara vea la proyeccion." % usados)
        return None
    if faltan:
        log("Aviso: no se vio la esquina %s; calibro con %d esquinas (zona cercana a esa esquina menos precisa)."
            % (faltan, len(usados)))
    cam_pts = np.concatenate([np.median(acum[i][-8:], axis=0) for i in usados]).astype(np.float32)
    hdmi_pts = np.concatenate([esq_hdmi[i] for i in usados]).astype(np.float32)
    H, _ = cv2.findHomography(cam_pts, hdmi_pts, 0)
    err = float(np.mean(np.linalg.norm(cv2.perspectiveTransform(cam_pts[:, None], H)[:, 0] - hdmi_pts, axis=1)))
    log("Calibracion lista. Error medio: %.2f px HDMI" % err)
    with open(ARCHIVO_CALIB, "w") as fh:
        json.dump({"H": H.tolist(), "hdmi": [w, h], "cam": tam, "error_px": err,
                   "fecha": time.strftime("%Y-%m-%d %H:%M")}, fh)
    ok_img = np.zeros((h, w, 3), np.uint8)
    for i in usados:
        c = esq_hdmi[i].mean(axis=0)
        cv2.circle(ok_img, (int(c[0]), int(c[1])), 30, (0, 255, 0), 3)
    texto(ok_img, "Calibracion OK (%.1f px)" % err, h // 2, 0.8, (0, 255, 0))
    salida.mostrar(ok_img)
    time.sleep(1.5)
    return H


# ------------------------------------------------------------------ manos
def dibujar_mano(img, p, grosor):
    vis = [0 <= x < img.shape[1] + 200 and 0 <= y < img.shape[0] + 200 for x, y in p]
    for a, b in CONEX:
        cv2.line(img, tuple(p[a]), tuple(p[b]), (255, 60, 220), grosor, cv2.LINE_AA)
    for k, q in enumerate(p):
        if k in PUNTAS:
            cv2.circle(img, tuple(q), grosor * 3, COL_PUNTAS[PUNTAS.index(k)], -1, cv2.LINE_AA)
        else:
            cv2.circle(img, tuple(q), grosor + 1, (255, 255, 120), -1, cv2.LINE_AA)
    return vis


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--recalibrar", action="store_true")
    ap.add_argument("--ver", action="store_true", help="ventana con la camara (por MobaXterm)")
    ap.add_argument("--x11", action="store_true", help="usar escritorio DISPLAY=:0 en vez de /dev/fb0")
    ap.add_argument("--camara", default="0", help="0, 1... (USB) o csi (Jetson)")
    ap.add_argument("--sin-marcadores", dest="sin_marcadores", action="store_true",
                    help="no dejar los marcadores en las esquinas mientras se ven las manos")
    args = ap.parse_args()

    detectar, gen = aruco()
    import plataforma as P
    salida = abrir_salida("x11" if args.x11 else "auto")
    cam = P.Camara(args.camara, "1280x720")
    ok, f = cam.read()
    if not ok:
        raise SystemExit("La camara %d no entrega imagen" % args.camara)
    log("Camara: %dx%d" % (f.shape[1], f.shape[0]))

    H = None
    if not args.recalibrar:
        H, c = cargar_calib(salida.w, salida.h, (f.shape[1], f.shape[0]))
        if H is not None:
            log("Usando calibracion guardada (%s, error %.1f px)" % (c.get("fecha"), c.get("error_px", 0)))
    while H is None:
        H = calibrar(cam, salida, detectar, gen, args.ver)
        if H is None:
            img = np.zeros((salida.h, salida.w, 3), np.uint8)
            texto(img, "No vi las 4 esquinas. Reintento en 3 s", salida.h // 2, 0.6, (0, 0, 255))
            salida.mostrar(img)
            time.sleep(3)

    import mediapipe as mp
    manos = mp.solutions.hands.Hands(static_image_mode=False, max_num_hands=2, model_complexity=0,
                                     min_detection_confidence=0.5, min_tracking_confidence=0.5)
    log("MediaPipe listo. Pon la mano sobre la mesa. Ctrl+C para salir.")
    base, _ = lienzo_marcadores(salida.w, salida.h, gen, fondo_blanco=False, escala=0.16)
    if args.sin_marcadores:
        base = np.zeros_like(base)
    grosor = max(2, salida.w // 220)
    t_log, n, n_manos = time.time(), 0, 0
    try:
        while True:
            ok, f = cam.read()
            if not ok:
                continue
            ch, cw = f.shape[:2]
            res = manos.process(cv2.cvtColor(cv2.resize(f, (640, 360)), cv2.COLOR_BGR2RGB))
            img = base.copy()
            lista = res.multi_hand_landmarks or []
            n_manos = len(lista)
            for lm in lista:
                cam_pts = np.float32([[p.x * cw, p.y * ch] for p in lm.landmark])
                hp = cv2.perspectiveTransform(cam_pts[:, None], H)[:, 0].astype(np.int32)
                dibujar_mano(img, hp, grosor)
            if not lista:
                texto(img, "Pon la mano sobre la mesa", salida.h // 2, 0.6, (120, 120, 120))
            salida.mostrar(img)
            if args.ver:
                v = f.copy()
                for lm in lista:
                    for p in lm.landmark:
                        cv2.circle(v, (int(p.x * cw), int(p.y * ch)), 5, (0, 255, 0), -1)
                cv2.imshow("Camara", cv2.resize(v, (640, 360)))
                cv2.waitKey(1)
            n += 1
            if time.time() - t_log > 2:
                log("%.1f FPS | manos: %d" % (n / (time.time() - t_log), n_manos))
                t_log, n = time.time(), 0
    except KeyboardInterrupt:
        log("Saliendo")
    finally:
        salida.cerrar()
        cam.release()


if __name__ == "__main__":
    main()
