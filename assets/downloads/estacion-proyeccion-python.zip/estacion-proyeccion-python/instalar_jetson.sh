#!/bin/bash
# Instalador de la ESTACION (calibracion + menu + modos: piano tiles, rave, cortina, flor...) en la Jetson Nano.
# Probado para JetPack 4.6 (Ubuntu 18.04, Python 3.6). Tambien sirve en JetPack 5/6.
#
#   bash instalar_jetson.sh            -> instala y deja que arranque sola con el escritorio (recomendado)
#   bash instalar_jetson.sh --consola  -> arranca SIN escritorio, directo al HDMI (framebuffer, mas ligero)
#
# Te pedira tu contrasena para los pasos con sudo. Deja la Jetson conectada a la corriente:
# si falta jetson-inference, compilarlo tarda de 30 a 90 minutos.
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 1
USUARIO="$(whoami)"
MODO="escritorio"
[ "$1" = "--consola" ] && MODO="consola"
PIP="python3 -m pip install --user"
ok()  { echo "  [OK] $*"; }
mal() { echo "  [!!] $*"; }

echo "=== Estacion para Jetson | carpeta: $DIR | usuario: $USUARIO | arranque: $MODO"
if [ ! -f /etc/nv_tegra_release ]; then
  mal "Esto no parece una Jetson (no existe /etc/nv_tegra_release). En la Raspberry usa instalar_pi.sh"
  exit 1
fi
head -n 1 /etc/nv_tegra_release

echo "=== 1/7 Paquetes del sistema"
sudo apt-get update
sudo apt-get install -y python3-pip python3-dev alsa-utils v4l-utils unclutter x11-xserver-utils \
     git cmake libpython3-dev

echo "=== 2/7 numpy y OpenCV con ArUco (los marcadores de calibracion)"
grep -q OPENBLAS_CORETYPE ~/.bashrc || echo "export OPENBLAS_CORETYPE=ARMV8   # numpy en Jetson Nano" >> ~/.bashrc
export OPENBLAS_CORETYPE=ARMV8
PYV=$(python3 -c "import sys; print('%d%d' % sys.version_info[:2])")
if [ "$PYV" -le 36 ]; then
  $PIP --upgrade "pip<22"
  $PIP "numpy==1.19.4"            # 1.19.5 truena en la Nano ("Illegal instruction")
  CV="opencv-contrib-python==4.5.5.64"
else
  $PIP --upgrade pip
  CV="opencv-contrib-python<4.9"
fi
if python3 -c "import cv2; cv2.aruco.DICT_4X4_50" 2>/dev/null; then
  ok "OpenCV ya trae ArUco: $(python3 -c 'import cv2; print(cv2.__version__)')"
else
  $PIP "$CV" && ok "OpenCV con ArUco instalado" || mal "No se pudo instalar $CV"
fi

echo "=== 3/7 Manos en la GPU (jetson-inference, poseNet resnet18-hand)"
if python3 -c "from jetson_inference import poseNet" 2>/dev/null || python3 -c "import jetson.inference" 2>/dev/null; then
  ok "jetson-inference ya esta instalado"
else
  echo "  No esta jetson-inference. Lo compilo ahora (30-90 min)..."
  bash "$DIR/instalar_vision.sh" || mal "Fallo la instalacion de jetson-inference (ver mensajes arriba)"
fi
echo "  Preparando el modelo de manos (la primera vez descarga y optimiza con TensorRT: unos minutos)..."
if python3 -c "
try:
    from jetson_inference import poseNet
except ImportError:
    from jetson.inference import poseNet
poseNet('resnet18-hand')
print('modelo de manos listo')
"; then
  ok "poseNet resnet18-hand listo"
else
  mal "No se pudo cargar resnet18-hand. Descargalo con:  cd ~/jetson-inference/tools && ./download-models.sh"
  mal "   (marca 'Pose-ResNet18-Hand'). Mientras, la estacion intentara usar MediaPipe si lo tienes."
fi

echo "=== 4/7 Permisos (camara, HDMI y audio)"
sudo usermod -aG video,audio "$USUARIO" && ok "usuario en grupos video y audio"

echo "=== 5/7 Maxima potencia"
sudo nvpmodel -m 0 && ok "modo MAXN (10 W). Usa fuente de 5 V 4 A por el conector redondo (jumper J48 puesto)"

echo "=== 6/7 Arranque automatico"
chmod +x "$DIR/iniciar_estacion.sh"
# que no arranquen dos programas peleandose la camara
[ -f ~/.config/autostart/asesor.desktop ] && mv ~/.config/autostart/asesor.desktop ~/.config/autostart/asesor.desktop.desactivado \
  && ok "desactive el arranque del asesor viejo (panel.py)"
crontab -l 2>/dev/null | grep -v iniciar_estacion | crontab -
if [ "$MODO" = "escritorio" ]; then
  mkdir -p ~/.config/autostart
  cat > ~/.config/autostart/estacion.desktop <<EOF
[Desktop Entry]
Type=Application
Name=Estacion de proyeccion
Exec=$DIR/iniciar_estacion.sh
X-GNOME-Autostart-enabled=true
EOF
  ok "arrancara al entrar al escritorio (ventana a pantalla completa en el HDMI)"
  if [ -f /etc/gdm3/custom.conf ]; then
    sudo sed -i "s/^#\?\s*AutomaticLoginEnable.*/AutomaticLoginEnable=true/; s/^#\?\s*AutomaticLogin\s*=.*/AutomaticLogin=$USUARIO/" /etc/gdm3/custom.conf
    ok "inicio de sesion automatico activado"
  else
    mal "No encontre gdm3: activa 'Inicio de sesion automatico' en Configuracion > Usuarios"
  fi
  sudo systemctl set-default graphical.target >/dev/null 2>&1
else
  rm -f ~/.config/autostart/estacion.desktop
  (crontab -l 2>/dev/null; echo "@reboot $DIR/iniciar_estacion.sh") | crontab -
  sudo systemctl set-default multi-user.target && ok "la Jetson arrancara sin escritorio; la estacion dibuja directo al HDMI"
  echo "  (para regresar al escritorio:  sudo systemctl set-default graphical.target && sudo reboot)"
fi

echo "=== 7/7 Revision"
OPENBLAS_CORETYPE=ARMV8 python3 - <<'EOF'
def prueba(nombre, codigo):
    try:
        exec(codigo, {})
        print("  [OK] " + nombre)
    except Exception as e:
        print("  [!!] %s: %s" % (nombre, e))
prueba("numpy", "import numpy; print('       numpy', numpy.__version__)")
prueba("OpenCV + ArUco", "import cv2; cv2.aruco.DICT_4X4_50; print('       cv2', cv2.__version__)")
prueba("jetson-inference (manos GPU)", "\ntry:\n    import jetson_inference\nexcept ImportError:\n    import jetson.inference")
prueba("plataforma", "import sys; sys.path.insert(0, '.'); import plataforma as P; print('       plataforma:', P.tipo())")
EOF
echo "  Camaras:"; ls /dev/video* 2>/dev/null || mal "no veo camaras USB (si usas la CSI, pon --camara csi en estacion_args.txt)"
echo "  Microfonos:"; arecord -l 2>/dev/null | grep -i "^card" | grep -vi tegra || mal "no veo microfono USB"

echo
echo "=== Listo. Para probar ahora mismo (sin reiniciar):"
echo "   cd $DIR && python3 estacion.py"
echo "   (camara CSI:  python3 estacion.py --camara csi    | por SSH con escritorio abierto funciona igual)"
echo "Despues reinicia (sudo reboot) y arrancara sola: calibra con las 4 esquinas y muestra el menu."
echo "Cierra sesion y vuelve a entrar (o reinicia) para que apliquen los permisos de video/audio."
