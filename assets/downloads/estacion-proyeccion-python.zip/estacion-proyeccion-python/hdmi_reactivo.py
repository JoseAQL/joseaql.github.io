#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hdmi_reactivo.py - Video reactivo estilo TouchDesigner en la salida HDMI de la Raspberry,
controlado con gestos de las manos. Usa la calibracion de hdmi_manos.py (calib_hdmi.json).

  python3 hdmi_reactivo.py               -> usa la calibracion guardada (o calibra si no hay)
  python3 hdmi_reactivo.py --recalibrar  -> calibra con los 4 marcadores proyectados
  python3 hdmi_reactivo.py --efecto ondas

EFECTOS de manos:  particulas, estelas, ondas, termico, caleido
EFECTOS de musica: espectro, circular, osciloscopio, lissajous, tunel, anillos, instancias,
                   estrobo, lineas, hiperespacio, metabolas   (ver efectos_audio.py)
GESTOS:
  Apuntar 1 s        -> salta entre el grupo de manos y el grupo de musica
  Palma abierta 1 s  -> siguiente efecto
  Puno 1 s           -> efecto anterior
  Pulgar arriba      -> cambia la paleta de colores
  Pellizco           -> explosion / onda en ese punto
  Dos manos          -> la distancia entre los indices controla la intensidad
AUDIO (adaptador USB): el volumen sube la intensidad, cada golpe de graves lanza una explosion u onda.
  --mic plughw:1,0   -> elegir microfono (por defecto busca solo uno USB)   --sin-audio -> apagarlo
Salir: Ctrl+C
"""
from __future__ import print_function

import argparse
import json
import math
import os
import re
import subprocess
import threading
import time

import cv2
import numpy as np

import efectos_audio as EA
import hdmi_manos as HM
import plataforma as P

log = HM.log
EFECTOS_MANOS = ["particulas", "estelas", "ondas", "termico", "caleido"]
EFECTOS = EFECTOS_MANOS + EA.EFECTOS_AUDIO
NOMBRES = {"particulas": "PARTICULAS", "estelas": "ESTELAS DE NEON", "ondas": "ONDAS",
           "termico": "TERMICO", "caleido": "CALEIDOSCOPIO"}
NOMBRES.update(EA.NOMBRES_AUDIO)
PALETAS = [("TURBO", "COLORMAP_TURBO"), ("FUEGO", "COLORMAP_HOT"), ("OCEANO", "COLORMAP_OCEAN"),
           ("ROSA", "COLORMAP_PINK"), ("MAGMA", "COLORMAP_MAGMA"), ("JET", "COLORMAP_JET")]
PUNTAS = (4, 8, 12, 16, 20)


# ------------------------------------------------------------------ gestos
def _d(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


gesto = P.gesto   # tolera puntos que no se vieron (poseNet de la Jetson)


class Estable(object):
    """Un gesto cuenta si se mantiene 0.2 s; da 'nuevo' al iniciar y 'sostenido' tras N segundos (una vez)."""

    def __init__(self):
        self.actual, self.cand, self.t_cand, self.t_ini, self.usado = "", "", 0, 0, set()

    def actualizar(self, g, t):
        nuevo = False
        if g != self.cand:
            self.cand, self.t_cand = g, t
        if self.cand != self.actual and t - self.t_cand >= 0.2:
            self.actual, self.t_ini, nuevo, self.usado = self.cand, t, True, set()
        return self.actual, t - self.t_ini, nuevo

    def una_vez(self, clave):
        if clave in self.usado:
            return False
        self.usado.add(clave)
        return True


# ------------------------------------------------------------------ audio en hilo aparte
def buscar_mic():
    """Primer dispositivo de captura USB segun 'arecord -l'."""
    try:
        sal = subprocess.check_output(["arecord", "-l"], stderr=subprocess.STDOUT).decode("utf-8", "ignore")
    except Exception as e:
        log("Audio: no pude listar microfonos (%s)" % e)
        return None
    tarjetas = [t for t in re.findall(r"card (\d+): ([^\n]*?), device (\d+)", sal) if P.mic_valido(t[1])]
    for c, nombre, d in tarjetas:
        if "usb" in nombre.lower():
            return "plughw:%s,%s" % (c, d)
    if tarjetas:
        c, nombre, d = tarjetas[0]
        return "plughw:%s,%s" % (c, d)
    return None


class Audio(object):
    """Lee el microfono con arecord y calcula nivel, graves, medios, agudos y golpes de graves (0..1)."""
    SR, N = 16000, 1024

    def __init__(self, dispositivo, corte=4000):
        self.dev = dispositivo
        self.corte = float(min(max(corte, 1000), self.SR / 2 - 100))   # Hz: arriba de esto se ignora
        self.rms = 0.0
        self.nivel = self.graves = self.medios = self.agudos = 0.0
        self.golpes = 0
        self.cajas = 0
        self.espectro = np.zeros(32, np.float32)
        self.onda = np.zeros(512, np.float32)
        self.ok = False
        self.lock = threading.Lock()
        cmd = ["arecord", "-q", "-D", dispositivo, "-f", "S16_LE", "-r", str(self.SR), "-c", "1", "-t", "raw"]
        try:
            self.p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as e:
            log("Audio: no se pudo abrir arecord (%s)" % e)
            return
        self.ok = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        f = np.fft.rfftfreq(self.N, 1.0 / self.SR)
        corte = self.corte
        # pasa-bajas: el chillido agudo del proyector (ventilador, fuente) no cuenta como musica
        paso = ((f >= 30) & (f <= corte)).astype(np.float32)
        medio = min(2000.0, corte * 0.5)
        bandas = [(f >= 30) & (f < 180), (f >= 180) & (f < medio), (f >= medio) & (f < corte)]
        bordes = np.geomspace(40, corte * 0.95, 33)
        idx = [np.where((f >= bordes[i]) & (f < bordes[i + 1]))[0] for i in range(32)]
        idx = [ix if len(ix) else np.array([int(np.argmin(np.abs(f - bordes[i])))]) for i, ix in enumerate(idx)]
        caja_banda = (f >= 1500) & (f < min(5000.0, corte))
        piso_e, max_e = None, np.full(32, 1e-3)
        prom_caja, t_caja = 0.0, -1.0
        maximos = np.array([1e-3, 1e-3, 1e-3, 1e-3])
        piso = None                      # ruido de fondo constante (ventiladores, zumbido)
        prom_graves, t_golpe, t_audio = 0.0, -1.0, 0.0
        ventana = np.hanning(self.N)
        while True:
            datos = self.p.stdout.read(self.N * 2)
            if not datos or len(datos) < self.N * 2:
                err = self.p.stderr.read().decode("utf-8", "ignore").strip()
                log("Audio: el microfono dejo de enviar datos. %s" % err[:120])
                self.ok = False
                return
            t_audio += self.N / float(self.SR)   # tiempo del audio (no del reloj)
            x = np.frombuffer(datos, np.int16).astype(np.float32) / 32768.0
            x = np.fft.irfft(np.fft.rfft(x) * paso, self.N).astype(np.float32)   # sin agudos ni zumbido grave
            rms = float(np.sqrt(np.mean(x ** 2)))
            esp = np.abs(np.fft.rfft(x * ventana))
            vals = np.array([rms] + [float(esp[b].mean()) for b in bandas])
            if piso is None:
                piso = vals.copy()
            piso = np.minimum(piso * 1.0004 + 1e-7, vals)      # ruido de fondo constante: sube muy despacio
            util = np.maximum(vals - piso * 1.05, 0)
            # volumen: lo que sobresale del ruido constante (ventilador del proyector, zumbido). Se resta
            # solo una parte del fondo para que una cancion pareja no se quede en cero.
            util[0] = max(vals[0] - piso[0] * 0.85, 0.0)
            maximos = np.maximum(maximos * 0.998, util)          # ganancia automatica
            maximos[0] = max(maximos[0], 0.006)                  # que un ruido chiquito no se vea como musica
            norm = np.clip(util / (maximos + 1e-9), 0, 1)
            if rms < 0.002 or util[0] < 0.0015:                  # silencio (o solo el ruido de fondo)
                norm[:] = 0
            ebandas = np.array([esp[ix].mean() for ix in idx], np.float32)
            if piso_e is None:
                piso_e = ebandas.copy()
            piso_e = np.minimum(piso_e * 1.0008 + 1e-7, ebandas)
            ut = np.maximum(ebandas - piso_e * 0.6, 0)           # solo quita una parte del fondo
            max_e = np.maximum(max_e * 0.997, ut)
            espectro = np.clip(ut / (max_e + 1e-9), 0, 1) if rms >= 0.002 else np.zeros(32, np.float32)
            ec = float(esp[caja_banda].mean())
            caja = prom_caja > 0 and ec > prom_caja * 2.0 and rms >= 0.004 and t_audio - t_caja > 0.15
            prom_caja = ec if prom_caja == 0 else prom_caja * 0.93 + ec * 0.07
            if caja:
                t_caja = t_audio
            g = norm[1]
            e = vals[1]                                          # energia de graves sin normalizar
            golpe = prom_graves > 0 and e > prom_graves * 1.8 and rms >= 0.004 and t_audio - t_golpe > 0.22
            prom_graves = e if prom_graves == 0 else prom_graves * 0.95 + e * 0.05
            with self.lock:
                self.rms = rms
                self.nivel = self.nivel * 0.6 + norm[0] * 0.4
                self.graves = self.graves * 0.5 + norm[1] * 0.5
                self.medios = self.medios * 0.6 + norm[2] * 0.4
                self.agudos = self.agudos * 0.6 + norm[3] * 0.4
                if golpe:
                    self.golpes += 1
                    t_golpe = t_audio
                if caja:
                    self.cajas += 1
                self.espectro = self.espectro * 0.45 + espectro.astype(np.float32) * 0.55
                self.onda = x[-512:].copy()

    def leer(self):
        with self.lock:
            g, self.golpes = self.golpes, 0
            return self.nivel, self.graves, self.medios, self.agudos, g

    def leer_todo(self):
        with self.lock:
            A = {"nivel": self.nivel, "graves": self.graves, "medios": self.medios, "agudos": self.agudos,
                 "rms": self.rms,
                 "kick": self.golpes > 0, "snare": self.cajas > 0,
                 "espectro": self.espectro.copy(), "onda": self.onda.copy()}
            self.golpes = self.cajas = 0
            return A


# ------------------------------------------------------------------ vision en hilo aparte
class Vision(object):
    def __init__(self, cam, H):
        self.cam, self.H = cam, H
        self.manos = P.DetectorManos(log=log)
        self.lock = threading.Lock()
        self.res = []          # lista de (puntos_hdmi 21x2, gesto)
        self.frame = None      # ultimo cuadro de camara
        self.fps = 0.0
        self.vivo = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        t0, n = time.time(), 0
        while self.vivo:
            ok, f = self.cam.read()
            if not ok:
                continue
            ch, cw = f.shape[:2]
            res = []
            if cw > 640:   # el detector trabaja con la imagen chica; los puntos regresan a pixeles de la grande
                k = cw / 640.0
                for cam, g in self.manos.procesar(cv2.resize(f, (640, int(ch / k)))):
                    res.append((cv2.perspectiveTransform((cam * k)[:, None], self.H)[:, 0], g))
            else:
                for cam, g in self.manos.procesar(f):
                    res.append((cv2.perspectiveTransform(cam[:, None], self.H)[:, 0], g))
            res.sort(key=lambda x: x[0][0][0])
            with self.lock:
                self.res, self.frame = res, f
            n += 1
            if time.time() - t0 > 2:
                self.fps, t0, n = n / (time.time() - t0), time.time(), 0

    def leer(self):
        with self.lock:
            return list(self.res), self.frame


# ------------------------------------------------------------------ motor de efectos
class Efectos(EA.EfectosAudioMixin):
    PALETAS = PALETAS

    def __init__(self, w, h, H):
        self.w, self.h, self.H = w, h, H
        self.buf = np.zeros((h, w), np.float32)        # capa de luz que se desvanece
        self.n = 1800
        self.pos = np.random.rand(self.n, 2).astype(np.float32) * np.float32([w, h])
        self.vel = np.zeros((self.n, 2), np.float32)
        self.radio = (25 + np.random.rand(self.n, 1) ** 1.5 * 110).astype(np.float32)
        self.ondas = []                                # [x, y, r, fuerza]
        self.paleta = 0
        self.intensidad = 1.0
        self.previas = {}
        self.audio = (0.0, 0.0, 0.0, 0.0)   # nivel, graves, medios, agudos
        self._init_audio_fx()

    def color(self, mapa_u8):
        cm = getattr(cv2, PALETAS[self.paleta][1], cv2.COLORMAP_JET)
        img = cv2.applyColorMap(mapa_u8, cm)
        img[mapa_u8 < 8] = 0
        return img

    def explosion(self, x, y):
        d = self.pos - np.float32([x, y])
        r = np.sqrt((d ** 2).sum(1))[:, None] + 1
        self.vel += d / r * (9000.0 / (r + 20.0))
        self.ondas.append([x, y, 5.0, 1.6])

    # -- cada efecto recibe puntas de dedos (lista de (x,y)) y dt; regresa imagen BGR
    def particulas(self, puntas, dt, manos, frame):
        pos, vel = self.pos, self.vel
        acc = np.zeros_like(pos)
        if puntas:
            A = np.float32(puntas)
            d = A[None] - pos[:, None]
            dist = np.sqrt((d ** 2).sum(-1)) + 1
            k = dist.argmin(1)
            v = d[np.arange(self.n), k]
            dm = dist[np.arange(self.n), k][:, None]
            tang = np.stack([-v[:, 1], v[:, 0]], 1) / dm
            acc += v / dm * np.clip((dm - self.radio) * 9 * self.intensidad, -1500, 2000) + tang * 450 * self.intensidad
        t = time.time()
        acc[:, 0] += 70 * np.sin(pos[:, 1] * 0.02 + t * 0.8)
        acc[:, 1] += 70 * np.cos(pos[:, 0] * 0.018 - t * 0.7)
        vel *= 0.94
        vel += acc * dt
        sp = np.sqrt((vel ** 2).sum(1))[:, None]
        vel *= np.minimum(1.0, 600 / (sp + 1e-3))
        pos += vel * dt
        pos[:, 0] %= self.w
        pos[:, 1] %= self.h
        xi = pos[:, 0].astype(np.int32)
        yi = pos[:, 1].astype(np.int32)
        cuenta = np.bincount(yi * self.w + xi, weights=np.sqrt(sp[:, 0]) + 8, minlength=self.w * self.h)
        capa = cuenta.reshape(self.h, self.w).astype(np.float32)
        self.buf = np.maximum(self.buf * 0.80, cv2.GaussianBlur(capa, (0, 0), 1.2) * 14)
        return self.color(np.clip(self.buf, 0, 255).astype(np.uint8))

    def estelas(self, puntas, dt, manos, frame):
        self.buf *= 0.90
        for i, (pts, _) in enumerate(manos):
            for j, k in enumerate(PUNTAS):
                clave = (i, k)
                p = (int(pts[k][0]), int(pts[k][1]))
                q = self.previas.get(clave, p)
                cv2.line(self.buf, q, p, 230.0 - j * 25, int(4 + 4 * self.intensidad), cv2.LINE_AA)
                self.previas[clave] = p
        if not manos:
            self.previas = {}
        brillo = cv2.GaussianBlur(self.buf, (0, 0), 4) * 0.8 + self.buf
        return self.color(np.clip(brillo, 0, 255).astype(np.uint8))

    def ondas_fx(self, puntas, dt, manos, frame):
        self.buf *= 0.86
        if puntas and np.random.rand() < 0.35:
            x, y = puntas[np.random.randint(len(puntas))]
            self.ondas.append([x, y, 3.0, 1.0])
        vivas = []
        for o in self.ondas:
            o[2] += (110 + 80 * self.intensidad) * dt * o[3]
            alfa = max(0.0, 1.0 - o[2] / (220 * o[3]))
            if alfa > 0.02:
                cv2.circle(self.buf, (int(o[0]), int(o[1])), int(o[2]), 255 * alfa, 3, cv2.LINE_AA)
                vivas.append(o)
        self.ondas = vivas[-40:]
        return self.color(np.clip(cv2.GaussianBlur(self.buf, (0, 0), 1.5) * 1.3, 0, 255).astype(np.uint8))

    def termico(self, puntas, dt, manos, frame):
        out = np.zeros((self.h, self.w, 3), np.uint8)
        if frame is None or not manos:
            return out
        vista = cv2.warpPerspective(frame, self.H, (self.w, self.h))
        g = cv2.equalizeHist(cv2.cvtColor(vista, cv2.COLOR_BGR2GRAY))
        efx = self.color(np.maximum(g, 9))
        mascara = np.zeros((self.h, self.w), np.uint8)
        if len(manos) >= 2:  # cuadro entre pulgar e indice de las dos manos
            a, b = manos[0][0], manos[1][0]
            quad = np.int32([a[4], a[8], b[8], b[4]])
            cv2.fillConvexPoly(mascara, cv2.convexHull(quad), 255)
            cv2.polylines(out, [cv2.convexHull(quad)], True, (255, 255, 255), 2, cv2.LINE_AA)
        else:                # una mano: su silueta aproximada
            cv2.fillConvexPoly(mascara, cv2.convexHull(manos[0][0].astype(np.int32)), 255)
        out[mascara > 0] = efx[mascara > 0]
        return out

    def caleido(self, puntas, dt, manos, frame):
        img = self.estelas(puntas, dt, manos, frame)
        hw, hh = self.w // 2, self.h // 2
        q = img[:hh, :hw]
        q = np.maximum(q, cv2.flip(img[:hh, hw:hw * 2], 1))
        q = np.maximum(q, cv2.flip(img[hh:hh * 2, :hw], 0))
        q = np.maximum(q, cv2.flip(img[hh:hh * 2, hw:hw * 2], -1))
        arriba = np.hstack([q, cv2.flip(q, 1)])
        return np.vstack([arriba, cv2.flip(arriba, 0)])

    def golpe(self, nombre, puntas):
        """Golpe de graves en la musica."""
        if puntas:
            x, y = puntas[np.random.randint(len(puntas))]
        else:
            x, y = self.w / 2 + np.random.randn() * 80, self.h / 2 + np.random.randn() * 60
        if nombre == "particulas":
            self.explosion(x, y)
        elif nombre in ("ondas", "estelas", "caleido"):
            self.ondas.append([x, y, 4.0, 1.3])
            if nombre != "ondas":
                cv2.circle(self.buf, (int(x), int(y)), 40, 255.0, -1, cv2.LINE_AA)

    def medidor(self, img):
        """Barras chicas de audio en la esquina inferior izquierda."""
        nombres = ["vol", "gra", "med", "agu"]
        for i, v in enumerate(self.audio):
            x = 10 + i * 16
            alto = int(v * 50)
            cv2.rectangle(img, (x, self.h - 12 - alto), (x + 10, self.h - 12), (200, 200, 200), -1)

    def render(self, nombre, puntas, dt, manos, frame):
        fn = {"particulas": self.particulas, "estelas": self.estelas, "ondas": self.ondas_fx,
              "termico": self.termico, "caleido": self.caleido}[nombre]
        return fn(puntas, dt, manos, frame)


# ------------------------------------------------------------------ esqueleto encima
def esqueleto(img, manos):
    for pts, _ in manos:
        p = pts.astype(np.int32)
        for a, b in HM.CONEX:
            cv2.line(img, tuple(p[a]), tuple(p[b]), (255, 255, 255), 1, cv2.LINE_AA)
        for k in PUNTAS:
            cv2.circle(img, tuple(p[k]), 4, (255, 255, 255), -1, cv2.LINE_AA)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--recalibrar", action="store_true")
    ap.add_argument("--efecto", default="particulas", choices=EFECTOS)
    ap.add_argument("--camara", default="0", help="0, 1... (USB) o csi (Jetson)")
    ap.add_argument("--x11", action="store_true")
    ap.add_argument("--sin-esqueleto", dest="sin_esqueleto", action="store_true")
    ap.add_argument("--mic", default="auto", help="dispositivo ALSA, p.ej. plughw:1,0")
    ap.add_argument("--sin-audio", dest="sin_audio", action="store_true")
    ap.add_argument("--rave", action="store_true",
                    help="modo VJ: cambia solo de efecto musical y de paleta cada 16 bombos o 25 s")
    args = ap.parse_args()

    detectar, gen = HM.aruco()
    salida = HM.abrir_salida("x11" if args.x11 else "auto")
    cam = P.Camara(args.camara, "1280x720")
    ok, f0 = cam.read()
    if not ok:
        raise SystemExit("La camara no entrega imagen")

    H = None
    if not args.recalibrar:
        H, c = HM.cargar_calib(salida.w, salida.h, (f0.shape[1], f0.shape[0]))
        if H is not None:
            log("Calibracion guardada: %s (error %.1f px)" % (c.get("fecha"), c.get("error_px", 0)))
    while H is None:
        H = HM.calibrar(cam, salida, detectar, gen)
        if H is None:
            time.sleep(2)

    audio = None
    if not args.sin_audio:
        dev = buscar_mic() if args.mic == "auto" else args.mic
        if dev:
            log("Audio: usando", dev)
            audio = Audio(dev)
        else:
            log("Audio: no encontre microfono (revisa 'arecord -l'). Sigo sin audio.")
    vis = Vision(cam, H)
    fx = Efectos(salida.w, salida.h, H)
    est = [Estable(), Estable()]
    i_efecto = EFECTOS.index(args.efecto)
    aviso, t_aviso = NOMBRES[EFECTOS[i_efecto]], time.time()
    log("Listo. Efecto: %s | palma 1 s = siguiente, puno 1 s = anterior, pulgar = paleta, pellizco = explosion"
        % EFECTOS[i_efecto])
    t_prev, t_log, cuadros = time.time(), time.time(), 0
    rave_bombos, t_rave = 0, time.time()
    if args.rave:
        i_efecto = EFECTOS.index(args.efecto) if args.efecto in EA.EFECTOS_AUDIO else len(EFECTOS_MANOS)
        aviso, t_aviso = "MODO RAVE - " + NOMBRES[EFECTOS[i_efecto]], time.time()
        log("Modo rave activado")
    try:
        while True:
            t = time.time()
            dt = min(0.1, t - t_prev)
            t_prev = t
            manos, frame = vis.leer()
            puntas = [(float(p[k][0]), float(p[k][1])) for p, _ in manos for k in PUNTAS]
            # --- gestos
            for i in range(2):
                g, dur, nuevo = est[i].actualizar(manos[i][1] if i < len(manos) else "", t)
                if g == "palma" and dur >= 1.0 and est[i].una_vez("sig"):
                    i_efecto = (i_efecto + 1) % len(EFECTOS)
                    aviso, t_aviso = NOMBRES[EFECTOS[i_efecto]], t
                    fx.buf[:] = 0
                    log("Gesto palma -> efecto", EFECTOS[i_efecto])
                elif g == "puno" and dur >= 1.0 and est[i].una_vez("ant"):
                    i_efecto = (i_efecto - 1) % len(EFECTOS)
                    aviso, t_aviso = NOMBRES[EFECTOS[i_efecto]], t
                    fx.buf[:] = 0
                    log("Gesto puno -> efecto", EFECTOS[i_efecto])
                elif g == "apuntar" and dur >= 1.0 and est[i].una_vez("grupo"):
                    i_efecto = len(EFECTOS_MANOS) if i_efecto < len(EFECTOS_MANOS) else 0
                    aviso, t_aviso = NOMBRES[EFECTOS[i_efecto]], t
                    fx.buf[:] = 0
                    log("Gesto apuntar -> grupo", "musica" if i_efecto else "manos")
                elif g == "pulgar" and nuevo:
                    fx.paleta = (fx.paleta + 1) % len(PALETAS)
                    aviso, t_aviso = "PALETA " + PALETAS[fx.paleta][0], t
                    log("Gesto pulgar -> paleta", PALETAS[fx.paleta][0])
                elif g == "pellizco" and nuevo and i < len(manos):
                    p = manos[i][0]
                    fx.explosion((p[4][0] + p[8][0]) / 2, (p[4][1] + p[8][1]) / 2)
            if len(manos) >= 2:
                d = _d(manos[0][0][8], manos[1][0][8])
                base = float(np.clip(d / (salida.w * 0.4), 0.3, 2.5))
            else:
                base = 1.0
            A = EA.audio_vacio()
            if audio is not None and audio.ok:
                A = audio.leer_todo()
                fx.audio = (A["nivel"], A["graves"], A["medios"], A["agudos"])
                base *= 0.7 + 1.3 * A["nivel"]
                if A["kick"] and EFECTOS[i_efecto] in EFECTOS_MANOS:
                    fx.golpe(EFECTOS[i_efecto], puntas)
                if args.rave:
                    rave_bombos += 1 if A["kick"] else 0
                    if rave_bombos >= 16 or t - t_rave > 25:
                        opciones = [k for k in range(len(EFECTOS_MANOS), len(EFECTOS)) if k != i_efecto]
                        i_efecto = int(np.random.choice(opciones))
                        fx.paleta = int(np.random.randint(len(PALETAS)))
                        fx.buf[:] = 0
                        aviso, t_aviso = NOMBRES[EFECTOS[i_efecto]], t
                        rave_bombos, t_rave = 0, t
                        log("Rave -> %s / %s" % (EFECTOS[i_efecto], PALETAS[fx.paleta][0]))
            fx.intensidad += (base - fx.intensidad) * 0.25
            # --- render
            if EFECTOS[i_efecto] in EA.EFECTOS_AUDIO:
                img = fx.render_audio(EFECTOS[i_efecto], A, manos, puntas)
            else:
                img = fx.render(EFECTOS[i_efecto], puntas, dt, manos, frame)
            if audio is not None and audio.ok:
                if fx.audio[1] > 0.05 and EFECTOS[i_efecto] in ("particulas", "estelas", "ondas", "caleido"):
                    img = cv2.convertScaleAbs(img, alpha=1.0 + 0.6 * fx.audio[1])
                fx.medidor(img)
            if not args.sin_esqueleto:
                esqueleto(img, manos)
            if t - t_aviso < 1.8:
                HM.texto(img, aviso, 40, 0.9, (255, 255, 255))
            elif not manos:
                HM.texto(img, "Pon la mano sobre la mesa", salida.h - 20, 0.5, (90, 90, 90))
            salida.mostrar(img)
            cuadros += 1
            if t - t_log > 3:
                gs = ",".join(g or "-" for _, g in manos) or "-"
                au = "vol %.2f graves %.2f" % fx.audio[:2] if audio is not None and audio.ok else "sin audio"
                log("%s | dibujo %.0f FPS | manos %d (%s) | vision %.1f FPS | %s"
                    % (EFECTOS[i_efecto], cuadros / (t - t_log), len(manos), gs, vis.fps, au))
                t_log, cuadros = t, 0
            time.sleep(max(0.0, 0.04 - (time.time() - t)))
    except KeyboardInterrupt:
        log("Saliendo")
    finally:
        vis.vivo = False
        time.sleep(0.2)
        salida.cerrar()
        cam.release()


if __name__ == "__main__":
    main()
