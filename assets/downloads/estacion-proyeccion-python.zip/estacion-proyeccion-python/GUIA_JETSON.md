# Estación de proyección en la Jetson Nano

Es **el mismo código que en la Raspberry**. `estacion.py` detecta en qué placa está y se ajusta solo
(ver `plataforma.py`). Lo que cambia en la Jetson:

| | Raspberry Pi 4 | Jetson Nano |
|---|---|---|
| Manos (21 puntos) | MediaPipe en el CPU | **poseNet `resnet18-hand` en la GPU** (jetson-inference, TensorRT) |
| Salida HDMI | framebuffer `/dev/fb0` | ventana a pantalla completa si hay escritorio; framebuffer si no (`--consola`) |
| Cámara | USB | USB (`--camara 0`) o **CSI** (`--camara csi`) |
| Resolución de dibujo | 640×480 | 480 px de alto con la proporción del proyector (ej. 856×480 para 16:9) y se escala |
| Arranque automático | `crontab @reboot` | al entrar al escritorio (`~/.config/autostart/estacion.desktop`) o `crontab` en modo consola |

Todos los modos son los mismos: Manos, Video reactivo, Rave musical, Piano Tiles, Piano libre,
Cortina de audio, Flor interactiva, Imagen a partículas, Cubo 3D, Centellas, Recalibrar y Salir.
Siempre **calibra al iniciar** con los 4 marcadores proyectados en las esquinas.

## 1. Lo que necesitas

- Jetson Nano con **JetPack 4.6** (la imagen oficial de NVIDIA para la Nano).
- **Fuente de 5 V / 4 A por el conector redondo** con el jumper **J48** puesto. Con la fuente micro-USB
  la Jetson baja la velocidad (igual que la Raspberry con poco voltaje).
- Proyector por HDMI, cámara USB (o la cámara CSI IMX219), micrófono USB (opcional) y bocina USB o por HDMI.
- Tarjeta microSD de 32 GB o más (jetson-inference ocupa varios GB).

## 2. Copiar la carpeta

Con MobaXterm, conéctate a la Jetson (`ssh usuario@IP-de-la-jetson`) y arrastra la carpeta **asesor** completa
al panel de la izquierda (quedará en `/home/usuario/asesor`). Deben ir al menos:
`estacion.py plataforma.py hdmi_manos.py hdmi_reactivo.py efectos_audio.py modos_base.py modos_juegos.py
modos_arte.py iniciar_estacion.sh instalar_jetson.sh instalar_vision.sh`.

## 3. Instalar (una sola vez)

```bash
cd ~/asesor
bash instalar_jetson.sh
```

Te pide tu contraseña para los pasos con `sudo` (escríbela tú). Hace:

1. Paquetes del sistema (audio, cámara, utilidades de pantalla).
2. `numpy 1.19.4` + **OpenCV con ArUco** (`opencv-contrib-python 4.5.5`) y agrega
   `export OPENBLAS_CORETYPE=ARMV8` a `~/.bashrc` (sin eso numpy truena con "Illegal instruction").
3. Si no está **jetson-inference**, lo compila (30–90 min) y prepara el modelo de manos `resnet18-hand`
   (la primera vez TensorRT lo optimiza: unos minutos).
4. Permisos de video y audio.
5. Modo de máxima potencia (`nvpmodel -m 0`).
6. Arranque automático al encender (y desactiva el arranque del asesor viejo `panel.py` para que no se peleen la cámara).
7. Revisión final: te dice qué quedó bien y qué no.

¿Sin escritorio? `bash instalar_jetson.sh --consola` hace que la Jetson arranque en modo texto
y la estación dibuje directo al HDMI (más ligero, como en la Raspberry).

## 4. Probar

```bash
cd ~/asesor
python3 estacion.py                 # cámara USB 0
python3 estacion.py --camara csi    # cámara CSI
python3 estacion.py --modo piano    # abrir directo un modo
```

Funciona igual lanzado desde MobaXterm: la imagen sale en el proyector, no en tu PC.
En la terminal verás algo así:

```
Plataforma: jetson
HDMI (escritorio :0): pantalla 1920x1080, dibujo a 856x480
Camara: 640x360
Marcadores proyectados vistos ahora: [0, 1, 2, 3]
Calibracion lista. Error medio: ... px HDMI
Vision iniciada en proceso aparte
Manos listas: detector posenet (... s en cargar)
Menu | dibujo ... FPS | vision ... FPS | manos 1
```

Mientras carga el detector de manos aparece abajo *"Cargando detector de manos..."*.

## 5. Opciones fijas

Para que el arranque automático use siempre ciertas opciones, crea `~/asesor/estacion_args.txt`:

```
--camara csi
--alto 400
```

| Opción | Para qué |
|---|---|
| `--camara 0` / `--camara csi` | cámara USB (número) o CSI |
| `--salida auto / x11 / fb` | ventana en el escritorio o framebuffer |
| `--alto 480` | altura de dibujo; 400 o 360 = más rápido |
| `--manos auto / posenet / mediapipe` | detector de manos |
| `--mic plughw:2,0` / `--sin-audio` | micrófono (por defecto prueba todos y usa el que más capta) |
| `--salida-audio plughw:2,0` / `--sin-sonido` | dónde suenan las notas del piano |
| `--res 1280x720` | resolución de cámara (por defecto 640x360, más rápida) |

Registro del arranque automático: `~/asesor/registros/estacion.log`.

## 6. Problemas comunes

| Síntoma | Qué hacer |
|---|---|
| `Illegal instruction (core dumped)` | `export OPENBLAS_CORETYPE=ARMV8` (ya va en `iniciar_estacion.sh` y en `~/.bashrc`) |
| `module 'cv2' has no attribute 'aruco'` | `python3 -m pip install --user opencv-contrib-python==4.5.5.64` |
| Se queda en "Cargando detector de manos" | la primera vez tarda varios minutos (TensorRT). Si no avanza: `cd ~/jetson-inference/tools && ./download-models.sh` y marca *Pose-ResNet18-Hand* |
| `cannot open display` al lanzarlo por SSH | la sesión del escritorio debe estar abierta (inicio automático) o usa `--salida fb` sin escritorio |
| Va lento | fuente de 5 V 4 A + J48, `sudo nvpmodel -m 0`, `sudo jetson_clocks`, `--alto 400` |
| No ve las 4 esquinas | que la cámara vea toda la proyección; con 3 esquinas también calibra |
| Las manos no coinciden con la proyección | usa el mosaico **Recalibrar** del menú (no muevas cámara ni proyector después) |
