# Guía rápida: manos proyectadas en la salida HDMI (Raspberry Pi 4B)

La Raspberry dibuja directo en su salida HDMI (el proyector), se calibra sola con 4 marcadores proyectados en las esquinas y luego proyecta las landmarks de tu mano encima de ella.

## 1. Lo que necesitas

| Qué | Detalle |
|---|---|
| Raspberry Pi 4B | Raspberry Pi OS de **64 bits** (Bullseye o Bookworm) |
| Cámara USB | La de la estación (`/dev/video0`), viendo la mesa desde arriba |
| Proyector | Conectado al **HDMI 0** de la Raspberry (el que está junto a la entrada de corriente) |
| PC con MobaXterm | Para entrar por SSH y pasar archivos |
| Red | PC y Raspberry conectadas (ahora: `192.168.137.2`) |

Software en la Raspberry (la tuya ya lo tiene):
- Python 3.9 o más nuevo
- OpenCV con ArUco: `python3 -c "import cv2; cv2.aruco"`
- MediaPipe: `python3 -c "import mediapipe"`
- Tu usuario en el grupo `video` (para dibujar en el HDMI sin sudo): `groups`

Si falta algo: `bash instalar_pi.sh` (pide tu contraseña para sudo).

## 2. Acomodar la estación
1. El proyector apunta a la mesa y la cámara ve **toda** la imagen proyectada, incluidas las 4 esquinas.
2. Mesa clara y mate; poca luz directa sobre la mesa.
3. Prende el proyector **antes** que la Raspberry, para que detecte bien la resolución del HDMI.

## 3. Entrar y copiar el proyecto
1. Abre MobaXterm y entra a la Raspberry (sesión `192.168.137.2`).
2. En la terminal:
   ```bash
   mkdir -p ~/asesor && cd ~/asesor
   ```
3. En el panel izquierdo (ya en `/home/raspberrypi/asesor`), botón **subir** (flecha verde) y elige los archivos de `C:\Users\josea\Documents\asesor`. Para esta demo basta `hdmi_manos.py`.

## 4. Correrlo
```bash
cd ~/asesor
python3 hdmi_manos.py --recalibrar
```
Qué pasa:
1. El HDMI se pone **blanco con 4 marcadores en las esquinas**. No tapes las esquinas.
2. En la terminal ves `Marcadores proyectados vistos ahora: [0, 1, 2, 3]`. Con 3 basta.
3. Sale `Calibracion lista` y la proyección muestra círculos verdes en las esquinas.
4. El HDMI queda negro con marcadores chicos. **Pon la mano sobre la mesa**: se proyecta el esqueleto sobre ella.
5. Para salir: `Ctrl+C`.

Las siguientes veces, mientras no muevas cámara ni proyector:
```bash
python3 hdmi_manos.py
```

Opciones:
| Opción | Para qué |
|---|---|
| `--recalibrar` | Calibrar de nuevo (si moviste cámara o proyector) |
| `--ver` | Abre en tu PC (por MobaXterm) una ventana con lo que ve la cámara |
| `--sin-marcadores` | Quita los marcadores chicos mientras se ven las manos |
| `--x11` | Si la Raspberry tiene escritorio, dibuja en una ventana de pantalla completa en vez de directo al HDMI |
| `--camara 1` | Usar otra cámara |

## 5. Que arranque solo al prender (sin sudo)
```bash
crontab -e
```
Agrega al final y guarda:
```
@reboot sleep 20 && cd /home/raspberrypi/asesor && python3 hdmi_manos.py >> registros/hdmi.log 2>&1
```

## 6. Problemas comunes
| Problema | Solución |
|---|---|
| `Permission denied: /dev/fb0` | `sudo usermod -aG video $USER`, cierra la sesión y vuelve a entrar |
| No ve alguna esquina | Mueve la cámara o el proyector hasta que la cámara vea toda la proyección y corre `--recalibrar` |
| Las landmarks quedan corridas | Recalibra con las 4 esquinas visibles; no muevas nada después |
| El HDMI sale en 640×480 | El proyector no estaba prendido al arrancar. Prende primero el proyector o fija la resolución en `/boot/config.txt` (`hdmi_force_hotplug=1`, `hdmi_group=2`, `hdmi_mode=82` para 1920×1080) |
| No detecta la mano | Más luz sobre la mano; quita la mano de la orilla de la imagen |
| Va lento | Normal en la Pi: ~7 FPS con MediaPipe. Cierra otros programas |

---

# Video reactivo con gestos y audio (`hdmi_reactivo.py`)

Efectos estilo TouchDesigner en la salida HDMI que siguen tus manos, cambian con gestos y reaccionan a la música. Usa la misma calibración que `hdmi_manos.py`.

```bash
cd ~/asesor
python3 hdmi_reactivo.py --mic plughw:4,0      # micrófono de la webcam
python3 hdmi_reactivo.py --recalibrar          # si moviste cámara o proyector
python3 hdmi_reactivo.py --efecto ondas        # empezar en otro efecto
```

**Efectos de manos (5):** partículas, estelas de neón, ondas, térmico (dentro del cuadro entre pulgar e índice de las dos manos), caleidoscopio.

**Efectos de música (11), con la FFT del sonido del ambiente, tipo rave** (`efectos_audio.py`):

| Efecto | Qué hace |
|---|---|
| Espectro | Barras de la FFT en espejo |
| Espectro circular | Barras de la FFT alrededor de tu mano, giran con los medios |
| Osciloscopio | La forma de onda del sonido en vivo |
| Lissajous | Figura X/Y de la onda con estela |
| Túnel feedback | La imagen anterior se escala y gira sin fin; anillo blanco en cada bombo |
| Anillos | Un anillo por cada bombo (graves) y por cada caja (medios) |
| Instancias | Rejilla de cuadros que crecen por banda de frecuencia |
| Estrobo | Destellos de color en bombo y caja |
| Líneas sonoras | Líneas tipo montañas que suben con el espectro |
| Hiperespacio | Estrellas que aceleran con el volumen |
| Metabolas | Burbujas líquidas que laten con los graves y siguen tus dedos |

**Modo rave** (`--rave`): cambia solo de efecto musical y de paleta cada 16 bombos o 25 segundos, como un VJ automático. Los gestos siguen funcionando.

```bash
python3 hdmi_reactivo.py --rave --mic plughw:4,0
```

| Gesto | Qué hace |
|---|---|
| Palma abierta 1 s | Siguiente efecto |
| Apuntar (solo índice) 1 s | Salta entre el grupo de manos y el de música |
| Puño 1 s | Efecto anterior |
| Pulgar arriba | Cambia la paleta de colores |
| Pellizco | Explosión u onda en ese punto |
| Dos manos | La distancia entre los índices sube o baja la intensidad |

**Audio:** el volumen sube la intensidad y cada golpe de graves lanza una explosión u onda. Abajo a la izquierda hay 4 barras: volumen, graves, medios y agudos.
- Ver micrófonos: `arecord -l`. Elegir uno: `--mic plughw:TARJETA,0`. Sin audio: `--sin-audio`.
- Probar si un micrófono capta: `arecord -D plughw:3,0 -f S16_LE -r 16000 -d 4 -V mono /tmp/t.wav` (la barra debe moverse).
- El adaptador USB (tarjeta 3) captaba silencio en la prueba: revisa que el micrófono esté en la entrada **rosa / mic** del adaptador.
