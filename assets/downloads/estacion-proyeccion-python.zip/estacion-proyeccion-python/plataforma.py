# -*- coding: utf-8 -*-
"""
plataforma.py - Lo que cambia entre Raspberry Pi, Jetson Nano y PC, para que el resto del codigo sea igual.

  tipo()                 "jetson", "raspberry" o "pc"
  Camara(fuente, res)    USB ("0", "1", "/dev/video0") o camara CSI de la Jetson ("csi" o "csi://0")
  DetectorManos(motor)   manos de 21 puntos: poseNet 'resnet18-hand' (Jetson, GPU) o MediaPipe (Pi / PC)
  gesto(pts)             palma, puno, pellizco, pulgar, apuntar o "" (tolera puntos que no se vieron)
  mic_valido(nombre)     descarta las tarjetas internas de la Jetson que no son microfonos

Compatible con Python 3.6 (JetPack 4) en adelante.
"""
from __future__ import print_function

import math
import os
import time

import cv2
import numpy as np

_TIPO = None


def tipo():
    global _TIPO
    if _TIPO is None and os.environ.get("ESTACION_PLATAFORMA"):   # para forzarla (pruebas)
        _TIPO = os.environ["ESTACION_PLATAFORMA"]
    if _TIPO is None:
        try:
            modelo = open("/proc/device-tree/model").read().lower()
        except Exception:
            modelo = ""
        if os.path.exists("/etc/nv_tegra_release") or "jetson" in modelo or "nvidia" in modelo:
            _TIPO = "jetson"
        elif "raspberry" in modelo:
            _TIPO = "raspberry"
        else:
            _TIPO = "pc"
    return _TIPO


def hay_escritorio():
    """True si hay un escritorio (servidor X) corriendo en la pantalla :0."""
    return os.path.exists("/tmp/.X11-unix/X0")


def preparar_x11():
    """Para poder abrir la ventana en la pantalla del HDMI aunque el programa se lance por SSH."""
    os.environ["DISPLAY"] = os.environ.get("DISPLAY") or ":0"
    if not os.environ.get("XAUTHORITY"):
        for ruta in ("/run/user/%d/gdm/Xauthority" % os.getuid(), os.path.expanduser("~/.Xauthority")):
            if os.path.exists(ruta):
                os.environ["XAUTHORITY"] = ruta
                break


def mic_valido(nombre):
    """Las tarjetas 'tegra' (APE / HDMI) de la Jetson aparecen como captura pero no son microfonos."""
    n = nombre.lower()
    return not any(x in n for x in ("tegra", "t210", "t186", "ape", "hda-intel", "hdmi"))


def parse_res(res):
    w, h = [int(v) for v in str(res).lower().split("x")]
    return w, h


# ====================================================================== camara
class Camara(object):
    """Misma interfaz que cv2.VideoCapture (read, release) para USB y para la camara CSI de la Jetson."""

    def __init__(self, fuente="0", res="640x360"):
        self.fuente = str(fuente)
        w, h = parse_res(res)
        self.cap = self.src = None
        if self.fuente.startswith("csi"):
            try:
                from jetson_utils import videoSource, cudaToNumpy, cudaDeviceSynchronize
            except ImportError:  # JetPack 4.4 o mas viejo
                import jetson.utils as ju
                videoSource, cudaToNumpy, cudaDeviceSynchronize = ju.videoSource, ju.cudaToNumpy, ju.cudaDeviceSynchronize
            uri = self.fuente if "://" in self.fuente else "csi://0"
            self.src = videoSource(uri, argv=["--input-width=%d" % w, "--input-height=%d" % h])
            self._a_numpy, self._sinc = cudaToNumpy, cudaDeviceSynchronize
        else:
            dev = int(self.fuente) if self.fuente.isdigit() else self.fuente
            self.cap = cv2.VideoCapture(dev, cv2.CAP_V4L2)
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    def read(self):
        if self.cap is not None:
            return self.cap.read()
        try:
            img = self.src.Capture()
        except Exception:
            return False, None
        if img is None:
            return False, None
        self._sinc()
        rgb = self._a_numpy(img)
        return True, cv2.cvtColor(np.asarray(rgb)[:, :, :3], cv2.COLOR_RGB2BGR)

    def release(self):
        if self.cap is not None:
            self.cap.release()
        if self.src is not None:
            try:
                self.src.Close()
            except Exception:
                pass
            self.src = None


# ====================================================================== gestos
def _d(a, b):
    return float(math.hypot(a[0] - b[0], a[1] - b[1]))


def _vis(m, idx):
    return all(not np.isnan(m[i][0]) for i in idx)


def gesto(m):
    """m: 21x2 en pixeles (puede traer NaN donde no se vio). Regresa palma, puno, pellizco, pulgar, apuntar o ''."""
    if not _vis(m, (0, 4, 8, 9)):
        return ""
    escala = max(1.0, _d(m[0], m[9]))
    if _d(m[4], m[8]) < 0.30 * escala:
        return "pellizco"
    ext = {}
    for t, p in ((8, 6), (12, 10), (16, 14), (20, 18)):
        if _vis(m, (t, p)):
            ext[t] = _d(m[0], m[t]) > 1.12 * _d(m[0], m[p])
    if len(ext) < 3:
        return ""
    pulgar = _vis(m, (2, 17)) and _d(m[4], m[17]) > 1.25 * _d(m[2], m[17])
    n = sum(ext.values())
    if len(ext) == 4 and n == 4 and pulgar:
        return "palma"
    if ext.get(8) and n == 1:
        return "apuntar"
    if n == 0:
        return "pulgar" if pulgar else "puno"
    return ""


# ====================================================================== relleno de puntos (poseNet)
CADENAS = [(0, 1, 2, 3, 4), (0, 5, 6, 7, 8), (0, 9, 10, 11, 12), (0, 13, 14, 15, 16), (0, 17, 18, 19, 20)]
CADENAS_LINKS = [(c[i], c[i + 1]) for c in CADENAS for i in range(len(c) - 1)] + [(5, 9), (9, 13), (13, 17)]


def rellenar(p, minimo=8):
    """poseNet a veces no ve algunos puntos (NaN). Los estima a lo largo de cada dedo.
    Regresa None si la mano trae muy pocos puntos."""
    ok = ~np.isnan(p[:, 0])
    if ok.sum() < minimo:
        return None
    p = p.copy()
    if not ok[0]:
        bases = [i for i in (1, 5, 9, 13, 17) if ok[i]]
        if not bases:
            return None
        p[0] = np.mean(p[bases], axis=0)
        ok[0] = True
    for cad in CADENAS:
        for k, i in enumerate(cad):
            if ok[i]:
                continue
            antes = [j for j in range(k) if ok[cad[j]]]
            despues = [j for j in range(k + 1, len(cad)) if ok[cad[j]]]
            if antes and despues:
                a, b = antes[-1], despues[0]
                f = (k - a) / float(b - a)
                p[i] = p[cad[a]] * (1 - f) + p[cad[b]] * f
            elif len(antes) >= 2:  # sigue la direccion del dedo
                a0, a1 = antes[-2], antes[-1]
                paso = (p[cad[a1]] - p[cad[a0]]) / float(a1 - a0)
                p[i] = p[cad[a1]] + paso * (k - a1)
            else:
                p[i] = p[cad[antes[-1]]]
    return p


# ====================================================================== detector de manos
class DetectorManos(object):
    """procesar(bgr) -> [(pts 21x2 float32 en pixeles de bgr, gesto)]"""

    def __init__(self, motor="auto", max_manos=2, log=print, umbral=0.15, min_puntos=8):
        self.motor, self.errores, self.max = None, [], max_manos
        self.umbral, self.min_puntos = float(umbral), int(min_puntos)
        if motor == "ninguno":   # pruebas sin detector de manos (no usa la GPU)
            log("Manos: desactivadas (--manos ninguno)")
            return
        if motor == "auto":
            orden = ["posenet", "mediapipe"] if tipo() == "jetson" else ["mediapipe", "posenet"]
        else:
            orden = [motor]
        for m in orden:
            try:
                getattr(self, "_iniciar_" + m)()
                self.motor = m
                break
            except Exception as e:
                self.errores.append("%s: %s" % (m, e))
        if self.motor is None:
            log("Manos: no hay detector (%s)" % "; ".join(self.errores))

    def _iniciar_mediapipe(self):
        import mediapipe as mpipe
        self.mp = mpipe.solutions.hands.Hands(static_image_mode=False, max_num_hands=self.max, model_complexity=0,
                                              min_detection_confidence=0.45, min_tracking_confidence=0.45)

    def _iniciar_posenet(self):
        try:
            from jetson_inference import poseNet
            from jetson_utils import cudaFromNumpy
        except ImportError:
            import jetson.inference as ji
            import jetson.utils as ju
            poseNet, cudaFromNumpy = ji.poseNet, ju.cudaFromNumpy
        self.net = None
        try:   # con argv se puede bajar el nivel de mensajes (sin "duplicate link detected" a cada rato)
            self.net = poseNet(argv=["poseNet", "--network=resnet18-hand", "--threshold=%.3f" % self.umbral,
                                     "--log-level=error"], threshold=self.umbral)
            if self.net.GetNumKeypoints() != 21:   # por si esta version ignora --network
                self.net = None
        except Exception:
            self.net = None
        if self.net is None:
            self.net = poseNet("resnet18-hand", threshold=self.umbral)
        self._cuda = cudaFromNumpy

    def set_umbral(self, v):
        self.umbral = float(v)
        if self.motor == "posenet":
            try:
                self.net.SetThreshold(self.umbral)
            except Exception:
                pass

    def procesar(self, bgr):
        if self.motor is None:
            time.sleep(0.05)
            return []
        h, w = bgr.shape[:2]
        res = []
        if self.motor == "mediapipe":
            entrada = bgr if w <= 640 else cv2.resize(bgr, (480, int(480 * h / w)))
            r = self.mp.process(cv2.cvtColor(entrada, cv2.COLOR_BGR2RGB))
            for lm in (r.multi_hand_landmarks or []):
                p = np.float32([[q.x * w, q.y * h] for q in lm.landmark])
                res.append((p, gesto(p)))
            return res
        rgb = np.ascontiguousarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        candidatas = []
        for pose in self.net.Process(self._cuda(rgb), overlay="none"):
            p = np.full((21, 2), np.nan, np.float32)
            for kp in pose.Keypoints:
                if 0 <= kp.ID < 21:
                    p[kp.ID] = (kp.x, kp.y)
            vistos = int(np.count_nonzero(~np.isnan(p[:, 0])))
            g = gesto(p)
            p = rellenar(p, self.min_puntos)
            if p is None:
                continue
            if not g and vistos >= 15:   # faltaba un punto clave (ej. la muneca): se usa la mano completada
                g = gesto(p)
            candidatas.append((vistos, p, g))
        candidatas.sort(key=lambda c: -c[0])
        return [(p, g) for _, p, g in candidatas[:self.max]]
