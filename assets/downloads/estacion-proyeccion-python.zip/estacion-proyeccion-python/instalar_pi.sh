#!/bin/bash
# Instalador del Asesor para Raspberry Pi 4B (Raspberry Pi OS de 64 bits, Bullseye o Bookworm).
# Uso:  cd ~/asesor && bash instalar_pi.sh
# Deja todo listo para PRUEBAS. No configura el arranque automatico (eso es instalar.sh, para la estacion final).
DIR="$(cd "$(dirname "$0")" && pwd)"
USUARIO="$(whoami)"
ok()   { echo "  [OK]  $*"; }
mal()  { echo "  [!!]  $*"; }

echo "=== 0/6 Equipo"
tr -d '\0' < /proc/device-tree/model; echo
. /etc/os-release; echo "$PRETTY_NAME  |  $(uname -m)  |  $(python3 --version)"
if [ "$(uname -m)" != "aarch64" ]; then
  mal "Sistema de 32 bits: funciona todo menos MediaPipe (manos). Para manos, graba Raspberry Pi OS de 64 bits."
fi

# Bookworm o mas nuevo no deja instalar con pip sin esta bandera
PIP="python3 -m pip install --user"
if ls /usr/lib/python3*/EXTERNALLY-MANAGED >/dev/null 2>&1; then
  PIP="$PIP --break-system-packages"
fi

echo "=== 1/6 Paquetes del sistema"
sudo apt-get update
sudo apt-get install -y python3-pip python3-numpy python3-pil python3-serial espeak-ng alsa-utils \
     v4l-utils fonts-dejavu-core unclutter x11-xserver-utils wget unzip

echo "=== 2/6 OpenCV con ArUco (marcadores de calibracion)"
if python3 -c "import cv2; cv2.aruco" 2>/dev/null; then
  ok "Ya tienes OpenCV $(python3 -c 'import cv2; print(cv2.__version__)') con ArUco"
else
  echo "  Tu OpenCV no tiene ArUco (o no hay OpenCV). Instalando opencv-contrib-python..."
  $PIP "opencv-contrib-python<4.11" && ok "OpenCV instalado" || mal "No se pudo instalar OpenCV"
fi

echo "=== 3/6 Manos (MediaPipe) — opcional, puede tardar"
if python3 -c "import mediapipe" 2>/dev/null; then ok "MediaPipe ya instalado"
else $PIP mediapipe && ok "MediaPipe instalado" || mal "MediaPipe no se instalo (el resto funciona igual)"; fi

echo "=== 4/6 Modelo de Teachable Machine (TensorFlow Lite) — opcional"
if python3 -c "import tflite_runtime" 2>/dev/null || python3 -c "import ai_edge_litert" 2>/dev/null; then ok "TFLite ya instalado"
else $PIP tflite-runtime 2>/dev/null && ok "tflite-runtime instalado" \
  || { $PIP ai-edge-litert && ok "ai-edge-litert instalado" || mal "TFLite no se instalo (solo afecta al clasificador)"; }; fi

echo "=== 5/6 Comandos de voz (Vosk) — opcional"
$PIP vosk >/dev/null && ok "Vosk instalado" || mal "Vosk no se instalo"
mkdir -p ~/modelos
if [ ! -d ~/modelos/vosk-model-small-es-0.42 ]; then
  wget -q -O /tmp/vosk-es.zip https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip \
    && unzip -q /tmp/vosk-es.zip -d ~/modelos && rm -f /tmp/vosk-es.zip && ok "Modelo de voz en espanol" \
    || mal "No se pudo bajar el modelo de voz"
fi

echo "=== 6/6 Permisos y carpetas"
sudo usermod -aG video,audio,dialout "$USUARIO"
mkdir -p "$DIR/registros" "$DIR/modelo" "$DIR/dataset" "$DIR/modelo_detector" "$DIR/dataset_detector"
chmod +x "$DIR"/*.sh "$DIR"/*.py 2>/dev/null

echo
echo "=== Resumen"
python3 - <<'EOF'
def prueba(nombre, codigo):
    try:
        exec(codigo, {})
        print("  [OK]  " + nombre)
    except Exception as e:
        print("  [--]  %s  (%s)" % (nombre, str(e).splitlines()[0][:70]))
prueba("OpenCV + ArUco", "import cv2; cv2.aruco")
prueba("numpy", "import numpy")
prueba("Pillow (texto con acentos)", "import PIL")
prueba("MediaPipe (manos)", "import mediapipe")
prueba("TFLite (clasificador)", "\ntry:\n import tflite_runtime\nexcept ImportError:\n import ai_edge_litert")
prueba("Vosk (voz)", "import vosk")
EOF
echo "  Camaras: $(ls /dev/video* 2>/dev/null | tr '\n' ' ')"
echo
echo "=== Siguiente paso: probar la camara"
echo "  python3 $DIR/probar_camara.py"
echo "Y luego el panel:  python3 $DIR/panel.py --pantalla \"\""
echo "  y abre en tu PC:  http://$(hostname -I | awk '{print $1}'):8080"
