#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ajustar_camara.py - Ajusta EN VIVO la camara y los filtros para que el detector vea bien la mano con poca luz.
Por MobaXterm la ventana sale en tu PC; en el proyector se ve la "luz de relleno".
Lo que guardes con M queda en filtros.json y estacion.py lo usa solo.

  python3 ajustar_camara.py                  (cierra antes la estacion: pkill -f estacion.py)
  python3 ajustar_camara.py --res 1280x720

Fila de arriba = SUBIR, fila de abajo = BAJAR:
  Q/A exposicion de la camara      W/S ganancia        E/D brillo       R/F contraste
  T/G gamma (aclara sombras)       Y/H CLAHE (contraste local)          U/J saturacion (0 = gris)
  I/K suavizado (quita ruido)      O/L recorte a la zona proyectada     P/N umbral del detector
  X/Z puntos minimos por mano      V/C luz de relleno en el proyector
  1 = exposicion automatica   B = cambiar vista   M = guardar   0 = restaurar todo   Esc = salir
Al salir (Esc o Ctrl+C) los ajustes se guardan solos en filtros.json.
"""
from __future__ import print_function

import argparse
import os
import sys
import time

if os.path.exists("/etc/nv_tegra_release"):
    os.environ.setdefault("OPENBLAS_CORETYPE", "ARMV8")

import cv2
import numpy as np

import filtros as FI
import hdmi_manos as HM
import plataforma as P

VENTANA = "Ajuste de camara (Esc = salir, M = guardar)"
GAMMAS = [0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.3, 2.6, 3.0]
CLAHES = [0, 1, 1.5, 2, 3, 4, 6]
SATS = [round(0.1 * i, 1) for i in range(16)]
SUAV = [0, 3, 5, 7, 9]
RECORTES = [round(0.1 * i, 1) for i in range(11)]
UMBRALES = [round(0.05 + 0.025 * i, 3) for i in range(19)]
MINPTS = list(range(4, 17))
RELLENOS = list(range(0, 160, 10))


def err(*a):
    print(*a, file=sys.stderr)
    sys.stderr.flush()


def paso(valor, lista, signo):
    i = min(range(len(lista)), key=lambda k: abs(lista[k] - valor))
    return lista[max(0, min(len(lista) - 1, i + signo))]


class Ajustador(object):
    def __init__(self, a):
        self.a = a
        self.cfg = FI.cargar()
        self.dev = FI.dispositivo(a.camara)
        self.ctrls = FI.controles(self.dev)
        self.auto, self.expo, self.v_manual, self.v_auto = FI.nombres_exposicion(self.ctrls)
        self.cam = P.Camara(a.camara, a.res)
        FI.aplicar_camara(a.camara, self.cfg)
        self.pre = FI.Preproceso(self.cfg)
        err("Cargando detector de manos...")
        self.det = P.DetectorManos("auto", max_manos=2, log=err, umbral=self.cfg["umbral"],
                                   min_puntos=self.cfg["min_puntos"])
        if self.det.motor == "posenet":   # que los avisos de la red no llenen la terminal
            nulo = os.open(os.devnull, os.O_WRONLY)
            os.dup2(nulo, 1)
        err("Detector: %s" % (self.det.motor or "ninguno"))
        self.salida = None
        if a.salida != "ninguna":
            try:
                self.salida = HM.abrir_salida(a.salida, 360)
            except Exception as e:
                err("Sin proyector (%s)" % e)
        self.vista, self.msg, self.t_msg, self.ultimo = 0, "", 0.0, ""
        self.t_proy = 0.0
        self.proyectar(True)

    # ---------------- proyector: luz de relleno
    def proyectar(self, forzar=False):
        if self.salida is None or (not forzar and time.time() - self.t_proy < 1.0):
            return
        self.t_proy = time.time()
        r = int(self.cfg.get("relleno", 0))
        img = np.full((self.salida.h, self.salida.w, 3), r, np.uint8)
        HM.texto(img, "Ajuste de camara - luz de relleno %d" % r, 24, 0.5, (90, 90, 90))
        self.salida.mostrar(img)

    def aviso(self, t):
        self.msg, self.t_msg = t, time.time()
        err(t)

    # ---------------- controles de camara
    def ctrl(self, nombre, signo, etiqueta):
        c = self.ctrls.get(nombre)
        if not c or "min" not in c:
            self.aviso("Tu camara no tiene '%s'" % etiqueta)
            return
        actual = self.cfg["camara"].get(nombre, c.get("value", c.get("default", 0)))
        pasito = max(c.get("step", 1), (c["max"] - c["min"]) // 16 or 1)
        nuevo = int(max(c["min"], min(c["max"], actual + signo * pasito)))
        FI.poner(self.dev, nombre, nuevo)
        self.cfg["camara"][nombre] = nuevo
        self.aviso("%s: %d" % (etiqueta, nuevo))

    def exposicion(self, signo):
        if not self.expo:
            self.aviso("Tu camara no deja cambiar la exposicion")
            return
        c = self.ctrls[self.expo]
        if self.auto:
            FI.poner(self.dev, self.auto, self.v_manual)
            self.cfg["camara"][self.auto] = self.v_manual
        actual = self.cfg["camara"].get(self.expo, c.get("value", c.get("default", 100)))
        nuevo = actual * 1.4 if signo > 0 else actual / 1.4
        nuevo = int(max(c.get("min", 1), min(c.get("max", 10000), round(nuevo))))
        if nuevo == actual:
            nuevo = int(max(c.get("min", 1), min(c.get("max", 10000), actual + signo)))
        FI.poner(self.dev, self.expo, nuevo)
        self.cfg["camara"][self.expo] = nuevo
        self.aviso("Exposicion manual: %d" % nuevo)

    def expo_auto(self):
        if self.auto:
            FI.poner(self.dev, self.auto, self.v_auto)
            self.cfg["camara"][self.auto] = self.v_auto
        self.cfg["camara"].pop(self.expo, None)
        self.aviso("Exposicion automatica")

    # ---------------- filtros de software
    def soft(self, clave, lista, signo, etiqueta):
        self.cfg[clave] = paso(self.cfg[clave], lista, signo)
        self.pre.actualizar(self.cfg)
        if clave == "umbral":
            self.det.set_umbral(self.cfg[clave])
        if clave == "min_puntos":
            self.det.min_puntos = int(self.cfg[clave])
        if clave == "relleno":
            self.proyectar(True)
        self.aviso("%s: %s" % (etiqueta, self.cfg[clave]))

    def restaurar(self):
        for n in list(self.cfg["camara"]):
            c = self.ctrls.get(n, {})
            if "default" in c:
                FI.poner(self.dev, n, c["default"])
        cam = {}
        self.cfg = FI.cargar()
        self.cfg.update({k: v for k, v in FI.DEFECTO.items() if k != "camara"})
        self.cfg["camara"] = cam
        self.pre.actualizar(self.cfg)
        self.det.set_umbral(self.cfg["umbral"])
        self.det.min_puntos = self.cfg["min_puntos"]
        self.proyectar(True)
        self.aviso("Todo regreso a como venia (falta M para guardar)")

    def tecla(self, k):
        mapa = {
            ord("q"): lambda: self.exposicion(+1), ord("a"): lambda: self.exposicion(-1),
            ord("w"): lambda: self.ctrl("gain", +1, "Ganancia"), ord("s"): lambda: self.ctrl("gain", -1, "Ganancia"),
            ord("e"): lambda: self.ctrl("brightness", +1, "Brillo"),
            ord("d"): lambda: self.ctrl("brightness", -1, "Brillo"),
            ord("r"): lambda: self.ctrl("contrast", +1, "Contraste"),
            ord("f"): lambda: self.ctrl("contrast", -1, "Contraste"),
            ord("t"): lambda: self.soft("gamma", GAMMAS, +1, "Gamma"),
            ord("g"): lambda: self.soft("gamma", GAMMAS, -1, "Gamma"),
            ord("y"): lambda: self.soft("clahe", CLAHES, +1, "CLAHE"),
            ord("h"): lambda: self.soft("clahe", CLAHES, -1, "CLAHE"),
            ord("u"): lambda: self.soft("saturacion", SATS, +1, "Saturacion"),
            ord("j"): lambda: self.soft("saturacion", SATS, -1, "Saturacion"),
            ord("i"): lambda: self.soft("suavizado", SUAV, +1, "Suavizado"),
            ord("k"): lambda: self.soft("suavizado", SUAV, -1, "Suavizado"),
            ord("o"): lambda: self.soft("recorte", RECORTES, +1, "Recorte"),
            ord("l"): lambda: self.soft("recorte", RECORTES, -1, "Recorte"),
            ord("p"): lambda: self.soft("umbral", UMBRALES, +1, "Umbral"),
            ord("n"): lambda: self.soft("umbral", UMBRALES, -1, "Umbral"),
            241: lambda: self.soft("umbral", UMBRALES, -1, "Umbral"),          # tecla Ñ
            ord("x"): lambda: self.soft("min_puntos", MINPTS, +1, "Puntos minimos"),
            ord("z"): lambda: self.soft("min_puntos", MINPTS, -1, "Puntos minimos"),
            ord("v"): lambda: self.soft("relleno", RELLENOS, +1, "Luz de relleno"),
            ord("c"): lambda: self.soft("relleno", RELLENOS, -1, "Luz de relleno"),
            ord("1"): self.expo_auto,
            ord("0"): self.restaurar,
        }
        if 65 <= k <= 90:   # mayusculas = minusculas
            k = k + 32
        if k in mapa:
            mapa[k]()
            return True
        if k == ord("b"):
            self.vista = (self.vista + 1) % 3
            self.aviso(["Vista: lo que ve el detector", "Vista: camara original", "Vista: lado a lado"][self.vista])
        elif k == ord("m"):
            FI.guardar(self.cfg)
            self.aviso("Guardado en filtros.json (la estacion lo usara al arrancar)")
        return k != 27

    # ---------------- pantalla en la PC
    def valor_ctrl(self, nombre):
        c = self.ctrls.get(nombre)
        if not c:
            return "no disponible"
        v = self.cfg["camara"].get(nombre, c.get("value", "?"))
        return "%s  (%s..%s)" % (v, c.get("min", "?"), c.get("max", "?"))

    def panel(self, alto, info):
        p = np.full((alto, 330, 3), 28, np.uint8)
        c = self.cfg
        if self.expo:
            modo_auto = self.auto and self.cfg["camara"].get(self.auto, self.ctrls.get(self.auto, {}).get("value")) \
                != self.v_manual
            expo = "auto" if modo_auto else str(self.cfg["camara"].get(self.expo, self.ctrls[self.expo].get("value")))
        else:
            expo = "no disponible"
        filas = [
            ("Q/A", "Exposicion", expo),
            ("W/S", "Ganancia", self.valor_ctrl("gain")),
            ("E/D", "Brillo", self.valor_ctrl("brightness")),
            ("R/F", "Contraste", self.valor_ctrl("contrast")),
            ("T/G", "Gamma", c["gamma"]),
            ("Y/H", "CLAHE", c["clahe"]),
            ("U/J", "Saturacion", c["saturacion"]),
            ("I/K", "Suavizado", c["suavizado"]),
            ("O/L", "Recorte", "%d %%" % int(c["recorte"] * 100)),
            ("P/N", "Umbral", c["umbral"]),
            ("X/Z", "Puntos min", c["min_puntos"]),
            ("V/C", "Relleno", c["relleno"]),
        ]
        y = 26
        cv2.putText(p, info, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1, cv2.LINE_AA)
        y += 28
        for tec, nombre, val in filas:
            cv2.putText(p, tec, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 200, 255), 1, cv2.LINE_AA)
            cv2.putText(p, "%s: %s" % (nombre, val), (60, y), cv2.FONT_HERSHEY_SIMPLEX, 0.47, (230, 230, 230), 1,
                        cv2.LINE_AA)
            y += 23
        y += 8
        for t in ("1 expo auto   B vista", "M guardar   0 restaurar", "Esc salir"):
            cv2.putText(p, t, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (150, 150, 150), 1, cv2.LINE_AA)
            y += 20
        if time.time() - self.t_msg < 4:
            cv2.putText(p, self.msg[:38], (10, alto - 14), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (80, 255, 80), 1,
                        cv2.LINE_AA)
        return p

    @staticmethod
    def dibujar(img, manos, dx=0, dy=0):
        for pts, g in manos:
            q = (pts - np.float32([dx, dy])).astype(np.int32)
            for a, b in P.CADENAS_LINKS:
                cv2.line(img, tuple(q[a]), tuple(q[b]), (255, 60, 220), 2, cv2.LINE_AA)
            for k in (4, 8, 12, 16, 20):
                cv2.circle(img, tuple(q[k]), 5, (0, 255, 255), -1, cv2.LINE_AA)
            cv2.putText(img, g or "mano", tuple(q[0] + [0, 18]), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    def correr(self):
        cv2.namedWindow(VENTANA, cv2.WINDOW_AUTOSIZE)
        try:
            self._bucle()
        except KeyboardInterrupt:
            pass
        finally:   # al salir (Esc o Ctrl+C) se guarda solo, para no perder la calibracion
            FI.guardar(self.cfg)
            err("Ajustes guardados en %s" % FI.ARCHIVO)
            self.cam.release()
            cv2.destroyAllWindows()
            if self.salida is not None:
                try:
                    self.salida.cerrar()
                except Exception:
                    pass

    def _bucle(self):
        n, t0, fps = 0, time.time(), 0.0
        while True:
            ok, f = self.cam.read()
            if not ok:
                time.sleep(0.02)
                continue
            entrada, (dx, dy) = self.pre(f)
            manos = [(pts + np.float32([dx, dy]), g) for pts, g in self.det.procesar(entrada)]
            n += 1
            if time.time() - t0 > 1:
                fps, n, t0 = n / (time.time() - t0), 0, time.time()
            if self.vista == 0:
                v = entrada.copy()
                self.dibujar(v, manos, dx, dy)
            else:
                v = f.copy()
                h, w = f.shape[:2]
                x0, y0, x1, y1 = self.pre.recorte(w, h)
                cv2.rectangle(v, (x0, y0), (x1 - 1, y1 - 1), (0, 200, 255), 2)
                self.dibujar(v, manos)
                if self.vista == 2:
                    e = entrada.copy()
                    self.dibujar(e, manos, dx, dy)
                    e = cv2.resize(e, (int(e.shape[1] * v.shape[0] / float(e.shape[0])), v.shape[0]))
                    v = np.hstack([v, e])
            k = self.a.ancho / float(v.shape[1])
            v = cv2.resize(v, (self.a.ancho, int(v.shape[0] * k)))
            info = "manos: %d   %.0f FPS   luz: %.0f" % (len(manos), fps, float(entrada.mean()))
            v = np.hstack([v, self.panel(v.shape[0], info)]) if v.shape[0] >= 420 else \
                np.hstack([cv2.copyMakeBorder(v, 0, 420 - v.shape[0], 0, 0, cv2.BORDER_CONSTANT), self.panel(420, info)])
            cv2.imshow(VENTANA, v)
            self.proyectar()
            k = cv2.waitKey(1) & 0xFF
            if k != 255 and not self.tecla(k):
                break


def main():
    ap = argparse.ArgumentParser(description="Ajuste en vivo de camara y filtros para detectar manos")
    ap.add_argument("--camara", default="0")
    ap.add_argument("--res", default="640x480", help="usa la misma que la estacion (con --ahorro es 640x480)")
    ap.add_argument("--salida", default="fb", choices=["fb", "x11", "auto", "ninguna"],
                    help="donde proyectar la luz de relleno (fb = proyector sin escritorio)")
    ap.add_argument("--ancho", type=int, default=640, help="ancho de la imagen en la ventana")
    a = ap.parse_args()
    if not os.environ.get("DISPLAY"):
        raise SystemExit("No hay DISPLAY: correlo desde MobaXterm (SSH con X11) para ver la ventana en tu PC.")
    Ajustador(a).correr()


if __name__ == "__main__":
    main()
