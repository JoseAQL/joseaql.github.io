# -*- coding: utf-8 -*-
"""
modos_arte.py - Modos visuales inspirados en piezas de TouchDesigner.

  Cortina   lineas verticales que empujas con la mano y vibran con la musica (estilo "Audio Curtain")
  Flor      plantas que crecen (L-system) segun pellizco: una mano = crecer, otra = florecer
  Imagen    una foto de la camara convertida en particulas que esquivan tu mano y explotan con el bombo
  Cubo      cubo 3D en alambre que gira con tu mano y late con los graves, con glitch en el bombo
  Centellas listón de particulas brillantes que sale de tu mano y fluye (estilo "Something Scintillant")
"""
import math
import random
import time

import cv2
import numpy as np

import modos_base as B


def _A(ctx):
    if ctx.A is None:
        return {"nivel": 0.0, "graves": 0.0, "medios": 0.0, "agudos": 0.0, "kick": False, "snare": False,
                "espectro": np.zeros(32, np.float32), "onda": np.zeros(512, np.float32)}
    return ctx.A


# ====================================================================== cortina de audio
class Cortina(B.Modo):
    nombre = "Cortina de audio"
    descripcion = "Empuja las lineas"
    NL, NP = 44, 26

    def entrar(self):
        self.x0 = np.linspace(14, self.w - 14, self.NL).astype(np.float32)
        self.y = np.linspace(0, self.h, self.NP).astype(np.float32)
        self.dx = np.zeros((self.NL, self.NP), np.float32)
        self.v = np.zeros_like(self.dx)
        self.prev = []

    def actualizar(self, ctx):
        A = _A(ctx)
        dt = min(ctx.dt, 0.06)
        X = self.x0[:, None] + self.dx
        Y = np.broadcast_to(self.y[None, :], X.shape)
        fuerza = np.zeros_like(self.dx)
        # empuje de las manos (puntas y palma), mas fuerte si la mano se mueve
        puntos = list(ctx.puntas) + [(float(p[9][0]), float(p[9][1])) for p, _ in ctx.manos]
        for (px, py) in puntos:
            ddx = X - px
            d2 = ddx ** 2 + (Y - py) ** 2
            fuerza += np.sign(ddx) * 2.2e6 / (d2 + 900) * np.exp(-d2 / 9000.0)
        # musica: cada linea vibra con su banda del espectro
        e = A["espectro"]
        banda = e[(np.arange(self.NL) * len(e) // self.NL) % len(e)][:, None]
        fase = ctx.t * 9 + self.y[None, :] * 0.05 + np.arange(self.NL)[:, None] * 0.4
        fuerza += banda * 500 * np.sin(fase)
        if A["kick"]:
            self.v += np.random.randn(self.NL, 1).astype(np.float32) * 35
        # resorte
        self.v += (fuerza - 40 * self.dx - 7 * self.v) * dt
        self.dx += self.v * dt
        self.dx = np.clip(self.dx, -120, 120)
        self.dx[:, 0] *= 0.5
        img = np.zeros((self.h, self.w, 3), np.uint8)
        X = self.x0[:, None] + self.dx
        for i in range(self.NL):
            pts = np.int32(np.stack([X[i], self.y], 1))[:, None]
            g = 150 + int(100 * min(1, abs(self.dx[i]).max() / 60))
            cv2.polylines(img, [pts], False, (g, g, min(255, g + 30)), 1, cv2.LINE_AA)
        return B.brillo(img, 3, 0.8)

    @staticmethod
    def icono(img, x, y, w, h, t):
        for i in range(10):
            xx = x + 12 + i * (w - 24) / 9.0
            pts = [(int(xx + 10 * math.sin(t * 2 + i * 0.6 + k * 0.5) * (1 if 3 < i < 7 else 0.3)), y + 10 + k * (h - 20) // 8)
                   for k in range(9)]
            cv2.polylines(img, [np.int32(pts)[:, None]], False, (230, 230, 230), 1, cv2.LINE_AA)


# ====================================================================== flor interactiva (L-system)
class Flor(B.Modo):
    nombre = "Flor interactiva"
    descripcion = "Pellizca: crecer y florecer"

    def entrar(self):
        self.crecer, self.florecer = 0.3, 0.2
        random.seed(7)
        self.semilla = [random.uniform(-0.35, 0.35) for _ in range(64)]

    def _rama(self, img, x, y, ang, largo, nivel, k, puntas):
        if nivel == 0 or largo < 4:
            puntas.append((x, y, ang))
            return k
        x2 = x + math.cos(ang) * largo
        y2 = y - math.sin(ang) * largo
        cv2.line(img, (int(x), int(y)), (int(x2), int(y2)), (255, 160, 60), max(1, nivel // 2), cv2.LINE_AA)
        abre = 0.45 + self.semilla[k % 64] * 0.4
        k = self._rama(img, x2, y2, ang + abre, largo * 0.72, nivel - 1, k + 1, puntas)
        k = self._rama(img, x2, y2, ang - abre * 0.9, largo * 0.68, nivel - 1, k + 2, puntas)
        return k

    def _petalos(self, img, x, y, ang, r, t, i):
        if r < 3:
            return
        n = 7
        for p in range(n):
            a = ang + p * 2 * math.pi / n + math.sin(t + i) * 0.1
            tip = (x + math.cos(a) * r * 1.6, y - math.sin(a) * r * 1.6)
            l1 = (x + math.cos(a + 0.35) * r * 0.7, y - math.sin(a + 0.35) * r * 0.7)
            l2 = (x + math.cos(a - 0.35) * r * 0.7, y - math.sin(a - 0.35) * r * 0.7)
            poli = np.int32([(x, y), l1, tip, l2])
            cv2.fillConvexPoly(img, poli, (60, 150 + p * 10, 255), cv2.LINE_AA)
        cv2.circle(img, (int(x), int(y)), max(2, int(r * 0.35)), (40, 220, 255), -1, cv2.LINE_AA)

    def actualizar(self, ctx):
        A = _A(ctx)
        img = np.zeros((self.h, self.w, 3), np.uint8)
        # control: distancia pulgar-indice (como "Grow: 0.37  Bloom: 0.27")
        valores = []
        for pts, _ in ctx.manos:
            esc = max(30.0, float(np.hypot(*(pts[0] - pts[9]))))
            d = float(np.hypot(*(pts[4] - pts[8]))) / (esc * 1.4)
            valores.append((min(1.0, max(0.0, d)), pts))
        if valores:
            self.crecer += (valores[0][0] - self.crecer) * 0.2
        if len(valores) > 1:
            self.florecer += (valores[1][0] - self.florecer) * 0.2
        else:
            self.florecer += (min(1.0, 0.15 + A["nivel"]) - self.florecer) * 0.1
        t = ctx.t
        for j, bx in enumerate((self.w * 0.3, self.w * 0.55, self.w * 0.78)):
            puntas = []
            nivel = 2 + int(self.crecer * 5)
            largo = 40 + 70 * self.crecer
            self._rama(img, bx, self.h - 10, math.pi / 2 + math.sin(t * 0.5 + j) * 0.08, largo, nivel, j * 9, puntas)
            for i, (x, y, ang) in enumerate(puntas):
                self._petalos(img, x, y, ang, (4 + 12 * self.florecer) * (1 + 0.6 * A["graves"]), t, i)
        for (v, pts), nombre in zip(valores, ("Crecer", "Florecer")):
            p4, p8 = pts[4].astype(int), pts[8].astype(int)
            cv2.line(img, tuple(p4), tuple(p8), (180, 120, 255), 3, cv2.LINE_AA)
            B.texto(img, "%s: %.2f" % (nombre, v), p8[0] + 10, p8[1], 0.55, (180, 120, 255))
        if not valores:
            B.texto(img, "Abre y cierra pulgar e indice para que crezca", self.w / 2, 40, 0.55, B.BLANCO, True)
        return B.brillo(img, 6, 0.9)

    @staticmethod
    def icono(img, x, y, w, h, t):
        cx, by = x + w // 2, y + h - 10
        cv2.line(img, (cx, by), (cx, by - h // 2), (255, 160, 60), 2)
        for a in (-0.6, 0.6):
            x2, y2 = int(cx + math.sin(a) * h * 0.3), int(by - h // 2 - math.cos(a) * h * 0.25)
            cv2.line(img, (cx, by - h // 2), (x2, y2), (255, 160, 60), 2)
            cv2.circle(img, (x2, y2), 8 + int(3 * math.sin(t * 3)), (60, 170, 255), -1)


# ====================================================================== imagen a particulas
class ImagenParticulas(B.Modo):
    nombre = "Imagen a particulas"
    descripcion = "Pellizca para tomar foto"
    usa_frame = True
    N = 2600

    def entrar(self):
        self.listo = False
        self.t_foto = 0
        self._objetivo_texto()

    def _objetivo_texto(self):
        lienzo = np.zeros((self.h, self.w), np.uint8)
        cv2.putText(lienzo, "ASESOR", (60, self.h // 2 + 40), cv2.FONT_HERSHEY_SIMPLEX, 3.2, 255, 18)
        self._desde_mascara(lienzo, None)

    def _desde_mascara(self, mascara, colores):
        ys, xs = np.nonzero(mascara > 60)
        if len(xs) < 50:
            return
        idx = np.random.choice(len(xs), self.N, replace=len(xs) < self.N)
        self.obj = np.stack([xs[idx], ys[idx]], 1).astype(np.float32)
        if colores is None:
            self.col = np.tile(np.float32([255, 120, 60]), (self.N, 1))
        else:
            self.col = colores[ys[idx], xs[idx]].astype(np.float32)
            self.col = np.clip(self.col * 1.6 + 30, 0, 255)
        if not self.listo:
            self.pos = np.random.rand(self.N, 2).astype(np.float32) * np.float32([self.w, self.h])
            self.vel = np.zeros_like(self.pos)
            self.listo = True

    def foto(self, ctx):
        if ctx.frame is None or ctx.H_frame is None:
            return
        vista = cv2.warpPerspective(ctx.frame, ctx.H_frame, (self.w, self.h))
        gris = cv2.cvtColor(vista, cv2.COLOR_BGR2GRAY)
        bordes = cv2.Canny(cv2.GaussianBlur(gris, (5, 5), 0), 40, 110)
        bordes = cv2.dilate(bordes, np.ones((2, 2), np.uint8))
        self._desde_mascara(bordes, vista)

    def actualizar(self, ctx):
        A = _A(ctx)
        for i, g, tipo in ctx.eventos:
            if g == "pellizco" and tipo == "nuevo" and ctx.t - self.t_foto > 2:
                self.t_foto = ctx.t
                self.foto(ctx)
        dt = min(ctx.dt, 0.06)
        pos, vel = self.pos, self.vel
        acc = (self.obj - pos) * (6 + 6 * A["medios"])
        for (px, py) in ctx.puntas + [(float(p[9][0]), float(p[9][1])) for p, _ in ctx.manos]:
            d = pos - np.float32([px, py])
            d2 = (d ** 2).sum(1)[:, None] + 1
            acc += d / np.sqrt(d2) * (4e5 / (d2 + 400)) * (d2 < 9000)
        if A["kick"]:
            c = np.float32([self.w / 2, self.h / 2])
            d = pos - c
            vel += d / (np.sqrt((d ** 2).sum(1))[:, None] + 1) * (150 + 300 * A["graves"])
        vel *= 0.86
        vel += acc * dt
        pos += vel * dt
        img = np.zeros((self.h, self.w, 3), np.uint8)
        xi = np.clip(pos[:, 0].astype(np.int32), 0, self.w - 1)
        yi = np.clip(pos[:, 1].astype(np.int32), 0, self.h - 1)
        img[yi, xi] = self.col.astype(np.uint8)
        img = cv2.dilate(img, np.ones((2, 2), np.uint8))
        if ctx.t - self.t_foto < 1.0:
            B.texto(img, "FOTO", self.w / 2, 40, 1.0, B.BLANCO, True)
        return B.brillo(img, 3, 0.8)

    @staticmethod
    def icono(img, x, y, w, h, t):
        rnd = np.random.RandomState(3)
        for _ in range(120):
            a, r = rnd.rand() * 6.28, rnd.rand() ** 0.5 * min(w, h) * 0.38 * (1 + 0.1 * math.sin(t * 3))
            cv2.circle(img, (int(x + w / 2 + math.cos(a) * r), int(y + h / 2 + math.sin(a) * r)), 1, (255, 140, 80), -1)


# ====================================================================== cubo 3D
class Cubo(B.Modo):
    nombre = "Cubo 3D"
    descripcion = "Gira con la mano"

    def entrar(self):
        v = [(x, y, z) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
        self.V = np.float32(v)
        self.E = [(a, b) for a in range(8) for b in range(a + 1, 8) if np.sum(np.abs(self.V[a] - self.V[b])) == 2]
        self.ax = self.ay = 0.0
        self.buf = np.zeros((self.h, self.w, 3), np.float32)
        self.glitch = 0.0

    def _proyectar(self, V, cx, cy, esc):
        z = V[:, 2] + 4.0
        return np.stack([cx + V[:, 0] * esc / z * 4, cy + V[:, 1] * esc / z * 4], 1)

    def actualizar(self, ctx):
        A = _A(ctx)
        dt = ctx.dt
        cx, cy = self.w / 2.0, self.h / 2.0
        if ctx.manos:
            p = ctx.manos[0][0][9]
            self.ay += ((p[0] - cx) / self.w * 6 - self.ay) * 0.08
            self.ax += ((p[1] - cy) / self.h * 6 - self.ax) * 0.08
        else:
            self.ay += dt * (0.4 + 2.0 * A["medios"])
            self.ax += dt * 0.25
        if A["kick"]:
            self.glitch = 1.0
        esc = 70 + 70 * A["graves"]
        Ry = np.float32([[math.cos(self.ay), 0, math.sin(self.ay)], [0, 1, 0], [-math.sin(self.ay), 0, math.cos(self.ay)]])
        Rx = np.float32([[1, 0, 0], [0, math.cos(self.ax), -math.sin(self.ax)], [0, math.sin(self.ax), math.cos(self.ax)]])
        self.buf *= 0.78
        for s, col in ((1.0, (255, 80, 200)), (0.55, (255, 200, 120))):
            P = self._proyectar((self.V * s) @ Rx.T @ Ry.T, cx, cy, esc)
            for a, b in self.E:
                cv2.line(self.buf, (int(P[a][0]), int(P[a][1])), (int(P[b][0]), int(P[b][1])), col, 2, cv2.LINE_AA)
        img = np.clip(self.buf, 0, 255).astype(np.uint8)
        if self.glitch > 0.05:   # glitch: bandas corridas
            for _ in range(int(6 * self.glitch)):
                y0 = random.randrange(0, self.h - 20)
                hh = random.randrange(4, 20)
                img[y0:y0 + hh] = np.roll(img[y0:y0 + hh], random.randrange(-40, 40), axis=1)
            self.glitch *= 0.75
        return B.brillo(img, 6, 1.0)

    @staticmethod
    def icono(img, x, y, w, h, t):
        cx, cy, r = x + w / 2, y + h / 2, min(w, h) * 0.22
        a = t
        pts = [(cx + r * math.cos(a + k * 1.5708) * 1.2, cy + r * math.sin(a + k * 1.5708) * 0.6 - r * 0.4) for k in range(4)]
        pts2 = [(px, py + r * 1.1) for px, py in pts]
        for k in range(4):
            for P in (pts, pts2):
                cv2.line(img, (int(P[k][0]), int(P[k][1])), (int(P[(k + 1) % 4][0]), int(P[(k + 1) % 4][1])), (255, 80, 200), 1)
            cv2.line(img, (int(pts[k][0]), int(pts[k][1])), (int(pts2[k][0]), int(pts2[k][1])), (255, 80, 200), 1)


# ====================================================================== centellas
class Centellas(B.Modo):
    nombre = "Centellas"
    descripcion = "Particulas brillantes"
    MAX = 2500

    def entrar(self):
        self.p = np.zeros((0, 5), np.float32)   # x, y, vx, vy, vida
        self.buf = np.zeros((self.h, self.w), np.float32)
        self.lut = B.colormap_lut("COLORMAP_HOT")

    def actualizar(self, ctx):
        A = _A(ctx)
        dt = min(ctx.dt, 0.06)
        t = ctx.t
        # emisores: puntas de dedos; sin manos, un liston que cruza la pantalla
        if ctx.puntas:
            emisores = ctx.puntas
        else:
            xs = np.linspace(0, self.w, 12)
            emisores = [(x, self.h * 0.55 + math.sin(x * 0.012 + t * 1.5) * 80) for x in xs]
        n = int((40 + 260 * A["nivel"]) * dt * 10) + (150 if A["kick"] else 0)
        if n > 0:
            e = np.float32(emisores)[np.random.randint(len(emisores), size=n)]
            nuevos = np.zeros((n, 5), np.float32)
            nuevos[:, :2] = e + np.random.randn(n, 2).astype(np.float32) * 6
            nuevos[:, 2] = 120 + np.random.randn(n) * 60
            nuevos[:, 3] = np.random.randn(n) * 50 - 30
            nuevos[:, 4] = 1.0 + np.random.rand(n) * 1.2
            self.p = np.vstack([self.p, nuevos])[-self.MAX:]
        p = self.p
        if len(p):
            # campo de flujo (ondas)
            ang = np.sin(p[:, 0] * 0.01 + t) + np.cos(p[:, 1] * 0.013 - t * 0.7)
            p[:, 2] += np.cos(ang * 2) * 90 * dt
            p[:, 3] += np.sin(ang * 2) * 90 * dt
            p[:, 0] += p[:, 2] * dt
            p[:, 1] += p[:, 3] * dt
            p[:, 4] -= dt
            self.p = p = p[(p[:, 4] > 0) & (p[:, 0] > -10) & (p[:, 0] < self.w + 10) & (p[:, 1] > -10) & (p[:, 1] < self.h + 10)]
        self.buf *= 0.55
        if len(p):
            xi = np.clip(p[:, 0].astype(np.int32), 0, self.w - 1)
            yi = np.clip(p[:, 1].astype(np.int32), 0, self.h - 1)
            destello = np.random.rand(len(p)) ** 3 * 255 * np.minimum(1, p[:, 4])   # titilan
            np.maximum.at(self.buf, (yi, xi), destello.astype(np.float32))
        brillo = cv2.GaussianBlur(self.buf, (0, 0), 2) * 3 + self.buf
        mapa = np.clip(brillo, 0, 255).astype(np.uint8)
        img = cv2.applyColorMap(mapa, cv2.COLORMAP_HOT)
        img[mapa < 6] = 0
        return img

    @staticmethod
    def icono(img, x, y, w, h, t):
        rnd = np.random.RandomState(int(t * 8) % 4294967296)
        for k in range(60):
            xx = x + 10 + k * (w - 20) / 60.0
            yy = y + h / 2 + math.sin(xx * 0.05 + t * 2) * h * 0.25 + rnd.randn() * 6
            cv2.circle(img, (int(xx), int(yy)), 1, (80, 120, 255) if rnd.rand() > 0.3 else (255, 255, 255), -1)
