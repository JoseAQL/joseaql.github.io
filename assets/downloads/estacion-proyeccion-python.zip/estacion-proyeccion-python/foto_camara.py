#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
foto_camara.py - Prueba rapida de la camara: toma una foto y la guarda (sirve para ver si la camara
ve la proyeccion completa). Funciona en Raspberry y Jetson, con o sin escritorio.

  python3 foto_camara.py                  -> camara 0 a 1280x720, guarda foto_camara.jpg
  python3 foto_camara.py --camara 1 --res 640x360
"""
from __future__ import print_function

import argparse
import time

import cv2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--camara", default="0")
    ap.add_argument("--res", default="1280x720")
    ap.add_argument("--salida", default="foto_camara.jpg")
    ap.add_argument("--n", type=int, default=20, help="cuadros para que se ajuste la exposicion")
    a = ap.parse_args()
    w, h = [int(v) for v in a.res.lower().split("x")]
    dev = int(a.camara) if a.camara.isdigit() else a.camara
    cap = cv2.VideoCapture(dev, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
    if not cap.isOpened():
        raise SystemExit("No se pudo abrir la camara %s" % a.camara)
    f, n_ok, t0 = None, 0, time.time()
    for _ in range(a.n):
        ok, img = cap.read()
        if ok:
            f, n_ok = img, n_ok + 1
    dt = time.time() - t0
    cap.release()
    if f is None:
        raise SystemExit("La camara abrio pero no entrego imagen")
    cv2.imwrite(a.salida, f)
    print("OK camara %s: %dx%d, %d cuadros en %.1f s (%.0f FPS) -> %s"
          % (a.camara, f.shape[1], f.shape[0], n_ok, dt, n_ok / max(dt, 1e-3), a.salida))
    print("Brillo promedio: %.0f / 255" % f.mean())


if __name__ == "__main__":
    main()
