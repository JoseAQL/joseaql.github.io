# Estación de proyección en Python (Jetson Nano y Raspberry Pi)

Proyector y cámara sobre la mesa. Al iniciar se calibra con 4 marcadores proyectados en las esquinas, muestra un menú proyectado y se juega con las manos. El mismo código corre en la Jetson Nano (manos con poseNet en la GPU) y en la Raspberry Pi 4 (manos con MediaPipe); `plataforma.py` detecta en cuál está.

Modos: Manos, Video reactivo, Rave musical, Piano Tiles, Piano libre, Cortina de audio, Flor interactiva, Imagen a partículas, Cubo 3D, Centellas, Recalibrar y Salir.

La versión rápida en C++ de esta misma estación está en **[../estacion-jetson-cpp](../estacion-jetson-cpp/)**.

## Versiones

Cada versión nueva se guarda con su número en esta misma carpeta. La versión anterior nunca se borra.

| Versión | Archivo | Qué cambió |
|---|---|---|
| v1 | `estacion.py` | Estación completa: calibración con ArUco, menú proyectado, todos los modos, efectos con audio y modo ahorro. |
| **v2 (vigente)** | `estacion2.py` | Usa la v1 sin cambiarla y le agrega una ventana por SSH con la cámara y un panel de ajustes en vivo (exposición, contraste, gamma, CLAHE…), filtro pasa-bajas para el micrófono y el botón MENU solo con el dedo índice. |

> Estas copias son las de esta conversación (7 de octubre). La que tienes en la Jetson puede ser un poco distinta.

## Cómo correrla

- Jetson: **[GUIA_JETSON.md](GUIA_JETSON.md)**.
- Raspberry Pi: **[GUIA_RASPBERRY.md](GUIA_RASPBERRY.md)**.

Las guías usan la carpeta `~/asesor` en la placa; en tu Jetson la tienes como `~/estacion`, y funciona igual.

```bash
python3 estacion2.py --salida fb --ahorro     # la v2, con ventana de ajustes por SSH
python3 estacion.py --salida fb --ahorro      # la v1
```

## Archivos

| Archivo | Para qué |
|---|---|
| `estacion.py`, `estacion2.py` | Programa principal (v1 y v2) |
| `plataforma.py` | Detecta si es Jetson o Raspberry y ajusta cámara, detector y salida |
| `hdmi_manos.py` | Calibración con marcadores y detección de manos |
| `hdmi_reactivo.py`, `efectos_audio.py` | Video reactivo y efectos con el micrófono |
| `modos_base.py`, `modos_arte.py`, `modos_juegos.py` | Los modos del menú |
| `filtros.py`, `ajustar_camara.py`, `filtros_jetson.json` | Ajustes de la cámara para ver mejor las manos |
| `probar_camara.py`, `ver_camara.py`, `foto_camara.py`, `prueba_calibracion.py` | Pruebas de cámara y calibración |
| `instalar_jetson.sh`, `instalar_raspberry.sh`, `instalar_pi.sh` | Instalación |
| `iniciar_estacion.sh`, `estacion_args.txt`, `bajo_consumo.sh` | Arranque automático, opciones y modo de bajo consumo |
