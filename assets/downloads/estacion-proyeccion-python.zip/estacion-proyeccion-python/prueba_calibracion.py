#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prueba_calibracion.py - Proyecta los 4 marcadores de calibracion, toma una foto con la camara y guarda
foto_calibracion.jpg con los marcadores que encontro dibujados. Sirve para acomodar la camara.

  python3 prueba_calibracion.py                 (sin escritorio: dibuja directo al HDMI)
  python3 prueba_calibracion.py --salida x11    (con escritorio)
  python3 prueba_calibracion.py --res 1280x720 --escala 0.4
"""
from __future__ import print_function

import argparse
import os
import time

if os.path.exists("/etc/nv_tegra_release"):
    os.environ.setdefault("OPENBLAS_CORETYPE", "ARMV8")

import cv2

import hdmi_manos as HM
import plataforma as P


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--camara", default="0")
    ap.add_argument("--res", default="640x360")
    ap.add_argument("--salida", default="auto", choices=["auto", "fb", "x11"])
    ap.add_argument("--escala", type=float, default=0.30, help="tamano de los marcadores (0.30 = 30%% del alto)")
    ap.add_argument("--margen", type=float, default=None, help="separacion de la orilla (ej. 0.10 = 10%% del alto)")
    ap.add_argument("--segundos", type=float, default=3.0)
    a = ap.parse_args()
    salida = HM.abrir_salida(a.salida, 480)
    detectar, gen = HM.aruco()
    img, esq = HM.lienzo_marcadores(salida.w, salida.h, gen, escala=a.escala, margen=a.margen)
    salida.mostrar(img)
    cam = P.Camara(a.camara, a.res)
    t0, mejor, mejor_n, f = time.time(), None, -1, None
    while time.time() - t0 < a.segundos:
        salida.mostrar(img)
        ok, f = cam.read()
        if not ok:
            continue
        c, ids, _ = detectar(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
        n = 0 if ids is None else len(ids)
        if n > mejor_n:
            mejor, mejor_n = (f.copy(), c, ids), n
    cam.release()
    if mejor is None:
        print("La camara no entrego imagen")
        return
    f, c, ids = mejor
    vistos = sorted(int(i) for i in ids.flatten()) if ids is not None else []
    v = f.copy()
    if ids is not None:
        cv2.aruco.drawDetectedMarkers(v, c, ids)
    cv2.putText(v, "vistos: %s" % (vistos or "ninguno"), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
    cv2.imwrite("foto_calibracion.jpg", v)
    print("Camara %dx%d | marcadores vistos: %s (se necesitan al menos 3 de [0, 1, 2, 3]) -> foto_calibracion.jpg"
          % (f.shape[1], f.shape[0], vistos or "ninguno"))
    print("Brillo promedio de la foto: %.0f / 255" % f.mean())
    try:
        salida.cerrar()
    except Exception:
        pass


if __name__ == "__main__":
    main()
