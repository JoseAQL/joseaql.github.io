#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ver_camara.py - Ver la camara en vivo en una ventana (para acomodarla y que vea toda la proyeccion).
Por MobaXterm la ventana aparece en tu PC (X11). Si OpenCV trae ArUco, marca los marcadores que ve.

  python3 ver_camara.py                -> camara 0
  python3 ver_camara.py --camara 1
Teclas: q o Esc = salir, s = guardar foto (foto_camara.jpg)
"""
from __future__ import print_function

import argparse
import time

import cv2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--camara", default="0")
    ap.add_argument("--res", default="1280x720")
    ap.add_argument("--ancho", type=int, default=800, help="ancho de la ventana")
    a = ap.parse_args()
    w, h = [int(v) for v in a.res.lower().split("x")]
    dev = int(a.camara) if a.camara.isdigit() else a.camara
    cap = cv2.VideoCapture(dev, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
    detectar = None
    if hasattr(cv2, "aruco"):
        try:
            import hdmi_manos as HM
            detectar, _ = HM.aruco()
        except Exception:
            detectar = None
    n, t0, fps = 0, time.time(), 0.0
    while True:
        ok, f = cap.read()
        if not ok:
            time.sleep(0.05)
            continue
        n += 1
        if time.time() - t0 > 1:
            fps, n, t0 = n / (time.time() - t0), 0, time.time()
        v = f.copy()
        txt = "%dx%d  %.0f FPS" % (f.shape[1], f.shape[0], fps)
        if detectar is not None:
            esq, ids, _ = detectar(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
            vistos = sorted(int(i) for i in ids.flatten()) if ids is not None else []
            if ids is not None:
                cv2.aruco.drawDetectedMarkers(v, esq, ids)
            txt += "  marcadores: %s" % (vistos or "ninguno")
        k = a.ancho / float(v.shape[1])
        v = cv2.resize(v, (a.ancho, int(v.shape[0] * k)))
        cv2.putText(v, txt, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(v, txt, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2, cv2.LINE_AA)
        cv2.imshow("Camara (q = salir, s = foto)", v)
        tecla = cv2.waitKey(1) & 0xFF
        if tecla in (ord("q"), 27):
            break
        if tecla == ord("s"):
            cv2.imwrite("foto_camara.jpg", f)
            print("Foto guardada: foto_camara.jpg")
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
