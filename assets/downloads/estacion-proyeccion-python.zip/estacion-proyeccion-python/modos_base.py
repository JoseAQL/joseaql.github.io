# -*- coding: utf-8 -*-
"""
modos_base.py - Piezas comunes para los modos de la estacion (estacion.py).

Cada modo es una clase con:
    nombre, descripcion          textos del menu
    icono(img, x, y, w, h, t)    dibuja su icono en el mosaico del menu
    entrar()                     se llama al abrirlo
    actualizar(ctx) -> imagen    imagen BGR del tamano del HDMI
ctx (Contexto) trae manos, puntas de dedos, gestos, audio, camara y tiempo.
"""
import math
import os
import re
import subprocess
import tempfile
import time
import wave

import cv2
import numpy as np

PUNTAS = (4, 8, 12, 16, 20)
CONEX = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10), (10, 11), (11, 12),
         (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]

# colores BGR
BLANCO, GRIS, NEGRO = (255, 255, 255), (110, 110, 110), (0, 0, 0)
CIAN, MAGENTA, AMARILLO = (255, 220, 0), (255, 60, 230), (0, 230, 255)
VERDE, ROJO, NARANJA = (80, 255, 80), (60, 60, 255), (40, 150, 255)


class Contexto(object):
    def __init__(self):
        self.t = time.time()
        self.dt = 0.04
        self.w, self.h = 640, 480
        self.manos = []        # [(pts 21x2 en pixeles HDMI, gesto)]
        self.puntas = []       # [(x, y)] de todas las puntas de dedos
        self.indices = []      # [(x, y)] punta del indice de cada mano
        self.eventos = []      # [(mano, gesto, "nuevo" | "1s")]
        self.A = None          # audio: dict de efectos_audio.audio_vacio()
        self.frame = None      # camara chica (BGR) o None
        self.H_frame = None    # homografia camara chica -> HDMI


class Modo(object):
    nombre = "Modo"
    descripcion = ""
    usa_frame = False

    def __init__(self, app):
        self.app = app
        self.w, self.h = app.w, app.h

    def entrar(self):
        pass

    def actualizar(self, ctx):
        return np.zeros((self.h, self.w, 3), np.uint8)

    @staticmethod
    def icono(img, x, y, w, h, t):
        cv2.circle(img, (x + w // 2, y + h // 2), min(w, h) // 4, GRIS, 2, cv2.LINE_AA)


# ------------------------------------------------------------------ dibujo
def texto(img, t, x, y, esc=0.6, col=BLANCO, centro=False, grosor=2):
    (tw, th), _ = cv2.getTextSize(t, cv2.FONT_HERSHEY_SIMPLEX, esc, grosor)
    if centro:
        x = int(x - tw / 2)
    cv2.putText(img, t, (int(x), int(y)), cv2.FONT_HERSHEY_SIMPLEX, esc, NEGRO, grosor + 3, cv2.LINE_AA)
    cv2.putText(img, t, (int(x), int(y)), cv2.FONT_HERSHEY_SIMPLEX, esc, col, grosor, cv2.LINE_AA)
    return tw


def brillo(img, sigma=5, fuerza=1.0):
    """Resplandor tipo neon (bloom)."""
    return cv2.addWeighted(img, 1.0, cv2.GaussianBlur(img, (0, 0), sigma), fuerza, 0)


def esqueleto(img, manos, col=(255, 255, 255), grosor=1):
    for pts, _ in manos:
        p = pts.astype(np.int32)
        for a, b in CONEX:
            cv2.line(img, (int(p[a][0]), int(p[a][1])), (int(p[b][0]), int(p[b][1])), col, grosor, cv2.LINE_AA)
        for k in PUNTAS:
            cv2.circle(img, (int(p[k][0]), int(p[k][1])), 4, col, -1, cv2.LINE_AA)


def colormap_lut(nombre):
    cm = getattr(cv2, nombre, cv2.COLORMAP_JET)
    return cv2.applyColorMap(np.arange(256, dtype=np.uint8)[:, None], cm)[:, 0]


def color_de(lut, v):
    c = lut[int(min(1.0, max(0.0, v)) * 255)]
    return (int(c[0]), int(c[1]), int(c[2]))


# ------------------------------------------------------------------ sonido (notas)
NOTAS = {"C4": 261.63, "D4": 293.66, "E4": 329.63, "F4": 349.23, "G4": 392.00, "A4": 440.00, "B4": 493.88,
         "C5": 523.25, "D5": 587.33, "E5": 659.25, "F5": 698.46, "G5": 783.99, "A5": 880.00, "B5": 987.77,
         "C6": 1046.5, "FALLA": 110.0}


def buscar_salida_audio():
    """Salida de audio: la del adaptador USB si existe (para audifonos/bocina), si no la de la Raspberry."""
    try:
        sal = subprocess.check_output(["aplay", "-l"], stderr=subprocess.STDOUT).decode("utf-8", "ignore")
    except Exception:
        return None
    for c, nombre, d in re.findall(r"card (\d+): ([^\n]*?), device (\d+)", sal):
        if "usb" in nombre.lower() and "cam" not in nombre.lower():
            return "plughw:%s,%s" % (c, d)
    return "default"


class Sonido(object):
    """Notas tipo piano generadas al iniciar y tocadas con aplay sin bloquear."""

    def __init__(self, dispositivo="auto", activo=True):
        self.activo = activo and bool(subprocess.call(["which", "aplay"], stdout=subprocess.DEVNULL) == 0)
        self.dev = buscar_salida_audio() if dispositivo == "auto" else dispositivo
        self.dir = os.path.join(tempfile.gettempdir(), "estacion_notas")
        self.procesos = []
        if not self.activo:
            return
        os.makedirs(self.dir, exist_ok=True)
        sr = 22050
        for n, f in NOTAS.items():
            ruta = os.path.join(self.dir, n + ".wav")
            if os.path.exists(ruta):
                continue
            dur = 0.25 if n == "FALLA" else 0.9
            t = np.arange(int(sr * dur)) / float(sr)
            env = np.exp(-t * (8 if n == "FALLA" else 4.5)) * np.minimum(1, t / 0.005)
            y = (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(4 * np.pi * f * t) + 0.2 * np.sin(6 * np.pi * f * t))
            if n == "FALLA":
                y = np.sign(np.sin(2 * np.pi * f * t))
            datos = (y / 1.7 * env * 0.6 * 32767).astype(np.int16)
            w = wave.open(ruta, "wb")
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(sr)
            w.writeframes(datos.tobytes())
            w.close()

    def tocar(self, nota):
        if not self.activo or nota not in NOTAS:
            return
        self.procesos = [p for p in self.procesos if p.poll() is None]
        if len(self.procesos) > 5:
            return
        cmd = ["aplay", "-q"] + (["-D", self.dev] if self.dev else []) + [os.path.join(self.dir, nota + ".wav")]
        try:
            self.procesos.append(subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except Exception:
            self.activo = False


# ------------------------------------------------------------------ toques (punta entra a un rectangulo)
class Toques(object):
    """Detecta cuando una punta de dedo ENTRA a un rectangulo (como un toque)."""

    def __init__(self, enfriar=0.25):
        self.dentro = {}
        self.ultimo = {}
        self.enfriar = enfriar

    def revisar(self, puntas, rects, t):
        """puntas: [(x,y)]; rects: {clave: (x0,y0,x1,y1)}. Regresa claves tocadas este cuadro y las ocupadas."""
        ocupadas = set()
        for clave, (x0, y0, x1, y1) in rects.items():
            for (x, y) in puntas:
                if x0 <= x <= x1 and y0 <= y <= y1:
                    ocupadas.add(clave)
                    break
        tocadas = []
        for clave in ocupadas:
            if not self.dentro.get(clave) and t - self.ultimo.get(clave, 0) > self.enfriar:
                tocadas.append(clave)
                self.ultimo[clave] = t
        self.dentro = {c: (c in ocupadas) for c in rects}
        return tocadas, ocupadas
