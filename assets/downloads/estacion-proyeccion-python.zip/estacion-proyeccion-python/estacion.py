#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
estacion.py - Lanzador de la estacion de proyeccion. Funciona igual en Raspberry Pi 4 y en Jetson Nano
(detecta sola la plataforma; ver plataforma.py).

Al arrancar:
  1. CALIBRA siempre con 4 marcadores proyectados en las esquinas.
  2. Muestra un MENU proyectado con mosaicos e iconos. Para abrir uno: deja el dedo indice
     encima 1.5 s (se llena la barra) o haz un pellizco sobre el mosaico.
  3. En cualquier modo, el boton MENU de la esquina superior izquierda (dedo encima 1.5 s) regresa al menu.

  python3 estacion.py                 normal
  python3 estacion.py --mic plughw:4,0
  python3 estacion.py --modo piano    abrir directo un modo (piano, cortina, flor, rave...)
  python3 estacion.py --camara csi    camara CSI de la Jetson (por defecto la USB 0)
  python3 estacion.py --salida fb     forzar framebuffer (sin escritorio) o --salida x11 (ventana completa)
Raspberry: manos con MediaPipe (CPU), salida al framebuffer.
Jetson:    manos con poseNet resnet18-hand (GPU, jetson-inference), salida en ventana a pantalla completa
           si hay escritorio o al framebuffer si no.
Salir: Ctrl+C, o el mosaico "Salir".
"""
from __future__ import print_function

import os

if os.path.exists("/etc/nv_tegra_release"):
    # numpy 1.19 de pip truena en la Jetson Nano ("Illegal instruction") sin esto; va antes de importar numpy
    os.environ.setdefault("OPENBLAS_CORETYPE", "ARMV8")

import argparse
import math
import multiprocessing as mp
import queue
import re
import subprocess
import time

import cv2
import numpy as np

import efectos_audio as EA
import filtros as FI
import hdmi_manos as HM
import hdmi_reactivo as R
import modos_arte as ARTE
import modos_base as B
import modos_juegos as JUEGOS
import plataforma as P

log = HM.log
PERMANENCIA = 1.5      # segundos con el dedo sobre un mosaico del menu
MENU_DEDO = 1.2        # segundos con el dedo indice sobre el boton MENU para regresar
MENU_PUNO = 2.0        # segundos con el puno cerrado (en cualquier lugar) para regresar al menu
GRACIA = 0.5           # si la mano "parpadea" fuera del boton menos de esto, no se pierde el avance
# misma resolucion para calibrar y para las manos. Raspberry: 640x360 (ligera para MediaPipe).
# Jetson: 1280x720 (muchas webcams en 640x480 recortan los lados; poseNet en la GPU aguanta 720p).
RES_CAM = "1280x720" if P.tipo() == "jetson" else "640x360"
ALTO_DIBUJO = 480     # se dibuja a 480 px de alto y se escala a la resolucion real del HDMI
# En la Raspberry las manos (MediaPipe) usan el CPU: OpenCV con 1 hilo para no pelearse los nucleos.
# En la Jetson las manos van en la GPU: el dibujo puede usar mas hilos.
cv2.setNumThreads(3 if P.tipo() == "jetson" else 1)


# ====================================================================== vision (proceso aparte)
def proceso_vision(fuente, res, motor, cola, parar, fps_max=0, max_manos=2, chico_cada=3):
    """Corre en otro proceso para no frenar el dibujo: camara + detector de manos (MediaPipe o poseNet).
    fps_max > 0 limita cuantas veces por segundo se buscan manos (menos consumo de corriente)."""
    import sys

    def logv(*a):   # en este proceso los mensajes van a stderr (stdout se silencia por los avisos de poseNet)
        print(time.strftime("[%H:%M:%S]"), *a, file=sys.stderr)
        sys.stderr.flush()

    cv2.setNumThreads(1)
    cfg = FI.cargar()
    cap = None
    for intento in range(5):   # la camara CSI puede tardar en soltarse despues de calibrar
        try:
            cap = P.Camara(fuente, res)
            if cap.read()[0]:
                break
            cap.release()
        except Exception as e:
            logv("Vision: no abre la camara %s (%s)" % (fuente, e))
        cap = None
        time.sleep(2)
    if cap is None:
        logv("Vision: sin camara, no hay manos")
        return
    FI.aplicar_camara(fuente, cfg)          # exposicion, ganancia... guardados con ajustar_camara.py
    pre = FI.Preproceso(cfg)                # gamma, CLAHE, saturacion, suavizado, recorte
    manos = P.DetectorManos(motor, max_manos=max_manos, log=logv, umbral=cfg["umbral"],
                            min_puntos=cfg["min_puntos"])
    if manos.motor == "posenet":
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)   # sin "duplicate link detected" llenando la terminal
    n, t0, fps = 0, time.time(), 0.0
    while not parar.is_set():
        t_cuadro = time.time()
        ok, f = cap.read()
        if not ok:
            time.sleep(0.01)
            continue
        ch, cw = f.shape[:2]
        entrada, (dx, dy) = pre(f)
        res = manos.procesar(entrada)
        if dx or dy:
            res = [(p + np.float32([dx, dy]), g) for p, g in res]
        chico = cv2.resize(f, (320, 180)) if n % chico_cada == 0 else None
        n += 1
        if time.time() - t0 > 2:
            fps, t0, n = n / (time.time() - t0), time.time(), 0
        msg = (time.time(), res, chico, fps, (cw, ch), manos.motor or "ninguno")
        if fps_max > 0:
            time.sleep(max(0.0, 1.0 / fps_max - (time.time() - t_cuadro)))
        try:
            cola.put_nowait(msg)
        except queue.Full:
            try:
                cola.get_nowait()
            except queue.Empty:
                pass
            try:
                cola.put_nowait(msg)
            except queue.Full:
                pass
    cap.release()


# ====================================================================== microfono
def probar_mics():
    """Graba 1 s de cada microfono y elige el que capta mas sonido."""
    try:
        sal = subprocess.check_output(["arecord", "-l"], stderr=subprocess.STDOUT).decode("utf-8", "ignore")
    except Exception:
        return None
    mejor, mejor_rms = None, 0.0
    for c, nombre, d in re.findall(r"card (\d+): ([^\n]*?), device (\d+)", sal):
        if not P.mic_valido(nombre):
            continue
        dev = "plughw:%s,%s" % (c, d)
        try:
            raw = subprocess.check_output(["arecord", "-q", "-D", dev, "-f", "S16_LE", "-r", "16000", "-c", "1",
                                           "-d", "1", "-t", "raw"], stderr=subprocess.DEVNULL, timeout=4)
            x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0
            rms = float(np.sqrt(np.mean(x ** 2))) if len(x) else 0.0
        except Exception:
            rms = 0.0
        log("Microfono %s (%s): nivel %.4f" % (dev, nombre.strip()[:30], rms))
        if rms > mejor_rms:
            mejor, mejor_rms = dev, rms
    return mejor if mejor_rms > 0.0008 else None


# ====================================================================== modos propios del lanzador
class ModoManos(B.Modo):
    nombre = "Manos"
    descripcion = "Esqueleto de la mano"

    def actualizar(self, ctx):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        for pts, g in ctx.manos:
            p = pts.astype(np.int32)
            for a, b in B.CONEX:
                cv2.line(img, tuple(p[a]), tuple(p[b]), (255, 60, 220), 4, cv2.LINE_AA)
            for k in range(21):
                cv2.circle(img, tuple(p[k]), 9 if k in B.PUNTAS else 5,
                           (0, 230, 255) if k in B.PUNTAS else (255, 255, 120), -1, cv2.LINE_AA)
            if g:
                B.texto(img, g.upper(), p[0][0] - 40, p[0][1] + 40, 0.7, B.AMARILLO)
        if not ctx.manos:
            B.texto(img, "Pon la mano sobre la mesa", self.w / 2, self.h / 2, 0.7, B.GRIS, True)
        return B.brillo(img, 6, 1.0)

    @staticmethod
    def icono(img, x, y, w, h, t):
        cx, cy = x + w // 2, y + h // 2 + 15
        for k, a in enumerate((-0.9, -0.45, 0, 0.45, 0.9)):
            l = 32 if k else 24
            cv2.line(img, (cx, cy), (int(cx + math.sin(a) * l), int(cy - math.cos(a) * l)), (255, 60, 220), 2)
            cv2.circle(img, (int(cx + math.sin(a) * l), int(cy - math.cos(a) * l)), 4, (0, 230, 255), -1)


class ModoReactivo(B.Modo):
    """Efectos de hdmi_reactivo.py con gestos: palma 1 s = siguiente, apuntar 1 s = anterior,
    pulgar = paleta, pellizco = explosion. (El puno 2 s regresa al menu, como en todos los modos.)"""
    nombre = "Video reactivo"
    descripcion = "Efectos con gestos"
    usa_frame = True
    rave = False

    def entrar(self):
        self.fx = R.Efectos(self.w, self.h, self.app.H)
        self.lista = EA.EFECTOS_AUDIO if self.rave else R.EFECTOS_MANOS
        self.i = 0
        self.aviso, self.t_aviso = R.NOMBRES[self.lista[0]], time.time()
        self.bombos, self.t_cambio = 0, time.time()

    def _cambiar(self, d, t):
        self.i = (self.i + d) % len(self.lista)
        self.fx.buf[:] = 0
        self.aviso, self.t_aviso = R.NOMBRES[self.lista[self.i]], t

    def actualizar(self, ctx):
        t, A, fx = ctx.t, ctx.A, self.fx
        for i, g, tipo in ctx.eventos:
            if g == "palma" and tipo == "1s":
                self._cambiar(1, t)
            elif g == "apuntar" and tipo == "1s":
                self._cambiar(-1, t)
            elif g == "pulgar" and tipo == "nuevo":
                fx.paleta = (fx.paleta + 1) % len(R.PALETAS)
                self.aviso, self.t_aviso = "PALETA " + R.PALETAS[fx.paleta][0], t
            elif g == "pellizco" and tipo == "nuevo" and i < len(ctx.manos):
                p = ctx.manos[i][0]
                fx.explosion((p[4][0] + p[8][0]) / 2, (p[4][1] + p[8][1]) / 2)
        if len(ctx.manos) >= 2:
            base = float(np.clip(R._d(ctx.manos[0][0][8], ctx.manos[1][0][8]) / (self.w * 0.4), 0.3, 2.5))
        else:
            base = 1.0
        if A is not None:
            fx.audio = (A["nivel"], A["graves"], A["medios"], A["agudos"])
            base *= 0.7 + 1.3 * A["nivel"]
            if self.rave:
                self.bombos += 1 if A["kick"] else 0
                if self.bombos >= 16 or t - self.t_cambio > 25:
                    self.i = int(np.random.choice([k for k in range(len(self.lista)) if k != self.i]))
                    fx.paleta = int(np.random.randint(len(R.PALETAS)))
                    fx.buf[:] = 0
                    self.aviso, self.t_aviso = R.NOMBRES[self.lista[self.i]], t
                    self.bombos, self.t_cambio = 0, t
            elif A["kick"]:
                fx.golpe(self.lista[self.i], ctx.puntas)
        fx.intensidad += (base - fx.intensidad) * 0.25
        nombre = self.lista[self.i]
        frame_hd = None
        if nombre == "termico" and ctx.frame is not None:
            frame_hd = cv2.resize(ctx.frame, (1280, 720))
        if nombre in EA.EFECTOS_AUDIO:
            img = fx.render_audio(nombre, A or EA.audio_vacio(), ctx.manos, ctx.puntas)
        else:
            img = fx.render(nombre, ctx.puntas, ctx.dt, ctx.manos, frame_hd)
        if A is not None:
            fx.medidor(img)
        B.esqueleto(img, ctx.manos)
        if t - self.t_aviso < 1.8:
            B.texto(img, self.aviso, self.w / 2, 90, 0.9, B.BLANCO, True)
        return img

    @staticmethod
    def icono(img, x, y, w, h, t):
        cx, cy = x + w // 2, y + h // 2
        for k in range(5):
            r = int((t * 30 + k * 12) % 50)
            cv2.circle(img, (cx, cy), r, (255, 200 - k * 30, 60 + k * 40), 1, cv2.LINE_AA)


class ModoRave(ModoReactivo):
    nombre = "Rave musical"
    descripcion = "FFT de la musica, VJ solo"
    rave = True

    @staticmethod
    def icono(img, x, y, w, h, t):
        n = 12
        for k in range(n):
            v = abs(math.sin(t * 3 + k * 0.7)) * (h - 30)
            x0 = int(x + 10 + k * (w - 20) / n)
            cv2.rectangle(img, (x0, int(y + h - 10 - v)), (int(x0 + (w - 20) / n - 2), y + h - 10),
                          (255 - k * 18, 80 + k * 14, 255), -1)


class ModoRecalibrar(B.Modo):
    nombre = "Recalibrar"
    descripcion = "Si moviste camara o proyector"

    @staticmethod
    def icono(img, x, y, w, h, t):
        for (px, py) in ((x + 14, y + 12), (x + w - 34, y + 12), (x + 14, y + h - 32), (x + w - 34, y + h - 32)):
            cv2.rectangle(img, (px, py), (px + 20, py + 20), (230, 230, 230), -1)
            cv2.rectangle(img, (px + 5, py + 5), (px + 12, py + 12), (0, 0, 0), -1)


class ModoSalir(B.Modo):
    nombre = "Salir"
    descripcion = "Cerrar la estacion"

    @staticmethod
    def icono(img, x, y, w, h, t):
        cx, cy, r = x + w // 2, y + h // 2, min(w, h) // 4
        cv2.ellipse(img, (cx, cy), (r, r), -90, 40, 320, (80, 80, 255), 3, cv2.LINE_AA)
        cv2.line(img, (cx, cy - r - 4), (cx, cy - 4), (80, 80, 255), 3)


MODOS = [ModoManos, ModoReactivo, ModoRave, JUEGOS.PianoTiles, JUEGOS.PianoLibre, ARTE.Cortina,
         ARTE.Flor, ARTE.ImagenParticulas, ARTE.Cubo, ARTE.Centellas, ModoRecalibrar, ModoSalir]
ALIAS = {"manos": ModoManos, "reactivo": ModoReactivo, "rave": ModoRave, "piano": JUEGOS.PianoTiles,
         "pianolibre": JUEGOS.PianoLibre, "cortina": ARTE.Cortina, "flor": ARTE.Flor,
         "imagen": ARTE.ImagenParticulas, "cubo": ARTE.Cubo, "centellas": ARTE.Centellas}


# ====================================================================== menu
class Menu(B.Modo):
    nombre = "Menu"
    COLS, FILAS = 4, 3

    def entrar(self):
        self.t_dentro, self.sel, self.t_visto = None, None, 0.0
        self.t_entrar = time.time()

    def mosaicos(self):
        mx, top, gap = 12, 58, 8
        tw = (self.w - 2 * mx - (self.COLS - 1) * gap) / float(self.COLS)
        th = (self.h - top - 10 - (self.FILAS - 1) * gap) / float(self.FILAS)
        res = []
        for k, cls in enumerate(MODOS[:self.COLS * self.FILAS]):
            c, f = k % self.COLS, k // self.COLS
            x0, y0 = int(mx + c * (tw + gap)), int(top + f * (th + gap))
            res.append((cls, (x0, y0, int(x0 + tw), int(y0 + th))))
        return res

    def actualizar(self, ctx):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        t = ctx.t
        B.texto(img, "ESTACION", 14, 38, 1.1, B.AMARILLO, False, 3)
        B.texto(img, "Deja el dedo 1.5 s sobre un modo o pellizca", 215, 34, 0.5, B.GRIS, False, 1)
        if ctx.A is not None:   # indicador de microfono: se mueve si oye musica
            x1 = self.w - 14
            nivel = min(1.0, ctx.A["nivel"]) if ctx.A.get("rms", 1) >= 0.002 else 0.0
            cv2.rectangle(img, (x1 - 90, 42), (x1, 52), (70, 70, 70), 1)
            cv2.rectangle(img, (x1 - 90, 42), (x1 - 90 + int(90 * nivel), 52), B.VERDE, -1)
            B.texto(img, "MIC", x1 - 126, 52, 0.4, B.GRIS, False, 1)
        dedos = ctx.indices or ctx.puntas
        if t - self.t_entrar < 1.2:   # recien llegado al menu: que la mano que regreso no abra otro modo
            dedos = []
        elegido, hover = None, None
        for k, (cls, (x0, y0, x1, y1)) in enumerate(self.mosaicos()):
            sobre = any(x0 <= x <= x1 and y0 <= y <= y1 for x, y in dedos)
            if sobre:
                hover = k
            col = B.AMARILLO if sobre else (90, 90, 90)
            cv2.rectangle(img, (x0, y0), (x1, y1), (25, 25, 25), -1)
            cv2.rectangle(img, (x0, y0), (x1, y1), col, 3 if sobre else 1)
            try:
                cls.icono(img, x0 + 4, y0 + 4, x1 - x0 - 8, int((y1 - y0) * 0.62), t)
            except Exception:
                pass
            B.texto(img, cls.nombre, (x0 + x1) / 2, y1 - 22, 0.48, B.BLANCO, True, 1)
            B.texto(img, cls.descripcion, (x0 + x1) / 2, y1 - 7, 0.34, B.GRIS, True, 1)
            for i, g, tipo in ctx.eventos:
                if g == "pellizco" and tipo == "nuevo" and i < len(ctx.manos):
                    p = ctx.manos[i][0]
                    px, py = (p[4][0] + p[8][0]) / 2, (p[4][1] + p[8][1]) / 2
                    if x0 <= px <= x1 and y0 <= py <= y1:
                        elegido = cls
        if hover is not None:
            if self.sel != hover:
                self.sel, self.t_dentro = hover, t
            self.t_visto = t
        elif self.sel is not None and t - self.t_visto > GRACIA:   # tolera que la mano parpadee
            self.sel = None
        if self.sel is not None:
            prog = min(1.0, (t - self.t_dentro) / PERMANENCIA)
            cls, (x0, y0, x1, y1) = self.mosaicos()[self.sel]
            cv2.rectangle(img, (x0 + 4, y1 - 7), (int(x0 + 4 + (x1 - x0 - 8) * prog), y1 - 1), B.AMARILLO, -1)
            if prog >= 1:
                elegido = cls
        for (x, y) in dedos:
            cv2.circle(img, (int(x), int(y)), 8, B.AMARILLO, 2, cv2.LINE_AA)
        if elegido is not None:
            self.app.abrir(elegido)
        return img


# ====================================================================== aplicacion
class App(object):
    def __init__(self, args):
        self.args = args
        log("Plataforma:", P.tipo())
        self.salida = HM.abrir_salida("x11" if args.x11 else args.salida, args.alto)
        self.tam_calib = P.parse_res(args.res)
        # ventana con la camara en tu PC (SSH/MobaXterm con X11). Solo si se lanzo desde SSH y se dibuja al
        # framebuffer (si la estacion usa la ventana del escritorio, no se pueden abrir las dos)
        self.ver = bool(os.environ.get("DISPLAY")) and not args.sin_ver and not isinstance(self.salida, HM.VentanaX11)
        self.t_ver, self.ultimo_A = 0.0, None
        if self.ver:
            log("Ventana de camara por SSH: activada (--sin-ver para quitarla)")
        self.relleno = int(args.relleno if args.relleno is not None else FI.cargar().get("relleno", 0))
        if self.relleno:
            log("Luz de relleno: %d" % self.relleno)
        self.w, self.h = self.salida.w, self.salida.h
        self.detectar, self.gen = HM.aruco()
        self.pantalla("ESTACION", "Iniciando...")
        self.sonido = B.Sonido(args.salida_audio, not args.sin_sonido)
        log("Notas por:", self.sonido.dev if self.sonido.activo else "sin sonido")
        self.audio = None
        if not args.sin_audio:
            dev = args.mic
            if dev == "auto":
                self.pantalla("ESTACION", "Buscando microfono...")
                dev = probar_mics()
            if dev:
                log("Audio: usando", dev)
                self.audio = R.Audio(dev, corte=args.corte_audio)
                log("Audio: se ignora lo que pase de %d Hz (ruido agudo del proyector)" % args.corte_audio)
            else:
                log("Audio: no hay microfono con sonido. Sigo sin audio.")
        self.H = self.calibrar_inicio()
        self.cola, self.parar, self.proc, self.reinicios = None, None, None, 0
        self.iniciar_vision()
        self.est = [R.Estable(), R.Estable()]
        self.manos_cam, self.frame, self.tam_cam, self.fps_vision = [], None, self.tam_calib, 0.0
        self.t_menu, self.t_menu_visto, self.t_modo = None, 0.0, 0.0
        self.t_puno, self.t_puno_visto, self.pos_puno = None, 0.0, (0, 0)
        self.menu = Menu(self)
        self.modo = self.menu
        self.menu.entrar()
        self.vivo = True
        if args.modo in ALIAS:
            self.abrir(ALIAS[args.modo])

    # ---------- pantalla simple
    def pantalla(self, titulo, sub):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        B.texto(img, titulo, self.w / 2, self.h / 2 - 20, 1.6, B.AMARILLO, True, 4)
        B.texto(img, sub, self.w / 2, self.h / 2 + 30, 0.7, B.BLANCO, True)
        self.salida.mostrar(img)

    # ---------- calibracion
    def _abrir_camara(self):
        FI.camara_automatica(self.args.camara)   # para calibrar: exposicion automatica (los ajustes de manos
        cam = P.Camara(self.args.camara, self.args.res)   # se ponen despues, en el proceso de vision)
        ok, f = False, None
        for _ in range(10):
            ok, f = cam.read()
            if ok:
                break
            time.sleep(0.1)
        if ok:
            self.tam_calib = (f.shape[1], f.shape[0])
        log("Camara: %dx%d" % self.tam_calib)
        return cam

    # intentos de calibracion: (tamano de marcador, separacion de la orilla, segundos).
    # Si la camara no alcanza las orillas de la proyeccion, los siguientes intentos los ponen mas adentro.
    INTENTOS_CALIB = [(0.30, None, 25.0), (0.22, 0.10, 20.0), (0.18, 0.18, 20.0)]

    def _calibrar(self, cam):
        for k, (esc, margen, tope) in enumerate(self.INTENTOS_CALIB):
            if k:
                log("Calibracion: intento %d con marcadores mas chicos y hacia adentro" % (k + 1))
            H = HM.calibrar(cam, self.salida, self.detectar, self.gen, tope=tope, escala=esc, margen=margen)
            if H is not None:
                return H
        return None

    def calibrar_inicio(self):
        """Siempre calibra al iniciar; si no ve las esquinas, usa la calibracion guardada."""
        cam = self._abrir_camara()
        H = self._calibrar(cam)
        cam.release()
        if H is None:
            H, c = HM.cargar_calib(self.w, self.h, self.tam_calib)
            if H is not None:
                log("No vi las esquinas: uso la calibracion guardada (%s)" % c.get("fecha"))
                self.pantalla("AVISO", "No vi las esquinas: uso la calibracion anterior")
                time.sleep(2)
        while H is None:
            self.pantalla("CALIBRAR", "La camara debe ver las 4 esquinas. Reintento...")
            time.sleep(2)
            cam = self._abrir_camara()
            H = self._calibrar(cam)
            cam.release()
        return H

    def iniciar_vision(self):
        # En la Jetson el proceso de vision usa CUDA: se arranca limpio ("spawn") para no heredar nada.
        ctx = mp.get_context("spawn" if P.tipo() == "jetson" else "fork")
        self.cola = ctx.Queue(maxsize=2)
        self.parar = ctx.Event()
        self.proc = ctx.Process(target=proceso_vision, daemon=True,
                                args=(self.args.camara, self.args.res, self.args.manos, self.cola, self.parar,
                                      10 if self.args.ahorro else 0, 1 if self.args.ahorro else 2,
                                      1 if self.ver else 3))
        self.proc.start()
        self.t_vision, self.vision_lista = time.time(), False
        log("Vision iniciada en proceso aparte (pid %d)" % self.proc.pid)

    def detener_vision(self):
        if self.proc is not None:
            self.parar.set()
            self.proc.join(timeout=5)
            if self.proc.is_alive():
                self.proc.terminate()
            self.proc = None

    # ---------- modos
    def abrir(self, cls):
        if cls is ModoSalir:
            self.vivo = False
            return
        if cls is ModoRecalibrar:
            self.detener_vision()
            cam = self._abrir_camara()
            H = self._calibrar(cam)
            cam.release()
            if H is not None:
                self.H = H
            self.iniciar_vision()
            self.modo = self.menu
            self.menu.entrar()
            return
        log("Abriendo modo:", cls.nombre)
        nuevo = cls(self)
        nuevo.entrar()
        self.modo = nuevo
        self.t_menu, self.t_modo = None, time.time()

    # ---------- bucle
    def _leer_vision(self):
        while True:
            try:
                tv, res, chico, fps, tam, motor = self.cola.get_nowait()
            except queue.Empty:
                break
            self.manos_cam, self.fps_vision, self.tam_cam = res, fps, tam
            if not self.vision_lista:
                self.vision_lista = True
                log("Manos listas: detector %s (%.0f s en cargar)" % (motor, time.time() - self.t_vision))
            if chico is not None:
                self.frame = chico

    def correr(self):
        t_prev, t_log, cuadros = time.time(), time.time(), 0
        ctx = B.Contexto()
        ctx.w, ctx.h = self.w, self.h
        while self.vivo:
            t = time.time()
            ctx.t, ctx.dt = t, min(0.1, t - t_prev)
            t_prev = t
            self._leer_vision()
            manos = []
            cw, ch = self.tam_cam
            kx, ky = self.tam_calib[0] / float(cw), self.tam_calib[1] / float(ch)
            for cam, g in self.manos_cam:
                if kx != 1.0 or ky != 1.0:
                    cam = cam * np.float32([kx, ky])
                hd = cv2.perspectiveTransform(cam[:, None], self.H)[:, 0]
                manos.append((hd, g))
            manos.sort(key=lambda m: m[0][0][0])
            ctx.manos = manos
            ctx.puntas = [(float(p[k][0]), float(p[k][1])) for p, _ in manos for k in B.PUNTAS]
            ctx.indices = [(float(p[8][0]), float(p[8][1])) for p, _ in manos]
            ctx.eventos = []
            for i in range(2):
                g, dur, nuevo = self.est[i].actualizar(manos[i][1] if i < len(manos) else "", t)
                if g and nuevo:
                    ctx.eventos.append((i, g, "nuevo"))
                if g and dur >= 1.0 and self.est[i].una_vez("1s"):
                    ctx.eventos.append((i, g, "1s"))
            ctx.A = self.audio.leer_todo() if (self.audio is not None and self.audio.ok) else None
            if ctx.A is not None:
                self.ultimo_A = ctx.A
            ctx.frame = self.frame
            ctx.H_frame = self.H.dot(np.diag([self.tam_calib[0] / 320.0, self.tam_calib[1] / 180.0, 1.0]))
            try:
                img = self.modo.actualizar(ctx)
            except Exception as e:
                log("Error en modo %s: %s" % (self.modo.nombre, e))
                import traceback
                traceback.print_exc()
                img = np.zeros((self.h, self.w, 3), np.uint8)
                B.texto(img, "Error en el modo. Regresando al menu", self.w / 2, self.h / 2, 0.6, B.ROJO, True)
                self.modo = self.menu
                self.menu.entrar()
            if self.modo is not self.menu:
                img = self._boton_menu(img, ctx)
            if self.relleno:   # gris minimo para que la mano quede iluminada por el proyector
                img = np.maximum(img, self.relleno)
            if not self.vision_lista:
                txt = "Cargando detector de manos... %d s" % (t - self.t_vision)
                if P.tipo() == "jetson" and t - self.t_vision > 20:
                    txt += " (la 1a vez tarda unos minutos)"
                B.texto(img, txt, self.w / 2, self.h - 12, 0.5, B.AMARILLO, True, 1)
            self.salida.mostrar(img)
            if self.ver and t - self.t_ver > 0.25:
                self.t_ver = t
                self._ventana_ssh(manos, ctx)
            cuadros += 1
            if t - t_log > 5 and self.proc is not None and not self.proc.is_alive() and self.reinicios < 3:
                self.reinicios += 1
                log("La vision se cerro (codigo %s); la reinicio" % self.proc.exitcode)
                self.iniciar_vision()
            if t - t_log > 5:
                log("%s | dibujo %.0f FPS | vision %.1f FPS | manos %d" %
                    (self.modo.nombre, cuadros / (t - t_log), self.fps_vision, len(manos)))
                t_log, cuadros = t, 0
            time.sleep(max(0.0, (1.0 / 15 if self.args.ahorro else 0.04) - (time.time() - t)))

    def _rect_menu(self):
        """Boton MENU en la esquina superior izquierda (18% del ancho, 17% del alto)."""
        return 0, 0, max(110, int(self.w * 0.18)), max(70, int(self.h * 0.17))

    def _volver_menu(self, motivo):
        log("Regresando al menu (%s)" % motivo)
        self.modo = self.menu
        self.menu.entrar()
        self.t_menu = self.t_puno = None

    def _boton_menu(self, img, ctx):
        x0, y0, x1, y1 = self._rect_menu()
        t = ctx.t
        # solo cuenta la punta del dedo INDICE (asi la mano abierta que pasa por ahi no te saca del modo)
        sobre = any(x0 <= x <= x1 and y0 <= y <= y1 for x, y in ctx.indices)
        if sobre:
            self.t_menu_visto = t
            self.t_menu = self.t_menu or t
        elif self.t_menu is not None and t - self.t_menu_visto > GRACIA:
            self.t_menu = None
        prog = min(1.0, (t - self.t_menu) / MENU_DEDO) if self.t_menu else 0.0
        # dibujo del boton
        sub = img[y0:y1, x0:x1]
        sub[:] = (sub * 0.25).astype(np.uint8)
        col = B.AMARILLO if self.t_menu else (200, 200, 200)
        if prog > 0:
            cv2.rectangle(img, (x0, y0), (int(x0 + (x1 - x0) * prog), y1), (0, 120, 160), -1)
        cv2.rectangle(img, (x0 + 1, y0 + 1), (x1, y1), col, 3)
        cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
        for k in range(3):  # icono de menu (tres rayas)
            yy = cy - 22 + k * 9
            cv2.line(img, (cx - 16, yy), (cx + 16, yy), col, 3, cv2.LINE_AA)
        B.texto(img, "MENU", cx, cy + 22, 0.75, col, True, 2)
        if prog >= 1:
            self._volver_menu("boton")
            return img
        # atajo opcional (--puno-menu): puno cerrado 2 s en cualquier lugar
        for p, g in (ctx.manos if self.args.puno_menu else []):
            if g == "puno":
                self.t_puno_visto, self.pos_puno = t, (int(p[9][0]), int(p[9][1]))
                self.t_puno = self.t_puno or t
        if self.t_puno is not None and t - self.t_puno_visto > 0.4:
            self.t_puno = None
        if self.t_puno is not None:
            dur = t - self.t_puno
            avance = min(1.0, dur / MENU_PUNO)
            if dur > 0.3:
                px, py = self.pos_puno
                cv2.circle(img, (px, py), 38, (60, 60, 60), 4, cv2.LINE_AA)
                cv2.ellipse(img, (px, py), (38, 38), -90, 0, int(360 * avance), B.AMARILLO, 6, cv2.LINE_AA)
                B.texto(img, "MENU", px, py + 62, 0.6, B.AMARILLO, True, 2)
            if avance >= 1:
                self._volver_menu("puno")
                return img
        # recordatorio los primeros segundos de cada modo
        if t - self.t_modo < 5:
            txt = "Volver al menu: dedo indice sobre MENU"
            if self.args.puno_menu:
                txt += "  o  puno cerrado 2 s"
            B.texto(img, txt, self.w / 2, self.h - 14, 0.5, B.AMARILLO, True, 1)
        return img

    def _ventana_ssh(self, manos_hdmi, ctx):
        """Lo que ve la camara (con las manos detectadas) y el audio, en una ventana en tu PC por SSH."""
        try:
            esc = 1.5
            if self.frame is not None:
                v = cv2.resize(self.frame, (480, 270))
            else:
                v = np.zeros((270, 480, 3), np.uint8)
                B.texto(v, "Sin imagen de camara todavia", 240, 135, 0.6, B.GRIS, True, 1)
            cw, ch = self.tam_cam
            k = np.float32([320.0 / cw * esc, 180.0 / ch * esc])
            for cam, g in self.manos_cam:
                q = (cam * k).astype(np.int32)
                for a, b in P.CADENAS_LINKS:
                    cv2.line(v, tuple(q[a]), tuple(q[b]), (255, 60, 220), 2, cv2.LINE_AA)
                for i in B.PUNTAS:
                    cv2.circle(v, tuple(q[i]), 4, (0, 255, 255), -1, cv2.LINE_AA)
                B.texto(v, g or "mano", q[0][0], q[0][1] + 18, 0.5, B.VERDE, True, 1)
            panel = np.full((270, 260, 3), 25, np.uint8)
            B.texto(panel, self.modo.nombre[:18], 10, 24, 0.55, B.AMARILLO, False, 1)
            B.texto(panel, "manos: %d   vision %.1f FPS" % (len(self.manos_cam), self.fps_vision), 10, 46, 0.42,
                    B.BLANCO, False, 1)
            A = self.ultimo_A
            if A is None:
                B.texto(panel, "AUDIO: sin microfono", 10, 76, 0.45, B.ROJO, False, 1)
            else:
                oye = A.get("rms", 0) >= 0.002
                B.texto(panel, "AUDIO: %s  (rms %.4f)" % ("oye" if oye else "silencio", A.get("rms", 0)), 10, 76,
                        0.42, B.VERDE if oye else B.GRIS, False, 1)
                for i, (nom, val) in enumerate((("nivel", A["nivel"]), ("graves", A["graves"]),
                                                ("medios", A["medios"]), ("agudos", A["agudos"]))):
                    y = 96 + i * 20
                    B.texto(panel, nom, 10, y + 10, 0.4, B.BLANCO, False, 1)
                    cv2.rectangle(panel, (70, y), (70 + int(170 * min(1.0, val)), y + 12), (0, 200, 255), -1)
                    cv2.rectangle(panel, (70, y), (240, y + 12), (90, 90, 90), 1)
                esp = A["espectro"]
                for i, e in enumerate(esp):
                    x = 10 + i * 7
                    cv2.rectangle(panel, (x, 255), (x + 5, 255 - int(70 * min(1.0, e))), (255, 120, 60), -1)
                if A.get("kick"):
                    cv2.circle(panel, (230, 30), 12, (0, 0, 255), -1)
            cv2.imshow("Estacion - camara (SSH)", np.hstack([v, panel]))
            cv2.waitKey(1)
        except Exception as e:
            log("Ventana SSH desactivada (%s)" % e)
            self.ver = False

    def cerrar(self):
        self.detener_vision()
        try:
            self.salida.cerrar()
        except Exception:
            pass


def main():
    ap = argparse.ArgumentParser(description="Estacion de proyeccion: calibra, menu y modos")
    ap.add_argument("--camara", default="0", help="0, 1... (USB) o csi (camara CSI de la Jetson)")
    ap.add_argument("--salida", default="auto", choices=["auto", "fb", "x11"],
                    help="auto: Raspberry=framebuffer, Jetson con escritorio=ventana completa")
    ap.add_argument("--alto", type=int, default=ALTO_DIBUJO,
                    help="altura a la que se dibuja (menos = mas rapido; se escala al HDMI)")
    ap.add_argument("--manos", default="auto", choices=["auto", "posenet", "mediapipe", "ninguno"],
                    help="detector de manos (auto: Jetson=poseNet en GPU, Raspberry=MediaPipe; ninguno = sin manos)")
    ap.add_argument("--sin-ver", dest="sin_ver", action="store_true",
                    help="no abrir la ventana con la camara en tu PC (por defecto se abre si corres por SSH)")
    ap.add_argument("--puno-menu", dest="puno_menu", action="store_true",
                    help="tambien regresar al menu con el puno cerrado 2 s (por defecto solo con el boton MENU)")
    ap.add_argument("--corte-audio", dest="corte_audio", type=int, default=4000,
                    help="Hz: el audio arriba de esto se ignora (chillido del proyector). 3000-6000")
    ap.add_argument("--relleno", type=int, default=None,
                    help="gris minimo proyectado 0..150 para iluminar la mano (por defecto el de filtros.json)")
    ap.add_argument("--ahorro", action="store_true",
                    help="gasta menos corriente: dibuja chico a 15 FPS, camara 640x480, manos 10 veces/s y una sola mano")
    ap.add_argument("--res", default=RES_CAM, help="resolucion de camara para calibrar y manos (ej. 1280x720)")
    ap.add_argument("--mic", default="auto", help="microfono ALSA (auto = el que capte mas sonido)")
    ap.add_argument("--sin-audio", dest="sin_audio", action="store_true")
    ap.add_argument("--salida-audio", dest="salida_audio", default="auto", help="donde suenan las notas")
    ap.add_argument("--sin-sonido", dest="sin_sonido", action="store_true")
    ap.add_argument("--modo", default="", help="abrir directo: " + ", ".join(sorted(ALIAS)))
    ap.add_argument("--x11", action="store_true")
    args = ap.parse_args()
    if args.ahorro:   # para fuentes debiles (Jetson por micro-USB, Raspberry con poco voltaje)
        args.alto = min(args.alto, 360)
        if args.res == RES_CAM:
            args.res = "640x480"
        log("Modo ahorro: dibujo a %d px de alto y 15 FPS, camara %s, manos 10 veces/s" % (args.alto, args.res))
    app = App(args)
    try:
        app.correr()
    except KeyboardInterrupt:
        log("Saliendo")
    finally:
        app.cerrar()


if __name__ == "__main__":
    main()
