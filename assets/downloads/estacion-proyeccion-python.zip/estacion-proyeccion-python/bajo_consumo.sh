#!/bin/bash
# Modo de BAJO CONSUMO para la Jetson Nano (fuentes debiles: cargador de celular, micro-USB).
#
#   sudo bash bajo_consumo.sh            -> lo aplica ahora (se pierde al reiniciar)
#   sudo bash bajo_consumo.sh --siempre  -> ademas lo deja fijo en cada arranque
#   sudo bash bajo_consumo.sh --quitar   -> regresa a maxima potencia (cuando tengas fuente de 5 V 4 A)
#
# Que hace: modo 5 W (2 nucleos de CPU, GPU limitada) y baja aun mas el reloj maximo de la GPU,
# que es lo que mas corriente jala de golpe cuando arranca el detector de manos.
GPU_MHZ="${GPU_MHZ:-460}"     # reloj maximo de la GPU en MHz (Nano: 76 ... 921). Menos = menos corriente.

if [ "$(id -u)" != "0" ]; then
  echo "Correlo con sudo:  sudo bash $0 $*"; exit 1
fi

GPU=""
for d in /sys/devices/57000000.gpu/devfreq/57000000.gpu /sys/devices/gpu.0/devfreq/57000000.gpu; do
  [ -d "$d" ] && GPU="$d" && break
done

if [ "$1" = "--quitar" ]; then
  systemctl disable --now bajo-consumo.service 2>/dev/null
  rm -f /etc/systemd/system/bajo-consumo.service
  nvpmodel -m 0
  echo "Listo: modo MAXN (10 W). Usalo solo con fuente de 5 V 4 A por el conector redondo."
  exit 0
fi

echo "=== Modo 5 W"
nvpmodel -m 1
sleep 1

if [ -n "$GPU" ]; then
  # el valor tiene que ser una de las frecuencias que la GPU acepta: se toma la mas cercana por abajo
  OBJ=$((GPU_MHZ * 1000000))
  ELEGIDA=$(tr ' ' '\n' < "$GPU/available_frequencies" | awk -v o="$OBJ" '$1<=o' | sort -n | tail -1)
  MIN=$(cat "$GPU/min_freq")
  [ -n "$ELEGIDA" ] && [ "$ELEGIDA" -ge "$MIN" ] && echo "$ELEGIDA" > "$GPU/max_freq"
  echo "=== GPU: maximo $(( $(cat "$GPU/max_freq") / 1000000 )) MHz"
else
  echo "(no encontre los controles de la GPU; solo quedo el modo 5 W)"
fi
echo "=== Estado"
nvpmodel -q 2>/dev/null | head -2

if [ "$1" = "--siempre" ]; then
  RUTA="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
  cat > /etc/systemd/system/bajo-consumo.service <<EOF
[Unit]
Description=Jetson en bajo consumo (fuente debil)
After=nvpmodel.service

[Service]
Type=oneshot
Environment=GPU_MHZ=$GPU_MHZ
ExecStart=/bin/bash $RUTA

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable bajo-consumo.service
  echo "Quedo fijo: se aplica solo en cada arranque.  Para quitarlo:  sudo bash $RUTA --quitar"
fi
