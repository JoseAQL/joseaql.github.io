#!/bin/bash
# Arranca la estacion (calibracion + menu) y la reinicia si se cierra por error.
# Sirve igual en Raspberry Pi y en Jetson Nano.
#   Raspberry (sin escritorio):  crontab -e  y agregar   @reboot /home/USUARIO/asesor/iniciar_estacion.sh
#   Jetson con escritorio:       lo instala solo instalar_jetson.sh (~/.config/autostart/estacion.desktop)
# Opciones fijas (por ejemplo --camara csi): escribelas en estacion_args.txt junto a este archivo.
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
mkdir -p registros

EXTRA=""
[ -f "$DIR/estacion_args.txt" ] && EXTRA="$(grep -v '^#' "$DIR/estacion_args.txt" | tr '\n' ' ')"

if [ -f /etc/nv_tegra_release ]; then
  export OPENBLAS_CORETYPE=ARMV8          # numpy de pip en la Jetson Nano
fi

if [ -S /tmp/.X11-unix/X0 ]; then         # hay escritorio: ventana a pantalla completa en el HDMI
  export DISPLAY=${DISPLAY:-:0}
  if [ -z "$XAUTHORITY" ]; then
    for x in "/run/user/$(id -u)/gdm/Xauthority" "$HOME/.Xauthority"; do
      [ -f "$x" ] && export XAUTHORITY="$x" && break
    done
  fi
  xset s off 2>/dev/null; xset -dpms 2>/dev/null; xset s noblank 2>/dev/null   # que no se apague la pantalla
  pgrep -x unclutter >/dev/null || (unclutter -idle 1 -root >/dev/null 2>&1 &)  # esconde el mouse
fi

[ "$1" = "--ya" ] && shift || sleep 15     # al prender, espera a que camara y audio esten listos
while true; do
  echo "--- inicio $(date)" >> registros/estacion.log
  # shellcheck disable=SC2086
  python3 estacion.py $EXTRA "$@" >> registros/estacion.log 2>&1
  [ $? -eq 0 ] && break      # salio con "Salir" o Ctrl+C
  sleep 3
done
