#!/bin/bash
# Instalador de la ESTACION (calibracion + menu + modos) en la Raspberry Pi 4.
# Raspberry Pi OS de 64 bits (Bullseye o Bookworm), sin escritorio o con escritorio apagado.
#
#   bash instalar_raspberry.sh             -> instala lo necesario
#   bash instalar_raspberry.sh --arranque  -> ademas hace que la estacion arranque sola al prender
#
# Te pedira tu contrasena para los pasos con sudo (escribela tu).
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 1
USUARIO="$(whoami)"
ok()  { echo "  [OK] $*"; }
mal() { echo "  [!!] $*"; }

echo "=== Estacion para Raspberry | carpeta: $DIR | usuario: $USUARIO"
tr -d '\0' < /proc/device-tree/model 2>/dev/null; echo
. /etc/os-release; echo "$PRETTY_NAME | $(uname -m) | $(python3 --version)"
if [ "$(getconf LONG_BIT)" != "64" ]; then
  mal "Tu sistema es de 32 bits: MediaPipe (manos) no se instala. Graba Raspberry Pi OS de 64 bits."
fi

PIP="python3 -m pip install --user"
ls /usr/lib/python3*/EXTERNALLY-MANAGED >/dev/null 2>&1 && PIP="$PIP --break-system-packages"   # Bookworm

echo "=== 1/5 Paquetes del sistema"
sudo apt-get update
sudo apt-get install -y python3-pip python3-numpy alsa-utils v4l-utils

echo "=== 2/5 OpenCV con ArUco (marcadores de calibracion)"
if python3 -c "import cv2; cv2.aruco.DICT_4X4_50" 2>/dev/null; then
  ok "OpenCV $(python3 -c 'import cv2; print(cv2.__version__)') con ArUco"
else
  $PIP "opencv-contrib-python<4.11" && ok "OpenCV instalado" || mal "No se pudo instalar OpenCV"
fi

echo "=== 3/5 Manos (MediaPipe)"
if python3 -c "import mediapipe" 2>/dev/null; then
  ok "MediaPipe ya instalado"
else
  $PIP mediapipe && ok "MediaPipe instalado" || mal "MediaPipe no se instalo"
fi

echo "=== 4/5 Permisos (HDMI, camara y audio)"
sudo usermod -aG video,audio "$USUARIO" && ok "usuario en grupos video y audio"
chmod +x "$DIR"/*.sh
mkdir -p "$DIR/registros"

if [ "$1" = "--arranque" ]; then
  (crontab -l 2>/dev/null | grep -v iniciar_estacion; echo "@reboot $DIR/iniciar_estacion.sh") | crontab -
  ok "arrancara sola al prender (crontab). Para quitarlo:  crontab -l | grep -v iniciar_estacion | crontab -"
fi

echo "=== 5/5 Revision"
python3 - <<'EOF'
def prueba(nombre, codigo):
    try:
        exec(codigo, {})
        print("  [OK] " + nombre)
    except Exception as e:
        print("  [!!] %s: %s" % (nombre, str(e).splitlines()[0][:80]))
prueba("numpy", "import numpy")
prueba("OpenCV + ArUco", "import cv2; cv2.aruco.DICT_4X4_50")
prueba("MediaPipe (manos)", "import mediapipe")
prueba("plataforma", "import sys; sys.path.insert(0, '.'); import plataforma as P; print('       plataforma:', P.tipo())")
EOF
echo "  HDMI: $(cat /sys/class/graphics/fb0/virtual_size 2>/dev/null) $(cat /sys/class/graphics/fb0/bits_per_pixel 2>/dev/null) bits"
echo "  Camaras: $(ls /dev/video* 2>/dev/null | tr '\n' ' ')"
echo "  Microfonos:"; arecord -l 2>/dev/null | grep "^card" || mal "no veo microfonos"
V=$(vcgencmd get_throttled 2>/dev/null | cut -d= -f2)
if [ -n "$V" ] && [ "$V" != "0x0" ]; then
  mal "La Raspberry reporto BAJO VOLTAJE o calor ($V). Usa la fuente oficial de 5.1 V 3 A y un disipador/ventilador."
fi

echo
echo "=== Listo. Prueba:   cd $DIR && python3 estacion.py"
echo "Si es la primera vez, cierra sesion y vuelve a entrar (o reinicia) para que apliquen los permisos."
