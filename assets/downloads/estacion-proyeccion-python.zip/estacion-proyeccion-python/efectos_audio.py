# -*- coding: utf-8 -*-
"""
efectos_audio.py - Visuales audio-reactivos estilo TouchDesigner para hdmi_reactivo.py.
Cada efecto recibe el estado del audio (A) y de las manos; el centro de los efectos sigue tu mano.

  espectro     barras del espectro en espejo (Audio Spectrum CHOP -> barras)
  circular     espectro radial alrededor de la mano, gira con los medios
  osciloscopio forma de onda en vivo con brillo
  lissajous    figura X/Y de la onda (osciloscopio de fase) con estela
  tunel        feedback infinito: la imagen anterior se escala y gira (Feedback TOP)
  anillos      anillos que salen con cada bombo (graves) y caja (medios)
  instancias   rejilla de cuadros que crecen por banda (instancing)
  estrobo      destellos en bombo/caja con figuras del espectro
  lineas       lineas de montanas desplazadas por el espectro (estilo Joy Division)
  hiperespacio estrellas que aceleran con el volumen
  metabolas    burbujas liquidas que laten con los graves
"""
import math
import time

import cv2
import numpy as np

EFECTOS_AUDIO = ["espectro", "circular", "osciloscopio", "lissajous", "tunel", "anillos",
                 "instancias", "estrobo", "lineas", "hiperespacio", "metabolas"]
NOMBRES_AUDIO = {"espectro": "ESPECTRO", "circular": "ESPECTRO CIRCULAR", "osciloscopio": "OSCILOSCOPIO",
                 "lissajous": "LISSAJOUS", "tunel": "TUNEL FEEDBACK", "anillos": "ANILLOS DE BOMBO",
                 "instancias": "INSTANCIAS", "estrobo": "ESTROBO", "lineas": "LINEAS SONORAS",
                 "hiperespacio": "HIPERESPACIO", "metabolas": "METABOLAS"}


def audio_vacio():
    return {"nivel": 0.0, "graves": 0.0, "medios": 0.0, "agudos": 0.0, "kick": False, "snare": False,
            "espectro": np.zeros(32, np.float32), "onda": np.zeros(512, np.float32)}


class EfectosAudioMixin(object):
    """Se mezcla con hdmi_reactivo.Efectos (usa self.w, self.h, self.buf, self.color, self.paleta)."""

    def _init_audio_fx(self):
        self.t0 = time.time()
        self.fb = np.zeros((self.h, self.w, 3), np.float32)      # buffer de feedback a color
        self.anillos_l = []                                      # [x, y, r, color]
        self.estrellas = np.random.randn(220, 3).astype(np.float32) * np.float32([1, 1, 0])
        self.estrellas[:, 2] = np.random.rand(220) * 4 + 0.5
        self.flash = 0.0
        self.flash_col = (255, 255, 255)
        self.liss = np.zeros((self.h, self.w), np.float32)

    def _centro(self, manos):
        if manos:
            p = manos[0][0][9]
            return float(p[0]), float(p[1])
        return self.w / 2.0, self.h / 2.0

    def _tono(self, v):
        """Color BGR de la paleta actual para un valor 0..1 (tabla precalculada)."""
        if getattr(self, "_lut_pal", None) != self.paleta:
            cm = getattr(cv2, self.PALETAS[self.paleta][1], cv2.COLORMAP_JET)
            self._lut = cv2.applyColorMap(np.arange(256, dtype=np.uint8)[:, None], cm)[:, 0]
            self._lut_pal = self.paleta
        c = self._lut[int(min(1.0, max(0.0, v)) * 255)]
        return (int(c[0]), int(c[1]), int(c[2]))

    # ------------------------------------------------------------------ 1 espectro
    def fx_espectro(self, A, manos):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        e = A["espectro"]
        n = len(e)
        ancho = self.w / (2.0 * n)
        cx, cy = self._centro(manos)
        base = int(cy) if manos else self.h // 2
        for i, v in enumerate(e):
            alto = int(v * self.h * 0.45 * (0.6 + self.intensidad * 0.4))
            col = self._tono(i / n)
            for lado in (-1, 1):
                x0 = int(self.w / 2 + lado * i * ancho)
                x1 = int(x0 + lado * (ancho - 2))
                cv2.rectangle(img, (min(x0, x1), base - alto), (max(x0, x1), base + alto // 3), col, -1)
        return cv2.add(img, cv2.GaussianBlur(img, (0, 0), 6) // 2)

    # ------------------------------------------------------------------ 2 circular
    def fx_circular(self, A, manos):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        cx, cy = self._centro(manos)
        e = A["espectro"]
        r0 = 45 + 60 * A["graves"]
        giro = (time.time() - self.t0) * (0.3 + 2 * A["medios"])
        n = len(e) * 2
        for k in range(n):
            v = e[k % len(e)] if k < len(e) else e[len(e) - 1 - (k - len(e))]
            a = giro + k * 2 * math.pi / n
            r1 = r0 + 10 + v * 150 * self.intensidad
            p0 = (int(cx + math.cos(a) * r0), int(cy + math.sin(a) * r0))
            p1 = (int(cx + math.cos(a) * r1), int(cy + math.sin(a) * r1))
            cv2.line(img, p0, p1, self._tono(v), 5, cv2.LINE_AA)
        cv2.circle(img, (int(cx), int(cy)), int(r0 - 6), self._tono(A["graves"]), 2, cv2.LINE_AA)
        return cv2.add(img, cv2.GaussianBlur(img, (0, 0), 5))

    # ------------------------------------------------------------------ 3 osciloscopio
    def fx_osciloscopio(self, A, manos):
        self.buf *= 0.55
        onda = A["onda"]
        cx, cy = self._centro(manos)
        y0 = cy if manos else self.h / 2
        xs = np.linspace(0, self.w - 1, len(onda))
        amp = self.h * 0.35 * (0.5 + self.intensidad)
        ys = y0 + np.clip(onda * 4, -1, 1) * amp
        pts = np.int32(np.stack([xs, ys], 1))[:, None]
        cv2.polylines(self.buf, [pts], False, 255.0, 2, cv2.LINE_AA)
        return self.color(np.clip(self.buf + cv2.GaussianBlur(self.buf, (0, 0), 4) * 0.8, 0, 255).astype(np.uint8))

    # ------------------------------------------------------------------ 4 lissajous
    def fx_lissajous(self, A, manos):
        self.liss *= 0.82
        onda = np.clip(A["onda"] * 5, -1, 1)
        d = 17
        cx, cy = self._centro(manos)
        esc = min(self.w, self.h) * 0.38 * (0.6 + self.intensidad * 0.5)
        x = cx + onda[d:] * esc
        y = cy + onda[:-d] * esc
        pts = np.int32(np.stack([x, y], 1))[:, None]
        cv2.polylines(self.liss, [pts], False, 255.0, 1, cv2.LINE_AA)
        return self.color(np.clip(self.liss * 1.5 + cv2.GaussianBlur(self.liss, (0, 0), 3), 0, 255).astype(np.uint8))

    # ------------------------------------------------------------------ 5 tunel feedback
    def fx_tunel(self, A, manos):
        cx, cy = self._centro(manos)
        ang = 1.2 + 6 * A["medios"]
        esc = 1.035 + 0.05 * A["graves"]
        M = cv2.getRotationMatrix2D((cx, cy), ang, esc)
        self.fb = cv2.warpAffine(self.fb, M, (self.w, self.h)) * 0.90
        r = int(20 + 70 * A["graves"] * self.intensidad)
        lados = 6
        t = time.time() - self.t0
        poli = np.int32([[cx + r * math.cos(t + k * 2 * math.pi / lados), cy + r * math.sin(t + k * 2 * math.pi / lados)]
                         for k in range(lados)])
        col = self._tono((t * 0.1) % 1.0)
        cv2.polylines(self.fb, [poli], True, col, 3, cv2.LINE_AA)
        if A["kick"]:
            cv2.circle(self.fb, (int(cx), int(cy)), r + 25, (255, 255, 255), 4, cv2.LINE_AA)
        return np.clip(self.fb, 0, 255).astype(np.uint8)

    # ------------------------------------------------------------------ 6 anillos
    def fx_anillos(self, A, manos, puntas):
        cx, cy = self._centro(manos)
        if A["kick"]:
            self.anillos_l.append([cx, cy, 10.0, 0.15, 7])
        if A["snare"]:
            x, y = puntas[np.random.randint(len(puntas))] if puntas else (cx, cy)
            self.anillos_l.append([x, y, 5.0, 0.75, 3])
        self.buf *= 0.80
        img = np.zeros((self.h, self.w, 3), np.uint8)
        vivos = []
        for a in self.anillos_l:
            a[2] += 9 + 14 * A["nivel"] * self.intensidad
            alfa = max(0.0, 1 - a[2] / (self.w * 0.7))
            if alfa > 0.03:
                col = tuple(int(c * alfa) for c in self._tono(a[3]))
                cv2.circle(img, (int(a[0]), int(a[1])), int(a[2]), col, a[4], cv2.LINE_AA)
                vivos.append(a)
        self.anillos_l = vivos[-30:]
        return cv2.add(img, cv2.GaussianBlur(img, (0, 0), 4))

    # ------------------------------------------------------------------ 7 instancias
    def fx_instancias(self, A, manos):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        cols, filas = 16, 12
        cw, ch = self.w / cols, self.h / filas
        e = A["espectro"]
        cx, cy = self._centro(manos)
        for i in range(cols):
            v = float(e[int(i * len(e) / cols)])
            for j in range(filas):
                x, y = (i + 0.5) * cw, (j + 0.5) * ch
                dist = math.hypot(x - cx, y - cy) / (self.w * 0.6)
                s = max(0.0, v * (1.3 - dist) * self.intensidad)
                lado = int(min(cw, ch) * 0.45 * min(1.0, s))
                if lado > 1:
                    cv2.rectangle(img, (int(x - lado), int(y - lado)), (int(x + lado), int(y + lado)),
                                  self._tono(i / cols), -1)
        return img

    # ------------------------------------------------------------------ 8 estrobo
    def fx_estrobo(self, A, manos):
        if A["kick"]:
            self.flash, self.flash_col = 1.0, self._tono(np.random.rand())
        elif A["snare"]:
            self.flash, self.flash_col = 0.7, (255, 255, 255)
        img = np.zeros((self.h, self.w, 3), np.uint8)
        if self.flash > 0.05:
            img[:] = tuple(int(c * self.flash * 0.8) for c in self.flash_col)   # sin blanco total
        self.flash *= 0.6
        cx, cy = self._centro(manos)
        r = int(30 + 120 * A["graves"])
        cv2.circle(img, (int(cx), int(cy)), r, self._tono(A["agudos"]), 6, cv2.LINE_AA)
        return img

    # ------------------------------------------------------------------ 9 lineas sonoras
    def fx_lineas(self, A, manos):
        img = np.zeros((self.h, self.w, 3), np.uint8)
        n_lin, n_pts = 22, 64
        e = A["espectro"]
        t = time.time() - self.t0
        xs = np.linspace(self.w * 0.12, self.w * 0.88, n_pts)
        cx, _ = self._centro(manos)
        env = np.exp(-((xs - cx) / (self.w * 0.18)) ** 2)
        for k in range(n_lin):
            y0 = self.h * 0.12 + k * (self.h * 0.8 / n_lin)
            v = e[(k * 3) % len(e)]
            ruido = np.sin(xs * 0.05 + t * 2 + k) * np.sin(xs * 0.013 - t + k * 0.7)
            ys = y0 - env * (5 + 70 * v * self.intensidad) * (0.6 + 0.4 * np.abs(ruido))
            pts = np.int32(np.stack([xs, ys], 1))
            poli = np.vstack([pts, [[int(xs[-1]), int(y0 + 40)], [int(xs[0]), int(y0 + 40)]]])
            cv2.fillPoly(img, [poli], (0, 0, 0))                     # tapa las lineas de atras
            cv2.polylines(img, [pts[:, None]], False, self._tono(0.3 + 0.7 * v), 2, cv2.LINE_AA)
        return img

    # ------------------------------------------------------------------ 10 hiperespacio
    def fx_hiperespacio(self, A, manos):
        self.buf *= 0.6
        cx, cy = self._centro(manos)
        st = self.estrellas
        vel = 0.03 + 0.25 * A["nivel"] * self.intensidad + (0.4 if A["kick"] else 0)
        z0 = st[:, 2].copy()
        st[:, 2] -= vel * st[:, 2]
        nuevas = st[:, 2] < 0.45
        st[nuevas, :2] = np.random.randn(int(nuevas.sum()), 2)
        st[nuevas, 2] = 4.0
        z0[nuevas] = 4.0
        f = 120.0
        for (x, y, z), za in zip(st, z0):
            p1 = (int(cx + x * f / z), int(cy + y * f / z))
            p0 = (int(cx + x * f / za), int(cy + y * f / za))
            cv2.line(self.buf, p0, p1, float(min(255, 60 + 200 / z)), 1 if z > 1.5 else 2, cv2.LINE_AA)
        return self.color(np.clip(self.buf, 0, 255).astype(np.uint8))

    # ------------------------------------------------------------------ 11 metabolas
    def fx_metabolas(self, A, manos, puntas):
        gw, gh = 160, 120
        sx, sy = gw / float(self.w), gh / float(self.h)
        yy, xx = np.mgrid[0:gh, 0:gw].astype(np.float32)
        cx, cy = self._centro(manos)
        t = time.time() - self.t0
        bolas = []
        for k in range(5):
            a = t * (0.6 + 0.2 * k) + k * 1.3
            r = 70 + 40 * math.sin(t * 0.7 + k)
            bolas.append((cx + math.cos(a) * r * 1.4, cy + math.sin(a * 1.3) * r, 16 + 26 * A["graves"]))
        for (x, y) in puntas[:5]:
            bolas.append((x, y, 10 + 14 * A["medios"]))
        campo = np.zeros((gh, gw), np.float32)
        for x, y, r in bolas:
            campo += (r * sx) ** 2 / ((xx - x * sx) ** 2 + (yy - y * sy) ** 2 + 1)
        mapa = np.clip((campo - 0.9) * 140, 0, 255).astype(np.uint8)
        img = self.color(cv2.resize(mapa, (self.w, self.h), interpolation=cv2.INTER_LINEAR))
        return img

    def render_audio(self, nombre, A, manos, puntas):
        if nombre in ("anillos", "metabolas"):
            return getattr(self, "fx_" + nombre)(A, manos, puntas)
        return getattr(self, "fx_" + nombre)(A, manos)
