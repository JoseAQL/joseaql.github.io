#!/bin/bash
# Corre la estacion C++ en el proyector (framebuffer del HDMI, sin escritorio).
#   bash correr.sh                 normal
#   bash correr.sh --ahorro        fuente debil (cargador de 33 W): menos consumo
#   bash correr.sh --modo pintar   abrir directo un modo
# Las opciones fijas se pueden poner en opciones.txt (una linea), por ejemplo:  --ahorro --menu-der
# Salir: Ctrl+C  (los ajustes se guardan solos en ajustes.cfg)
cd "$(dirname "$0")"
[ -x build/estacion ] || { echo "Primero compila:  bash compilar.sh"; exit 1; }
EXTRA=""
[ -f opciones.txt ] && EXTRA="$(head -1 opciones.txt)"
# con el escritorio prendido el proyector no muestra el framebuffer
if pgrep -x Xorg >/dev/null; then
  echo "AVISO: el escritorio esta prendido y tapa al framebuffer. Apagalo con:"
  echo "   sudo systemctl isolate multi-user.target"
fi
# si la estacion de Python esta corriendo, se cierra (las dos no pueden usar la camara)
pkill -f "estacion.py" 2>/dev/null && sleep 1
pkill -f "estacion2.py" 2>/dev/null && sleep 1
pkill -x estacion 2>/dev/null && sleep 1     # otra copia de esta (por ejemplo la que arranca sola)
exec ./build/estacion --salida fb $EXTRA "$@"
