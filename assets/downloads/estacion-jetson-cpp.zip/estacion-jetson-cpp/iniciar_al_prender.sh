#!/bin/bash
# Hace que la estacion C++ arranque sola al prender la Jetson (y el modo de bajo consumo).
#   bash iniciar_al_prender.sh          -> activar
#   bash iniciar_al_prender.sh quitar   -> desactivar
DIR="$(cd "$(dirname "$0")" && pwd)"
LINEA="@reboot sleep 15 && cd $DIR && ./build/estacion --salida fb --sin-ver \$(head -1 opciones.txt 2>/dev/null) >> $DIR/estacion.log 2>&1"
crontab -l 2>/dev/null | grep -v "estacion_cpp\|$DIR/build/estacion" > /tmp/cron_estacion
if [ "$1" = "quitar" ]; then
  crontab /tmp/cron_estacion && echo "Listo: ya no arranca sola."
  exit 0
fi
echo "$LINEA" >> /tmp/cron_estacion
if [ "$(systemctl get-default 2>/dev/null)" = "graphical.target" ]; then
  echo "AVISO: la Jetson arranca con escritorio y eso tapa al proyector. Para arrancar sin escritorio:"
  echo "   sudo systemctl set-default multi-user.target"
fi
if crontab -l 2>/dev/null | grep -q "estacion.py\|iniciar_estacion"; then
  echo "AVISO: tambien arranca sola la version Python y se pelearian la camara. Quitala con:  crontab -e"
fi
crontab /tmp/cron_estacion && echo "Listo: arrancara sola al prender (log en $DIR/estacion.log)."
echo "Para el bajo consumo fijo:  sudo bash $DIR/bajo_consumo.sh --siempre"
