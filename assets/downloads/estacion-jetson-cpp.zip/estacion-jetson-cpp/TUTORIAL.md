# Estación C++ en la Jetson Nano — tutorial desde cero

Versión en C++ de la estación de proyección. Hace lo mismo que la de Python (calibrar, menú proyectado, modos con las manos), pero mucho más rápido:

- **La mano se detecta en C++ directo en la GPU** (poseNet `resnet18-hand` de jetson-inference). El Python de la Jetson solo era una capa encima de ese mismo C++, así que aquí no hace falta. Si algún día falla, se puede usar el **puente de Python** (`--motor python`), como en el juego del Kinect.
- **Cada cosa corre en su propio hilo**: cámara, detector, dibujo, sonido y la ventana por SSH. La ventana de tu PC ya no frena el proyector (en Python bajaba a 2 FPS).
- **Solo importan el pulgar y el índice**:
  - la punta del **índice** es el puntero;
  - **pulgar junto al índice = CERRADA** (es el clic);
  - **separados = ABIERTA**.
- **Calibración del proyector por puntos**: unos 4 segundos, contra ~25 s de la de ArUco.
- **Autocalibrado de la cámara para las manos**: prueba exposiciones con tu mano y se queda con la que mejor la ve.

---

## Resumen rápido (si ya sabes cómo)

```
sudo bash ~/estacion/bajo_consumo.sh          # bajo consumo (cargador de 33 W)
cd ~ && tar xzf estacion_cpp.tar.gz           # solo la primera vez (subes el .tar.gz con MobaXterm)
cd ~/estacion_cpp
bash compilar.sh                              # solo la primera vez (1 a 3 min)
bash correr.sh                                # corre en el proyector. Salir: Ctrl+C
```

---

## 0. Lo que necesitas

- Jetson Nano con lo que ya tiene instalado: JetPack 4.6, jetson-inference compilado, OpenCV 4.1.1, cmake. Ya lo revisé: todo está.
- Cámara USB, proyector por HDMI y adaptador de audio USB (para el sonido del piano).
- Tu PC con **MobaXterm** y el archivo **`estacion_cpp.tar.gz`**. Descárgalo de la conversación con Claude y guárdalo en `Documentos\asesor`.
- El cargador de 33 W por el conector redondo con el jumper J48 puesto.

## 1. Prender todo

1. Conecta a la Jetson el **HDMI del proyector**, la **cámara USB** y el **adaptador de audio**.
2. Prende el proyector y ponlo en la **entrada HDMI** (con el teclado si hace falta, como la otra vez).
3. Conecta la corriente de la Jetson y espera **1 minuto** a que arranque.

## 2. Entrar por SSH con MobaXterm

1. Abre MobaXterm → **Session → SSH**.
2. Remote host: `100.120.239.19` (o la IP de la Jetson en tu red). Usuario: `jetson`.
3. Revisa que **X11-Forwarding** esté activado; viene así por defecto. Con eso sale la ventana de cámara en tu PC.
4. Escribe tu contraseña cuando la pida.

## 3. Bajo consumo (por el cargador de 33 W)

Sin esto, la Jetson se puede apagar sola al cargar el detector:

```
sudo bash ~/estacion/bajo_consumo.sh
```

Para que se quede fijo en cada arranque: `sudo bash ~/estacion/bajo_consumo.sh --siempre`. También viene una copia en `~/estacion_cpp/bajo_consumo.sh`.

## 4. Copiar el código a la Jetson (solo la primera vez)

1. En la terminal escribe `cd ~`. Con la casilla **Follow terminal folder** activada (abajo del panel izquierdo), el panel de archivos se pone en `/home/jetson/`.
2. En el panel izquierdo usa el botón de **subir** (flecha verde hacia arriba) y elige `Documentos\asesor\estacion_cpp.tar.gz`. Si ya existía uno viejo, bórralo antes (`rm ~/estacion_cpp.tar.gz`), porque MobaXterm a veces no lo reemplaza.
3. En la terminal:

```
cd ~
tar xzf estacion_cpp.tar.gz
cd estacion_cpp
```

Queda en `~/estacion_cpp`. **No toca nada de `~/estacion`**: la versión de Python sigue igual.

## 5. Compilar (solo la primera vez, o cuando cambie el código)

```
bash compilar.sh
```

Tarda de 1 a 3 minutos. Al final debe decir:

```
-- poseNet C++ (GPU): SI
...
LISTO: ./build/estacion
  ... (compilados: posenet python sim ninguno)
```

Si dice `poseNet C++ (GPU): NO`, de todos modos funciona con el puente de Python. Avísame con lo que salió.

Si **no compila** y los errores mencionan `poseNet`, `jetson` o `cuda`, compila sin esa parte (usará el puente de Python, igual de funcional pero un poco más lento):

```
bash compilar.sh sin-posenet
```

## 6. Correr la estación

```
bash correr.sh
```

`opciones.txt` ya trae `--ahorro`: dibuja a 640x360 y 20 FPS, detecta 10 veces por segundo y una sola mano. Cuando tengas una fuente de 5 V 4 A, borra esa línea para ir a toda velocidad.

Lo que pasa al arrancar:

1. **Calibración (~4 s)**: el proyector se pone negro, luego muestra 4 puntos blancos y luego una rejilla de 20 puntos. **La cámara tiene que ver la proyección.** En la terminal sale algo como `Calibracion lista: error 0.8 px con 20 puntos`.
2. **"Cargando detector de manos..."**: ~15 segundos. Usa el mismo modelo que la versión Python (ya está optimizado para tu GPU), así que no tarda los minutos de la primera vez.
3. Sale el **MENÚ**.

En la terminal, cada 5 segundos sale una línea así:

```
Menu | dibujo 20 FPS | vision 10.0 FPS (detector 45 ms) | camara 30 FPS | manos 1 | luz 130
```

- **dibujo**: cuadros por segundo en el proyector.
- **vision**: cuántas veces por segundo busca la mano.
- **camara**: si baja de 30, la exposición está muy larga. Bájala con **A** o usa el autocalibrado.
- **luz**: lo ideal es entre 100 y 160.

Para salir: **Ctrl+C**. Los ajustes se guardan solos en `ajustes.cfg`. La primera vez se copian tus ajustes de la versión Python (`~/estacion/filtros.json`).

## 7. Cómo se usa con la mano

| Qué haces | Qué pasa |
|---|---|
| Mueves la punta del **índice** | Mueves el puntero (círculo verde) |
| **Juntas pulgar e índice** (pellizco) | **Clic inmediato**; el círculo se pone rojo |
| Dejas el índice **1.2 s** encima de algo | También lo elige (se llena el borde) |
| Índice o pellizco sobre **MENU** (arriba a la izquierda), 1 s | Regresa al menú |

Rozar el botón MENU con la mano abierta **no** te saca. Si te estorba ahí, corre `bash correr.sh --menu-der` y queda a la derecha.

## 8. Los modos del menú

| Modo | Qué hace |
|---|---|
| **Manos** | Prueba: dibuja pulgar e índice y dice ABIERTA o CERRADA. Pellizca dentro del círculo amarillo y te mide el tiempo de reacción |
| **Pintar** | Pellizca y mueve para pintar. Colores a la derecha; botón BORRAR |
| **Burbujas** | Juego de 30 s: revienta las burbujas con el índice |
| **Piano** | Pasa el índice por las teclas (Do a Do). Suena por el adaptador USB |
| **Partículas** | Cierra la mano y atraes las partículas; ábrela y explotan |
| **Autocalibrar** | Ajusta la cámara para tus manos (sección 10) |
| **Recalibrar** | Repite la calibración del proyector (si moviste cámara o proyector) |
| **Salir** | Cierra la estación |

## 9. La ventana por SSH (en tu PC) y las teclas

Se abre sola en tu PC: a la izquierda lo que ve la cámara con el pulgar y el índice marcados, a la derecha el **menú de ajustes**. **Da clic en esa ventana** y usa las teclas. La fila de arriba sube y la de abajo baja:

| Teclas | Ajuste |
|---|---|
| Q / A | Exposición de la cámara |
| W / S | Ganancia |
| E / D | Brillo |
| R / F | Contraste |
| T / G | Gamma (aclara sombras) |
| Y / H | CLAHE (contraste local) |
| U / J | Saturación |
| I / K | Suavizado |
| O / L | Recorte a la proyección: SÍ / NO |
| P / N | Umbral del detector |
| X / Z | Puntos mínimos por mano |
| V / C | Luz de relleno (gris para iluminar la mano) |
| 1 | Exposición automática |
| 2 | **Autocalibrar manos** |
| 3 | **Recalibrar el proyector** |
| 4 | Auto-exposición continua SÍ/NO (mantiene la imagen ni quemada ni oscura) |
| B | Cambiar vista: lo que ve el detector o la cámara completa |
| M | Guardar ahora |
| 0 | Regresar los filtros a como venían (la cámara se queda igual) |
| 9 | Ir al menú |

**Las mismas teclas funcionan en la terminal de MobaXterm**, aunque no salga la ventana.

En la ventana también ves los FPS de la visión, el dibujo y la cámara, la **latencia** y la **luz**. Para que el detector vea bien la mano, la luz debe estar entre **100 y 160**. Si pasa de 200, la imagen está quemada: baja la exposición con **A** o usa el autocalibrado.

## 10. Autocalibrado de manos

1. Entra a **Autocalibrar** en el menú, o presiona **2**.
2. Pon la mano **abierta y quieta** dentro del cuadro proyectado.
3. Prueba 8 exposiciones, ~1.5 s cada una, y ve con cuál detecta mejor el pulgar y el índice sin quemar la imagen.
4. Te muestra las barras, se queda con la mejor, la **guarda** y regresa al menú.

Si dice "No vi bien la mano": acerca la mano, sube la luz de relleno con **V** y repite.

## 11. Opciones útiles

```
bash correr.sh --modo pintar      abre directo un modo (manos, pintar, burbujas, piano, particulas, autocalibrar)
bash correr.sh --sin-calibrar     no calibra: usa la ultima calibracion guardada
bash correr.sh --calib-python     usa la calibracion de la version Python (~/estacion/calib_hdmi.json)
bash correr.sh --motor python     landmarks por el puente de Python
bash correr.sh --sin-ver          sin ventana en tu PC
bash correr.sh --ssh-sin-hilo     si la ventana de tu PC falla, la dibuja de otra forma
bash correr.sh --audio no         sin sonido
./build/estacion --ayuda          todas las opciones
```

Para que arranque sola al prender la Jetson: `bash iniciar_al_prender.sh`. Para quitarlo: `bash iniciar_al_prender.sh quitar`.

## 12. Si algo falla

| Problema | Qué hacer |
|---|---|
| `FALTA OpenCV para C++` al compilar | `sudo apt install libopencv-dev` |
| No compila (errores de poseNet/cuda) | `bash compilar.sh sin-posenet` |
| `poseNet C++ (GPU): NO` | Sigue funcionando con `--motor python`. Revisa que exista `/usr/local/include/jetson-inference/poseNet.h` |
| La Jetson se apaga al cargar el detector | `sudo bash ~/estacion/bajo_consumo.sh` y deja `--ahorro` en `opciones.txt` |
| `No vi los puntos` / `SIN CALIBRACION` | La cámara no ve la proyección: muévela, apaga la luz del cuarto y presiona **3**. O usa `--calib-python` |
| `No abre la camara 0` | Está ocupada por la versión Python: `pkill -f estacion` y vuelve a correr |
| No sale la ventana en tu PC | Activa X11 en MobaXterm. Prueba `--ssh-sin-hilo`, o usa las teclas en la terminal |
| No se ve nada en el proyector | Entrada HDMI del proyector. Si `correr.sh` avisa que el escritorio está prendido: `sudo systemctl isolate multi-user.target` |
| La mano no se detecta bien | Autocalibrar (**2**), luz de relleno (**V**), umbral (**N** baja, ve más) |
| Se ve un cursor parpadeando en el proyector | `sudo sh -c 'echo 0 > /sys/class/graphics/fbcon/cursor_blink'` |
| Después de un error la terminal ya no muestra lo que escribes | Escribe `reset` y Enter |
| El clic (pellizco) se activa solo o no se activa | En `ajustes.cfg`: `pinza_cerrar` (cerrar: más alto = más fácil) y `pinza_abrir` |

## 13. Cómo está organizado el código

```
estacion_cpp/
  compilar.sh            compila (revisa dependencias)
  correr.sh              corre en el proyector (lee opciones.txt)
  opciones.txt           opciones fijas (trae --ahorro)
  ajustes.cfg            ajustes guardados (se crea solo)
  calibracion.txt        ultima calibracion del proyector (se crea sola)
  iniciar_al_prender.sh  arranque automatico
  bajo_consumo.sh        modo 5 W para fuentes debiles
  CMakeLists.txt
  src/
    main.cpp         opciones de la linea de comandos
    app.cpp/.hpp     la estacion: arranque, bucle principal, boton MENU, teclas, ventana SSH
    modos.cpp        menu y modos (Manos, Pintar, Burbujas, Piano, Particulas, Autocalibrar...)
    manos.cpp/.hpp   puntero = punta del indice (suavizado y adelantado), pinza pulgar-indice con histeresis
    vision.cpp/.hpp  hilo de vision: recorte, gamma, CLAHE... y detector
    detector.cpp/.hpp  poseNet C++ (GPU), puente Python, simulado
    camara.cpp/.hpp  hilo de captura (cuadro mas nuevo) y controles V4L2 (exposicion, ganancia...)
    calibracion.cpp/.hpp  calibracion del proyector por puntos (homografia)
    salida.cpp/.hpp  framebuffer del HDMI (escribe directo en /dev/fb0), ventana, PNG
    sonido.cpp/.hpp  notas y efectos con aplay (un solo tubo abierto, poco retraso)
    ui.cpp/.hpp      texto, botones (pellizco o dedo encima), cursor, barras
    ajustes.cpp/.hpp ajustes.cfg (e importa filtros.json de la version Python)
    comun.cpp/.hpp   tiempo, log, filtro One Euro, completar puntos de la mano
  pruebas/prueba_sim.py   prueba automatica con camara y mano simuladas (en una PC)
```

Para agregar un modo nuevo: copia una clase de `modos.cpp` (por ejemplo `ModoPiano`), cámbiale el nombre y agrégala en `crear_modos()`. Recibe `c.manos`; cada mano trae `punta`, `cerrada`, `evento_cerrar` y `evento_abrir`.
