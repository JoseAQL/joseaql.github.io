# Estación de proyección interactiva en C++ (Jetson Nano)

Un proyector y una cámara sobre la mesa. La estación se calibra sola proyectando puntos, muestra un menú proyectado y se controla con la mano: la punta del **índice** es el puntero y juntar **pulgar con índice** es el clic.

Es la versión en C++ de la estación que primero se hizo en Python. Está pensada para que la Jetson Nano no batalle:

- **Detección de la mano en la GPU** con poseNet `resnet18-hand` (jetson-inference). Si hace falta, también puede leer los puntos de la mano desde Python (`--motor python`).
- **Un hilo por tarea**: cámara, visión, dibujo, sonido y la ventana de ajustes por SSH. La ventana de tu PC ya no frena al proyector.
- **Calibración del proyector por puntos** (unos 4 s): resta la imagen en negro, saca una homografía con 4 puntos y la afina con una rejilla de 5 × 4 usando RANSAC.
- **Autocalibración de la cámara para las manos**: prueba 8 exposiciones y se queda con la más corta que todavía detecta bien el pulgar y el índice.
- **Modos**: menú, prueba de manos, pintar, burbujas, piano, partículas, autocalibrar y recalibrar.

> Todavía no se ha medido en la Jetson real. El programa escribe cada 5 s los FPS de dibujo, de visión y los ms del detector, para comparar con la versión de Python.

## Versiones

| Versión | Qué cambió |
|---|---|
| **v1 (vigente)** | Primera versión en C++: hilos separados, poseNet en GPU, calibración por puntos, autocalibración de manos y los modos del menú. |

Las siguientes iteraciones se guardan con su número en esta misma carpeta y se agregan aquí.

## Arranque rápido

```bash
sudo bash bajo_consumo.sh      # opcional: modo 5 W para fuentes débiles
bash compilar.sh               # la primera vez (1 a 3 min)
bash correr.sh                 # corre en el proyector; salir con Ctrl+C
```

El paso a paso desde cero (prender la Jetson, pasar la carpeta con MobaXterm, compilar, calibrar, teclas del panel por SSH y qué hacer si algo falla) está en **[TUTORIAL.md](TUTORIAL.md)**.

## Estructura

| Archivo | Para qué |
|---|---|
| `src/main.cpp` | Opciones de línea de comandos |
| `src/app.*` | Programa principal: arranque, ciclo de dibujo, teclas y ventana por SSH |
| `src/camara.*` | Captura en su propio hilo y controles V4L2 (exposición, ganancia…) |
| `src/detector.*` | poseNet en GPU, puente de Python o detector simulado |
| `src/vision.*` | Recorte, preprocesamiento y detección en su propio hilo |
| `src/manos.*` | Paso de cámara a proyector, filtro One Euro, predicción y pellizco |
| `src/calibracion.*` | Calibración del proyector por puntos proyectados |
| `src/modos.cpp` | Menú y modos de la estación |
| `src/salida.*` | Salida directa al HDMI (framebuffer), ventana o PNG |
| `src/sonido.*` | Sonido con poco retraso por `aplay` |
| `src/ui.*` | Texto, botones y cursor |
| `pruebas/prueba_sim.py` | Prueba automática con cámara y manos simuladas |
| `compilar.sh`, `correr.sh`, `iniciar_al_prender.sh`, `bajo_consumo.sh` | Compilar, correr, arranque automático y bajo consumo |
