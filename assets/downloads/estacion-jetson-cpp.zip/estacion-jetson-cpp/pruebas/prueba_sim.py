#!/usr/bin/env python3
"""Prueba automatica de la estacion C++ con camara y mano simuladas (en la PC, sin Jetson).
Mueve una mano falsa (escribiendo /tmp/fake_objetivo.json) y revisa el log y las imagenes.
  python3 pruebas/prueba_sim.py            (desde la carpeta estacion_cpp, ya compilada)
"""
import json, math, os, re, shutil, subprocess, sys, threading, time

AQUI = os.path.dirname(os.path.abspath(__file__))
RAIZ = os.path.dirname(AQUI)
SAL = "/tmp/ec"
os.makedirs(SAL, exist_ok=True)
OBJ = "/tmp/fake_objetivo.json"
lineas, res = [], {}


def obj(x=None, y=None, forma="abierta"):
    tmp = OBJ + ".tmp"
    json.dump({"mano": x is not None, "x": x or 0, "y": y or 0, "forma": forma}, open(tmp, "w"))
    os.replace(tmp, OBJ)


def esperar(patron, timeout=5.0, desde=0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        for i in range(desde, len(lineas)):
            if re.search(patron, lineas[i]):
                return time.time() - t0, i + 1
        time.sleep(0.02)
    return None, len(lineas)


def foto(nombre):
    time.sleep(0.6)
    if os.path.exists(SAL + "/ultimo.png"):
        shutil.copy(SAL + "/ultimo.png", SAL + "/" + nombre + ".png")


def main():
    for f in ("ajustes.cfg", "calibracion.txt"):
        if os.path.exists(os.path.join(RAIZ, f)):
            os.remove(os.path.join(RAIZ, f))
    xvfb = subprocess.Popen(["Xvfb", ":99", "-screen", "0", "1400x900x24"], stderr=subprocess.DEVNULL)
    time.sleep(1)
    env = dict(os.environ, DISPLAY=":99")
    obj()
    p = subprocess.Popen([RAIZ + "/build/estacion", "--camara", "sim", "--salida", "png:" + SAL, "--motor", "sim",
                          "--audio", "no", "--teclas-stdin", "--duracion", "120"],
                         stdin=subprocess.PIPE, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, env=env, cwd=RAIZ)

    def leer():
        for l in p.stderr:
            l = l.decode("utf-8", "ignore").rstrip()
            lineas.append(l)
            print("   |", l)
    threading.Thread(target=leer, daemon=True).start()

    t, i = esperar("Manos listas", 20)
    res["arranque_s"] = t
    time.sleep(1.5)
    # cuadricula del menu 852x480: 4x2 mosaicos
    def centro(k):
        tw, th = (852 - 24 - 30) / 4.0, (480 - 64 - 10 - 10) / 2.0
        return 12 + (k % 4) * (tw + 10) + tw / 2, 64 + (k // 4) * (th + 10) + th / 2

    # 1) Piano con pellizco (clic inmediato)
    x, y = centro(3)
    obj(x, y); time.sleep(0.5)
    obj(x, y, "pinza")
    t, i = esperar("Modo: Piano", 3, i)
    res["piano_por_pellizco_s"] = t
    obj(x, y); time.sleep(0.3)
    for xx in range(40, 830, 50):
        obj(xx, 330); time.sleep(0.1)
    foto("piano")
    # 2) boton MENU con el dedo encima (1 s)
    obj(70, 40)
    t, i = esperar("Modo: Menu", 3, i)
    res["menu_por_dedo_s"] = t
    obj(); time.sleep(1.0)
    # 3) Pintar con el dedo encima (dwell)
    x, y = centro(1)
    obj(x, y)
    t, i = esperar("Modo: Pintar", 3, i)
    res["pintar_por_dwell_s"] = t
    obj(); time.sleep(0.5)
    obj(200, 250, "pinza"); time.sleep(0.3)
    for xx in range(200, 620, 8):
        obj(xx, 250 + 60 * math.sin(xx / 45.0), "pinza"); time.sleep(0.03)
    obj(620, 250); time.sleep(0.4)
    foto("pintar")
    # 4) mano abierta pasando por el boton MENU sin quedarse: NO debe salir
    for yy in range(300, 0, -40):
        obj(100, yy); time.sleep(0.05)
    obj(400, 300); time.sleep(1.5)
    t, _ = esperar("Modo: Menu", 0.2, i)
    res["roce_menu_no_sale"] = t is None
    # 5) menu con pellizco en el boton
    obj(70, 40); time.sleep(0.4); obj(70, 40, "pinza")
    t, i = esperar("Modo: Menu", 3, i)
    res["menu_por_pellizco_s"] = t
    obj(); time.sleep(1.0)
    # 6) Burbujas
    x, y = centro(2)
    obj(x, y); time.sleep(0.4); obj(x, y, "pinza")
    t, i = esperar("Modo: Burbujas", 3, i)
    obj(x, y)
    for k in range(70):
        obj(80 + (k * 97) % 700, 120 + (k * 53) % 330); time.sleep(0.08)
    foto("burbujas")
    # 7) teclas por la terminal
    p.stdin.write(b"vq"); p.stdin.flush()
    t, i = esperar("Ajuste: Exposicion manual", 3, i)
    res["teclas_stdin"] = t is not None
    # 8) autocalibrado (tecla 2) con la mano quieta en el cuadro
    obj(426, 300)
    p.stdin.write(b"2"); p.stdin.flush()
    t, i = esperar("Modo: Autocalibrar", 3, i)
    time.sleep(6)
    foto("autocal_probando")
    t, i = esperar("Autocal: me quedo con exposicion (\\d+)", 30, i)
    m = re.search("exposicion (\\d+)", lineas[i - 1]) if t else None
    res["autocal_exposicion"] = int(m.group(1)) if m else None
    time.sleep(1.0)
    foto("autocal_resultado")
    subprocess.call(["import", "-window", "root", SAL + "/ventana_ssh.png"], env=env)
    t, i = esperar("Modo: Menu", 8, i)
    # 9) Particulas
    obj(); time.sleep(1.0)
    x, y = centro(4)
    obj(x, y); time.sleep(0.4); obj(x, y, "pinza")
    t, i = esperar("Modo: Particulas", 3, i)
    obj(x, y)
    for k in range(40):
        obj(300 + 150 * math.cos(k / 5.0), 260 + 100 * math.sin(k / 5.0), "pinza" if k > 25 else "abierta")
        time.sleep(0.05)
    obj(300, 260); time.sleep(0.3)
    foto("particulas")
    # 10) Manos (prueba)
    obj(70, 40)
    t, i = esperar("Modo: Menu", 3, i)
    obj(); time.sleep(1.0)
    x, y = centro(0)
    obj(x, y); time.sleep(0.4); obj(x, y, "pinza")
    t, i = esperar("Modo: Manos", 3, i)
    obj(430, 300); time.sleep(1.0)
    foto("manos")
    # 11) Recalibrar con tecla 3
    obj()
    p.stdin.write(b"3"); p.stdin.flush()
    t, i = esperar("Calibracion lista", 10, i)
    res["recalibrar_tecla"] = t
    # 12) Salir desde el menu
    time.sleep(1.5)
    x, y = centro(7)
    obj(x, y); time.sleep(0.4); obj(x, y, "pinza")
    try:
        p.wait(timeout=8)
        res["salio"] = True
    except subprocess.TimeoutExpired:
        res["salio"] = False
        p.kill()
    xvfb.kill()
    print("RESULTADOS", json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
