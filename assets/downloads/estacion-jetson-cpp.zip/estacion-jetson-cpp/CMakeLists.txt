cmake_minimum_required(VERSION 3.10)
project(estacion_cpp CXX)
if(POLICY CMP0148)
  cmake_policy(SET CMP0148 OLD)   # FindPythonLibs en cmake nuevos
endif()

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG")
if(CMAKE_SYSTEM_PROCESSOR MATCHES "aarch64")
  set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -mcpu=cortex-a57")      # CPU de la Jetson Nano
endif()

option(USAR_POSENET "poseNet de jetson-inference en C++ (GPU)" ON)
option(USAR_PYTHON "Puente a Python para sacar los landmarks (Python C API)" ON)
set(JETSON_PREFIX "/usr/local" CACHE PATH "donde se instalo jetson-inference")

find_package(OpenCV REQUIRED COMPONENTS core imgproc imgcodecs highgui videoio calib3d)
find_package(Threads REQUIRED)

add_executable(estacion
  src/main.cpp src/app.cpp src/modos.cpp src/ui.cpp src/manos.cpp src/vision.cpp
  src/detector.cpp src/camara.cpp src/calibracion.cpp src/salida.cpp src/sonido.cpp
  src/ajustes.cpp src/comun.cpp)
target_include_directories(estacion PRIVATE ${OpenCV_INCLUDE_DIRS})
target_link_libraries(estacion ${OpenCV_LIBS} Threads::Threads)

# ---------------------------------------------------------------- poseNet en C++ (jetson-inference)
if(USAR_POSENET)
  find_path(JI_INCLUDE jetson-inference/poseNet.h PATHS ${JETSON_PREFIX}/include /usr/local/include NO_DEFAULT_PATH)
  find_library(JI_LIB jetson-inference PATHS ${JETSON_PREFIX}/lib /usr/local/lib NO_DEFAULT_PATH)
  find_library(JU_LIB jetson-utils PATHS ${JETSON_PREFIX}/lib /usr/local/lib NO_DEFAULT_PATH)
  find_path(CUDA_INC cuda_runtime.h PATHS ${JETSON_PREFIX}/cuda/include /usr/local/cuda/include NO_DEFAULT_PATH)
  find_library(CUDART_LIB cudart PATHS ${JETSON_PREFIX}/cuda/lib64 /usr/local/cuda/lib64 NO_DEFAULT_PATH)
  if(JI_INCLUDE AND JI_LIB AND JU_LIB AND CUDA_INC AND CUDART_LIB)
    message(STATUS "poseNet C++ (GPU): SI  (${JI_LIB})")
    target_compile_definitions(estacion PRIVATE CON_POSENET)
    target_include_directories(estacion PRIVATE ${JI_INCLUDE} ${JI_INCLUDE}/jetson-inference
                               ${JI_INCLUDE}/jetson-utils ${CUDA_INC})
    target_link_libraries(estacion ${JI_LIB} ${JU_LIB} ${CUDART_LIB})
    if(EXISTS /usr/lib/aarch64-linux-gnu/tegra)
      target_link_libraries(estacion "-Wl,-rpath-link,/usr/lib/aarch64-linux-gnu/tegra")
    endif()
  else()
    message(STATUS "poseNet C++ (GPU): NO (no encontre jetson-inference en ${JETSON_PREFIX})")
  endif()
endif()

# ---------------------------------------------------------------- puente a Python
if(USAR_PYTHON)
  find_package(PythonLibs 3 QUIET)
  if(PYTHONLIBS_FOUND)
    message(STATUS "Puente Python: SI  (${PYTHON_LIBRARIES})")
    target_compile_definitions(estacion PRIVATE CON_PYTHON)
    target_include_directories(estacion PRIVATE ${PYTHON_INCLUDE_DIRS})
    target_link_libraries(estacion ${PYTHON_LIBRARIES})
  else()
    message(STATUS "Puente Python: NO (instala python3-dev)")
  endif()
endif()
