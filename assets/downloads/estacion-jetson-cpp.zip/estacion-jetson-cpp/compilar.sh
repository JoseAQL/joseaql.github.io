#!/bin/bash
# Compila la estacion C++ en la Jetson (o en una PC con OpenCV).
#   bash compilar.sh          -> compila (1 a 3 minutos la primera vez)
#   bash compilar.sh limpio   -> borra lo compilado y empieza de cero
#   bash compilar.sh sin-posenet -> si falla la parte de poseNet en C++, compila solo con el puente de Python
cd "$(dirname "$0")"
echo "=== Revisando lo necesario"
falta=0
command -v cmake >/dev/null || { echo "  FALTA cmake:  sudo apt install cmake"; falta=1; }
command -v g++ >/dev/null || { echo "  FALTA g++:    sudo apt install g++"; falta=1; }
pkg-config --exists opencv4 || { echo "  FALTA OpenCV para C++:  sudo apt install libopencv-dev"; falta=1; }
[ $falta = 0 ] || exit 1
echo "  OpenCV $(pkg-config --modversion opencv4) | $(cmake --version | head -1) | g++ $(g++ -dumpversion)"
if [ -f /usr/local/include/jetson-inference/poseNet.h ]; then
  echo "  jetson-inference (poseNet en C++): SI"
else
  echo "  jetson-inference: NO -> se usara el puente de Python o el simulador"
fi
OPC=""
[ "$1" = "limpio" ] && rm -rf build
[ "$1" = "sin-posenet" ] && { rm -rf build; OPC="-DUSAR_POSENET=OFF"; }
mkdir -p build && cd build || exit 1
echo "=== Configurando"
cmake -DCMAKE_BUILD_TYPE=Release $OPC .. | grep -E "poseNet|Puente|Error|error" || exit 1
echo "=== Compilando (con $(nproc) nucleos)"
make -j"$(nproc)" 2>&1 | grep -E "error|Error|\[100%\]"
RESULTADO=${PIPESTATUS[0]}
if [ "$RESULTADO" = 0 ] && [ -x estacion ]; then
  echo ""
  echo "LISTO: ./build/estacion   (para correrla:  bash correr.sh)"
  ./estacion --ayuda | grep compilados
else
  echo ""
  echo "NO COMPILO. Copia los errores de arriba."
  echo "Si los errores hablan de poseNet / jetson / cuda, prueba:  bash compilar.sh sin-posenet"
  exit 1
fi
