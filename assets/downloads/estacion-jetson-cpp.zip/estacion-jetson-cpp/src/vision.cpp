#include "vision.hpp"

#include <algorithm>
#include <unistd.h>

#include <opencv2/imgproc.hpp>

namespace est {

void Vision::iniciar(Camara* cam, const Ajustes& aj, const std::string& motor, int fps_max, int max_manos) {
    detener();
    cam_ = cam;
    aj_ = aj;
    motor_ = motor;
    fps_max_ = fps_max;
    max_manos_ = std::max(1, max_manos);
    listo_ = false;
    t_inicio_ = ahora();
    vivo_ = true;
    th_ = std::thread(&Vision::hilo, this);
}

void Vision::detener() {
    vivo_ = false;
    if (th_.joinable()) th_.join();
}

void Vision::poner_roi(const cv::Rect& r) {
    std::lock_guard<std::mutex> lk(mtx_);
    roi_ = r;
}

void Vision::poner_ajustes(const Ajustes& aj) {
    std::lock_guard<std::mutex> lk(mtx_);
    aj_nuevos_ = aj;
    hay_aj_nuevos_ = true;
}

bool Vision::tomar(ResultadoVision& r, uint64_t ultimo_n) {
    std::lock_guard<std::mutex> lk(mtx_);
    if (res_.n <= ultimo_n) return false;
    r = res_;
    return true;
}

void Vision::copiar_vista(VistaVision& v) {
    std::lock_guard<std::mutex> lk(mtx_);
    v.camara = vista_.camara.clone();
    v.detector = vista_.detector.clone();
    v.roi = vista_.roi;
    v.cam_w = vista_.cam_w;
    v.cam_h = vista_.cam_h;
    v.manos = vista_.manos;
}

std::string Vision::detector() {
    std::lock_guard<std::mutex> lk(mtx_);
    return nombre_detector_;
}

std::string Vision::error() {
    std::lock_guard<std::mutex> lk(mtx_);
    return error_;
}

// recorte + suavizado + gamma + CLAHE + saturacion (lo mismo que filtros.py)
void Vision::preparar(const cv::Mat& cuadro, const cv::Rect& roi, cv::Mat& out) {
    cv::Mat img = cuadro(roi);
    bool copia = false;
    if (aj_.suavizado >= 3) {
        int k = aj_.suavizado | 1;
        cv::GaussianBlur(img, out, cv::Size(k, k), 0);
        img = out;
        copia = true;
    }
    if (std::fabs(aj_.gamma - 1.0f) > 1e-3) {
        if (lut_gamma_ != aj_.gamma) {
            lut_.create(1, 256, CV_8U);
            for (int i = 0; i < 256; i++)
                lut_.at<uchar>(i) = cv::saturate_cast<uchar>(std::pow(i / 255.0, 1.0 / aj_.gamma) * 255.0);
            lut_gamma_ = aj_.gamma;
        }
        cv::LUT(img, lut_, out);
        img = out;
        copia = true;
    }
    if (aj_.clahe > 0) {
        if (!clahe_ || clahe_valor_ != aj_.clahe) {
            clahe_ = cv::createCLAHE(aj_.clahe, cv::Size(8, 8));
            clahe_valor_ = aj_.clahe;
        }
        cv::Mat lab;
        cv::cvtColor(img, lab, cv::COLOR_BGR2Lab);
        std::vector<cv::Mat> c;
        cv::split(lab, c);
        clahe_->apply(c[0], c[0]);
        cv::merge(c, lab);
        cv::cvtColor(lab, out, cv::COLOR_Lab2BGR);
        img = out;
        copia = true;
    }
    if (aj_.saturacion < 0.99f || aj_.saturacion > 1.01f) {
        if (aj_.saturacion <= 0.01f) {
            cv::Mat g;
            cv::cvtColor(img, g, cv::COLOR_BGR2GRAY);
            cv::cvtColor(g, out, cv::COLOR_GRAY2BGR);
        } else {
            cv::Mat hsv;
            cv::cvtColor(img, hsv, cv::COLOR_BGR2HSV);
            std::vector<cv::Mat> c;
            cv::split(hsv, c);
            c[1].convertTo(c[1], -1, aj_.saturacion, 0);
            cv::merge(c, hsv);
            cv::cvtColor(hsv, out, cv::COLOR_HSV2BGR);
        }
        img = out;
        copia = true;
    }
    if (!copia) img.copyTo(out);
    else if (img.data != out.data) img.copyTo(out);
}

void Vision::hilo() {
    std::string err;
    std::unique_ptr<Detector> det = crear_detector(motor_, aj_.umbral, err);
    {
        std::lock_guard<std::mutex> lk(mtx_);
        if (det) nombre_detector_ = det->nombre();
        error_ = err;
    }
    if (!det) {
        log("Vision: sin detector de manos (%s)", err.c_str());
        return;
    }
    listo_ = true;
    log("Manos listas: detector %s (%.0f s en cargar)", nombre_detector_.c_str(), ahora() - t_inicio_);

    uint64_t id = 0;
    cv::Mat cuadro, entrada;
    double t_vista = 0, t_fps = ahora();
    int n_fps = 0;
    float fps = 0;
    uint64_t n = 0;
    std::vector<ManoCruda> manos;
    while (vivo_ && g_vivo) {
        if (pausado_) { usleep(20000); continue; }
        double t_cap;
        if (!cam_->esperar(id, cuadro, t_cap, 0.25)) continue;
        double t0 = ahora();
        cv::Rect roi;
        {
            std::lock_guard<std::mutex> lk(mtx_);
            if (hay_aj_nuevos_) {
                if (aj_nuevos_.umbral != aj_.umbral) det->set_umbral(aj_nuevos_.umbral);
                aj_ = aj_nuevos_;
                hay_aj_nuevos_ = false;
            }
            roi = roi_;
        }
        cv::Rect completo(0, 0, cuadro.cols, cuadro.rows);
        if (!aj_.recorte || roi.area() < 64 * 64) roi = completo;
        roi &= completo;
        preparar(cuadro, roi, entrada);
        manos.clear();
        det->procesar(entrada, roi.tl(), manos);
        // a pixeles de la camara completa, y solo las manos con suficientes puntos
        std::vector<ManoCruda> buenas;
        for (auto& m : manos) {
            if (m.vistos < aj_.min_puntos) continue;
            for (int i = 0; i < 21; i++)
                if (m.ok[i]) m.p[i] += cv::Point2f((float)roi.x, (float)roi.y);
            buenas.push_back(m);
        }
        std::sort(buenas.begin(), buenas.end(), [](const ManoCruda& a, const ManoCruda& b) { return a.vistos > b.vistos; });
        if ((int)buenas.size() > max_manos_) buenas.resize(max_manos_);
        double t1 = ahora();
        n_fps++;
        if (t1 - t_fps >= 1.0) {
            fps = float(n_fps / (t1 - t_fps));
            n_fps = 0;
            t_fps = t1;
        }
        cv::Scalar med = cv::mean(entrada);
        float luz = (float)((med[0] + med[1] + med[2]) / 3.0);
        {
            std::lock_guard<std::mutex> lk(mtx_);
            res_.n = ++n;
            res_.t_captura = t_cap;
            res_.t_listo = t1;
            res_.manos = buenas;
            res_.luz = luz;
            res_.roi = roi;
            res_.fps = fps;
            res_.ms_detector = float((t1 - t0) * 1000.0);
            if (t1 - t_vista > 0.15) {                // imagenes chicas para la ventana SSH
                t_vista = t1;
                int ancho = 560;
                cv::resize(cuadro, vista_.camara, cv::Size(ancho, ancho * cuadro.rows / cuadro.cols), 0, 0, cv::INTER_AREA);
                cv::resize(entrada, vista_.detector, cv::Size(ancho, std::max(1, ancho * entrada.rows / entrada.cols)), 0, 0, cv::INTER_AREA);
                vista_.roi = roi;
                vista_.cam_w = cuadro.cols;
                vista_.cam_h = cuadro.rows;
                vista_.manos = buenas;
            }
        }
        if (fps_max_ > 0) {
            double espera = 1.0 / fps_max_ - (ahora() - t0);
            if (espera > 0) usleep((useconds_t)(espera * 1e6));
        }
    }
}

}  // namespace est
