#include "detector.hpp"

#include <cstdlib>
#include <random>
#include <stdexcept>

#include <opencv2/imgproc.hpp>

#include "camara.hpp"

#ifdef CON_POSENET
#include <jetson-inference/poseNet.h>
#include <jetson-utils/cudaMappedMemory.h>
#include <jetson-utils/logging.h>
#endif

#ifdef CON_PYTHON
#include <Python.h>
#endif

namespace est {

// ====================================================================== poseNet en C++ (GPU)
#ifdef CON_POSENET
class DetectorPoseNet : public Detector {
public:
    explicit DetectorPoseNet(float umbral) {
        Log::SetLevel(Log::ERROR);                     // sin "duplicate link detected" y demas avisos
        net_ = poseNet::Create("resnet18-hand", umbral);
        if (!net_) throw std::runtime_error("no pude cargar resnet18-hand (jetson-inference)");
        if (net_->GetNumKeypoints() != 21)
            throw std::runtime_error("la red cargada no es de manos (21 puntos)");
    }
    ~DetectorPoseNet() override {
        delete net_;
        if (buf_) cudaFreeHost(buf_);
    }
    const char* nombre() const override { return "posenet (C++ GPU)"; }
    void set_umbral(float u) override { net_->SetThreshold(u); }

    bool procesar(const cv::Mat& bgr, cv::Point, std::vector<ManoCruda>& manos) override {
        const int w = bgr.cols, h = bgr.rows;
        const size_t n = (size_t)w * h * 3;
        if (n > cap_) {                                // memoria compartida CPU/GPU (sin copias)
            if (buf_) cudaFreeHost(buf_);
            buf_ = nullptr;
            cap_ = 0;
            if (!cudaAllocMapped(&buf_, n)) return false;
            cap_ = n;
        }
        cv::Mat rgb(h, w, CV_8UC3, buf_);
        cv::cvtColor(bgr, rgb, cv::COLOR_BGR2RGB);     // se escribe directo en la memoria de la GPU
        poses_.clear();
        if (!net_->Process((uchar3*)buf_, w, h, poses_, poseNet::OVERLAY_NONE)) return false;
        for (const auto& pose : poses_) {
            ManoCruda m;
            for (const auto& kp : pose.Keypoints) {
                if (kp.ID >= 21) continue;
                m.p[kp.ID] = cv::Point2f(kp.x, kp.y);
                if (!m.ok[kp.ID]) m.vistos++;
                m.ok[kp.ID] = true;
            }
            manos.push_back(m);
        }
        return true;
    }

private:
    poseNet* net_ = nullptr;
    void* buf_ = nullptr;
    size_t cap_ = 0;
    std::vector<poseNet::ObjectPose> poses_;
};
#endif

// ====================================================================== puente a Python
#ifdef CON_PYTHON
static const char* CODIGO_PYTHON = R"PY(
import os, sys
os.environ.setdefault("OPENBLAS_CORETYPE", "ARMV8")
import numpy as np
_motor = None
try:
    try:
        from jetson_inference import poseNet
        from jetson_utils import cudaFromNumpy
    except ImportError:
        import jetson.inference as _ji, jetson.utils as _ju
        poseNet, cudaFromNumpy = _ji.poseNet, _ju.cudaFromNumpy
    _net = poseNet(argv=["poseNet", "--network=resnet18-hand", "--threshold=%f" % _UMBRAL,
                         "--log-level=error"], threshold=_UMBRAL)
    _motor = "posenet"
except Exception as _e:
    import mediapipe as _mp
    _hands = _mp.solutions.hands.Hands(static_image_mode=False, max_num_hands=2, model_complexity=0,
                                      min_detection_confidence=0.45, min_tracking_confidence=0.45)
    _motor = "mediapipe"

def motor():
    return _motor

def umbral(u):
    if _motor == "posenet":
        _net.SetThreshold(float(u))

def procesar_mano(buf, w, h):
    """buf: RGB (bytes). Regresa [[id, x, y, id, x, y, ...], ...] en pixeles."""
    rgb = np.frombuffer(buf, dtype=np.uint8).reshape((h, w, 3))
    salida = []
    if _motor == "posenet":
        for pose in _net.Process(cudaFromNumpy(rgb), overlay="none"):
            fila = []
            for kp in pose.Keypoints:
                fila += [kp.ID, kp.x, kp.y]
            salida.append(fila)
    else:
        r = _hands.process(rgb)
        for lm in (r.multi_hand_landmarks or []):
            fila = []
            for i, q in enumerate(lm.landmark):
                fila += [i, q.x * w, q.y * h]
            salida.append(fila)
    return salida
)PY";

class DetectorPython : public Detector {
public:
    explicit DetectorPython(float umbral) {
        setenv("OPENBLAS_CORETYPE", "ARMV8", 0);
        if (!Py_IsInitialized()) Py_Initialize();
        std::string codigo = "_UMBRAL = " + std::to_string(umbral) + "\n" + CODIGO_PYTHON;
        if (PyRun_SimpleString(codigo.c_str()) != 0) throw std::runtime_error("el codigo de Python fallo (ver arriba)");
        PyObject* m = PyImport_AddModule("__main__");       // referencia prestada
        fn_ = PyObject_GetAttrString(m, "procesar_mano");
        fn_umbral_ = PyObject_GetAttrString(m, "umbral");
        PyObject* fm = PyObject_GetAttrString(m, "motor");
        if (!fn_ || !PyCallable_Check(fn_)) throw std::runtime_error("no encontre procesar_mano en Python");
        if (fm) {
            PyObject* r = PyObject_CallObject(fm, nullptr);
            if (r && PyUnicode_Check(r)) motor_ = std::string("python/") + PyUnicode_AsUTF8(r);
            Py_XDECREF(r);
            Py_DECREF(fm);
        }
    }
    ~DetectorPython() override {
        Py_XDECREF(fn_);
        Py_XDECREF(fn_umbral_);
    }
    const char* nombre() const override { return motor_.c_str(); }
    void set_umbral(float u) override {
        if (!fn_umbral_) return;
        PyObject* r = PyObject_CallFunction(fn_umbral_, "d", (double)u);
        Py_XDECREF(r);
    }
    bool procesar(const cv::Mat& bgr, cv::Point, std::vector<ManoCruda>& manos) override {
        cv::cvtColor(bgr, rgb_, cv::COLOR_BGR2RGB);
        PyObject* b = PyBytes_FromStringAndSize((const char*)rgb_.data, (Py_ssize_t)rgb_.total() * 3);
        PyObject* r = PyObject_CallFunction(fn_, "Oii", b, rgb_.cols, rgb_.rows);
        Py_DECREF(b);
        if (!r) { PyErr_Print(); return false; }
        if (PyList_Check(r)) {
            for (Py_ssize_t i = 0; i < PyList_Size(r); i++) {
                PyObject* fila = PyList_GetItem(r, i);         // prestada
                if (!PyList_Check(fila)) continue;
                ManoCruda m;
                Py_ssize_t n = PyList_Size(fila);
                for (Py_ssize_t k = 0; k + 2 < n; k += 3) {
                    long id = PyLong_AsLong(PyList_GetItem(fila, k));
                    double x = PyFloat_AsDouble(PyList_GetItem(fila, k + 1));
                    double y = PyFloat_AsDouble(PyList_GetItem(fila, k + 2));
                    if (id < 0 || id >= 21) continue;
                    m.p[id] = cv::Point2f((float)x, (float)y);
                    if (!m.ok[id]) m.vistos++;
                    m.ok[id] = true;
                }
                manos.push_back(m);
            }
        }
        Py_DECREF(r);
        return true;
    }

private:
    PyObject* fn_ = nullptr;
    PyObject* fn_umbral_ = nullptr;
    cv::Mat rgb_;
    std::string motor_ = "python";
};
#endif

// ====================================================================== simulado
class DetectorSim : public Detector {
public:
    const char* nombre() const override { return "simulado"; }
    bool procesar(const cv::Mat& bgr, cv::Point origen, std::vector<ManoCruda>& manos) override {
        float x, y;
        std::string forma;
        if (!sim::objetivo(x, y, forma)) return true;
        if (std::uniform_real_distribution<float>(0, 1)(rng_) > sim::calidad_por_exposicion()) return true;
        // forma de la mano en coordenadas de dibujo: punta del indice en (0,0), dedos hacia arriba
        static const float abierta[21][2] = {
            {0.02f, 1.0f}, {-0.15f, 0.85f}, {-0.28f, 0.70f}, {-0.38f, 0.55f}, {-0.45f, 0.42f},
            {-0.08f, 0.55f}, {-0.05f, 0.35f}, {-0.02f, 0.17f}, {0.0f, 0.0f},
            {0.05f, 0.55f}, {0.07f, 0.32f}, {0.08f, 0.14f}, {0.09f, -0.02f},
            {0.16f, 0.58f}, {0.19f, 0.38f}, {0.21f, 0.22f}, {0.22f, 0.08f},
            {0.26f, 0.65f}, {0.30f, 0.50f}, {0.33f, 0.38f}, {0.35f, 0.27f}};
        float rw = 853, rh = 480;
        if (const char* e = getenv("ESTACION_SIM_RENDER")) sscanf(e, "%fx%f", &rw, &rh);
        float esc = 0.28f * rh;
        std::vector<cv::Point2f> pr(21);
        for (int i = 0; i < 21; i++) pr[i] = cv::Point2f(x + abierta[i][0] * esc, y + abierta[i][1] * esc);
        if (forma == "pinza") {                        // pulgar tocando el indice
            pr[3] = cv::Point2f(x - 0.10f * esc, y + 0.14f * esc);
            pr[4] = cv::Point2f(x - 0.02f * esc, y + 0.04f * esc);
        }
        cv::Matx33d H = sim::render_a_camara((int)rw, (int)rh, camara_w(), camara_h());
        std::vector<cv::Point2f> pc;
        cv::perspectiveTransform(pr, pc, H);
        ManoCruda m;
        std::normal_distribution<float> ruido(0, 0.8f);
        for (int i = 0; i < 21; i++) {
            m.p[i] = pc[i] - cv::Point2f((float)origen.x, (float)origen.y) + cv::Point2f(ruido(rng_), ruido(rng_));
            m.ok[i] = m.p[i].x >= 0 && m.p[i].y >= 0 && m.p[i].x < bgr.cols && m.p[i].y < bgr.rows;
            m.vistos += m.ok[i];
        }
        if (m.vistos >= 5) manos.push_back(m);
        return true;
    }

private:
    static int camara_w() { const char* e = getenv("ESTACION_SIM_CAM"); int w = 640, h = 480; if (e) sscanf(e, "%dx%d", &w, &h); return w; }
    static int camara_h() { const char* e = getenv("ESTACION_SIM_CAM"); int w = 640, h = 480; if (e) sscanf(e, "%dx%d", &w, &h); return h; }
    std::mt19937 rng_{1234};
};

class DetectorNinguno : public Detector {
public:
    const char* nombre() const override { return "ninguno"; }
    bool procesar(const cv::Mat&, cv::Point, std::vector<ManoCruda>&) override { return true; }
};

// ====================================================================== fabrica
std::string motores_compilados() {
    std::string s;
#ifdef CON_POSENET
    s += "posenet ";
#endif
#ifdef CON_PYTHON
    s += "python ";
#endif
    s += "sim ninguno";
    return s;
}

std::unique_ptr<Detector> crear_detector(const std::string& motor, float umbral, std::string& error) {
    std::vector<std::string> orden;
    if (motor == "auto") orden = {"posenet", "python"};
    else orden = {motor};
    for (const auto& m : orden) {
        try {
            if (m == "posenet") {
#ifdef CON_POSENET
                return std::unique_ptr<Detector>(new DetectorPoseNet(umbral));
#else
                error += "posenet: no se compilo con jetson-inference; ";
                continue;
#endif
            }
            if (m == "python") {
#ifdef CON_PYTHON
                return std::unique_ptr<Detector>(new DetectorPython(umbral));
#else
                error += "python: no se compilo con Python.h; ";
                continue;
#endif
            }
            if (m == "sim") return std::unique_ptr<Detector>(new DetectorSim());
            if (m == "ninguno") return std::unique_ptr<Detector>(new DetectorNinguno());
            error += m + ": motor desconocido; ";
        } catch (const std::exception& e) {
            error += m + ": " + e.what() + "; ";
        }
    }
    return nullptr;
}

}  // namespace est
