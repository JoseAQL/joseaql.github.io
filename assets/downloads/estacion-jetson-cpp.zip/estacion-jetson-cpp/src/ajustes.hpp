// ajustes.hpp - todos los valores ajustables, guardados en ajustes.cfg (texto "clave = valor").
#pragma once

#include <map>
#include <string>

namespace est {

struct Ajustes {
    // camara (los controles V4L2 se guardan solo si se cambiaron: cam.exposure_absolute = 157 ...)
    std::map<std::string, int> ctrl;

    // preproceso de la imagen para el detector
    float gamma = 1.0f;          // >1 aclara sombras
    float clahe = 0.0f;          // contraste local (0 = apagado)
    float saturacion = 1.0f;     // 0 = gris
    int suavizado = 0;           // 0,3,5,7,9
    bool recorte = true;         // solo la zona proyectada (mas rapido y la mano se ve mas grande)

    // detector
    float umbral = 0.15f;        // poseNet: menos = ve mas (con mas errores)
    int min_puntos = 5;          // puntos minimos (de 21) para aceptar una mano

    // proyeccion
    int relleno = 0;             // gris minimo proyectado para iluminar la mano (0..150)

    // gestos (pulgar-indice)
    float pinza_cerrar = 0.30f;  // distancia pulgar-indice / largo del indice para "cerrada"
    float pinza_abrir = 0.45f;   // ... para volver a "abierta" (histeresis)
    int dwell_ms = 1200;         // dejar el dedo encima este tiempo tambien selecciona
    int prediccion_ms = 0;       // adelanto extra del puntero (compensa retraso)

    // auto-exposicion continua para las manos
    bool auto_exposicion = false;
    int luz_objetivo = 120;      // brillo medio buscado en la zona de las manos (0..255)

    bool cargar(const std::string& ruta);
    bool guardar(const std::string& ruta) const;
    bool importar_filtros_json(const std::string& ruta);   // filtros.json de la version Python
    void restaurar();                                        // todo de fabrica (menos la camara)
};

}  // namespace est
