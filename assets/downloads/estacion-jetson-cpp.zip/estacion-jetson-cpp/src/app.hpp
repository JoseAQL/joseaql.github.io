// app.hpp - la estacion: une camara, vision, manos, modos, salida al proyector y ventana SSH.
#pragma once

#include <deque>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <termios.h>

#include <opencv2/core.hpp>

#include "ajustes.hpp"
#include "calibracion.hpp"
#include "camara.hpp"
#include "manos.hpp"
#include "salida.hpp"
#include "sonido.hpp"
#include "ui.hpp"
#include "vision.hpp"

namespace est {

struct Opciones {
    std::string camara = "0";
    int cam_w = 640, cam_h = 480, cam_fps = 30;
    std::string salida = "fb";
    int alto = 480;                   // altura de dibujo (se escala al HDMI)
    std::string motor = "auto";
    bool ahorro = false;
    int max_manos = 2;
    bool calibrar = true;
    bool calib_python = false;        // usar calib_hdmi.json de la version Python
    bool ver = true;                  // ventana por SSH
    bool ssh_hilo = true;             // la ventana SSH en su propio hilo (no frena el proyector)
    std::string audio = "auto";
    bool menu_der = false;
    std::string modo_inicial;
    std::string config;               // ruta de ajustes.cfg
    double duracion = 0;              // segundos (pruebas); 0 = sin limite
    int fps = 30;                     // cuadros de dibujo por segundo
    bool teclas_stdin = false;        // leer teclas de la entrada estandar aunque no sea terminal (pruebas)
};

struct Contexto {
    double t = 0, dt = 0;
    int w = 0, h = 0;
    std::vector<ManoUI> manos;
};

class App;

class Modo {
public:
    explicit Modo(App& app) : app(app) {}
    virtual ~Modo() {}
    virtual const char* nombre() const = 0;
    virtual const char* descripcion() const { return ""; }
    virtual void entrar(const Contexto&) {}
    virtual void dibujar(const Contexto& c, cv::Mat& img) = 0;
    virtual void icono(cv::Mat& img, cv::Rect r, double t) const;
    virtual bool con_boton_menu() const { return true; }
    enum { NORMAL = 0, RECALIBRAR = 1, SALIR = 2 };
    virtual int accion() const { return NORMAL; }

protected:
    App& app;
};

std::vector<std::unique_ptr<Modo>> crear_modos(App& app);
std::unique_ptr<Modo> crear_menu(App& app, const std::vector<Modo*>& opciones);

// copia de lo que muestra la ventana SSH (se lee desde otro hilo)
struct Resumen {
    std::string modo, detector, error_detector;
    bool detector_listo = false;
    float fps_dibujo = 0, fps_vision = 0, ms_detector = 0, latencia_ms = 0, luz = 0, fps_camara = 0;
    std::vector<ManoUI> manos;
    Ajustes aj;
    std::string expo, ganancia, brillo, contraste;
    std::string aviso;
    double t_aviso = 0;
    int vista = 0;
    std::vector<cv::Point2f> contorno_cam;    // borde de la proyeccion visto por la camara
};

class App {
public:
    explicit App(const Opciones& op);
    ~App();
    int correr();

    // ---- para los modos
    Ajustes& ajustes() { return aj_; }
    ControlesV4L2& controles() { return ctl_; }
    Sonido& sonido() { return son_; }
    const ResultadoVision& ultimo() const { return res_; }
    bool detector_listo() { return vis_.listo(); }
    int ancho() const { return w_; }
    int alto() const { return h_; }
    double dwell() const { return aj_.dwell_ms / 1000.0; }
    void elegir(Modo* m) { siguiente_ = m; }
    void ir_menu();
    void ajustes_cambiados();
    void poner_control(const std::string& nombre, int valor);
    void guardar_ajustes();
    void aviso(const std::string& s);
    float fps_dibujo() const { return fps_dibujo_; }

    // ---- para la ventana SSH (otro hilo)
    Resumen resumen();
    void copiar_vista(VistaVision& v) { vis_.copiar_vista(v); }
    void tecla(int k);

private:
    bool iniciar();
    void cerrar();
    void mostrar(const cv::Mat& img);
    bool calibrar_proyector(bool al_inicio);
    void aplicar_calibracion(const Calibracion& c);
    void procesar_teclas();
    void boton_menu(Contexto& c, cv::Mat& img);
    void auto_exposicion(double t);
    void hilo_vista();
    void dibujar_vista(cv::Mat& out, const Resumen& r, const VistaVision& v);
    std::string valor_ctrl(const std::string& n);

    Opciones op_;
    Ajustes aj_;
    std::string ruta_aj_, ruta_calib_;
    std::unique_ptr<Salida> sal_;
    Camara cam_;
    ControlesV4L2 ctl_;
    Vision vis_;
    Sonido son_;
    SeguidorManos seg_;
    Calibracion calib_;
    cv::Matx33d H_ = cv::Matx33d::eye();
    int w_ = 853, h_ = 480;

    std::vector<std::unique_ptr<Modo>> modos_;
    std::unique_ptr<Modo> menu_;
    Modo* modo_ = nullptr;
    Modo* siguiente_ = nullptr;
    bool recalibrar_ = false;
    double t_modo_ = 0;
    ui::Boton boton_menu_;

    ResultadoVision res_;
    float fps_dibujo_ = 0;
    double t_expo_ = 0;

    // ventana SSH
    std::thread th_vista_;
    std::atomic<bool> vista_viva_{false};
    bool ver_ = false;
    std::mutex mtx_resumen_, mtx_teclas_;
    Resumen resumen_;
    std::deque<int> teclas_;
    std::string aviso_;
    double t_aviso_ = 0;
    int vista_ = 0;
    double t_vista_main_ = 0;
    // teclas desde la terminal SSH (sin ventana)
    bool teclas_tty_ = false, teclas_stdin_ = false;
    struct termios tty_orig_;
};

}  // namespace est
