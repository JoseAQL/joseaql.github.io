// modos.cpp - menu y modos de la estacion. Todos usan solo la punta del INDICE (puntero) y la pinza
// pulgar-indice (CERRADA = clic / pintar / atraer, ABIERTA = mover / soltar).
#include <algorithm>
#include <deque>
#include <map>
#include <random>

#include <opencv2/imgproc.hpp>

#include "app.hpp"

namespace est {

static std::mt19937 g_rng(42);
static float azar(float a, float b) { return std::uniform_real_distribution<float>(a, b)(g_rng); }

static cv::Scalar color_hsv(float h, float s = 1.0f, float v = 1.0f) {
    cv::Mat m(1, 1, CV_8UC3, cv::Scalar(h * 180.0f, s * 255.0f, v * 255.0f)), r;
    cv::cvtColor(m, r, cv::COLOR_HSV2BGR);
    cv::Vec3b c = r.at<cv::Vec3b>(0, 0);
    return cv::Scalar(c[0], c[1], c[2]);
}

// ====================================================================== MENU
class ModoMenu : public Modo {
public:
    ModoMenu(App& a, const std::vector<Modo*>& ops) : Modo(a), ops_(ops), botones_(ops.size()) {}
    const char* nombre() const override { return "Menu"; }
    bool con_boton_menu() const override { return false; }
    void entrar(const Contexto& c) override {
        t_entrar_ = c.t;
        for (auto& b : botones_) b.reiniciar();
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        ui::fondo(img);
        const int cols = 4, filas = (int)(ops_.size() + cols - 1) / cols;
        const int mx = 12, top = 64, gap = 10;
        float tw = (c.w - 2 * mx - (cols - 1) * gap) / (float)cols;
        float th = (c.h - top - 10 - (filas - 1) * gap) / (float)filas;
        ui::texto(img, "ESTACION", 14, 40, 1.15, ui::AMARILLO, false, 3);
        ui::texto(img, "Apunta con el indice: pellizca (pulgar+indice) o espera para elegir", 205, 34, 0.45, ui::GRIS, false, 1);
        ui::texto(img, cv::format("manos %d | vision %.0f FPS | dibujo %.0f FPS", (int)c.manos.size(), app.ultimo().fps,
                                  app.fps_dibujo()),
                  205, 54, 0.42, ui::VERDE, false, 1);
        bool espera = c.t - t_entrar_ < 0.8;                 // la mano que regreso no abre otro modo
        std::map<int, float> progreso;
        for (size_t i = 0; i < ops_.size(); i++) {
            int col = (int)i % cols, fil = (int)i / cols;
            ui::Boton& b = botones_[i];
            b.rect = cv::Rect((int)(mx + col * (tw + gap)), (int)(top + fil * (th + gap)), (int)tw, (int)th);
            b.etiqueta = ops_[i]->nombre();
            b.sub = ops_[i]->descripcion();
            bool activo = !espera && b.actualizar(c.manos, c.t, app.dwell());
            b.dibujar(img, c.t, app.dwell(), 0.62);
            cv::Rect ic(b.rect.x + 6, b.rect.y + 6, b.rect.width - 12, (int)(b.rect.height * 0.56));
            ops_[i]->icono(img, ic, c.t);
            for (const auto& m : c.manos)
                if (dentro(b.rect, m.punta)) progreso[m.id] = b.progreso(c.t, app.dwell());
            if (activo) {
                app.sonido().clic();
                app.elegir(ops_[i]);
            }
        }
        for (const auto& m : c.manos) ui::cursor(img, m, c.t, progreso.count(m.id) ? progreso[m.id] : 0);
    }

private:
    std::vector<Modo*> ops_;
    std::vector<ui::Boton> botones_;
    double t_entrar_ = 0;
};

// ====================================================================== MANOS (prueba de reaccion)
class ModoManos : public Modo {
public:
    using Modo::Modo;
    const char* nombre() const override { return "Manos"; }
    const char* descripcion() const override { return "Prueba pulgar e indice"; }
    void entrar(const Contexto& c) override {
        estelas_.clear();
        aciertos_ = 0;
        tiempos_.clear();
        nuevo_blanco(c);
    }
    void icono(cv::Mat& img, cv::Rect r, double) const override {
        cv::Point b(r.x + r.width / 2, r.y + r.height - 6);
        cv::line(img, b, b + cv::Point(-22, -30), ui::NARANJA, 3, cv::LINE_AA);
        cv::line(img, b + cv::Point(-22, -30), b + cv::Point(-26, -46), ui::NARANJA, 3, cv::LINE_AA);
        cv::line(img, b, b + cv::Point(6, -40), ui::CIAN, 3, cv::LINE_AA);
        cv::line(img, b + cv::Point(6, -40), b + cv::Point(8, -62), ui::CIAN, 3, cv::LINE_AA);
        cv::circle(img, b + cv::Point(8, -62), 5, ui::BLANCO, -1, cv::LINE_AA);
        cv::circle(img, b + cv::Point(-26, -46), 5, ui::BLANCO, -1, cv::LINE_AA);
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        // blanco a tocar: pellizco dentro del circulo
        float pulso = (float)(std::sin(c.t * 5) * 0.5 + 0.5);
        cv::circle(img, blanco_, 30 + (int)(pulso * 4), ui::AMARILLO, 3, cv::LINE_AA);
        cv::circle(img, blanco_, 6, ui::AMARILLO, -1, cv::LINE_AA);
        for (const auto& m : c.manos) {
            auto& e = estelas_[m.id];
            e.push_back(m.punta);
            if (e.size() > 25) e.pop_front();
            for (size_t i = 1; i < e.size(); i++)
                cv::line(img, e[i - 1], e[i], cv::Scalar(255, 120, 40) * (i / (double)e.size()), 3, cv::LINE_AA);
            if (m.evento_cerrar && dist(m.punta, blanco_) < 38) {
                aciertos_++;
                tiempos_.push_back(c.t - t_blanco_);
                if (tiempos_.size() > 10) tiempos_.erase(tiempos_.begin());
                app.sonido().nota(660 + 40 * (aciertos_ % 8), 0.25f);
                nuevo_blanco(c);
            }
        }
        ui::manos_dedos(img, c.manos, true);
        for (const auto& m : c.manos) {
            ui::cursor(img, m, c.t);
            ui::texto(img, cv::format("%s  %.2f", m.cerrada ? "CERRADA" : "ABIERTA", m.apertura), m.p[0].x - 50,
                      m.p[0].y + 34, 0.6, m.cerrada ? ui::ROJO : ui::VERDE2, false, 2);
        }
        double prom = 0;
        for (double v : tiempos_) prom += v;
        if (!tiempos_.empty()) prom /= tiempos_.size();
        ui::texto(img, "PRUEBA: pellizca dentro del circulo amarillo", c.w / 2.0f, 30, 0.6, ui::BLANCO, true, 1);
        ui::texto(img, cv::format("aciertos %d | tiempo promedio %.2f s", aciertos_, prom), c.w / 2.0f, 56, 0.55,
                  ui::AMARILLO, true, 1);
        const ResultadoVision& r = app.ultimo();
        ui::texto(img, cv::format("vision %.0f FPS  detector %.0f ms  luz %.0f", r.fps, r.ms_detector, r.luz), 10.0f,
                  c.h - 12.0f, 0.42, ui::GRIS, false, 1);
        if (c.manos.empty()) ui::texto(img, "Pon la mano sobre la mesa", c.w / 2.0f, c.h / 2.0f, 0.8, ui::GRIS, true, 2);
    }

private:
    void nuevo_blanco(const Contexto& c) {
        blanco_ = cv::Point2f(azar(c.w * 0.25f, c.w * 0.85f), azar(c.h * 0.3f, c.h * 0.85f));
        t_blanco_ = c.t;
    }
    std::map<int, std::deque<cv::Point2f>> estelas_;
    cv::Point2f blanco_;
    double t_blanco_ = 0;
    int aciertos_ = 0;
    std::vector<double> tiempos_;
};

// ====================================================================== PINTAR
class ModoPintar : public Modo {
public:
    using Modo::Modo;
    const char* nombre() const override { return "Pintar"; }
    const char* descripcion() const override { return "Pellizca para pintar"; }
    void entrar(const Contexto& c) override {
        lienzo_ = cv::Mat::zeros(c.h, c.w, CV_8UC3);
        ultimo_.clear();
        borrar_ = ui::Boton(cv::Rect(c.w - 130, c.h - 62, 120, 52), "BORRAR");
        borrar_.reiniciar();
    }
    void icono(cv::Mat& img, cv::Rect r, double t) const override {
        std::vector<cv::Point> pts;
        for (int i = 0; i <= 20; i++)
            pts.push_back(cv::Point(r.x + 15 + i * (r.width - 30) / 20,
                                    r.y + r.height / 2 + (int)(std::sin(i * 0.5 + t * 2) * r.height * 0.25)));
        cv::polylines(img, pts, false, ui::MAGENTA, 5, cv::LINE_AA);
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        static const cv::Scalar colores[] = {ui::CIAN, ui::MAGENTA, ui::AMARILLO, ui::VERDE2, ui::ROJO, ui::BLANCO};
        const int ncol = 6;
        if (lienzo_.size() != img.size()) entrar(c);
        // paleta (dedo encima 0.35 s o pellizco)
        for (int i = 0; i < ncol; i++) {
            cv::Point2f p(c.w - 34.0f, 84.0f + i * 46.0f);
            for (const auto& m : c.manos)
                if (dist(m.punta, p) < 22 && (m.evento_cerrar || c.t - t_paleta_[i] > 0.35)) {
                    if (color_ != i) app.sonido().clic();
                    color_ = i;
                }
            bool sobre = false;
            for (const auto& m : c.manos) sobre |= dist(m.punta, p) < 22;
            if (!sobre) t_paleta_[i] = c.t;
        }
        for (const auto& m : c.manos) {
            bool en_paleta = m.punta.x > c.w - 60;
            if (m.cerrada && !en_paleta) {
                auto it = ultimo_.find(m.id);
                if (it != ultimo_.end()) cv::line(lienzo_, it->second, m.punta, colores[color_], 7, cv::LINE_AA);
                ultimo_[m.id] = m.punta;
            } else {
                ultimo_.erase(m.id);
            }
        }
        if (borrar_.actualizar(c.manos, c.t, app.dwell())) {
            lienzo_.setTo(cv::Scalar::all(0));
            app.sonido().pop(0.7f);
        }
        lienzo_.copyTo(img);
        for (int i = 0; i < ncol; i++) {
            cv::Point p(c.w - 34, 84 + i * 46);
            cv::circle(img, p, 18, colores[i], -1, cv::LINE_AA);
            cv::circle(img, p, 21, i == color_ ? ui::BLANCO : ui::GRIS_OSC, i == color_ ? 3 : 1, cv::LINE_AA);
        }
        borrar_.dibujar(img, c.t, app.dwell(), 0.6);
        ui::texto(img, "PINTAR: junta pulgar e indice para pintar", c.w / 2.0f, c.h - 16.0f, 0.5, ui::GRIS, true, 1);
        for (const auto& m : c.manos) {
            ui::cursor(img, m, c.t);
            cv::circle(img, m.punta, 5, colores[color_], -1, cv::LINE_AA);
        }
    }

private:
    cv::Mat lienzo_;
    std::map<int, cv::Point2f> ultimo_;
    int color_ = 0;
    double t_paleta_[6] = {0, 0, 0, 0, 0, 0};
    ui::Boton borrar_;
};

// ====================================================================== BURBUJAS (reaccion)
class ModoBurbujas : public Modo {
public:
    using Modo::Modo;
    const char* nombre() const override { return "Burbujas"; }
    const char* descripcion() const override { return "Revientalas: 30 s"; }
    void entrar(const Contexto& c) override {
        burbujas_.clear();
        chispas_.clear();
        puntos_ = 0;
        t0_ = c.t;
        t_nace_ = c.t;
        fin_ = false;
        otra_ = ui::Boton(cv::Rect(c.w / 2 - 110, c.h / 2 + 40, 220, 64), "OTRA VEZ");
        otra_.reiniciar();
    }
    void icono(cv::Mat& img, cv::Rect r, double t) const override {
        for (int k = 0; k < 4; k++) {
            int y = r.y + r.height - 12 - (int)(std::fmod(t * 25 + k * 17, std::max(1, r.height - 28)));
            cv::circle(img, cv::Point(r.x + 20 + k * (r.width - 40) / 3, y), 7 + k * 2, color_hsv(k * 0.2f), 2, cv::LINE_AA);
        }
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        const double duracion = 30;
        double resta = duracion - (c.t - t0_);
        if (!fin_ && resta <= 0) {
            fin_ = true;
            record_ = std::max(record_, puntos_);
            otra_.reiniciar();
        }
        if (!fin_ && c.t - t_nace_ > 0.55 && burbujas_.size() < 7) {
            t_nace_ = c.t;
            Burbuja b;
            b.r = azar(22, 40);
            b.p = cv::Point2f(azar(b.r + 20, c.w - b.r - 20), c.h + b.r);
            b.v = cv::Point2f(azar(-15, 15), -azar(45, 95) - (float)(c.t - t0_) * 1.5f);
            b.col = color_hsv(azar(0, 1), 0.7f, 1.0f);
            burbujas_.push_back(b);
        }
        for (auto& b : burbujas_) b.p += b.v * (float)c.dt;
        for (size_t i = 0; i < burbujas_.size();) {
            Burbuja& b = burbujas_[i];
            bool rota = false;
            if (!fin_)
                for (const auto& m : c.manos)
                    if (dist(m.punta, b.p) < b.r + 6) rota = true;
            if (rota) {
                puntos_++;
                app.sonido().pop(azar(0.8f, 1.4f));
                for (int k = 0; k < 14; k++) {
                    float a = azar(0, 6.283f), v = azar(80, 220);
                    chispas_.push_back({b.p, cv::Point2f(std::cos(a) * v, std::sin(a) * v), c.t, b.col});
                }
            }
            if (rota || b.p.y < -b.r) burbujas_.erase(burbujas_.begin() + i);
            else i++;
        }
        for (const auto& b : burbujas_) {
            cv::circle(img, b.p, (int)b.r, b.col * 0.35, -1, cv::LINE_AA);
            cv::circle(img, b.p, (int)b.r, b.col, 2, cv::LINE_AA);
            cv::circle(img, b.p + cv::Point2f(-b.r * 0.35f, -b.r * 0.35f), (int)(b.r * 0.2f), ui::BLANCO, -1, cv::LINE_AA);
        }
        for (size_t i = 0; i < chispas_.size();) {
            auto& s = chispas_[i];
            double edad = c.t - s.t;
            if (edad > 0.5) { chispas_.erase(chispas_.begin() + i); continue; }
            s.p += s.v * (float)c.dt;
            cv::circle(img, s.p, 3, s.col * (1.0 - edad * 1.8), -1, cv::LINE_AA);
            i++;
        }
        ui::texto(img, cv::format("PUNTOS %d", puntos_), c.w - 200.0f, 36, 0.8, ui::AMARILLO, false, 2);
        if (!fin_) {
            ui::texto(img, cv::format("%.0f s", std::max(0.0, resta)), c.w / 2.0f, 36, 0.8, ui::BLANCO, true, 2);
        } else {
            ui::texto(img, cv::format("FIN!  %d burbujas", puntos_), c.w / 2.0f, c.h / 2.0f - 30, 1.2, ui::AMARILLO, true, 3);
            ui::texto(img, cv::format("record %d", record_), c.w / 2.0f, c.h / 2.0f + 10, 0.7, ui::BLANCO, true, 2);
            if (otra_.actualizar(c.manos, c.t, app.dwell())) entrar(c);
            otra_.dibujar(img, c.t, app.dwell(), 0.7);
        }
        for (const auto& m : c.manos) ui::cursor(img, m, c.t);
    }

private:
    struct Burbuja { cv::Point2f p, v; float r; cv::Scalar col; };
    struct Chispa { cv::Point2f p, v; double t; cv::Scalar col; };
    std::vector<Burbuja> burbujas_;
    std::vector<Chispa> chispas_;
    int puntos_ = 0, record_ = 0;
    double t0_ = 0, t_nace_ = 0;
    bool fin_ = false;
    ui::Boton otra_;
};

// ====================================================================== PIANO
class ModoPiano : public Modo {
public:
    using Modo::Modo;
    const char* nombre() const override { return "Piano"; }
    const char* descripcion() const override { return "Toca las teclas"; }
    void entrar(const Contexto&) override {
        tecla_mano_.clear();
        std::fill(std::begin(luz_), std::end(luz_), -10.0);
    }
    void icono(cv::Mat& img, cv::Rect r, double t) const override {
        int n = 7, tw = (r.width - 20) / n;
        for (int i = 0; i < n; i++) {
            cv::Rect k(r.x + 10 + i * tw, r.y + 10, tw - 3, r.height - 16);
            bool on = ((int)(t * 3) % n) == i;
            cv::rectangle(img, k, on ? ui::AMARILLO : ui::BLANCO, -1);
        }
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        static const float freq[8] = {261.63f, 293.66f, 329.63f, 349.23f, 392.00f, 440.00f, 493.88f, 523.25f};
        static const char* nom[8] = {"Do", "Re", "Mi", "Fa", "Sol", "La", "Si", "Do"};
        const int n = 8, y0 = (int)(c.h * 0.30), y1 = c.h - 12;
        float kw = (c.w - 20) / (float)n;
        std::map<int, int> ahora_mano;
        for (const auto& m : c.manos) {
            int k = -1;
            if (m.punta.y >= y0 && m.punta.y <= y1) k = (int)((m.punta.x - 10) / kw);
            if (k < 0 || k >= n) k = -1;
            ahora_mano[m.id] = k;
            bool entro = k >= 0 && (!tecla_mano_.count(m.id) || tecla_mano_[m.id] != k);
            if (k >= 0 && (entro || m.evento_cerrar)) {
                app.sonido().nota(freq[k]);
                luz_[k] = c.t;
            }
        }
        tecla_mano_ = ahora_mano;
        for (int i = 0; i < n; i++) {
            cv::Rect r((int)(10 + i * kw), y0, (int)kw - 4, y1 - y0);
            float f = (float)std::max(0.0, 1.0 - (c.t - luz_[i]) / 0.35);
            cv::Scalar col = ui::BLANCO * (0.55 + 0.25 * (1 - f)) + ui::AMARILLO * (f * 0.8);
            cv::rectangle(img, r, col, -1);
            cv::rectangle(img, r, ui::GRIS_OSC, 2);
            ui::texto(img, nom[i], r.x + r.width / 2.0f, y1 - 18.0f, 0.7, cv::Scalar(40, 40, 40), true, 2);
        }
        ui::texto(img, "PIANO: pasa la punta del indice por las teclas", c.w / 2.0f, y0 - 16.0f, 0.55, ui::BLANCO, true, 1);
        for (const auto& m : c.manos) ui::cursor(img, m, c.t);
    }

private:
    std::map<int, int> tecla_mano_;
    double luz_[8];
};

// ====================================================================== PARTICULAS
class ModoParticulas : public Modo {
public:
    using Modo::Modo;
    const char* nombre() const override { return "Particulas"; }
    const char* descripcion() const override { return "Cierra: atrae, abre: explota"; }
    void entrar(const Contexto&) override { ps_.clear(); }
    void icono(cv::Mat& img, cv::Rect r, double t) const override {
        cv::Point cc = (r.tl() + r.br()) / 2;
        for (int k = 0; k < 18; k++) {
            float a = (float)(k * 0.35 + t * 2), rad = 6.0f + k * 1.6f;
            cv::circle(img, cc + cv::Point((int)(std::cos(a) * rad), (int)(std::sin(a) * rad)), 2, color_hsv(k / 18.0f), -1);
        }
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        const size_t maximo = 1400;
        float tono = (float)std::fmod(c.t * 0.08, 1.0);
        for (const auto& m : c.manos) {
            for (int k = 0; k < 7 && ps_.size() < maximo; k++) {
                float a = azar(0, 6.283f), v = azar(10, 70);
                ps_.push_back({m.punta, m.velocidad * 0.25f + cv::Point2f(std::cos(a) * v, std::sin(a) * v), 2.5f,
                               color_hsv(std::fmod(tono + azar(0, 0.15f), 1.0f))});
            }
            if (m.evento_abrir) {                   // explosion al abrir la mano
                app.sonido().pop(0.6f);
                for (auto& p : ps_) {
                    cv::Point2f d = p.p - m.punta;
                    float r = std::max(8.0f, std::hypot(d.x, d.y));
                    if (r < 220) p.v += d * (520.0f / r);
                }
            }
        }
        for (auto& p : ps_) {
            for (const auto& m : c.manos)
                if (m.cerrada) {                    // atraccion con giro
                    cv::Point2f d = m.punta - p.p;
                    float r = std::max(10.0f, std::hypot(d.x, d.y));
                    p.v += d * (900.0f / (r * r) * 60.0f * (float)c.dt) + cv::Point2f(-d.y, d.x) * (1.2f * (float)c.dt);
                }
            p.v *= 0.975f;
            p.p += p.v * (float)c.dt;
            p.vida -= (float)c.dt;
        }
        ps_.erase(std::remove_if(ps_.begin(), ps_.end(),
                                 [&](const P& p) { return p.vida <= 0 || p.p.x < -20 || p.p.y < -20 || p.p.x > c.w + 20 || p.p.y > c.h + 20; }),
                  ps_.end());
        for (const auto& p : ps_) cv::circle(img, p.p, p.vida > 1.2f ? 3 : 2, p.col * std::min(1.0f, p.vida), -1);
        ui::texto(img, "PARTICULAS: cierra (pulgar+indice) para atraer, abre para explotar", c.w / 2.0f, c.h - 14.0f, 0.45,
                  ui::GRIS, true, 1);
        for (const auto& m : c.manos) ui::cursor(img, m, c.t);
    }

private:
    struct P { cv::Point2f p, v; float vida; cv::Scalar col; };
    std::vector<P> ps_;
};

// ====================================================================== AUTOCALIBRADO DE MANOS
// Prueba varias exposiciones de la camara con la mano quieta y se queda con la que mejor ve
// el pulgar y el indice (y que no queme la imagen).
class ModoAutocal : public Modo {
public:
    using Modo::Modo;
    const char* nombre() const override { return "Autocalibrar"; }
    const char* descripcion() const override { return "Camara para las manos"; }
    void icono(cv::Mat& img, cv::Rect r, double t) const override {
        cv::Point cc = (r.tl() + r.br()) / 2;
        cv::circle(img, cc, 16, ui::CIAN, 3, cv::LINE_AA);
        cv::circle(img, cc, 6, ui::CIAN, -1, cv::LINE_AA);
        for (int k = 0; k < 8; k++) {
            float a = (float)(k * 0.785 + t);
            cv::line(img, cc + cv::Point((int)(std::cos(a) * 22), (int)(std::sin(a) * 22)),
                     cc + cv::Point((int)(std::cos(a) * 30), (int)(std::sin(a) * 30)), ui::AMARILLO, 2, cv::LINE_AA);
        }
    }
    void entrar(const Contexto& c) override {
        estado_ = INSTRUCCIONES;
        t_ = c.t;
        visto_desde_ = -1;
        res_.clear();
        mejor_ = -1;
        ControlesV4L2::Info e = app.controles().info("exposure_absolute");
        hay_expo_ = e.existe;
        candidatos_.clear();
        if (hay_expo_) {
            double lo = std::max(e.min, 8), hi = std::min(e.max, 2500);
            const int n = 8;
            for (int i = 0; i < n; i++)
                candidatos_.push_back((int)std::lround(lo * std::pow(hi / lo, i / (double)(n - 1))));
        }
        previo_ = app.ajustes().ctrl;
        previo_real_.clear();
        int v;
        if (app.controles().leer("exposure_auto", v)) previo_real_["exposure_auto"] = v;
        if (app.controles().leer("exposure_absolute", v)) previo_real_["exposure_absolute"] = v;
    }
    void dibujar(const Contexto& c, cv::Mat& img) override {
        cv::Rect caja((int)(c.w * 0.32), (int)(c.h * 0.22), (int)(c.w * 0.36), (int)(c.h * 0.66));
        cv::rectangle(img, caja, ui::GRIS, 2, cv::LINE_AA);
        ui::manos_dedos(img, c.manos, true);
        ui::texto(img, "AUTOCALIBRADO DE MANOS", c.w / 2.0f, 34, 0.8, ui::AMARILLO, true, 2);
        const ResultadoVision& r = app.ultimo();
        if (estado_ == INSTRUCCIONES) {
            ui::texto(img, "Pon la mano ABIERTA dentro del cuadro y dejala quieta", c.w / 2.0f, 62, 0.55, ui::BLANCO, true, 1);
            if (!hay_expo_) {
                ui::texto(img, "Tu camara no deja cambiar la exposicion", c.w / 2.0f, c.h / 2.0f, 0.7, ui::ROJO, true, 2);
                if (c.t - t_ > 3) app.ir_menu();
                return;
            }
            bool mano = !r.manos.empty();
            if (mano && visto_desde_ < 0) visto_desde_ = c.t;
            if (!mano) visto_desde_ = -1;
            double falta = std::max(0.0, 3.0 - (c.t - t_));
            ui::texto(img, cv::format("empiezo en %.0f s", std::ceil(falta)), c.w / 2.0f, c.h - 20.0f, 0.6, ui::GRIS, true, 1);
            if ((falta <= 0 && visto_desde_ > 0 && c.t - visto_desde_ > 0.8) || c.t - t_ > 8) iniciar_prueba(c, 0);
        } else if (estado_ == PROBANDO) {
            int k = (int)res_.size();
            // juntar resultados de la deteccion con esta exposicion (despues de que la camara se acomode)
            if (r.n > n_ultimo_ && r.t_captura > t_ + 0.35) {
                n_ultimo_ = r.n;
                cuadros_++;
                luz_ += r.luz;
                if (!r.manos.empty()) {
                    con_mano_++;
                    int pts = 0;
                    for (int i = 1; i <= 8; i++) pts += r.manos[0].ok[i];
                    puntos_ += pts;
                }
            }
            float prog = (k + (float)std::min(1.0, (c.t - t_) / 1.4)) / candidatos_.size();
            ui::texto(img, cv::format("Probando exposicion %d (%d de %d)", candidatos_[k], k + 1, (int)candidatos_.size()),
                      c.w / 2.0f, 62, 0.55, ui::BLANCO, true, 1);
            ui::barra(img, cv::Rect(c.w / 4, c.h - 34, c.w / 2, 14), prog, ui::VERDE);
            if (c.t - t_ > 1.4 && cuadros_ >= 3) {
                Prueba p;
                p.expo = candidatos_[k];
                p.deteccion = cuadros_ ? con_mano_ / (float)cuadros_ : 0;
                p.puntos = con_mano_ ? puntos_ / (8.0f * con_mano_) : 0;
                p.luz = cuadros_ ? luz_ / cuadros_ : 0;
                p.nota = p.deteccion * p.puntos * (p.luz > 215 ? 0.6f : 1.0f);
                res_.push_back(p);
                log("Autocal: exposicion %d -> manos %.0f%%, puntos %.0f%%, luz %.0f, nota %.2f", p.expo, p.deteccion * 100,
                    p.puntos * 100, p.luz, p.nota);
                if (res_.size() < candidatos_.size()) iniciar_prueba(c, (int)res_.size());
                else elegir(c);
            } else if (c.t - t_ > 4.0) {            // la camara no manda resultados: se salta
                res_.push_back(Prueba{candidatos_[k], 0, 0, 0, 0});
                if (res_.size() < candidatos_.size()) iniciar_prueba(c, (int)res_.size());
                else elegir(c);
            }
        } else {
            dibujar_resultado(c, img);
            if (c.t - t_ > 5) app.ir_menu();
        }
        for (const auto& m : c.manos) ui::cursor(img, m, c.t);
    }

private:
    enum Estado { INSTRUCCIONES, PROBANDO, LISTO };
    struct Prueba { int expo; float deteccion, puntos, luz, nota; };

    void iniciar_prueba(const Contexto& c, int k) {
        estado_ = PROBANDO;
        if (app.controles().info("exposure_auto").existe) app.poner_control("exposure_auto", 1);
        app.poner_control("exposure_absolute", candidatos_[k]);
        t_ = c.t;
        n_ultimo_ = app.ultimo().n;
        cuadros_ = con_mano_ = 0;
        puntos_ = 0;
        luz_ = 0;
    }
    void elegir(const Contexto& c) {
        estado_ = LISTO;
        t_ = c.t;
        float mejor_nota = 0;
        for (const auto& p : res_) mejor_nota = std::max(mejor_nota, p.nota);
        mejor_ = -1;
        // la exposicion mas corta que ve casi igual de bien (menos borroso al mover la mano)
        for (size_t i = 0; i < res_.size(); i++)
            if (res_[i].nota >= mejor_nota * 0.95f && mejor_nota > 0.15f) { mejor_ = (int)i; break; }
        if (mejor_ >= 0) {
            app.poner_control("exposure_absolute", res_[mejor_].expo);
            app.guardar_ajustes();
            app.aviso(cv::format("Autocal: exposicion %d guardada", res_[mejor_].expo));
            log("Autocal: me quedo con exposicion %d (nota %.2f)", res_[mejor_].expo, res_[mejor_].nota);
        } else {
            app.ajustes().ctrl = previo_;
            app.controles().aplicar(previo_real_);     // como estaba la camara antes de probar
            app.aviso("Autocal: no vi bien la mano");
            log("Autocal: no vi bien la mano con ninguna exposicion; regreso a los valores anteriores");
        }
    }
    void dibujar_resultado(const Contexto& c, cv::Mat& img) {
        if (mejor_ < 0) {
            ui::texto(img, "No vi bien la mano. Acercala o sube la luz de relleno (V)", c.w / 2.0f, 62, 0.55, ui::ROJO, true, 1);
        } else {
            ui::texto(img, cv::format("Listo: exposicion %d (guardada)", res_[mejor_].expo), c.w / 2.0f, 62, 0.6, ui::VERDE2, true, 2);
        }
        int bw = (c.w - 80) / (int)std::max<size_t>(1, res_.size());
        for (size_t i = 0; i < res_.size(); i++) {
            int x = 40 + (int)i * bw, alto = (int)(res_[i].nota * (c.h * 0.4));
            cv::Rect b(x + 4, c.h - 50 - alto, bw - 8, std::max(2, alto));
            cv::rectangle(img, b, (int)i == mejor_ ? ui::VERDE2 : ui::GRIS, -1);
            ui::texto(img, std::to_string(res_[i].expo), x + bw / 2.0f, c.h - 30.0f, 0.4, ui::BLANCO, true, 1);
        }
    }

    Estado estado_ = INSTRUCCIONES;
    double t_ = 0, visto_desde_ = -1;
    bool hay_expo_ = false;
    std::vector<int> candidatos_;
    std::vector<Prueba> res_;
    int mejor_ = -1;
    uint64_t n_ultimo_ = 0;
    int cuadros_ = 0, con_mano_ = 0;
    float puntos_ = 0, luz_ = 0;
    std::map<std::string, int> previo_, previo_real_;
};

// ====================================================================== acciones (recalibrar / salir)
class ModoAccion : public Modo {
public:
    ModoAccion(App& a, const char* n, const char* d, int acc) : Modo(a), n_(n), d_(d), acc_(acc) {}
    const char* nombre() const override { return n_; }
    const char* descripcion() const override { return d_; }
    int accion() const override { return acc_; }
    void dibujar(const Contexto&, cv::Mat&) override {}
    void icono(cv::Mat& img, cv::Rect r, double) const override {
        cv::Point cc = (r.tl() + r.br()) / 2;
        if (acc_ == RECALIBRAR) {
            for (cv::Point d : {cv::Point(-1, -1), cv::Point(1, -1), cv::Point(1, 1), cv::Point(-1, 1)})
                cv::circle(img, cc + cv::Point(d.x * r.width / 3, d.y * r.height / 3), 6, ui::BLANCO, -1, cv::LINE_AA);
        } else {
            int rad = std::min(r.width, r.height) / 4;
            cv::ellipse(img, cc, cv::Size(rad, rad), -90, 40, 320, ui::ROJO, 3, cv::LINE_AA);
            cv::line(img, cc + cv::Point(0, -rad - 4), cc + cv::Point(0, -4), ui::ROJO, 3, cv::LINE_AA);
        }
    }

private:
    const char *n_, *d_;
    int acc_;
};

// ====================================================================== fabrica
std::vector<std::unique_ptr<Modo>> crear_modos(App& app) {
    std::vector<std::unique_ptr<Modo>> v;
    v.emplace_back(new ModoManos(app));
    v.emplace_back(new ModoPintar(app));
    v.emplace_back(new ModoBurbujas(app));
    v.emplace_back(new ModoPiano(app));
    v.emplace_back(new ModoParticulas(app));
    v.emplace_back(new ModoAutocal(app));
    v.emplace_back(new ModoAccion(app, "Recalibrar", "Proyector (puntos)", Modo::RECALIBRAR));
    v.emplace_back(new ModoAccion(app, "Salir", "Cerrar la estacion", Modo::SALIR));
    return v;
}

std::unique_ptr<Modo> crear_menu(App& app, const std::vector<Modo*>& opciones) {
    return std::unique_ptr<Modo>(new ModoMenu(app, opciones));
}

}  // namespace est
