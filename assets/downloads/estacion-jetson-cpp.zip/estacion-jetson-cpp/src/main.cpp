// main.cpp - Estacion de proyeccion en C++ para la Jetson Nano.
//
//   ./build/estacion                       framebuffer del HDMI, camara 0, detector poseNet en GPU
//   ./build/estacion --ahorro              fuente debil: dibujo 640x360 a 20 FPS, manos 10 veces/s, 1 mano
//   ./build/estacion --motor python        landmarks por el puente de Python (como el juego del Kinect)
//   ./build/estacion --sin-calibrar        usa la calibracion guardada
//   ./build/estacion --calib-python        usa calib_hdmi.json de ~/estacion (version Python)
//   ./build/estacion --modo pintar         abre directo un modo
// Salir: Ctrl+C (los ajustes se guardan solos)
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#include <opencv2/core.hpp>

#include "app.hpp"
#include "detector.hpp"

using namespace est;

static void al_salir(int) { g_vivo = false; }

static void ayuda() {
    std::printf(
        "Estacion C++ - opciones:\n"
        "  --camara 0|1|/dev/video0|sim   camara (sim = simulada para probar en la PC)\n"
        "  --res 640x480                  resolucion de la camara\n"
        "  --salida fb|ventana|png:DIR|nula\n"
        "  --alto 480                     altura de dibujo (se escala al HDMI)\n"
        "  --fps 30                       cuadros de dibujo por segundo\n"
        "  --motor auto|posenet|python|sim|ninguno   (compilados: %s)\n"
        "  --manos 2                      manos maximas\n"
        "  --ahorro                       menos consumo (fuente debil)\n"
        "  --sin-calibrar                 no calibra al iniciar (usa la guardada)\n"
        "  --calib-python                 usa calib_hdmi.json de la version Python\n"
        "  --sin-ver                      sin ventana por SSH\n"
        "  --ssh-sin-hilo                 la ventana SSH en el hilo principal (si la de hilo falla)\n"
        "  --audio auto|no|plughw:2,0     salida de sonido\n"
        "  --menu-der                     boton MENU arriba a la derecha\n"
        "  --modo manos|pintar|burbujas|piano|particulas|autocalibrar\n"
        "  --config ruta/ajustes.cfg\n"
        "  --duracion N                   salir despues de N segundos (pruebas)\n",
        motores_compilados().c_str());
}

int main(int argc, char** argv) {
    Opciones op;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto sig = [&]() -> std::string {
            if (i + 1 >= argc) { std::fprintf(stderr, "Falta el valor de %s\n", a.c_str()); std::exit(2); }
            return argv[++i];
        };
        if (a == "--camara") op.camara = sig();
        else if (a == "--res") { std::string r = sig(); std::sscanf(r.c_str(), "%dx%d", &op.cam_w, &op.cam_h); }
        else if (a == "--salida") op.salida = sig();
        else if (a == "--alto") op.alto = std::atoi(sig().c_str());
        else if (a == "--fps") op.fps = std::atoi(sig().c_str());
        else if (a == "--motor") op.motor = sig();
        else if (a == "--manos") op.max_manos = std::atoi(sig().c_str());
        else if (a == "--ahorro") op.ahorro = true;
        else if (a == "--sin-calibrar") op.calibrar = false;
        else if (a == "--calib-python") op.calib_python = true;
        else if (a == "--sin-ver") op.ver = false;
        else if (a == "--ssh-sin-hilo") op.ssh_hilo = false;
        else if (a == "--audio") op.audio = sig();
        else if (a == "--menu-der") op.menu_der = true;
        else if (a == "--modo") op.modo_inicial = sig();
        else if (a == "--config") op.config = sig();
        else if (a == "--duracion") op.duracion = std::atof(sig().c_str());
        else if (a == "--teclas-stdin") op.teclas_stdin = true;
        else if (a == "-h" || a == "--ayuda" || a == "--help") { ayuda(); return 0; }
        else { std::fprintf(stderr, "Opcion desconocida: %s\n\n", a.c_str()); ayuda(); return 2; }
    }
    std::signal(SIGINT, al_salir);
    std::signal(SIGTERM, al_salir);
    std::signal(SIGPIPE, SIG_IGN);           // si aplay se cierra no se cae todo
    cv::setNumThreads(2);
    log("Estacion C++ | motores: %s | %s", motores_compilados().c_str(), op.ahorro ? "modo ahorro" : "normal");
    App app(op);
    return app.correr();
}
