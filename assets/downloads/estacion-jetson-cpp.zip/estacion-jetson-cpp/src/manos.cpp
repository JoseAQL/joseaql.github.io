#include "manos.hpp"

#include <algorithm>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

namespace est {

void SeguidorManos::configurar(const Ajustes& aj) {
    cerrar_ = aj.pinza_cerrar;
    abrir_ = std::max(aj.pinza_abrir, aj.pinza_cerrar + 0.05f);
    pred_ = aj.prediccion_ms / 1000.0;
}

void SeguidorManos::actualizar(const std::vector<ManoCruda>& manos_cam, const cv::Matx33d& H, double t_captura) {
    // 1) a coordenadas de dibujo, solo manos con pulgar e indice utilizables
    struct Nueva { std::array<cv::Point2f, 21> p; float apertura; };
    std::vector<Nueva> nuevas;
    for (ManoCruda m : manos_cam) {
        if (!completar_mano(m)) continue;
        std::vector<cv::Point2f> cam(m.p.begin(), m.p.end()), dib;
        for (int i = 0; i < 21; i++)
            if (!m.ok[i]) cam[i] = m.p[0];
        cv::perspectiveTransform(cam, dib, H);
        Nueva n;
        std::copy(dib.begin(), dib.end(), n.p.begin());
        // "largo del indice" no cambia al doblarlo: suma de sus 3 segmentos
        float largo = dist(n.p[5], n.p[6]) + dist(n.p[6], n.p[7]) + dist(n.p[7], n.p[8]);
        float largo_pulgar = dist(n.p[2], n.p[3]) + dist(n.p[3], n.p[4]);
        largo = std::max(largo, largo_pulgar * 1.2f);
        if (largo < 4.0f) continue;
        n.apertura = dist(n.p[4], n.p[8]) / largo;
        nuevas.push_back(n);
    }
    // 2) emparejar con las pistas por cercania de la punta del indice
    std::vector<bool> usada(pistas_.size(), false);
    for (const auto& n : nuevas) {
        int mejor = -1;
        float dmin = 1e9f;
        for (size_t i = 0; i < pistas_.size(); i++) {
            if (usada[i]) continue;
            float d = dist(pistas_[i].m.punta_cruda, n.p[8]);
            if (d < dmin) { dmin = d; mejor = (int)i; }
        }
        if (mejor < 0 || dmin > 220.0f) {
            Pista p;
            p.m.id = siguiente_id_++;
            pistas_.push_back(p);
            usada.push_back(false);
            mejor = (int)pistas_.size() - 1;
        }
        usada[mejor] = true;
        Pista& p = pistas_[mejor];
        p.m.p = n.p;
        p.m.punta_cruda = n.p[8];
        p.m.apertura = n.apertura;
        p.m.t_visto = ahora();
        p.t_cap = t_captura;
        p.fx.filtrar(n.p[8].x, t_captura);
        p.fy.filtrar(n.p[8].y, t_captura);
        // pinza con histeresis: cerrada abajo de 'cerrar', abierta arriba de 'abrir'
        if (!p.m.cerrada && n.apertura < cerrar_) { p.m.cerrada = true; p.ev_cerrar = true; }
        else if (p.m.cerrada && n.apertura > abrir_) { p.m.cerrada = false; p.ev_abrir = true; }
    }
}

const std::vector<ManoUI>& SeguidorManos::cuadro(double t, int w, int h) {
    // se olvidan las manos que no se ven hace rato (tolerancia para parpadeos del detector)
    pistas_.erase(std::remove_if(pistas_.begin(), pistas_.end(),
                                 [&](const Pista& p) { return t - p.m.t_visto > 0.30; }),
                  pistas_.end());
    salida_.clear();
    for (auto& p : pistas_) {
        ManoUI m = p.m;
        cv::Point2f v((float)p.fx.velocidad(), (float)p.fy.velocidad());
        float rap = std::hypot(v.x, v.y);
        if (rap > 3000.0f) v *= 3000.0f / rap;
        // adelanto: lo que se movio desde que la camara tomo el cuadro (max 120 ms)
        float adel = (float)std::min(0.12, std::max(0.0, t - p.t_cap + pred_));
        m.velocidad = v;
        m.punta = cv::Point2f((float)p.fx.valor(), (float)p.fy.valor()) + v * adel;
        m.punta.x = limitar(m.punta.x, 0, (float)w - 1);
        m.punta.y = limitar(m.punta.y, 0, (float)h - 1);
        m.evento_cerrar = p.ev_cerrar;
        m.evento_abrir = p.ev_abrir;
        p.ev_cerrar = p.ev_abrir = false;
        salida_.push_back(m);
    }
    std::sort(salida_.begin(), salida_.end(), [](const ManoUI& a, const ManoUI& b) { return a.punta.x < b.punta.x; });
    return salida_;
}

}  // namespace est
