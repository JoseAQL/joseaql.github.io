#include "sonido.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <regex>

#include "comun.hpp"

namespace est {

static const int SR = 22050;

static std::string buscar_salida_usb() {
    FILE* p = popen("aplay -l 2>/dev/null", "r");
    if (!p) return "default";
    char linea[512];
    std::string r = "default";
    std::regex re("card (\\d+):.*device (\\d+):");
    while (fgets(linea, sizeof(linea), p)) {
        std::string s(linea);
        std::smatch m;
        if (std::regex_search(s, m, re) && (s.find("USB") != std::string::npos || s.find("usb") != std::string::npos)) {
            r = "plughw:" + m[1].str() + "," + m[2].str();
            break;
        }
    }
    pclose(p);
    return r;
}

bool Sonido::iniciar(const std::string& dispositivo) {
    detener();
    if (dispositivo == "no") return false;
    dev_ = dispositivo == "auto" ? buscar_salida_usb() : dispositivo;
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "aplay -q -t raw -f S16_LE -r %d -c 1 -B 60000 -D %s 2>/dev/null", SR, dev_.c_str());
    tubo_ = popen(cmd, "w");
    if (!tubo_) {
        log("Sonido: no pude abrir aplay");
        return false;
    }
#ifdef F_SETPIPE_SZ
    fcntl(fileno(tubo_), F_SETPIPE_SZ, 4096);       // tubo chico: las notas no se forman en fila
#endif
    activo_ = true;
    th_ = std::thread(&Sonido::hilo, this);
    log("Sonido por %s", dev_.c_str());
    return true;
}

void Sonido::detener() {
    activo_ = false;
    if (th_.joinable()) th_.join();
    if (tubo_) pclose(tubo_);
    tubo_ = nullptr;
}

void Sonido::nota(float f, float dur, float vol) {
    if (!activo_) return;
    std::lock_guard<std::mutex> lk(mtx_);
    if (voces_.size() < 12) voces_.push_back({f, 0, 0, dur, vol, 0});
}

void Sonido::pop(float tono) {
    if (!activo_) return;
    std::lock_guard<std::mutex> lk(mtx_);
    if (voces_.size() < 12) voces_.push_back({900.0f * tono, 0, 0, 0.09f, 0.35f, 1});
}

void Sonido::clic() {
    if (!activo_) return;
    std::lock_guard<std::mutex> lk(mtx_);
    if (voces_.size() < 12) voces_.push_back({1400.0f, 0, 0, 0.05f, 0.25f, 2});
}

void Sonido::hilo() {
    const int N = 256;                               // ~12 ms por bloque
    short buf[N];
    float mezcla[N];
    const double t0 = ahora();
    long escritas = 0;
    while (activo_ && g_vivo) {
        double adelanto = escritas / (double)SR - (ahora() - t0);   // no adelantarse mas de ~40 ms
        if (adelanto > 0.04) usleep((useconds_t)((adelanto - 0.03) * 1e6));
        std::memset(mezcla, 0, sizeof(mezcla));
        {
            std::lock_guard<std::mutex> lk(mtx_);
            for (auto& v : voces_) {
                for (int i = 0; i < N; i++) {
                    float t = v.t + i / (float)SR;
                    if (t >= v.dur) break;
                    float env, s;
                    if (v.tipo == 0) {                // nota tipo piano: ataque rapido y caida suave
                        env = std::min(1.0f, t / 0.005f) * std::exp(-4.0f * t / v.dur);
                        float ph = v.fase + 2 * (float)M_PI * v.f * i / SR;
                        s = std::sin(ph) + 0.35f * std::sin(2 * ph) + 0.12f * std::sin(3 * ph);
                    } else if (v.tipo == 1) {         // pop: tono que baja muy rapido
                        env = std::exp(-35.0f * t);
                        float fi = v.f * (1.0f - 0.6f * t / v.dur);
                        s = std::sin(v.fase + 2 * (float)M_PI * fi * i / SR);
                    } else {
                        env = std::exp(-60.0f * t);
                        s = std::sin(v.fase + 2 * (float)M_PI * v.f * i / SR);
                    }
                    mezcla[i] += s * env * v.vol;
                }
                v.fase = std::fmod(v.fase + 2 * (float)M_PI * v.f * N / SR, 2 * (float)M_PI);
                v.t += N / (float)SR;
            }
            voces_.erase(std::remove_if(voces_.begin(), voces_.end(), [](const Voz& v) { return v.t >= v.dur; }),
                         voces_.end());
        }
        for (int i = 0; i < N; i++) buf[i] = (short)(std::tanh(mezcla[i]) * 30000.0f);
        if (fwrite(buf, sizeof(short), N, tubo_) != (size_t)N) {   // aplay se cerro
            log("Sonido: aplay se cerro, sigo sin sonido");
            activo_ = false;
            break;
        }
        fflush(tubo_);
        escritas += N;
    }
}

}  // namespace est
