#include "ui.hpp"

#include <cmath>

namespace est {
namespace ui {

int texto(cv::Mat& img, const std::string& s, float x, float y, double esc, const cv::Scalar& col, bool centrado,
          int grosor) {
    int base = 0;
    cv::Size t = cv::getTextSize(s, cv::FONT_HERSHEY_DUPLEX, esc, grosor, &base);
    int xi = centrado ? (int)(x - t.width / 2) : (int)x;
    cv::putText(img, s, cv::Point(xi, (int)y), cv::FONT_HERSHEY_DUPLEX, esc, NEGRO, grosor + 3, cv::LINE_AA);
    cv::putText(img, s, cv::Point(xi, (int)y), cv::FONT_HERSHEY_DUPLEX, esc, col, grosor, cv::LINE_AA);
    return t.width;
}

void fondo(cv::Mat& img) {
    static cv::Mat cache;
    if (cache.size() != img.size()) {
        cache.create(img.size(), CV_8UC3);
        for (int y = 0; y < img.rows; y++) {
            float k = y / (float)img.rows;
            cache.row(y).setTo(cv::Scalar(8 + 4 * k, 8 + 14 * k, 8 + 4 * k));
        }
        for (int x = 0; x < img.cols; x += 48) cv::line(cache, {x, 0}, {x, img.rows}, cv::Scalar(16, 34, 16), 1);
        for (int y = 0; y < img.rows; y += 48) cv::line(cache, {0, y}, {img.cols, y}, cv::Scalar(16, 34, 16), 1);
    }
    cache.copyTo(img);
}

void cursor(cv::Mat& img, const ManoUI& m, double t, float progreso) {
    cv::Point c((int)m.punta.x, (int)m.punta.y);
    float pulso = (float)(std::sin(t * 6) * 0.5 + 0.5);
    cv::Scalar col = m.cerrada ? ROJO : VERDE2;
    int r = 16 + (int)(pulso * 3);
    cv::circle(img, c, r + 3, NEGRO, 3, cv::LINE_AA);
    cv::circle(img, c, r, col, 2, cv::LINE_AA);
    if (m.cerrada) cv::circle(img, c, 9, col, -1, cv::LINE_AA);
    else cv::circle(img, c, 4, col, -1, cv::LINE_AA);
    if (progreso > 0)
        cv::ellipse(img, c, cv::Size(r + 7, r + 7), -90, 0, 360 * progreso, AMARILLO, 4, cv::LINE_AA);
}

void manos_dedos(cv::Mat& img, const std::vector<ManoUI>& manos, bool detalle) {
    for (const auto& m : manos) {
        auto P = [&](int i) { return cv::Point((int)m.p[i].x, (int)m.p[i].y); };
        if (detalle) {
            for (int a : {9, 13, 17}) cv::line(img, P(0), P(a), GRIS_OSC, 2, cv::LINE_AA);
            cv::line(img, P(5), P(9), GRIS_OSC, 2, cv::LINE_AA);
        }
        cv::Scalar cp = m.cerrada ? ROJO : NARANJA, ci = m.cerrada ? ROJO : CIAN;
        for (int i = 0; i < 4; i++) cv::line(img, P(i == 0 ? 0 : i), P(i + 1), cp, 4, cv::LINE_AA);   // pulgar
        cv::line(img, P(0), P(5), ci, 4, cv::LINE_AA);
        for (int i = 5; i < 8; i++) cv::line(img, P(i), P(i + 1), ci, 4, cv::LINE_AA);                  // indice
        for (int i = 1; i <= 8; i++) cv::circle(img, P(i), (i == 4 || i == 8) ? 8 : 5, BLANCO, -1, cv::LINE_AA);
        cv::line(img, P(4), P(8), m.cerrada ? ROJO : GRIS, 1, cv::LINE_AA);
    }
}

void barra(cv::Mat& img, cv::Rect r, float v, const cv::Scalar& col) {
    cv::rectangle(img, r, cv::Scalar(35, 35, 35), -1);
    cv::Rect f = r;
    f.width = (int)(r.width * std::max(0.0f, std::min(1.0f, v)));
    if (f.width > 0) cv::rectangle(img, f, col, -1);
    cv::rectangle(img, r, cv::Scalar(90, 90, 90), 1);
}

// borde que se va "llenando" alrededor del rectangulo (como el menu del Kinect)
void borde_progreso(cv::Mat& img, cv::Rect r, float t, const cv::Scalar& col, int grosor) {
    if (t <= 0) return;
    float per = 2.0f * (r.width + r.height), resta = per * std::min(1.0f, t);
    cv::Point p[5] = {{r.x, r.y}, {r.x + r.width, r.y}, {r.x + r.width, r.y + r.height}, {r.x, r.y + r.height}, {r.x, r.y}};
    for (int i = 0; i < 4 && resta > 0; i++) {
        float largo = (float)cv::norm(p[i + 1] - p[i]);
        float f = std::min(1.0f, resta / largo);
        cv::Point fin = p[i] + cv::Point((int)((p[i + 1].x - p[i].x) * f), (int)((p[i + 1].y - p[i].y) * f));
        cv::line(img, p[i], fin, col, grosor, cv::LINE_AA);
        resta -= largo;
    }
}

// ------------------------------------------------------------------ boton
bool Boton::actualizar(const std::vector<ManoUI>& manos, double t, double dwell) {
    bool sobre = false, pellizco = false;
    for (const auto& m : manos)
        if (dentro(rect, m.punta)) {
            sobre = true;
            if (m.evento_cerrar) pellizco = true;
        }
    if (sobre) {
        t_visto_ = t;
        if (t_encima_ < 0) t_encima_ = t;
    } else if (t_encima_ >= 0 && t - t_visto_ > 0.35) {   // tolera que la mano parpadee
        t_encima_ = -1;
        bloqueado_ = false;
    } else if (t_encima_ < 0) {
        bloqueado_ = false;
    }
    if (bloqueado_ || t_encima_ < 0) return false;
    if (pellizco || t - t_encima_ >= dwell) {
        bloqueado_ = true;
        t_flash_ = t;
        return true;
    }
    return false;
}

float Boton::progreso(double t, double dwell) const {
    if (t_encima_ < 0 || bloqueado_) return 0;
    return (float)std::min(1.0, (t - t_encima_) / dwell);
}

void Boton::dibujar(cv::Mat& img, double t, double dwell, double esc) const {
    bool flash = t_flash_ > 0 && t - t_flash_ < 0.35;
    bool hov = t_encima_ >= 0;
    cv::Mat roi = img(rect & cv::Rect(0, 0, img.cols, img.rows));
    roi.convertTo(roi, -1, 0.35, 0);                       // oscurece lo de atras (en su lugar)
    roi += cv::Scalar(hov ? 7 : 12, hov ? 26 : 12, hov ? 7 : 12);
    cv::rectangle(img, rect, flash ? VERDE2 : (hov ? VERDE : GRIS_OSC), 2, cv::LINE_AA);
    borde_progreso(img, rect, progreso(t, dwell), VERDE2, 4);
    float cx = rect.x + rect.width / 2.0f;
    if (sub.empty()) {
        texto(img, etiqueta, cx, rect.y + rect.height / 2.0f + 10 * esc, esc, BLANCO, true, 2);
    } else {
        texto(img, etiqueta, cx, rect.y + rect.height - 30 * esc - 8, esc, BLANCO, true, 2);
        texto(img, sub, cx, rect.y + rect.height - 8, esc * 0.55, GRIS, true, 1);
    }
}

}  // namespace ui
}  // namespace est
