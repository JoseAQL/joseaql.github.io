#include "camara.hpp"

#include <fcntl.h>
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cstring>
#include <fstream>
#include <regex>
#include <sstream>

#include <opencv2/imgproc.hpp>

#include "comun.hpp"

namespace est {

// ====================================================================== captura
bool Camara::abrir(const std::string& fuente, int ancho, int alto, int fps) {
    cerrar();
    fps_ = fps > 0 ? fps : 30;
    sim_ = (fuente == "sim");
    if (sim_) {
        w_ = ancho; h_ = alto; dev_ = "sim";
    } else {
        bool numero = !fuente.empty() && std::all_of(fuente.begin(), fuente.end(), ::isdigit);
        dev_ = numero ? "/dev/video" + fuente : fuente;
        bool ok = numero ? cap_.open(std::stoi(fuente), cv::CAP_V4L2) : cap_.open(fuente, cv::CAP_V4L2);
        if (!ok) {
            log("Camara: no abre %s", dev_.c_str());
            return false;
        }
        cap_.set(cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'));
        cap_.set(cv::CAP_PROP_FRAME_WIDTH, ancho);
        cap_.set(cv::CAP_PROP_FRAME_HEIGHT, alto);
        cap_.set(cv::CAP_PROP_FPS, fps_);
        cap_.set(cv::CAP_PROP_BUFFERSIZE, 1);
        cv::Mat f;
        for (int i = 0; i < 20 && f.empty(); i++) cap_.read(f);
        if (f.empty()) {
            log("Camara: %s no entrega imagen", dev_.c_str());
            cap_.release();
            return false;
        }
        w_ = f.cols; h_ = f.rows;
    }
    vivo_ = true;
    th_ = std::thread(&Camara::hilo, this);
    log("Camara %s: %dx%d", dev_.c_str(), w_, h_);
    return true;
}

void Camara::cerrar() {
    vivo_ = false;
    if (th_.joinable()) th_.join();
    if (cap_.isOpened()) cap_.release();
}

void Camara::hilo() {
    cv::Mat nuevo;
    double t0 = ahora();
    int n = 0;
    while (vivo_) {
        if (sim_) {
            double sig = t0 + (n + 1) * (1.0 / fps_);
            double espera = sig - ahora();
            if (espera > 0) usleep((useconds_t)(espera * 1e6));
            nuevo = sim::cuadro_camara(w_, h_);
        } else if (!cap_.read(nuevo) || nuevo.empty()) {
            usleep(5000);
            continue;
        }
        double t = ahora();
        {
            std::lock_guard<std::mutex> lk(mtx_);
            cv::swap(cuadro_, nuevo);
            id_++;
            t_ = t;
        }
        cv_.notify_all();
        if (++n >= 30) {
            fps_real_ = float(n / (ahora() - t0));
            n = 0;
            t0 = ahora();
        }
    }
}

bool Camara::esperar(uint64_t& id, cv::Mat& out, double& t_captura, double timeout) {
    std::unique_lock<std::mutex> lk(mtx_);
    if (!cv_.wait_for(lk, std::chrono::duration<double>(timeout), [&] { return id_ > id || !vivo_; }))
        return false;
    if (cuadro_.empty() || id_ <= id) return false;
    cuadro_.copyTo(out);
    id = id_;
    t_captura = t_;
    return true;
}

// ====================================================================== controles V4L2
static int id_control(const std::string& n) {
    static const std::map<std::string, int> ids = {
        {"brightness", V4L2_CID_BRIGHTNESS},
        {"contrast", V4L2_CID_CONTRAST},
        {"saturation", V4L2_CID_SATURATION},
        {"hue", V4L2_CID_HUE},
        {"gain", V4L2_CID_GAIN},
        {"gamma", V4L2_CID_GAMMA},
        {"sharpness", V4L2_CID_SHARPNESS},
        {"backlight_compensation", V4L2_CID_BACKLIGHT_COMPENSATION},
        {"power_line_frequency", V4L2_CID_POWER_LINE_FREQUENCY},
        {"white_balance_temperature_auto", V4L2_CID_AUTO_WHITE_BALANCE},
        {"white_balance_temperature", V4L2_CID_WHITE_BALANCE_TEMPERATURE},
        {"exposure_auto", V4L2_CID_EXPOSURE_AUTO},
        {"exposure_absolute", V4L2_CID_EXPOSURE_ABSOLUTE},
        {"exposure_auto_priority", V4L2_CID_EXPOSURE_AUTO_PRIORITY},
    };
    auto it = ids.find(n);
    return it == ids.end() ? -1 : it->second;
}

// rangos de una camara USB tipica (los mismos que la tuya) para el simulador
static ControlesV4L2::Info info_sim(const std::string& n) {
    ControlesV4L2::Info i;
    i.existe = true;
    if (n == "exposure_absolute") { i.min = 1; i.max = 5000; i.defecto = 157; }
    else if (n == "exposure_auto") { i.min = 0; i.max = 3; i.defecto = 3; }
    else if (n == "gain") { i.min = 0; i.max = 100; i.defecto = 0; }
    else if (n == "brightness") { i.min = -64; i.max = 64; i.defecto = 0; }
    else if (n == "contrast") { i.min = 0; i.max = 64; i.defecto = 32; }
    else if (n == "exposure_auto_priority") { i.min = 0; i.max = 1; i.defecto = 0; }
    else i.existe = false;
    std::lock_guard<std::mutex> lk(sim::mtx());
    auto it = sim::controles().find(n);
    i.valor = it == sim::controles().end() ? i.defecto : it->second;
    return i;
}

bool ControlesV4L2::abrir(const std::string& dispositivo) {
    cerrar();
    if (dispositivo == "sim") { sim_ = true; return true; }
    fd_ = ::open(dispositivo.c_str(), O_RDWR | O_NONBLOCK);
    if (fd_ < 0) log("Controles: no abre %s (%s)", dispositivo.c_str(), strerror(errno));
    return fd_ >= 0;
}

void ControlesV4L2::cerrar() {
    if (fd_ >= 0) ::close(fd_);
    fd_ = -1;
    sim_ = false;
}

ControlesV4L2::Info ControlesV4L2::info(const std::string& nombre) {
    if (sim_) return info_sim(nombre);
    Info r;
    int id = id_control(nombre);
    if (fd_ < 0 || id < 0) return r;
    v4l2_queryctrl q;
    std::memset(&q, 0, sizeof(q));
    q.id = id;
    if (ioctl(fd_, VIDIOC_QUERYCTRL, &q) < 0 || (q.flags & V4L2_CTRL_FLAG_DISABLED)) return r;
    r.existe = true;
    r.min = q.minimum; r.max = q.maximum; r.paso = q.step > 0 ? q.step : 1; r.defecto = q.default_value;
    leer(nombre, r.valor);
    return r;
}

bool ControlesV4L2::leer(const std::string& nombre, int& valor) {
    if (sim_) { valor = info_sim(nombre).valor; return true; }
    int id = id_control(nombre);
    if (fd_ < 0 || id < 0) return false;
    v4l2_control c{};
    c.id = id;
    if (ioctl(fd_, VIDIOC_G_CTRL, &c) < 0) return false;
    valor = c.value;
    return true;
}

bool ControlesV4L2::poner(const std::string& nombre, int valor) {
    if (sim_) {
        std::lock_guard<std::mutex> lk(sim::mtx());
        sim::controles()[nombre] = valor;
        return true;
    }
    int id = id_control(nombre);
    if (fd_ < 0 || id < 0) return false;
    v4l2_control c{};
    c.id = id;
    c.value = valor;
    return ioctl(fd_, VIDIOC_S_CTRL, &c) == 0;
}

void ControlesV4L2::aplicar(const std::map<std::string, int>& ctrl) {
    for (const auto& kv : ctrl)
        if (kv.first.find("auto") != std::string::npos) poner(kv.first, kv.second);
    for (const auto& kv : ctrl)
        if (kv.first.find("auto") == std::string::npos) poner(kv.first, kv.second);
}

void ControlesV4L2::modo_calibracion() {
    Info a = info("exposure_auto");
    if (a.existe) poner("exposure_auto", 3);           // automatica (aperture priority)
    Info g = info("gain");
    if (g.existe) poner("gain", g.defecto);
}

// ====================================================================== simulador
namespace sim {

static std::mutex g_mtx;
static std::map<std::string, int> g_ctrl;
static cv::Mat g_render;
static std::mutex g_render_mtx;

std::mutex& mtx() { return g_mtx; }
std::map<std::string, int>& controles() { return g_ctrl; }

void poner_render(const cv::Mat& bgr) {
    std::lock_guard<std::mutex> lk(g_render_mtx);
    bgr.copyTo(g_render);
}

// proyector 1920x1080 visto por la camara con perspectiva (igual que el simulador de Python)
cv::Matx33d render_a_camara(int rw, int rh, int cw, int ch) {
    std::vector<cv::Point2f> src = {{0, 0}, {(float)rw, 0}, {(float)rw, (float)rh}, {0, (float)rh}};
    float kx = cw / 640.0f, ky = ch / 360.0f;
    std::vector<cv::Point2f> dst = {{70 * kx, 40 * ky}, {590 * kx, 30 * ky}, {610 * kx, 335 * ky}, {50 * kx, 345 * ky}};
    cv::Mat H = cv::getPerspectiveTransform(src, dst);
    return cv::Matx33d((double*)H.clone().ptr());
}

float calidad_por_exposicion() {
    std::lock_guard<std::mutex> lk(g_mtx);
    auto it = g_ctrl.find("exposure_absolute");
    auto ia = g_ctrl.find("exposure_auto");
    if (it == g_ctrl.end() || (ia != g_ctrl.end() && ia->second == 3)) return 1.0f;
    double e = std::max(1, it->second);
    double z = (std::log(e) - std::log(300.0)) / 0.7;        // la mano se ve mejor con exposicion ~300
    return (float)std::exp(-0.5 * z * z);
}

cv::Mat cuadro_camara(int w, int h) {
    cv::Mat f(h, w, CV_8UC3, cv::Scalar(55, 55, 55));
    cv::Mat r;
    {
        std::lock_guard<std::mutex> lk(g_render_mtx);
        if (!g_render.empty()) r = g_render.clone();
    }
    if (!r.empty()) {
        cv::Matx33d H = render_a_camara(r.cols, r.rows, w, h);
        cv::Mat proy, mask;
        cv::warpPerspective(r, proy, cv::Mat(H), f.size());
        cv::warpPerspective(cv::Mat(r.size(), CV_8UC1, cv::Scalar(255)), mask, cv::Mat(H), f.size());
        cv::Mat mx = cv::max(f, proy);
        mx.copyTo(f, mask);
    }
    float k = 1.0f;
    {
        std::lock_guard<std::mutex> lk(g_mtx);
        auto it = g_ctrl.find("exposure_absolute");
        auto ia = g_ctrl.find("exposure_auto");
        if (it != g_ctrl.end() && !(ia != g_ctrl.end() && ia->second == 3))
            k = limitar(it->second / 157.0f, 0.2f, 4.0f);
    }
    if (std::fabs(k - 1.0f) > 0.01f) f.convertTo(f, -1, k, 0);
    cv::Mat ruido(f.size(), CV_8UC3);
    cv::randu(ruido, 0, 6);
    f += ruido;
    return f;
}

bool objetivo(float& x, float& y, std::string& forma) {
    std::ifstream fi("/tmp/fake_objetivo.json");
    if (!fi) return false;
    std::stringstream ss;
    ss << fi.rdbuf();
    std::string s = ss.str();
    if (s.find("\"mano\": true") == std::string::npos && s.find("\"mano\":true") == std::string::npos) return false;
    std::smatch m;
    if (std::regex_search(s, m, std::regex("\"x\"\\s*:\\s*(-?[0-9.]+)"))) x = std::stof(m[1]); else return false;
    if (std::regex_search(s, m, std::regex("\"y\"\\s*:\\s*(-?[0-9.]+)"))) y = std::stof(m[1]); else return false;
    forma = "abierta";
    if (std::regex_search(s, m, std::regex("\"forma\"\\s*:\\s*\"(\\w+)\""))) forma = m[1];
    return true;
}

}  // namespace sim
}  // namespace est
