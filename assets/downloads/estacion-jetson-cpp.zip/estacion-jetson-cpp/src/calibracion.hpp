// calibracion.hpp - relacion camara <-> proyeccion (homografia).
//
// Calibracion por PUNTOS (sin ArUco, solo OpenCV basico): se proyecta negro, luego 4 puntos blancos
// y luego una rejilla de 5x4 puntos. Restando la imagen negra quedan solo los puntos, aunque haya luz
// en el cuarto. Con 4 puntos se saca una relacion aproximada y con la rejilla se afina. ~4 segundos.
#pragma once

#include <cmath>
#include <functional>
#include <string>

#include <opencv2/core.hpp>

#include "camara.hpp"

namespace est {

struct Calibracion {
    cv::Matx33d H = cv::Matx33d::eye();   // camara (cam_w x cam_h) -> dibujo (w x h)
    int cam_w = 0, cam_h = 0, w = 0, h = 0;
    double error = 0;                     // error medio en pixeles de dibujo
    int puntos = 0;
    std::string fecha, origen;
    bool ok = false;

    cv::Matx33d escalada(int cw, int ch, int rw, int rh) const;
    bool compatible(int cw, int ch) const {      // misma forma de imagen (4:3, 16:9...) que la camara actual
        return cam_w > 0 && cam_h > 0 && std::fabs(cam_w / (double)cam_h - cw / (double)ch) < 0.01 * (cw / (double)ch);
    }
    // rectangulo de la camara donde cae la proyeccion (+ margen), para recortar lo que ve el detector
    cv::Rect zona_camara(int cw, int ch, int rw, int rh, float margen = 0.08f) const;
};

bool cargar_calibracion(const std::string& ruta, Calibracion& c);
bool guardar_calibracion(const std::string& ruta, const Calibracion& c);
bool importar_calibracion_python(const std::string& ruta_json, Calibracion& c);   // calib_hdmi.json

class Calibrador {
public:
    Calibrador(Camara& cam, ControlesV4L2& ctl, std::function<void(const cv::Mat&)> mostrar, int w, int h)
        : cam_(cam), ctl_(ctl), mostrar_(mostrar), w_(w), h_(h) {}
    bool correr(Calibracion& out);
    std::string detalle;                  // que paso (para el log)

private:
    cv::Mat capturar(const cv::Mat& patron, double espera, int n);
    Camara& cam_;
    ControlesV4L2& ctl_;
    std::function<void(const cv::Mat&)> mostrar_;
    int w_, h_;
};

}  // namespace est
