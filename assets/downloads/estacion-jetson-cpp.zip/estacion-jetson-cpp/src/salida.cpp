#include "salida.hpp"

#include <fcntl.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>

#include <cstring>

#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "comun.hpp"

namespace est {

// ====================================================================== framebuffer (/dev/fb0)
class SalidaFB : public Salida {
public:
    explicit SalidaFB(const std::string& dev) {
        fd_ = ::open(dev.c_str(), O_RDWR);
        if (fd_ < 0) throw std::runtime_error("no abre " + dev + " (" + strerror(errno) + "). Estas en el grupo video?");
        fb_var_screeninfo v;
        fb_fix_screeninfo f;
        if (ioctl(fd_, FBIOGET_VSCREENINFO, &v) < 0 || ioctl(fd_, FBIOGET_FSCREENINFO, &f) < 0)
            throw std::runtime_error("ioctl del framebuffer fallo");
        W_ = v.xres; H_ = v.yres; bpp_ = v.bits_per_pixel; stride_ = f.line_length;
        yoff_ = v.yoffset;
        largo_ = f.smem_len;
        if ((size_t)(yoff_ + H_) * stride_ > largo_) yoff_ = 0;
        if ((size_t)H_ * stride_ > largo_) throw std::runtime_error("el framebuffer es mas chico de lo que dice");
        mem_ = (uint8_t*)mmap(nullptr, largo_, PROT_READ | PROT_WRITE, MAP_SHARED, fd_, 0);
        if (mem_ == MAP_FAILED) throw std::runtime_error("mmap del framebuffer fallo");
        rgba_ = (bpp_ == 32 && v.red.offset == 0);   // la mayoria es BGRA (rojo en el byte 2)
        despertar();
        std::memset(mem_ + yoff_ * stride_, 0, (size_t)stride_ * H_);
        log("Framebuffer %s: %dx%d, %d bits, %s", dev.c_str(), W_, H_, bpp_, rgba_ ? "RGBA" : (bpp_ == 32 ? "BGRA" : "565"));
        if (bpp_ != 32 && bpp_ != 16) throw std::runtime_error("framebuffer de " + std::to_string(bpp_) + " bits no soportado");
    }
    ~SalidaFB() override {
        if (mem_ && mem_ != MAP_FAILED) {
            std::memset(mem_ + yoff_ * stride_, 0, (size_t)stride_ * H_);
            munmap(mem_, largo_);
        }
        if (fd_ >= 0) ::close(fd_);
    }
    int ancho() const override { return W_; }
    int alto() const override { return H_; }
    std::string nombre() const override { return "framebuffer"; }
    void mostrar(const cv::Mat& bgr) override {
        double t = ahora();
        if (t - t_despertar_ > 10) despertar();   // que la consola no apague el HDMI
        if (bpp_ == 32) {
            cv::cvtColor(bgr, chico4_, rgba_ ? cv::COLOR_BGR2RGBA : cv::COLOR_BGR2BGRA);
            cv::Mat destino(H_, W_, CV_8UC4, mem_ + yoff_ * stride_, stride_);
            cv::resize(chico4_, destino, destino.size(), 0, 0, cv::INTER_LINEAR);   // escribe directo al HDMI
        } else {
            cv::resize(bgr, grande_, cv::Size(W_, H_), 0, 0, cv::INTER_LINEAR);
            cv::Mat destino(H_, W_, CV_8UC2, mem_ + yoff_ * stride_, stride_);
            cv::cvtColor(grande_, destino, cv::COLOR_BGR2BGR565);
        }
    }

private:
    void despertar() {
        ioctl(fd_, FBIOBLANK, FB_BLANK_UNBLANK);
        t_despertar_ = ahora();
    }
    int fd_ = -1, W_ = 0, H_ = 0, bpp_ = 32, stride_ = 0, yoff_ = 0;
    size_t largo_ = 0;
    uint8_t* mem_ = nullptr;
    bool rgba_ = false;
    double t_despertar_ = 0;
    cv::Mat chico4_, grande_;
};

// ====================================================================== ventana (escritorio)
class SalidaVentana : public Salida {
public:
    SalidaVentana() {
        cv::namedWindow(NOMBRE, cv::WINDOW_NORMAL);
        cv::setWindowProperty(NOMBRE, cv::WND_PROP_FULLSCREEN, cv::WINDOW_FULLSCREEN);
    }
    ~SalidaVentana() override { cv::destroyWindow(NOMBRE); }
    int ancho() const override { return 1280; }
    int alto() const override { return 720; }
    std::string nombre() const override { return "ventana"; }
    void mostrar(const cv::Mat& bgr) override {
        cv::imshow(NOMBRE, bgr);
        cv::waitKey(1);
    }

private:
    static constexpr const char* NOMBRE = "Estacion";
};

// ====================================================================== PNG (pruebas)
class SalidaPNG : public Salida {
public:
    explicit SalidaPNG(const std::string& carpeta) : carpeta_(carpeta) {}
    int ancho() const override { return 1920; }
    int alto() const override { return 1080; }
    std::string nombre() const override { return "png"; }
    void mostrar(const cv::Mat& bgr) override {
        n_++;
        double t = ahora();
        if (t - t_ < 0.5) return;                    // dos imagenes por segundo bastan
        t_ = t;
        cv::imwrite(carpeta_ + "/ultimo_tmp.png", bgr);
        std::rename((carpeta_ + "/ultimo_tmp.png").c_str(), (carpeta_ + "/ultimo.png").c_str());
    }

private:
    std::string carpeta_;
    long n_ = 0;
    double t_ = 0;
};

class SalidaNula : public Salida {
public:
    int ancho() const override { return 1920; }
    int alto() const override { return 1080; }
    std::string nombre() const override { return "nula"; }
    void mostrar(const cv::Mat&) override {}
};

std::unique_ptr<Salida> crear_salida(const std::string& tipo, std::string& error) {
    try {
        if (tipo == "fb" || tipo.compare(0, 3, "fb:") == 0)
            return std::unique_ptr<Salida>(new SalidaFB(tipo == "fb" ? "/dev/fb0" : tipo.substr(3)));
        if (tipo == "ventana") return std::unique_ptr<Salida>(new SalidaVentana());
        if (tipo.compare(0, 4, "png:") == 0) return std::unique_ptr<Salida>(new SalidaPNG(tipo.substr(4)));
        if (tipo == "nula") return std::unique_ptr<Salida>(new SalidaNula());
        error = "salida desconocida: " + tipo;
    } catch (const std::exception& e) {
        error = e.what();
    }
    return nullptr;
}

}  // namespace est
