// salida.hpp - a donde va la imagen: framebuffer del HDMI (sin escritorio), ventana, archivos PNG o nada.
#pragma once

#include <memory>
#include <string>

#include <opencv2/core.hpp>

namespace est {

class Salida {
public:
    virtual ~Salida() {}
    virtual int ancho() const = 0;      // resolucion real (HDMI)
    virtual int alto() const = 0;
    virtual void mostrar(const cv::Mat& bgr) = 0;   // imagen chica de dibujo; se escala sola
    virtual std::string nombre() const = 0;
};

// tipo: fb | fb:/dev/fb1 | ventana | png:/carpeta | nula
std::unique_ptr<Salida> crear_salida(const std::string& tipo, std::string& error);

}  // namespace est
