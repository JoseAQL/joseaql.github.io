// vision.hpp - hilo de vision: toma el cuadro mas nuevo de la camara, lo prepara (recorte, gamma...)
// y busca las manos. Nunca frena el dibujo: el hilo principal solo recoge el ultimo resultado.
#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

#include "ajustes.hpp"
#include "camara.hpp"
#include "comun.hpp"
#include "detector.hpp"

namespace est {

struct ResultadoVision {
    uint64_t n = 0;                   // numero de resultado (sube con cada deteccion)
    double t_captura = 0;             // hora en que la camara tomo el cuadro
    double t_listo = 0;               // hora en que termino el detector
    std::vector<ManoCruda> manos;     // en pixeles de la camara completa
    float luz = 0;                    // brillo medio de lo que ve el detector (0..255)
    cv::Rect roi;                     // recorte usado
    float fps = 0;                    // detecciones por segundo
    float ms_detector = 0;            // tiempo del detector
};

struct VistaVision {                  // para la ventana por SSH
    cv::Mat camara;                   // cuadro completo (chico)
    cv::Mat detector;                 // lo que ve el detector (recorte + filtros, chico)
    cv::Rect roi;
    int cam_w = 0, cam_h = 0;
    std::vector<ManoCruda> manos;     // pixeles de la camara completa
};

class Vision {
public:
    ~Vision() { detener(); }
    void iniciar(Camara* cam, const Ajustes& aj, const std::string& motor, int fps_max, int max_manos);
    void detener();
    void pausar(bool p) { pausado_ = p; }
    void poner_roi(const cv::Rect& r);
    void poner_ajustes(const Ajustes& aj);
    bool tomar(ResultadoVision& r, uint64_t ultimo_n);
    void copiar_vista(VistaVision& v);
    bool listo() const { return listo_; }
    std::string detector();
    std::string error();
    double t_inicio() const { return t_inicio_; }

private:
    void hilo();
    void preparar(const cv::Mat& cuadro, const cv::Rect& roi, cv::Mat& out);

    Camara* cam_ = nullptr;
    std::thread th_;
    std::atomic<bool> vivo_{false}, pausado_{false}, listo_{false};
    std::mutex mtx_;
    Ajustes aj_, aj_nuevos_;
    bool hay_aj_nuevos_ = false;
    cv::Rect roi_;
    ResultadoVision res_;
    VistaVision vista_;
    std::string motor_, nombre_detector_, error_;
    int fps_max_ = 0, max_manos_ = 2;
    double t_inicio_ = 0;
    // preproceso
    cv::Mat lut_;
    float lut_gamma_ = -1;
    cv::Ptr<cv::CLAHE> clahe_;
    float clahe_valor_ = -1;
};

}  // namespace est
