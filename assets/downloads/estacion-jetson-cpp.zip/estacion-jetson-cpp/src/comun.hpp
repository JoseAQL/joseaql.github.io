// comun.hpp - utilidades compartidas: tiempo, log, filtro de suavizado, puntos de la mano.
#pragma once

#include <array>
#include <atomic>
#include <cmath>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

namespace est {

// ------------------------------------------------------------------ tiempo y log
double ahora();                                   // segundos (reloj monotono)
void log(const char* fmt, ...) __attribute__((format(printf, 1, 2)));
std::string fecha_hora();                         // "2026-10-07 12:34:56"
std::string carpeta_programa();                   // carpeta donde esta el ejecutable (sin "/build")

extern std::atomic<bool> g_vivo;                  // se pone en false con Ctrl+C

// ------------------------------------------------------------------ geometria
inline float dist(const cv::Point2f& a, const cv::Point2f& b) { return std::hypot(a.x - b.x, a.y - b.y); }
inline float limitar(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline bool dentro(const cv::Rect& r, const cv::Point2f& p) {
    return p.x >= r.x && p.y >= r.y && p.x < r.x + r.width && p.y < r.y + r.height;
}

// ------------------------------------------------------------------ mano (21 puntos)
// 0 muneca | 1-4 pulgar | 5-8 indice | 9-12 medio | 13-16 anular | 17-20 menique
// La estacion solo usa PULGAR (1-4) e INDICE (5-8): punta del indice = puntero,
// pulgar junto al indice = mano "cerrada" (clic), separados = "abierta".
enum { MUNECA = 0, PULGAR_PUNTA = 4, INDICE_BASE = 5, INDICE_PUNTA = 8 };

struct ManoCruda {                                // lo que regresa el detector (pixeles de la camara)
    std::array<cv::Point2f, 21> p;
    std::array<bool, 21> ok;
    int vistos = 0;
    ManoCruda() { ok.fill(false); }
};

// Completa puntos que el detector no vio, siguiendo cada dedo (como plataforma.rellenar de Python).
// Regresa false si la mano no tiene suficiente pulgar/indice para usarse.
bool completar_mano(ManoCruda& m);

// ------------------------------------------------------------------ filtro "One Euro"
// Suaviza mucho cuando la mano esta quieta (sin temblor) y casi nada cuando se mueve rapido (sin retraso).
class FiltroEuro {
public:
    FiltroEuro(double fmin = 1.2, double beta = 0.015, double dcorte = 1.0)
        : fmin_(fmin), beta_(beta), dcorte_(dcorte) {}
    double filtrar(double x, double t);
    double velocidad() const { return dx_; }      // unidades por segundo
    double valor() const { return x_; }
    void reiniciar() { listo_ = false; }
    bool listo() const { return listo_; }

private:
    static double alfa(double dt, double fc) {
        const double tau = 1.0 / (2.0 * M_PI * fc);
        return 1.0 / (1.0 + tau / dt);
    }
    double fmin_, beta_, dcorte_;
    double x_ = 0, dx_ = 0, t_ = 0;
    bool listo_ = false;
};

}  // namespace est
