// manos.hpp - convierte lo que ve la camara en "manos de la estacion" sobre la proyeccion:
// puntero = punta del INDICE (suavizado y adelantado), estado = pulgar e indice juntos (CERRADA)
// o separados (ABIERTA), con eventos de cerrar/abrir para usarlos como clic.
#pragma once

#include <vector>

#include <opencv2/core.hpp>

#include "ajustes.hpp"
#include "comun.hpp"

namespace est {

struct ManoUI {
    int id = 0;
    cv::Point2f punta;                 // puntero (dibujo): indice suavizado + prediccion
    cv::Point2f punta_cruda;           // ultima deteccion sin suavizar
    cv::Point2f velocidad;             // pixeles por segundo
    bool cerrada = false;              // pulgar tocando el indice
    bool evento_cerrar = false;        // se cerro en este cuadro (clic)
    bool evento_abrir = false;         // se abrio en este cuadro
    float apertura = 1.0f;             // distancia pulgar-indice / largo del indice
    std::array<cv::Point2f, 21> p;     // todos los puntos en coordenadas de dibujo
    double t_visto = 0;
};

class SeguidorManos {
public:
    void configurar(const Ajustes& aj);
    // nueva deteccion: manos en pixeles de la camara, H = camara -> dibujo
    void actualizar(const std::vector<ManoCruda>& manos_cam, const cv::Matx33d& H, double t_captura);
    // cada cuadro de dibujo: suaviza, adelanta el puntero y entrega los eventos una sola vez
    const std::vector<ManoUI>& cuadro(double t, int w, int h);
    void olvidar() { pistas_.clear(); salida_.clear(); }

private:
    struct Pista {
        ManoUI m;
        FiltroEuro fx, fy;
        double t_cap = 0;
        bool ev_cerrar = false, ev_abrir = false;
    };
    std::vector<Pista> pistas_;
    std::vector<ManoUI> salida_;
    int siguiente_id_ = 1;
    float cerrar_ = 0.30f, abrir_ = 0.45f;
    double pred_ = 0.0;
};

}  // namespace est
