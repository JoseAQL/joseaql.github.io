// sonido.hpp - notas y efectos con muy poco retraso: un hilo mezcla las voces y las manda a 'aplay'
// por una tuberia que se queda abierta (no se abre un programa por cada nota).
#pragma once

#include <atomic>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace est {

class Sonido {
public:
    ~Sonido() { detener(); }
    bool iniciar(const std::string& dispositivo);   // "auto", "no" o "plughw:2,0"
    void detener();
    void nota(float frecuencia, float duracion = 0.45f, float volumen = 0.35f);
    void pop(float tono = 1.0f);                     // burbuja que revienta
    void clic();                                     // seleccion en el menu
    bool activo() const { return activo_; }
    const std::string& dispositivo() const { return dev_; }

private:
    struct Voz {
        float f, fase = 0, t = 0, dur, vol;
        int tipo;                                    // 0 nota, 1 pop, 2 clic
    };
    void hilo();
    FILE* tubo_ = nullptr;
    std::thread th_;
    std::mutex mtx_;
    std::vector<Voz> voces_;
    std::atomic<bool> activo_{false};
    std::string dev_;
};

}  // namespace est
