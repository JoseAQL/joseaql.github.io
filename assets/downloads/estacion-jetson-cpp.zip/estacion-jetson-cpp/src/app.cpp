#include "app.hpp"

#include <sys/select.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <algorithm>
#include <cstdlib>

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>

namespace est {

static const char* VENTANA_SSH = "Estacion C++ - camara y ajustes (SSH)";
static const float GAMMAS[] = {0.6f, 0.8f, 1.0f, 1.2f, 1.4f, 1.6f, 1.8f, 2.0f, 2.3f, 2.6f, 3.0f};
static const float CLAHES[] = {0, 1, 1.5f, 2, 3, 4, 6};
static const int SUAV[] = {0, 3, 5, 7, 9};

template <typename T, size_t N>
static T paso_lista(T v, const T (&l)[N], int signo) {
    size_t k = 0;
    for (size_t i = 1; i < N; i++)
        if (std::fabs((double)l[i] - v) < std::fabs((double)l[k] - v)) k = i;
    int j = std::max(0, std::min((int)N - 1, (int)k + signo));
    return l[j];
}

void Modo::icono(cv::Mat& img, cv::Rect r, double) const {
    cv::circle(img, (r.tl() + r.br()) / 2, std::min(r.width, r.height) / 4, ui::GRIS, 2, cv::LINE_AA);
}

// El servidor X (MobaXterm) responde? Con OpenCV 4.1 + GTK, abrir una ventana sin servidor X cierra
// todo el programa, asi que primero se prueba la conexion (DISPLAY = ":0" o "localhost:10.0").
static bool display_responde(const char* disp) {
    if (!disp || !*disp) return false;
    std::string d(disp);
    size_t dp = d.rfind(':');
    if (dp == std::string::npos) return false;
    std::string host = d.substr(0, dp);
    int num = std::atoi(d.substr(dp + 1).c_str());
    int fd = -1;
    bool ok = false;
    if (host.empty() || host == "unix") {
        fd = socket(AF_UNIX, SOCK_STREAM, 0);
        sockaddr_un a{};
        a.sun_family = AF_UNIX;
        snprintf(a.sun_path, sizeof(a.sun_path), "/tmp/.X11-unix/X%d", num);
        ok = fd >= 0 && connect(fd, (sockaddr*)&a, sizeof(a)) == 0;
    } else {
        addrinfo pista{}, *r = nullptr;
        pista.ai_socktype = SOCK_STREAM;
        if (getaddrinfo(host.c_str(), std::to_string(6000 + num).c_str(), &pista, &r) == 0 && r) {
            fd = socket(r->ai_family, SOCK_STREAM, 0);
            if (fd >= 0) {
                timeval tv{2, 0};
                setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
                ok = connect(fd, r->ai_addr, r->ai_addrlen) == 0;
            }
            freeaddrinfo(r);
        }
    }
    if (fd >= 0) close(fd);
    return ok;
}

App::App(const Opciones& op) : op_(op) {}

App::~App() { cerrar(); }

// ====================================================================== arranque
bool App::iniciar() {
    std::string carpeta = carpeta_programa();
    ruta_aj_ = op_.config.empty() ? carpeta + "/ajustes.cfg" : op_.config;
    ruta_calib_ = carpeta + "/calibracion.txt";
    const char* home = getenv("HOME");
    std::string home_s = home ? home : ".";

    // ajustes: los propios, o los de la version Python la primera vez
    if (aj_.cargar(ruta_aj_)) {
        log("Ajustes: %s", ruta_aj_.c_str());
    } else {
        for (const std::string& p : {carpeta + "/../estacion/filtros.json", home_s + "/estacion/filtros.json"})
            if (aj_.importar_filtros_json(p)) {
                log("Ajustes importados de %s (version Python)", p.c_str());
                break;
            }
        aj_.guardar(ruta_aj_);
    }

    std::string err;
    sal_ = crear_salida(op_.salida, err);
    if (!sal_) {
        log("Salida: %s", err.c_str());
        return false;
    }
    h_ = op_.ahorro ? std::min(op_.alto, 360) : op_.alto;
    w_ = ((int)std::lround(h_ * (double)sal_->ancho() / sal_->alto()) / 2) * 2;
    log("Dibujo %dx%d -> %s %dx%d", w_, h_, sal_->nombre().c_str(), sal_->ancho(), sal_->alto());
    cv::Mat img(h_, w_, CV_8UC3);
    ui::fondo(img);
    ui::texto(img, "ESTACION C++", w_ / 2.0f, h_ / 2.0f - 10, 1.3, ui::AMARILLO, true, 3);
    ui::texto(img, "Iniciando camara...", w_ / 2.0f, h_ / 2.0f + 35, 0.6, ui::BLANCO, true, 1);
    mostrar(img);

    if (op_.camara == "sim") {
        setenv("ESTACION_SIM_RENDER", cv::format("%dx%d", w_, h_).c_str(), 1);
        setenv("ESTACION_SIM_CAM", cv::format("%dx%d", op_.cam_w, op_.cam_h).c_str(), 1);
    }
    if (!cam_.abrir(op_.camara, op_.cam_w, op_.cam_h, op_.cam_fps)) {
        ui::fondo(img);
        ui::texto(img, "No abre la camara " + op_.camara, w_ / 2.0f, h_ / 2.0f, 0.8, ui::ROJO, true, 2);
        mostrar(img);
        sleep(3);
        return false;
    }
    ctl_.abrir(cam_.dispositivo());
    if (ctl_.info("exposure_auto_priority").existe) ctl_.poner("exposure_auto_priority", 0);   // 30 FPS fijos
    son_.iniciar(op_.audio);

    modos_ = crear_modos(*this);
    std::vector<Modo*> lista;
    for (auto& m : modos_) lista.push_back(m.get());
    menu_ = crear_menu(*this, lista);

    // calibracion del proyector
    Calibracion c;
    if (op_.calib_python) {
        for (const std::string& p : {carpeta + "/../estacion/calib_hdmi.json", home_s + "/estacion/calib_hdmi.json"})
            if (importar_calibracion_python(p, c)) break;
        if (c.ok && !c.compatible(cam_.ancho(), cam_.alto())) {
            log("calib_hdmi.json es de una camara %dx%d (otra forma de imagen que %dx%d): no sirve, calibro",
                c.cam_w, c.cam_h, cam_.ancho(), cam_.alto());
            c.ok = false;
        }
        if (c.ok) aplicar_calibracion(c);
        else calibrar_proyector(true);
    } else if (op_.calibrar) {
        calibrar_proyector(true);
    } else if (cargar_calibracion(ruta_calib_, c) && c.compatible(cam_.ancho(), cam_.alto())) {
        aplicar_calibracion(c);
        log("Calibracion guardada: %s", c.fecha.c_str());
    } else {
        calibrar_proyector(true);
    }
    ctl_.aplicar(aj_.ctrl);                           // ajustes de camara para las manos

    seg_.configurar(aj_);
    int fps_max = op_.ahorro ? 10 : 0;
    int manos = op_.ahorro ? 1 : op_.max_manos;
    vis_.iniciar(&cam_, aj_, op_.motor, fps_max, manos);
    vis_.poner_roi(calib_.zona_camara(cam_.ancho(), cam_.alto(), w_, h_));

    const char* disp = getenv("DISPLAY");
    ver_ = op_.ver && disp && *disp && op_.salida != "ventana";
    if (ver_ && !display_responde(disp)) {
        log("La ventana SSH no se abre: el servidor X de tu PC no responde (DISPLAY=%s). Sigo sin ventana;"
            " las teclas funcionan en la terminal", disp);
        ver_ = false;
    }
    if (ver_ && op_.ssh_hilo) {
        vista_viva_ = true;
        th_vista_ = std::thread(&App::hilo_vista, this);
    }
    if (ver_) log("Ventana por SSH activada (--sin-ver para quitarla)");
    else if (op_.ver && op_.salida != "ventana" && !(disp && *disp)) log("Sin ventana SSH (no hay DISPLAY: conecta con X11)");

    // teclas tambien desde la terminal (sirve aunque no haya ventana X11)
    if (isatty(STDIN_FILENO) && tcgetpgrp(STDIN_FILENO) == getpgrp() &&   // solo en primer plano
        tcgetattr(STDIN_FILENO, &tty_orig_) == 0) {
        struct termios crudo = tty_orig_;
        crudo.c_lflag &= ~(ICANON | ECHO);
        crudo.c_cc[VMIN] = 0;
        crudo.c_cc[VTIME] = 0;
        if (tcsetattr(STDIN_FILENO, TCSANOW, &crudo) == 0) {
            teclas_tty_ = true;
            log("Teclas: tambien funcionan aqui en la terminal (Q/A exposicion, V/C relleno, 2 autocal, 3 recalibrar...)");
        }
    }
    teclas_stdin_ = teclas_tty_ || op_.teclas_stdin;

    modo_ = menu_.get();
    Contexto c0;
    c0.t = ahora(); c0.w = w_; c0.h = h_;
    modo_->entrar(c0);
    if (!op_.modo_inicial.empty()) {
        for (auto& m : modos_) {
            std::string n = m->nombre();
            std::transform(n.begin(), n.end(), n.begin(), ::tolower);
            if (n.find(op_.modo_inicial) == 0 && m->accion() == Modo::NORMAL) {
                modo_ = m.get();
                modo_->entrar(c0);
            }
        }
    }
    t_modo_ = ahora();
    boton_menu_.reiniciar();
    return true;
}

void App::cerrar() {
    if (teclas_tty_) {
        tcsetattr(STDIN_FILENO, TCSANOW, &tty_orig_);
        teclas_tty_ = false;
    }
    vista_viva_ = false;
    if (th_vista_.joinable()) th_vista_.join();
    vis_.detener();
    cam_.cerrar();
    son_.detener();
    if (!ruta_aj_.empty()) {
        aj_.guardar(ruta_aj_);
        log("Ajustes guardados en %s", ruta_aj_.c_str());
        ruta_aj_.clear();
    }
    sal_.reset();
}

void App::mostrar(const cv::Mat& img) {
    sal_->mostrar(img);
    if (cam_.simulada()) sim::poner_render(img);
}

// ====================================================================== calibracion
void App::aplicar_calibracion(const Calibracion& c) {
    calib_ = c;
    H_ = c.escalada(cam_.ancho(), cam_.alto(), w_, h_);
    vis_.poner_roi(c.zona_camara(cam_.ancho(), cam_.alto(), w_, h_));
    seg_.olvidar();
}

bool App::calibrar_proyector(bool al_inicio) {
    vis_.pausar(true);
    log("Calibrando el proyector (puntos)...");
    Calibrador cal(cam_, ctl_, [this](const cv::Mat& m) { mostrar(m); }, w_, h_);
    Calibracion c;
    bool ok = false;
    for (int intento = 0; intento < 2 && !ok && g_vivo; intento++) {
        ok = cal.correr(c);
        log("Calibracion intento %d: %s", intento + 1, cal.detalle.c_str());
    }
    ctl_.aplicar(aj_.ctrl);
    if (ok) {
        guardar_calibracion(ruta_calib_, c);
        aplicar_calibracion(c);
        log("Calibracion lista: error %.2f px con %d puntos", c.error, c.puntos);
        aviso(cv::format("Calibrado (error %.1f px)", c.error));
    } else {
        Calibracion g;
        std::string carpeta = carpeta_programa();
        const char* home = getenv("HOME");
        auto sirve = [&](bool leido) { return leido && g.compatible(cam_.ancho(), cam_.alto()); };
        if (sirve(cargar_calibracion(ruta_calib_, g)) ||
            sirve(importar_calibracion_python(carpeta + "/../estacion/calib_hdmi.json", g)) ||
            sirve(importar_calibracion_python(std::string(home ? home : ".") + "/estacion/calib_hdmi.json", g))) {
            aplicar_calibracion(g);
            log("No vi los puntos: uso la calibracion %s (%s)", g.origen.c_str(), g.fecha.c_str());
            aviso("No vi los puntos: uso la calibracion anterior");
        } else if (al_inicio) {
            Calibracion a;                    // aproximada: la camara completa = la proyeccion
            a.cam_w = cam_.ancho(); a.cam_h = cam_.alto(); a.w = w_; a.h = h_;
            a.H = cv::Matx33d(w_ / (double)a.cam_w, 0, 0, 0, h_ / (double)a.cam_h, 0, 0, 0, 1);
            a.ok = true;
            a.origen = "aproximada";
            aplicar_calibracion(a);
            log("SIN CALIBRACION: la camara no vio los puntos. Revisa que vea la proyeccion (tecla 3 = reintentar)");
            aviso("Sin calibracion: tecla 3 o mosaico Recalibrar");
        }
    }
    vis_.pausar(false);
    return ok;
}

// ====================================================================== ayudas para los modos
void App::ir_menu() {
    modo_ = menu_.get();
    Contexto c;
    c.t = ahora(); c.w = w_; c.h = h_;
    modo_->entrar(c);
    log("Modo: Menu");
}

void App::ajustes_cambiados() {
    vis_.poner_ajustes(aj_);
    seg_.configurar(aj_);
}

void App::poner_control(const std::string& nombre, int valor) {
    ctl_.poner(nombre, valor);
    aj_.ctrl[nombre] = valor;
}

void App::guardar_ajustes() { aj_.guardar(ruta_aj_); }

void App::aviso(const std::string& s) {
    std::lock_guard<std::mutex> lk(mtx_resumen_);
    aviso_ = s;
    t_aviso_ = ahora();
}

// ====================================================================== bucle principal
int App::correr() {
    if (!iniciar()) {
        cerrar();
        return 1;
    }
    const int fps = op_.ahorro ? std::min(op_.fps, 20) : op_.fps;
    const double periodo = 1.0 / std::max(5, fps);
    double t_prev = ahora(), t_log = t_prev, t_ini = t_prev, t_res = 0;
    int cuadros = 0;
    cv::Mat img(h_, w_, CV_8UC3);
    Contexto c;
    c.w = w_;
    c.h = h_;
    while (g_vivo) {
        double t = ahora();
        c.t = t;
        c.dt = std::min(0.1, t - t_prev);
        t_prev = t;

        ResultadoVision r;
        if (vis_.tomar(r, res_.n)) {
            res_ = r;
            seg_.actualizar(r.manos, H_, r.t_captura);
        }
        c.manos = seg_.cuadro(t, w_, h_);
        procesar_teclas();

        img.setTo(cv::Scalar::all(0));
        modo_->dibujar(c, img);
        if (modo_ != menu_.get() && modo_->con_boton_menu()) boton_menu(c, img);
        if (!vis_.listo()) {
            std::string e = vis_.error();
            std::string txt = e.empty() ? cv::format("Cargando detector de manos... %.0f s", t - vis_.t_inicio())
                                        : "Sin detector: " + e.substr(0, 70);
            ui::texto(img, txt, w_ / 2.0f, h_ - 12.0f, 0.5, e.empty() ? ui::AMARILLO : ui::ROJO, true, 1);
        }
        if (aj_.relleno > 0) cv::max(img, cv::Scalar::all(aj_.relleno), img);   // luz de relleno
        mostrar(img);

        // cambios de modo pedidos durante el dibujo
        if (siguiente_) {
            Modo* m = siguiente_;
            siguiente_ = nullptr;
            if (m->accion() == Modo::SALIR) break;
            if (m->accion() == Modo::RECALIBRAR) {
                calibrar_proyector(false);
                ir_menu();
            } else {
                modo_ = m;
                t_modo_ = t;
                boton_menu_.reiniciar();
                m->entrar(c);
                log("Modo: %s", m->nombre());
            }
        }
        if (recalibrar_) {
            recalibrar_ = false;
            calibrar_proyector(false);
            ir_menu();
        }
        auto_exposicion(t);

        if (t - t_res > 0.2) {                    // resumen para la ventana SSH
            t_res = t;
            Resumen s;
            s.modo = modo_->nombre();
            s.detector = vis_.detector();
            s.error_detector = vis_.error();
            s.detector_listo = vis_.listo();
            s.fps_dibujo = fps_dibujo_;
            s.fps_vision = res_.fps;
            s.ms_detector = res_.ms_detector;
            s.latencia_ms = res_.n ? (float)((res_.t_listo - res_.t_captura) * 1000.0 + periodo * 500.0) : 0;
            s.luz = res_.luz;
            s.fps_camara = cam_.fps_real();
            s.manos = c.manos;
            s.aj = aj_;
            s.expo = valor_ctrl("exposure_absolute");
            int ea;
            if (ctl_.leer("exposure_auto", ea) && ea != 1) s.expo = "auto";
            s.ganancia = valor_ctrl("gain");
            s.brillo = valor_ctrl("brightness");
            s.contraste = valor_ctrl("contrast");
            std::vector<cv::Point2f> esq = {{0, 0}, {(float)w_, 0}, {(float)w_, (float)h_}, {0, (float)h_}};
            cv::perspectiveTransform(esq, s.contorno_cam, H_.inv());
            std::lock_guard<std::mutex> lk(mtx_resumen_);
            s.aviso = aviso_;
            s.t_aviso = t_aviso_;
            s.vista = vista_;
            resumen_ = s;
        }
        if (ver_ && !op_.ssh_hilo && t - t_vista_main_ > 0.3) {   // modo sin hilo: ventana en este hilo
            t_vista_main_ = t;
            VistaVision v;
            vis_.copiar_vista(v);
            cv::Mat out;
            dibujar_vista(out, resumen(), v);
            cv::imshow(VENTANA_SSH, out);
            int k = cv::waitKey(1) & 0xFF;
            if (k != 255) tecla(k);
        }

        cuadros++;
        if (t - t_log >= 5) {
            fps_dibujo_ = float(cuadros / (t - t_log));
            log("%s | dibujo %.0f FPS | vision %.1f FPS (detector %.0f ms) | camara %.0f FPS | manos %d | luz %.0f",
                modo_->nombre(), fps_dibujo_, res_.fps, res_.ms_detector, cam_.fps_real(), (int)c.manos.size(), res_.luz);
            t_log = t;
            cuadros = 0;
        }
        if (op_.duracion > 0 && t - t_ini > op_.duracion) break;
        double espera = periodo - (ahora() - t);
        if (espera > 0) usleep((useconds_t)(espera * 1e6));
    }
    log("Saliendo");
    cerrar();
    return 0;
}

// boton MENU: punta del indice encima 1 s, o pellizco encima (inmediato)
void App::boton_menu(Contexto& c, cv::Mat& img) {
    int bw = std::max(110, (int)(w_ * 0.18)), bh = std::max(70, (int)(h_ * 0.17));
    boton_menu_.rect = op_.menu_der ? cv::Rect(w_ - bw, 0, bw, bh) : cv::Rect(0, 0, bw, bh);
    boton_menu_.etiqueta = "";
    if (boton_menu_.actualizar(c.manos, c.t, 1.0)) {
        son_.clic();
        siguiente_ = menu_.get();
    }
    boton_menu_.dibujar(img, c.t, 1.0, 0.8);
    cv::Rect r = boton_menu_.rect;
    cv::Point cc(r.x + r.width / 2, r.y + r.height / 2 - 12);
    for (int k = 0; k < 3; k++)
        cv::line(img, cc + cv::Point(-16, -8 + k * 8), cc + cv::Point(16, -8 + k * 8), ui::BLANCO, 3, cv::LINE_AA);
    ui::texto(img, "MENU", r.x + r.width / 2.0f, r.y + r.height / 2.0f + 24, 0.7, ui::BLANCO, true, 2);
    if (c.t - t_modo_ < 4) {
        float x = op_.menu_der ? (float)(w_ - 330) : 8.0f;
        ui::texto(img, "MENU: indice encima 1 s o pellizca encima", x, r.y + r.height + 20.0f, 0.45, ui::AMARILLO, false, 1);
    }
}

// mantiene la imagen de las manos ni quemada ni oscura (opcional, tecla 4)
void App::auto_exposicion(double t) {
    if (!aj_.auto_exposicion || !vis_.listo() || t - t_expo_ < 0.7 || res_.n == 0) return;
    t_expo_ = t;
    ControlesV4L2::Info e = ctl_.info("exposure_absolute");
    if (!e.existe) return;
    float luz = res_.luz;
    int actual = aj_.ctrl.count("exposure_absolute") ? aj_.ctrl["exposure_absolute"] : e.valor;
    int nuevo = actual;
    if (luz > aj_.luz_objetivo + 22) nuevo = (int)std::lround(actual / 1.15);
    else if (luz < aj_.luz_objetivo - 22) nuevo = (int)std::lround(actual * 1.15) + 1;
    nuevo = std::max(e.min, std::min(e.max, nuevo));
    if (nuevo == actual) return;
    if (ctl_.info("exposure_auto").existe) poner_control("exposure_auto", 1);
    poner_control("exposure_absolute", nuevo);
}

std::string App::valor_ctrl(const std::string& n) {
    ControlesV4L2::Info i = ctl_.info(n);
    if (!i.existe) return "no disponible";
    int v = aj_.ctrl.count(n) ? aj_.ctrl[n] : i.valor;
    return cv::format("%d  (%d..%d)", v, i.min, i.max);
}

// ====================================================================== teclas (ventana SSH)
void App::tecla(int k) {
    std::lock_guard<std::mutex> lk(mtx_teclas_);
    if (teclas_.size() < 32) teclas_.push_back(k);
}

void App::procesar_teclas() {
    while (teclas_stdin_) {                       // teclas escritas en la terminal
        fd_set fs;
        FD_ZERO(&fs);
        FD_SET(STDIN_FILENO, &fs);
        struct timeval tv = {0, 0};
        if (select(STDIN_FILENO + 1, &fs, nullptr, nullptr, &tv) <= 0) break;
        unsigned char ch;
        ssize_t n = read(STDIN_FILENO, &ch, 1);
        if (n <= 0) { teclas_stdin_ = false; break; }
        if (ch != '\n' && ch != '\r') tecla(ch);
    }
    std::deque<int> ts;
    {
        std::lock_guard<std::mutex> lk(mtx_teclas_);
        ts.swap(teclas_);
    }
    for (int k : ts) {
        if (k >= 'A' && k <= 'Z') k += 32;
        std::string msg;
        bool cambio = false;
        auto ctrl_paso = [&](const char* n, int signo, const char* etiqueta) {
            ControlesV4L2::Info i = ctl_.info(n);
            if (!i.existe) { msg = std::string("Tu camara no tiene ") + etiqueta; return; }
            int actual = aj_.ctrl.count(n) ? aj_.ctrl[n] : i.valor;
            int paso = std::max(i.paso, (i.max - i.min) / 16);
            int v = std::max(i.min, std::min(i.max, actual + signo * std::max(1, paso)));
            poner_control(n, v);
            msg = cv::format("%s: %d", etiqueta, v);
        };
        switch (k) {
            case 'q': case 'a': {
                ControlesV4L2::Info i = ctl_.info("exposure_absolute");
                if (!i.existe) { msg = "Tu camara no deja cambiar la exposicion"; break; }
                if (ctl_.info("exposure_auto").existe) poner_control("exposure_auto", 1);
                int actual = aj_.ctrl.count("exposure_absolute") ? aj_.ctrl["exposure_absolute"] : i.valor;
                int v = (int)std::lround(k == 'q' ? actual * 1.4 : actual / 1.4);
                if (v == actual) v += k == 'q' ? 1 : -1;
                v = std::max(i.min, std::min(i.max, v));
                poner_control("exposure_absolute", v);
                msg = cv::format("Exposicion manual: %d", v);
                break;
            }
            case 'w': ctrl_paso("gain", +1, "Ganancia"); break;
            case 's': ctrl_paso("gain", -1, "Ganancia"); break;
            case 'e': ctrl_paso("brightness", +1, "Brillo"); break;
            case 'd': ctrl_paso("brightness", -1, "Brillo"); break;
            case 'r': ctrl_paso("contrast", +1, "Contraste"); break;
            case 'f': ctrl_paso("contrast", -1, "Contraste"); break;
            case 't': case 'g': aj_.gamma = paso_lista(aj_.gamma, GAMMAS, k == 't' ? 1 : -1); msg = cv::format("Gamma: %.1f", aj_.gamma); cambio = true; break;
            case 'y': case 'h': aj_.clahe = paso_lista(aj_.clahe, CLAHES, k == 'y' ? 1 : -1); msg = cv::format("CLAHE: %.1f", aj_.clahe); cambio = true; break;
            case 'u': case 'j': aj_.saturacion = limitar(aj_.saturacion + (k == 'u' ? 0.1f : -0.1f), 0, 1.5f); msg = cv::format("Saturacion: %.1f", aj_.saturacion); cambio = true; break;
            case 'i': case 'k': aj_.suavizado = paso_lista(aj_.suavizado, SUAV, k == 'i' ? 1 : -1); msg = cv::format("Suavizado: %d", aj_.suavizado); cambio = true; break;
            case 'o': case 'l': aj_.recorte = (k == 'o'); msg = aj_.recorte ? "Recorte: solo la proyeccion" : "Recorte: camara completa"; cambio = true; break;
            case 'p': case 'n': aj_.umbral = limitar(aj_.umbral + (k == 'p' ? 0.025f : -0.025f), 0.05f, 0.5f); msg = cv::format("Umbral: %.3f", aj_.umbral); cambio = true; break;
            case 'x': case 'z': aj_.min_puntos = std::max(3, std::min(16, aj_.min_puntos + (k == 'x' ? 1 : -1))); msg = cv::format("Puntos minimos: %d", aj_.min_puntos); cambio = true; break;
            case 'v': case 'c': aj_.relleno = std::max(0, std::min(150, aj_.relleno + (k == 'v' ? 10 : -10))); msg = cv::format("Luz de relleno: %d", aj_.relleno); break;
            case '1':
                if (ctl_.info("exposure_auto").existe) poner_control("exposure_auto", 3);
                aj_.ctrl.erase("exposure_absolute");
                msg = "Exposicion automatica";
                break;
            case '2':
                for (auto& m : modos_)
                    if (std::string(m->nombre()).find("Autocal") == 0) siguiente_ = m.get();
                msg = "Autocalibrado de manos";
                break;
            case '3': recalibrar_ = true; msg = "Recalibrando el proyector"; break;
            case '4': aj_.auto_exposicion = !aj_.auto_exposicion; msg = aj_.auto_exposicion ? "Auto-exposicion: SI" : "Auto-exposicion: NO"; break;
            case 'b': vista_ = 1 - vista_; msg = vista_ ? "Vista: camara completa" : "Vista: lo que ve el detector"; break;
            case 'm': guardar_ajustes(); msg = "Guardado en ajustes.cfg"; break;
            case '0': aj_.restaurar(); msg = "Todo como venia (M para guardar)"; cambio = true; break;
            case '9': case 8: case 9: siguiente_ = menu_.get(); msg = "Menu"; break;
            default: break;
        }
        if (cambio) ajustes_cambiados();
        if (!msg.empty()) {
            log("Ajuste: %s", msg.c_str());
            aviso(msg);
        }
    }
}

// ====================================================================== ventana SSH
Resumen App::resumen() {
    std::lock_guard<std::mutex> lk(mtx_resumen_);
    return resumen_;
}

void App::hilo_vista() {
    bool creada = false;
    while (vista_viva_ && g_vivo) {
        try {
            VistaVision v;
            vis_.copiar_vista(v);
            cv::Mat out;
            dibujar_vista(out, resumen(), v);
            if (!creada) {
                cv::namedWindow(VENTANA_SSH, cv::WINDOW_NORMAL | cv::WINDOW_GUI_NORMAL);
                cv::resizeWindow(VENTANA_SSH, out.cols, out.rows);
                creada = true;
            }
            cv::imshow(VENTANA_SSH, out);
            int k = cv::waitKey(200) & 0xFF;      // tambien marca el ritmo (~4 por segundo)
            if (k != 255) tecla(k);
        } catch (const std::exception& e) {
            log("Ventana SSH desactivada (%s)", e.what());
            break;
        }
    }
    if (creada) {
        try { cv::destroyWindow(VENTANA_SSH); cv::waitKey(1); } catch (...) {}
    }
}

static void letrero(cv::Mat& img, const std::string& s, int x, int y, double esc = 0.45,
                    cv::Scalar col = cv::Scalar(230, 230, 230)) {
    cv::putText(img, s, cv::Point(x, y), cv::FONT_HERSHEY_SIMPLEX, esc, col, 1, cv::LINE_AA);
}

void App::dibujar_vista(cv::Mat& out, const Resumen& r, const VistaVision& v) {
    const int ancho = 560;
    cv::Mat izq;
    float k = 1;
    cv::Point2f off(0, 0);
    bool detector = r.vista == 0 && !v.detector.empty() && v.roi.width > 0;
    if (detector) {
        izq = v.detector.clone();
        k = ancho / (float)v.roi.width;
        off = cv::Point2f((float)v.roi.x, (float)v.roi.y);
    } else if (!v.camara.empty() && v.cam_w > 0) {
        izq = v.camara.clone();
        k = ancho / (float)v.cam_w;
        cv::rectangle(izq, cv::Rect(cv::Point2f(v.roi.x * k, v.roi.y * k), cv::Point2f(v.roi.br()) * k), ui::AMARILLO, 1);
        std::vector<cv::Point> c;
        for (auto& p : r.contorno_cam) c.push_back(cv::Point(p * k));
        if (c.size() == 4) cv::polylines(izq, c, true, ui::VERDE, 2, cv::LINE_AA);
    } else {
        izq = cv::Mat(420, ancho, CV_8UC3, cv::Scalar(20, 20, 20));
        letrero(izq, "Sin imagen de camara todavia", 150, 210, 0.6, ui::GRIS);
    }
    for (const auto& m : v.manos) {
        auto P = [&](int i) { return cv::Point((m.p[i] - off) * k); };
        for (int i = 0; i < 21; i++)
            if (m.ok[i]) cv::circle(izq, P(i), (i >= 1 && i <= 8) ? 4 : 2, (i >= 1 && i <= 8) ? ui::BLANCO : ui::GRIS, -1, cv::LINE_AA);
        for (int i = 1; i < 4; i++)
            if (m.ok[i] && m.ok[i + 1]) cv::line(izq, P(i), P(i + 1), ui::NARANJA, 2, cv::LINE_AA);
        for (int i = 5; i < 8; i++)
            if (m.ok[i] && m.ok[i + 1]) cv::line(izq, P(i), P(i + 1), ui::CIAN, 2, cv::LINE_AA);
        if (m.ok[4] && m.ok[8]) cv::line(izq, P(4), P(8), ui::ROJO, 1, cv::LINE_AA);
    }
    ui::texto(izq, detector ? "DETECTOR (B cambia)" : "CAMARA (B cambia)", 8, 22, 0.55, ui::AMARILLO, false, 1);

    const int alto = std::max(izq.rows, 560);
    cv::Mat p(alto, 340, CV_8UC3, cv::Scalar(28, 28, 28));
    int y = 22;
    letrero(p, r.modo + " | manos " + std::to_string(r.manos.size()), 10, y, 0.5, ui::AMARILLO);
    y += 20;
    letrero(p, cv::format("vision %.1f FPS (%.0f ms) | dibujo %.0f FPS", r.fps_vision, r.ms_detector, r.fps_dibujo), 10, y, 0.42);
    y += 18;
    letrero(p, cv::format("camara %.0f FPS | latencia ~%.0f ms | luz %.0f", r.fps_camara, r.latencia_ms, r.luz), 10, y, 0.42);
    y += 18;
    std::string det = r.detector_listo ? "detector: " + r.detector
                                       : (r.error_detector.empty() ? "cargando detector..." : "ERROR: " + r.error_detector);
    letrero(p, det.substr(0, 48), 10, y, 0.4, r.detector_listo ? ui::GRIS : ui::ROJO);
    y += 22;
    const Ajustes& a = r.aj;
    struct Fila { const char* t; std::string txt; };
    std::vector<Fila> filas = {
        {"Q/A", "Exposicion: " + r.expo}, {"W/S", "Ganancia: " + r.ganancia}, {"E/D", "Brillo: " + r.brillo},
        {"R/F", "Contraste: " + r.contraste}, {"T/G", cv::format("Gamma: %.1f", a.gamma)},
        {"Y/H", cv::format("CLAHE: %.1f", a.clahe)}, {"U/J", cv::format("Saturacion: %.1f", a.saturacion)},
        {"I/K", cv::format("Suavizado: %d", a.suavizado)}, {"O/L", std::string("Recorte: ") + (a.recorte ? "SI" : "NO")},
        {"P/N", cv::format("Umbral: %.3f", a.umbral)}, {"X/Z", cv::format("Puntos min: %d", a.min_puntos)},
        {"V/C", cv::format("Relleno: %d", a.relleno)}};
    for (const auto& f : filas) {
        letrero(p, f.t, 10, y, 0.48, cv::Scalar(0, 200, 255));
        letrero(p, f.txt, 60, y, 0.45);
        y += 21;
    }
    y += 4;
    letrero(p, "1 expo auto  2 autocal manos  3 recalibrar", 10, y, 0.42, ui::GRIS);
    y += 18;
    letrero(p, std::string("4 auto-expo: ") + (a.auto_exposicion ? "SI" : "NO") + "  B vista  M guardar", 10, y, 0.42, ui::GRIS);
    y += 18;
    letrero(p, "0 restaurar  9 menu   (clic aqui y teclas)", 10, y, 0.42, ui::GRIS);
    y += 22;
    if (ahora() - r.t_aviso < 4 && !r.aviso.empty()) letrero(p, r.aviso.substr(0, 40), 10, y, 0.47, ui::VERDE2);
    y += 24;
    cv::line(p, cv::Point(10, y - 14), cv::Point(330, y - 14), cv::Scalar(70, 70, 70), 1);
    for (size_t i = 0; i < r.manos.size() && i < 2; i++) {
        const ManoUI& m = r.manos[i];
        letrero(p, cv::format("Mano %d: %s", (int)i + 1, m.cerrada ? "CERRADA (clic)" : "ABIERTA"), 10, y, 0.5,
                m.cerrada ? ui::ROJO : ui::VERDE2);
        ui::barra(p, cv::Rect(200, y - 11, 130, 12), 1.0f - std::min(1.0f, m.apertura), m.cerrada ? ui::ROJO : ui::CIAN);
        y += 22;
    }
    if (r.manos.empty()) letrero(p, "Sin manos", 10, y, 0.5, ui::GRIS);
    if (izq.rows < alto) cv::copyMakeBorder(izq, izq, 0, alto - izq.rows, 0, 0, cv::BORDER_CONSTANT, cv::Scalar(0, 0, 0));
    cv::hconcat(izq, p, out);
}

}  // namespace est
