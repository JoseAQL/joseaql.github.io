// camara.hpp - captura en un hilo propio (siempre el cuadro mas nuevo, sin cola que atrase)
// y controles V4L2 (exposicion, ganancia, brillo, contraste...) por ioctl directo.
#pragma once

#include <atomic>
#include <condition_variable>
#include <map>
#include <mutex>
#include <string>
#include <thread>

#include <opencv2/core.hpp>
#include <opencv2/videoio.hpp>

namespace est {

class Camara {
public:
    ~Camara() { cerrar(); }
    // fuente: "0", "1", "/dev/video0" o "sim" (camara simulada para probar en la PC)
    bool abrir(const std::string& fuente, int ancho, int alto, int fps);
    void cerrar();
    // Espera un cuadro mas nuevo que 'id' (hasta timeout). Copia el cuadro y su hora de captura.
    bool esperar(uint64_t& id, cv::Mat& out, double& t_captura, double timeout = 0.25);
    int ancho() const { return w_; }
    int alto() const { return h_; }
    float fps_real() const { return fps_real_; }
    const std::string& dispositivo() const { return dev_; }
    bool simulada() const { return sim_; }

private:
    void hilo();
    cv::VideoCapture cap_;
    std::thread th_;
    std::mutex mtx_;
    std::condition_variable cv_;
    cv::Mat cuadro_;
    uint64_t id_ = 0;
    double t_ = 0;
    std::atomic<bool> vivo_{false};
    int w_ = 0, h_ = 0, fps_ = 30;
    std::atomic<float> fps_real_{0};
    std::string dev_;
    bool sim_ = false;
};

// Controles de la camara (como v4l2-ctl, pero directo y rapido).
class ControlesV4L2 {
public:
    struct Info {
        bool existe = false;
        int min = 0, max = 0, paso = 1, defecto = 0, valor = 0;
    };
    ~ControlesV4L2() { cerrar(); }
    bool abrir(const std::string& dispositivo);   // "/dev/video0" o "sim"
    void cerrar();
    Info info(const std::string& nombre);
    bool poner(const std::string& nombre, int valor);
    bool leer(const std::string& nombre, int& valor);
    // aplica primero los modos automaticos (exposure_auto...) y luego los valores
    void aplicar(const std::map<std::string, int>& ctrl);
    // exposicion automatica y ganancia de fabrica (para calibrar el proyector)
    void modo_calibracion();

private:
    int fd_ = -1;
    bool sim_ = false;
};

// ------------------------------------------------------------------ simulador (pruebas en la PC)
namespace sim {
void poner_render(const cv::Mat& bgr);                  // la app avisa que dibujo un cuadro
cv::Mat cuadro_camara(int w, int h);                     // lo que "veria" la camara
cv::Matx33d render_a_camara(int rw, int rh, int cw, int ch);
bool objetivo(float& x, float& y, std::string& forma);   // /tmp/fake_objetivo.json (coordenadas de dibujo)
float calidad_por_exposicion();                          // 0..1: que tan bien se ve la mano con la exposicion simulada
std::map<std::string, int>& controles();
std::mutex& mtx();
}  // namespace sim

}  // namespace est
