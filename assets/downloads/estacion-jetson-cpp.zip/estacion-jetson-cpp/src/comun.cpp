#include "comun.hpp"

#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <ctime>
#include <mutex>
#include <unistd.h>

namespace est {

std::atomic<bool> g_vivo(true);

double ahora() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

static std::mutex g_log_mtx;

void log(const char* fmt, ...) {
    char msg[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);
    std::time_t t = std::time(nullptr);
    char hora[16];
    std::strftime(hora, sizeof(hora), "%H:%M:%S", std::localtime(&t));
    std::lock_guard<std::mutex> lk(g_log_mtx);
    std::fprintf(stderr, "[%s] %s\n", hora, msg);
    std::fflush(stderr);
}

std::string fecha_hora() {
    std::time_t t = std::time(nullptr);
    char b[32];
    std::strftime(b, sizeof(b), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
    return b;
}

std::string carpeta_programa() {
    char ruta[4096];
    ssize_t n = readlink("/proc/self/exe", ruta, sizeof(ruta) - 1);
    if (n <= 0) return ".";
    ruta[n] = 0;
    std::string s(ruta);
    s = s.substr(0, s.find_last_of('/'));
    if (s.size() >= 6 && s.substr(s.size() - 6) == "/build") s = s.substr(0, s.size() - 6);
    return s;
}

// ------------------------------------------------------------------ completar puntos
static const int CADENAS[5][5] = {{0, 1, 2, 3, 4}, {0, 5, 6, 7, 8}, {0, 9, 10, 11, 12},
                                  {0, 13, 14, 15, 16}, {0, 17, 18, 19, 20}};

bool completar_mano(ManoCruda& m) {
    // muneca: promedio de las bases que se vean
    if (!m.ok[0]) {
        cv::Point2f s(0, 0);
        int n = 0;
        for (int i : {1, 5, 9, 13, 17})
            if (m.ok[i]) { s += m.p[i]; n++; }
        if (n == 0) {
            // sin bases: si al menos hay pulgar e indice, usa el centro de sus puntos
            for (int i = 1; i <= 8; i++)
                if (m.ok[i]) { s += m.p[i]; n++; }
            if (n == 0) return false;
        }
        m.p[0] = s * (1.0f / n);
        m.ok[0] = true;
    }
    for (const auto& cad : CADENAS) {
        for (int k = 1; k < 5; k++) {
            int i = cad[k];
            if (m.ok[i]) continue;
            int antes = -1, despues = -1, antes2 = -1;
            for (int j = k - 1; j >= 0; j--)
                if (m.ok[cad[j]]) { if (antes < 0) antes = j; else { antes2 = j; break; } }
            for (int j = k + 1; j < 5; j++)
                if (m.ok[cad[j]]) { despues = j; break; }
            if (antes >= 0 && despues >= 0) {
                float f = float(k - antes) / float(despues - antes);
                m.p[i] = m.p[cad[antes]] * (1 - f) + m.p[cad[despues]] * f;
            } else if (antes >= 0 && antes2 >= 0) {          // sigue la direccion del dedo
                cv::Point2f paso = (m.p[cad[antes]] - m.p[cad[antes2]]) * (1.0f / float(antes - antes2));
                m.p[i] = m.p[cad[antes]] + paso * float(k - antes);
            } else if (antes >= 0) {
                m.p[i] = m.p[cad[antes]];
            } else {
                continue;
            }
            m.ok[i] = true;
        }
    }
    // para la estacion basta con pulgar e indice completos
    for (int i = 1; i <= 8; i++)
        if (!m.ok[i]) return false;
    return true;
}

// ------------------------------------------------------------------ One Euro
double FiltroEuro::filtrar(double x, double t) {
    if (!listo_) {
        x_ = x; dx_ = 0; t_ = t; listo_ = true;
        return x;
    }
    double dt = t - t_;
    if (dt <= 1e-4) dt = 1e-4;
    t_ = t;
    double dx = (x - x_) / dt;
    double ad = alfa(dt, dcorte_);
    dx_ = ad * dx + (1 - ad) * dx_;
    double corte = fmin_ + beta_ * std::fabs(dx_);
    double a = alfa(dt, corte);
    x_ = a * x + (1 - a) * x_;
    return x_;
}

}  // namespace est
