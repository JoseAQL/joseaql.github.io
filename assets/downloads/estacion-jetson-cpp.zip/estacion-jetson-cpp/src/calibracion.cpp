#include "calibracion.hpp"

#include <unistd.h>

#include <algorithm>
#include <fstream>
#include <regex>
#include <sstream>

#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>

#include "comun.hpp"

namespace est {

// ====================================================================== utilidades
cv::Matx33d Calibracion::escalada(int cw, int ch, int rw, int rh) const {
    cv::Matx33d Sc(cam_w / (double)cw, 0, 0, 0, cam_h / (double)ch, 0, 0, 0, 1);   // camara nueva -> vieja
    cv::Matx33d Sr(rw / (double)w, 0, 0, 0, rh / (double)h, 0, 0, 0, 1);             // dibujo viejo -> nuevo
    return Sr * H * Sc;
}

cv::Rect Calibracion::zona_camara(int cw, int ch, int rw, int rh, float margen) const {
    cv::Matx33d Hi = escalada(cw, ch, rw, rh).inv();
    std::vector<cv::Point2f> esq = {{0, 0}, {(float)rw, 0}, {(float)rw, (float)rh}, {0, (float)rh}}, cam;
    cv::perspectiveTransform(esq, cam, Hi);
    cv::Rect r = cv::boundingRect(cam);
    int mx = (int)(r.width * margen), my = (int)(r.height * margen);
    r.x -= mx; r.y -= my; r.width += 2 * mx; r.height += 2 * my;
    return r & cv::Rect(0, 0, cw, ch);
}

bool guardar_calibracion(const std::string& ruta, const Calibracion& c) {
    std::ofstream f(ruta);
    if (!f) return false;
    f.precision(12);
    f << "# calibracion camara -> proyeccion (estacion C++)\n";
    f << "fecha = " << c.fecha << "\norigen = " << c.origen << "\n";
    f << "cam = " << c.cam_w << " " << c.cam_h << "\ndibujo = " << c.w << " " << c.h << "\n";
    f << "error = " << c.error << "\npuntos = " << c.puntos << "\nH =";
    for (int i = 0; i < 9; i++) f << " " << c.H.val[i];
    f << "\n";
    return true;
}

bool cargar_calibracion(const std::string& ruta, Calibracion& c) {
    std::ifstream f(ruta);
    if (!f) return false;
    std::string linea;
    int leidos = 0;
    while (std::getline(f, linea)) {
        size_t e = linea.find('=');
        if (e == std::string::npos || linea[0] == '#') continue;
        std::string k = linea.substr(0, e);
        k.erase(k.find_last_not_of(" ") + 1);
        std::istringstream v(linea.substr(e + 1));
        if (k == "cam") { v >> c.cam_w >> c.cam_h; leidos++; }
        else if (k == "dibujo") { v >> c.w >> c.h; leidos++; }
        else if (k == "error") v >> c.error;
        else if (k == "puntos") v >> c.puntos;
        else if (k == "fecha") { std::getline(v, c.fecha); }
        else if (k == "origen") { std::getline(v, c.origen); }
        else if (k == "H") { for (int i = 0; i < 9; i++) v >> c.H.val[i]; if (v) leidos++; }
    }
    c.ok = leidos == 3 && c.cam_w > 0 && c.w > 0;
    return c.ok;
}

// calib_hdmi.json de la version Python: {"H": [[..],[..],[..]], "hdmi": [w, h], "cam": [cw, ch], ...}
bool importar_calibracion_python(const std::string& ruta_json, Calibracion& c) {
    std::ifstream f(ruta_json);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    std::string s = ss.str();
    auto numeros = [&](const std::string& clave) {
        std::vector<double> r;
        size_t a = s.find("\"" + clave + "\"");
        if (a == std::string::npos) return r;
        size_t i = s.find('[', a);
        int nivel = 0;
        size_t j = i;
        for (; j < s.size(); j++) {
            if (s[j] == '[') nivel++;
            else if (s[j] == ']' && --nivel == 0) break;
        }
        std::string t = s.substr(i, j - i + 1);
        std::regex num("-?[0-9]+(\\.[0-9]+)?([eE][-+]?[0-9]+)?");
        for (std::sregex_iterator it(t.begin(), t.end(), num), fin; it != fin; ++it) r.push_back(std::stod(it->str()));
        return r;
    };
    std::vector<double> H = numeros("H"), hd = numeros("hdmi"), cam = numeros("cam");
    if (H.size() != 9 || hd.size() != 2) return false;
    for (int i = 0; i < 9; i++) c.H.val[i] = H[i];
    c.w = (int)hd[0]; c.h = (int)hd[1];
    c.cam_w = cam.size() == 2 ? (int)cam[0] : 1280;
    c.cam_h = cam.size() == 2 ? (int)cam[1] : 720;
    c.origen = "python (" + ruta_json + ")";
    c.fecha = "?";
    c.ok = true;
    return true;
}

// ====================================================================== calibracion por puntos
struct Mancha {
    cv::Point2f c;
    double peso;
};

// manchas brillantes en la diferencia (patron - negro)
static std::vector<Mancha> buscar_manchas(const cv::Mat& dif32) {
    std::vector<Mancha> r;
    cv::Mat d;
    dif32.convertTo(d, CV_8U);               // lo negativo queda en 0
    cv::GaussianBlur(d, d, cv::Size(5, 5), 0);
    double mx;
    cv::minMaxLoc(d, nullptr, &mx);
    if (mx < 18) return r;                    // no se ve nada
    cv::Mat bin;
    cv::threshold(d, bin, std::max(12.0, mx * 0.35), 255, cv::THRESH_BINARY);
    cv::morphologyEx(bin, bin, cv::MORPH_OPEN, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3, 3)));
    cv::Mat lab, est, cen;
    int n = cv::connectedComponentsWithStats(bin, lab, est, cen, 8, CV_32S);
    const double area_max = 0.02 * d.total();
    for (int i = 1; i < n; i++) {
        int area = est.at<int>(i, cv::CC_STAT_AREA);
        if (area < 5 || area > area_max) continue;
        cv::Rect bb(est.at<int>(i, cv::CC_STAT_LEFT), est.at<int>(i, cv::CC_STAT_TOP),
                    est.at<int>(i, cv::CC_STAT_WIDTH), est.at<int>(i, cv::CC_STAT_HEIGHT));
        double sx = 0, sy = 0, s = 0;            // centro pesado por brillo (precision subpixel)
        for (int y = bb.y; y < bb.y + bb.height; y++) {
            const int* l = lab.ptr<int>(y);
            const uchar* v = d.ptr<uchar>(y);
            for (int x = bb.x; x < bb.x + bb.width; x++)
                if (l[x] == i) { sx += x * (double)v[x]; sy += y * (double)v[x]; s += v[x]; }
        }
        if (s <= 0) continue;
        r.push_back({cv::Point2f((float)(sx / s), (float)(sy / s)), s});
    }
    std::sort(r.begin(), r.end(), [](const Mancha& a, const Mancha& b) { return a.peso > b.peso; });
    return r;
}

cv::Mat Calibrador::capturar(const cv::Mat& patron, double espera, int n) {
    mostrar_(patron);
    double t0 = ahora();
    usleep((useconds_t)(espera * 1e6));
    cv::Mat suma, f, g;
    uint64_t id = 0;
    int tomados = 0;
    double t;
    while (tomados < n && ahora() - t0 < espera + 3.0) {
        if (!cam_.esperar(id, f, t, 0.5)) continue;
        if (t < t0 + espera * 0.8) continue;       // cuadros tomados antes de que cambiara la proyeccion
        cv::cvtColor(f, g, cv::COLOR_BGR2GRAY);
        if (suma.empty()) suma = cv::Mat::zeros(g.size(), CV_32F);
        cv::accumulate(g, suma);
        tomados++;
    }
    if (tomados > 0) suma /= tomados;
    return suma;
}

bool Calibrador::correr(Calibracion& out) {
    detalle.clear();
    ctl_.modo_calibracion();                       // exposicion automatica: con la de manos el blanco se quema
    const int R = std::max(8, (int)(h_ * 0.045));
    cv::Mat negro(h_, w_, CV_8UC3, cv::Scalar(0, 0, 0));
    capturar(negro, 1.0, 1);                       // deja que la camara se acomode
    cv::Mat fondo = capturar(negro, 0.3, 3);
    if (fondo.empty()) { detalle = "la camara no entrega imagen"; return false; }

    const float insets[] = {0.08f, 0.15f, 0.22f};
    for (float in : insets) {
        // --- etapa A: 4 puntos en las esquinas
        float x0 = w_ * in, y0 = h_ * in, x1 = w_ * (1 - in), y1 = h_ * (1 - in);
        std::vector<cv::Point2f> dib4 = {{x0, y0}, {x1, y0}, {x1, y1}, {x0, y1}};
        cv::Mat p4 = negro.clone();
        for (auto& p : dib4) cv::circle(p4, p, R, cv::Scalar(255, 255, 255), -1, cv::LINE_AA);
        cv::Mat c4 = capturar(p4, 0.6, 3);
        if (c4.empty()) continue;
        std::vector<Mancha> m4 = buscar_manchas(c4 - fondo);
        detalle += cv::format("margen %.0f%%: %d manchas; ", in * 100, (int)m4.size());
        if (m4.size() < 4) continue;
        m4.resize(4);
        // ordenar: arriba-izq = menor x+y, abajo-der = mayor x+y, arriba-der = mayor x-y, abajo-izq = menor x-y
        std::vector<cv::Point2f> cam4(4);
        auto por = [&](std::function<float(const cv::Point2f&)> f, bool mayor) {
            int k = 0;
            for (int i = 1; i < 4; i++)
                if (mayor ? f(m4[i].c) > f(m4[k].c) : f(m4[i].c) < f(m4[k].c)) k = i;
            return m4[k].c;
        };
        cam4[0] = por([](const cv::Point2f& p) { return p.x + p.y; }, false);
        cam4[2] = por([](const cv::Point2f& p) { return p.x + p.y; }, true);
        cam4[1] = por([](const cv::Point2f& p) { return p.x - p.y; }, true);
        cam4[3] = por([](const cv::Point2f& p) { return p.x - p.y; }, false);
        bool distintos = true;
        for (int i = 0; i < 4; i++)
            for (int j = i + 1; j < 4; j++)
                if (dist(cam4[i], cam4[j]) < 4) distintos = false;
        if (!distintos) { detalle += "esquinas repetidas; "; continue; }
        cv::Mat Ha = cv::getPerspectiveTransform(cam4, dib4);
        cv::Matx33d HA((double*)Ha.ptr());

        // --- etapa B: rejilla de 5x4 puntos para afinar
        const int C = 5, F = 4;
        std::vector<cv::Point2f> dibg;
        for (int f = 0; f < F; f++)
            for (int c = 0; c < C; c++)
                dibg.push_back({x0 + (x1 - x0) * c / (C - 1), y0 + (y1 - y0) * f / (F - 1)});
        cv::Mat pg = negro.clone();
        int R2 = std::max(6, (int)(R * 0.7));
        for (auto& p : dibg) cv::circle(pg, p, R2, cv::Scalar(255, 255, 255), -1, cv::LINE_AA);
        cv::Mat cg = capturar(pg, 0.5, 3);
        std::vector<Mancha> mg = cg.empty() ? std::vector<Mancha>() : buscar_manchas(cg - fondo);
        std::vector<cv::Point2f> pred;
        cv::perspectiveTransform(dibg, pred, HA.inv());
        float sep = 1e9f;                                  // separacion entre puntos vecinos en la camara
        for (int i = 0; i + 1 < (int)pred.size(); i++)
            if ((i + 1) % C) sep = std::min(sep, dist(pred[i], pred[i + 1]));
        std::vector<cv::Point2f> cam_ok, dib_ok;
        for (size_t i = 0; i < pred.size(); i++) {
            int k = -1;
            float dmin = sep * 0.4f;
            for (size_t j = 0; j < mg.size(); j++) {
                float d = dist(pred[i], mg[j].c);
                if (d < dmin) { dmin = d; k = (int)j; }
            }
            if (k >= 0) { cam_ok.push_back(mg[k].c); dib_ok.push_back(dibg[i]); }
        }
        cv::Matx33d H = HA;
        double err = 99;
        int usados = 0;
        if (cam_ok.size() >= 8) {
            cv::Mat mask;
            cv::Mat Hb = cv::findHomography(cam_ok, dib_ok, cv::RANSAC, 4.0, mask);
            if (!Hb.empty()) {
                H = cv::Matx33d((double*)Hb.ptr());
                std::vector<cv::Point2f> proy;
                cv::perspectiveTransform(cam_ok, proy, H);
                usados = 0;
                err = 0;
                for (size_t i = 0; i < proy.size(); i++)
                    if (mask.at<uchar>((int)i)) { err += dist(proy[i], dib_ok[i]); usados++; }
                err = usados ? err / usados : 99;
            }
        }
        detalle += cv::format("rejilla %d/%d puntos (%d buenos), error %.2f px; ", (int)cam_ok.size(), C * F, usados, err);
        if (usados < 8 || err > 8.0) continue;     // solo se acepta si la rejilla confirma (no un reflejo)
        out.H = H;
        out.cam_w = cam_.ancho();
        out.cam_h = cam_.alto();
        out.w = w_;
        out.h = h_;
        out.error = err;
        out.puntos = usados;
        out.fecha = fecha_hora();
        out.origen = "puntos";
        out.ok = true;
        mostrar_(negro);
        return true;
    }
    mostrar_(negro);
    return false;
}

}  // namespace est
