// ui.hpp - dibujo con OpenCV (texto con borde, tarjetas estilo consola, cursor) y botones que se
// activan con la punta del indice: pellizco (pulgar+indice) = clic inmediato, o dejar el dedo encima.
#pragma once

#include <string>
#include <vector>

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

#include "manos.hpp"

namespace est {
namespace ui {

// colores BGR
const cv::Scalar BLANCO(240, 240, 240), GRIS(130, 130, 130), GRIS_OSC(55, 55, 55), NEGRO(0, 0, 0);
const cv::Scalar VERDE(60, 200, 60), VERDE2(120, 255, 140), AMARILLO(0, 220, 255), CIAN(230, 220, 60);
const cv::Scalar ROJO(70, 70, 230), MAGENTA(230, 70, 220), NARANJA(40, 150, 255), AZUL(240, 140, 40);

int texto(cv::Mat& img, const std::string& s, float x, float y, double esc, const cv::Scalar& col,
          bool centrado = false, int grosor = 2);
void fondo(cv::Mat& img);                                   // degradado oscuro + cuadricula tenue
void cursor(cv::Mat& img, const ManoUI& m, double t, float progreso = 0);
void manos_dedos(cv::Mat& img, const std::vector<ManoUI>& manos, bool detalle);   // pulgar e indice
void barra(cv::Mat& img, cv::Rect r, float v, const cv::Scalar& col);
void borde_progreso(cv::Mat& img, cv::Rect r, float t, const cv::Scalar& col, int grosor = 4);

// Boton que se activa con la mano: pellizco encima (inmediato) o dedo encima 'dwell' segundos.
class Boton {
public:
    Boton() {}
    Boton(cv::Rect r, std::string etiqueta, std::string sub = "") : rect(r), etiqueta(etiqueta), sub(sub) {}
    // regresa true en el cuadro en que se activa
    bool actualizar(const std::vector<ManoUI>& manos, double t, double dwell);
    void dibujar(cv::Mat& img, double t, double dwell, double esc = 0.7) const;
    void reiniciar() { t_encima_ = -1; bloqueado_ = true; }
    float progreso(double t, double dwell) const;
    bool encima() const { return t_encima_ >= 0; }

    cv::Rect rect;
    std::string etiqueta, sub;

private:
    double t_encima_ = -1, t_visto_ = -1, t_flash_ = -1;
    bool bloqueado_ = false;           // tras activarse: hay que salir del boton para volver a activarlo
};

}  // namespace ui
}  // namespace est
