// detector.hpp - detectores de mano (21 puntos). Todos regresan puntos en pixeles de la imagen recibida.
//
//   posenet : jetson-inference poseNet "resnet18-hand" en C++ (GPU, TensorRT). El mas rapido.
//   python  : el mismo poseNet (o MediaPipe en una PC) llamado desde C++ con la API de Python,
//             como en los juegos del Kinect. Solo los landmarks salen de Python.
//   sim     : mano simulada (pruebas en la PC)
//   ninguno : sin manos
#pragma once

#include <memory>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

#include "comun.hpp"

namespace est {

class Detector {
public:
    virtual ~Detector() {}
    virtual const char* nombre() const = 0;
    // bgr: imagen (normalmente el recorte de la zona proyectada). origen: donde empieza ese recorte
    // dentro del cuadro completo de la camara (solo lo usa el simulador).
    virtual bool procesar(const cv::Mat& bgr, cv::Point origen, std::vector<ManoCruda>& manos) = 0;
    virtual void set_umbral(float) {}
};

// motor: auto | posenet | python | sim | ninguno. Si falla regresa nullptr y explica en 'error'.
std::unique_ptr<Detector> crear_detector(const std::string& motor, float umbral, std::string& error);
std::string motores_compilados();

}  // namespace est
