#include "ajustes.hpp"

#include <fstream>
#include <regex>
#include <sstream>

#include "comun.hpp"

namespace est {

static std::string recortar(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

bool Ajustes::cargar(const std::string& ruta) {
    std::ifstream f(ruta);
    if (!f) return false;
    std::string linea;
    while (std::getline(f, linea)) {
        size_t h = linea.find('#');
        if (h != std::string::npos) linea = linea.substr(0, h);
        size_t e = linea.find('=');
        if (e == std::string::npos) continue;
        std::string k = recortar(linea.substr(0, e)), v = recortar(linea.substr(e + 1));
        if (k.empty() || v.empty()) continue;
        try {
            if (k.compare(0, 4, "cam.") == 0) ctrl[k.substr(4)] = std::stoi(v);
            else if (k == "gamma") gamma = std::stof(v);
            else if (k == "clahe") clahe = std::stof(v);
            else if (k == "saturacion") saturacion = std::stof(v);
            else if (k == "suavizado") suavizado = std::stoi(v);
            else if (k == "recorte") recorte = std::stoi(v) != 0;
            else if (k == "umbral") umbral = std::stof(v);
            else if (k == "min_puntos") min_puntos = std::stoi(v);
            else if (k == "relleno") relleno = std::stoi(v);
            else if (k == "pinza_cerrar") pinza_cerrar = std::stof(v);
            else if (k == "pinza_abrir") pinza_abrir = std::stof(v);
            else if (k == "dwell_ms") dwell_ms = std::stoi(v);
            else if (k == "prediccion_ms") prediccion_ms = std::stoi(v);
            else if (k == "auto_exposicion") auto_exposicion = std::stoi(v) != 0;
            else if (k == "luz_objetivo") luz_objetivo = std::stoi(v);
        } catch (...) {
            log("ajustes: valor raro en '%s'", linea.c_str());
        }
    }
    return true;
}

bool Ajustes::guardar(const std::string& ruta) const {
    std::ofstream f(ruta);
    if (!f) return false;
    f << "# Ajustes de la estacion C++ (se guardan solos al salir o con la tecla M)\n";
    f << "# camara (controles V4L2)\n";
    for (const auto& kv : ctrl) f << "cam." << kv.first << " = " << kv.second << "\n";
    f << "# imagen para el detector\n";
    f << "gamma = " << gamma << "\nclahe = " << clahe << "\nsaturacion = " << saturacion << "\n";
    f << "suavizado = " << suavizado << "\nrecorte = " << (recorte ? 1 : 0) << "\n";
    f << "# detector\numbral = " << umbral << "\nmin_puntos = " << min_puntos << "\n";
    f << "# proyeccion\nrelleno = " << relleno << "\n";
    f << "# gestos pulgar-indice\npinza_cerrar = " << pinza_cerrar << "\npinza_abrir = " << pinza_abrir
      << "\ndwell_ms = " << dwell_ms << "\nprediccion_ms = " << prediccion_ms << "\n";
    f << "# auto-exposicion continua\nauto_exposicion = " << (auto_exposicion ? 1 : 0)
      << "\nluz_objetivo = " << luz_objetivo << "\n";
    return true;
}

void Ajustes::restaurar() {
    Ajustes d;
    std::map<std::string, int> c = ctrl;
    *this = d;
    ctrl = c;
}

// filtros.json de la version Python, por ejemplo:
// {"camara":{"exposure_auto":1,"exposure_absolute":1182,"gain":12},"gamma":1.0,...,"relleno":30}
bool Ajustes::importar_filtros_json(const std::string& ruta) {
    std::ifstream f(ruta);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    std::string s = ss.str();
    std::regex num("\"(\\w+)\"\\s*:\\s*(-?[0-9]+(\\.[0-9]+)?)");
    size_t a = s.find("\"camara\"");
    std::string cam, resto = s;
    if (a != std::string::npos) {
        size_t i = s.find('{', a), j = s.find('}', a);
        if (i != std::string::npos && j != std::string::npos && j > i) {
            cam = s.substr(i, j - i + 1);
            resto = s.substr(0, a) + s.substr(j + 1);
        }
    }
    for (std::sregex_iterator it(cam.begin(), cam.end(), num), fin; it != fin; ++it)
        ctrl[(*it)[1]] = (int)std::lround(std::stod((*it)[2]));
    for (std::sregex_iterator it(resto.begin(), resto.end(), num), fin; it != fin; ++it) {
        std::string k = (*it)[1];
        double v = std::stod((*it)[2]);
        if (k == "gamma") gamma = (float)v;
        else if (k == "clahe") clahe = (float)v;
        else if (k == "saturacion") saturacion = (float)v;
        else if (k == "suavizado") suavizado = (int)v;
        else if (k == "umbral") umbral = (float)v;   // "recorte" no se importa: aqui va prendido
        else if (k == "min_puntos") min_puntos = (int)v;
        else if (k == "relleno") relleno = (int)v;
    }
    return true;
}

}  // namespace est
