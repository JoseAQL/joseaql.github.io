# TallerCNC


Software **libre (GPL-3.0) y 100 % offline** para diseñar, proyectar y cortar con láser o fresadora GRBL.
Sin cuenta, sin internet y sin suscripción. Funciona en Windows 10, Windows 11 y Linux.

![Plantillas paramétricas](imagenes/plantillas.png)

| PCB desde Gerber | Grabado de imagen y G-code |
|---|---|
| ![](imagenes/pcb.png) | ![](imagenes/corte.png) |

| Juegos de mesa | Control de la máquina y flasheo de GRBL |
|---|---|
| ![](imagenes/juegos.png) | ![](imagenes/control.png) |

Todos los modelos incluidos: ![](imagenes/catalogo.png)

## Descargar

1. Pestaña **Actions** del repositorio > **TallerCNC** > la ejecución más reciente con palomita verde.
2. En **Artifacts**:
   - **TallerCNC-Windows**: instalador (`Setup`) y versión **portable** que no se instala.
   - **TallerCNC-Linux**: el `.AppImage`. Dale permiso de ejecución (`chmod +x`) y ábrelo.

Sin descargar nada: abre `index.html` en Edge o Chrome (o usa `Abrir TallerCNC (navegador).bat`).

## Cómo abrirlo

| Opción | Qué hacer |
| --- | --- |
| App de Windows | Instala con el `Setup` o abre el `.exe` portable (no necesita instalar). Es un programa sin firma: si Windows avisa, “Más información” → “Ejecutar de todas formas”. |
| App de Linux | `chmod +x TallerCNC-*.AppImage` y ábrelo. Para el USB: `sudo usermod -aG dialout $USER` y reinicia sesión. |
| Sin instalar nada | Doble clic en `Abrir TallerCNC (navegador).bat` (Windows) o `abrir_tallercnc_linux.sh`. Necesita Edge o Chrome para usar el puerto USB. |
| Construir tú mismo | Instala Node.js 18+ y ejecuta `escritorio/construir_windows.bat` o `escritorio/construir_linux.sh`. |

## Qué hace

- **Plantillas paramétricas** (25 modelos): caja con lengüetas (ECMA A20), caja de envío FEFCO 0201, caja de regalo con tapa, charola, caja de cerillos, caja almohada, cajas poligonales de 3 a 12 lados, pirámides, sólidos platónicos y caja de madera con uniones dentadas (con kerf).
  - **PRO con mecanismo:** cubo pop-up con liga, caja sorpresa que se abre en 4 lados y funda de tarjeta con jalador.
  - **Juegos de mesa:** tablero de ajedrez/damas, piezas de ajedrez de perfil con base, molino, gato, mancala, go, dominó, tangram y laberinto.
  - **Origami:** Miura-ori, Yoshimura (lámpara plegable) y caja masu. El láser solo marca los dobleces: verde = monte, naranja = valle.
  - Puedes ajustar las medidas **por volumen** (cm³) o sumar holgura alrededor del objeto. Unidades en mm o pulgadas.
- **Exportar:** PDF a escala real (se divide en varias hojas y trae regla de 50 mm para verificar), SVG para Inkscape y DXF para LibreCAD, FreeCAD o AutoCAD.
- **Proyector:**
  - *Plantilla 1:1:* calibras con la regla de 100 mm y cortas a mano sobre el material.
  - *Sobre la máquina:* calibras 4 esquinas y ves en la cama exactamente lo que se va a cortar, y dónde está la herramienta, **antes** de prender el láser. En la app de escritorio la ventana del proyector se abre sola en la segunda pantalla.
- **Importar CAD:** DXF (líneas, polilíneas, arcos, círculos, splines, elipses) y SVG. Las capas se asignan por color o por nombre. En la app de escritorio puede vigilar un archivo y recargarlo cada vez que guardas. Incluye una macro de FreeCAD en `integraciones/freecad`.
- **Imagen:** grabado de fotos con láser (tramado Floyd–Steinberg o Jarvis, escala de grises o blanco y negro), espejo para grabar acrílico por detrás, relieve con fresa y conversión de un dibujo en línea de corte.
- **3D (STL):** convierte el modelo en un mapa de alturas, en **positivo** (la figura sobresale) o en **negativo** (molde). Con fresadora hace desbaste y acabado con compensación de fresa de bola; con láser lo graba en escala de grises.
- **PCB desde Gerber + Excellon:**
  - *Láser:* graba el negativo para el método de pintura + ácido. Un láser de diodo no quita cobre.
  - *Fresadora:* aislamiento con V-bit, varias pasadas.
  - Recomienda broca por diámetro de agujero, avisa si la pista es más delgada que el corte de tu herramienta y saca el contorno.
- **Corte (CAM):** G-code para láser (modo dinámico M4, perforado para dobleces) o fresadora (pasadas por profundidad, corte afuera/adentro/sobre la línea, cambio de broca con pausa). Trae una tabla de materiales y una prueba de calibración de potencia × velocidad. Bloquea PVC/vinil en láser.
- **Control:** conecta por USB (Web Serial). Incluye lectura de posición, jog, ceros, home, desbloqueo, recorrer marco, consola, envío por conteo de caracteres, pausa, seguir y alto.
- **Flashear GRBL 1.1h al Arduino** desde la propia app (protocolo STK500 de Optiboot, Uno/Nano). Como alternativa, en `firmware/` hay scripts con avrdude.
- **Mi taller:** área de trabajo, tipo y potencia de láser, biblioteca de fresas y brocas, y calculadora de pasos/mm.

## Primer uso con Arduino + CNC Shield

1. Pestaña **Control** → *Flashear GRBL* (elige Uno o Nano). Espera el mensaje “¡Listo!”.
2. **Conectar** a 115200 → *Ver ajustes $$*.
3. En **Mi taller** calcula pasos/mm y envíalos a `$100` y `$101`. Configura el área de trabajo.
4. Para láser pulsa *Activar modo láser* (`$32=1`). Para fresa, *Modo fresa* (`$32=0`).
5. Haz la **prueba de calibración** en tu material y ajusta la tabla en Corte.

## Seguridad

Usa gafas para la longitud de onda de tu láser y nunca lo dejes solo. Ten ventilación y un extintor a la mano. **No cortes con láser PVC, vinil ni policarbonato**: liberan gases tóxicos y corrosivos. Sujeta bien el material antes de fresar.

## Estructura del código

```
index.html, css/      interfaz
js/core.js            geometría (mm), capas, relleno, offset
js/boxes.js           cajas paramétricas y modelos PRO
js/extras.js          juegos de mesa y origami
js/export.js          SVG, DXF R12 y PDF 1:1 por hojas
js/importers.js       DXF y SVG
js/cam.js             G-code láser/fresa, ráster, relieve, taladros, materiales
js/imaging.js         imagen, STL, Gerber/Excellon, contornos
js/grbl.js            Web Serial, envío por conteo de caracteres, flasheo STK500
js/projector.js       proyector 1:1 y con homografía de 4 puntos
escritorio/           envoltura Electron (USB, segunda pantalla, vigilar archivos)
firmware/             GRBL 1.1h (GPL-3.0, github.com/gnea/grbl) y scripts avrdude
integraciones/        macro de FreeCAD
ejemplos/             PCB, STL y DXF/SVG de prueba
```

Para **agregar una plantilla**, registra en `js/boxes.js` o `js/extras.js` un objeto con `params` (largo, ancho, alto…) y una función `build(p)` que devuelva trazos con capa `cut`, `fold`, `valley`, `engrave` o `ref`.

## Limitaciones de esta versión

Esta es una versión inicial (0.1); trae algunas aproximaciones:

- El relieve STL se ve solo desde arriba (no hace 4 ejes).
- El Gerber soporta aperturas C, R, O y P, regiones y arcos. Las macros de apertura se aproximan como círculos.
- El cubo pop-up y la caja sorpresa son modelos experimentales: ajusta la liga.
- El flasheo desde la app no soporta el Arduino Mega; para el Mega usa avrdude.

## Versiones

| Versión | Fecha | Cambios |
|---|---|---|
| v0.1 | 2026-10-14 | Primera versión: 25 plantillas (cajas, PRO con mecanismo, juegos, origami), PDF/SVG/DXF, importar DXF/SVG, proyector 1:1 y sobre la máquina, CAM láser/fresa, imagen, STL, PCB, control GRBL y flasheo del Arduino. |

## Licencia

GPL-3.0-or-later (ver `LICENSE`). GRBL es © Sungeun K. Jeon y colaboradores, también GPL-3.0.
