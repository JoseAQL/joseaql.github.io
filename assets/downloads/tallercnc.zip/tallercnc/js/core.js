/* TallerCNC - núcleo de geometría. Todo se guarda en milímetros.
 * Licencia GPL-3.0-or-later */
'use strict';
window.TC = window.TC || {};

(function (TC) {
  const LAYERS = {
    cut:     { name: 'Corte',     color: '#e5484d', dxf: 1 },
    fold:    { name: 'Doblez (monte)', color: '#30a46c', dxf: 3 },
    valley:  { name: 'Doblez (valle)', color: '#f5a623', dxf: 2 },
    engrave: { name: 'Grabado',   color: '#3e63dd', dxf: 5 },
    ref:     { name: 'Referencia',color: '#8b8d98', dxf: 8 }
  };
  TC.LAYERS = LAYERS;

  /** Un trazo: lista de puntos [x,y] en mm. */
  function path(pts, layer = 'cut', closed = false) {
    return { type: 'path', layer, closed, pts: pts.map(p => [p[0], p[1]]) };
  }
  TC.path = path;
  TC.line = (x1, y1, x2, y2, layer = 'cut') => path([[x1, y1], [x2, y2]], layer, false);
  TC.rect = (x, y, w, h, layer = 'cut') => path([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], layer, true);
  TC.circle = (cx, cy, r, layer = 'cut', seg) => {
    const n = seg || Math.max(24, Math.ceil(2 * Math.PI * r / 0.8));
    const pts = [];
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
    return path(pts, layer, true);
  };
  TC.arcPts = (cx, cy, r, a0, a1, n) => {
    n = n || Math.max(8, Math.ceil(Math.abs(a1 - a0) * r / 0.8));
    const pts = [];
    for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
    return pts;
  };
  TC.polygon = (cx, cy, r, sides, rot = 0, layer = 'cut') => {
    const pts = [];
    for (let i = 0; i < sides; i++) { const a = rot + i / sides * Math.PI * 2; pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); }
    return path(pts, layer, true);
  };

  /** Turtle: dibuja contornos con avance + giro (útil para cajas). */
  class Turtle {
    constructor(x = 0, y = 0, ang = 0) { this.x = x; this.y = y; this.a = ang; this.pts = [[x, y]]; }
    fwd(d) { this.x += d * Math.cos(this.a); this.y += d * Math.sin(this.a); this.pts.push([this.x, this.y]); return this; }
    turn(deg) { this.a += deg * Math.PI / 180; return this; }
    to(x, y) { this.x = x; this.y = y; this.pts.push([x, y]); return this; }
    rel(dx, dy) { return this.to(this.x + dx, this.y + dy); }
  }
  TC.Turtle = Turtle;

  function bbox(items) {
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const it of items) {
      if (it.type === 'path') for (const [x, y] of it.pts) { if (x < x0) x0 = x; if (y < y0) y0 = y; if (x > x1) x1 = x; if (y > y1) y1 = y; }
      else if (it.type === 'raster' || it.type === 'heightmap') { x0 = Math.min(x0, it.x); y0 = Math.min(y0, it.y); x1 = Math.max(x1, it.x + it.w); y1 = Math.max(y1, it.y + it.h); }
      else if (it.type === 'drills') for (const h of it.holes) { x0 = Math.min(x0, h.x - h.d / 2); y0 = Math.min(y0, h.y - h.d / 2); x1 = Math.max(x1, h.x + h.d / 2); y1 = Math.max(y1, h.y + h.d / 2); }
    }
    if (!isFinite(x0)) return { x0: 0, y0: 0, x1: 0, y1: 0, w: 0, h: 0 };
    return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0 };
  }
  TC.bbox = bbox;

  function transform(items, fn) {
    return items.map(it => it.type === 'path' ? Object.assign({}, it, { pts: it.pts.map(p => fn(p[0], p[1])) }) : it);
  }
  TC.translate = (items, dx, dy) => items.map(it => {
    if (it.type === 'path') return Object.assign({}, it, { pts: it.pts.map(p => [p[0] + dx, p[1] + dy]) });
    if (it.type === 'raster' || it.type === 'heightmap') return Object.assign({}, it, { x: it.x + dx, y: it.y + dy });
    if (it.type === 'drills') return Object.assign({}, it, { holes: it.holes.map(h => Object.assign({}, h, { x: h.x + dx, y: h.y + dy })) });
    return it;
  });
  TC.scale = (items, s) => transform(items, (x, y) => [x * s, y * s]);
  TC.rotate = (items, deg) => {
    const a = deg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    return transform(items, (x, y) => [x * c - y * s, x * s + y * c]);
  };
  TC.mirrorX = items => transform(items, (x, y) => [-x, y]);
  /** Mueve el diseño para que su esquina inferior-izquierda quede en (margin, margin). */
  TC.normalize = (items, margin = 0) => { const b = bbox(items); return TC.translate(items, margin - b.x0, margin - b.y0); };

  /** Une segmentos sueltos en polilíneas (para DXF importados). */
  TC.joinSegments = function (items, tol = 0.01) {
    const out = [], open = [];
    for (const it of items) (it.type === 'path' && !it.closed ? open : out).push(it);
    const near = (a, b) => Math.abs(a[0] - b[0]) < tol && Math.abs(a[1] - b[1]) < tol;
    while (open.length) {
      let cur = open.shift(); let pts = cur.pts.slice(); let grew = true;
      while (grew) {
        grew = false;
        for (let i = 0; i < open.length; i++) {
          const o = open[i]; if (o.layer !== cur.layer) continue;
          const s = o.pts[0], e = o.pts[o.pts.length - 1];
          if (near(pts[pts.length - 1], s)) { pts = pts.concat(o.pts.slice(1)); }
          else if (near(pts[pts.length - 1], e)) { pts = pts.concat(o.pts.slice(0, -1).reverse()); }
          else if (near(pts[0], e)) { pts = o.pts.slice(0, -1).concat(pts); }
          else if (near(pts[0], s)) { pts = o.pts.slice(1).reverse().concat(pts); }
          else continue;
          open.splice(i, 1); grew = true; break;
        }
      }
      const closed = pts.length > 2 && near(pts[0], pts[pts.length - 1]);
      if (closed) pts.pop();
      out.push(path(pts, cur.layer, closed));
    }
    return out;
  };

  TC.pathLength = it => { let L = 0; const p = it.pts; for (let i = 1; i < p.length; i++) L += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]); if (it.closed && p.length > 1) L += Math.hypot(p[0][0] - p[p.length - 1][0], p[0][1] - p[p.length - 1][1]); return L; };

  /** Área con signo (positiva = antihorario en coordenadas y-arriba). */
  TC.area = pts => { let a = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; a += p[0] * q[1] - q[0] * p[1]; } return a / 2; };

  /** Offset sencillo de un polígono (miter limitado). Positivo = hacia afuera. */
  TC.offsetPolygon = function (pts, d) {
    const n = pts.length; if (n < 3) return pts.slice();
    const sign = TC.area(pts) > 0 ? 1 : -1; // afuera depende de la orientación
    const out = [];
    for (let i = 0; i < n; i++) {
      const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n];
      let d1x = p1[0] - p0[0], d1y = p1[1] - p0[1]; let l1 = Math.hypot(d1x, d1y) || 1; d1x /= l1; d1y /= l1;
      let d2x = p2[0] - p1[0], d2y = p2[1] - p1[1]; let l2 = Math.hypot(d2x, d2y) || 1; d2x /= l2; d2y /= l2;
      // normales hacia afuera
      const n1x = d1y * sign, n1y = -d1x * sign, n2x = d2y * sign, n2y = -d2x * sign;
      let bx = n1x + n2x, by = n1y + n2y; const bl = Math.hypot(bx, by);
      if (bl < 1e-6) { out.push([p1[0] + n1x * d, p1[1] + n1y * d]); continue; }
      bx /= bl; by /= bl; const cos = bx * n1x + by * n1y; const m = Math.min(1 / Math.max(cos, 0.25), 4);
      out.push([p1[0] + bx * d * m, p1[1] + by * d * m]);
    }
    return out;
  };

  /** Relleno por líneas (para grabar áreas con láser vectorial o fresa). Regla par-impar. */
  TC.hatch = function (polys, spacing = 0.2, angleDeg = 0, layer = 'engrave') {
    const a = -angleDeg * Math.PI / 180, c = Math.cos(a), s = Math.sin(a);
    const rot = polys.map(p => p.map(([x, y]) => [x * c - y * s, x * s + y * c]));
    let y0 = Infinity, y1 = -Infinity;
    rot.forEach(p => p.forEach(q => { y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); }));
    const out = []; let flip = false;
    for (let y = y0 + spacing / 2; y < y1; y += spacing) {
      const xs = [];
      for (const p of rot) for (let i = 0; i < p.length; i++) {
        const A = p[i], B = p[(i + 1) % p.length];
        if ((A[1] <= y && B[1] > y) || (B[1] <= y && A[1] > y)) xs.push(A[0] + (y - A[1]) / (B[1] - A[1]) * (B[0] - A[0]));
      }
      xs.sort((u, v) => u - v); if (flip) xs.reverse();
      for (let i = 0; i + 1 < xs.length; i += 2) {
        const back = ([x, yy]) => [x * c + yy * s, -x * s + yy * c];
        out.push(path([back([xs[i], y]), back([xs[i + 1], y])], layer, false));
      }
      flip = !flip;
    }
    return out;
  };

  /** Unidades */
  TC.units = { mode: 'mm' };
  TC.toMM = v => TC.units.mode === 'in' ? v * 25.4 : v;
  TC.fromMM = v => TC.units.mode === 'in' ? v / 25.4 : v;
  TC.fmt = (v, d = 2) => (Math.round(v * 10 ** d) / 10 ** d).toString();

  /** Descarga un archivo desde el navegador o Electron. */
  TC.download = function (name, data, mime = 'application/octet-stream') {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  };

  TC.toast = function (msg, kind = 'info') {
    const el = document.createElement('div'); el.className = 'toast ' + kind; el.textContent = msg;
    document.getElementById('toasts').appendChild(el); setTimeout(() => el.remove(), 4000);
  };
})(window.TC);
