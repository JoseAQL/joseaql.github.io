/* TallerCNC - CAM: convierte el diseño en G-code para GRBL (láser o fresadora).
 * Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const f3 = v => (Math.round(v * 1000) / 1000).toString();

  /* Perfil del taller (se guarda en el navegador) */
  const DEFAULT_SHOP = {
    machine: { name: 'Mi CNC', bedW: 300, bedH: 180, bedZ: 45, head: 'laser', sMax: 1000, safeZ: 5, units: 'mm', laserType: 'diodo', laserW: 5 },
    tools: [
      { id: 'fe3', name: 'Fresa plana 3.175 mm (1/8")', type: 'flat', d: 3.175, flutes: 2 },
      { id: 'fe1', name: 'Fresa plana 1 mm', type: 'flat', d: 1.0, flutes: 2 },
      { id: 'vb30', name: 'V-bit 30° punta 0.1 mm', type: 'vbit', d: 3.175, angle: 30, tip: 0.1 },
      { id: 'vb60', name: 'V-bit 60°', type: 'vbit', d: 6, angle: 60, tip: 0.2 },
      { id: 'bola', name: 'Fresa de bola 3.175 mm', type: 'ball', d: 3.175 },
      { id: 'mai', name: 'Fresa de maíz 1.5 mm (PCB contorno)', type: 'flat', d: 1.5 },
      { id: 'br08', name: 'Broca PCB 0.8 mm', type: 'drill', d: 0.8 },
      { id: 'br10', name: 'Broca PCB 1.0 mm', type: 'drill', d: 1.0 },
      { id: 'br12', name: 'Broca PCB 1.2 mm', type: 'drill', d: 1.2 }
    ]
  };
  // Valores iniciales conservadores: haz la prueba de calibración con tu máquina.
  TC.MATERIALS = {
    carton:   { name: 'Cartón corrugado 3 mm', t: 3,  laser: { cut: [80, 400, 1], fold: [12, 1200, 1], engrave: [30, 1500, 1] }, mill: { feed: 800, plunge: 200, step: 3, rpm: 10000 } },
    cartulina:{ name: 'Cartulina / opalina 0.3 mm', t: 0.3, laser: { cut: [40, 900, 1], fold: [8, 2000, 1], engrave: [15, 2500, 1] }, mill: { feed: 600, plunge: 200, step: 0.3, rpm: 10000 } },
    kraft:    { name: 'Papel kraft', t: 0.2, laser: { cut: [30, 1200, 1], fold: [6, 2500, 1], engrave: [12, 3000, 1] }, mill: { feed: 600, plunge: 200, step: 0.2, rpm: 10000 } },
    mdf3:     { name: 'MDF 3 mm', t: 3, laser: { cut: [100, 150, 2], fold: [20, 1500, 1], engrave: [40, 1500, 1] }, mill: { feed: 600, plunge: 150, step: 1.0, rpm: 12000 } },
    mdf6:     { name: 'MDF 6 mm', t: 6, laser: { cut: [100, 120, 4], fold: [20, 1500, 1], engrave: [40, 1500, 1] }, mill: { feed: 600, plunge: 150, step: 1.2, rpm: 12000 } },
    triplay:  { name: 'Triplay de abedul 3 mm', t: 3, laser: { cut: [100, 180, 2], fold: [20, 1500, 1], engrave: [35, 1800, 1] }, mill: { feed: 700, plunge: 200, step: 1.0, rpm: 12000 } },
    acrilico: { name: 'Acrílico 3 mm (solo láser CO2 o fresa)', t: 3, laser: { cut: [100, 120, 3], fold: [20, 1500, 1], engrave: [30, 2000, 1] }, mill: { feed: 500, plunge: 120, step: 0.5, rpm: 15000 } },
    piel:     { name: 'Piel / cuero 2 mm', t: 2, laser: { cut: [90, 300, 2], fold: [15, 1500, 1], engrave: [25, 2500, 1] }, mill: { feed: 500, plunge: 150, step: 1, rpm: 10000 } },
    corcho:   { name: 'Corcho 3 mm', t: 3, laser: { cut: [70, 500, 1], fold: [10, 2000, 1], engrave: [20, 2500, 1] }, mill: { feed: 800, plunge: 200, step: 3, rpm: 10000 } },
    fr4:      { name: 'Placa PCB FR4 1.6 mm', t: 1.6, laser: { cut: [0, 0, 0], fold: [0, 0, 0], engrave: [60, 1200, 1] }, mill: { feed: 200, plunge: 80, step: 0.4, rpm: 12000 } },
    aluminio: { name: 'Aluminio (solo fresa)', t: 3, laser: { cut: [0, 0, 0], fold: [0, 0, 0], engrave: [0, 0, 0] }, mill: { feed: 250, plunge: 60, step: 0.2, rpm: 15000 } },
    pvc:      { name: 'PVC / vinil (¡NO láser!)', t: 3, forbidLaser: true, laser: { cut: [0, 0, 0], fold: [0, 0, 0], engrave: [0, 0, 0] }, mill: { feed: 600, plunge: 150, step: 1, rpm: 12000 } }
  };

  TC.shop = (() => { try { return Object.assign(structuredClone(DEFAULT_SHOP), JSON.parse(localStorage.getItem('tc.shop') || '{}')); } catch (e) { return structuredClone(DEFAULT_SHOP); } })();
  TC.saveShop = () => { try { localStorage.setItem('tc.shop', JSON.stringify(TC.shop)); } catch (e) { /* sin almacenamiento */ } };
  TC.resetShop = () => { TC.shop = structuredClone(DEFAULT_SHOP); TC.saveShop(); };

  /** Ancho de línea que deja un V-bit a cierta profundidad. */
  TC.vbitWidth = (tool, depth) => (tool.tip || 0) + 2 * depth * Math.tan((tool.angle || 60) * Math.PI / 360);

  /* ---------- Orden de corte ---------- */
  function orderPaths(list) {
    // interiores antes que exteriores: los contenidos primero, luego vecino más cercano
    const withBox = list.map(it => ({ it, b: TC.bbox([it]) }));
    const contains = (A, B) => A.b.x0 <= B.b.x0 && A.b.y0 <= B.b.y0 && A.b.x1 >= B.b.x1 && A.b.y1 >= B.b.y1 && (A.b.w * A.b.h > B.b.w * B.b.h);
    withBox.forEach(a => { a.depth = withBox.filter(o => o !== a && o.it.closed && contains(o, a)).length; });
    const out = []; let pos = [0, 0];
    const maxD = Math.max(0, ...withBox.map(a => a.depth));
    for (let d = maxD; d >= 0; d--) {
      let pool = withBox.filter(a => a.depth === d);
      while (pool.length) {
        let bi = 0, bd = Infinity, rev = false;
        pool.forEach((a, i) => {
          const s = a.it.pts[0], e = a.it.pts[a.it.pts.length - 1];
          const ds = Math.hypot(s[0] - pos[0], s[1] - pos[1]); if (ds < bd) { bd = ds; bi = i; rev = false; }
          if (!a.it.closed) { const de = Math.hypot(e[0] - pos[0], e[1] - pos[1]); if (de < bd) { bd = de; bi = i; rev = true; } }
        });
        const a = pool.splice(bi, 1)[0]; let pts = a.it.pts.slice(); if (rev) pts.reverse();
        if (a.it.closed) pts.push(pts[0]);
        out.push({ pts, closed: a.it.closed, layer: a.it.layer }); pos = pts[pts.length - 1];
      }
    }
    return out;
  }
  TC.orderPaths = orderPaths;

  /** Línea discontinua (perforado) para dobleces con láser. */
  function dashify(pts, on, off) {
    const out = []; let cur = [pts[0]], state = true, left = on;
    for (let i = 1; i < pts.length; i++) {
      let a = pts[i - 1]; const b = pts[i]; let seg = Math.hypot(b[0] - a[0], b[1] - a[1]);
      while (seg > 1e-9) {
        if (seg >= left) {
          const t = left / seg, p = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
          if (state) { cur.push(p); out.push(cur); } cur = [p]; state = !state; seg -= left; left = state ? on : off; a = p;
        } else { if (state) cur.push(b); left -= seg; seg = 0; }
      }
    }
    if (state && cur.length > 1) out.push(cur);
    return out;
  }
  TC.dashify = dashify;

  /* ---------- Generador principal ---------- */
  /**
   * job = { mode:'laser'|'mill', ops:{layer:{on, power, speed, passes, dash, tool, depth, stepdown, feed, plunge, side}}, raster settings, origin }
   */
  TC.generateGcode = function (items, job) {
    const M = TC.shop.machine, g = [], stats = { moves: 0, cutLen: 0, time: 0 };
    const sMax = M.sMax || 1000, safe = M.safeZ || 5, flipY = false;
    const Y = y => flipY ? -y : y;
    let last = [0, 0];
    const travel = (x, y) => { const d = Math.hypot(x - last[0], y - last[1]); stats.time += d / 3000; last = [x, y]; };
    const cut = (x, y, F) => { const d = Math.hypot(x - last[0], y - last[1]); stats.cutLen += d; stats.time += d / Math.max(F, 1); last = [x, y]; };
    g.push('; TallerCNC - G-code para GRBL 1.1', `; Modo: ${job.mode === 'laser' ? 'láser' : 'fresadora'}  Material: ${job.materialName || ''}`, `; Generado: ${new Date().toISOString()}`, 'G21 ; milímetros', 'G90 ; absoluto', 'G17');
    const order = ['engrave', 'valley', 'fold', 'cut'];
    // ráster primero (grabado de imagen)
    for (const r of items.filter(i => i.type === 'raster')) {
      if (job.mode === 'laser') for (const l of rasterLaser(r, job, stats)) g.push(l);
    }
    for (const r of items.filter(i => i.type === 'heightmap')) {
      if (job.mode === 'mill') for (const l of heightmapMill(r, job, stats)) g.push(l);
    }
    for (const r of items.filter(i => i.type === 'drills')) {
      if (job.mode === 'mill') for (const l of drillMill(r, job, stats)) g.push(l);
    }
    if (job.mode === 'laser') g.push('M4 S0 ; láser dinámico (requiere $32=1)');
    for (const lay of order) {
      const op = job.ops[lay]; if (!op || !op.on) continue;
      let list = items.filter(i => i.type === 'path' && i.layer === lay && i.pts.length > 1);
      if (!list.length) continue;
      if (job.mode === 'mill' && op.side && op.side !== 'on') {
        const tool = TC.shop.tools.find(t => t.id === op.tool) || { d: 3.175 };
        list = list.map(it => it.closed ? Object.assign({}, it, { pts: TC.offsetPolygon(it.pts, (op.side === 'outside' ? 1 : -1) * tool.d / 2) }) : it);
      }
      let paths = orderPaths(list);
      if (job.mode === 'laser' && op.dash) paths = paths.flatMap(p => dashify(p.pts, op.dashOn || 4, op.dashOff || 2).map(pts => ({ pts })));
      g.push(`; --- Capa: ${TC.LAYERS[lay].name} ---`);
      if (job.mode === 'laser') {
        const S = Math.round(op.power / 100 * sMax), F = op.speed;
        for (let pass = 0; pass < (op.passes || 1); pass++) {
          for (const p of paths) {
            g.push(`G0 X${f3(p.pts[0][0])} Y${f3(Y(p.pts[0][1]))}`); travel(p.pts[0][0], p.pts[0][1]);
            g.push(`G1 F${F} S${S}`);
            for (let i = 1; i < p.pts.length; i++) { g.push(`G1 X${f3(p.pts[i][0])} Y${f3(Y(p.pts[i][1]))}`); cut(p.pts[i][0], p.pts[i][1], F); }
            g.push('S0');
          }
        }
      } else {
        const depth = op.depth, sd = Math.max(0.05, op.stepdown || depth), F = op.feed, Fz = op.plunge;
        const levels = []; for (let z = sd; z < depth - 1e-6; z += sd) levels.push(-z); levels.push(-depth);
        g.push(`M3 S${job.rpm || sMax}`, 'G4 P2');
        for (const p of paths) {
          g.push(`G0 Z${safe}`, `G0 X${f3(p.pts[0][0])} Y${f3(Y(p.pts[0][1]))}`); travel(p.pts[0][0], p.pts[0][1]);
          for (const z of levels) {
            g.push(`G1 Z${f3(z)} F${Fz}`); stats.time += Math.abs(z) / Fz;
            const pts = p.closed ? p.pts : (levels.indexOf(z) % 2 ? p.pts.slice().reverse() : p.pts);
            if (!p.closed && levels.indexOf(z) % 2) g.push(`G1 X${f3(pts[0][0])} Y${f3(Y(pts[0][1]))} F${F}`);
            g.push(`G1 X${f3(pts[1][0])} Y${f3(Y(pts[1][1]))} F${F}`); cut(pts[1][0], pts[1][1], F);
            for (let i = 2; i < pts.length; i++) { g.push(`G1 X${f3(pts[i][0])} Y${f3(Y(pts[i][1]))}`); cut(pts[i][0], pts[i][1], F); }
          }
          g.push(`G0 Z${safe}`);
        }
      }
    }
    if (job.mode === 'laser') g.push('M5 S0'); else g.push(`G0 Z${safe}`, 'M5');
    g.push('G0 X0 Y0', 'M2');
    stats.lines = g.length; stats.minutes = stats.time;
    return { gcode: g.join('\n') + '\n', stats };
  };

  /* ---------- Ráster láser (imágenes, fotos, PCB negativo) ---------- */
  function rasterLaser(r, job, stats) {
    const out = [], c = r.canvas, ctx = c.getContext('2d'), { width: W, height: H } = c, data = ctx.getImageData(0, 0, W, H).data;
    const M = TC.shop.machine, sMax = M.sMax || 1000, pmin = (r.pmin ?? 0) / 100 * sMax, pmax = (r.pmax ?? 60) / 100 * sMax, F = r.speed || 1500;
    const px = r.w / W, py = r.h / H, over = r.overscan ?? 2;
    out.push(`; --- Grabado ráster ${W}x${H} px, ${f3(r.w)}x${f3(r.h)} mm ---`, 'M4 S0', `G0 X${f3(r.x)} Y${f3(r.y + r.h)}`, `G1 F${F}`);
    let dir = 1;
    for (let j = 0; j < H; j++) {
      const y = r.y + r.h - (j + 0.5) * py; const row = [];
      for (let i = 0; i < W; i++) { const k = (j * W + i) * 4, a = data[k + 3] / 255, lum = (0.299 * data[k] + 0.587 * data[k + 1] + 0.114 * data[k + 2]) / 255; const dark = (1 - lum) * a; row.push(dark < 0.02 ? 0 : Math.round(pmin + (pmax - pmin) * dark)); }
      const first = row.findIndex(v => v > 0); if (first < 0) continue;
      let lastI = W - 1; while (row[lastI] === 0) lastI--;
      const idx = dir > 0 ? [...Array(lastI - first + 1).keys()].map(i => i + first) : [...Array(lastI - first + 1).keys()].map(i => lastI - i);
      const startX = r.x + (dir > 0 ? first * px - over : (lastI + 1) * px + over);
      out.push(`G0 X${f3(startX)} Y${f3(y)} S0`);
      let i0 = 0;
      while (i0 < idx.length) {
        const v = row[idx[i0]]; let i1 = i0; while (i1 + 1 < idx.length && row[idx[i1 + 1]] === v) i1++;
        const xEnd = r.x + (dir > 0 ? (idx[i1] + 1) * px : idx[i1] * px);
        out.push(`G1 X${f3(xEnd)} S${v}`); stats.time += Math.abs((i1 - i0 + 1) * px) / F; i0 = i1 + 1;
      }
      out.push(`G1 X${f3(dir > 0 ? r.x + (lastI + 1) * px + over : r.x + first * px - over)} S0`);
      dir = -dir;
    }
    out.push('S0');
    return out;
  }

  /* ---------- Relieve con fresa (mapa de alturas) ---------- */
  function heightmapMill(r, job, stats) {
    const out = [], { gw, gh, z } = r, safe = TC.shop.machine.safeZ || 5;
    const tool = TC.shop.tools.find(t => t.id === r.tool) || { d: 3.175 };
    const step = Math.max(tool.d * (r.stepover ?? 0.25), r.w / gw), F = r.feed || 800, Fz = r.plunge || 200;
    const sd = r.stepdown || 1, depth = r.depth;
    const at = (x, y) => { const i = Math.min(gw - 1, Math.max(0, Math.round((x - r.x) / r.w * (gw - 1)))), j = Math.min(gh - 1, Math.max(0, Math.round((y - r.y) / r.h * (gh - 1)))); return z[j * gw + i]; };
    // compensación simple de fresa de bola: toma el máximo bajo el radio
    const rad = tool.d / 2, samples = [[0, 0], [rad, 0], [-rad, 0], [0, rad], [0, -rad], [rad * .7, rad * .7], [-rad * .7, rad * .7], [rad * .7, -rad * .7], [-rad * .7, -rad * .7]];
    const zAt = (x, y) => Math.max(...samples.map(([dx, dy]) => (at(x + dx, y + dy) - 1) * depth - (tool.type === 'ball' ? (rad - Math.sqrt(Math.max(0, rad * rad - dx * dx - dy * dy))) : 0)));
    out.push(`; --- Relieve 3D ${f3(r.w)}x${f3(r.h)} mm, profundidad ${depth} mm ---`, `M3 S${job.rpm || 1000}`, 'G4 P2', `G0 Z${safe}`);
    const levels = []; for (let l = sd; l < depth; l += sd) levels.push(-l); levels.push(-depth - 1);
    const xs = []; for (let x = r.x; x <= r.x + r.w + 1e-6; x += step / 2) xs.push(x);
    levels.forEach((floor, li) => {
      const finish = li === levels.length - 1;
      out.push(finish ? '; acabado' : `; desbaste a ${f3(-floor)} mm`);
      let dir = 1;
      for (let y = r.y; y <= r.y + r.h + 1e-6; y += step) {
        const row = (dir > 0 ? xs : xs.slice().reverse());
        const zz = row.map(x => Math.max(floor, zAt(x, y)));
        out.push(`G0 X${f3(row[0])} Y${f3(y)}`, `G1 Z${f3(zz[0])} F${Fz}`);
        for (let i = 1; i < row.length; i++) out.push(`G1 X${f3(row[i])} Z${f3(zz[i])} F${F}`);
        stats.time += r.w / F; dir = -dir;
        out.push(`G0 Z${f3(Math.max(...zz) + 1)}`);
      }
      out.push(`G0 Z${safe}`);
    });
    out.push('M5');
    return out;
  }

  /* ---------- Taladrado (PCB) ---------- */
  function drillMill(r, job, stats) {
    const out = [], safe = TC.shop.machine.safeZ || 5;
    const groups = {};
    r.holes.forEach(h => { (groups[h.tool] = groups[h.tool] || []).push(h); });
    for (const [tid, holes] of Object.entries(groups)) {
      const tool = TC.shop.tools.find(t => t.id === tid);
      out.push(`; --- Taladrar ${holes.length} agujeros con ${tool ? tool.name : tid} ---`, `G0 Z${safe + 15}`, 'M5', `M0 ; cambia a ${tool ? tool.name : tid} y presiona continuar (~)`, `M3 S${job.rpm || 1000}`, 'G4 P2');
      const ordered = []; let pos = [0, 0]; const pool = holes.slice();
      while (pool.length) { let bi = 0, bd = Infinity; pool.forEach((h, i) => { const d = Math.hypot(h.x - pos[0], h.y - pos[1]); if (d < bd) { bd = d; bi = i; } }); const h = pool.splice(bi, 1)[0]; ordered.push(h); pos = [h.x, h.y]; }
      for (const h of ordered) { out.push(`G0 X${f3(h.x)} Y${f3(h.y)}`, `G0 Z1`, `G1 Z${f3(-r.depth)} F${r.plunge || 60}`, `G0 Z1`); stats.time += 0.05; }
      out.push(`G0 Z${safe}`);
    }
    return out;
  }

  /* ---------- Simulación: devuelve segmentos para dibujar ---------- */
  TC.parseGcodeForPreview = function (text) {
    const segs = []; let x = 0, y = 0, z = 0, mode = 0, s = 0, laserOn = false;
    for (const raw of text.split('\n')) {
      const line = raw.replace(/;.*|\(.*?\)/g, '').toUpperCase(); if (!line.trim()) continue;
      const w = {}; line.replace(/([A-Z])(-?[\d.]+)/g, (_, k, v) => { w[k] = +v; });
      if (w.G !== undefined && [0, 1, 2, 3].includes(w.G)) mode = w.G;
      if (w.M === 3 || w.M === 4) laserOn = true; if (w.M === 5) laserOn = false;
      if (w.S !== undefined) s = w.S;
      const nx = w.X ?? x, ny = w.Y ?? y, nz = w.Z ?? z;
      if (w.X !== undefined || w.Y !== undefined || w.Z !== undefined) {
        segs.push({ x0: x, y0: y, z0: z, x1: nx, y1: ny, z1: nz, rapid: mode === 0, on: laserOn && mode !== 0 && (s > 0 || nz < 0) });
        x = nx; y = ny; z = nz;
      }
    }
    return segs;
  };
})(window.TC);
