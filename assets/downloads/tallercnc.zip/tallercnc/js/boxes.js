/* TallerCNC - generadores paramétricos de cajas.
 * Coordenadas en mm, eje Y hacia arriba. L = largo, W = ancho, H = alto (medidas interiores).
 * Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const P = TC.path, L_ = TC.line;
  const T = {};
  TC.templates = T;

  const num = (k, label, def, extra = {}) => Object.assign({ k, label, def, type: 'num', unit: 'mm', min: 0.1, step: 1 }, extra);
  const int = (k, label, def, min, max) => ({ k, label, def, type: 'int', min, max, step: 1, unit: '' });
  const bool = (k, label, def) => ({ k, label, def, type: 'bool' });
  const thick = num('t', 'Grosor del material', 0.4, { step: 0.1, min: 0.05 });

  function reg(id, def) { def.id = id; T[id] = def; }

  /* ---------- utilidades ---------- */
  function polyNet(faces, opts = {}) {
    // faces: listas de puntos. Aristas compartidas = doblez; sueltas = corte (algunas con pestaña).
    const tab = opts.tab ?? 6, key = (a, b) => {
      const r = v => Math.round(v * 1000) / 1000;
      const A = r(a[0]) + ',' + r(a[1]), B = r(b[0]) + ',' + r(b[1]);
      return A < B ? A + '|' + B : B + '|' + A;
    };
    const edges = new Map();
    faces.forEach((f, fi) => f.forEach((a, i) => {
      const b = f[(i + 1) % f.length], k = key(a, b);
      if (!edges.has(k)) edges.set(k, { a, b, n: 0, fi }); edges.get(k).n++;
    }));
    const items = []; let parity = 0;
    const tabSet = opts.tabEdges; // índice opcional de aristas con pestaña
    let idx = 0;
    for (const e of edges.values()) {
      if (e.n > 1) { items.push(L_(e.a[0], e.a[1], e.b[0], e.b[1], 'fold')); continue; }
      const wantTab = tabSet ? tabSet.includes(idx) : (parity++ % 2 === 0);
      idx++;
      if (wantTab && tab > 0) {
        // la pestaña sale hacia afuera de la cara dueña
        const f = faces[e.fi]; const cx = f.reduce((s, p) => s + p[0], 0) / f.length, cy = f.reduce((s, p) => s + p[1], 0) / f.length;
        const dx = e.b[0] - e.a[0], dy = e.b[1] - e.a[1], len = Math.hypot(dx, dy);
        let nx = -dy / len, ny = dx / len;
        const mx = (e.a[0] + e.b[0]) / 2, my = (e.a[1] + e.b[1]) / 2;
        if ((mx + nx - cx) ** 2 + (my + ny - cy) ** 2 < (mx - cx) ** 2 + (my - cy) ** 2) { nx = -nx; ny = -ny; }
        const h = Math.min(tab, len * 0.3), ins = Math.min(h * 1.0, len * 0.3);
        const ux = dx / len, uy = dy / len;
        items.push(L_(e.a[0], e.a[1], e.b[0], e.b[1], 'fold'));
        items.push(P([e.a, [e.a[0] + ux * ins + nx * h, e.a[1] + uy * ins + ny * h], [e.b[0] - ux * ins + nx * h, e.b[1] - uy * ins + ny * h], e.b], 'cut'));
      } else items.push(L_(e.a[0], e.a[1], e.b[0], e.b[1], 'cut'));
    }
    return TC.joinSegments(items);
  }
  TC.polyNet = polyNet;

  function regPoly(cx, cy, side, n, rot) {
    const R = side / (2 * Math.sin(Math.PI / n)); const pts = [];
    for (let i = 0; i < n; i++) { const a = rot + i * 2 * Math.PI / n; pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]); }
    return pts;
  }
  /** Polígono regular cuyo lado inferior va de (x1,y) a (x2,y); se dibuja hacia abajo (dir=-1) o arriba (dir=1). */
  function polyOnEdge(x1, x2, y, n, dir) {
    const side = x2 - x1, ap = side / (2 * Math.tan(Math.PI / n));
    const cx = (x1 + x2) / 2, cy = y + dir * ap;
    // vértice inicial en (x1,y)
    const a0 = Math.atan2(y - cy, x1 - cx);
    const R = side / (2 * Math.sin(Math.PI / n)); const pts = [];
    for (let i = 0; i < n; i++) { const a = a0 + dir * -1 * i * 2 * Math.PI / n; pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]); }
    return pts;
  }

  function tray(L, W, H, t, ox = 0, oy = 0, tabs = true) {
    // charola: base L×W, cuatro paredes de alto H y pestañas de esquina pegadas a las paredes largas
    const h = H, g = Math.min(H * 0.85, 20) * 0.9, x0 = ox, x1 = ox + L, y0 = oy, y1 = oy + W, e = Math.min(1.5, h * 0.1);
    const pts = [[x0, y0 - h], [x1, y0 - h]];
    if (tabs) pts.push([x1 + g, y0 - h + e], [x1 + g, y0 - e]);
    pts.push([x1, y0], [x1 + h, y0], [x1 + h, y1], [x1, y1]);
    if (tabs) pts.push([x1 + g, y1 + e], [x1 + g, y1 + h - e]);
    pts.push([x1, y1 + h], [x0, y1 + h]);
    if (tabs) pts.push([x0 - g, y1 + h - e], [x0 - g, y1 + e]);
    pts.push([x0, y1], [x0 - h, y1], [x0 - h, y0], [x0, y0]);
    if (tabs) pts.push([x0 - g, y0 - e], [x0 - g, y0 - h + e]);
    const items = [P(pts, 'cut', true), TC.rect(x0, y0, L, W, 'fold')];
    if (tabs) [[x1, y0 - h, x1, y0], [x1, y1, x1, y1 + h], [x0, y1, x0, y1 + h], [x0, y0 - h, x0, y0]].forEach(a => items.push(L_(a[0], a[1], a[2], a[3], 'fold')));
    return items;
  }
  TC.tray = tray;

  /* ---------- 1. Caja con lengüetas (ECMA A20.20.03.01 / tuck-end inverso) ---------- */
  reg('tuck', {
    name: 'Caja con lengüetas (tuck end)', cat: 'Cajas plegadizas', code: 'ECMA A20 · tipo cosmético',
    params: [num('L', 'Largo', 60), num('W', 'Ancho', 40), num('H', 'Alto', 100), thick],
    build(p) {
      const t = p.t, L = p.L + t, W = p.W + t, H = p.H + t;
      const a = Math.min(15, Math.max(8, W * 0.35));            // pestaña de pegado
      const k = Math.min(15, Math.max(8, W * 0.4));              // lengüeta de cierre
      const dh = Math.min(W * 0.85, L * 0.45);                   // solapas antipolvo
      const r = Math.min(k * 0.6, L * 0.15), gi = Math.min(a * 0.4, H * 0.08), tp = Math.min(dh * 0.6, W * 0.4);
      const x1 = a, x2 = a + L, x3 = x2 + W, x4 = x3 + L, x5 = x4 + W;
      const pts = [
        [x1, 0], [0, gi], [0, H - gi], [x1, H],
        [x2, H], [x2 + t, H + dh], [x3 - tp, H + dh], [x3, H + t],
        [x3, H + W], [x3 + t, H + W], [x3 + t + r, H + W + k], [x4 - t - r, H + W + k], [x4 - t, H + W], [x4, H + W],
        [x4, H + t], [x4 + tp, H + dh], [x5 - t, H + dh], [x5, H],
        [x5, 0], [x5 - t, -dh], [x4 + tp, -dh], [x4, 0],
        [x3, 0], [x3 - t, -dh], [x2 + tp, -dh], [x2, -t],
        [x2, -W], [x2 - t, -W], [x2 - t - r, -W - k], [x1 + t + r, -W - k], [x1 + t, -W], [x1, -W]
      ];
      const items = [P(pts, 'cut', true)];
      [x1, x2, x3, x4].forEach(x => items.push(L_(x, 0, x, H, 'fold')));
      items.push(L_(x2, H, x5, H, 'fold')); items.push(L_(x3, H + W, x4, H + W, 'fold'));
      items.push(L_(x1, 0, x3, 0, 'fold')); items.push(L_(x4, 0, x5, 0, 'fold')); items.push(L_(x1, -W, x2, -W, 'fold'));
      return items;
    },
    notes: 'Pega la pestaña izquierda por dentro del último panel. La tapa superior y la inferior se cierran metiendo la lengüeta.'
  });

  /* ---------- 2. FEFCO 0201 caja ranurada ---------- */
  reg('fefco0201', {
    name: 'Caja de envío ranurada', cat: 'Cajas de cartón', code: 'FEFCO 0201',
    params: [num('L', 'Largo', 200), num('W', 'Ancho', 150), num('H', 'Alto', 100), Object.assign({}, thick, { def: 3 })],
    build(p) {
      const t = p.t, L = p.L + t, W = p.W + t, H = p.H + 2 * t, f = W / 2 + t / 2, s = Math.max(2 * t, 3), a = Math.min(35, Math.max(20, H * 0.25)), gi = a * 0.3;
      const xs = [a, a + L, a + L + W, a + 2 * L + W, a + 2 * L + 2 * W];
      const pts = [[xs[0], 0], [0, gi], [0, H - gi], [xs[0], H]];
      for (let i = 0; i < 4; i++) {
        const xa = xs[i], xb = xs[i + 1];
        const l = xa + (i === 0 ? 0 : s / 2), r = xb - (i === 3 ? 0 : s / 2);
        if (i > 0) pts.push([l, H]);
        pts.push([l, H + f], [r, H + f]); if (i < 3) pts.push([r, H]);
      }
      pts.push([xs[4], H], [xs[4], 0]);
      for (let i = 3; i >= 0; i--) {
        const xa = xs[i], xb = xs[i + 1];
        const l = xa + (i === 0 ? 0 : s / 2), r = xb - (i === 3 ? 0 : s / 2);
        if (i < 3) pts.push([r, 0]);
        pts.push([r, -f], [l, -f]); if (i > 0) pts.push([l, 0]);
      }
      const items = [P(pts, 'cut', true)];
      xs.slice(0, 4).forEach(x => items.push(L_(x, 0, x, H, 'fold')));
      items.push(L_(xs[0], 0, xs[4], 0, 'fold')); items.push(L_(xs[0], H, xs[4], H, 'fold'));
      return items;
    },
    notes: 'La caja de envío más común. Medidas interiores; las solapas se juntan al centro.'
  });

  /* ---------- 3. Caja con tapa (telescópica) ---------- */
  reg('lidbox', {
    name: 'Caja de regalo con tapa', cat: 'Cajas de cartón', code: 'FEFCO 0310 (simplificada)',
    params: [num('L', 'Largo', 100), num('W', 'Ancho', 80), num('H', 'Alto', 50), num('hl', 'Alto de tapa', 20), num('c', 'Holgura tapa', 1, { step: 0.5 }), thick],
    build(p) {
      const t = p.t, base = tray(p.L + t, p.W + t, p.H, t, 0, 0);
      const Ll = p.L + 3 * t + p.c, Wl = p.W + 3 * t + p.c;
      const bb = TC.bbox(base);
      const lid = TC.translate(tray(Ll, Wl, p.hl, t, 0, 0), bb.w + 2 * p.hl + 30, 0);
      return base.concat(lid);
    },
    notes: 'Base y tapa como charolas con pestañas de esquina. Pega las pestañas por dentro.'
  });

  /* ---------- 4. Charola ---------- */
  reg('tray', {
    name: 'Charola / bandeja', cat: 'Cajas de cartón', code: 'FEFCO 04xx (simplificada)',
    params: [num('L', 'Largo', 120), num('W', 'Ancho', 90), num('H', 'Alto', 30), thick],
    build: p => tray(p.L + p.t, p.W + p.t, p.H, p.t)
  });

  /* ---------- 5. Caja de cerillos (deslizable) ---------- */
  reg('matchbox', {
    name: 'Caja de cerillos (manga + cajón)', cat: 'Cajas de cartón', code: 'FEFCO 0501',
    params: [num('L', 'Largo', 80), num('W', 'Ancho', 50), num('H', 'Alto', 20), num('c', 'Holgura', 0.8, { step: 0.1 }), bool('notch', 'Muesca para el dedo', true), thick],
    build(p) {
      const t = p.t, items = tray(p.L, p.W, p.H, t, 0, 0, true);
      const bb = TC.bbox(items);
      const Wo = p.W + 2 * t + p.c, Ho = p.H + t + p.c, Lo = p.L - 2; // manga
      const ox = bb.x1 + 25, a = Math.min(12, Ho * 0.8);
      const xs = [ox, ox + Wo, ox + Wo + Ho, ox + 2 * Wo + Ho, ox + 2 * Wo + 2 * Ho];
      items.push(P([[xs[0], 0], [xs[4], 0], [xs[4] + a, 2], [xs[4] + a, Lo - 2], [xs[4], Lo], [xs[0], Lo]], 'cut', true));
      xs.slice(1).forEach(x => items.push(L_(x, 0, x, Lo, 'fold')));
      if (p.notch) {
        const r = Math.min(8, Ho * 0.4), cx = (xs[1] + xs[2]) / 2;
        items.push(P(TC.arcPts(cx, 0, r, 0, Math.PI), 'cut', false));
        items.push(P(TC.arcPts(cx, Lo, r, Math.PI, 2 * Math.PI), 'cut', false));
      }
      return items;
    },
    notes: 'El cajón es una charola; la manga se pega con la pestaña lateral. Las muescas son para empujar el cajón.'
  });

  /* ---------- 6. Caja almohada ---------- */
  reg('pillow', {
    name: 'Caja almohada', cat: 'Cajas plegadizas', code: 'ECMA F70.01',
    params: [num('L', 'Largo', 140), num('W', 'Ancho', 70), num('s', 'Curvatura', 12, { step: 1 }), thick],
    build(p) {
      const W = p.W + p.t, L = p.L, s = p.s, a = 12;
      const items = [];
      const arc = (x1, x2, y, sag, n = 40) => { const pts = []; for (let i = 0; i <= n; i++) { const u = i / n; pts.push([x1 + (x2 - x1) * u, y + sag * 4 * u * (1 - u)]); } return pts; };
      const top = arc(a, a + W, L, s).concat(arc(a + W, a + 2 * W, L, s).slice(1));
      const bot = arc(a + 2 * W, a + W, 0, -s).concat(arc(a + W, a, 0, -s).slice(1));
      items.push(P([[a, 0], [0, 4], [0, L - 4]].concat(top, [[a + 2 * W, 0]], bot.slice(1)), 'cut', true));
      items.push(P(arc(a, a + W, L, -s), 'fold')); items.push(P(arc(a + W, a + 2 * W, L, -s), 'fold'));
      items.push(P(arc(a, a + W, 0, s), 'fold')); items.push(P(arc(a + W, a + 2 * W, 0, s), 'fold'));
      items.push(L_(a, 0, a, L, 'fold')); items.push(L_(a + W, 0, a + W, L, 'fold'));
      return items;
    },
    notes: 'Marca bien los dobleces curvos; las tapas se cierran presionando hacia adentro.'
  });

  /* ---------- 7. Prisma poligonal con tapa ---------- */
  reg('prism', {
    name: 'Caja poligonal (hexagonal, octagonal…)', cat: 'Geométricas', code: 'Paramétrica',
    params: [int('n', 'Número de lados', 6, 3, 12), num('d', 'Ancho entre caras', 80), num('H', 'Alto', 60), num('tab', 'Pestañas', 8), thick],
    build(p) {
      const n = p.n, side = p.d * Math.tan(Math.PI / n), H = p.H, g = p.tab;
      const faces = [];
      for (let i = 0; i < n; i++) faces.push([[i * side, 0], [(i + 1) * side, 0], [(i + 1) * side, H], [i * side, H]]);
      faces.push(polyOnEdge(0, side, 0, n, -1));
      faces.push(polyOnEdge(0, side, H, n, 1).map(q => q));
      // pestaña de pegado lateral
      const items = polyNet(faces, { tab: g, tabEdges: [] });
      // reconstruimos: añadimos pestañas a los bordes superiores e inferiores de las caras 1..n-1 y al borde final
      const extra = [];
      const tabOn = (a, b, out) => { const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy), ux = dx / len, uy = dy / len, nx = -uy * out, ny = ux * out, h = Math.min(g, len * 0.3); extra.push(P([a, [a[0] + ux * h + nx * h, a[1] + uy * h + ny * h], [b[0] - ux * h + nx * h, b[1] - uy * h + ny * h], b], 'cut')); };
      const keep = items.filter(it => {
        if (it.layer !== 'cut' || it.pts.length !== 2) return true;
        const [a, b] = it.pts, horiz = Math.abs(a[1] - b[1]) < 1e-6, vert = Math.abs(a[0] - b[0]) < 1e-6;
        const x = Math.min(a[0], b[0]);
        if (horiz && (Math.abs(a[1]) < 1e-6 || Math.abs(a[1] - H) < 1e-6) && x >= side - 1e-6) {
          const [l, r] = a[0] < b[0] ? [a, b] : [b, a];
          extra.push(L_(l[0], l[1], r[0], r[1], 'fold'));
          tabOn(Math.abs(a[1]) < 1e-6 ? r : l, Math.abs(a[1]) < 1e-6 ? l : r, 1);
          return false;
        }
        if (vert && Math.abs(a[0] - n * side) < 1e-6) { extra.push(L_(a[0], a[1], b[0], b[1], 'fold')); tabOn([a[0], Math.max(a[1], b[1])], [a[0], Math.min(a[1], b[1])], 1); return false; }
        return true;
      });
      return TC.joinSegments(keep.concat(extra));
    },
    notes: 'Cambia el número de lados para hexágono, octágono, etc. La tapa y la base cuelgan del primer panel.'
  });

  /* ---------- 8. Pirámide ---------- */
  reg('pyramid', {
    name: 'Pirámide', cat: 'Geométricas', code: 'Paramétrica',
    params: [int('n', 'Lados de la base', 4, 3, 12), num('side', 'Lado de la base', 60), num('h', 'Altura', 70), num('tab', 'Pestañas', 7)],
    build(p) {
      const n = p.n, base = regPoly(0, 0, p.side, n, Math.PI / 2 + Math.PI / n);
      const ap = p.side / (2 * Math.tan(Math.PI / n)), sl = Math.hypot(p.h, ap);
      const faces = [base];
      base.forEach((a, i) => {
        const b = base[(i + 1) % n], mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2, d = Math.hypot(mx, my);
        faces.push([a, [mx / d * (d + sl), my / d * (d + sl)], b]);
      });
      return polyNet(faces, { tab: p.tab });
    }
  });

  /* ---------- 9. Sólidos platónicos ---------- */
  function triStrip(nTop, side) {
    const h = side * Math.sqrt(3) / 2, faces = [];
    for (let i = 0; i < nTop; i++) {
      faces.push([[i * side, 0], [(i + 1) * side, 0], [(i + 0.5) * side, h]]);
      faces.push([[(i + 1) * side, 0], [(i + 1.5) * side, h], [(i + 0.5) * side, h]]);
    }
    return faces;
  }
  reg('platonic', {
    name: 'Sólidos platónicos', cat: 'Geométricas', code: 'Tetraedro · Cubo · Octaedro · Icosaedro',
    params: [{ k: 'kind', label: 'Sólido', type: 'select', def: 'cube', opts: [['tetra', 'Tetraedro'], ['cube', 'Cubo'], ['octa', 'Octaedro'], ['ico', 'Icosaedro']] }, num('side', 'Arista', 50), num('tab', 'Pestañas', 7)],
    build(p) {
      const s = p.side, h = s * Math.sqrt(3) / 2; let faces;
      if (p.kind === 'cube') {
        const sq = (x, y) => [[x, y], [x + s, y], [x + s, y + s], [x, y + s]];
        faces = [sq(s, 0), sq(s, s), sq(s, 2 * s), sq(s, 3 * s), sq(0, s), sq(2 * s, s)];
      } else if (p.kind === 'tetra') {
        faces = [[[0, 0], [s, 0], [s / 2, h]], [[s, 0], [2 * s, 0], [1.5 * s, h]], [[s / 2, h], [1.5 * s, h], [s, 0]], [[s / 2, h], [1.5 * s, h], [s, 2 * h]]];
      } else if (p.kind === 'octa') {
        faces = triStrip(4, s);
      } else {
        faces = triStrip(5, s);
        for (let i = 0; i < 5; i++) {
          faces.push([[(i + 0.5) * s, h], [(i + 1.5) * s, h], [(i + 1) * s, 2 * h]]);
          faces.push([[i * s, 0], [(i + 1) * s, 0], [(i + 0.5) * s, -h]]);
        }
      }
      return polyNet(faces, { tab: p.tab });
    }
  });

  /* ---------- 10. Caja de madera con uniones dentadas (láser / fresa) ---------- */
  function fingerPanel(w, h, types, t, n4) {
    // types: [abajo, derecha, arriba, izquierda] en 'A' (esquinas llenas), 'B' (esquinas recortadas) o 'F' (liso)
    const corners = [[0, 0], [w, 0], [w, h], [0, h]], lens = [w, h, w, h];
    const dirs = [[1, 0], [0, 1], [-1, 0], [0, -1]], inn = [[0, 1], [-1, 0], [0, -1], [1, 0]];
    const pts = [];
    for (let e = 0; e < 4; e++) {
      const type = types[e], prevB = types[(e + 3) % 4] === 'B', nextB = types[(e + 1) % 4] === 'B';
      const len = lens[e], n = type === 'F' ? 1 : n4[e];
      const s0 = prevB ? t : 0, s1 = len - (nextB ? t : 0);
      const [cx, cy] = corners[e], [dx, dy] = dirs[e], [ix, iy] = inn[e];
      for (let k = 0; k < n; k++) {
        const a = Math.max(s0, k * len / n), b = Math.min(s1, (k + 1) * len / n);
        if (b <= a) continue;
        const inset = type === 'F' ? 0 : ((k % 2 === 0) === (type === 'B') ? t : 0);
        pts.push([cx + dx * a + ix * inset, cy + dy * a + iy * inset]);
        pts.push([cx + dx * b + ix * inset, cy + dy * b + iy * inset]);
      }
    }
    const clean = pts.filter((q, i) => { const r = pts[(i + 1) % pts.length]; return Math.hypot(q[0] - r[0], q[1] - r[1]) > 1e-6; });
    return clean;
  }
  reg('fingerbox', {
    name: 'Caja de madera con uniones dentadas', cat: 'Láser / CNC (madera, MDF, acrílico)', code: 'Finger joint',
    params: [num('L', 'Largo exterior', 120), num('W', 'Ancho exterior', 80), num('H', 'Alto exterior', 60), num('t', 'Grosor del material', 3, { step: 0.1 }), num('fw', 'Ancho de diente', 10), num('kerf', 'Kerf (ancho de corte)', 0.15, { step: 0.01, min: 0 }), bool('lid', 'Con tapa', false)],
    build(p) {
      const { L, W, H, t } = p, nOf = len => { let n = Math.max(3, Math.round(len / p.fw)); if (n % 2 === 0) n++; return n; };
      const top = p.lid ? 'A' : 'F';
      const panels = [
        { name: 'Fondo', w: L, h: W, types: ['B', 'B', 'B', 'B'] },
        { name: 'Frente', w: L, h: H, types: ['A', 'A', top, 'A'] },
        { name: 'Atrás', w: L, h: H, types: ['A', 'A', top, 'A'] },
        { name: 'Lado', w: W, h: H, types: ['A', 'B', top === 'F' ? 'F' : 'A', 'B'] },
        { name: 'Lado', w: W, h: H, types: ['A', 'B', top === 'F' ? 'F' : 'A', 'B'] }
      ];
      if (p.lid) panels.push({ name: 'Tapa', w: L, h: W, types: ['B', 'B', 'B', 'B'] });
      const items = []; let x = 0, y = 0, rowH = 0; const maxW = Math.max(L * 2.2, 250);
      for (const pn of panels) {
        if (x + pn.w > maxW) { x = 0; y += rowH + 6; rowH = 0; }
        let pts = fingerPanel(pn.w, pn.h, pn.types, t, [nOf(pn.w), nOf(pn.h), nOf(pn.w), nOf(pn.h)]);
        if (p.kerf > 0) pts = TC.offsetPolygon(pts, p.kerf / 2);
        items.push(P(pts.map(q => [q[0] + x, q[1] + y]), 'cut', true));
        x += pn.w + 6; rowH = Math.max(rowH, pn.h);
      }
      return items;
    },
    notes: 'Medidas exteriores. Ajusta el kerf con una pieza de prueba: si queda flojo, súbelo; si no entra, bájalo.'
  });

  /* ---------- 11. PRO: cubo pop-up con liga ---------- */
  reg('popcube', {
    name: 'Cubo pop-up con liga', cat: 'PRO con mecanismo', code: 'Liga elástica',
    params: [num('s', 'Lado del cubo', 70), num('n', 'Muesca para la liga', 4, { step: 0.5 })],
    build(p) {
      const s = p.s, nc = p.n, items = [];
      const piece = (ox) => {
        // tira de 3 caras con muescas en V en las esquinas exteriores para enganchar la liga
        const P2 = [[ox, nc], [ox + nc, 0], [ox + 3 * s - nc, 0], [ox + 3 * s, nc], [ox + 3 * s, s - nc], [ox + 3 * s - nc, s], [ox + nc, s], [ox, s - nc]];
        items.push(P(P2, 'cut', true));
        items.push(L_(ox + s, 0, ox + s, s, 'fold')); items.push(L_(ox + 2 * s, 0, ox + 2 * s, s, 'fold'));
      };
      piece(0); piece(3 * s + 15);
      return items;
    },
    notes: 'Arma las dos tiras en U cruzadas formando el cubo. Pasa una liga en diagonal enganchada en las muescas de las esquinas. Aplánalo en un sobre: al sacarlo, salta solo. (Modelo experimental: ajusta la liga.)'
  });

  /* ---------- 12. PRO: caja que se abre en 4 pétalos ---------- */
  reg('petalbox', {
    name: 'Caja sorpresa que se abre (4 lados)', cat: 'PRO con mecanismo', code: 'Liga elástica',
    params: [num('s', 'Lado', 80), num('H', 'Alto', 80), num('hole', 'Agujero para liga', 3, { step: 0.5 }), Object.assign({}, thick)],
    build(p) {
      const { s, H } = p, items = [];
      // cruz: base al centro y 4 paredes que caen
      items.push(P([[0, 0], [0, -H], [s, -H], [s, 0]], 'cut', false));
      items.push(P([[s, 0], [s + H, 0], [s + H, s], [s, s]], 'cut', false));
      items.push(P([[s, s], [s, s + H], [0, s + H], [0, s]], 'cut', false));
      items.push(P([[0, s], [-H, s], [-H, 0], [0, 0]], 'cut', false));
      items.push(TC.rect(0, 0, s, s, 'fold'));
      const r = p.hole / 2, e = Math.min(8, H * 0.1);
      // dos agujeros cerca de la punta de cada pared para la liga + 4 en la base
      [[s / 2 - e, -H + e], [s / 2 + e, -H + e], [s + H - e, s / 2 - e], [s + H - e, s / 2 + e], [s / 2 - e, s + H - e], [s / 2 + e, s + H - e], [-H + e, s / 2 - e], [-H + e, s / 2 + e],
        [e, e], [s - e, e], [s - e, s - e], [e, s - e]].forEach(([x, y]) => items.push(TC.circle(x, y, r, 'cut')));
      // tapa (charola)
      const lid = TC.translate(tray(s + 3 * p.t, s + 3 * p.t, 18, p.t, 0, 0), s + H + 40, -s / 2);
      return TC.joinSegments(items).concat(lid);
    },
    notes: 'Une con ligas las esquinas de cada pared hacia la base (pasan por los agujeros). Con la tapa puesta las paredes quedan de pie; al quitarla, se abren hacia afuera. Pega fotos o un regalo al centro.'
  });

  /* ---------- 13. PRO: funda de tarjeta con jalador ---------- */
  reg('cardsleeve', {
    name: 'Funda de tarjeta con jalador', cat: 'PRO con mecanismo', code: 'Tira de jalón',
    params: [num('w', 'Ancho de tarjeta', 86), num('h', 'Alto de tarjeta', 54), num('c', 'Holgura', 2, { step: 0.5 })],
    build(p) {
      const w = p.w + p.c, h = p.h + p.c, g = 8, items = [];
      // funda: frente + vuelta + pestañas
      items.push(P([[0, 0], [w, 0], [w + g, 3], [w + g, h - 3], [w, h], [w, 2 * h], [0, 2 * h], [0, h], [-g, h - 3], [-g, 3]], 'cut', true));
      items.push(L_(0, h, w, h, 'fold')); items.push(L_(w, 0, w, h, 'fold')); items.push(L_(0, 0, 0, h, 'fold'));
      items.push(P(TC.arcPts(w / 2, 2 * h, 10, Math.PI, 2 * Math.PI), 'cut'));
      // tira de jalón: una base que empuja la tarjeta y una lengüeta que sale de la funda
      const ox = w + 40; const tw = w - 6;
      items.push(P([[ox, 0], [ox + tw, 0], [ox + tw, h - 4], [ox + tw / 2 + 12, h - 4], [ox + tw / 2 + 12, h + 30], [ox + tw / 2 - 12, h + 30], [ox + tw / 2 - 12, h - 4], [ox, h - 4]], 'cut', true));
      items.push(L_(ox, 12, ox + tw, 12, 'fold'));
      return items;
    },
    notes: 'La tarjeta descansa sobre el doblez de la tira; al jalar la lengüeta, la tarjeta sube y asoma por la muesca. Basado en el mecanismo de fundas de tarjeta.'
  });
})(window.TC);
