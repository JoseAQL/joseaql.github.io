/* TallerCNC - modo proyector.
 * 1) Plantilla 1:1 para cortar a mano.  2) Sobre la máquina: corrige perspectiva con 4 esquinas
 * y muestra lo que se va a cortar (y dónde está la herramienta) ANTES de cortar.  Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const load = () => { try { return JSON.parse(localStorage.getItem('tc.proj') || '{}'); } catch (e) { return {}; } };
  const cfg = Object.assign({ pxPerMM: 3.78, ox: 40, oy: 40, rot: 0, mirror: false, quad: null, grid: true, lineW: 2 }, load());
  const save = () => { try { localStorage.setItem('tc.proj', JSON.stringify(cfg)); } catch (e) { /* */ } };

  /** Homografía de 4 puntos (src -> dst). */
  function homography(src, dst) {
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    // eliminación gaussiana
    for (let c = 0; c < 8; c++) {
      let p = c; for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      [A[c], A[p]] = [A[p], A[c]]; [b[c], b[p]] = [b[p], b[c]];
      for (let r = 0; r < 8; r++) if (r !== c) { const f = A[r][c] / A[c][c]; for (let k = c; k < 8; k++) A[r][k] -= f * A[c][k]; b[r] -= f * b[c]; }
    }
    const h = b.map((v, i) => v / A[i][i]);
    return ([x, y]) => { const w = h[6] * x + h[7] * y + 1; return [(h[0] * x + h[1] * y + h[2]) / w, (h[3] * x + h[4] * y + h[5]) / w]; };
  }
  TC.homography = homography;

  const Proj = {
    cfg, mode: 'plantilla', calibrating: false, win: null, el: null, canvas: null, drag: null,
    open(mode) {
      this.mode = mode || 'plantilla';
      if (!this.el) {
        this.el = document.createElement('div'); this.el.id = 'projector';
        this.el.innerHTML = `<canvas></canvas><div class="proj-help"></div>`;
        document.body.appendChild(this.el); this.canvas = this.el.querySelector('canvas');
        this.bindInput(this.canvas, window);
      }
      this.el.style.display = 'block';
      this.el.requestFullscreen?.().catch(() => {});
      this.help(); this.loop();
    },
    openWindow(mode) {
      this.mode = mode || 'plantilla';
      const w = window.open('', 'tallercnc_proyector', 'width=1024,height=768');
      if (!w) { TC.toast('El navegador bloqueó la ventana. Permite ventanas emergentes.', 'warn'); return; }
      w.document.title = 'TallerCNC · Proyector';
      w.document.body.style.cssText = 'margin:0;background:#000;overflow:hidden';
      w.document.body.innerHTML = '<canvas style="display:block;width:100vw;height:100vh"></canvas><div style="position:fixed;left:8px;bottom:8px;color:#888;font:12px sans-serif">Arrastra esta ventana al proyector y presiona F para pantalla completa. Esc para salir.</div>';
      this.win = w; this.canvas = w.document.querySelector('canvas'); this.bindInput(this.canvas, w);
      w.addEventListener('keydown', e => { if (e.key === 'f' || e.key === 'F') w.document.documentElement.requestFullscreen?.(); });
      this.loop();
    },
    close() {
      if (this.el) this.el.style.display = 'none';
      if (document.fullscreenElement) document.exitFullscreen?.();
      this.calibrating = false;
    },
    help() {
      const h = this.el && this.el.querySelector('.proj-help'); if (!h) return;
      h.innerHTML = this.mode === 'maquina'
        ? `<b>Proyector sobre la máquina</b> · C: calibrar esquinas (${this.calibrating ? 'ACTIVO: arrastra los 4 puntos a las esquinas reales del área de trabajo' : 'apagado'}) · G: cuadrícula 10 mm · Esc: salir`
        : `<b>Plantilla 1:1</b> · Arrastra para mover · Q/E: girar 90° · M: espejo · +/−: ajustar escala · R: regla de 100 mm · Esc: salir`;
    },
    bindInput(cv, w) {
      const doc = w.document;
      cv.addEventListener('mousedown', e => {
        const p = [e.offsetX, e.offsetY];
        if (this.mode === 'maquina' && this.calibrating) {
          const q = this.getQuad(cv); let bi = -1, bd = 40;
          q.forEach((c, i) => { const d = Math.hypot(c[0] - p[0], c[1] - p[1]); if (d < bd) { bd = d; bi = i; } });
          if (bi >= 0) this.drag = { corner: bi };
        } else this.drag = { start: p, ox: cfg.ox, oy: cfg.oy };
      });
      cv.addEventListener('mousemove', e => {
        if (!this.drag) return;
        if (this.drag.corner !== undefined) { const q = this.getQuad(cv); q[this.drag.corner] = [e.offsetX, e.offsetY]; cfg.quad = q.map(([x, y]) => [x / cv.width, y / cv.height]); }
        else { cfg.ox = this.drag.ox + e.offsetX - this.drag.start[0]; cfg.oy = this.drag.oy + e.offsetY - this.drag.start[1]; }
      });
      w.addEventListener('mouseup', () => { if (this.drag) save(); this.drag = null; });
      doc.addEventListener('keydown', e => {
        const k = e.key;
        if (k === 'Escape') { if (w !== window) w.close(); else this.close(); }
        else if (k === 'c' || k === 'C') { this.calibrating = !this.calibrating; this.help(); }
        else if (k === 'g' || k === 'G') cfg.grid = !cfg.grid;
        else if (k === 'm' || k === 'M') cfg.mirror = !cfg.mirror;
        else if (k === 'q' || k === 'Q') cfg.rot = (cfg.rot + 270) % 360;
        else if (k === 'e' || k === 'E') cfg.rot = (cfg.rot + 90) % 360;
        else if (k === '+' || k === '=') cfg.pxPerMM *= 1.002;
        else if (k === '-') cfg.pxPerMM /= 1.002;
        else if (k === 'r' || k === 'R') this.ruler = !this.ruler;
        else if (k.startsWith('Arrow')) { const s = e.shiftKey ? 10 : 1; if (k === 'ArrowLeft') cfg.ox -= s; if (k === 'ArrowRight') cfg.ox += s; if (k === 'ArrowUp') cfg.oy -= s; if (k === 'ArrowDown') cfg.oy += s; }
        else return;
        save(); this.help();
      });
    },
    getQuad(cv) {
      if (cfg.quad) return cfg.quad.map(([x, y]) => [x * cv.width, y * cv.height]);
      const m = 60; return [[m, cv.height - m], [cv.width - m, cv.height - m], [cv.width - m, m], [m, m]];
    },
    loop() {
      if (this._raf) return;
      const tick = () => {
        this._raf = null;
        const open = (this.el && this.el.style.display !== 'none') || (this.win && !this.win.closed);
        if (!open) return;
        this.draw(); this._raf = requestAnimationFrame(tick);
      };
      this._raf = requestAnimationFrame(tick);
    },
    draw() {
      const cv = this.canvas, own = cv.ownerDocument.defaultView;
      const W = own.innerWidth, H = own.innerHeight; if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      const ctx = cv.getContext('2d'); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
      const items = TC.app ? TC.app.items() : [];
      let map;
      const M = TC.shop.machine;
      if (this.mode === 'maquina') {
        const q = this.getQuad(cv); map = homography([[0, 0], [M.bedW, 0], [M.bedW, M.bedH], [0, M.bedH]], q);
        ctx.strokeStyle = '#333'; ctx.lineWidth = 1;
        if (cfg.grid) { ctx.beginPath(); for (let x = 0; x <= M.bedW; x += 10) { const a = map([x, 0]), b = map([x, M.bedH]); ctx.moveTo(...a); ctx.lineTo(...b); } for (let y = 0; y <= M.bedH; y += 10) { const a = map([0, y]), b = map([M.bedW, y]); ctx.moveTo(...a); ctx.lineTo(...b); } ctx.stroke(); }
        ctx.strokeStyle = '#888'; ctx.lineWidth = 2; ctx.beginPath(); q.forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...p)); ctx.closePath(); ctx.stroke();
        if (this.calibrating) q.forEach((p, i) => { ctx.fillStyle = '#ffd400'; ctx.beginPath(); ctx.arc(p[0], p[1], 10, 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = '14px sans-serif'; ctx.fillText(['0,0', 'X máx', 'X,Y máx', 'Y máx'][i], p[0] + 14, p[1] - 10); });
        // posición de la herramienta en vivo
        const g = TC.grbl; if (g && g.port) { const p = map([g.status.wpos[0], g.status.wpos[1]]); ctx.strokeStyle = '#ffd400'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(p[0] - 15, p[1]); ctx.lineTo(p[0] + 15, p[1]); ctx.moveTo(p[0], p[1] - 15); ctx.lineTo(p[0], p[1] + 15); ctx.stroke(); }
        const job = TC.app ? TC.app.jobOffset() : [0, 0]; const m0 = map; map = p => m0([p[0] + job[0], p[1] + job[1]]);
      } else {
        const b = TC.bbox(items), s = cfg.pxPerMM, a = cfg.rot * Math.PI / 180, c = Math.cos(a), sn = Math.sin(a);
        map = ([x, y]) => { let u = (x - b.x0), v = (y - b.y0); if (cfg.mirror) u = b.w - u; const ru = u * c - v * sn, rv = u * sn + v * c; return [cfg.ox + ru * s, H - cfg.oy - rv * s]; };
        if (this.ruler) {
          ctx.strokeStyle = '#ffd400'; ctx.lineWidth = 2; ctx.beginPath(); const y = 30, x0 = 30; ctx.moveTo(x0, y); ctx.lineTo(x0 + 100 * s, y);
          for (let i = 0; i <= 100; i += 10) { ctx.moveTo(x0 + i * s, y); ctx.lineTo(x0 + i * s, y + (i % 50 ? 8 : 16)); } ctx.stroke();
          ctx.fillStyle = '#ffd400'; ctx.font = '14px sans-serif'; ctx.fillText(`100 mm — mídela con una regla y ajusta con +/− (${s.toFixed(3)} px/mm)`, x0, y + 34);
        }
      }
      ctx.lineWidth = cfg.lineW; ctx.lineJoin = 'round';
      const colors = { cut: '#ffffff', fold: '#40ff80', valley: '#ffb020', engrave: '#40a0ff', ref: '#666' };
      for (const it of items) {
        if (it.type === 'path') {
          ctx.strokeStyle = colors[it.layer] || '#fff'; ctx.setLineDash(it.layer === 'fold' ? [10, 6] : it.layer === 'valley' ? [3, 5] : []);
          ctx.beginPath(); it.pts.forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...map(p))); if (it.closed) ctx.closePath(); ctx.stroke();
        } else if ((it.type === 'raster' || it.type === 'heightmap') && it.canvas && this.mode !== 'maquina') {
          const p0 = map([it.x, it.y + it.h]), p1 = map([it.x + it.w, it.y]); ctx.globalAlpha = 0.6; ctx.drawImage(it.canvas, p0[0], p0[1], p1[0] - p0[0], p1[1] - p0[1]); ctx.globalAlpha = 1;
        } else if (it.type === 'raster' || it.type === 'heightmap' || it.type === 'drills') {
          const b = it.type === 'drills' ? TC.bbox(it.holes.map(h => TC.path([[h.x, h.y]]))) : { x0: it.x, y0: it.y, x1: it.x + it.w, y1: it.y + it.h };
          ctx.strokeStyle = '#40a0ff'; ctx.setLineDash([6, 4]); ctx.beginPath(); [[b.x0, b.y0], [b.x1, b.y0], [b.x1, b.y1], [b.x0, b.y1]].forEach((p, i) => ctx[i ? 'lineTo' : 'moveTo'](...map(p))); ctx.closePath(); ctx.stroke();
          if (it.type === 'drills') { ctx.setLineDash([]); it.holes.forEach(h => { const p = map([h.x, h.y]); ctx.beginPath(); ctx.arc(p[0], p[1], 3, 0, 7); ctx.stroke(); }); }
        }
      }
      ctx.setLineDash([]);
    }
  };
  TC.projector = Proj;
})(window.TC);
