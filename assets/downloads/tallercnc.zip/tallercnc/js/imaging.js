/* TallerCNC - imágenes (grabado y relieve), modelos STL (positivo/negativo) y PCB (Gerber/Excellon).
 * Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  /* ================= IMAGEN ================= */
  /** Convierte una imagen en un objeto ráster para láser. */
  TC.imageToRaster = function (img, o) {
    const res = o.res || 10; // puntos por mm
    const W = Math.max(1, Math.round(o.w * res)), H = Math.max(1, Math.round(o.h * res));
    const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H); ctx.drawImage(img, 0, 0, W, H);
    const id = ctx.getImageData(0, 0, W, H), d = id.data, g = new Float32Array(W * H);
    for (let i = 0; i < W * H; i++) {
      let v = (0.299 * d[4 * i] + 0.587 * d[4 * i + 1] + 0.114 * d[4 * i + 2]) / 255;
      v = (v - 0.5) * (o.contrast ?? 1) + 0.5 + (o.brightness ?? 0); v = Math.min(1, Math.max(0, v));
      if (o.gamma && o.gamma !== 1) v = Math.pow(v, o.gamma);
      if (o.invert) v = 1 - v; g[i] = v;
    }
    const mode = o.mode || 'floyd';
    if (mode === 'threshold') for (let i = 0; i < g.length; i++) g[i] = g[i] < (o.threshold ?? 0.5) ? 0 : 1;
    else if (mode === 'floyd' || mode === 'jarvis') {
      const K = mode === 'floyd' ? [[1, 0, 7], [-1, 1, 3], [0, 1, 5], [1, 1, 1]].map(k => [k[0], k[1], k[2] / 16])
        : [[1, 0, 7], [2, 0, 5], [-2, 1, 3], [-1, 1, 5], [0, 1, 7], [1, 1, 5], [2, 1, 3], [-2, 2, 1], [-1, 2, 3], [0, 2, 5], [1, 2, 3], [2, 2, 1]].map(k => [k[0], k[1], k[2] / 48]);
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const i = y * W + x, old = g[i], nw = old < 0.5 ? 0 : 1, err = old - nw; g[i] = nw;
        for (const [dx, dy, f] of K) { const xx = x + dx, yy = y + dy; if (xx >= 0 && xx < W && yy < H) g[yy * W + xx] += err * f; }
      }
    } // 'gray' = potencia variable
    for (let i = 0; i < W * H; i++) { const v = Math.round(Math.min(1, Math.max(0, g[i])) * 255); d[4 * i] = d[4 * i + 1] = d[4 * i + 2] = v; d[4 * i + 3] = 255; }
    ctx.putImageData(id, 0, 0);
    return { type: 'raster', canvas: c, x: 0, y: 0, w: o.w, h: o.h, pmin: o.pmin ?? 0, pmax: o.pmax ?? 60, speed: o.speed ?? 1500, overscan: 2 };
  };

  /** Imagen -> mapa de alturas (relieve con fresa). Claro = alto (o al revés si invert). */
  TC.imageToHeightmap = function (img, o) {
    const gw = Math.max(2, Math.round(o.w * (o.res || 4))), gh = Math.max(2, Math.round(o.h * (o.res || 4)));
    const c = document.createElement('canvas'); c.width = gw; c.height = gh; const ctx = c.getContext('2d');
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, gw, gh); ctx.drawImage(img, 0, 0, gw, gh);
    const d = ctx.getImageData(0, 0, gw, gh).data, z = new Float32Array(gw * gh);
    for (let j = 0; j < gh; j++) for (let i = 0; i < gw; i++) {
      const k = ((gh - 1 - j) * gw + i) * 4; let v = (0.299 * d[k] + 0.587 * d[k + 1] + 0.114 * d[k + 2]) / 255;
      if (o.invert) v = 1 - v; z[j * gw + i] = v;
    }
    if (o.blur) blurZ(z, gw, gh, o.blur);
    return mkHeightmap(z, gw, gh, o);
  };
  function blurZ(z, w, h, n) { const t = new Float32Array(z.length); for (let k = 0; k < n; k++) { for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) { let s = 0, c = 0; for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) { const x = i + di, y = j + dj; if (x >= 0 && y >= 0 && x < w && y < h) { s += z[y * w + x]; c++; } } t[j * w + i] = s / c; } z.set(t); } }
  function mkHeightmap(z, gw, gh, o) {
    const c = document.createElement('canvas'); c.width = gw; c.height = gh; const ctx = c.getContext('2d'), id = ctx.createImageData(gw, gh);
    for (let j = 0; j < gh; j++) for (let i = 0; i < gw; i++) { const v = Math.round(z[j * gw + i] * 255), k = ((gh - 1 - j) * gw + i) * 4; id.data[k] = id.data[k + 1] = id.data[k + 2] = v; id.data[k + 3] = 255; }
    ctx.putImageData(id, 0, 0);
    return { type: 'heightmap', z, gw, gh, x: 0, y: 0, w: o.w, h: o.h, depth: o.depth || 3, tool: o.tool || 'bola', stepover: o.stepover ?? 0.2, stepdown: o.stepdown || 1, feed: o.feed || 800, plunge: o.plunge || 200, canvas: c };
  }

  /* ================= STL ================= */
  TC.parseSTL = function (buf) {
    const dv = new DataView(buf), tris = [];
    const n = buf.byteLength >= 84 ? dv.getUint32(80, true) : 0;
    if (buf.byteLength === 84 + n * 50 && n > 0) {
      for (let i = 0; i < n; i++) { const o = 84 + i * 50 + 12, t = []; for (let v = 0; v < 3; v++) t.push([dv.getFloat32(o + v * 12, true), dv.getFloat32(o + v * 12 + 4, true), dv.getFloat32(o + v * 12 + 8, true)]); tris.push(t); }
    } else {
      const txt = new TextDecoder().decode(buf); const re = /vertex\s+(\S+)\s+(\S+)\s+(\S+)/g; let m, cur = [];
      while ((m = re.exec(txt))) { cur.push([+m[1], +m[2], +m[3]]); if (cur.length === 3) { tris.push(cur); cur = []; } }
    }
    return tris;
  };
  /** STL -> mapa de alturas visto desde arriba. mode: 'positivo' (sobresale) o 'negativo' (molde). */
  TC.stlToHeightmap = function (tris, o) {
    let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity, z1 = -Infinity;
    const rot = o.axis === 'y' ? (p => [p[0], p[2], p[1]]) : o.axis === 'x' ? (p => [p[1], p[2], p[0]]) : (p => p);
    tris = tris.map(t => t.map(rot));
    tris.forEach(t => t.forEach(([x, y, z]) => { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); z0 = Math.min(z0, z); z1 = Math.max(z1, z); }));
    const sx = x1 - x0 || 1, sy = y1 - y0 || 1, sz = z1 - z0 || 1;
    const w = o.w || sx, h = o.h || (w * sy / sx), res = o.res || 4;
    const gw = Math.max(2, Math.round(w * res)), gh = Math.max(2, Math.round(h * res)), zb = new Float32Array(gw * gh).fill(-1);
    for (const t of tris) {
      const P = t.map(([x, y, z]) => [(x - x0) / sx * (gw - 1), (y - y0) / sy * (gh - 1), (z - z0) / sz]);
      const minx = Math.max(0, Math.floor(Math.min(P[0][0], P[1][0], P[2][0]))), maxx = Math.min(gw - 1, Math.ceil(Math.max(P[0][0], P[1][0], P[2][0])));
      const miny = Math.max(0, Math.floor(Math.min(P[0][1], P[1][1], P[2][1]))), maxy = Math.min(gh - 1, Math.ceil(Math.max(P[0][1], P[1][1], P[2][1])));
      const [a, b, c] = P, den = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1]); if (Math.abs(den) < 1e-12) continue;
      for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
        const l1 = ((b[1] - c[1]) * (x - c[0]) + (c[0] - b[0]) * (y - c[1])) / den, l2 = ((c[1] - a[1]) * (x - c[0]) + (a[0] - c[0]) * (y - c[1])) / den, l3 = 1 - l1 - l2;
        if (l1 < -1e-4 || l2 < -1e-4 || l3 < -1e-4) continue;
        const z = l1 * a[2] + l2 * b[2] + l3 * c[2]; const k = y * gw + x; if (z > zb[k]) zb[k] = z;
      }
    }
    const z = new Float32Array(gw * gh);
    for (let k = 0; k < z.length; k++) { const v = zb[k] < 0 ? 0 : zb[k]; z[k] = o.mode === 'negativo' ? (zb[k] < 0 ? 1 : 1 - v) : v; }
    const hm = mkHeightmap(z, gw, gh, Object.assign({}, o, { w, h }));
    hm.info = `${tris.length} triángulos · modelo ${sx.toFixed(1)}×${sy.toFixed(1)}×${sz.toFixed(1)} mm`;
    return hm;
  };

  /* ================= PCB: GERBER + EXCELLON ================= */
  TC.parseGerber = function (text) {
    const ap = {}; let cur = null, x = 0, y = 0, interp = 1, unit = 1, fmt = { xi: 2, xd: 4, yi: 2, yd: 4 }, region = false, regionPts = [], quadrant = 'multi';
    const prims = []; // {t:'line',a,b,w} {t:'flash',x,y,ap} {t:'region',pts}
    const coord = (s, dec) => { if (s.includes('.')) return parseFloat(s) * unit; const neg = s[0] === '-'; const v = parseInt(s.replace(/^[+-]/, ''), 10) / 10 ** dec; return (neg ? -v : v) * unit; };
    const body = text.replace(/\r/g, '');
    const tokens = body.match(/%[^%]*%|[^*%\n]+\*/g) || [];
    for (let tk of tokens) {
      tk = tk.trim();
      if (tk[0] === '%') {
        const inner = tk.slice(1, -1);
        for (const cmd of inner.split('*').filter(Boolean)) {
          if (cmd.startsWith('FS')) { const m = /X(\d)(\d)Y(\d)(\d)/.exec(cmd); if (m) fmt = { xi: +m[1], xd: +m[2], yi: +m[3], yd: +m[4] }; }
          else if (cmd === 'MOIN') unit = 25.4; else if (cmd === 'MOMM') unit = 1;
          else if (cmd.startsWith('AD')) {
            const m = /ADD(\d+)([A-Za-z_][\w.]*),?(.*)/.exec(cmd); if (!m) continue;
            const ps = m[3].split('X').map(parseFloat);
            const t = m[2]; ap[m[1]] = t === 'C' ? { s: 'C', d: ps[0] * unit } : t === 'R' ? { s: 'R', w: ps[0] * unit, h: (ps[1] ?? ps[0]) * unit } : t === 'O' ? { s: 'O', w: ps[0] * unit, h: (ps[1] ?? ps[0]) * unit } : t === 'P' ? { s: 'P', d: ps[0] * unit, n: ps[1] || 4 } : { s: 'C', d: (isNaN(ps[0]) ? 0.3 : ps[0]) * unit, macro: t };
          }
        }
        continue;
      }
      let c = tk.slice(0, -1);
      if (c.startsWith('G04')) continue;
      if (/^G36/.test(c)) { region = true; regionPts = []; continue; }
      if (/^G37/.test(c)) { region = false; if (regionPts.length > 2) prims.push({ t: 'region', pts: regionPts }); regionPts = []; continue; }
      if (/^G7[45]/.test(c)) { quadrant = c.startsWith('G74') ? 'single' : 'multi'; continue; }
      const gm = /^G0?([123])(?!\d)/.exec(c); if (gm) { interp = +gm[1]; c = c.slice(gm[0].length); }
      const dsel = /^(?:G54)?D(\d+)$/.exec(c); if (dsel && +dsel[1] >= 10) { cur = dsel[1]; continue; }
      const m = /^(?:X([+-]?[\d.]+))?(?:Y([+-]?[\d.]+))?(?:I([+-]?[\d.]+))?(?:J([+-]?[\d.]+))?D0?([123])$/.exec(c);
      if (!m) continue;
      const nx = m[1] !== undefined ? coord(m[1], fmt.xd) : x, ny = m[2] !== undefined ? coord(m[2], fmt.yd) : y;
      const I = m[3] !== undefined ? coord(m[3], fmt.xd) : 0, J = m[4] !== undefined ? coord(m[4], fmt.yd) : 0, op = +m[5];
      let seg = [[nx, ny]];
      if (interp !== 1 && (I || J)) {
        const cx = x + I, cy = y + J, r = Math.hypot(I, J); let a0 = Math.atan2(y - cy, x - cx), a1 = Math.atan2(ny - cy, nx - cx);
        if (interp === 3) { if (a1 <= a0) a1 += 2 * Math.PI; } else { if (a1 >= a0) a1 -= 2 * Math.PI; }
        seg = TC.arcPts(cx, cy, r, a0, a1).slice(1); void quadrant;
      }
      if (op === 1) {
        if (region) { if (!regionPts.length) regionPts.push([x, y]); regionPts.push(...seg); }
        else { let p = [x, y]; for (const q of seg) { prims.push({ t: 'line', a: p, b: q, ap: ap[cur] }); p = q; } }
      } else if (op === 2) { if (region && regionPts.length > 2) { prims.push({ t: 'region', pts: regionPts }); regionPts = []; } }
      else if (op === 3) prims.push({ t: 'flash', x: nx, y: ny, ap: ap[cur] });
      x = nx; y = ny;
    }
    let bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
    const grow = (px, py, r = 0) => { bx0 = Math.min(bx0, px - r); by0 = Math.min(by0, py - r); bx1 = Math.max(bx1, px + r); by1 = Math.max(by1, py + r); };
    let minW = Infinity;
    prims.forEach(p => { if (p.t === 'line') { const r = apR(p.ap); grow(p.a[0], p.a[1], r); grow(p.b[0], p.b[1], r); if (p.ap && p.ap.s === 'C' && p.ap.d > 0) minW = Math.min(minW, p.ap.d); } else if (p.t === 'flash') grow(p.x, p.y, apR(p.ap)); else p.pts.forEach(q => grow(q[0], q[1])); });
    return { prims, bbox: { x0: bx0, y0: by0, x1: bx1, y1: by1 }, minTrace: isFinite(minW) ? minW : null };
  };
  const apR = a => !a ? 0.1 : a.s === 'C' || a.s === 'P' ? a.d / 2 : Math.hypot(a.w, a.h) / 2;

  /** Pinta el cobre en un canvas (blanco = cobre). */
  TC.renderGerber = function (g, res, bb, mirror) {
    const W = Math.ceil((bb.x1 - bb.x0) * res) + 2, H = Math.ceil((bb.y1 - bb.y0) * res) + 2;
    const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); ctx.fillStyle = ctx.strokeStyle = '#fff'; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const X = x => mirror ? (bb.x1 - x) * res + 1 : (x - bb.x0) * res + 1, Y = y => (bb.y1 - y) * res + 1;
    for (const p of g.prims) {
      if (p.t === 'line') {
        const a = p.ap || { s: 'C', d: 0.2 };
        if (a.s === 'R') { ctx.lineCap = 'square'; ctx.lineWidth = Math.max(a.w, a.h) * res; } else { ctx.lineCap = 'round'; ctx.lineWidth = (a.d || Math.min(a.w, a.h)) * res; }
        ctx.beginPath(); ctx.moveTo(X(p.a[0]), Y(p.a[1])); ctx.lineTo(X(p.b[0]), Y(p.b[1])); ctx.stroke();
      } else if (p.t === 'flash') {
        const a = p.ap || { s: 'C', d: 0.5 }, cx = X(p.x), cy = Y(p.y);
        ctx.beginPath();
        if (a.s === 'C') ctx.arc(cx, cy, a.d / 2 * res, 0, 2 * Math.PI);
        else if (a.s === 'R') ctx.rect(cx - a.w / 2 * res, cy - a.h / 2 * res, a.w * res, a.h * res);
        else if (a.s === 'O') { const r = Math.min(a.w, a.h) / 2 * res; ctx.roundRect ? ctx.roundRect(cx - a.w / 2 * res, cy - a.h / 2 * res, a.w * res, a.h * res, r) : ctx.rect(cx - a.w / 2 * res, cy - a.h / 2 * res, a.w * res, a.h * res); }
        else if (a.s === 'P') { for (let i = 0; i < a.n; i++) { const t = i / a.n * 2 * Math.PI; ctx[i ? 'lineTo' : 'moveTo'](cx + a.d / 2 * res * Math.cos(t), cy + a.d / 2 * res * Math.sin(t)); } ctx.closePath(); }
        ctx.fill();
      } else { ctx.beginPath(); p.pts.forEach((q, i) => ctx[i ? 'lineTo' : 'moveTo'](X(q[0]), Y(q[1]))); ctx.closePath(); ctx.fill(); }
    }
    return c;
  };

  TC.parseExcellon = function (text) {
    let unit = 1, tools = {}, cur = null, inch = false, lz = true; const holes = [];
    for (let line of text.replace(/\r/g, '').split('\n')) {
      line = line.trim(); if (!line || line[0] === ';') continue;
      if (/^INCH/.test(line) || line === 'M72') { inch = true; unit = 25.4; if (/TZ/.test(line)) lz = false; }
      if (/^METRIC/.test(line) || line === 'M71') { inch = false; unit = 1; if (/TZ/.test(line)) lz = false; }
      const td = /^T(\d+).*C([\d.]+)/.exec(line); if (td) { tools[+td[1]] = parseFloat(td[2]) * unit; continue; }
      const ts = /^T(\d+)$/.exec(line); if (ts) { cur = +ts[1]; continue; }
      const m = /^X([+-]?[\d.]+)Y([+-]?[\d.]+)/.exec(line);
      if (m && cur) {
        const conv = s => { if (s.includes('.')) return parseFloat(s) * unit; const neg = s[0] === '-'; s = s.replace(/^[+-]/, ''); const dec = inch ? 4 : 3; const v = lz ? parseInt(s.padEnd((inch ? 2 : 3) + dec, '0'), 10) / 10 ** dec : parseInt(s, 10) / 10 ** dec; return (neg ? -v : v) * unit; };
        holes.push({ x: conv(m[1]), y: conv(m[2]), d: tools[cur] || 0.8 });
      }
    }
    return holes;
  };

  /** Contornos (marching squares) de una máscara binaria. Devuelve trazos en mm. */
  TC.contours = function (mask, W, H, toMM) {
    const segs = [], key = (x, y) => x * 4 + ',' + y * 4;
    const v = (x, y) => (x < 0 || y < 0 || x >= W || y >= H) ? 0 : mask[y * W + x];
    for (let y = -1; y < H; y++) for (let x = -1; x < W; x++) {
      const a = v(x, y), b = v(x + 1, y), c = v(x + 1, y + 1), d = v(x, y + 1), code = a | b << 1 | c << 2 | d << 3;
      if (code === 0 || code === 15) continue;
      const T = [x + 0.5, y], R = [x + 1, y + 0.5], B = [x + 0.5, y + 1], L = [x, y + 0.5];
      const tbl = { 1: [[L, T]], 2: [[T, R]], 3: [[L, R]], 4: [[R, B]], 5: [[L, T], [R, B]], 6: [[T, B]], 7: [[L, B]], 8: [[B, L]], 9: [[B, T]], 10: [[T, R], [B, L]], 11: [[B, R]], 12: [[R, L]], 13: [[R, T]], 14: [[T, L]] };
      for (const s of tbl[code]) segs.push([[s[0][0] + 0.5, s[0][1] + 0.5], [s[1][0] + 0.5, s[1][1] + 0.5]]);
    }
    // unir por hash
    const start = new Map(); segs.forEach((s, i) => { const k = key(...s[0]); if (!start.has(k)) start.set(k, []); start.get(k).push(i); });
    const used = new Uint8Array(segs.length), out = [];
    for (let i = 0; i < segs.length; i++) {
      if (used[i]) continue; used[i] = 1; const pts = [segs[i][0], segs[i][1]];
      for (;;) {
        const lst = start.get(key(...pts[pts.length - 1])) || []; const n = lst.find(j => !used[j]);
        if (n === undefined) break; used[n] = 1; pts.push(segs[n][1]);
      }
      const closed = pts.length > 3 && key(...pts[0]) === key(...pts[pts.length - 1]); if (closed) pts.pop();
      out.push({ pts: TC.simplify(pts.map(toMM), 0.01), closed });
    }
    return out;
  };

  /** Distancia aproximada (chamfer 3-4) hasta el cobre, en píxeles. */
  function distanceField(mask, W, H) {
    const INF = 1e9, d = new Float32Array(W * H);
    for (let i = 0; i < d.length; i++) d[i] = mask[i] ? 0 : INF;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = y * W + x; let v = d[i]; if (x > 0) v = Math.min(v, d[i - 1] + 1); if (y > 0) { v = Math.min(v, d[i - W] + 1); if (x > 0) v = Math.min(v, d[i - W - 1] + 1.414); if (x < W - 1) v = Math.min(v, d[i - W + 1] + 1.414); } d[i] = v; }
    for (let y = H - 1; y >= 0; y--) for (let x = W - 1; x >= 0; x--) { const i = y * W + x; let v = d[i]; if (x < W - 1) v = Math.min(v, d[i + 1] + 1); if (y < H - 1) { v = Math.min(v, d[i + W] + 1); if (x < W - 1) v = Math.min(v, d[i + W + 1] + 1.414); if (x > 0) v = Math.min(v, d[i + W - 1] + 1.414); } d[i] = v; }
    return d;
  }

  /**
   * Construye el trabajo de PCB.
   * o = { copper:texto Gerber, outline:texto Gerber (opcional), drill:texto Excellon (opcional), method:'laser'|'mill', mirror, res, tool, passes, overlap, depth }
   */
  TC.buildPCB = function (o) {
    const cu = TC.parseGerber(o.copper), ol = o.outline ? TC.parseGerber(o.outline) : null;
    const bb0 = ol && isFinite(ol.bbox.x0) ? ol.bbox : cu.bbox, m = 1;
    const bb = { x0: bb0.x0 - m, y0: bb0.y0 - m, x1: bb0.x1 + m, y1: bb0.y1 + m };
    const res = o.res || (o.method === 'laser' ? 20 : 25);
    const canvas = TC.renderGerber(cu, res, bb, o.mirror), W = canvas.width, H = canvas.height;
    const items = [], report = [];
    const toMM = ([px, py]) => [(px - 1) / res, (H - 1 - py) / res];
    const holes = o.drill ? TC.parseExcellon(o.drill) : [];
    if (o.method === 'laser') {
      // negativo: pintura se quema donde NO hay cobre (negro = láser encendido)
      const neg = document.createElement('canvas'); neg.width = W; neg.height = H; const c2 = neg.getContext('2d');
      c2.drawImage(canvas, 0, 0); const id = c2.getImageData(0, 0, W, H);
      for (let i = 0; i < id.data.length; i += 4) { const cuOn = id.data[i] > 127; const v = cuOn ? 255 : 0; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; }
      // marcas de centro en los agujeros (puntito quemado para guiar la broca)
      c2.putImageData(id, 0, 0); c2.fillStyle = '#000';
      holes.forEach(h => { const x = o.mirror ? (bb.x1 - h.x) * res + 1 : (h.x - bb.x0) * res + 1, y = (bb.y1 - h.y) * res + 1; c2.beginPath(); c2.arc(x, y, Math.max(1, h.d * 0.25 * res), 0, 2 * Math.PI); c2.fill(); });
      items.push({ type: 'raster', canvas: neg, x: 0, y: 0, w: W / res, h: H / res, pmin: 0, pmax: o.power ?? 80, speed: o.speed ?? 1000, overscan: 2 });
      report.push('Ruta láser: pinta la placa, graba este negativo (quita pintura donde se ataca), ataca con cloruro férrico, limpia con acetona y taladra.');
    } else {
      const tool = TC.shop.tools.find(t => t.id === o.tool) || TC.shop.tools[2];
      const toolW = tool.type === 'vbit' ? TC.vbitWidth(tool, o.depth || 0.1) : tool.d;
      const id = canvas.getContext('2d').getImageData(0, 0, W, H).data, cuMask = new Uint8Array(W * H);
      for (let i = 0; i < W * H; i++) cuMask[i] = id[4 * i] > 127 ? 1 : 0;
      const dist = distanceField(cuMask, W, H);
      for (let p = 0; p < (o.passes || 1); p++) {
        const r = (toolW / 2 + p * toolW * (1 - (o.overlap ?? 0.4))) * res;
        const mask = new Uint8Array(W * H); for (let i = 0; i < mask.length; i++) mask[i] = dist[i] <= r ? 1 : 0;
        TC.contours(mask, W, H, toMM).forEach(c => items.push(TC.path(c.pts, 'engrave', c.closed)));
      }
      report.push(`Aislamiento con ${tool.name}: ancho de corte ≈ ${toolW.toFixed(2)} mm a ${o.depth || 0.1} mm de profundidad, ${o.passes || 1} pasada(s).`);
      if (cu.minTrace && cu.minTrace < toolW) report.push(`⚠ La pista más delgada mide ${cu.minTrace.toFixed(2)} mm, menos que tu corte (${toolW.toFixed(2)} mm). Usa un V-bit más agudo, menos profundidad o la ruta láser.`);
    }
    // agujeros: herramienta recomendada
    const drills = TC.shop.tools.filter(t => t.type === 'drill').sort((a, b) => a.d - b.d);
    const sizes = {};
    holes.forEach(h => {
      const best = drills.find(t => t.d >= h.d - 0.05) || drills[drills.length - 1];
      h.tool = best ? best.id : 'br10'; const x = o.mirror ? (bb.x1 - h.x) + m - m : h.x - bb.x0, y = h.y - bb.y0;
      h.x = x; h.y = y; sizes[h.d.toFixed(2)] = (sizes[h.d.toFixed(2)] || 0) + 1; h.toolName = best ? best.name : '?';
    });
    if (holes.length) {
      items.push({ type: 'drills', holes, depth: o.boardT ? o.boardT + 0.3 : 1.9, plunge: 60 });
      report.push('Agujeros: ' + Object.entries(sizes).map(([d, n]) => { const t = drills.find(t => t.d >= +d - 0.05) || drills[drills.length - 1]; return `${n} de ${d} mm → ${t ? t.name : 'sin broca'}`; }).join('; '));
    }
    if (ol) {
      const ocv = TC.renderGerber({ prims: ol.prims }, res, bb, o.mirror), od = ocv.getContext('2d').getImageData(0, 0, W, H).data, om = new Uint8Array(W * H);
      for (let i = 0; i < W * H; i++) om[i] = od[4 * i] > 127 ? 1 : 0;
      const outs = TC.contours(om, W, H, toMM).filter(c => c.closed);
      if (outs.length) {
        const biggest = outs.reduce((a, b) => (TC.bbox([TC.path(a.pts)]).w > TC.bbox([TC.path(b.pts)]).w ? a : b));
        items.push(TC.path(biggest.pts, 'cut', true));
        report.push('Contorno: córtalo al final con fresa de maíz 1–2 mm, dejando 2–4 puentes.');
      }
    }
    if (cu.minTrace) report.push(`Pista mínima detectada: ${cu.minTrace.toFixed(2)} mm.`);
    return { items, report, preview: canvas, size: [(bb.x1 - bb.x0), (bb.y1 - bb.y0)] };
  };
})(window.TC);
