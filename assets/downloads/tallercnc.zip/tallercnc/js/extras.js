/* TallerCNC - juegos de mesa y patrones de origami.
 * Juegos tradicionales de dominio público. Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const P = TC.path, L_ = TC.line, T = TC.templates;
  const num = (k, label, def, extra = {}) => Object.assign({ k, label, def, type: 'num', unit: 'mm', min: 0.1, step: 1 }, extra);
  const int = (k, label, def, min, max) => ({ k, label, def, type: 'int', min, max, step: 1, unit: '' });
  const bool = (k, label, def) => ({ k, label, def, type: 'bool' });
  const reg = (id, def) => { def.id = id; T[id] = def; };
  const hatchRect = (x, y, w, h, sp) => TC.hatch([[[x, y], [x + w, y], [x + w, y + h], [x, y + h]]], sp, 0, 'engrave');

  /* ---------- Tablero de cuadros (ajedrez / damas) ---------- */
  reg('chessboard', {
    name: 'Tablero de ajedrez / damas', cat: 'Juegos de mesa', code: '8×8 (o el que quieras)',
    params: [int('n', 'Casillas por lado', 8, 3, 19), num('sq', 'Tamaño de casilla', 25), num('m', 'Margen', 12), bool('fill', 'Rellenar casillas oscuras (grabado)', true), num('sp', 'Separación de relleno', 0.25, { step: 0.05 }), bool('pieces', 'Incluir fichas de damas', false)],
    build(p) {
      const { n, sq, m } = p, items = [], S = n * sq;
      items.push(TC.rect(-m, -m, S + 2 * m, S + 2 * m, 'cut'));
      items.push(TC.rect(0, 0, S, S, 'engrave'));
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if ((i + j) % 2 === 0) {
        if (p.fill) items.push(...hatchRect(i * sq, j * sq, sq, sq, p.sp)); else items.push(TC.rect(i * sq, j * sq, sq, sq, 'engrave'));
      }
      if (p.pieces) {
        const r = sq * 0.4, ox = S + 2 * m + 10;
        for (let k = 0; k < 24; k++) { const cx = ox + r + (k % 4) * (2 * r + 3), cy = r + Math.floor(k / 4) * (2 * r + 3); items.push(TC.circle(cx, cy, r, 'cut')); items.push(TC.circle(cx, cy, r * 0.7, 'engrave')); }
      }
      return items;
    },
    notes: 'Graba primero (azul) y corta al final (rojo). Para dos colores usa acrílico o tiñe la madera antes.'
  });

  /* ---------- Piezas de ajedrez de perfil con base ---------- */
  const PROF = { // medio perfil (x, y) con altura 1
    peon: [[0.30, 0], [0.30, 0.07], [0.20, 0.12], [0.12, 0.22], [0.09, 0.50], [0.18, 0.55], [0.10, 0.60], [0.17, 0.70], [0.16, 0.82], [0.10, 0.90], [0, 0.93]],
    torre: [[0.32, 0], [0.32, 0.07], [0.22, 0.12], [0.17, 0.25], [0.17, 0.70], [0.24, 0.74], [0.24, 0.95], [0.16, 0.95], [0.16, 0.88], [0.06, 0.88], [0.06, 0.95], [0, 0.95]],
    alfil: [[0.31, 0], [0.31, 0.07], [0.20, 0.12], [0.11, 0.30], [0.09, 0.55], [0.20, 0.60], [0.10, 0.64], [0.17, 0.75], [0.14, 0.86], [0.04, 0.93], [0.05, 0.97], [0, 1]],
    dama: [[0.33, 0], [0.33, 0.07], [0.22, 0.12], [0.12, 0.30], [0.10, 0.62], [0.21, 0.67], [0.11, 0.71], [0.20, 0.88], [0.13, 0.88], [0.08, 0.95], [0.05, 0.98], [0, 1]],
    rey: [[0.34, 0], [0.34, 0.07], [0.23, 0.12], [0.13, 0.30], [0.11, 0.62], [0.22, 0.67], [0.12, 0.71], [0.18, 0.86], [0.04, 0.86], [0.04, 0.92], [0.10, 0.92], [0.10, 0.96], [0.04, 0.96], [0.04, 1.04], [0, 1.04]]
  };
  const KNIGHT = [[0.32, 0], [0.32, 0.07], [0.22, 0.12], [0.20, 0.30], [0.26, 0.55], [0.22, 0.78], [0.10, 0.92], [0.02, 0.95], [-0.06, 0.88], [-0.22, 0.72], [-0.28, 0.62], [-0.20, 0.56], [-0.05, 0.62], [-0.16, 0.30], [-0.22, 0.12], [-0.32, 0.07], [-0.32, 0]];
  function pieceOutline(kind, h, tab, t) {
    let pts;
    if (kind === 'caballo') pts = KNIGHT.map(([x, y]) => [x * h, y * h]);
    else { const half = PROF[kind].map(([x, y]) => [x * h, y * h]); pts = half.concat(half.slice(0, -1).reverse().map(([x, y]) => [-x, y])); }
    // espiga inferior que entra en la base
    const w = Math.min(tab, h * 0.4);
    const first = pts[0], last = pts[pts.length - 1];
    return [[-w / 2, -t], [w / 2, -t], [w / 2, 0], first].concat(pts.slice(1, -1), [last, [-w / 2, 0]]).map(q => q);
  }
  reg('chesspieces', {
    name: 'Piezas de ajedrez de perfil', cat: 'Juegos de mesa', code: '16 piezas por color',
    params: [num('h', 'Altura del peón', 40), num('t', 'Grosor del material', 3, { step: 0.1 }), num('base', 'Diámetro de base', 24)],
    build(p) {
      const items = []; const set = ['torre', 'caballo', 'alfil', 'dama', 'rey', 'alfil', 'caballo', 'torre', 'peon', 'peon', 'peon', 'peon', 'peon', 'peon', 'peon', 'peon'];
      const scale = { peon: 1, torre: 1.15, caballo: 1.25, alfil: 1.35, dama: 1.5, rey: 1.6 };
      let x = 0; const tabW = p.base * 0.5;
      set.forEach((k, i) => {
        const h = p.h * scale[k]; const o = pieceOutline(k, h, tabW, p.t);
        const bb = TC.bbox([P(o)]); items.push(P(o.map(([a, b]) => [a - bb.x0 + x, b + p.t]), 'cut', true)); x += bb.w + 4;
        const cx = i * (p.base + 4) + p.base / 2, cy = -p.base / 2 - 6;
        items.push(TC.circle(cx, cy, p.base / 2, 'cut'));
        items.push(TC.rect(cx - tabW / 2 - 0.05, cy - p.t / 2 - 0.05, tabW + 0.1, p.t + 0.1, 'cut'));
      });
      return items;
    },
    notes: 'Cada pieza encaja en su base redonda. Corta dos juegos en materiales de distinto color.'
  });

  /* ---------- Molino (Nine Men's Morris) ---------- */
  reg('morris', {
    name: 'Molino (Nine Men’s Morris)', cat: 'Juegos de mesa', code: 'Tradicional',
    params: [num('S', 'Lado del tablero', 200), int('k', 'Fichas por jugador', 9, 3, 12)],
    build(p) {
      const S = p.S, m = S * 0.08, items = [TC.rect(0, 0, S, S, 'cut')], c = S / 2, st = (S / 2 - m) / 3;
      for (let i = 0; i < 3; i++) { const h = S / 2 - m - i * st; items.push(TC.rect(c - h, c - h, 2 * h, 2 * h, 'engrave')); for (const [dx, dy] of [[0, -1], [1, 0], [0, 1], [-1, 0]]) items.push(TC.circle(c + dx * h, c + dy * h, 3, 'engrave')); for (const [dx, dy] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) items.push(TC.circle(c + dx * h, c + dy * h, 3, 'engrave')); }
      const o = S / 2 - m, i3 = o - 2 * st;
      items.push(L_(c, c - o, c, c - i3, 'engrave'), L_(c, c + i3, c, c + o, 'engrave'), L_(c - o, c, c - i3, c, 'engrave'), L_(c + i3, c, c + o, c, 'engrave'));
      const r = st * 0.3; for (let j = 0; j < 2 * p.k; j++) { const cx = S + 15 + r + (j % 3) * (2 * r + 3), cy = r + Math.floor(j / 3) * (2 * r + 3); items.push(TC.circle(cx, cy, r, 'cut')); if (j >= p.k) items.push(TC.circle(cx, cy, r * 0.5, 'engrave')); }
      return items;
    }
  });

  /* ---------- Gato (tres en raya) ---------- */
  reg('tictactoe', {
    name: 'Gato (tres en raya)', cat: 'Juegos de mesa', code: 'Tradicional',
    params: [num('S', 'Lado del tablero', 150)],
    build(p) {
      const S = p.S, c = S / 3, items = [TC.rect(0, 0, S, S, 'cut')];
      items.push(L_(c, 8, c, S - 8, 'engrave'), L_(2 * c, 8, 2 * c, S - 8, 'engrave'), L_(8, c, S - 8, c, 'engrave'), L_(8, 2 * c, S - 8, 2 * c, 'engrave'));
      const r = c * 0.35, w = r * 0.35;
      for (let i = 0; i < 5; i++) {
        const cx = S + 15 + r + (i % 3) * (2 * r + 4), cy = r + Math.floor(i / 3) * (2 * r + 4);
        items.push(TC.circle(cx, cy, r, 'cut'), TC.circle(cx, cy, r - w, 'cut'));
        const cx2 = cx, cy2 = cy + 2 * (2 * r + 4) + 10, a = r, b = w / 2;
        const X = [[b, 0], [a, a - b], [a - b, a], [0, b], [-a + b, a], [-a, a - b], [-b, 0], [-a, -a + b], [-a + b, -a], [0, -b], [a - b, -a], [a, -a + b]];
        items.push(P(X.map(([x, y]) => [cx2 + x * 0.75, cy2 + y * 0.75]), 'cut', true));
      }
      return items;
    }
  });

  /* ---------- Mancala (dos capas apiladas) ---------- */
  reg('mancala', {
    name: 'Mancala', cat: 'Juegos de mesa', code: 'Dos capas: superior con huecos + fondo',
    params: [int('n', 'Huecos por fila', 6, 4, 8), num('d', 'Diámetro de hueco', 34), num('g', 'Separación', 6)],
    build(p) {
      const { n, d, g } = p, W = (n + 2) * (d + g) + g, H = 2 * d + 3 * g, items = [];
      const top = [TC.rect(0, 0, W, H, 'cut')];
      for (let i = 0; i < n; i++) for (let j = 0; j < 2; j++) top.push(TC.circle(g + (d + g) * (i + 1) + d / 2, g + j * (d + g) + d / 2, d / 2, 'cut'));
      const stadium = (x) => { const r = d / 2, pts = TC.arcPts(x + r, H - g - r, r, 0, Math.PI).concat(TC.arcPts(x + r, g + r, r, Math.PI, 2 * Math.PI)); return P(pts, 'cut', true); };
      top.push(stadium(g), stadium(W - g - d));
      items.push(...top, TC.rect(0, -H - 10, W, H, 'cut'));
      return items;
    },
    notes: 'Corta las dos placas y pégalas. En fresadora también puedes tallar los huecos como bolsillos en una sola pieza.'
  });

  /* ---------- Go ---------- */
  reg('go', {
    name: 'Go', cat: 'Juegos de mesa', code: '9×9, 13×13 o 19×19',
    params: [int('n', 'Líneas', 9, 5, 19), num('sp', 'Separación', 22), num('m', 'Margen', 15)],
    build(p) {
      const { n, sp, m } = p, S = (n - 1) * sp, items = [TC.rect(-m, -m, S + 2 * m, S + 2 * m, 'cut')];
      for (let i = 0; i < n; i++) items.push(L_(i * sp, 0, i * sp, S, 'engrave'), L_(0, i * sp, S, i * sp, 'engrave'));
      const stars = n === 19 ? [3, 9, 15] : n === 13 ? [3, 6, 9] : n === 9 ? [2, 4, 6] : [Math.floor(n / 2)];
      stars.forEach(a => stars.forEach(b => items.push(TC.circle(a * sp, b * sp, 1.6, 'engrave'))));
      return items;
    }
  });

  /* ---------- Dominó ---------- */
  reg('domino', {
    name: 'Dominó (28 fichas)', cat: 'Juegos de mesa', code: 'Doble seis',
    params: [num('w', 'Ancho de ficha', 22), num('r', 'Radio de punto', 1.6, { step: 0.1 })],
    build(p) {
      const w = p.w, h = 2 * w, items = [], q = w / 4;
      const pip = { 0: [], 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] };
      let k = 0;
      for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) {
        const x = (k % 7) * (w + 3), y = Math.floor(k / 7) * (h + 3); k++;
        items.push(L_(x + 3, y + w, x + w - 3, y + w, 'engrave'));
        pip[a].forEach(([u, v]) => items.push(TC.circle(x + w / 2 + u * q, y + w / 2 + v * q, p.r, 'engrave')));
        pip[b].forEach(([u, v]) => items.push(TC.circle(x + w / 2 + u * q, y + w * 1.5 + v * q, p.r, 'engrave')));
        items.push(TC.rect(x, y, w, h, 'cut'));
      }
      return items;
    }
  });

  /* ---------- Tangram ---------- */
  reg('tangram', {
    name: 'Tangram', cat: 'Juegos de mesa', code: 'Rompecabezas de 7 piezas',
    params: [num('S', 'Lado', 120)],
    build(p) {
      const s = p.S, items = [TC.rect(0, 0, s, s, 'cut')], h = s / 2, q = s / 4;
      items.push(L_(0, 0, s, s, 'cut'), L_(0, s, h, h, 'cut'), L_(h, 0, s, h, 'cut'), L_(q, q, h, 0, 'cut'), L_(3 * q, q, h, h, 'cut'), L_(s, h, 3 * q, 3 * q, 'cut'));
      return items;
    }
  });

  /* ---------- Laberinto de bolita ---------- */
  reg('maze', {
    name: 'Laberinto (para bolita o lápiz)', cat: 'Juegos de mesa', code: 'Generado al azar con semilla',
    params: [int('c', 'Columnas', 12, 4, 40), int('r', 'Filas', 12, 4, 40), num('cell', 'Tamaño de celda', 12), int('seed', 'Semilla', 7, 1, 99999)],
    build(p) {
      let s = p.seed; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
      const { c, r, cell } = p, vis = new Array(c * r).fill(false), right = new Array(c * r).fill(true), top = new Array(c * r).fill(true);
      const stack = [0]; vis[0] = true;
      while (stack.length) {
        const cur = stack[stack.length - 1], x = cur % c, y = Math.floor(cur / c), nb = [];
        if (x > 0 && !vis[cur - 1]) nb.push([cur - 1, 'L']); if (x < c - 1 && !vis[cur + 1]) nb.push([cur + 1, 'R']);
        if (y > 0 && !vis[cur - c]) nb.push([cur - c, 'D']); if (y < r - 1 && !vis[cur + c]) nb.push([cur + c, 'U']);
        if (!nb.length) { stack.pop(); continue; }
        const [nx, d] = nb[Math.floor(rnd() * nb.length)];
        if (d === 'R') right[cur] = false; if (d === 'L') right[nx] = false; if (d === 'U') top[cur] = false; if (d === 'D') top[nx] = false;
        vis[nx] = true; stack.push(nx);
      }
      const items = [TC.rect(-8, -8, c * cell + 16, r * cell + 16, 'cut')];
      items.push(L_(cell, 0, c * cell, 0, 'engrave'), L_(0, 0, 0, r * cell, 'engrave'), L_(0, r * cell, (c - 1) * cell, r * cell, 'engrave'), L_(c * cell, 0, c * cell, r * cell, 'engrave'));
      for (let i = 0; i < c * r; i++) { const x = i % c, y = Math.floor(i / c); if (right[i] && x < c - 1) items.push(L_((x + 1) * cell, y * cell, (x + 1) * cell, (y + 1) * cell, 'engrave')); if (top[i] && y < r - 1) items.push(L_(x * cell, (y + 1) * cell, (x + 1) * cell, (y + 1) * cell, 'engrave')); }
      return TC.joinSegments(items);
    }
  });

  /* ---------- Origami: Miura-ori ---------- */
  reg('miura', {
    name: 'Miura-ori (plegado de mapa)', cat: 'Origami (marcar dobleces)', code: 'Teselado',
    params: [int('nx', 'Columnas', 8, 2, 30), int('ny', 'Filas', 6, 2, 30), num('a', 'Ancho de celda', 20), num('b', 'Alto de celda', 15), num('off', 'Desfase del zigzag', 4, { step: 0.5 })],
    build(p) {
      const { nx, ny, a, b, off } = p, items = [];
      const X = (i, j) => i * a + (j % 2 ? off : 0);
      const W = nx * a + off, H = ny * b;
      items.push(TC.rect(0, 0, W, H, 'cut'));
      for (let j = 1; j < ny; j++) for (let i = 0; i < nx; i++) items.push(L_(X(i, j) + (i === 0 ? 0 : 0), j * b, X(i + 1, j), j * b, j % 2 ? 'fold' : 'valley'));
      for (let i = 1; i < nx; i++) for (let j = 0; j < ny; j++) items.push(L_(X(i, j), j * b, X(i, j + 1), (j + 1) * b, (i + j) % 2 ? 'fold' : 'valley'));
      return items;
    },
    notes: 'Con láser a baja potencia (o medio corte) para marcar sin cortar. Verde = monte, naranja = valle.'
  });

  /* ---------- Origami: Yoshimura (cilindro plegable / lámpara) ---------- */
  reg('yoshimura', {
    name: 'Yoshimura (lámpara plegable)', cat: 'Origami (marcar dobleces)', code: 'Teselado de rombos',
    params: [int('nx', 'Rombos por fila', 8, 3, 30), int('ny', 'Filas', 8, 2, 40), num('a', 'Ancho de rombo', 25), num('b', 'Alto de fila', 12)],
    build(p) {
      const { nx, ny, a, b } = p, items = [TC.rect(0, 0, nx * a, ny * b, 'cut')];
      for (let j = 1; j < ny; j++) items.push(L_(0, j * b, nx * a, j * b, 'valley'));
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
        const x = i * a, y = j * b, sh = j % 2 ? a / 2 : 0;
        const x0 = x + sh, xm = x0 + a / 2, x1 = x0 + a, clip = v => Math.max(0, Math.min(nx * a, v));
        if (j % 2 === 0) { items.push(L_(clip(x0), y, clip(xm), y + b, 'fold'), L_(clip(xm), y + b, clip(x1), y, 'fold')); }
        else { items.push(L_(clip(x0 - a / 2), y + b, clip(x0), y, 'fold'), L_(clip(x0), y, clip(x0 + a / 2), y + b, 'fold')); }
      }
      return items.filter(it => it.type !== 'path' || TC.pathLength(it) > 0.01);
    }
  });

  /* ---------- Origami: caja masu ---------- */
  reg('masu', {
    name: 'Caja masu (guía de dobleces)', cat: 'Origami (marcar dobleces)', code: 'Papel cuadrado',
    params: [num('S', 'Lado del papel', 200)],
    build(p) {
      const s = p.S, q = s / 4, h = s / 2, items = [TC.rect(0, 0, s, s, 'cut')];
      items.push(L_(0, 0, s, s, 'valley'), L_(0, s, s, 0, 'valley'));
      items.push(P([[h, 0], [s, h], [h, s], [0, h]], 'fold', true));
      items.push(P([[h, q], [3 * q, h], [h, 3 * q], [q, h]], 'valley', true));
      [q, 3 * q].forEach(v => items.push(L_(v, q * 0.5, v, s - q * 0.5, 'valley'), L_(q * 0.5, v, s - q * 0.5, v, 'valley')));
      return items;
    },
    notes: 'Marca los dobleces con láser a baja potencia y dóblalo como masu tradicional: las líneas guían cada paso.'
  });
})(window.TC);
