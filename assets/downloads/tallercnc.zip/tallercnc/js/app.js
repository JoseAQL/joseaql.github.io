/* TallerCNC - interfaz. Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const panel = $('#panel'), cv = $('#view'), ctx = cv.getContext('2d');

  const S = {
    tab: 'templates', cat: null, tpl: 'tuck', params: {}, design: [], label: '', sim: null, gcode: '', stats: null,
    view: { scale: 2, ox: 60, oy: 500 }, origin: [10, 10],
    pdf: { page: 'carta', landscape: false, monochrome: false },
    job: null, img: null, imgOpts: { w: 80, res: 10, mode: 'floyd', brightness: 0, contrast: 1, invert: false, pmin: 0, pmax: 60, speed: 1500, depth: 3, tool: 'bola', thr: 0.5 },
    stl: null, stlOpts: { w: 80, mode: 'positivo', axis: 'z', depth: 6, res: 4, tool: 'bola', stepover: 0.2, stepdown: 1.5, feed: 800 },
    pcb: { copper: '', outline: '', drill: '', names: {}, method: 'laser', mirror: false, tool: 'vb30', depth: 0.1, passes: 2, boardT: 1.6, power: 80, speed: 1000, report: [], preview: null },
    log: []
  };
  TC.app = {
    items: () => jobItems(),
    jobOffset: () => [0, 0],
    state: S
  };

  /* ---------------- utilidades de interfaz ---------------- */
  const U = () => TC.units.mode === 'in' ? 'in' : 'mm';
  function fieldHTML(p, val, pre = 'f') {
    const id = `${pre}_${p.k}`;
    if (p.type === 'bool') return `<div class="field"><label for="${id}">${esc(p.label)}</label><input type="checkbox" id="${id}" ${val ? 'checked' : ''}></div>`;
    if (p.type === 'select') return `<div class="field"><label for="${id}">${esc(p.label)}</label><select id="${id}">${p.opts.map(([v, l]) => `<option value="${v}" ${v === val ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>`;
    const isLen = p.unit === 'mm', shown = isLen ? +TC.fmt(TC.fromMM(val), 3) : val;
    const step = isLen && TC.units.mode === 'in' ? 0.01 : p.step;
    return `<div class="field"><label for="${id}">${esc(p.label)}</label><div class="u"><input type="number" id="${id}" value="${shown}" step="${step}" ${p.min != null ? `min="${isLen ? TC.fromMM(p.min) : p.min}"` : ''} ${p.max != null ? `max="${p.max}"` : ''}><span>${isLen ? U() : (p.unit || '')}</span></div></div>`;
  }
  function readField(p, pre = 'f') {
    const el = $(`#${pre}_${p.k}`); if (!el) return p.def;
    if (p.type === 'bool') return el.checked; if (p.type === 'select') return el.value;
    let v = parseFloat(el.value); if (isNaN(v)) v = p.def; if (p.type === 'int') v = Math.round(v);
    return p.unit === 'mm' ? TC.toMM(v) : v;
  }
  const num = (k, label, val, unit = 'mm', extra = {}) => fieldHTML(Object.assign({ k, label, type: 'num', unit, step: 1 }, extra), val, 'o');
  const getNum = (k, unit = 'mm') => { const v = parseFloat($('#o_' + k).value); return unit === 'mm' ? TC.toMM(v) : v; };

  function setDesign(items, label) {
    S.design = TC.normalize(items, 0); S.label = label || ''; S.sim = null; S.gcode = ''; S.stats = null;
    updateDims(); fit(); draw();
  }
  function jobItems() { return TC.translate(S.design, S.origin[0], S.origin[1]); }
  function updateDims() {
    const b = TC.bbox(S.design); const f = v => TC.fmt(TC.fromMM(v), TC.units.mode === 'in' ? 2 : 1);
    $('#dims').textContent = S.design.length ? `${S.label} · ${f(b.w)} × ${f(b.h)} ${U()}` : 'Sin diseño';
  }

  /* ---------------- vista ---------------- */
  function fit() {
    const r = cv.getBoundingClientRect(); const b = TC.bbox(jobItems().concat($('#showBed').checked ? [TC.rect(0, 0, TC.shop.machine.bedW, TC.shop.machine.bedH)] : []));
    if (!b.w && !b.h) return; const pad = 30;
    S.view.scale = Math.min((r.width - 2 * pad) / (b.w || 1), (r.height - 2 * pad) / (b.h || 1));
    S.view.ox = pad - b.x0 * S.view.scale + ((r.width - 2 * pad) - b.w * S.view.scale) / 2;
    S.view.oy = r.height - pad + b.y0 * S.view.scale - ((r.height - 2 * pad) - b.h * S.view.scale) / 2;
  }
  function draw() {
    const dpr = window.devicePixelRatio || 1, r = cv.getBoundingClientRect();
    if (cv.width !== Math.round(r.width * dpr) || cv.height !== Math.round(r.height * dpr)) { cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, r.width, r.height);
    const { scale: s, ox, oy } = S.view, X = x => ox + x * s, Y = y => oy - y * s;
    const M = TC.shop.machine;
    if ($('#showBed').checked) {
      ctx.fillStyle = '#16191d'; ctx.fillRect(X(0), Y(M.bedH), M.bedW * s, M.bedH * s);
      const step = s * 10 > 8 ? 10 : s * 50 > 8 ? 50 : 100;
      ctx.strokeStyle = '#20252b'; ctx.lineWidth = 1; ctx.beginPath();
      for (let x = 0; x <= M.bedW; x += step) { ctx.moveTo(X(x), Y(0)); ctx.lineTo(X(x), Y(M.bedH)); }
      for (let y = 0; y <= M.bedH; y += step) { ctx.moveTo(X(0), Y(y)); ctx.lineTo(X(M.bedW), Y(y)); }
      ctx.stroke(); ctx.strokeStyle = '#3b414a'; ctx.strokeRect(X(0), Y(M.bedH), M.bedW * s, M.bedH * s);
      ctx.fillStyle = '#6f7782'; ctx.font = '11px sans-serif'; ctx.fillText(`${M.name} · ${M.bedW}×${M.bedH} mm`, X(0), Y(M.bedH) - 6);
      ctx.fillStyle = '#ff6a2b'; ctx.beginPath(); ctx.arc(X(0), Y(0), 4, 0, 7); ctx.fill();
    }
    const items = jobItems();
    for (const it of items) {
      if ((it.type === 'raster' || it.type === 'heightmap') && it.canvas) { ctx.imageSmoothingEnabled = false; ctx.globalAlpha = 0.9; ctx.drawImage(it.canvas, X(it.x), Y(it.y + it.h), it.w * s, it.h * s); ctx.globalAlpha = 1; ctx.strokeStyle = '#3e63dd'; ctx.setLineDash([4, 3]); ctx.strokeRect(X(it.x), Y(it.y + it.h), it.w * s, it.h * s); ctx.setLineDash([]); }
    }
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    for (const lay of ['ref', 'engrave', 'valley', 'fold', 'cut']) {
      ctx.strokeStyle = TC.LAYERS[lay].color; ctx.lineWidth = lay === 'cut' ? 1.4 : 1.1; ctx.setLineDash(lay === 'fold' ? [6, 3] : lay === 'valley' ? [2, 3] : []);
      ctx.beginPath();
      for (const it of items) if (it.type === 'path' && it.layer === lay) { it.pts.forEach((p, i) => i ? ctx.lineTo(X(p[0]), Y(p[1])) : ctx.moveTo(X(p[0]), Y(p[1]))); if (it.closed) ctx.closePath(); }
      ctx.stroke();
    }
    ctx.setLineDash([]);
    for (const it of items) if (it.type === 'drills') { ctx.strokeStyle = '#ffd400'; it.holes.forEach(h => { ctx.beginPath(); ctx.arc(X(h.x), Y(h.y), Math.max(1.5, h.d / 2 * s), 0, 7); ctx.stroke(); }); }
    if ($('#showSim').checked && S.sim) {
      for (const sg of S.sim) {
        if (sg.rapid) { ctx.strokeStyle = 'rgba(160,170,180,.35)'; ctx.setLineDash([3, 3]); ctx.lineWidth = 0.8; }
        else if (sg.on) { ctx.strokeStyle = 'rgba(255,140,40,.9)'; ctx.setLineDash([]); ctx.lineWidth = 1.2; }
        else continue;
        ctx.beginPath(); ctx.moveTo(X(sg.x0), Y(sg.y0)); ctx.lineTo(X(sg.x1), Y(sg.y1)); ctx.stroke();
      }
      ctx.setLineDash([]);
    }
    const g = TC.grbl; if (g.port) { const p = g.status.wpos; ctx.strokeStyle = '#ffd400'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X(p[0]), Y(p[1]), 7, 0, 7); ctx.moveTo(X(p[0]) - 12, Y(p[1])); ctx.lineTo(X(p[0]) + 12, Y(p[1])); ctx.moveTo(X(p[0]), Y(p[1]) - 12); ctx.lineTo(X(p[0]), Y(p[1]) + 12); ctx.stroke(); }
  }
  // zoom y paneo
  let dragV = null;
  cv.addEventListener('wheel', e => { e.preventDefault(); const f = Math.exp(-e.deltaY * 0.0015), r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top; S.view.ox = mx - (mx - S.view.ox) * f; S.view.oy = my - (my - S.view.oy) * f; S.view.scale *= f; draw(); }, { passive: false });
  cv.addEventListener('mousedown', e => { dragV = [e.clientX, e.clientY, S.view.ox, S.view.oy]; });
  window.addEventListener('mousemove', e => { if (!dragV) return; S.view.ox = dragV[2] + e.clientX - dragV[0]; S.view.oy = dragV[3] + e.clientY - dragV[1]; draw(); });
  window.addEventListener('mouseup', () => { dragV = null; });
  cv.addEventListener('dblclick', () => { fit(); draw(); });
  $('#zoomFit').onclick = () => { fit(); draw(); };
  $('#showBed').onchange = () => { fit(); draw(); }; $('#showSim').onchange = draw;
  window.addEventListener('resize', () => { draw(); });

  /* ---------------- pestañas ---------------- */
  $$('#rail button').forEach(b => b.onclick = () => { $$('#rail button').forEach(x => x.classList.toggle('on', x === b)); S.tab = b.dataset.tab; renderPanel(); });
  function renderPanel() { ({ templates: pTemplates, import: pImport, image: pImage, pcb: pPCB, relief: pRelief, cam: pCAM, control: pControl, shop: pShop })[S.tab](); }

  /* ================= PLANTILLAS ================= */
  const cats = () => [...new Set(Object.values(TC.templates).map(t => t.cat))];
  function thumb(t, c) {
    try {
      const vals = {}; t.params.forEach(p => vals[p.k] = p.def); const items = t.build(vals), b = TC.bbox(items);
      const g = c.getContext('2d'), W = c.width = 300, H = c.height = 172, s = Math.min((W - 16) / b.w, (H - 16) / b.h);
      g.translate((W - b.w * s) / 2, (H + b.h * s) / 2); g.lineWidth = 1;
      for (const it of items) if (it.type === 'path') { g.strokeStyle = TC.LAYERS[it.layer].color; g.beginPath(); it.pts.forEach((p, i) => g[i ? 'lineTo' : 'moveTo']((p[0] - b.x0) * s, -(p[1] - b.y0) * s)); if (it.closed) g.closePath(); g.stroke(); }
    } catch (e) { console.warn(t.id, e); }
  }
  function pTemplates() {
    const all = Object.values(TC.templates); S.cat = S.cat || all[0].cat;
    const t = TC.templates[S.tpl];
    panel.innerHTML = `<h2>Plantillas paramétricas</h2><p class="sub">Elige un modelo, cambia sus medidas y expórtalo, proyéctalo o córtalo.</p>
      <div class="cats">${cats().map(c => `<button data-cat="${esc(c)}" class="${c === S.cat ? 'on' : ''}">${esc(c)}</button>`).join('')}</div>
      <div class="cards">${all.filter(x => x.cat === S.cat).map(x => `<button class="card ${x.id === S.tpl ? 'on' : ''}" data-tpl="${x.id}"><canvas></canvas><b>${esc(x.name)}</b><small>${esc(x.code || '')}</small></button>`).join('')}</div>
      <h3>${esc(t.name)}</h3>
      <div id="params">${t.params.map(p => fieldHTML(p, S.params[p.k] ?? p.def)).join('')}</div>
      ${t.params.some(p => p.k === 'L') && t.params.some(p => p.k === 'H') ? `
      <h3>Calcular por volumen u objeto</h3>
      <div class="field"><label>Volumen deseado</label><div class="u"><input type="number" id="vol" placeholder="p. ej. 500"><span>cm³</span></div></div>
      <div class="row"><button id="byVol">Ajustar medidas al volumen (misma proporción)</button></div>
      <div class="field"><label>Holgura alrededor del objeto</label><div class="u"><input type="number" id="clr" value="${TC.fromMM(2)}" step="0.5"><span>${U()}</span></div></div>
      <div class="row"><button id="addClr">Sumar holgura a L, A y H</button></div>` : ''}
      ${t.notes ? `<div class="note">${esc(t.notes)}</div>` : ''}
      <h3>Exportar e imprimir</h3>
      <div class="field"><label>Tamaño de hoja (PDF)</label><select id="pdfPage">${Object.keys(TC.PAGES).map(k => `<option ${k === S.pdf.page ? 'selected' : ''}>${k}</option>`).join('')}</select></div>
      <div class="field"><label>Hoja horizontal</label><input type="checkbox" id="pdfLand" ${S.pdf.landscape ? 'checked' : ''}></div>
      <div class="field"><label>Imprimir en negro</label><input type="checkbox" id="pdfMono" ${S.pdf.monochrome ? 'checked' : ''}></div>
      <div class="row"><button class="primary" data-x="pdf">PDF</button><button data-x="svg">SVG</button><button data-x="dxf">DXF</button></div>
      <div class="row"><button class="accent" id="toProj">Proyectar 1:1</button><button id="toCam">Preparar corte →</button></div>`;
    $$('[data-cat]', panel).forEach(b => b.onclick = () => { S.cat = b.dataset.cat; const first = all.find(x => x.cat === S.cat); S.tpl = first.id; S.params = {}; buildTemplate(); pTemplates(); });
    $$('[data-tpl]', panel).forEach(b => { thumb(TC.templates[b.dataset.tpl], b.querySelector('canvas')); b.onclick = () => { S.tpl = b.dataset.tpl; S.params = {}; buildTemplate(); pTemplates(); }; });
    $$('#params input, #params select').forEach(el => el.addEventListener('input', () => { t.params.forEach(p => S.params[p.k] = readField(p)); buildTemplate(true); }));
    const byVol = $('#byVol'); if (byVol) byVol.onclick = () => { const v = parseFloat($('#vol').value); if (!v) return TC.toast('Escribe un volumen en cm³'); const P = cur(); const k = Math.cbrt(v * 1000 / (P.L * P.W * P.H)); ['L', 'W', 'H'].forEach(q => S.params[q] = Math.round(P[q] * k * 10) / 10); buildTemplate(); pTemplates(); TC.toast(`Nuevas medidas: ${S.params.L} × ${S.params.W} × ${S.params.H} mm`, 'ok'); };
    const addClr = $('#addClr'); if (addClr) addClr.onclick = () => { const c = TC.toMM(parseFloat($('#clr').value) || 0); const P = cur(); ['L', 'W', 'H'].forEach(q => S.params[q] = Math.round((P[q] + 2 * c) * 10) / 10); buildTemplate(); pTemplates(); };
    $('#pdfPage').onchange = e => S.pdf.page = e.target.value; $('#pdfLand').onchange = e => S.pdf.landscape = e.target.checked; $('#pdfMono').onchange = e => S.pdf.monochrome = e.target.checked;
    $$('[data-x]', panel).forEach(b => b.onclick = () => doExport(b.dataset.x));
    $('#toProj').onclick = () => TC.projector.open('plantilla');
    $('#toCam').onclick = () => $('[data-tab=cam]').click();
  }
  function cur() { const t = TC.templates[S.tpl], v = {}; t.params.forEach(p => v[p.k] = S.params[p.k] ?? p.def); return v; }
  function buildTemplate(keepView) {
    const t = TC.templates[S.tpl];
    try { const items = t.build(cur()); S.design = TC.normalize(items, 0); S.label = t.name; S.sim = null; S.gcode = ''; updateDims(); if (!keepView) fit(); draw(); }
    catch (e) { console.error(e); TC.toast('No se pudo generar: ' + e.message, 'err'); }
  }

  /* ================= EXPORTAR / PROYECTO ================= */
  function doExport(kind) {
    if (!S.design.length) return TC.toast('No hay diseño para exportar', 'warn');
    const name = (S.label || 'diseno').normalize('NFD').replace(/[^\w]+/g, '_').replace(/_+$/, '').toLowerCase();
    if (kind === 'svg') TC.download(name + '.svg', TC.toSVG(S.design), 'image/svg+xml');
    if (kind === 'dxf') TC.download(name + '.dxf', TC.toDXF(S.design), 'application/dxf');
    if (kind === 'pdf') { const r = TC.toPDF(S.design, S.pdf); TC.download(name + '.pdf', new Blob([r.bytes], { type: 'application/pdf' })); TC.toast(`PDF de ${r.pages} hoja(s) (${r.nx}×${r.ny}). Imprime al 100 %.`, 'ok'); }
  }
  $$('[data-exp]').forEach(b => b.onclick = () => { closeMenus(); doExport(b.dataset.exp); });
  $$('[data-proj]').forEach(b => b.onclick = () => { closeMenus(); TC.projector.open(b.dataset.proj); });
  $$('[data-projwin]').forEach(b => b.onclick = () => { closeMenus(); TC.projector.openWindow(b.dataset.projwin); });
  $$('.menu > button').forEach(b => b.onclick = e => { e.stopPropagation(); const m = b.parentElement, o = m.classList.contains('open'); closeMenus(); if (!o) m.classList.add('open'); });
  function closeMenus() { $$('.menu').forEach(m => m.classList.remove('open')); }
  document.addEventListener('click', closeMenus);
  $$('#unitSeg button').forEach(b => b.onclick = () => { TC.units.mode = b.dataset.u; $$('#unitSeg button').forEach(x => x.classList.toggle('on', x === b)); updateDims(); renderPanel(); });

  $('#btnSave').onclick = () => {
    const data = { app: 'TallerCNC', version: 1, label: S.label, tpl: S.tpl, params: S.params, origin: S.origin, items: S.design.map(it => it.type === 'path' ? it : it.type === 'raster' ? Object.assign({}, it, { canvas: undefined, png: it.canvas.toDataURL() }) : null).filter(Boolean) };
    TC.download((S.label || 'proyecto').replace(/\W+/g, '_') + '.tcnc', JSON.stringify(data), 'application/json');
  };
  $('#btnOpen').onclick = () => $('#fileOpen').click();
  $('#fileOpen').onchange = async e => {
    const f = e.target.files[0]; if (!f) return; e.target.value = '';
    try {
      const d = JSON.parse(await f.text()); const items = [];
      for (const it of d.items) { if (it.type === 'raster') { const img = await loadImg(it.png); const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; c.getContext('2d').drawImage(img, 0, 0); items.push(Object.assign({}, it, { canvas: c })); } else items.push(it); }
      S.tpl = d.tpl || S.tpl; S.params = d.params || {}; S.origin = d.origin || S.origin; setDesign(items, d.label || f.name); TC.toast('Proyecto abierto', 'ok');
    } catch (err) { TC.toast('No se pudo abrir: ' + err.message, 'err'); }
  };
  const loadImg = src => new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = ko; i.src = src; });

  /* ================= IMPORTAR CAD ================= */
  function pImport() {
    panel.innerHTML = `<h2>Importar desde CAD</h2><p class="sub">Dibuja en LibreCAD, QCAD, FreeCAD, Inkscape o AutoCAD y trae aquí el archivo.</p>
      <div class="row"><input type="file" id="cadFile" accept=".dxf,.svg"></div>
      <div class="field"><label>Agregar al diseño actual</label><input type="checkbox" id="cadAdd"></div>
      <div class="field"><label>Escalar</label><div class="u"><input type="number" id="cadScale" value="100" step="1"><span>%</span></div></div>
      <div class="note"><b>Capas por color o nombre:</b><br>rojo / “corte” → cortar<br>verde / “doblez” → doblez monte<br>naranja / “valle” → doblez valle<br>azul / “grabado” → grabar<br>gris / “referencia” → no se corta</div>
      <h3>Vigilar archivo (recarga automática)</h3>
      <p class="sub">En la app de escritorio puedes vigilar un archivo: cada vez que guardes en tu CAD se recarga aquí solo.</p>
      <div class="row"><button id="watchBtn" ${window.tallerDesktop ? '' : 'disabled'}>${window.tallerDesktop ? 'Elegir archivo para vigilar…' : 'Disponible en la app de escritorio'}</button></div>
      <h3>FreeCAD</h3>
      <p class="sub">Copia <code>integraciones/freecad/EnviarATallerCNC.FCMacro</code> a tu carpeta de macros. Selecciona una cara o un boceto y ejecútala: exporta el DXF a la carpeta vigilada.</p>
      <h3>Herramientas</h3>
      <div class="row"><button id="rot90">Girar 90°</button><button id="mirX">Espejo</button><button id="joinSeg">Unir segmentos</button></div>`;
    $('#cadFile').onchange = async e => { const f = e.target.files[0]; if (f) loadCAD(f.name, await f.text()); };
    $('#rot90').onclick = () => setDesign(TC.rotate(S.design, 90), S.label);
    $('#mirX').onclick = () => setDesign(TC.mirrorX(S.design), S.label);
    $('#joinSeg').onclick = () => setDesign(TC.joinSegments(S.design), S.label);
    if (window.tallerDesktop) $('#watchBtn').onclick = async () => { const r = await window.tallerDesktop.watchFile(); if (r) TC.toast('Vigilando ' + r, 'ok'); };
  }
  function loadCAD(name, text) {
    try {
      let items = /\.svg$/i.test(name) ? TC.importSVG(text) : TC.importDXF(text);
      const sc = ($('#cadScale') ? parseFloat($('#cadScale').value) : 100) / 100; if (sc !== 1) items = TC.scale(items, sc);
      if ($('#cadAdd') && $('#cadAdd').checked && S.design.length) { const b = TC.bbox(S.design); items = TC.translate(TC.normalize(items), b.x1 + 10, 0); items = S.design.concat(items); }
      setDesign(items, name); TC.toast(`${name}: ${items.filter(i => i.type === 'path').length} trazos`, 'ok');
    } catch (err) { console.error(err); TC.toast('No se pudo leer el archivo: ' + err.message, 'err'); }
  }
  if (window.tallerDesktop) window.tallerDesktop.onFileChanged((name, text) => { loadCAD(name, text); });

  /* ================= IMAGEN ================= */
  function pImage() {
    const o = S.imgOpts;
    panel.innerHTML = `<h2>Imagen</h2><p class="sub">Graba fotos con láser, haz relieves con fresa o convierte un dibujo en línea de corte.</p>
      <div class="row"><input type="file" id="imgFile" accept="image/*"></div>
      ${S.img ? `<img class="thumb" src="${S.img.src}">` : ''}
      ${num('w', 'Ancho', o.w)}
      <h3>Grabado láser</h3>
      <div class="field"><label>Método</label><select id="o_mode">${[['floyd', 'Tramado Floyd–Steinberg'], ['jarvis', 'Tramado Jarvis'], ['gray', 'Escala de grises (potencia variable)'], ['threshold', 'Blanco y negro']].map(([v, l]) => `<option value="${v}" ${v === o.mode ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      ${num('res', 'Resolución', o.res, 'líneas/mm', { step: 1 })}
      ${num('brightness', 'Brillo (−1 a 1)', o.brightness, '', { step: 0.05 })}
      ${num('contrast', 'Contraste', o.contrast, '×', { step: 0.1 })}
      <div class="field"><label>Invertir (negativo)</label><input type="checkbox" id="o_invert" ${o.invert ? 'checked' : ''}></div>
      <div class="field"><label>Espejo (grabar por detrás del acrílico)</label><input type="checkbox" id="o_mirror" ${o.mirror ? 'checked' : ''}></div>
      ${num('pmin', 'Potencia mínima', o.pmin, '%')}${num('pmax', 'Potencia máxima', o.pmax, '%')}${num('speed', 'Velocidad', o.speed, 'mm/min')}
      <div class="row"><button class="primary" id="mkRaster">Crear grabado</button></div>
      <h3>Relieve con fresa (madera)</h3>
      ${num('depth', 'Profundidad máxima', o.depth)}
      <div class="field"><label>Herramienta</label><select id="o_tool">${toolOpts(o.tool)}</select></div>
      <div class="row"><button id="mkRelief">Crear relieve</button></div>
      <div class="note">Claro = alto. Para acrílico iluminado por el canto, usa grabado láser en espejo por la parte de atrás.</div>
      <h3>Convertir en línea de corte</h3>
      ${num('thr', 'Umbral (0–1)', o.thr, '', { step: 0.05 })}
      <div class="row"><button id="mkVector">Vectorizar contorno</button></div>`;
    $('#imgFile').onchange = e => { const f = e.target.files[0]; if (!f) return; const rd = new FileReader(); rd.onload = async () => { S.img = await loadImg(rd.result); S.imgOpts.w = Math.min(TC.shop.machine.bedW - 20, 100); pImage(); }; rd.readAsDataURL(f); };
    const read = () => { ['w'].forEach(k => o[k] = getNum(k)); ['res', 'brightness', 'contrast', 'pmin', 'pmax', 'speed', 'thr'].forEach(k => o[k] = getNum(k, '')); o.depth = getNum('depth'); o.mode = $('#o_mode').value; o.invert = $('#o_invert').checked; o.mirror = $('#o_mirror').checked; o.tool = $('#o_tool').value; o.h = o.w * S.img.height / S.img.width; };
    const need = () => { if (!S.img) { TC.toast('Primero carga una imagen', 'warn'); return false; } read(); return true; };
    $('#mkRaster').onclick = () => { if (!need()) return; const r = TC.imageToRaster(S.img, o); if (o.mirror) mirrorCanvas(r.canvas); setDesign([r], 'Grabado de imagen'); TC.toast(`${r.canvas.width}×${r.canvas.height} puntos`, 'ok'); };
    $('#mkRelief').onclick = () => { if (!need()) return; const hm = TC.imageToHeightmap(S.img, Object.assign({}, o, { res: 4, blur: 1 })); setDesign([hm], 'Relieve de imagen'); };
    $('#mkVector').onclick = () => {
      if (!need()) return; const res = 8, W = Math.round(o.w * res), H = Math.round(o.h * res), c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.drawImage(S.img, 0, 0, W, H);
      const d = g.getImageData(0, 0, W, H).data, mask = new Uint8Array(W * H); for (let i = 0; i < W * H; i++) { const l = (0.299 * d[4 * i] + 0.587 * d[4 * i + 1] + 0.114 * d[4 * i + 2]) / 255; mask[i] = (o.invert ? l > o.thr : l < o.thr) ? 1 : 0; }
      const paths = TC.contours(mask, W, H, ([x, y]) => [x / res, (H - y) / res]).filter(p => p.pts.length > 4).map(p => TC.path(TC.simplify(p.pts, 0.08), 'cut', p.closed));
      setDesign(paths, 'Contorno de imagen'); TC.toast(`${paths.length} contornos`, 'ok');
    };
  }
  function mirrorCanvas(c) { const t = document.createElement('canvas'); t.width = c.width; t.height = c.height; const g = t.getContext('2d'); g.translate(c.width, 0); g.scale(-1, 1); g.drawImage(c, 0, 0); c.getContext('2d').clearRect(0, 0, c.width, c.height); c.getContext('2d').drawImage(t, 0, 0); }
  const toolOpts = (sel, filter) => TC.shop.tools.filter(t => !filter || filter(t)).map(t => `<option value="${t.id}" ${t.id === sel ? 'selected' : ''}>${esc(t.name)}</option>`).join('');

  /* ================= PCB ================= */
  function pPCB() {
    const o = S.pcb;
    panel.innerHTML = `<h2>Placas PCB (Gerber)</h2><p class="sub">Exporta de KiCad o EasyEDA: capa de cobre, contorno (Edge.Cuts) y taladros (.drl).</p>
      <div class="field"><label>Cobre (.gtl/.gbl/.gbr)</label><input type="file" id="pcbCu"></div>
      <div class="field"><label>Contorno (opcional)</label><input type="file" id="pcbOl"></div>
      <div class="field"><label>Taladros .drl (opcional)</label><input type="file" id="pcbDr"></div>
      <div class="stats">${Object.entries(o.names).map(([k, v]) => `${k}: ${esc(v)}`).join('<br>')}</div>
      <h3>¿Con qué la haces?</h3>
      <div class="field"><label>Método</label><select id="pcbMethod"><option value="laser" ${o.method === 'laser' ? 'selected' : ''}>Láser (pintura + ácido)</option><option value="mill" ${o.method === 'mill' ? 'selected' : ''}>Fresadora (aislamiento)</option></select></div>
      <div class="field"><label>Capa inferior (espejo)</label><input type="checkbox" id="pcbMirror" ${o.mirror ? 'checked' : ''}></div>
      <div id="pcbLaser" ${o.method === 'laser' ? '' : 'hidden'}>${num('power', 'Potencia para quitar pintura', o.power, '%')}${num('speed', 'Velocidad', o.speed, 'mm/min')}
        <div class="note">Un láser de diodo azul no quita cobre: quema la pintura donde no va cobre y luego atacas con cloruro férrico o persulfato.</div></div>
      <div id="pcbMill" ${o.method === 'mill' ? '' : 'hidden'}>
        <div class="field"><label>Fresa de aislamiento</label><select id="pcbTool">${toolOpts(o.tool, t => t.type !== 'drill' && t.type !== 'ball')}</select></div>
        ${num('depth', 'Profundidad', o.depth, 'mm', { step: 0.01 })}${num('passes', 'Pasadas de aislamiento', o.passes, '', { step: 1 })}
      </div>
      ${num('boardT', 'Grosor de la placa', o.boardT, 'mm', { step: 0.1 })}
      <div class="row"><button class="primary" id="pcbBuild">Generar pasos</button></div>
      ${o.report.length ? `<h3>Pasos recomendados</h3><ul class="report">${o.report.map(r => `<li>${esc(r)}</li>`).join('')}</ul>` : ''}
      <div class="note">Orden sugerido: 1) ${o.method === 'laser' ? 'grabado láser del negativo → ataque químico' : 'aislamiento (V-bit)'} 2) taladros (cambio de broca por tamaño) 3) contorno con fresa de maíz.</div>`;
    const rd = (id, key) => { $(id).onchange = async e => { const f = e.target.files[0]; if (!f) return; o[key] = await f.text(); o.names[key === 'copper' ? 'Cobre' : key === 'outline' ? 'Contorno' : 'Taladros'] = f.name; }; };
    rd('#pcbCu', 'copper'); rd('#pcbOl', 'outline'); rd('#pcbDr', 'drill');
    $('#pcbMethod').onchange = e => { o.method = e.target.value; pPCB(); };
    $('#pcbBuild').onclick = () => {
      if (!o.copper) return TC.toast('Carga la capa de cobre', 'warn');
      o.mirror = $('#pcbMirror').checked; o.boardT = getNum('boardT');
      if (o.method === 'laser') { o.power = getNum('power', ''); o.speed = getNum('speed', ''); } else { o.tool = $('#pcbTool').value; o.depth = getNum('depth'); o.passes = Math.max(1, Math.round(getNum('passes', ''))); }
      try { const r = TC.buildPCB(o); o.report = r.report; setDesign(r.items, 'PCB'); pPCB(); TC.toast('Listo: revisa los pasos y ve a Corte', 'ok'); }
      catch (err) { console.error(err); TC.toast('Error leyendo Gerber: ' + err.message, 'err'); }
    };
  }

  /* ================= 3D / RELIEVE ================= */
  function pRelief() {
    const o = S.stlOpts;
    panel.innerHTML = `<h2>Modelos 3D (STL)</h2><p class="sub">Talla el modelo en positivo (sobresale) o en negativo (molde), visto desde arriba.</p>
      <div class="row"><input type="file" id="stlFile" accept=".stl"></div>
      ${S.stl ? `<div class="stats">${S.stl.length} triángulos cargados</div>` : ''}
      <div class="field"><label>Modo</label><select id="o_mode"><option value="positivo" ${o.mode === 'positivo' ? 'selected' : ''}>Positivo (figura en relieve)</option><option value="negativo" ${o.mode === 'negativo' ? 'selected' : ''}>Negativo (molde / hueco)</option></select></div>
      <div class="field"><label>Eje hacia arriba</label><select id="o_axis">${['z', 'y', 'x'].map(a => `<option ${a === o.axis ? 'selected' : ''}>${a}</option>`).join('')}</select></div>
      ${num('w', 'Ancho final', o.w)}${num('depth', 'Profundidad', o.depth)}${num('res', 'Resolución', o.res, 'pts/mm', { step: 1 })}
      <div class="field"><label>Herramienta</label><select id="o_tool">${toolOpts(o.tool, t => t.type === 'ball' || t.type === 'flat')}</select></div>
      ${num('stepover', 'Paso lateral (fracción del diámetro)', o.stepover, '', { step: 0.05 })}${num('stepdown', 'Bajada por pasada (desbaste)', o.stepdown)}${num('feed', 'Avance', o.feed, 'mm/min')}
      <div class="row"><button class="primary" id="mkStl">Generar mapa de alturas</button></div>
      <div class="note">Con láser: el relieve se graba como imagen en escala de grises (oscuro = más profundo). Ve a Imagen o usa “Enviar a láser”.</div>
      <div class="row"><button id="stlLaser">Enviar a láser (escala de grises)</button></div>`;
    $('#stlFile').onchange = async e => { const f = e.target.files[0]; if (!f) return; S.stl = TC.parseSTL(await f.arrayBuffer()); TC.toast(`${S.stl.length} triángulos`, 'ok'); pRelief(); };
    const read = () => { o.mode = $('#o_mode').value; o.axis = $('#o_axis').value; o.w = getNum('w'); o.depth = getNum('depth'); o.res = getNum('res', ''); o.tool = $('#o_tool').value; o.stepover = getNum('stepover', ''); o.stepdown = getNum('stepdown'); o.feed = getNum('feed', ''); };
    $('#mkStl').onclick = () => { if (!S.stl) return TC.toast('Carga un archivo STL', 'warn'); read(); const hm = TC.stlToHeightmap(S.stl, o); setDesign([hm], 'Relieve 3D'); TC.toast(hm.info, 'ok'); };
    $('#stlLaser').onclick = () => {
      if (!S.stl) return TC.toast('Carga un archivo STL', 'warn'); read(); const hm = TC.stlToHeightmap(S.stl, o);
      const c = document.createElement('canvas'); c.width = hm.gw; c.height = hm.gh; const g = c.getContext('2d'), id = g.createImageData(hm.gw, hm.gh);
      for (let j = 0; j < hm.gh; j++) for (let i = 0; i < hm.gw; i++) { const v = Math.round(hm.z[j * hm.gw + i] * 255), k = ((hm.gh - 1 - j) * hm.gw + i) * 4; id.data[k] = id.data[k + 1] = id.data[k + 2] = v; id.data[k + 3] = 255; }
      g.putImageData(id, 0, 0); setDesign([{ type: 'raster', canvas: c, x: 0, y: 0, w: hm.w, h: hm.h, pmin: 5, pmax: 80, speed: 1500, overscan: 2 }], 'Relieve 3D (láser)');
    };
  }

  /* ================= CAM ================= */
  function defaultJob() {
    const M = TC.shop.machine, mat = TC.MATERIALS[S.job?.material || 'cartulina'];
    const mode = S.job?.mode || (M.head === 'mill' ? 'mill' : 'laser');
    const L = mat.laser, mi = mat.mill;
    return {
      mode, material: S.job?.material || 'cartulina', materialName: mat.name, rpm: mi.rpm, ops: mode === 'laser' ? {
        cut: { on: true, power: L.cut[0], speed: L.cut[1], passes: L.cut[2] },
        fold: { on: true, power: L.fold[0], speed: L.fold[1], passes: 1 },
        valley: { on: true, power: L.fold[0], speed: L.fold[1], passes: 1, dash: true, dashOn: 4, dashOff: 2 },
        engrave: { on: true, power: L.engrave[0], speed: L.engrave[1], passes: L.engrave[2] },
        ref: { on: false, power: 0, speed: 1000, passes: 1 }
      } : {
        cut: { on: true, tool: 'fe3', depth: mat.t + 0.2, stepdown: mi.step, feed: mi.feed, plunge: mi.plunge, side: 'outside' },
        fold: { on: true, tool: 'vb60', depth: Math.min(0.5, mat.t / 3), stepdown: 1, feed: mi.feed, plunge: mi.plunge, side: 'on' },
        valley: { on: true, tool: 'vb60', depth: Math.min(0.5, mat.t / 3), stepdown: 1, feed: mi.feed, plunge: mi.plunge, side: 'on' },
        engrave: { on: true, tool: 'vb30', depth: 0.3, stepdown: 0.3, feed: mi.feed, plunge: mi.plunge, side: 'on' },
        ref: { on: false, tool: 'fe3', depth: 0, stepdown: 1, feed: 500, plunge: 100, side: 'on' }
      }
    };
  }
  function pCAM() {
    if (!S.job) S.job = defaultJob();
    const j = S.job, laser = j.mode === 'laser', mat = TC.MATERIALS[j.material];
    const lays = ['cut', 'fold', 'valley', 'engrave'];
    const present = new Set(S.design.filter(i => i.type === 'path').map(i => i.layer));
    const hasR = S.design.some(i => i.type === 'raster'), hasH = S.design.some(i => i.type === 'heightmap'), hasD = S.design.some(i => i.type === 'drills');
    const b = TC.bbox(jobItems()), M = TC.shop.machine, out = b.x0 < 0 || b.y0 < 0 || b.x1 > M.bedW || b.y1 > M.bedH;
    panel.innerHTML = `<h2>Preparar el corte</h2><p class="sub">Convierte el diseño en G-code para tu máquina GRBL.</p>
      <div class="field"><label>Cabezal</label><select id="cMode"><option value="laser" ${laser ? 'selected' : ''}>Láser</option><option value="mill" ${!laser ? 'selected' : ''}>Fresadora / broca</option></select></div>
      <div class="field"><label>Material</label><select id="cMat">${Object.entries(TC.MATERIALS).map(([k, m]) => `<option value="${k}" ${k === j.material ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></div>
      ${laser && mat.forbidLaser ? '<div class="note warn">⚠ Este material libera gases tóxicos (cloro) con láser. No lo cortes con láser.</div>' : ''}
      ${laser && j.material === 'acrilico' && M.laserType === 'diodo' ? '<div class="note warn">Un láser de diodo azul casi no corta acrílico transparente. Se necesita CO2 o fresa.</div>' : ''}
      <h3>Capas</h3>
      <table class="ops"><tr><th></th><th>Capa</th>${laser ? '<th>Pot %</th><th>mm/min</th><th>Pasadas</th>' : '<th>Herramienta</th><th>Prof.</th><th>Lado</th>'}</tr>
      ${lays.map(l => { const op = j.ops[l]; const dim = present.has(l) ? '' : 'style="opacity:.45"'; return `<tr ${dim}><td><input type="checkbox" data-op="${l}.on" ${op.on ? 'checked' : ''}></td><td><span style="color:${TC.LAYERS[l].color}">■</span> ${TC.LAYERS[l].name}</td>${laser
        ? `<td><input type="number" data-op="${l}.power" value="${op.power}" min="0" max="100"></td><td><input type="number" data-op="${l}.speed" value="${op.speed}"></td><td><input type="number" data-op="${l}.passes" value="${op.passes}" min="1"></td>`
        : `<td><select data-op="${l}.tool">${toolOpts(op.tool, t => t.type !== 'drill')}</select></td><td><input type="number" data-op="${l}.depth" value="${op.depth}" step="0.1"></td><td><select data-op="${l}.side">${[['on', 'Sobre'], ['outside', 'Afuera'], ['inside', 'Adentro']].map(([v, n]) => `<option value="${v}" ${op.side === v ? 'selected' : ''}>${n}</option>`).join('')}</select></td>`}</tr>`; }).join('')}
      </table>
      ${laser ? `<div class="field"><label>Valle como perforado</label><input type="checkbox" data-op="valley.dash" ${j.ops.valley.dash ? 'checked' : ''}></div>` : `
        ${num('stepdown', 'Bajada por pasada (corte)', j.ops.cut.stepdown)}${num('feed', 'Avance', j.ops.cut.feed, 'mm/min')}${num('plunge', 'Bajada (Z)', j.ops.cut.plunge, 'mm/min')}${num('rpm', 'S husillo', j.rpm, '')}
        <div class="note">Ancho de línea de V-bit a la profundidad elegida: ${TC.shop.tools.filter(t => t.type === 'vbit').map(t => `${esc(t.name)} → ${TC.vbitWidth(t, j.ops.engrave.depth).toFixed(2)} mm`).join('; ')}</div>`}
      ${hasR ? `<div class="note">Incluye grabado de imagen (ráster)${laser ? '' : ' — solo con láser'}.</div>` : ''}${hasH ? `<div class="note">Incluye relieve 3D${laser ? ' — solo con fresa' : ''}.</div>` : ''}${hasD ? `<div class="note">Incluye taladros con pausa para cambio de broca${laser ? ' — solo con fresa' : ''}.</div>` : ''}
      <h3>Posición en la mesa</h3>
      ${num('ox', 'Origen X', S.origin[0])}${num('oy', 'Origen Y', S.origin[1])}
      ${out ? '<div class="note warn">El diseño se sale del área de trabajo de tu máquina.</div>' : ''}
      <div class="row"><button class="primary big" id="gen">Generar G-code</button></div>
      ${S.stats ? `<div class="stats">${S.stats.lines} líneas · recorrido de corte ${(S.stats.cutLen / 1000).toFixed(2)} m · tiempo aprox. ${fmtMin(S.stats.minutes)}</div>
      <div class="row"><button id="dl">Descargar .gcode</button><button class="accent" id="projMach">Ver en proyector</button><button id="send">Enviar a la máquina →</button></div>` : ''}
      <h3>Prueba de calibración (láser)</h3>
      <p class="sub">Cuadrícula de potencia × velocidad para encontrar los valores de tu material.</p>
      <div class="row"><button id="testGrid">Generar prueba</button></div>`;
    $('#cMode').onchange = e => { S.job = defaultJobFor(e.target.value, j.material); pCAM(); };
    $('#cMat').onchange = e => { S.job = defaultJobFor(j.mode, e.target.value); pCAM(); };
    $$('[data-op]', panel).forEach(el => el.onchange = () => { const [l, k] = el.dataset.op.split('.'); j.ops[l][k] = el.type === 'checkbox' ? el.checked : el.tagName === 'SELECT' ? el.value : parseFloat(el.value); });
    const pos = () => { S.origin = [getNum('ox'), getNum('oy')]; draw(); }; $('#o_ox').onchange = pos; $('#o_oy').onchange = pos;
    $('#gen').onclick = () => {
      pos();
      if (!laser) { const sd = getNum('stepdown'), fd = getNum('feed', ''), pl = getNum('plunge', ''); lays.forEach(l => { j.ops[l].feed = fd; j.ops[l].plunge = pl; }); j.ops.cut.stepdown = sd; j.rpm = getNum('rpm', ''); }
      if (laser && TC.MATERIALS[j.material].forbidLaser) return TC.toast('Material no apto para láser', 'err');
      const r = TC.generateGcode(jobItems(), j); S.gcode = r.gcode; S.stats = r.stats; S.sim = TC.parseGcodeForPreview(r.gcode);
      $('#showSim').checked = true; draw(); pCAM(); TC.toast('G-code listo', 'ok');
    };
    if (S.stats) {
      $('#dl').onclick = () => TC.download((S.label || 'trabajo').replace(/\W+/g, '_') + '.gcode', S.gcode, 'text/plain');
      $('#projMach').onclick = () => TC.projector.open('maquina');
      $('#send').onclick = () => $('[data-tab=control]').click();
    }
    $('#testGrid').onclick = () => { const g = laserTest(j); S.gcode = g; S.sim = TC.parseGcodeForPreview(g); S.stats = { lines: g.split('\n').length, cutLen: 0, minutes: 6 }; $('#showSim').checked = true; draw(); pCAM(); TC.toast('Prueba lista: 5 potencias × 5 velocidades', 'ok'); };
  }
  function defaultJobFor(mode, material) { S.job = { mode, material }; const d = defaultJob(); d.mode = mode; return d; }
  const fmtMin = m => m < 1 ? '< 1 min' : m < 60 ? `${Math.round(m)} min` : `${Math.floor(m / 60)} h ${Math.round(m % 60)} min`;
  function laserTest(j) {
    const sMax = TC.shop.machine.sMax, powers = [20, 40, 60, 80, 100], speeds = [300, 600, 1000, 1500, 2500], sq = 8, gap = 4, [ox, oy] = S.origin;
    const g = ['; Prueba de calibración TallerCNC', 'G21 G90', 'M4 S0'];
    speeds.forEach((sp, r) => powers.forEach((pw, c) => {
      const x = ox + c * (sq + gap), y = oy + r * (sq + gap); g.push(`; ${pw}% ${sp} mm/min`);
      for (let k = 0; k <= sq / 0.3; k++) { const yy = y + k * 0.3; g.push(`G0 X${x.toFixed(2)} Y${yy.toFixed(2)}`, `G1 X${(x + sq).toFixed(2)} F${sp} S${Math.round(pw / 100 * sMax)}`, 'S0'); }
    }));
    g.push('M5 S0', 'G0 X0 Y0', '; Filas = velocidades ' + speeds.join(', ') + ' mm/min (de abajo arriba); columnas = potencias ' + powers.join(', ') + '%', 'M2');
    return g.join('\n') + '\n';
  }

  /* ================= CONTROL ================= */
  let jogStep = 1, jogFeed = 1000;
  function pControl() {
    const g = TC.grbl, st = g.status, con = !!g.port;
    panel.innerHTML = `<h2>Control de la máquina</h2>
      ${g.supported ? '' : '<div class="note warn">Este navegador no puede usar el puerto USB. Abre TallerCNC en Chrome/Edge o usa la app de escritorio.</div>'}
      <div class="row"><select id="baud">${[115200, 250000, 57600, 9600].map(b => `<option>${b}</option>`).join('')}</select><button class="${con ? 'danger' : 'primary'}" id="conn">${con ? 'Desconectar' : 'Conectar'}</button></div>
      <div style="margin:6px 0">Estado: <span class="state ${esc(st.state.split(':')[0])}" id="stState">${esc(st.state)}</span></div>
      <div class="dro"><span></span><span class="hdr">Trabajo</span><span class="hdr">Máquina</span>
        ${['X', 'Y', 'Z'].map((a, i) => `<span class="ax">${a}</span><span class="v" id="w${a}">${st.wpos[i].toFixed(3)}</span><span class="m" id="m${a}">${st.mpos[i].toFixed(3)}</span>`).join('')}</div>
      <div class="jog">
        <span></span><button data-jog="Y+">▲</button><span></span><span></span><button data-jog="Z+">Z▲</button>
        <button data-jog="X-">◀</button><button id="goZero" title="Ir al cero de trabajo">⌂</button><button data-jog="X+">▶</button><span></span><span></span>
        <span></span><button data-jog="Y-">▼</button><span></span><span></span><button data-jog="Z-">Z▼</button></div>
      <div class="field"><label>Paso</label><select id="jStep">${[0.1, 1, 5, 10, 50].map(v => `<option ${v === jogStep ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
      <div class="field"><label>Velocidad de jog</label><div class="u"><input type="number" id="jFeed" value="${jogFeed}"><span>mm/min</span></div></div>
      <div class="row"><button data-cmd="G10 L20 P1 X0 Y0">Cero XY</button><button data-cmd="G10 L20 P1 Z0">Cero Z</button><button data-cmd="$H">Home</button><button data-cmd="$X">Desbloquear</button></div>
      <div class="row"><button id="frame">Recorrer marco</button><button id="pointer">Puntero láser 1%</button><button data-rt="reset">Reset</button></div>
      <h3>Trabajo</h3>
      <div class="stats">${S.gcode ? `${S.gcode.split('\n').length} líneas listas (${esc(S.label)})` : 'Genera el G-code en “Corte (CAM)” o carga un archivo.'}</div>
      <div class="row"><input type="file" id="gFile" accept=".gcode,.nc,.ngc,.tap,.txt"></div>
      <div class="progress"><i id="prog"></i></div>
      <div class="row"><button class="primary big" id="run" ${S.gcode && con ? '' : 'disabled'}>▶ Iniciar</button><button id="hold">❚❚ Pausa</button><button id="resume">▶ Seguir</button><button class="danger" id="stop">■ Alto</button></div>
      <h3>Consola</h3>
      <div class="log" id="log">${S.log.slice(-200).map(([t, k]) => `<div class="${k}">${esc(t)}</div>`).join('')}</div>
      <div class="row"><input type="text" id="cmd" placeholder="Comando G-code o $ (Enter)"><button id="cmdSend">Enviar</button></div>
      <div class="row"><button data-cmd="$$">Ver ajustes $$</button><button data-cmd="$32=1">Activar modo láser</button><button data-cmd="$32=0">Modo fresa</button></div>
      <h3>Convertir el Arduino en CNC (flashear GRBL 1.1h)</h3>
      <p class="sub">Conecta el Arduino solo (sin otro programa usando el puerto). Esto borra el programa que tenga.</p>
      <div class="field"><label>Placa</label><select id="board"><option value="uno">Arduino Uno / Nano nuevo (115200)</option><option value="nano-old">Nano con bootloader antiguo (57600)</option></select></div>
      <div class="row"><button class="accent" id="flash">Flashear GRBL</button></div>
      <div class="note">Después: conecta a 115200, pulsa “Ver ajustes $$” y configura pasos/mm ($100–$102) en “Mi taller”.</div>`;
    $('#conn').onclick = async () => { try { if (g.port) await g.disconnect(); else await g.connect(+$('#baud').value); pControl(); } catch (e) { TC.toast(e.message, 'err'); } };
    $$('[data-jog]', panel).forEach(b => b.onclick = () => { if (!g.port) return; const a = b.dataset.jog; g.jog(a[0], (a[1] === '+' ? 1 : -1) * jogStep, a[0] === 'Z' ? Math.min(jogFeed, 500) : jogFeed); });
    $('#jStep').onchange = e => jogStep = +e.target.value; $('#jFeed').onchange = e => jogFeed = +e.target.value;
    $('#goZero').onclick = () => g.port && g.send('G90 G0 X0 Y0');
    $$('[data-cmd]', panel).forEach(b => b.onclick = () => g.port ? g.send(b.dataset.cmd) : TC.toast('Conecta primero', 'warn'));
    $('[data-rt=reset]').onclick = () => g.realtime('\x18');
    $('#frame').onclick = () => { if (!g.port) return; const b = TC.bbox(jobItems()); g.stream([`G90 G0 X${b.x0.toFixed(2)} Y${b.y0.toFixed(2)}`, `G1 X${b.x1.toFixed(2)} F3000 S0`, `G1 Y${b.y1.toFixed(2)}`, `G1 X${b.x0.toFixed(2)}`, `G1 Y${b.y0.toFixed(2)}`].join('\n')); };
    $('#pointer').onclick = () => { if (!g.port) return; g.send(`M3 S${Math.round(TC.shop.machine.sMax * 0.01)}`); setTimeout(() => g.send('M5'), 8000); TC.toast('Puntero encendido 8 s (con $32=0 enciende sin moverse)', 'warn'); };
    $('#gFile').onchange = async e => { const f = e.target.files[0]; if (!f) return; S.gcode = await f.text(); S.sim = TC.parseGcodeForPreview(S.gcode); S.label = f.name; $('#showSim').checked = true; draw(); pControl(); };
    $('#run').onclick = () => { if (!confirm('¿Material sujeto, gafas puestas y cero de trabajo hecho? Iniciar el trabajo.')) return; g.stream(S.gcode); };
    $('#hold').onclick = () => g.hold(); $('#resume').onclick = () => g.resume(); $('#stop').onclick = () => g.stop();
    const sendCmd = () => { const v = $('#cmd').value.trim(); if (!v) return; if (!g.port) return TC.toast('Conecta primero', 'warn'); g.send(v); $('#cmd').value = ''; };
    $('#cmdSend').onclick = sendCmd; $('#cmd').onkeydown = e => { if (e.key === 'Enter') sendCmd(); };
    $('#flash').onclick = async () => {
      if (!confirm('Se borrará el programa actual del Arduino y se grabará GRBL 1.1h. ¿Continuar?')) return;
      try { await TC.flashArduino(TC.GRBL_HEX, $('#board').value, m => addLog(m, 'info')); TC.toast('GRBL instalado', 'ok'); }
      catch (e) { addLog(e.message, 'err'); TC.toast(e.message, 'err'); }
    };
    const lg = $('#log'); lg.scrollTop = lg.scrollHeight;
  }
  function addLog(t, k) {
    S.log.push([t, k]); if (S.log.length > 1000) S.log.splice(0, 500);
    const lg = S.tab === 'control' && $('#log'); if (lg) { const d = document.createElement('div'); d.className = k; d.textContent = t; lg.appendChild(d); lg.scrollTop = lg.scrollHeight; }
  }
  TC.grbl.on('log', addLog);
  TC.grbl.on('hello', l => TC.toast('Conectado: ' + l, 'ok'));
  TC.grbl.on('status', st => {
    if (S.tab === 'control') { const e = $('#stState'); if (e) { e.textContent = st.state; e.className = 'state ' + st.state.split(':')[0]; } ['X', 'Y', 'Z'].forEach((a, i) => { const w = $('#w' + a), m = $('#m' + a); if (w) w.textContent = (st.wpos[i] || 0).toFixed(3); if (m) m.textContent = (st.mpos[i] || 0).toFixed(3); }); }
    draw();
  });
  TC.grbl.on('progress', (d, t) => { const p = $('#prog'); if (p) p.style.width = (t ? d / t * 100 : 0) + '%'; });
  TC.grbl.on('finished', () => TC.toast('Trabajo terminado', 'ok'));

  /* ================= MI TALLER ================= */
  function pShop() {
    const M = TC.shop.machine;
    panel.innerHTML = `<h2>Mi taller</h2><p class="sub">Registra una vez tu máquina, láser y herramientas. Se guarda en esta computadora.</p>
      <h3>Máquina</h3>
      <div class="field"><label>Nombre</label><input type="text" id="mName" value="${esc(M.name)}"></div>
      ${num('bedW', 'Área X', M.bedW)}${num('bedH', 'Área Y', M.bedH)}${num('bedZ', 'Recorrido Z', M.bedZ)}${num('safeZ', 'Altura segura Z', M.safeZ)}
      <div class="field"><label>Cabezal</label><select id="mHead">${[['laser', 'Láser'], ['mill', 'Fresadora'], ['both', 'Ambos (intercambiable)']].map(([v, n]) => `<option value="${v}" ${v === M.head ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      ${num('sMax', 'S máximo ($30)', M.sMax, '')}
      <div class="field"><label>Tipo de láser</label><select id="mLaser">${[['diodo', 'Diodo azul 445–455 nm'], ['co2', 'CO2 10.6 µm'], ['fibra', 'Fibra 1064 nm']].map(([v, n]) => `<option value="${v}" ${v === M.laserType ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
      ${num('laserW', 'Potencia óptica del láser', M.laserW, 'W', { step: 0.5 })}
      <h3>Herramientas</h3>
      <table class="ops"><tr><th>Nombre</th><th>Tipo</th><th>Ø mm</th><th>Áng.</th><th></th></tr>
      ${TC.shop.tools.map((t, i) => `<tr><td><input type="text" data-t="${i}.name" value="${esc(t.name)}"></td><td><select data-t="${i}.type">${[['flat', 'Plana'], ['ball', 'Bola'], ['vbit', 'V-bit'], ['drill', 'Broca']].map(([v, n]) => `<option value="${v}" ${v === t.type ? 'selected' : ''}>${n}</option>`).join('')}</select></td><td><input type="number" step="0.01" data-t="${i}.d" value="${t.d}"></td><td><input type="number" data-t="${i}.angle" value="${t.angle || ''}"></td><td><button data-del="${i}">✕</button></td></tr>`).join('')}</table>
      <div class="row"><button id="addTool">+ Herramienta</button><button id="resetShop">Restablecer</button></div>
      <h3>Calcular pasos/mm</h3>
      <div class="field"><label>Pasos por vuelta del motor</label><input type="number" id="spr" value="200"></div>
      <div class="field"><label>Micropasos del driver</label><select id="micro">${[1, 2, 4, 8, 16, 32].map(v => `<option ${v === 16 ? 'selected' : ''}>${v}</option>`).join('')}</select></div>
      <div class="field"><label>Avance por vuelta (mm)</label><input type="number" id="mmrev" value="8" step="0.1"></div>
      <div class="note" id="spmOut"></div>
      <p class="sub">Husillo T8 = 8 mm/vuelta · banda GT2 con polea de 20 dientes = 40 mm/vuelta · husillo M8 = 1.25 mm/vuelta.</p>
      <div class="row"><button id="spmSend">Enviar a $100 y $101</button></div>`;
    const save = () => { M.name = $('#mName').value; ['bedW', 'bedH', 'bedZ', 'safeZ'].forEach(k => M[k] = getNum(k)); M.sMax = getNum('sMax', ''); M.laserW = getNum('laserW', ''); M.head = $('#mHead').value; M.laserType = $('#mLaser').value; TC.saveShop(); S.job = null; fit(); draw(); };
    $$('input,select', panel).forEach(el => { if (!el.dataset.t && !['spr', 'micro', 'mmrev'].includes(el.id)) el.addEventListener('change', save); });
    $$('[data-t]', panel).forEach(el => el.onchange = () => { const [i, k] = el.dataset.t.split('.'); TC.shop.tools[i][k] = el.type === 'number' ? parseFloat(el.value) : el.value; TC.saveShop(); });
    $$('[data-del]', panel).forEach(b => b.onclick = () => { TC.shop.tools.splice(+b.dataset.del, 1); TC.saveShop(); pShop(); });
    $('#addTool').onclick = () => { TC.shop.tools.push({ id: 't' + Date.now(), name: 'Nueva herramienta', type: 'flat', d: 3 }); TC.saveShop(); pShop(); };
    $('#resetShop').onclick = () => { if (confirm('¿Volver a los valores de fábrica?')) { TC.resetShop(); pShop(); } };
    const calc = () => { const v = TC.stepsPerMM(+$('#spr').value, +$('#micro').value, +$('#mmrev').value); $('#spmOut').textContent = `Pasos/mm = ${v.toFixed(3)}`; return v; };
    ['spr', 'micro', 'mmrev'].forEach(id => $('#' + id).oninput = calc); calc();
    $('#spmSend').onclick = () => { if (!TC.grbl.port) return TC.toast('Conecta la máquina en Control', 'warn'); const v = calc().toFixed(3); TC.grbl.send(`$100=${v}`); TC.grbl.send(`$101=${v}`); };
  }

  /* ---------------- arranque ---------------- */
  buildTemplate(); renderPanel();
  setTimeout(() => { fit(); draw(); }, 50);
  TC.app.refresh = () => { fit(); draw(); };
  TC.app.setDesign = setDesign;
})(window.TC);
