/* TallerCNC - importar SVG y DXF (LibreCAD, QCAD, FreeCAD, Inkscape, AutoCAD).
 * Capas: rojo/corte -> corte, verde/doblez -> doblez, azul/grabado -> grabado. Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  function layerFromColor(c) {
    if (!c) return 'cut';
    c = c.toLowerCase().trim();
    const ctx = document.createElement('canvas').getContext('2d'); ctx.fillStyle = '#000'; ctx.fillStyle = c; const hex = ctx.fillStyle;
    if (!/^#/.test(hex)) return 'cut';
    const n = parseInt(hex.slice(1), 16), r = n >> 16 & 255, g = n >> 8 & 255, b = n & 255;
    if (r > 150 && g < 120 && b < 120) return 'cut';
    if (r > 200 && g > 120 && b < 100) return 'valley';
    if (g > 120 && r < 120 && b < 150) return 'fold';
    if (b > 150 && r < 120) return 'engrave';
    if (r === g && g === b && r > 100) return 'ref';
    return 'cut';
  }
  function layerFromName(name) {
    const s = (name || '').toLowerCase();
    if (/valle|valley/.test(s)) return 'valley';
    if (/dobl|fold|crease|score|monte|mountain/.test(s)) return 'fold';
    if (/grab|engrav|etch|raster/.test(s)) return 'engrave';
    if (/ref|guia|guide|const/.test(s)) return 'ref';
    if (/cort|cut/.test(s)) return 'cut';
    return null;
  }

  /* ---------- SVG ---------- */
  TC.importSVG = function (text, tol = 0.2) {
    const host = document.createElement('div');
    host.style.cssText = 'position:absolute;left:-99999px;top:0;width:1px;height:1px;overflow:hidden';
    host.innerHTML = text.replace(/<\?xml[^>]*>/, '').replace(/<!DOCTYPE[^>]*>/i, '');
    document.body.appendChild(host);
    const svg = host.querySelector('svg'); const items = [];
    try {
      // escala px -> mm
      let s = 25.4 / 96;
      const wAttr = svg.getAttribute('width'), vb = svg.viewBox && svg.viewBox.baseVal;
      const unit = v => { const m = /([\d.]+)\s*(mm|cm|in|pt|px)?/.exec(v || ''); if (!m) return null; const f = { mm: 1, cm: 10, in: 25.4, pt: 25.4 / 72, px: 25.4 / 96 }[m[2] || 'px']; return +m[1] * f; };
      if (wAttr && vb && vb.width) { const mm = unit(wAttr); if (mm) s = mm / vb.width; }
      const els = svg.querySelectorAll('path,line,polyline,polygon,rect,circle,ellipse');
      const root = svg.getScreenCTM ? svg.getCTM() : null; void root;
      els.forEach(el => {
        if (el.closest('defs,clipPath,mask,symbol')) return;
        const cs = getComputedStyle(el); if (cs.display === 'none') return;
        const lay = layerFromName(el.closest('g[id],g[inkscape\\:label]')?.getAttribute('inkscape:label') || el.closest('g[id]')?.id) || layerFromColor(cs.stroke !== 'none' ? cs.stroke : cs.fill);
        const len = el.getTotalLength ? el.getTotalLength() : 0; if (!len) return;
        const m = el.getCTM(), svgM = svg.getCTM(), M = svgM ? svgM.inverse().multiply(m) : m;
        // dividir en subtrazos: detectamos saltos grandes
        const n = Math.min(20000, Math.max(8, Math.ceil(len * s / tol)));
        let cur = [], prev = null; const step = len / n;
        const closedTag = /^(polygon|rect|circle|ellipse)$/.test(el.tagName);
        for (let i = 0; i <= n; i++) {
          const pt = el.getPointAtLength(Math.min(len, i * step)); const x = M.a * pt.x + M.c * pt.y + M.e, y = M.b * pt.x + M.d * pt.y + M.f;
          const q = [x * s, -y * s];
          if (prev && Math.hypot(q[0] - prev[0], q[1] - prev[1]) > step * s * 3 + 0.5) { if (cur.length > 1) items.push(TC.path(cur, lay, false)); cur = []; }
          cur.push(q); prev = q;
        }
        if (cur.length > 1) {
          const closed = closedTag || (Math.hypot(cur[0][0] - cur[cur.length - 1][0], cur[0][1] - cur[cur.length - 1][1]) < 0.05);
          if (closed && cur.length > 2) cur.pop();
          items.push(TC.path(simplify(cur, tol / 4), lay, closed));
        }
      });
    } finally { host.remove(); }
    return TC.normalize(items, 0);
  };

  function simplify(pts, eps) { // Ramer-Douglas-Peucker
    if (pts.length < 3) return pts;
    const d2 = (p, a, b) => { const dx = b[0] - a[0], dy = b[1] - a[1], l = dx * dx + dy * dy; if (!l) return Math.hypot(p[0] - a[0], p[1] - a[1]); const t = Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l)); return Math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy); };
    const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1; const st = [[0, pts.length - 1]];
    while (st.length) { const [i, j] = st.pop(); let md = 0, mi = -1; for (let k = i + 1; k < j; k++) { const d = d2(pts[k], pts[i], pts[j]); if (d > md) { md = d; mi = k; } } if (md > eps) { keep[mi] = 1; st.push([i, mi], [mi, j]); } }
    return pts.filter((_, i) => keep[i]);
  }
  TC.simplify = simplify;

  /* ---------- DXF ---------- */
  TC.importDXF = function (text) {
    const lines = text.split(/\r?\n/); const pairs = [];
    for (let i = 0; i + 1 < lines.length; i += 2) pairs.push([parseInt(lines[i].trim(), 10), lines[i + 1].trim()]);
    let scale = 1; const items = []; const layerColor = {};
    // unidades
    for (let i = 0; i < pairs.length; i++) if (pairs[i][0] === 9 && pairs[i][1] === '$INSUNITS') { const u = +pairs[i + 1][1]; scale = { 1: 25.4, 2: 304.8, 4: 1, 5: 10, 6: 1000 }[u] || 1; }
    // colores de capa
    for (let i = 0; i < pairs.length; i++) if (pairs[i][0] === 0 && pairs[i][1] === 'LAYER') { let name = '', col = 7; for (let j = i + 1; j < pairs.length && pairs[j][0] !== 0; j++) { if (pairs[j][0] === 2) name = pairs[j][1]; if (pairs[j][0] === 62) col = Math.abs(+pairs[j][1]); } layerColor[name] = col; }
    const aci = c => ({ 1: 'cut', 3: 'fold', 2: 'valley', 5: 'engrave', 4: 'engrave', 8: 'ref', 9: 'ref' })[c] || 'cut';
    const pickLayer = (lname, col) => layerFromName(lname) || aci(col != null ? col : layerColor[lname]);
    let i = pairs.findIndex(p => p[0] === 2 && p[1] === 'ENTITIES'); if (i < 0) i = 0;
    const arc = (cx, cy, r, a0, a1) => { if (a1 < a0) a1 += 360; return TC.arcPts(cx, cy, r, a0 * Math.PI / 180, a1 * Math.PI / 180); };
    const bulgePts = (p, q, bulge) => {
      if (!bulge) return [q];
      const th = 4 * Math.atan(bulge), dx = q[0] - p[0], dy = q[1] - p[1], c = Math.hypot(dx, dy), r = c / (2 * Math.sin(th / 2));
      const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2, hh = Math.sqrt(Math.max(0, r * r - c * c / 4)) * Math.sign(bulge) * (Math.abs(th) > Math.PI ? -1 : 1);
      const cx = mx - dy / c * hh, cy = my + dx / c * hh, a0 = Math.atan2(p[1] - cy, p[0] - cx); let a1 = Math.atan2(q[1] - cy, q[0] - cx);
      if (bulge > 0 && a1 < a0) a1 += 2 * Math.PI; if (bulge < 0 && a1 > a0) a1 -= 2 * Math.PI;
      return TC.arcPts(cx, cy, Math.abs(r), a0, a1).slice(1);
    };
    while (i < pairs.length) {
      if (pairs[i][0] !== 0) { i++; continue; }
      const type = pairs[i][1]; const e = { codes: [] }; let j = i + 1;
      for (; j < pairs.length && pairs[j][0] !== 0; j++) e.codes.push(pairs[j]);
      const g = (c, d) => { const f = e.codes.find(p => p[0] === c); return f ? f[1] : d; };
      const gn = (c, d = 0) => parseFloat(g(c, d));
      const lay = pickLayer(g(8, ''), g(62, null) != null ? Math.abs(+g(62)) : null);
      if (type === 'LINE') items.push(TC.line(gn(10), gn(20), gn(11), gn(21), lay));
      else if (type === 'CIRCLE') items.push(TC.circle(gn(10), gn(20), gn(40), lay));
      else if (type === 'ARC') items.push(TC.path(arc(gn(10), gn(20), gn(40), gn(50), gn(51)), lay, false));
      else if (type === 'LWPOLYLINE') {
        const v = []; let last = null;
        for (const [c, val] of e.codes) { if (c === 10) { last = { x: +val, y: 0, b: 0 }; v.push(last); } else if (c === 20 && last) last.y = +val; else if (c === 42 && last) last.b = +val; }
        const closed = (+g(70, 0) & 1) === 1; const pts = [];
        v.forEach((p, k) => { if (k === 0) pts.push([p.x, p.y]); else pts.push(...bulgePts([v[k - 1].x, v[k - 1].y], [p.x, p.y], v[k - 1].b)); });
        if (closed && v.length > 1) { const tail = bulgePts([v[v.length - 1].x, v[v.length - 1].y], [v[0].x, v[0].y], v[v.length - 1].b); tail.pop(); pts.push(...tail); }
        if (pts.length > 1) items.push(TC.path(pts, lay, closed));
      } else if (type === 'POLYLINE') {
        const closed = (+g(70, 0) & 1) === 1; const v = []; let k = j;
        while (k < pairs.length && !(pairs[k][0] === 0 && pairs[k][1] === 'SEQEND')) {
          if (pairs[k][0] === 0 && pairs[k][1] === 'VERTEX') { const vv = { x: 0, y: 0, b: 0 }; k++; for (; k < pairs.length && pairs[k][0] !== 0; k++) { if (pairs[k][0] === 10) vv.x = +pairs[k][1]; if (pairs[k][0] === 20) vv.y = +pairs[k][1]; if (pairs[k][0] === 42) vv.b = +pairs[k][1]; } v.push(vv); } else k++;
        }
        const pts = []; v.forEach((p, n) => { if (n === 0) pts.push([p.x, p.y]); else pts.push(...bulgePts([v[n - 1].x, v[n - 1].y], [p.x, p.y], v[n - 1].b)); });
        if (pts.length > 1) items.push(TC.path(pts, lay, closed)); j = k;
      } else if (type === 'SPLINE') {
        const pts = []; let last = null; for (const [c, val] of e.codes) { if (c === 10) { last = [+val, 0]; pts.push(last); } else if (c === 20 && last) last[1] = +val; }
        if (pts.length > 1) items.push(TC.path(chaikin(pts, 3), lay, (+g(70, 0) & 1) === 1));
      } else if (type === 'ELLIPSE') {
        const cx = gn(10), cy = gn(20), mx = gn(11), my = gn(21), ra = gn(40, 1), t0 = gn(41, 0), t1 = gn(42, Math.PI * 2);
        const R = Math.hypot(mx, my), ang = Math.atan2(my, mx), pts = []; const n = 72;
        for (let q = 0; q <= n; q++) { const t = t0 + (t1 - t0) * q / n, x = R * Math.cos(t), y = R * ra * Math.sin(t); pts.push([cx + x * Math.cos(ang) - y * Math.sin(ang), cy + x * Math.sin(ang) + y * Math.cos(ang)]); }
        items.push(TC.path(pts, lay, Math.abs(t1 - t0 - 2 * Math.PI) < 1e-3));
      } else if (type === 'ENDSEC' && items.length) break;
      i = j;
    }
    return TC.normalize(TC.joinSegments(TC.scale(items, scale)), 0);
  };
  function chaikin(pts, it) { for (let k = 0; k < it; k++) { const o = [pts[0]]; for (let i = 0; i + 1 < pts.length; i++) { const a = pts[i], b = pts[i + 1]; o.push([0.75 * a[0] + 0.25 * b[0], 0.75 * a[1] + 0.25 * b[1]], [0.25 * a[0] + 0.75 * b[0], 0.25 * a[1] + 0.75 * b[1]]); } o.push(pts[pts.length - 1]); pts = o; } return pts; }
})(window.TC);
