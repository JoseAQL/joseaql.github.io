/* TallerCNC - control de GRBL por USB (Web Serial) y flasheo del Arduino (STK500v1).
 * Funciona en Chrome/Edge y en la app de escritorio (Electron). Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const enc = new TextEncoder(), dec = new TextDecoder();
  const RX_BUFFER = 127; // tamaño del búfer serie de GRBL en Arduino Uno (128 - 1)

  class Grbl {
    constructor() {
      this.port = null; this.reader = null; this.writer = null; this.buf = ''; this.listeners = {};
      this.status = { state: 'Desconectado', mpos: [0, 0, 0], wpos: [0, 0, 0], wco: [0, 0, 0], feed: 0, spindle: 0 };
      this.queue = []; this.sent = []; this.streaming = false; this.paused = false; this.total = 0; this.done = 0; this.poll = null;
    }
    on(ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); }
    emit(ev, ...a) { (this.listeners[ev] || []).forEach(f => f(...a)); }
    get supported() { return 'serial' in navigator; }

    async connect(baud = 115200) {
      if (!this.supported) throw new Error('Este navegador no tiene Web Serial. Usa Chrome/Edge o la app de escritorio.');
      this.port = await navigator.serial.requestPort();
      await this.port.open({ baudRate: baud });
      this.writer = this.port.writable.getWriter();
      this.readLoop();
      this.status.state = 'Conectando…'; this.emit('status', this.status);
      setTimeout(() => this.realtime('\x18'), 300); // soft reset para leer el saludo
      this.poll = setInterval(() => { if (this.port) this.realtime('?'); }, 250);
    }
    async disconnect() {
      clearInterval(this.poll); this.poll = null; this.streaming = false;
      try { this.reader && await this.reader.cancel(); } catch (e) { /* */ }
      try { this.writer && this.writer.releaseLock(); } catch (e) { /* */ }
      try { this.port && await this.port.close(); } catch (e) { /* */ }
      this.port = null; this.status.state = 'Desconectado'; this.emit('status', this.status);
    }
    async readLoop() {
      while (this.port && this.port.readable) {
        this.reader = this.port.readable.getReader();
        try {
          for (;;) {
            const { value, done } = await this.reader.read(); if (done) break;
            this.buf += dec.decode(value); let i;
            while ((i = this.buf.indexOf('\n')) >= 0) { const line = this.buf.slice(0, i).trim(); this.buf = this.buf.slice(i + 1); if (line) this.handle(line); }
          }
        } catch (e) { this.emit('log', '! ' + e.message, 'err'); break; }
        finally { try { this.reader.releaseLock(); } catch (e) { /* */ } }
      }
    }
    handle(line) {
      if (line[0] === '<') { this.parseStatus(line); return; }
      if (line === 'ok' || line.startsWith('error')) {
        const c = this.sent.shift();
        if (line.startsWith('error')) this.emit('log', `${line} ← ${c ? c.line : ''} (${errText(line)})`, 'err');
        else if (!this.streaming) this.emit('log', 'ok', 'ok');
        if (this.streaming) { this.done++; this.emit('progress', this.done, this.total); this.pump(); }
        return;
      }
      if (line.startsWith('ALARM')) { this.emit('log', `${line} (${alarmText(line)})`, 'err'); this.streaming = false; }
      else if (line.startsWith('Grbl')) { this.sent = []; this.emit('log', line, 'info'); this.emit('hello', line); }
      else this.emit('log', line, 'info');
    }
    parseStatus(line) {
      const parts = line.slice(1, -1).split('|'); this.status.state = parts[0];
      for (const p of parts.slice(1)) {
        const [k, v] = p.split(':'); const n = v ? v.split(',').map(Number) : [];
        if (k === 'MPos') { this.status.mpos = n; this.status.wpos = n.map((x, i) => x - (this.status.wco[i] || 0)); }
        else if (k === 'WPos') { this.status.wpos = n; this.status.mpos = n.map((x, i) => x + (this.status.wco[i] || 0)); }
        else if (k === 'WCO') { this.status.wco = n; this.status.wpos = this.status.mpos.map((x, i) => x - n[i]); }
        else if (k === 'FS') { this.status.feed = n[0]; this.status.spindle = n[1]; }
      }
      this.emit('status', this.status);
    }
    async write(s) { if (!this.writer) throw new Error('No conectado'); await this.writer.write(enc.encode(s)); }
    realtime(ch) { if (this.writer) this.writer.write(enc.encode(ch)).catch(() => {}); }
    async send(line) {
      line = line.trim(); if (!line) return;
      this.sent.push({ line, len: line.length + 1 }); this.emit('log', '> ' + line, 'tx'); await this.write(line + '\n');
    }
    /** Envío con conteo de caracteres (el método recomendado para GRBL). */
    stream(gcode) {
      this.queue = gcode.split('\n').map(l => l.replace(/;.*|\(.*?\)/g, '').trim()).filter(Boolean);
      this.total = this.queue.length; this.done = 0; this.streaming = true; this.paused = false; this.sent = [];
      this.emit('progress', 0, this.total); this.pump();
    }
    pump() {
      if (!this.streaming || this.paused) return;
      let used = this.sent.reduce((s, c) => s + c.len, 0);
      while (this.queue.length && used + this.queue[0].length + 1 <= RX_BUFFER) {
        const line = this.queue.shift(); this.sent.push({ line, len: line.length + 1 }); used += line.length + 1;
        this.write(line + '\n').catch(e => this.emit('log', e.message, 'err'));
      }
      if (!this.queue.length && !this.sent.length) { this.streaming = false; this.emit('finished'); }
    }
    hold() { this.realtime('!'); this.paused = true; }
    resume() { this.realtime('~'); this.paused = false; this.pump(); }
    stop() { this.queue = []; this.streaming = false; this.realtime('!'); setTimeout(() => this.realtime('\x18'), 200); this.realtime('\x85'); }
    jog(axis, dist, feed) { return this.send(`$J=G21G91${axis}${dist}F${feed}`); }
    jogCancel() { this.realtime('\x85'); }
  }
  TC.grbl = new Grbl();

  const ERR = { 1: 'G-code sin letra', 2: 'valor numérico mal escrito', 3: 'comando $ no reconocido', 5: 'homing no habilitado ($22)', 8: 'no se puede en este estado (¿alarma? usa $X)', 9: 'G-code bloqueado por alarma o jog', 15: 'jog fuera del área de trabajo', 20: 'comando G-code no soportado', 22: 'falta velocidad F', 33: 'arco inválido' };
  const ALM = { 1: 'final de carrera tocado (límite duro)', 2: 'movimiento fuera del área (límite suave)', 3: 'reset durante movimiento', 8: 'homing falló: no encontró el final de carrera', 9: 'homing falló: no encontró el interruptor' };
  const errText = l => ERR[+l.split(':')[1]] || 'ver wiki de GRBL';
  const alarmText = l => ALM[+l.split(':')[1]] || 'revisa la máquina y desbloquea con $X';

  /* Descripción de los ajustes $ de GRBL 1.1 */
  TC.GRBL_SETTINGS = {
    0: 'Pulso de paso (µs)', 1: 'Retardo para apagar motores (ms, 255 = siempre activos)', 2: 'Invertir pulso de paso (máscara)', 3: 'Invertir dirección (máscara X=1,Y=2,Z=4)', 4: 'Invertir enable', 5: 'Invertir finales de carrera', 6: 'Invertir sonda',
    10: 'Reporte de estado', 11: 'Desviación de unión (mm)', 12: 'Tolerancia de arcos (mm)', 13: 'Reportar en pulgadas', 20: 'Límites suaves (0/1)', 21: 'Límites duros (0/1)', 22: 'Homing habilitado (0/1)', 23: 'Dirección de homing (máscara)', 24: 'Velocidad fina de homing', 25: 'Velocidad de búsqueda de homing', 26: 'Antirrebote homing (ms)', 27: 'Retroceso homing (mm)',
    30: 'RPM / potencia máxima (S máximo)', 31: 'RPM / potencia mínima', 32: 'Modo láser (1 = sí)', 100: 'Pasos/mm X', 101: 'Pasos/mm Y', 102: 'Pasos/mm Z', 110: 'Velocidad máx X (mm/min)', 111: 'Velocidad máx Y', 112: 'Velocidad máx Z', 120: 'Aceleración X (mm/s²)', 121: 'Aceleración Y', 122: 'Aceleración Z', 130: 'Recorrido máx X (mm)', 131: 'Recorrido máx Y', 132: 'Recorrido máx Z'
  };
  /** Pasos/mm: (pasos por vuelta × micropasos) / avance por vuelta. */
  TC.stepsPerMM = (stepsRev, micro, mmPerRev) => stepsRev * micro / mmPerRev;

  /* ================= Flasheo de GRBL (STK500v1, bootloader Optiboot) ================= */
  function parseHex(text) {
    const mem = new Uint8Array(32768).fill(0xff); let max = 0, base = 0;
    for (const l of text.split(/\r?\n/)) {
      if (l[0] !== ':') continue;
      const n = parseInt(l.substr(1, 2), 16), addr = parseInt(l.substr(3, 4), 16), type = parseInt(l.substr(7, 2), 16);
      if (type === 0) { for (let i = 0; i < n; i++) mem[base + addr + i] = parseInt(l.substr(9 + i * 2, 2), 16); max = Math.max(max, base + addr + n); }
      else if (type === 2) base = parseInt(l.substr(9, 4), 16) * 16;
      else if (type === 1) break;
    }
    return mem.slice(0, max);
  }
  TC.parseHex = parseHex;

  /** Flashea un .hex al Arduino. board: 'uno' (115200) o 'nano-old' (57600). */
  TC.flashArduino = async function (hexText, board = 'uno', log = () => {}) {
    if (!('serial' in navigator)) throw new Error('Necesitas Chrome/Edge o la app de escritorio para flashear.');
    if (TC.grbl.port) await TC.grbl.disconnect();
    const baud = board === 'nano-old' ? 57600 : board === 'mega' ? 115200 : 115200;
    if (board === 'mega') throw new Error('El Mega usa STK500v2: usa los scripts de avrdude incluidos.');
    const data = parseHex(hexText); log(`Firmware: ${data.length} bytes`);
    const port = await navigator.serial.requestPort();
    await port.open({ baudRate: baud });
    const writer = port.writable.getWriter(), reader = port.readable.getReader();
    let rx = [];
    const pumpRead = (async () => { try { for (;;) { const { value, done } = await reader.read(); if (done) break; rx.push(...value); } } catch (e) { /* cerrado */ } })();
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const waitBytes = async (n, ms = 1000) => { const t = Date.now(); while (rx.length < n && Date.now() - t < ms) await sleep(5); const out = rx.slice(0, n); rx = rx.slice(n); return out; };
    const cmd = async (bytes, expect = 2, ms = 1000) => { rx = []; await writer.write(new Uint8Array([...bytes, 0x20])); const r = await waitBytes(expect, ms); if (r[0] !== 0x14 || r[r.length - 1] !== 0x10) throw new Error('El bootloader no respondió bien (' + r.map(b => b.toString(16)).join(' ') + ')'); return r; };
    try {
      log('Reiniciando el Arduino…');
      await port.setSignals({ dataTerminalReady: false, requestToSend: false }); await sleep(250);
      await port.setSignals({ dataTerminalReady: true, requestToSend: true }); await sleep(50);
      let ok = false;
      for (let i = 0; i < 10 && !ok; i++) { try { await cmd([0x30], 2, 300); ok = true; } catch (e) { await sleep(50); } }
      if (!ok) throw new Error('No hubo sincronía con el bootloader. Revisa el puerto, la placa (Uno/Nano) y que no esté abierto en otro programa.');
      log('Sincronizado. Firma del chip…');
      rx = []; await writer.write(new Uint8Array([0x75, 0x20])); const sig = await waitBytes(5);
      log('Firma: ' + sig.slice(1, 4).map(b => b.toString(16).padStart(2, '0')).join(' ') + (sig[1] === 0x1e && sig[2] === 0x95 && sig[3] === 0x0f ? ' (ATmega328P ✓)' : ''));
      await cmd([0x50]); // entrar a modo de programación
      const page = 128;
      for (let a = 0; a < data.length; a += page) {
        const w = a >> 1; await cmd([0x55, w & 0xff, w >> 8]);
        const chunk = data.slice(a, a + page);
        await cmd([0x64, chunk.length >> 8, chunk.length & 0xff, 0x46, ...chunk], 2, 2000);
        if ((a / page) % 16 === 0) log(`Escribiendo… ${Math.round(a / data.length * 100)}%`);
      }
      log('Verificando…');
      for (let a = 0; a < data.length; a += page) {
        const w = a >> 1; await cmd([0x55, w & 0xff, w >> 8]);
        const n = Math.min(page, data.length - a); rx = [];
        await writer.write(new Uint8Array([0x74, n >> 8, n & 0xff, 0x46, 0x20])); const r = await waitBytes(n + 2, 2000);
        for (let i = 0; i < n; i++) if (r[i + 1] !== data[a + i]) throw new Error(`Error de verificación en 0x${(a + i).toString(16)}`);
      }
      await cmd([0x51]);
      log('¡Listo! GRBL quedó grabado. Conéctate a 115200 baudios.');
    } finally {
      try { await reader.cancel(); } catch (e) { /* */ } await pumpRead;
      try { reader.releaseLock(); writer.releaseLock(); await port.close(); } catch (e) { /* */ }
    }
  };
})(window.TC);
