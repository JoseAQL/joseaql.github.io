/* TallerCNC - exportar SVG, DXF y PDF a escala real. Licencia GPL-3.0-or-later */
'use strict';
(function (TC) {
  const paths = items => items.filter(i => i.type === 'path' && i.pts.length > 1);

  /* ---------- SVG (mm, y hacia abajo) ---------- */
  TC.toSVG = function (items, opts = {}) {
    const m = opts.margin ?? 5, b = TC.bbox(items), W = b.w + 2 * m, H = b.h + 2 * m;
    const X = x => (x - b.x0 + m).toFixed(3), Y = y => (b.y1 - y + m).toFixed(3);
    const groups = {};
    for (const it of paths(items)) {
      const d = 'M' + it.pts.map(p => X(p[0]) + ' ' + Y(p[1])).join(' L') + (it.closed ? ' Z' : '');
      (groups[it.layer] = groups[it.layer] || []).push(`<path d="${d}"/>`);
    }
    let rasters = '';
    for (const it of items.filter(i => i.type === 'raster' && i.canvas)) {
      rasters += `<image x="${X(it.x)}" y="${Y(it.y + it.h)}" width="${it.w}" height="${it.h}" href="${it.canvas.toDataURL()}" preserveAspectRatio="none"/>`;
    }
    const dash = { fold: ' stroke-dasharray="3 1.5"', valley: ' stroke-dasharray="1 1"', ref: ' stroke-dasharray="0.5 1"' };
    const g = Object.keys(groups).map(k => `<g id="${k}" inkscape:label="${TC.LAYERS[k].name}" inkscape:groupmode="layer" fill="none" stroke="${TC.LAYERS[k].color}" stroke-width="${opts.sw ?? 0.2}"${dash[k] || ''}>${groups[k].join('')}</g>`).join('\n');
    return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="${W.toFixed(3)}mm" height="${H.toFixed(3)}mm" viewBox="0 0 ${W.toFixed(3)} ${H.toFixed(3)}">
<!-- Generado por TallerCNC. Rojo=corte, verde=doblez monte, naranja=doblez valle, azul=grabado -->
${rasters}
${g}
</svg>`;
  };

  /* ---------- DXF R12 (mm) ---------- */
  TC.toDXF = function (items) {
    const o = [];
    const w = (c, v) => o.push(String(c), String(v));
    w(0, 'SECTION'); w(2, 'HEADER'); w(9, '$ACADVER'); w(1, 'AC1009'); w(9, '$INSUNITS'); w(70, 4); w(9, '$MEASUREMENT'); w(70, 1); w(0, 'ENDSEC');
    w(0, 'SECTION'); w(2, 'TABLES'); w(0, 'TABLE'); w(2, 'LAYER'); w(70, Object.keys(TC.LAYERS).length);
    for (const [k, L] of Object.entries(TC.LAYERS)) { w(0, 'LAYER'); w(2, k.toUpperCase()); w(70, 0); w(62, L.dxf); w(6, 'CONTINUOUS'); }
    w(0, 'ENDTAB'); w(0, 'ENDSEC');
    w(0, 'SECTION'); w(2, 'ENTITIES');
    for (const it of paths(items)) {
      const lay = it.layer.toUpperCase();
      if (it.pts.length === 2 && !it.closed) {
        w(0, 'LINE'); w(8, lay); w(10, it.pts[0][0].toFixed(4)); w(20, it.pts[0][1].toFixed(4)); w(30, 0); w(11, it.pts[1][0].toFixed(4)); w(21, it.pts[1][1].toFixed(4)); w(31, 0);
      } else {
        w(0, 'POLYLINE'); w(8, lay); w(66, 1); w(10, 0); w(20, 0); w(30, 0); w(70, it.closed ? 1 : 0);
        for (const p of it.pts) { w(0, 'VERTEX'); w(8, lay); w(10, p[0].toFixed(4)); w(20, p[1].toFixed(4)); w(30, 0); }
        w(0, 'SEQEND'); w(8, lay);
      }
    }
    w(0, 'ENDSEC'); w(0, 'EOF');
    return o.join('\r\n') + '\r\n';
  };

  /* ---------- PDF vectorial, escala 1:1, dividido en hojas ---------- */
  const PAGES = { carta: [215.9, 279.4], a4: [210, 297], oficio: [215.9, 340.4], tabloide: [279.4, 431.8], a3: [297, 420] };
  TC.PAGES = PAGES;
  TC.toPDF = function (items, opts = {}) {
    const [pw0, ph0] = PAGES[opts.page || 'carta'];
    const land = opts.landscape, pw = land ? ph0 : pw0, ph = land ? pw0 : ph0;
    const marg = opts.margin ?? 10, ov = opts.overlap ?? 0; // mm
    const b = TC.bbox(items), uw = pw - 2 * marg, uh = ph - 2 * marg;
    const nx = Math.max(1, Math.ceil((b.w - ov) / (uw - ov))), ny = Math.max(1, Math.ceil((b.h - ov) / (uh - ov)));
    const k = 72 / 25.4; // pt por mm
    const col = hex => { const n = parseInt(hex.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255].map(v => v.toFixed(3)).join(' '); };
    const dash = { fold: '[6 3] 0 d', valley: '[2 2] 0 d', ref: '[1 2] 0 d' };
    const pageStreams = [];
    for (let j = ny - 1; j >= 0; j--) for (let i = 0; i < nx; i++) {
      const ox = b.x0 + i * (uw - ov), oy = b.y0 + j * (uh - ov);
      let s = 'q\n';
      // recorte al área útil
      s += `${(marg * k).toFixed(2)} ${(marg * k).toFixed(2)} ${(uw * k).toFixed(2)} ${(uh * k).toFixed(2)} re W n\n`;
      const byLayer = {};
      for (const it of paths(items)) (byLayer[it.layer] = byLayer[it.layer] || []).push(it);
      for (const [lay, list] of Object.entries(byLayer)) {
        if (opts.monochrome) s += '0 0 0 RG\n'; else s += col(TC.LAYERS[lay].color) + ' RG\n';
        s += (dash[lay] || '[] 0 d') + '\n' + (opts.lw ?? 0.5) + ' w 1 J 1 j\n';
        for (const it of list) {
          s += it.pts.map((p, n) => `${((p[0] - ox + marg) * k).toFixed(2)} ${((p[1] - oy + marg) * k).toFixed(2)} ${n ? 'l' : 'm'}`).join('\n');
          s += it.closed ? ' h S\n' : ' S\n';
        }
      }
      s += 'Q\n';
      // marco, etiqueta y regla de verificación
      s += '0.6 g 0.6 G 0.3 w [] 0 d\n';
      s += `${(marg * k).toFixed(2)} ${(marg * k).toFixed(2)} ${(uw * k).toFixed(2)} ${(uh * k).toFixed(2)} re S\n`;
      const label = `TallerCNC  hoja ${String.fromCharCode(65 + (ny - 1 - j))}${i + 1}  (${nx}x${ny})  Escala 1:1 - imprimir al 100%, sin ajustar a pagina`;
      s += `BT /F1 7 Tf ${(marg * k).toFixed(2)} ${((marg - 6) * k).toFixed(2)} Td (${label}) Tj ET\n`;
      if (i === 0 && j === ny - 1 || opts.rulerAll) {
        const rx = (pw - marg - 52) * k, ry = (ph - marg + 2) * k;
        s += `0 g 0 G 0.5 w ${rx.toFixed(2)} ${ry.toFixed(2)} m ${(rx + 50 * k).toFixed(2)} ${ry.toFixed(2)} l S\n`;
        for (let t = 0; t <= 50; t += 10) s += `${(rx + t * k).toFixed(2)} ${ry.toFixed(2)} m ${(rx + t * k).toFixed(2)} ${(ry + 4).toFixed(2)} l S\n`;
        s += `BT /F1 6 Tf ${(rx - 60).toFixed(2)} ${(ry).toFixed(2)} Td (50 mm =) Tj ET\n`;
      }
      pageStreams.push(s);
    }
    // ensamblar el PDF
    const objs = [];
    const add = s => { objs.push(s); return objs.length; };
    const catalog = add(''), pagesObj = add(''), font = add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
    const kids = [];
    for (const s of pageStreams) {
      const c = add(`<< /Length ${s.length} >>\nstream\n${s}endstream`);
      kids.push(add(`<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${(pw * k).toFixed(2)} ${(ph * k).toFixed(2)}] /Resources << /Font << /F1 ${font} 0 R >> >> /Contents ${c} 0 R >>`));
    }
    objs[catalog - 1] = `<< /Type /Catalog /Pages ${pagesObj} 0 R /ViewerPreferences << /PrintScaling /None >> >>`;
    objs[pagesObj - 1] = `<< /Type /Pages /Kids [${kids.map(n => n + ' 0 R').join(' ')}] /Count ${kids.length} >>`;
    let out = '%PDF-1.4\n%âãÏÓ\n'; const offs = [];
    objs.forEach((o, n) => { offs.push(out.length); out += `${n + 1} 0 obj\n${o}\nendobj\n`; });
    const xref = out.length;
    out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map(o => String(o).padStart(10, '0') + ' 00000 n \n').join('');
    out += `trailer\n<< /Size ${objs.length + 1} /Root ${catalog} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    const bytes = new Uint8Array(out.length); for (let n = 0; n < out.length; n++) bytes[n] = out.charCodeAt(n) & 255;
    return { bytes, pages: pageStreams.length, nx, ny };
  };
})(window.TC);
