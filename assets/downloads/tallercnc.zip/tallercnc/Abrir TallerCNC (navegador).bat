@echo off
REM Abre TallerCNC sin instalar nada. Usa Edge o Chrome (necesarios para el puerto USB).
set "APP=%~dp0index.html"
where msedge >nul 2>nul && (start "" msedge --app="file:///%APP:\=/%" & exit /b)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%APP:\=/%" & exit /b)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%APP:\=/%" & exit /b)
start "" "%APP%"
