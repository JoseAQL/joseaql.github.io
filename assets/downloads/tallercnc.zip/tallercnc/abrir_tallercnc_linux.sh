#!/usr/bin/env bash
# Abre TallerCNC sin instalar nada (Chrome o Chromium para usar el puerto USB).
DIR="$(cd "$(dirname "$0")" && pwd)"
for b in google-chrome chromium chromium-browser microsoft-edge; do
  if command -v $b >/dev/null; then exec $b --app="file://$DIR/index.html"; fi
done
xdg-open "$DIR/index.html"
