#!/usr/bin/env bash
# Construye AppImage y .deb (requiere Node.js 18+)
cd "$(dirname "$0")" && npm install && npm run dist:linux && echo "Listo en escritorio/dist"
