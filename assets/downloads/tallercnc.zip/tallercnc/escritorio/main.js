// TallerCNC - app de escritorio (Electron) para Windows 10/11 y Linux.
// Habilita el puerto USB (Web Serial), el proyector en pantalla externa y la vigilancia de archivos CAD.
// Licencia GPL-3.0-or-later
const { app, BrowserWindow, ipcMain, dialog, screen, Menu, shell } = require('electron');
const path = require('path');
const fs = require('fs');

let win = null, watcher = null;
const ROOT = app.isPackaged ? path.join(process.resourcesPath, 'app-web') : path.join(__dirname, '..');

function createWindow() {
  win = new BrowserWindow({
    width: 1400, height: 880, minWidth: 980, minHeight: 600, backgroundColor: '#121417', title: 'TallerCNC',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(ROOT, 'index.html'));

  const ses = win.webContents.session;
  // Puertos serie: si hay uno lo usa; si hay varios, pregunta cuál.
  ses.on('select-serial-port', async (event, ports, webContents, callback) => {
    event.preventDefault();
    if (!ports.length) { dialog.showMessageBox(win, { type: 'warning', message: 'No se encontró ningún puerto USB. Conecta el Arduino e intenta de nuevo.' }); return callback(''); }
    if (ports.length === 1) return callback(ports[0].portId);
    const labels = ports.map(p => `${p.portName || p.portId}${p.displayName ? ' — ' + p.displayName : ''}`);
    const r = await dialog.showMessageBox(win, { type: 'question', message: 'Elige el puerto del Arduino', buttons: [...labels, 'Cancelar'], cancelId: labels.length });
    callback(r.response < ports.length ? ports[r.response].portId : '');
  });
  ses.setPermissionCheckHandler((wc, permission) => permission === 'serial' || permission === 'fullscreen' || permission === 'window-management');
  ses.setDevicePermissionHandler(details => details.deviceType === 'serial');

  // Ventana del proyector: si hay una segunda pantalla, se abre ahí en pantalla completa.
  win.webContents.setWindowOpenHandler(({ frameName, url }) => {
    if (frameName === 'tallercnc_proyector') {
      const displays = screen.getAllDisplays(), primary = screen.getPrimaryDisplay();
      const ext = displays.find(d => d.id !== primary.id);
      const b = (ext || primary).bounds;
      return { action: 'allow', overrideBrowserWindowOptions: { x: b.x, y: b.y, width: b.width, height: b.height, fullscreen: !!ext, autoHideMenuBar: true, backgroundColor: '#000000', title: 'TallerCNC · Proyector' } };
    }
    if (/^https?:/.test(url)) { shell.openExternal(url); return { action: 'deny' }; }
    return { action: 'allow' };
  });
}

ipcMain.handle('watch-file', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Archivo a vigilar (DXF o SVG)', filters: [{ name: 'CAD', extensions: ['dxf', 'svg'] }], properties: ['openFile'] });
  if (r.canceled || !r.filePaths[0]) return null;
  const file = r.filePaths[0];
  if (watcher) watcher.close();
  let t = null;
  const send = () => { try { win.webContents.send('file-changed', path.basename(file), fs.readFileSync(file, 'utf8')); } catch (e) { /* archivo en escritura */ } };
  watcher = fs.watch(file, () => { clearTimeout(t); t = setTimeout(send, 400); });
  send();
  return file;
});

const menu = Menu.buildFromTemplate([
  { label: 'Archivo', submenu: [{ role: 'reload', label: 'Recargar' }, { type: 'separator' }, { role: 'quit', label: 'Salir' }] },
  { label: 'Ver', submenu: [{ role: 'togglefullscreen', label: 'Pantalla completa' }, { role: 'zoomIn', label: 'Acercar' }, { role: 'zoomOut', label: 'Alejar' }, { role: 'resetZoom', label: 'Tamaño normal' }, { role: 'toggleDevTools', label: 'Herramientas de desarrollo' }] },
  { label: 'Ayuda', submenu: [{ label: 'Wiki de GRBL', click: () => shell.openExternal('https://github.com/gnea/grbl/wiki') }, { label: 'Acerca de TallerCNC', click: () => dialog.showMessageBox(win, { message: 'TallerCNC 0.1\nSoftware libre (GPL-3.0) para diseñar, proyectar y cortar con láser o fresadora GRBL.\nSin suscripción y sin internet.' }) }] }
]);

app.whenReady().then(() => { Menu.setApplicationMenu(menu); createWindow(); });
app.on('window-all-closed', () => app.quit());
