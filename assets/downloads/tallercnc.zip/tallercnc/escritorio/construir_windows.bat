@echo off
REM Construye el instalador de Windows (requiere Node.js 18+ de https://nodejs.org)
cd /d "%~dp0"
call npm install
call npm run dist:win
echo Instalador en escritorio\dist
pause
