// Puente seguro entre la interfaz y el sistema (solo lo necesario). GPL-3.0-or-later
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('tallerDesktop', {
  watchFile: () => ipcRenderer.invoke('watch-file'),
  onFileChanged: cb => ipcRenderer.on('file-changed', (_e, name, text) => cb(name, text))
});
