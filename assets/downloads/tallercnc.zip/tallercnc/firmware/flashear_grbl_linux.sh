#!/usr/bin/env bash
# Flashea GRBL 1.1h a un Arduino Uno / Nano con avrdude (alternativa al botón "Flashear GRBL" de la app).
# Instala avrdude con:  sudo apt install avrdude
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
PUERTO="${1:-/dev/ttyUSB0}"
BAUD="${2:-115200}"   # usa 57600 para Nano con bootloader antiguo
echo "Puerto: $PUERTO  Baudios: $BAUD"
if ! command -v avrdude >/dev/null; then echo "Falta avrdude: sudo apt install avrdude"; exit 1; fi
avrdude -v -p atmega328p -c arduino -P "$PUERTO" -b "$BAUD" -D -U flash:w:"$DIR/grbl_v1.1h.20190825.hex":i
echo "Listo: GRBL 1.1h instalado. Conéctate a 115200 baudios desde TallerCNC."
