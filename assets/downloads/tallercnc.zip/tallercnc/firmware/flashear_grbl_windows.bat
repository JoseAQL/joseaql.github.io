@echo off
REM Flashea GRBL 1.1h a un Arduino Uno / Nano usando avrdude (alternativa al boton "Flashear GRBL" de la app).
REM Requiere avrdude: viene con el Arduino IDE o se descarga de https://github.com/avrdudes/avrdude/releases
setlocal
set /p PUERTO=Puerto del Arduino (ej. COM3):
set /p PLACA=Placa: 1 = Uno o Nano nuevo, 2 = Nano bootloader antiguo [1]:
set BAUD=115200
if "%PLACA%"=="2" set BAUD=57600
avrdude -v -p atmega328p -c arduino -P %PUERTO% -b %BAUD% -D -U flash:w:"%~dp0grbl_v1.1h.20190825.hex":i
if errorlevel 1 (
  echo.
  echo No se pudo flashear. Revisa el puerto, cierra otros programas que usen el Arduino y prueba la otra opcion de placa.
) else (
  echo.
  echo Listo: GRBL 1.1h instalado. Conectate a 115200 baudios desde TallerCNC.
)
pause
