#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
preparar_voc.py - Deja listo un dataset etiquetado (formato Pascal VOC) para train_ssd.py de jetson-inference.

Cuando exportas de CVAT o Roboflow en formato "Pascal VOC" te llegan imagenes .jpg y anotaciones .xml.
Este script las ordena en la estructura que espera train_ssd.py:

  instrumental/
    JPEGImages/      imagenes
    Annotations/     .xml
    ImageSets/Main/  train.txt  val.txt  trainval.txt  test.txt
    labels.txt       una clase por linea

Uso:
  python3 preparar_voc.py carpeta_exportada  instrumental
"""
import os
import random
import shutil
import sys
import xml.etree.ElementTree as ET


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    origen, destino = sys.argv[1], sys.argv[2]
    for sub in ("JPEGImages", "Annotations", "ImageSets/Main"):
        os.makedirs(os.path.join(destino, sub), exist_ok=True)
    imagenes, xmls = {}, {}
    for raiz, _, archivos in os.walk(origen):
        for a in archivos:
            base, ext = os.path.splitext(a)
            if ext.lower() in (".jpg", ".jpeg", ".png"):
                imagenes[base] = os.path.join(raiz, a)
            elif ext.lower() == ".xml":
                xmls[base] = os.path.join(raiz, a)
    ids, clases = [], set()
    for base, x in sorted(xmls.items()):
        if base not in imagenes:
            print("Sin imagen para", x)
            continue
        arbol = ET.parse(x)
        objetos = arbol.findall("object")
        if not objetos:
            continue
        for o in objetos:
            clases.add(o.find("name").text.strip())
        img_dest = os.path.join(destino, "JPEGImages", base + ".jpg")
        if imagenes[base].lower().endswith(".png"):
            import cv2
            cv2.imwrite(img_dest, cv2.imread(imagenes[base]))
        else:
            shutil.copy(imagenes[base], img_dest)
        fn = arbol.find("filename")
        if fn is not None:
            fn.text = base + ".jpg"
        arbol.write(os.path.join(destino, "Annotations", base + ".xml"))
        ids.append(base)
    if not ids:
        sys.exit("No encontre pares imagen + .xml con objetos")
    random.seed(7)
    random.shuffle(ids)
    n_val = max(1, len(ids) // 10)
    val, train = ids[:n_val], ids[n_val:]
    main_dir = os.path.join(destino, "ImageSets", "Main")
    for nombre, lista in (("train", train), ("val", val), ("trainval", ids), ("test", val)):
        with open(os.path.join(main_dir, nombre + ".txt"), "w") as f:
            f.write("\n".join(sorted(lista)) + "\n")
    with open(os.path.join(destino, "labels.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(sorted(clases)) + "\n")
    print("Listo: %d imagenes (%d entrenamiento, %d validacion)" % (len(ids), len(train), len(val)))
    print("Clases:", ", ".join(sorted(clases)))


if __name__ == "__main__":
    main()
