#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
panel.py - Panel de pruebas estilo nodos (tipo TouchDesigner) para el Asesor de Procesos
==========================================================================================
Corre en la Jetson y se abre desde el navegador de tu PC o celular:
    http://<IP-de-la-jetson>:8080          (con Tailscale, p.ej. http://100.120.239.19:8080)

  python3 panel.py                 -> con camara y proyector reales
  python3 panel.py --simular       -> sin hardware: mesa, camara y proyector simulados
  python3 panel.py --puerto 9000   -> otro puerto

Arranca como consola: pantalla de inicio retro -> menu proyectado en la mesa -> modos.
Modos de trabajo: asesor, calibracion, patrones, zonas, guante, clasificador, captura
Modos interactivos: gestos, esqueleto, dedos, particulas, pizarra, reactivo, objetos
Solo usa la libreria estandar de Python (3.6+), OpenCV y numpy.
"""
from __future__ import print_function

import argparse
import collections
import glob
import json
import math
import os
import queue
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

import numpy as np

import asesor as A
import manos as M
import vision as V

cv2 = A.cv2

# ------------------------------------------------------------------ Log compartido con la pagina
LOG = collections.deque(maxlen=300)
_log_original = A.log


def log(*a):
    LOG.append([time.strftime("%H:%M:%S"), " ".join(str(x) for x in a)])
    _log_original(*a)


A.log = log

MODOS = [
    {"id": "menu", "nombre": "Men\u00fa", "desc": "Men\u00fa proyectado para elegir modo con la mano", "grupo": "sistema"},
    {"id": "asesor", "nombre": "Asesor", "desc": "La receta completa: pasos, voz y validaciones", "grupo": "trabajo"},
    {"id": "calibracion", "nombre": "Calibraci\u00f3n", "desc": "Calibra c\u00e1mara y proyector", "grupo": "trabajo"},
    {"id": "patrones", "nombre": "Patrones", "desc": "Rejilla en mm, puntero y rect\u00e1ngulos", "grupo": "trabajo"},
    {"id": "zonas", "nombre": "Zonas", "desc": "Ocupaci\u00f3n de zonas y botones", "grupo": "trabajo"},
    {"id": "guante", "nombre": "Guante", "desc": "Color del guante en vivo", "grupo": "trabajo"},
    {"id": "clasificador", "nombre": "Clasificador", "desc": "Modelo de la charola por lugar", "grupo": "trabajo"},
    {"id": "captura", "nombre": "Captura", "desc": "Fotos para entrenar modelos", "grupo": "trabajo"},
    {"id": "gestos", "nombre": "Gestos", "desc": "Palma, pellizco, pulgar y pu\u00f1o", "grupo": "interactivo"},
    {"id": "esqueleto", "nombre": "Esqueleto", "desc": "Manos de ne\u00f3n con estelas", "grupo": "interactivo"},
    {"id": "dedos", "nombre": "Dedos", "desc": "Efecto entre pulgar e \u00edndice", "grupo": "interactivo"},
    {"id": "particulas", "nombre": "Part\u00edculas", "desc": "Miles de part\u00edculas que siguen tus manos", "grupo": "interactivo"},
    {"id": "pizarra", "nombre": "Pizarra", "desc": "Dibuja en la mesa con pellizco", "grupo": "interactivo"},
    {"id": "reactivo", "nombre": "Reactivo", "desc": "Luz que sigue el movimiento", "grupo": "interactivo"},
    {"id": "objetos", "nombre": "Objetos", "desc": "Detecta y cuenta objetos o instrumental", "grupo": "interactivo"},
]
IDS_MODOS = [m["id"] for m in MODOS]
MENU_ITEMS = [m["id"] for m in MODOS if m["id"] != "menu"]
MODOS_TRABAJO = [m["id"] for m in MODOS if m["grupo"] == "trabajo"]
MODOS_MANOS = ("menu", "gestos", "esqueleto", "dedos", "particulas", "pizarra")
MAGENTA = (255, 60, 230)
COLORES_PIZARRA = {"cian": (255, 220, 0), "magenta": (255, 60, 230), "amarillo": (0, 230, 255),
                   "verde": (60, 255, 60), "blanco": (255, 255, 255)}
PALETA_CLASES = [(0, 220, 255), (255, 200, 0), (60, 255, 60), (255, 60, 230), (80, 140, 255), (255, 255, 255)]

# ruta en config, etiqueta, tipo, min, max, paso, nodo
PARAMS = [
    ["deteccion.umbral_diferencia", "Umbral de diferencia", "int", 5, 120, 1, "zonas"],
    ["deteccion.absorber_quieto_s", "Absorber quieto (s)", "float", 0.5, 10, 0.5, "zonas"],
    ["botones.tiempo_activacion_s", "Tiempo de boton (s)", "float", 0.3, 4, 0.1, "zonas"],
    ["botones.umbral_ocupacion", "Ocupacion para boton", "float", 0.05, 0.9, 0.05, "zonas"],
    ["guante.habilitado", "Usar guante", "bool", 0, 1, 1, "mascara"],
    ["guante.usar_en_botones", "Guante activa botones", "bool", 0, 1, 1, "mascara"],
    ["guante.hsv_min.0", "Tono minimo (H)", "int", 0, 179, 1, "mascara"],
    ["guante.hsv_max.0", "Tono maximo (H)", "int", 0, 179, 1, "mascara"],
    ["guante.hsv_min.1", "Saturacion minima (S)", "int", 0, 255, 1, "mascara"],
    ["guante.hsv_min.2", "Brillo minimo (V)", "int", 0, 255, 1, "mascara"],
    ["clasificador.umbral", "Confianza minima", "float", 0.3, 0.99, 0.01, "clasif"],
    ["voz.habilitada", "Voz activa", "bool", 0, 1, 1, "voz"],
    ["voz.velocidad", "Velocidad de voz", "int", 80, 260, 5, "voz"],
    ["reactivo.fuente", "Fuente", "choice", ["movimiento", "guante"], None, None, "proyector"],
    ["reactivo.paleta", "Paleta", "choice", ["turbo", "jet", "hot", "ocean", "pink"], None, None, "proyector"],
    ["reactivo.decaimiento", "Duracion de estela", "float", 0.5, 0.98, 0.01, "proyector"],
    ["reactivo.sensibilidad", "Umbral de movimiento", "int", 5, 120, 1, "proyector"],
    ["dedos.efecto", "Efecto entre dedos", "choice", ["termico", "pixel", "invertir", "bordes", "neon"], None, None,
     "manos"],
    ["dedos.esqueleto", "Proyectar esqueleto", "bool", 0, 1, 1, "manos"],
    ["manos.motor", "Detector de manos", "choice", ["auto", "posenet", "mediapipe"], None, None, "manos"],
    ["inicio.modo", "Modo al encender", "choice", IDS_MODOS, None, None, "sistema"],
    ["inicio.splash", "Pantalla de arranque retro", "bool", 0, 1, 1, "sistema"],
    ["gestos.en_asesor", "Gestos en el asesor", "bool", 0, 1, 1, "sistema"],
    ["objetos.modelo", "Modelo", "choice", ["general", "instrumental"], None, None, "objetos"],
    ["objetos.umbral", "Confianza minima", "float", 0.2, 0.95, 0.05, "objetos"],
    ["particulas.comportamiento", "Comportamiento", "choice", ["seguir", "esquivar", "orbitar"], None, None,
     "particulas"],
    ["particulas.cantidad", "Cantidad", "int", 500, 8000, 250, "particulas"],
    ["particulas.paleta", "Paleta", "choice", ["turbo", "jet", "hot", "ocean", "pink"], None, None, "particulas"],
    ["pizarra.color", "Color", "choice", ["cian", "magenta", "amarillo", "verde", "blanco"], None, None, "pizarra"],
    ["pizarra.grosor", "Grosor (mm)", "int", 2, 25, 1, "pizarra"],
    ["osc.habilitado", "Enviar OSC", "bool", 0, 1, 1, "osc"],
    ["osc.host", "IP de la PC con TouchDesigner", "text", None, None, None, "osc"],
    ["osc.puerto", "Puerto", "int", 1000, 65000, 1, "osc"],
]


def cfg_get(cfg, ruta):
    x = cfg
    for p in ruta.split("."):
        x = x[int(p)] if isinstance(x, list) else x.get(p)
        if x is None:
            return None
    return x


def cfg_set(cfg, ruta, valor):
    partes = ruta.split(".")
    x = cfg
    for p in partes[:-1]:
        x = x[int(p)] if isinstance(x, list) else x.setdefault(p, {})
    ult = partes[-1]
    if isinstance(x, list):
        x[int(ult)] = valor
    else:
        x[ult] = valor


def asegurar_defaults(cfg):
    cfg.setdefault("deteccion", {"umbral_diferencia": 35, "absorber_quieto_s": 3.0})
    cfg.setdefault("botones", {"tiempo_activacion_s": 1.5, "umbral_ocupacion": 0.25})
    cfg.setdefault("guante", {"habilitado": False, "hsv_min": [100, 80, 40], "hsv_max": [130, 255, 255],
                              "usar_en_botones": True, "usar_en_pick": True})
    cfg.setdefault("clasificador", {"carpeta": "modelo", "umbral": 0.8, "clase_vacio": "Vacio",
                                    "margen_recorte_mm": 6})
    cfg.setdefault("voz", {"habilitada": True, "velocidad": 150})
    r = cfg.setdefault("reactivo", {})
    r.setdefault("fuente", "movimiento")
    r.setdefault("paleta", "turbo")
    r.setdefault("decaimiento", 0.9)
    r.setdefault("sensibilidad", 40)
    d = cfg.setdefault("dedos", {})
    d.setdefault("efecto", "termico")
    d.setdefault("esqueleto", True)
    for sec, vals in (("manos", {"motor": "auto"}), ("inicio", {"modo": "menu", "splash": True}),
                      ("gestos", {"en_asesor": True}),
                      ("objetos", {"modelo": "general", "umbral": 0.5, "carpeta": "modelo_detector"}),
                      ("particulas", {"comportamiento": "seguir", "cantidad": 3000, "paleta": "turbo"}),
                      ("pizarra", {"color": "cian", "grosor": 6}),
                      ("osc", {"habilitado": False, "host": "127.0.0.1", "puerto": 7000})):
        s = cfg.setdefault(sec, {})
        for k, v in vals.items():
            s.setdefault(k, v)


# ------------------------------------------------------------------ Simulador (sin hardware)
class Simulador(object):
    """Mesa virtual: marcadores impresos, piezas, una mano con guante azul que se mueve con el mouse
    del panel, y la luz del proyector cayendo sobre la mesa. Asi la calibracion y la deteccion
    funcionan de verdad sin camara ni proyector."""

    def __init__(self, cfg):
        self.W, self.H = float(cfg["mesa"]["ancho_mm"]), float(cfg["mesa"]["alto_mm"])
        self.m = 70
        self.cw, self.ch = int(cfg["camara"]["ancho"]), int(cfg["camara"]["alto"])
        pw, ph = int(cfg["proyector"]["ancho"]), int(cfg["proyector"]["alto"])
        cw, ch = self.cw, self.ch
        Wt, Ht = int(self.W + 2 * self.m), int(self.H + 2 * self.m)
        self.H_mesa2cam = cv2.getPerspectiveTransform(
            np.float32([[0, 0], [Wt, 0], [Wt, Ht], [0, Ht]]),
            np.float32([[0.07 * cw, 0.08 * ch], [0.93 * cw, 0.05 * ch], [0.96 * cw, 0.95 * ch], [0.04 * cw, 0.93 * ch]]))
        self.H_proy2cam = cv2.getPerspectiveTransform(
            np.float32([[0, 0], [pw, 0], [pw, ph], [0, ph]]),
            np.float32([[0.02 * cw, 0.01 * ch], [0.99 * cw, 0.0], [1.0 * cw, 1.0 * ch], [0.0, 0.99 * ch]]))
        base = np.full((Ht, Wt, 3), 212, np.uint8)
        lado = 70
        ids = cfg["calibracion"]["marcadores_mesa"]
        for i, (x, y) in zip(ids, [(0, 0), (self.W, 0), (self.W, self.H), (0, self.H)]):
            cx, cy = int(x + self.m), int(y + self.m)
            base[cy - lado // 2:cy + lado // 2, cx - lado // 2:cx + lado // 2] = \
                cv2.cvtColor(A.imagen_marcador(i, lado), cv2.COLOR_GRAY2BGR)
        self.base = base
        self.mano = None
        self.mano_auto = False
        self.luz = None
        self.lock = threading.Lock()

    def set_luz(self, img):
        with self.lock:
            self.luz = img

    def cuadro(self):
        mesa = self.base.copy()
        m = self.m
        mano = self.mano
        if self.mano_auto:
            t = time.time()
            mano = (self.W * (0.5 + 0.38 * math.sin(t * 0.7)), self.H * (0.5 + 0.35 * math.sin(t * 1.1 + 1)))
        if mano is not None:
            x, y = int(mano[0] + m), int(mano[1] + m)
            cv2.line(mesa, (x + 8, y + 12), (x + 20, int(self.H + 2 * m)), (120, 120, 120), 70)  # sombra
            cv2.line(mesa, (x, y), (x + 10, int(self.H + 2 * m)), (190, 95, 35), 60)  # antebrazo
            cv2.ellipse(mesa, (x, y), (42, 52), 0, 0, 360, (200, 100, 40), -1)  # palma
            for k in range(4):
                cv2.line(mesa, (x - 30 + k * 20, y - 30), (x - 34 + k * 22, y - 78), (200, 100, 40), 14)
        cam = cv2.warpPerspective(mesa, self.H_mesa2cam, (self.cw, self.ch), borderValue=(60, 60, 60))
        with self.lock:
            luz = self.luz
        f = cam.astype(np.float32)
        if luz is not None:
            l = cv2.warpPerspective(luz, self.H_proy2cam, (self.cw, self.ch)).astype(np.float32)
            f = f * (0.42 + 0.58 * l / 255.0)
        else:
            f = f * 0.42
        f += np.random.normal(0, 2.0, f.shape).astype(np.float32)
        return np.clip(f, 0, 255).astype(np.uint8)


class CamaraSim(object):
    def __init__(self, sim):
        self.sim, self.frame, self.t = sim, None, 0.0
        self.lock = threading.Lock()
        self.vivo = True
        th = threading.Thread(target=self._loop)
        th.daemon = True
        th.start()
        while self.frame is None:
            time.sleep(0.02)

    def _loop(self):
        while self.vivo:
            f = self.sim.cuadro()
            with self.lock:
                self.frame, self.t = f, time.time()
            time.sleep(0.05)

    def leer(self):
        with self.lock:
            return self.frame, self.t

    def leer_nuevo(self, despues_de, tope=2.0):
        t0 = time.time()
        while time.time() - t0 < tope:
            f, t = self.leer()
            if t > despues_de:
                return f
            time.sleep(0.005)
        return self.leer()[0]

    def cerrar(self):
        self.vivo = False


class ProyectorSim(object):
    def __init__(self, cfg, sim):
        self.w, self.h = int(cfg["proyector"]["ancho"]), int(cfg["proyector"]["alto"])
        self.sim = sim

    def negro(self):
        return np.zeros((self.h, self.w, 3), np.uint8)

    def mostrar(self, img, espera_ms=1):
        self.sim.set_luz(img)
        time.sleep(max(1, espera_ms) / 1000.0)
        return 255

    def pausa(self, img, seg):
        t0 = time.time()
        while time.time() - t0 < seg:
            self.mostrar(img, 15)


class ProyectorEspia(object):
    """Envuelve al proyector real o simulado para guardar lo ultimo proyectado (vista previa del panel)."""

    def __init__(self, proy):
        self.p = proy
        self.w, self.h = proy.w, proy.h
        self.ultima = None

    def negro(self):
        return self.p.negro()

    def mostrar(self, img, espera_ms=1):
        self.ultima = img
        return self.p.mostrar(img, espera_ms)

    def pausa(self, img, seg):
        t0 = time.time()
        while time.time() - t0 < seg:
            self.mostrar(img, 15)


# ------------------------------------------------------------------ Motor del panel
PALETAS = {"turbo": "COLORMAP_TURBO", "jet": "COLORMAP_JET", "hot": "COLORMAP_HOT",
           "ocean": "COLORMAP_OCEAN", "pink": "COLORMAP_PINK"}


def a_color(mapa, nombre):
    cm = getattr(cv2, PALETAS.get(nombre, "COLORMAP_JET"), cv2.COLORMAP_JET)
    return cv2.applyColorMap(mapa, cm)


def gris(img):
    return cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (5, 5), 0)


def frac_dif(a, b, umbral=30):
    return np.count_nonzero(cv2.absdiff(a, b) > umbral) / float(a.size)


def reducir(img, ancho=480):
    if img is None:
        return None
    h, w = img.shape[:2]
    if w <= ancho:
        return img
    return cv2.resize(img, (ancho, int(h * ancho / float(w))), interpolation=cv2.INTER_AREA)


class Motor(object):
    def __init__(self, args):
        self.args = args
        args.debug, args.calibrar = False, False
        self.cfg = A.cargar_json(A.ruta(args.config))
        asegurar_defaults(self.cfg)
        self.archivo_calib_real = self.cfg["calibracion"]["archivo"]
        if args.receta:
            self.cfg["receta"] = args.receta
        self.dir_reg = A.ruta(self.cfg.get("registro_dir", "registros"))
        os.makedirs(self.dir_reg, exist_ok=True)
        self.sim = None
        if args.simular:
            self.sim = Simulador(self.cfg)
            self.cfg["calibracion"]["archivo"] = "calibracion_sim.json"
            self.cfg["camara"]["tipo"] = "simulada"
        else:
            A.preparar_pantalla(args.pantalla)
        self.eventos = queue.Queue()
        self.voz = A.Voz(self.cfg)
        self.ultima_voz = ""
        decir_orig = self.voz.decir

        def decir(texto):
            if texto:
                self.ultima_voz = texto
            decir_orig(texto)
        self.voz.decir = decir
        self.cam = CamaraSim(self.sim) if self.sim else A.Camara(self.cfg)
        self.proy = ProyectorEspia(ProyectorSim(self.cfg, self.sim) if self.sim else A.Proyector(self.cfg))
        self.voz_q = queue.Queue()  # la voz pasa por el panel: 'menu' y nombres de modo cambian de modo
        A.Oido(self.cfg, self.voz, self.voz_q)
        A.EntradaTorque(self.cfg, self.eventos)
        self.clasif = A.Clasificador(self.cfg)
        archivo = A.ruta(self.cfg["calibracion"]["archivo"])
        self.calib = A.cargar_json(archivo) if os.path.exists(archivo) else None
        self.cmds = queue.Queue()
        self.lock = threading.Lock()
        self.previas = {}
        self.asesor = None
        self.geo = None
        self.guante = A.Guante(self.cfg)
        self.modo = "arranque"
        self.t_arranque, self._sono = time.time(), False
        self.ip = ip_local()
        self.calibrando = False
        self.verificacion = None
        self.error = ""
        self.fps = 0.0
        self.patron = "rejilla"
        self.puntero = None
        self.rects = []
        self.res_cls = {}
        self.t_cls = 0.0
        self.cobertura = 0.0
        self.trail = None
        self.r_prev = None
        self.ultimo_torque = None
        self.det_manos = None
        self.n_manos = 0
        self._dedos_L = None
        self.manos_mm, self.manos_cam, self.gestos_act, self.puntero_mm = [], [], [], None
        self.gestos = [V.Gestos(), V.Gestos()]
        self.cont_gestos, self.t_flash = {}, 0.0
        self.menu_sel, self._tiles = 0, None
        self.estelas = {}
        self.pt_pos, self.pt_vel, self.pt_t = None, None, 0.0
        self.pizarra, self.piz_prev = None, {}
        self.det_obj, self._clave_obj, self.dets_obj, self.cuenta_obj, self.t_obj = None, None, [], {}, 0.0
        self.emisor = None
        self.cap = {"activo": False, "clase": "", "fase": "", "n": 0, "previas": 0, "max": 150, "cada": 1.5}
        self._reconstruir()
        self.vivo = True

    # ---------- utilidades
    def _reconstruir(self):
        """Rehace geometria y asesor (tras calibrar o cambiar receta)."""
        self.asesor = None
        self.geo = A.Geometria(self.cfg, self.calib) if self.calib else None
        self.trail, self.r_prev = None, None
        self._tiles, self.pizarra = None, None

    def _asesor(self):
        if self.asesor is None and self.calib:
            self.asesor = A.Asesor(self.cfg, self.args, cam=self.cam, proy=self.proy, voz=self.voz,
                                   eventos=self.eventos, calib=self.calib, servicios=False, clasif=self.clasif,
                                   objetos=self.det_obj if (self.det_obj and self.det_obj.ok) else None)
        return self.asesor

    def _previa(self, nombre, img):
        if img is not None:
            with self.lock:
                self.previas[nombre] = img

    def _mensaje(self, texto, color=A.AMARILLO):
        img = self.proy.negro()
        A.poner_parrafo(img, texto, 80, self.proy.h // 2 - 60, self.proy.w - 160, 52, color)
        return img

    def _recetas(self):
        res = []
        for p in sorted(glob.glob(os.path.join(A.BASE, "*.json"))):
            try:
                with open(p, encoding="utf-8") as f:
                    if "pasos" in json.load(f):
                        res.append(os.path.basename(p))
            except Exception:
                pass
        return res

    # ---------- comandos de la pagina (se ejecutan en el hilo principal)
    def _atender(self):
        while True:
            try:
                accion, d = self.cmds.get_nowait()
            except queue.Empty:
                return
            try:
                self._accion(accion, d)
            except Exception as e:
                self.error = "%s: %s" % (accion, e)
                log("Error en accion", accion, e)
                traceback.print_exc()

    def _accion(self, accion, d):
        if accion == "modo":
            m = d.get("modo")
            if m in IDS_MODOS and m != self.modo:
                self.modo = m
                self.error = ""
                self.trail, self.r_prev = None, None
                with self.lock:  # borra vistas previas del modo anterior
                    for k in ("vista", "mascara", "recortes"):
                        self.previas.pop(k, None)
                self.estelas, self.pt_pos, self.piz_prev = {}, None, {}
                self.dets_obj, self.cuenta_obj = [], {}
                if m == "menu" and self._tiles:
                    for tl in self._tiles:
                        tl["zona"].reiniciar()
                        tl["ret"].reiniciar()
                log("Modo:", m)
                if m == "asesor" and self._asesor():
                    while not self.eventos.empty():
                        self.eventos.get_nowait()
                    self.asesor.ir_espera()
                elif self.asesor:
                    self.asesor._reiniciar_detectores()
        elif accion == "param":
            self._param(d["ruta"], d["valor"])
        elif accion == "guardar":
            copia = json.loads(json.dumps(self.cfg))
            copia["calibracion"]["archivo"] = self.archivo_calib_real
            copia["camara"]["tipo"] = copia["camara"].get("tipo") if not self.sim else "usb"
            with open(A.ruta(self.args.config), "w", encoding="utf-8") as f:
                json.dump(copia, f, indent=2, ensure_ascii=False)
            log("Configuracion guardada en", self.args.config)
        elif accion in ("iniciar", "siguiente", "repetir", "ayuda", "cancelar"):
            self.eventos.put(("cmd", accion))
        elif accion == "torque":
            v = float(d["valor"])
            self.ultimo_torque = v
            self.eventos.put(("torque", v))
            log("Torque enviado desde el panel:", v)
        elif accion == "decir":
            self.voz.decir(d.get("texto", ""))
        elif accion == "receta":
            self.cfg["receta"] = d["nombre"]
            self._reconstruir()
            log("Receta:", d["nombre"])
            if self.modo == "asesor":
                self._asesor()
        elif accion == "calibrar":
            self.calibrando = True
            log("Calibrando...")
            c = A.calibrar(self.cfg, self.cam, self.proy, self.voz)
            self.calibrando = False
            if c:
                self.calib = c
                self._reconstruir()
            else:
                self.error = "No se pudo calibrar. Revisa marcadores, luz y enfoque."
        elif accion == "verificar":
            if self.calib:
                r = A.verificar_calibracion(self.cfg, self.cam, self.proy, self.calib)
                self.verificacion = {True: "Calibracion vigente", False: "La camara se movio: recalibra",
                                     None: "No se ven los 4 marcadores"}[r]
                log("Verificacion:", self.verificacion)
        elif accion == "patron":
            self.patron = d["nombre"]
        elif accion == "puntero":
            self.puntero = None if d.get("x") is None else [float(d["x"]), float(d["y"])]
        elif accion == "rects":
            self.rects = [[round(float(v)) for v in r] for r in d.get("rects", [])][-12:]
        elif accion == "mano":
            if self.sim:
                self.sim.mano = None if d.get("x") is None else (float(d["x"]), float(d["y"]))
                if "auto" in d:
                    self.sim.mano_auto = bool(d["auto"])
        elif accion == "captura_iniciar":
            self._captura_iniciar(d)
        elif accion == "pizarra_borrar":
            if self.pizarra is not None:
                self.pizarra[:] = 0
        elif accion == "captura_parar":
            if self.cap["activo"]:
                self.cap["activo"] = False
                log("Captura detenida: %d fotos" % self.cap["n"])
                self.voz.decir("Listo, %d fotos" % self.cap["n"])

    def _param(self, ruta, valor):
        defs = {p[0]: p for p in PARAMS}
        if ruta not in defs:
            return
        tipo = defs[ruta][2]
        if tipo == "int":
            valor = int(round(float(valor)))
        elif tipo == "float":
            valor = float(valor)
        elif tipo == "bool":
            valor = bool(valor)
        elif tipo == "text":
            valor = str(valor).strip()
        cfg_set(self.cfg, ruta, valor)
        grupo = ruta.split(".")[0]
        if grupo in ("deteccion", "botones") and self.asesor:
            self.asesor._preparar()
        elif grupo == "guante":
            self.guante = A.Guante(self.cfg)
            if self.asesor:
                self.asesor.guante = self.guante
        elif ruta == "clasificador.umbral":
            self.clasif.umbral = valor
        elif ruta == "voz.habilitada":
            self.voz.hab = valor
        elif ruta == "manos.motor":
            self.det_manos = None
        elif ruta == "particulas.cantidad":
            self.pt_pos = None
        elif grupo == "botones":
            self._tiles = None

    # ---------- modos (cada uno regresa la imagen para el proyector)
    def _sin_calib(self):
        return self._mensaje("Sin calibracion. Ve al modo Calibracion y presiona Calibrar.")

    def _m_asesor(self, frame, nuevo, ahora):
        a = self._asesor()
        if a is None:
            return self._sin_calib()
        if nuevo:
            if self.gestos_act and self.cfg["gestos"].get("en_asesor", True):
                self._gestos_asesor(a)
            v, m = a.procesar(frame, ahora)
            self._previa("vista", a.imagen_debug(v, m))
            if m is not None:
                self._previa("mascara", cv2.cvtColor(m, cv2.COLOR_GRAY2BGR))
        return a.imagen_proyector(ahora)

    def _gestos_asesor(self, a):
        for i, (est, dur, nuevo) in enumerate(self.gestos_act):
            G = self.gestos[i]
            if est == "palma" and dur >= 1.0 and a.estado == "ESPERA" and G.una_vez("iniciar"):
                log("Gesto: palma abierta -> iniciar")
                self.eventos.put(("cmd", "iniciar"))
            elif est == "pulgar" and nuevo and a.estado == "PASO" and a.p.get("tipo") == "confirmar":
                log("Gesto: pulgar arriba -> siguiente")
                self.eventos.put(("cmd", "siguiente"))
        for px, py in self._pellizcos_mm():
            for n in a._botones_activos():
                b = a.botones.get(n)
                if b:
                    x, y, w, h = b["rect"]
                    if x <= px <= x + w and y <= py <= y + h:
                        log("Gesto: pellizco en", n)
                        self.eventos.put(("cmd", n))

    def _m_zonas(self, frame, nuevo, ahora):
        a = self._asesor()
        if a is None:
            return self._sin_calib()
        g = a.geo
        if nuevo:
            vc = g.vista_mesa(frame)
            v = gris(vc)
            m = a.guante.mascara(vc)
            for b in a.botones.values():
                oc = b["zona"].actualizar(v, ahora, m if a.guante.en_botones else None)
                b["ret"].actualizar(oc, ahora)
            for z in a.zonas.values():
                z.actualizar(v, ahora)
            for d in a.lugares.values():
                d["zona"].actualizar(v, ahora)
            self._previa("vista", a.imagen_debug(v, m))
        L = g.lienzo()
        umbral = float(self.cfg["botones"]["umbral_ocupacion"])
        for n in a.botones:
            a._boton(L, n, n.upper(), A.VERDE, ahora)
        items = [(n, a.receta["zonas"][n], z) for n, z in a.zonas.items()] + \
                [(n, d["rect"], d["zona"]) for n, d in a.lugares.items()] + \
                [(n, b["rect"], b["zona"]) for n, b in a.botones.items()]
        for n, r, z in items:
            (x0, y0), (x1, y1) = g.rect(r)
            col = A.ROJO if z.ocupacion >= umbral else A.CIAN
            if n not in a.botones:
                cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
            A.poner_texto(L, "%s %d%%" % (n, round(z.ocupacion * 100)), x0, max(0, y0 - g.px(22)), g.px(18), col)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def _m_guante(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        L = g.lienzo()
        if nuevo:
            vc = g.vista_mesa(frame)
            gu = A.Guante(self.cfg)
            gu.hab = True
            m = gu.mascara(vc)
            self.cobertura = np.count_nonzero(m) / float(m.size)
            prev = vc.copy()
            prev[m > 0] = (255, 0, 255)
            self._previa("mascara", prev)
            self._previa("vista", vc)
            grande = cv2.resize(m, g.tam_lienzo, interpolation=cv2.INTER_NEAREST)
            res = cv2.findContours(grande, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            self._contornos = res[-2]
        cv2.drawContours(L, getattr(self, "_contornos", []), -1, A.CIAN, max(2, g.px(4)))
        A.poner_texto(L, "Guante: %.1f%% de la mesa" % (self.cobertura * 100), g.px(20), g.px(15), g.px(26), A.BLANCO)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def _recortes(self, a, frame):
        return {n: A.cuadrar(a.geo.recorte(frame, d["rect"], self.clasif.margen if self.clasif.ok else 6))
                for n, d in a.lugares.items()}

    def _mosaico(self, rec, etiquetas):
        if not rec:
            return None
        tiles = []
        for n in sorted(rec):
            t = cv2.resize(rec[n], (120, 120))
            cv2.rectangle(t, (0, 96), (120, 120), (20, 20, 20), -1)
            cv2.putText(t, A.sin_acentos(etiquetas.get(n, n))[:16], (4, 113), cv2.FONT_HERSHEY_SIMPLEX, 0.38,
                        (255, 255, 255), 1, cv2.LINE_AA)
            tiles.append(t)
        return np.hstack(tiles)

    def _m_clasificador(self, frame, nuevo, ahora):
        a = self._asesor()
        if a is None:
            return self._sin_calib()
        if not a.lugares:
            return self._mensaje("La receta no tiene 'lugares'. Elige receta_charola.json")
        if not self.clasif.ok:
            return self._mensaje("No hay modelo en la carpeta modelo/. Sigue GUIA_ENTRENAMIENTO.md")
        if nuevo and ahora - self.t_cls > 0.5:
            self.t_cls = ahora
            rec = self._recortes(a, frame)
            self.res_cls = {n: self.clasif.clasificar(img) for n, img in rec.items()}
            self._previa("recortes", self._mosaico(rec, {n: "%s %d%%" % (e, c * 100)
                                                         for n, (e, c) in self.res_cls.items()}))
        g = a.geo
        L = g.lienzo()
        for n, d in a.lugares.items():
            e = self.res_cls.get(n)
            col, txt = A.GRIS, d["instrumento"]
            if e:
                txt = "%s %d%%" % (e[0], round(e[1] * 100))
                if e[1] < self.clasif.umbral:
                    col = A.AMARILLO
                elif A._norm(e[0]) == A._norm(d["instrumento"]):
                    col = A.VERDE
                elif A._norm(e[0]) == A._norm(self.clasif.vacio):
                    col = A.GRIS
                else:
                    col = A.ROJO
            (x0, y0), (x1, y1) = g.rect(d["rect"])
            cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
            A.poner_parrafo(L, txt, x0, y1 + g.px(4), x1 - x0, g.px(16), col)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def _captura_iniciar(self, d):
        if d.get("tipo") == "mesa":
            clase = (d.get("clase") or "mesa").strip()
            carpeta = A.ruta(os.path.join("dataset_detector", "JPEGImages"))
            os.makedirs(carpeta, exist_ok=True)
            self.cap = {"activo": True, "tipo": "mesa", "clase": clase, "carpeta": carpeta, "fase": "capturando",
                        "t0": time.time(), "n": 0, "max": int(d.get("max", 150)), "cada": float(d.get("cada", 2.0)),
                        "previas": len(os.listdir(carpeta)), "prev": None, "t_quieto": None, "t_ult": 0.0,
                        "ocupados": []}
            self.voz.decir("Capturando la mesa completa. Cambie los objetos de lugar entre fotos")
            log("Captura de mesa completa para el detector:", clase)
            return
        a = self._asesor()
        if a is None or not a.lugares:
            self.error = "La receta activa no tiene 'lugares' para capturar."
            return
        clase = (d.get("clase") or "").strip()
        if not clase:
            self.error = "Escribe el nombre de la clase."
            return
        carpeta = A.ruta(os.path.join("dataset", clase))
        os.makedirs(carpeta, exist_ok=True)
        vacio = A._norm(clase) == A._norm(self.cfg["clasificador"].get("clase_vacio", "Vacio"))
        self.cap = {"activo": True, "clase": clase, "carpeta": carpeta, "vacio": vacio,
                    "fase": "capturando" if vacio else "referencia", "t0": time.time(), "n": 0,
                    "previas": len([f for f in os.listdir(carpeta) if f.lower().endswith(".jpg")]),
                    "max": int(d.get("max", 150)), "cada": float(d.get("cada", 1.5)),
                    "ref": None, "prev": None, "t_quieto": None, "t_ult": 0.0, "ult": {}, "ocupados": []}
        self.voz.decir("Capturando lugares vacíos" if vacio else "Deje los lugares vacíos")
        log("Captura:", clase)

    def _m_captura(self, frame, nuevo, ahora):
        a = self._asesor()
        if a is None:
            return self._sin_calib()
        c = self.cap
        if c.get("tipo") == "mesa":
            g = a.geo
            if c["activo"] and nuevo:
                v = gris(g.vista_mesa(frame))
                mov = c["prev"] is not None and frac_dif(v, c["prev"]) > 0.01
                c["prev"] = v
                if mov:
                    c["t_quieto"] = None
                elif c["t_quieto"] is None:
                    c["t_quieto"] = ahora
                if c["t_quieto"] is not None and ahora - c["t_quieto"] >= 0.6 and ahora - c["t_ult"] >= c["cada"]:
                    nombre = A.sin_acentos(c["clase"]).replace(" ", "_")
                    cv2.imwrite(os.path.join(c["carpeta"], "%s_%d.jpg" % (nombre, int(ahora * 1000))), frame)
                    c["n"] += 1
                    c["t_ult"] = ahora
                    self.voz.tono("clic")
                    if c["n"] >= c["max"]:
                        self._accion("captura_parar", {})
            L = g.lienzo()
            cv2.rectangle(L, (0, 0), (g.tam_lienzo[0] - 1, g.tam_lienzo[1] - 1), A.GRIS, max(2, g.px(3)))
            txt = ("Mesa completa: %d fotos" % c["n"]) if c["activo"] else "Captura detenida"
            A.poner_texto(L, txt, g.px(30), g.px(15), g.px(28), A.BLANCO)
            A.poner_texto(L, "Mueva los objetos y quite las manos entre fotos", g.px(30), g.px(50), g.px(18), A.GRIS)
            return g.a_proyector(L, self.proy.w, self.proy.h)
        g = a.geo
        if c["activo"] and nuevo:
            rec = self._recortes(a, frame)
            gr = {k: gris(v) for k, v in rec.items()}
            if c["fase"] == "referencia":
                if ahora - c["t0"] >= 4:
                    c["ref"], c["fase"] = gr, "capturando"
                    self.voz.decir("Coloque %s y muévalo entre fotos" % c["clase"])
            else:
                mov = c["prev"] is not None and any(frac_dif(gr[k], c["prev"][k]) > 0.01 for k in gr)
                if mov:
                    c["t_quieto"] = None
                elif c["t_quieto"] is None:
                    c["t_quieto"] = ahora
                quieto = c["t_quieto"] is not None and ahora - c["t_quieto"] >= 0.5
                c["ocupados"] = [k for k in rec if c["vacio"] or frac_dif(gr[k], c["ref"][k]) > 0.04]
                if quieto and c["ocupados"] and ahora - c["t_ult"] >= c["cada"]:
                    nombre = A.sin_acentos(c["clase"]).replace(" ", "_")
                    nuevos = 0
                    for k in c["ocupados"]:
                        if not c["vacio"] and k in c["ult"] and frac_dif(gr[k], c["ult"][k]) < 0.02:
                            continue
                        cv2.imwrite(os.path.join(c["carpeta"], "%s_%d_%s.jpg" % (nombre, int(ahora * 1000), k)), rec[k])
                        c["ult"][k] = gr[k]
                        nuevos += 1
                    if nuevos:
                        c["n"] += nuevos
                        c["t_ult"] = ahora
                        self.voz.tono("clic")
                    if c["n"] >= c["max"]:
                        self._accion("captura_parar", {})
            c["prev"] = gr
            self._previa("recortes", self._mosaico(rec, {k: ("OCUPADO" if k in c.get("ocupados", []) else k)
                                                         for k in rec}))
        L = g.lienzo()
        for n, d in a.lugares.items():
            col = A.VERDE if n in c.get("ocupados", []) else A.GRIS
            (x0, y0), (x1, y1) = g.rect(d["rect"])
            cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
            A.poner_texto(L, n, x0, y0 - g.px(20), g.px(16), A.GRIS)
        if c["activo"]:
            if c["fase"] == "referencia":
                txt = "Deje los lugares VACIOS... %d" % max(0, 4 - int(ahora - c["t0"]))
            else:
                txt = "%s: %d fotos" % (c["clase"], c["n"])
            A.poner_texto(L, txt, g.px(30), g.px(15), g.px(30), A.AMARILLO if c["fase"] == "referencia" else A.BLANCO)
        else:
            A.poner_texto(L, "Captura detenida", g.px(30), g.px(15), g.px(26), A.GRIS)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def _overlay_mm(self, L):
        g = self.geo
        for r in self.rects:
            (x0, y0), (x1, y1) = g.rect(r)
            cv2.rectangle(L, (x0, y0), (x1, y1), A.CIAN, max(2, g.px(3)))
            A.poner_texto(L, "[%d, %d, %d, %d]" % tuple(r), x0, y1 + g.px(4), g.px(16), A.CIAN)
        if self.puntero:
            x, y = g.px(self.puntero[0]), g.px(self.puntero[1])
            cv2.circle(L, (x, y), g.px(18), A.AMARILLO, max(2, g.px(3)))
            cv2.line(L, (x - g.px(40), y), (x + g.px(40), y), A.AMARILLO, max(1, g.px(2)))
            cv2.line(L, (x, y - g.px(40)), (x, y + g.px(40)), A.AMARILLO, max(1, g.px(2)))
            A.poner_texto(L, "(%d, %d) mm" % tuple(self.puntero), x + g.px(24), y + g.px(8), g.px(20), A.AMARILLO)

    def _m_patrones(self, frame, nuevo, ahora):
        w, h = self.proy.w, self.proy.h
        p = self.patron
        if p in ("blanco", "negro", "colores", "marcadores"):
            if p == "blanco":
                img = np.full((h, w, 3), 255, np.uint8)
            elif p == "negro":
                img = self.proy.negro()
            elif p == "colores":
                img = self.proy.negro()
                cols = [(255, 255, 255), (0, 255, 255), (255, 255, 0), (0, 255, 0), (255, 0, 255), (0, 0, 255), (255, 0, 0)]
                bw = w // len(cols)
                for i, c in enumerate(cols):
                    img[:, i * bw:(i + 1) * bw] = c
            else:
                img = A.patron_aruco(w, h)[0]
            if self.geo is not None and (self.puntero or self.rects):
                L = self.geo.lienzo()
                self._overlay_mm(L)
                img = np.maximum(img, self.geo.a_proyector(L, w, h)) if p == "negro" else img
            return img
        g = self.geo
        if g is None:
            return self._sin_calib()
        L = g.lienzo()
        if p == "rejilla":
            for mm in range(0, int(g.W) + 1, 50):
                fuerte = mm % 100 == 0
                cv2.line(L, (g.px(mm), 0), (g.px(mm), g.px(g.H)), A.BLANCO if fuerte else A.GRIS, 2 if fuerte else 1)
                if fuerte:
                    A.poner_texto(L, str(mm), g.px(mm) + 4, 4, g.px(16), A.AMARILLO)
            for mm in range(0, int(g.H) + 1, 50):
                fuerte = mm % 100 == 0
                cv2.line(L, (0, g.px(mm)), (g.px(g.W), g.px(mm)), A.BLANCO if fuerte else A.GRIS, 2 if fuerte else 1)
                if fuerte and mm:
                    A.poner_texto(L, str(mm), 4, g.px(mm) + 4, g.px(16), A.AMARILLO)
        else:  # receta: dibuja todo lo definido
            a = self._asesor()
            if a:
                todo = [(n, r, A.CIAN) for n, r in a.receta.get("zonas", {}).items()] + \
                       [(n, b["rect"], A.VERDE) for n, b in a.botones.items()] + \
                       [(n, d["rect"], A.AMARILLO) for n, d in a.lugares.items()]
                for n, r, col in todo:
                    (x0, y0), (x1, y1) = g.rect(r)
                    cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
                    A.poner_texto(L, n, x0 + g.px(4), y0 + g.px(4), g.px(16), col)
                ax, ay, aw, ah = a.area_texto
                (x0, y0), (x1, y1) = g.rect([ax, ay, aw, ah])
                cv2.rectangle(L, (x0, y0), (x1, y1), A.GRIS, 1)
                A.poner_texto(L, "area de texto", x0 + g.px(4), y0 + g.px(4), g.px(16), A.GRIS)
        self._overlay_mm(L)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def _m_reactivo(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        r = self.cfg["reactivo"]
        if nuevo:
            vc = g.vista_mesa(frame)
            v = gris(vc)
            if r["fuente"] == "guante":
                gu = A.Guante(self.cfg)
                gu.hab = True
                mov = gu.mascara(vc)
            else:
                mov = np.zeros_like(v) if self.r_prev is None else \
                    ((cv2.absdiff(v, self.r_prev) > int(r["sensibilidad"])) * 255).astype(np.uint8)
                mov = cv2.dilate(mov, np.ones((5, 5), np.uint8))
            self.r_prev = v
            if self.trail is None:
                self.trail = np.zeros(v.shape, np.float32)
            self.trail = np.maximum(self.trail * float(r["decaimiento"]), mov.astype(np.float32))
            color = a_color(self.trail.astype(np.uint8), r["paleta"])
            color[self.trail < 12] = 0
            self._color_reactivo = color
            self._previa("mascara", color)
            self._previa("vista", vc)
        L = g.lienzo()
        c = getattr(self, "_color_reactivo", None)
        if c is not None:
            L = cv2.resize(c, g.tam_lienzo, interpolation=cv2.INTER_LINEAR)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ manos, gestos y puntero
    def _usa_manos(self):
        if self.modo in MODOS_MANOS:
            return True
        if self.modo == "asesor" and self.cfg["gestos"].get("en_asesor", True):
            return self._detector_manos().ok
        return bool(self.cfg["osc"].get("habilitado")) and self._detector_manos().ok

    def _detector_manos(self):
        if self.det_manos is None:
            self.det_manos = V.Manos(self.cfg["manos"].get("motor", "auto"))
            log("Manos:", self.det_manos.motor if self.det_manos.ok else self.det_manos.error)
        return self.det_manos

    def _actualizar_manos(self, frame, ahora):
        g = self.geo
        det = self._detector_manos()
        self.manos_mm, self.manos_cam, self.gestos_act, self.puntero_mm = [], [], [], None
        if det.ok:
            cam = det.detectar(frame)
            cam = sorted(cam, key=lambda m: float(np.nanmean(m[:, 0])))[:2]
            self.manos_cam = cam
            for i, m in enumerate(cam):
                self.manos_mm.append(cv2.perspectiveTransform(m.reshape(-1, 1, 2), g.H_cam2mm).reshape(-1, 2))
                self.gestos_act.append(self.gestos[i].actualizar(V.clasificar_gesto(m), ahora))
            for i in range(len(cam), 2):
                self.gestos[i].actualizar("", ahora)
            for m in self.manos_mm:
                if not np.isnan(m[V.INDICE][0]):
                    self.puntero_mm = (float(m[V.INDICE][0]), float(m[V.INDICE][1]))
                    break
        elif self.modo != "asesor":
            # Sin detector de manos: se sigue el color del guante (asi funciona tambien la simulacion)
            gu = A.Guante(self.cfg)
            gu.hab = True
            m = gu.mascara(g.vista_mesa(frame))
            if m is not None and np.count_nonzero(m) > 0.004 * m.size:
                ys, xs = np.nonzero(m)
                k = np.argsort(ys)[:max(5, len(ys) // 40)]  # la punta: lo mas lejano del operario
                self.puntero_mm = (float(xs[k].mean() / g.sd), float(ys[k].mean() / g.sd))
        self.n_manos = len(self.manos_cam)
        for i, (est, dur, nuevo) in enumerate(self.gestos_act):
            if est == "puno" and dur >= 1.5 and self.modo not in ("menu", "arranque", "asesor") \
                    and self.gestos[i].una_vez("menu"):
                log("Gesto: puño sostenido -> menú")
                self._ir_modo("menu")

    def _puntas_mm(self):
        pts = []
        for m in self.manos_mm:
            for k in V.PUNTAS:
                if not np.isnan(m[k][0]):
                    pts.append((float(m[k][0]), float(m[k][1])))
        if not pts and self.puntero_mm:
            pts.append(self.puntero_mm)
        return pts

    def _pellizcos_mm(self):
        """Puntos (mm) donde una mano acaba de hacer pellizco."""
        res = []
        for i, (est, dur, nuevo) in enumerate(self.gestos_act):
            if est == "pellizco" and nuevo and i < len(self.manos_mm):
                m = self.manos_mm[i]
                res.append(((m[4][0] + m[8][0]) / 2.0, (m[4][1] + m[8][1]) / 2.0))
        return res

    def _manos_lienzo(self):
        s = self.geo.s
        return [m * s for m in self.manos_mm]

    def _ir_modo(self, m):
        self._accion("modo", {"modo": m})

    # ================================================================ arranque tipo consola
    def _m_arranque(self, frame, nuevo, ahora):
        t = ahora - self.t_arranque
        dur = 3.6 if self.cfg["inicio"].get("splash", True) else 0.0
        if not self._sono:
            self._sono = True
            self.voz.tono("inicio")
        if t < dur:
            return self._splash(t, dur)
        self._boot()
        return self.proy.negro()

    def _splash(self, t, dur):
        w, h = self.proy.w, self.proy.h
        img = np.zeros((h, w, 3), np.uint8)
        hor = int(h * 0.60)
        # sol con franjas
        cx, cy, r = w // 2, hor - int(h * 0.06), int(h * 0.26)
        sol = np.zeros_like(img)
        for yy in range(cy - r, hor):
            f = (yy - (cy - r)) / float(max(1, hor - (cy - r)))
            cv2.line(sol, (0, yy), (w, yy), (int(80 + 60 * f), int(60 + 120 * (1 - f)), 255), 1)
        disco = np.zeros((h, w), np.uint8)
        cv2.circle(disco, (cx, cy), r, 255, -1)
        for k in range(6):
            yk = hor - 12 - k * int(r * 0.13)
            cv2.rectangle(disco, (0, yk - (k + 2)), (w, yk), 0, -1)
        disco[hor:] = 0
        img[disco > 0] = sol[disco > 0]
        # piso con rejilla en perspectiva que avanza
        fase = (t * 0.9) % 1.0
        for k in range(12):
            y = int(hor + (h - hor) * ((k + fase) / 12.0) ** 2)
            cv2.line(img, (0, y), (w, y), (190, 40, 210), 2)
        for i in range(-14, 15):
            cv2.line(img, (w // 2 + i * w // 70, hor), (w // 2 + i * w // 9, h), (190, 40, 210), 2)
        cv2.line(img, (0, hor), (w, hor), (255, 120, 255), 3)
        # logo que aparece letra por letra
        n = min(6, int(t / 0.13) + 1)
        logo = "ASESOR"[:n]
        tam = int(h * 0.19)
        A.poner_texto(img, logo, w // 2 + 8, int(h * 0.22) + 8, tam, (255, 220, 0), True, mono=True)
        A.poner_texto(img, logo, w // 2, int(h * 0.22), tam, (255, 255, 255), True, mono=True)
        A.poner_texto(img, "ESTACIÓN DE GUIADO POR PROYECCIÓN", w // 2, int(h * 0.36), int(h * 0.035),
                      (230, 200, 255), True, mono=True)
        # estado
        det = self.cfg["manos"].get("motor", "auto")
        lineas = ["CÁMARA ........ %s" % ("SIMULADA" if self.sim else "OK"),
                  "PROYECTOR ..... %dx%d" % (w, h),
                  "VOZ ........... %s" % (self.voz.motor or "TEXTO").upper(),
                  "MANOS ......... %s" % ("POSENET" if V.HAY_JETSON else "MEDIAPIPE" if det != "posenet" else "-"),
                  "CALIBRACIÓN ... %s" % ("OK" if self.calib else "PENDIENTE")]
        for i, l in enumerate(lineas):
            if t > 0.9 + i * 0.35:
                A.poner_texto(img, l, int(w * 0.06), int(h * 0.70) + i * int(h * 0.05), int(h * 0.03),
                              (120, 255, 120), mono=True)
        bx0, bx1, by = int(w * 0.55), int(w * 0.94), int(h * 0.92)
        cv2.rectangle(img, (bx0, by), (bx1, by + int(h * 0.025)), (255, 255, 255), 2)
        cv2.rectangle(img, (bx0 + 4, by + 4), (bx0 + 4 + int((bx1 - bx0 - 8) * min(1.0, t / dur)),
                                               by + int(h * 0.025) - 4), (255, 220, 0), -1)
        if t > dur - 1.0 and int(t * 4) % 2 == 0:
            A.poner_texto(img, "CARGANDO MENÚ", bx0, by - int(h * 0.05), int(h * 0.03), (255, 255, 255), mono=True)
        img[::3] = (img[::3] * 0.55).astype(np.uint8)  # lineas de barrido tipo TV
        return img

    def _boot(self):
        destino = self.cfg["inicio"].get("modo", "menu")
        if destino not in IDS_MODOS:
            destino = "menu"
        if self.calib is None:
            if self.sim:
                self._accion("calibrar", {})
            if self.calib is None:
                self.modo = "calibracion"
                self.voz.decir("Falta calibrar. Pegue los marcadores y calibre desde el panel")
                return
        else:
            r = A.verificar_calibracion(self.cfg, self.cam, self.proy, self.calib)
            if r is False:
                self.voz.decir("La cámara se movió. Recalibrando")
                self._accion("calibrar", {})
        self.modo = "arranque"
        self._ir_modo(destino)
        if destino == "menu":
            self.voz.decir("Elija un modo")

    # ================================================================ menu proyectado
    def _menu_tiles(self):
        g = self.geo
        if self._tiles is None:
            cols, filas, m, top, gap = 5, 3, 15.0, 100.0, 14.0
            tw = (g.W - 2 * m - (cols - 1) * gap) / cols
            th = (g.H - top - m - (filas - 1) * gap) / filas
            b = self.cfg["botones"]
            self._tiles = []
            for i, mid in enumerate(MENU_ITEMS):
                c, f = i % cols, i // cols
                rect = [m + c * (tw + gap), top + f * (th + gap), tw, th]
                self._tiles.append({"id": mid, "rect": rect, "zona": A.Zona(mid, rect, g, self.cfg),
                                    "ret": A.Retencion(max(1.2, b.get("tiempo_activacion_s", 1.5)),
                                                       b.get("umbral_ocupacion", 0.25))})
        return self._tiles

    def _m_menu(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._mensaje("Falta calibrar: elige Calibración en el panel o di 'calibración'.")
        tiles = self._menu_tiles()
        elegido, hover = None, None
        if self.puntero_mm:
            for i, tl in enumerate(tiles):
                x, y, w, h = tl["rect"]
                if x <= self.puntero_mm[0] <= x + w and y <= self.puntero_mm[1] <= y + h:
                    hover = i
            if hover is not None:
                self.menu_sel = hover
        if nuevo:
            v = gris(g.vista_mesa(frame))
            for tl in tiles:
                if tl["ret"].actualizar(tl["zona"].actualizar(v, ahora), ahora):
                    elegido = tl["id"]
            for px, py in self._pellizcos_mm():
                for tl in tiles:
                    x, y, w, h = tl["rect"]
                    if x <= px <= x + w and y <= py <= y + h:
                        elegido = tl["id"]
        L = g.lienzo()
        A.poner_texto(L, "ASESOR", g.px(18), g.px(12), g.px(46), A.AMARILLO, mono=True)
        A.poner_texto(L, "ELIGE UN MODO", g.px(210), g.px(18), g.px(24), A.BLANCO, mono=True)
        A.poner_texto(L, "Pellizca o deja la mano quieta sobre un modo  ·  di su nombre  ·  puño 1.5 s = menú",
                      g.px(210), g.px(52), g.px(15), A.GRIS)
        A.poner_texto(L, "%s  ·  http://%s:%d" % (time.strftime("%H:%M"), self.ip, self.args.puerto),
                      g.px(g.W - 330), g.px(18), g.px(17), A.GRIS, mono=True)
        info = {m["id"]: m for m in MODOS}
        for i, tl in enumerate(tiles):
            (x0, y0), (x1, y1) = g.rect(tl["rect"])
            col = A.CIAN if tl["id"] in MODOS_TRABAJO else MAGENTA
            cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
            if i == self.menu_sel:
                d = g.px(7)
                cv2.rectangle(L, (x0 - d, y0 - d), (x1 + d, y1 + d), A.AMARILLO, max(2, g.px(4)))
            A.poner_texto(L, "%02d" % (i + 1), x0 + g.px(8), y0 + g.px(6), g.px(26), col, mono=True)
            nombre = info[tl["id"]]["nombre"].upper()
            A.poner_texto(L, nombre, x0 + g.px(8), y0 + g.px(40), min(g.px(22), int((x1 - x0) * 0.9 / max(1, len(nombre) * 0.62))),
                          A.BLANCO, mono=True)
            A.poner_parrafo(L, info[tl["id"]]["desc"],
                            x0 + g.px(8), y0 + g.px(70), x1 - x0 - g.px(16), g.px(13), A.GRIS)
            prog = tl["ret"].progreso(ahora)
            if prog > 0:
                cv2.rectangle(L, (x0 + g.px(4), y1 - g.px(10)), (x0 + g.px(4) + int((x1 - x0 - g.px(8)) * prog),
                                                                  y1 - g.px(5)), A.AMARILLO, -1)
        if self.puntero_mm:
            c = (g.px(self.puntero_mm[0]), g.px(self.puntero_mm[1]))
            cv2.circle(L, c, g.px(10), A.AMARILLO, max(2, g.px(3)))
        if elegido:
            self.voz.tono("clic")
            log("Menú ->", elegido)
            self._ir_modo(elegido)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ gestos
    def _m_gestos(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        det = self._detector_manos()
        if not det.ok:
            return self._mensaje("Gestos necesita el detector de manos. " + det.error)
        L = g.lienzo()
        boton = [g.W / 2 - 130, g.H - 190, 260, 150]
        for i, (est, dur, nuevo_g) in enumerate(self.gestos_act):
            if nuevo_g and est:
                self.cont_gestos[est] = self.cont_gestos.get(est, 0) + 1
        for px, py in self._pellizcos_mm():
            if boton[0] <= px <= boton[0] + boton[2] and boton[1] <= py <= boton[1] + boton[3]:
                self.t_flash = ahora
                self.voz.tono("clic")
        M.dibujar_manos(L, self._manos_lienzo(), g.s * 1.8)
        for i, m in enumerate(self._manos_lienzo()):
            if i < len(self.gestos_act) and not np.isnan(m[0][0]):
                est, dur, _ = self.gestos_act[i]
                A.poner_texto(L, "%s %.1fs" % (V.NOMBRES_GESTOS.get(est, est), dur) if est else "—",
                              int(m[0][0]) - g.px(40), int(m[0][1]) + g.px(30), g.px(24), A.AMARILLO)
        (x0, y0), (x1, y1) = g.rect(boton)
        col = A.VERDE if ahora - self.t_flash < 0.6 else A.CIAN
        cv2.rectangle(L, (x0, y0), (x1, y1), col, max(3, g.px(5)))
        A.poner_texto(L, "PELLIZCA AQUÍ", (x0 + x1) // 2, (y0 + y1) // 2, g.px(26), col, True)
        leyenda = ["Palma abierta 1 s: iniciar", "Pulgar arriba: siguiente", "Pellizco: presionar",
                   "Puño 1.5 s: menú"]
        for i, l in enumerate(leyenda):
            A.poner_texto(L, l, g.px(20), g.px(15 + 28 * i), g.px(20), A.GRIS)
        cuenta = "   ".join("%s %d" % (V.NOMBRES_GESTOS[k], v) for k, v in sorted(self.cont_gestos.items()))
        A.poner_texto(L, cuenta or "Haz un gesto frente a la cámara", g.px(g.W / 2 - 60), g.px(15), g.px(18), A.BLANCO)
        if nuevo:
            prev = frame.copy()
            M.dibujar_manos(prev, self.manos_cam, 1.5)
            self._previa("vista", prev)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ esqueleto de neon con estelas
    def _m_esqueleto(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        if nuevo:
            vistos = set()
            for i, m in enumerate(self._manos_lienzo()):
                for k in V.PUNTAS:
                    if not np.isnan(m[k][0]):
                        self.estelas.setdefault((i, k), collections.deque(maxlen=28)).append(
                            (int(m[k][0]), int(m[k][1])))
                        vistos.add((i, k))
            if not self.manos_mm and self.puntero_mm:
                self.estelas.setdefault(("p", 0), collections.deque(maxlen=40)).append(
                    (g.px(self.puntero_mm[0]), g.px(self.puntero_mm[1])))
                vistos.add(("p", 0))
            for clave in list(self.estelas):
                if clave not in vistos:
                    if self.estelas[clave]:
                        self.estelas[clave].popleft()
                    else:
                        del self.estelas[clave]
        capa = g.lienzo()
        colores = [(255, 80, 255), (255, 220, 0), (0, 255, 200), (0, 180, 255), (120, 120, 255)]
        for (i, k), pts in self.estelas.items():
            col = colores[(V.PUNTAS.index(k) if k in V.PUNTAS else 0) % len(colores)]
            n = len(pts)
            for j in range(1, n):
                f = j / float(n)
                cv2.line(capa, pts[j - 1], pts[j], tuple(int(c * f) for c in col), max(1, int(g.px(10) * f)),
                         cv2.LINE_AA)
        for m in self._manos_lienzo():
            vis = ~np.isnan(m[:, 0])
            p = np.nan_to_num(m).astype(np.int32)
            for a, b in M.CONEXIONES:
                if vis[a] and vis[b]:
                    cv2.line(capa, tuple(int(v) for v in p[a]), tuple(int(v) for v in p[b]), (255, 60, 220),
                             max(2, g.px(5)), cv2.LINE_AA)
            for k in range(21):
                if vis[k]:
                    cv2.circle(capa, tuple(int(v) for v in p[k]), g.px(6), (255, 255, 120), -1, cv2.LINE_AA)
        brillo = cv2.GaussianBlur(capa, (0, 0), max(1, g.px(9)))
        L = cv2.addWeighted(capa, 1.0, brillo, 1.8, 0)
        if not self.estelas and not self.manos_mm:
            A.poner_texto(L, "Mueve las manos sobre la mesa", g.px(20), g.px(15), g.px(24), A.GRIS)
        if nuevo:
            self._previa("mascara", L)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ particulas
    def _m_particulas(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        c = self.cfg["particulas"]
        n = int(c["cantidad"])
        if self.pt_pos is None or len(self.pt_pos) != n:
            self.pt_pos = np.random.rand(n, 2).astype(np.float32) * np.float32([g.W, g.H])
            self.pt_vel = np.zeros((n, 2), np.float32)
            self.pt_r = (35.0 + np.random.rand(n, 1) ** 1.5 * 170.0).astype(np.float32)  # radio propio de cada una
            self.pt_t = ahora
        dt = float(min(0.08, max(0.005, ahora - self.pt_t)))
        self.pt_t = ahora
        pos, vel = self.pt_pos, self.pt_vel
        acc = np.zeros_like(pos)
        atr = self._puntas_mm()
        if atr:
            A_ = np.float32(atr)
            d = A_[None, :, :] - pos[:, None, :]
            dist = np.sqrt((d ** 2).sum(-1)) + 1.0
            k = dist.argmin(1)
            v = d[np.arange(len(pos)), k]
            dm = dist[np.arange(len(pos)), k][:, None]
            modo = c["comportamiento"]
            tang = np.stack([-v[:, 1], v[:, 0]], 1) / dm
            if modo == "seguir":  # nube que gira alrededor de los dedos
                acc += v / dm * np.clip((dm - self.pt_r) * 14.0, -2500.0, 3000.0) + tang * 700.0
            elif modo == "esquivar":
                acc -= v / dm * (9e6 / (dm ** 2 + 2500.0))
            else:  # orbitar: anillos rapidos
                acc += tang * 2600.0 + v / dm * (dm - self.pt_r * 0.7) * 16.0
        t = ahora
        acc[:, 0] += 180.0 * np.sin(pos[:, 1] * 0.012 + t * 0.7)
        acc[:, 1] += 180.0 * np.cos(pos[:, 0] * 0.010 - t * 0.6)
        for px, py in self._pellizcos_mm():  # pellizco = explosion
            d = pos - np.float32([px, py])
            r = np.sqrt((d ** 2).sum(1))[:, None] + 1.0
            vel += d / r * (60000.0 / (r + 40.0))
        vel *= np.float32(0.955)
        vel += acc * dt
        vel_n = np.sqrt((vel ** 2).sum(1))[:, None]
        vel *= np.minimum(1.0, 900.0 / (vel_n + 1e-3))
        pos += vel * dt
        pos[:, 0] %= g.W
        pos[:, 1] %= g.H
        sd = 0.5
        W2, H2 = int(g.W * sd), int(g.H * sd)
        xi = np.clip((pos[:, 0] * sd).astype(np.int32), 0, W2 - 1)
        yi = np.clip((pos[:, 1] * sd).astype(np.int32), 0, H2 - 1)
        buf = np.bincount(yi * W2 + xi, weights=np.sqrt(vel_n[:, 0]) + 6.0, minlength=W2 * H2)
        buf = buf.reshape(H2, W2).astype(np.float32)
        brillo = cv2.GaussianBlur(buf, (0, 0), 1.4) * 26.0 + buf * 6.0
        mapa = np.clip(brillo, 0, 255).astype(np.uint8)
        col = a_color(mapa, c["paleta"])
        col[mapa < 6] = 0
        L = cv2.resize(col, g.tam_lienzo, interpolation=cv2.INTER_LINEAR)
        if nuevo:
            self._previa("mascara", L)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ pizarra
    def _m_pizarra(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        if self.pizarra is None or self.pizarra.shape[:2] != (g.tam_lienzo[1], g.tam_lienzo[0]):
            self.pizarra = g.lienzo()
        c = self.cfg["pizarra"]
        color = COLORES_PIZARRA.get(c["color"], A.CIAN)
        grosor = max(1, g.px(float(c["grosor"])))
        borrar = [g.W - 140, 10, 130, 80]
        if nuevo:
            trazos = []
            if self.manos_mm:
                for i, m in enumerate(self.manos_mm):
                    est = self.gestos_act[i][0] if i < len(self.gestos_act) else ""
                    dur = self.gestos_act[i][1] if i < len(self.gestos_act) else 0
                    if est == "pellizco" and not np.isnan(m[4][0]) and not np.isnan(m[8][0]):
                        trazos.append((i, ((m[4][0] + m[8][0]) / 2, (m[4][1] + m[8][1]) / 2)))
                    if est == "palma" and dur >= 2.0 and self.gestos[i].una_vez("borrar"):
                        self.pizarra[:] = 0
                        self.voz.decir("Pizarra borrada")
            elif self.puntero_mm:
                trazos.append((0, self.puntero_mm))
            activos = set()
            for i, (x, y) in trazos:
                p = (g.px(x), g.px(y))
                if borrar[0] <= x <= borrar[0] + borrar[2] and borrar[1] <= y <= borrar[1] + borrar[3]:
                    self.pizarra[:] = 0
                    self.piz_prev.clear()
                    continue
                if i in self.piz_prev:
                    cv2.line(self.pizarra, self.piz_prev[i], p, color, grosor, cv2.LINE_AA)
                self.piz_prev[i] = p
                activos.add(i)
            for i in list(self.piz_prev):
                if i not in activos:
                    del self.piz_prev[i]
        L = self.pizarra.copy()
        (x0, y0), (x1, y1) = g.rect(borrar)
        cv2.rectangle(L, (x0, y0), (x1, y1), A.ROJO, max(2, g.px(3)))
        A.poner_texto(L, "BORRAR", (x0 + x1) // 2, (y0 + y1) // 2, g.px(20), A.ROJO, True)
        A.poner_texto(L, "Pellizca y mueve para dibujar  ·  palma 2 s o BORRAR limpia", g.px(20), g.px(15),
                      g.px(18), A.GRIS)
        if self.puntero_mm:
            cv2.circle(L, (g.px(self.puntero_mm[0]), g.px(self.puntero_mm[1])), g.px(8), color, max(1, g.px(2)))
        if nuevo:
            self._previa("mascara", L)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ objetos / instrumental
    def _detector_objetos(self):
        c = self.cfg["objetos"]
        clave = (c.get("modelo", "general"), float(c.get("umbral", 0.5)))
        if self.det_obj is None or self._clave_obj != clave:
            modelo = "general" if clave[0] == "general" else "carpeta"
            self.det_obj = V.Objetos(modelo, c.get("carpeta", "modelo_detector"), clave[1])
            self._clave_obj = clave
            log("Objetos:", self.det_obj.motor if self.det_obj.ok else self.det_obj.error)
            if self.asesor:
                self.asesor.objetos = self.det_obj if self.det_obj.ok else None
        return self.det_obj

    def _m_objetos(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        det = self._detector_objetos()
        if not det.ok:
            return self._mensaje("Objetos: " + det.error)
        if nuevo and ahora - self.t_obj > 0.1:
            self.t_obj = ahora
            dets = det.detectar(frame)
            self.cuenta_obj = V.contar(dets)
            self.dets_obj = []
            prev = frame.copy()
            for clase, conf, x1, y1, x2, y2 in dets:
                esq = np.float32([[[x1, y1]], [[x2, y1]], [[x2, y2]], [[x1, y2]]])
                poly = cv2.perspectiveTransform(esq, g.H_cam2lienzo).astype(np.int32)
                self.dets_obj.append((clase, conf, poly))
                cv2.rectangle(prev, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                cv2.putText(prev, "%s %d%%" % (A.sin_acentos(clase), conf * 100), (int(x1), int(y1) - 6),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            self._previa("vista", prev)
        L = g.lienzo()
        for clase, conf, poly in self.dets_obj:
            col = PALETA_CLASES[sum(ord(ch) for ch in clase) % len(PALETA_CLASES)]
            cv2.polylines(L, [poly], True, col, max(2, g.px(3)))
            p0 = poly[:, 0, :].min(axis=0)
            A.poner_texto(L, "%s %d%%" % (clase, round(conf * 100)), int(p0[0]), int(p0[1]) - g.px(22), g.px(17), col)
        y = g.px(15)
        A.poner_texto(L, "Detector: %s" % ("general (90 objetos)" if self.cfg["objetos"]["modelo"] == "general"
                                           else "instrumental"), g.px(20), y, g.px(18), A.GRIS)
        for i, (clase, n) in enumerate(sorted(self.cuenta_obj.items())):
            A.poner_texto(L, "%s: %d" % (clase, n), g.px(20), y + g.px(28 * (i + 1)), g.px(22), A.BLANCO)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ dedos (cuadro entre las manos)
    def _m_dedos(self, frame, nuevo, ahora):
        g = self.geo
        if g is None:
            return self._sin_calib()
        det = self._detector_manos()
        if not det.ok:
            return self._mensaje("Dedos necesita el detector de manos. " + det.error)
        if nuevo:
            vista = cv2.warpPerspective(frame, g.H_cam2lienzo, g.tam_lienzo)
            d = self.cfg["dedos"]
            manos_l = self._manos_lienzo()
            L, _ = M.componer(g.lienzo(), manos_l, d["efecto"], fuente=vista, esqueleto=bool(d["esqueleto"]),
                              escala=g.s * 1.6)
            if len(manos_l) < 2:
                A.poner_texto(L, "Pon las dos manos: pulgar e índice forman el cuadro", g.px(20), g.px(15),
                              g.px(24), A.GRIS)
            self._dedos_L = L
            prev = frame.copy()
            M.dibujar_manos(prev, self.manos_cam, 1.5)
            self._previa("vista", prev)
            self._previa("mascara", L)
        L = self._dedos_L if self._dedos_L is not None else g.lienzo()
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def _m_calibracion(self, frame, nuevo, ahora):
        if self.geo is None:
            return self._mensaje("Modo calibración: pega los 4 marcadores y presiona Calibrar en el panel.")
        L = self.geo.lienzo()
        g = self.geo
        for (x, y) in [(0, 0), (g.W, 0), (g.W, g.H), (0, g.H)]:
            cv2.circle(L, (g.px(x), g.px(y)), g.px(40), A.VERDE, max(2, g.px(4)))
        A.poner_parrafo(L, "Calibrado. Los círculos deben caer sobre los marcadores.", g.px(60),
                        g.px(g.H / 2 - 30), g.px(g.W - 120), g.px(30), A.VERDE)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    # ================================================================ entradas: voz, teclado, OSC
    def _voz_comandos(self):
        while True:
            try:
                tipo, v = self.voz_q.get_nowait()
            except queue.Empty:
                return
            if v == "menu":
                self._ir_modo("menu")
            elif isinstance(v, str) and v.startswith("modo:"):
                self._ir_modo(v[5:])
            else:
                self.eventos.put((tipo, v))

    def _tecla(self, k):
        if k in (27, 8, ord("m")):
            self._ir_modo("menu")
            return
        if self.modo == "menu":
            n = len(MENU_ITEMS)
            mov = {65361: -1, ord("a"): -1, 65363: 1, ord("d"): 1, 65362: -5, ord("w"): -5, 65364: 5, ord("s"): 5}
            if k in mov:
                self.menu_sel = (self.menu_sel + mov[k]) % n
            elif k in (13, 10, 32, 65421):
                self._ir_modo(MENU_ITEMS[self.menu_sel])
            elif ord("1") <= k <= ord("9"):
                self._ir_modo(MENU_ITEMS[k - ord("1")])
            elif k == ord("0"):
                self._ir_modo(MENU_ITEMS[9])
        elif k == ord("c"):
            self._accion("calibrar", {})
        elif k in (ord("i"), ord("n"), ord("r")):
            self.eventos.put(("cmd", {"i": "iniciar", "n": "siguiente", "r": "repetir"}[chr(k)]))

    def _osc(self):
        c = self.cfg["osc"]
        destino = (c.get("host", "127.0.0.1"), int(c.get("puerto", 7000)))
        if self.emisor is None or self.emisor.destino != destino:
            self.emisor = V.EmisorOSC(*destino)
            log("OSC: enviando a %s:%d" % destino)
        e, g = self.emisor, self.geo
        e.enviar("/modo", self.modo)
        e.enviar("/manos/n", len(self.manos_mm))
        for i, m in enumerate(self.manos_mm):
            for k in range(21):
                if not np.isnan(m[k][0]):
                    e.enviar("/mano/%d/p%d" % (i, k), float(m[k][0] / g.W), float(m[k][1] / g.H))
            e.enviar("/mano/%d/gesto" % i, self.gestos_act[i][0] if i < len(self.gestos_act) else "")
        if self.puntero_mm:
            e.enviar("/puntero", float(self.puntero_mm[0] / g.W), float(self.puntero_mm[1] / g.H))
        for clase, n in self.cuenta_obj.items():
            e.enviar("/objetos/" + A.sin_acentos(clase).replace(" ", "_"), int(n))

    # ================================================================ bucle principal
    def correr(self):
        t_prev, t_prev_img, cuadros, t_fps = 0.0, 0.0, 0, time.time()
        errores_manos = 0
        while self.vivo:
            self._atender()
            self._voz_comandos()
            frame, t = self.cam.leer()
            ahora = time.time()
            nuevo = frame is not None and t != t_prev
            if nuevo:
                t_prev = t
                cuadros += 1
                if self.geo is not None and self.modo != "arranque" and self._usa_manos():
                    try:
                        self._actualizar_manos(frame, ahora)
                    except Exception as e:
                        errores_manos += 1
                        if errores_manos < 5:
                            log("Error de manos:", e)
            try:
                img = getattr(self, "_m_" + self.modo)(frame, nuevo, ahora)
            except Exception as e:
                self.error = "Modo %s: %s" % (self.modo, e)
                traceback.print_exc()
                img = self._mensaje("Error: %s" % e, A.ROJO)
                time.sleep(0.2)
            k = self.proy.mostrar(img, 1)
            if nuevo and self.geo is not None and self.cfg["osc"].get("habilitado"):
                self._osc()
            if nuevo and ahora - t_prev_img > 0.12:
                t_prev_img = ahora
                self._previa("camara", reducir(frame))
                self._previa("proyector", reducir(img))
            if ahora - t_fps >= 2:
                self.fps = cuadros / (ahora - t_fps)
                t_fps, cuadros = ahora, 0
            if k == ord("q"):
                break
            if k != 255:
                self._tecla(k)
        self.cam.cerrar()

    # ---------- estado para la pagina
    def estado(self):
        a = self.asesor
        ocup, geom, fsm = {}, {"zonas": {}, "botones": {}, "lugares": {}}, None
        receta = None
        if a:
            receta = a.receta
            for n, z in a.zonas.items():
                ocup[n] = round(z.ocupacion, 3)
            for n, b in a.botones.items():
                ocup[n] = round(b["zona"].ocupacion, 3)
            for n, d in a.lugares.items():
                ocup[n] = round(d["zona"].ocupacion, 3)
            fsm = {"estado": a.estado, "paso": a.i + 1, "total": len(a.receta.get("pasos", [])),
                   "texto": a.p.get("texto", "") if a.p else "", "tipo": a.p.get("tipo") if a.p else "",
                   "aviso": a.aviso[1] if a.aviso and time.time() < a.aviso[2] else "",
                   "aviso_tipo": a.aviso[0] if a.aviso else ""}
        else:
            try:
                receta = A.cargar_json(A.ruta(self.cfg["receta"]))
            except Exception:
                receta = {}
        if receta:
            geom["zonas"] = receta.get("zonas", {})
            geom["botones"] = receta.get("botones", {})
            geom["lugares"] = {n: {"rect": d["rect"], "instrumento": d.get("instrumento", "")}
                               for n, d in receta.get("lugares", {}).items()}
        cls = {n: [e, round(c, 3), (a.lugares[n]["instrumento"] if a and n in a.lugares else "")]
               for n, (e, c) in self.res_cls.items()}
        if a and a.p and a.p.get("tipo") == "charola":
            for n, e in a.sub.get("estado", {}).items():
                cls[n] = [e[1], round(e[2], 3), a.lugares[n]["instrumento"]]
        cap = {k: v for k, v in self.cap.items() if k in ("activo", "clase", "fase", "n", "previas", "max", "tipo")}
        mano = None
        if self.sim:
            mano = {"auto": self.sim.mano_auto, "pos": list(self.sim.mano) if self.sim.mano else None}
        return {
            "sim": bool(self.sim), "modo": self.modo, "modos": MODOS, "fps": round(self.fps, 1),
            "calibrado": self.calib is not None, "calibrando": self.calibrando,
            "calib": {"error_px": round(self.calib.get("error_px", 0), 2), "fecha": self.calib.get("fecha", "")}
            if self.calib else None,
            "verificacion": self.verificacion,
            "mesa": {"W": self.cfg["mesa"]["ancho_mm"], "H": self.cfg["mesa"]["alto_mm"]},
            "camara": {"tipo": self.cfg["camara"].get("tipo", "usb"), "ancho": self.cfg["camara"]["ancho"],
                       "alto": self.cfg["camara"]["alto"]},
            "proyector": {"ancho": self.proy.w, "alto": self.proy.h},
            "receta": self.cfg["receta"], "recetas": self._recetas(), "geom": geom,
            "ocupacion": ocup, "fsm": fsm,
            "clasif": {"ok": self.clasif.ok, "etiquetas": getattr(self.clasif, "etiquetas", []), "res": cls,
                       "umbral": self.clasif.umbral},
            "captura": cap, "cobertura": round(self.cobertura, 4),
            "patron": self.patron, "puntero": self.puntero, "rects": self.rects,
            "voz": {"motor": self.voz.motor or "texto", "ultimo": self.ultima_voz,
                    "hablando": self.voz.hablando.is_set()},
            "torque": self.ultimo_torque, "mano": mano, "n_manos": self.n_manos,
            "manos_motor": self.det_manos.motor if self.det_manos else "",
            "gestos": [[e, round(d, 1)] for e, d, _ in self.gestos_act],
            "puntero": self.puntero_mm if self.modo != "patrones" else self.puntero,
            "objetos": {"ok": bool(self.det_obj and self.det_obj.ok),
                        "motor": self.det_obj.motor if self.det_obj else "",
                        "error": self.det_obj.error if self.det_obj and not self.det_obj.ok else "",
                        "modelo": self.cfg["objetos"]["modelo"], "cuenta": self.cuenta_obj,
                        "dets": [[c, round(p, 2)] for c, p, _ in self.dets_obj][:20]},
            "osc": {"hab": bool(self.cfg["osc"].get("habilitado")), "host": self.cfg["osc"].get("host"),
                    "puerto": self.cfg["osc"].get("puerto"), "enviados": self.emisor.enviados if self.emisor else 0},
            "ip": self.ip, "menu_sel": self.menu_sel,
            "manos_error": self.det_manos.error if self.det_manos and not self.det_manos.ok else "",
            "params": [p + [cfg_get(self.cfg, p[0])] for p in PARAMS],
            "log": list(LOG)[-60:], "error": self.error,
        }


# ------------------------------------------------------------------ Servidor web
class Servidor(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


MOTOR = None
PAGINA = os.path.join(A.BASE, "panel.html")


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _enviar(self, codigo, cuerpo, tipo):
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(cuerpo)

    def _json(self, obj, codigo=200):
        self._enviar(codigo, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        ruta = self.path.split("?")[0]
        try:
            if ruta in ("/", "/index.html"):
                with open(PAGINA, "rb") as f:
                    self._enviar(200, f.read(), "text/html; charset=utf-8")
            elif ruta == "/api/estado":
                with MOTOR.lock:
                    pass
                self._json(MOTOR.estado())
            elif ruta.startswith("/img/") and ruta.endswith(".jpg"):
                nombre = ruta[5:-4]
                with MOTOR.lock:
                    img = MOTOR.previas.get(nombre)
                if img is None:
                    img = np.full((90, 160, 3), 30, np.uint8)
                ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 72])
                self._enviar(200, buf.tobytes(), "image/jpeg")
            else:
                self._json({"error": "no existe"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            traceback.print_exc()
            self._json({"error": str(e)}, 500)

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
            datos = json.loads(self.rfile.read(n).decode("utf-8") or "{}") if n else {}
            ruta = self.path.split("?")[0]
            if ruta == "/api/accion":
                MOTOR.cmds.put((datos.get("accion", ""), datos))
                self._json({"ok": True})
            else:
                self._json({"error": "no existe"}, 404)
        except Exception as e:
            self._json({"error": str(e)}, 400)


def ip_local():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "IP-de-la-jetson"


def main():
    global MOTOR
    ap = argparse.ArgumentParser(description="Panel de pruebas del Asesor (estilo nodos)")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--receta", default="")
    ap.add_argument("--simular", action="store_true", help="sin camara ni proyector")
    ap.add_argument("--puerto", type=int, default=8080)
    ap.add_argument("--pantalla", default=":0")
    args = ap.parse_args()
    if A.aruco is None:
        sys.exit("Tu OpenCV no trae ArUco. Corre instalar.sh")
    MOTOR = Motor(args)
    srv = Servidor(("0.0.0.0", args.puerto), Manejador)
    th = threading.Thread(target=srv.serve_forever)
    th.daemon = True
    th.start()
    log("Panel listo: abre http://%s:%d  (o la IP de Tailscale de la Jetson)" % (ip_local(), args.puerto))
    try:
        MOTOR.correr()
    except KeyboardInterrupt:
        log("Panel detenido")
    finally:
        srv.shutdown()


if __name__ == "__main__":
    main()
