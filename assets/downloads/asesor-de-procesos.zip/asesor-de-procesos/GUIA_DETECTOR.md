# Guía: detector de objetos e instrumental quirúrgico

El modo **Objetos** encuentra cosas en **cualquier parte de la mesa**, las encierra con un recuadro proyectado con su nombre y las **cuenta**. Usa **detectNet** de NVIDIA (jetson-inference), optimizado con TensorRT para la Jetson.

Hay dos modelos:

| Modelo | Qué reconoce | Qué necesitas |
|---|---|---|
| **General** | 90 objetos comunes: tijeras, botella, taza, celular, libro, teclado… | Nada: viene listo |
| **Instrumental** | Tus instrumentos: pinza Kelly, tijera Mayo, porta agujas… | Entrenarlo con fotos tuyas (esta guía) |

> El modelo general **no conoce instrumental quirúrgico**: a lo más dice "tijeras". Para distinguir tus instrumentos hay que entrenar el tuyo.

---

## Paso 0. Instalar jetson-inference (una sola vez)
En la Jetson, desde MobaXterm:
```bash
cd ~/asesor
bash instalar_vision.sh
```
Tarda de 30 a 90 minutos. También instala **poseNet**, que es el detector de manos de los modos Gestos, Esqueleto, Dedos, Partículas y Pizarra.

## Paso 1. Probar el modelo general
1. Abre el panel (`http://IP-de-la-jetson:8080`) y elige el modo **Objetos**.
2. En parámetros deja **Modelo: general**.
3. Pon en la mesa tijeras, una botella o una taza.

La primera vez tarda unos minutos en arrancar porque TensorRT optimiza el modelo para tu Jetson. Después arranca en segundos.

---

## Paso 2. Tomar fotos para el modelo de instrumental
1. En el panel, modo **Captura**.
2. En el selector elige **Mesa completa (detector de objetos)**.
3. Escribe un nombre, por ejemplo `instrumental`, y presiona **Iniciar**.
4. Pon los instrumentos sobre la mesa y quita las manos: cada vez que todo queda quieto se toma una foto (suena un clic).
5. **Entre fotos, cambia los instrumentos de lugar**, gíralos, ábrelos, júntalos, quita unos y pon otros.

Las fotos quedan en `~/asesor/dataset_detector/JPEGImages/`.

**Cuántas fotos:** entre 150 y 300 en total, procurando que cada instrumento aparezca **100 o más veces** sumando todas las fotos. Incluye fotos con la luz real del cuarto, con el proyector encendido, instrumentos encimados y un poco tapados.

## Paso 3. Dibujar los recuadros (etiquetar)
Cada instrumento en cada foto necesita su recuadro con su nombre. Es la parte manual.

1. Baja la carpeta `dataset_detector` a tu PC con el panel SFTP de MobaXterm (clic derecho → Download).
2. Usa **CVAT** (cvat.ai) o **Roboflow** (roboflow.com); los dos tienen versión gratuita en el navegador.
3. Crea las clases **con el mismo nombre que usarás en la receta**, por ejemplo `Pinza Kelly`, `Tijera Mayo`, `Porta agujas`.
4. Sube las fotos y dibuja un recuadro ajustado alrededor de cada instrumento.
5. Exporta en formato **Pascal VOC**. Te baja un `.zip` con imágenes y archivos `.xml`.
6. Descomprímelo y ordénalo con:
```bash
python3 preparar_voc.py carpeta_descomprimida instrumental
```
Queda una carpeta `instrumental/` lista para entrenar.

**Consejos para etiquetar:**
- El recuadro debe tocar los bordes del instrumento, sin dejar mucho aire.
- Si un instrumento está medio tapado, etiquétalo igual.
- Si dos instrumentos son casi iguales vistos desde arriba, júntalos en una clase al principio.

## Paso 4. Entrenar
Elige una opción. La **A** es mucho más rápida.

### Opción A: en tu PC con tarjeta NVIDIA, o en Google Colab
```bash
git clone --depth=1 https://github.com/dusty-nv/pytorch-ssd
cd pytorch-ssd
pip install -r requirements.txt
mkdir -p models
wget https://nvidia.box.com/shared/static/djf5w54rjvpqocsiztzaandq1m3avr7c.pth -O models/mobilenet-v1-ssd-mp-0_675.pth
python3 train_ssd.py --dataset-type=voc --data=RUTA/instrumental --model-dir=models/instrumental --batch-size=8 --epochs=60
python3 onnx_export.py --model-dir=models/instrumental
```
Al final, en `models/instrumental/` quedan **`ssd-mobilenet.onnx`** y **`labels.txt`**.

### Opción B: todo en la Jetson (lento, unas horas)
Necesitas haber aceptado PyTorch al instalar jetson-inference.
```bash
cd ~/jetson-inference/python/training/detection/ssd
python3 train_ssd.py --dataset-type=voc --data=RUTA/instrumental --model-dir=models/instrumental --batch-size=2 --workers=1 --epochs=40
python3 onnx_export.py --model-dir=models/instrumental
```
Detén el panel mientras entrenas, para que la Jetson tenga toda la memoria.

## Paso 5. Instalar tu modelo en la estación
Copia los dos archivos a la carpeta `~/asesor/modelo_detector/`:
```
~/asesor/modelo_detector/ssd-mobilenet.onnx
~/asesor/modelo_detector/labels.txt
```
En el panel, modo **Objetos**, cambia **Modelo** a **instrumental**. La primera vez tarda unos minutos (TensorRT lo optimiza).

En tu PC también funciona sin Jetson: el panel usa OpenCV para correr el mismo `.onnx` (más lento, útil para probar).

## Paso 6. Usarlo en una receta de conteo
`receta_conteo.json` trae un ejemplo. El paso `contar` revisa que haya exactamente lo esperado:
```json
{
  "tipo": "contar",
  "zona": "bandeja",
  "esperado": {"Pinza Kelly": 2, "Tijera Mayo": 1, "Porta agujas": 1},
  "estricto": true,
  "texto": "Coloque el instrumental en la bandeja"
}
```
- `esperado`: cuántos de cada instrumento. Los nombres deben ser iguales a los de `labels.txt` (mayúsculas y acentos no importan).
- `zona` (opcional): solo cuenta lo que está dentro de esa zona de la receta.
- `estricto`: si es `true`, también avisa si hay algo que no debería estar.
- Solo cuenta cuando no hay manos moviéndose, y pide 3 conteos seguidos correctos antes de avanzar.
- En voz dice lo que falta o sobra: "Falta: 1 Pinza Kelly. Sobra: 1 Tijera Mayo."

Para un solo objeto hay un atajo:
```json
{"tipo": "detectar", "objeto": "tijeras", "cantidad": 1, "texto": "Coloque las tijeras en la mesa"}
```
Con el modelo general, los nombres van en español: `tijeras`, `botella`, `taza`, `celular`, `libro`…

Para usar la receta:
```bash
python3 panel.py --receta receta_conteo.json
```
o elígela en el panel, modo Asesor.

---

## Problemas comunes
| Problema | Solución |
|---|---|
| No detecta nada con el modelo instrumental | Baja la **Confianza mínima** a 0.3 en el panel para ver si el modelo "casi" los ve; si sí, faltan fotos |
| Confunde dos instrumentos | Más fotos donde aparezcan los dos juntos; revisa que estén bien etiquetados |
| Detecta la mano como instrumento | Agrega fotos con manos sosteniendo instrumentos, etiquetando solo los instrumentos |
| Funciona en el día y falla en la noche | Toma fotos con esa luz y vuelve a entrenar |
| Tarda mucho en arrancar | Es normal solo la primera vez (TensorRT). Si pasa siempre, revisa que la carpeta permita escribir el archivo `.engine` |
