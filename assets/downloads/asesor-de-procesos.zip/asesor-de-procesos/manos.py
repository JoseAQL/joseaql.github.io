#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
manos.py - Deteccion de manos con MediaPipe (21 puntos por mano) y efectos "entre los dedos".
Lo usan dedos.py (webcam en la PC) y panel.py (modo Dedos, proyectado sobre la mesa).
Funciona con la API vieja de MediaPipe (mp.solutions) o con la nueva (Tasks); si hace falta,
descarga solo el modelo hand_landmarker.task.
"""
from __future__ import print_function

import os
import time

import numpy as np
import cv2

BASE = os.path.dirname(os.path.abspath(__file__))
URL_MODELO = ("https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
              "hand_landmarker/float16/1/hand_landmarker.task")

# Puntos de MediaPipe: 0 muñeca, 4 punta pulgar, 8 punta indice, 12 medio, 16 anular, 20 meñique
PULGAR, INDICE = 4, 8
PUNTAS = (4, 8, 12, 16, 20)
CONEXIONES = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10), (10, 11),
              (11, 12), (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]

EFECTOS = ["termico", "pixel", "invertir", "bordes", "neon"]
NOMBRES_EFECTOS = {"termico": "Termico", "pixel": "Pixelado", "invertir": "Invertido",
                   "bordes": "Bordes", "neon": "Neon"}


class DetectorManos(object):
    def __init__(self, max_manos=2, confianza=0.6):
        self.ok, self.error, self.api = False, "", None
        try:
            import mediapipe as mp
        except ImportError:
            self.error = "Falta MediaPipe: python3 -m pip install mediapipe"
            return
        self.mp = mp
        sol = getattr(mp, "solutions", None)
        if sol is not None and hasattr(sol, "hands"):
            self.h = sol.hands.Hands(static_image_mode=False, max_num_hands=max_manos, model_complexity=0,
                                     min_detection_confidence=confianza, min_tracking_confidence=0.5)
            self.api, self.ok = "solutions", True
            return
        try:
            from mediapipe.tasks import python as mpt
            from mediapipe.tasks.python import vision
            modelo = os.path.join(BASE, "modelos_mp", "hand_landmarker.task")
            if not os.path.exists(modelo):
                os.makedirs(os.path.dirname(modelo), exist_ok=True)
                from urllib.request import urlretrieve
                print("Descargando modelo de manos de MediaPipe...")
                urlretrieve(URL_MODELO, modelo)
            opciones = vision.HandLandmarkerOptions(
                base_options=mpt.BaseOptions(model_asset_path=modelo),
                running_mode=vision.RunningMode.VIDEO, num_hands=max_manos,
                min_hand_detection_confidence=confianza, min_tracking_confidence=0.5)
            self.h = vision.HandLandmarker.create_from_options(opciones)
            self.t0, self.ts = time.time(), -1
            self.api, self.ok = "tasks", True
        except Exception as e:
            self.error = "No se pudo iniciar MediaPipe: %s" % e

    def detectar(self, bgr):
        """Regresa una lista de manos; cada mano es un arreglo (21, 2) en pixeles de la imagen."""
        if not self.ok:
            return []
        h, w = bgr.shape[:2]
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        if self.api == "solutions":
            r = self.h.process(rgb)
            lista = [lm.landmark for lm in (r.multi_hand_landmarks or [])]
        else:
            ts = max(self.ts + 1, int((time.time() - self.t0) * 1000))
            self.ts = ts
            img = self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=rgb)
            lista = self.h.detect_for_video(img, ts).hand_landmarks
        return [np.array([[p.x * w, p.y * h] for p in lm], np.float32) for lm in lista]


def aplicar_efecto(img, nombre):
    if nombre == "termico":
        g = cv2.equalizeHist(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
        return cv2.applyColorMap(g, getattr(cv2, "COLORMAP_TURBO", cv2.COLORMAP_JET))
    if nombre == "pixel":
        h, w = img.shape[:2]
        chico = cv2.resize(img, (max(1, w // 18), max(1, h // 18)), interpolation=cv2.INTER_AREA)
        return cv2.resize(chico, (w, h), interpolation=cv2.INTER_NEAREST)
    if nombre == "invertir":
        return 255 - img
    if nombre == "bordes":
        b = cv2.Canny(cv2.GaussianBlur(img, (5, 5), 0), 50, 130)
        out = np.zeros_like(img)
        out[b > 0] = (80, 255, 80)
        return out
    if nombre == "neon":
        b = cv2.dilate(cv2.Canny(cv2.GaussianBlur(img, (5, 5), 0), 40, 110), np.ones((3, 3), np.uint8))
        brillo = cv2.GaussianBlur(b, (0, 0), 6)
        out = (img * 0.25).astype(np.uint8)
        out[..., 0] = np.clip(out[..., 0] + brillo, 0, 255)
        out[..., 2] = np.clip(out[..., 2] + (brillo * 0.6).astype(np.uint8), 0, 255)
        out[b > 0] = (255, 120, 255)
        return out
    return img


def cuadro_dedos(manos):
    """Con dos manos: poligono con puntas de pulgar e indice de cada una (como en el video)."""
    if len(manos) < 2:
        return None
    utiles = [m for m in manos if not np.isnan(m[[0, PULGAR, INDICE]]).any()]
    if len(utiles) < 2:
        return None
    a, b = sorted(utiles[:2], key=lambda m: m[0][0])
    pts = np.array([a[PULGAR], a[INDICE], b[INDICE], b[PULGAR]], np.float32)
    return cv2.convexHull(pts.astype(np.int32))


def dibujar_manos(img, manos, escala=1.0):
    gro = max(1, int(round(2 * escala)))
    for m in manos:
        vis = ~np.isnan(m[:, 0])
        p = np.nan_to_num(m).astype(np.int32)
        for i, j in CONEXIONES:
            if vis[i] and vis[j]:
                cv2.line(img, tuple(int(v) for v in p[i]), tuple(int(v) for v in p[j]), (90, 230, 90), gro, cv2.LINE_AA)
        for k, q in enumerate(p):
            if vis[k]:
                r = int(round((7 if k in PUNTAS else 4) * escala))
                cv2.circle(img, tuple(int(v) for v in q), r, (40, 60, 255) if k in PUNTAS else (90, 230, 90), -1,
                           cv2.LINE_AA)


def componer(fondo, manos, efecto, fuente=None, esqueleto=True, escala=1.0):
    """Pone el efecto solo dentro del cuadro formado por los dedos.
    fondo: imagen donde se dibuja; fuente: imagen a la que se aplica el efecto (por defecto el fondo)."""
    fuente = fondo if fuente is None else fuente
    out = fondo.copy()
    quad = cuadro_dedos(manos)
    if quad is not None:
        mascara = np.zeros(fondo.shape[:2], np.uint8)
        cv2.fillConvexPoly(mascara, quad, 255)
        efx = aplicar_efecto(fuente, efecto)
        out[mascara > 0] = efx[mascara > 0]
        cv2.polylines(out, [quad], True, (255, 255, 255), max(1, int(round(2 * escala))), cv2.LINE_AA)
    if esqueleto:
        dibujar_manos(out, manos, escala)
    return out, quad
