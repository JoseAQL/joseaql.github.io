#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
vision.py - Vision del Asesor: manos (21 puntos), gestos, deteccion de objetos y envio OSC.

Elige solo el mejor motor disponible:
  Manos:    poseNet 'resnet18-hand' de jetson-inference (Jetson, TensorRT)  ->  MediaPipe (PC)
  Objetos:  detectNet de jetson-inference (Jetson)  ->  OpenCV DNN con el ONNX entrenado (PC)
Todo regresa coordenadas en pixeles de la imagen de camara.
Compatible con Python 3.6+.
"""
from __future__ import print_function

import math
import os
import socket
import struct
import time

import numpy as np
import cv2

BASE = os.path.dirname(os.path.abspath(__file__))

try:  # jetson-inference (solo en Jetson, ver instalar_vision.sh)
    from jetson_inference import poseNet, detectNet
    from jetson_utils import cudaFromNumpy
    HAY_JETSON = True
except Exception:
    HAY_JETSON = False

MUNECA, PULGAR, INDICE, MEDIO, ANULAR, MENIQUE = 0, 4, 8, 12, 16, 20
PUNTAS = (4, 8, 12, 16, 20)


# ------------------------------------------------------------------ Manos
class Manos(object):
    """detectar(bgr) -> lista de arreglos (21, 2); puntos que no se vieron quedan en NaN."""

    def __init__(self, preferir="auto", umbral=0.15):
        self.ok, self.motor, self.error = False, "ninguno", ""
        if HAY_JETSON and preferir in ("auto", "posenet"):
            try:
                self.net = poseNet("resnet18-hand", threshold=umbral)
                self.motor, self.ok = "poseNet", True
                return
            except Exception as e:
                self.error = "poseNet: %s" % e
        if preferir in ("auto", "mediapipe"):
            try:
                import manos as M
                self.mp = M.DetectorManos()
                if self.mp.ok:
                    self.motor, self.ok = "MediaPipe", True
                    return
                self.error = self.mp.error
            except Exception as e:
                self.error = "MediaPipe: %s" % e
        if not self.error:
            self.error = "No hay detector de manos: instala jetson-inference (Jetson) o mediapipe (PC)"

    def detectar(self, bgr):
        if not self.ok:
            return []
        if self.motor == "MediaPipe":
            return self.mp.detectar(bgr)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        img = cudaFromNumpy(rgb)
        res = []
        for pose in self.net.Process(img, overlay="none"):
            pts = np.full((21, 2), np.nan, np.float32)
            for kp in pose.Keypoints:
                if 0 <= kp.ID < 21:
                    pts[kp.ID] = (kp.x, kp.y)
            if np.count_nonzero(~np.isnan(pts[:, 0])) >= 6:
                res.append(pts)
        return res


def completa(mano, idx):
    return all(not np.isnan(mano[i][0]) for i in idx)


# ------------------------------------------------------------------ Gestos
GESTOS = ["palma", "puno", "pellizco", "pulgar", "apuntar"]
NOMBRES_GESTOS = {"palma": "Palma abierta", "puno": "Puño", "pellizco": "Pellizco",
                  "pulgar": "Pulgar arriba", "apuntar": "Apuntar", "": "—"}


def _d(a, b):
    return float(math.hypot(a[0] - b[0], a[1] - b[1]))


def clasificar_gesto(m):
    """Gesto instantaneo de una mano (arreglo 21x2)."""
    if not completa(m, (0, 4, 8, 9)):
        return ""
    escala = max(1.0, _d(m[MUNECA], m[9]))
    if _d(m[PULGAR], m[INDICE]) < 0.32 * escala:
        return "pellizco"
    ext = {}
    for punta, pip in ((8, 6), (12, 10), (16, 14), (20, 18)):
        if completa(m, (punta, pip)):
            ext[punta] = _d(m[MUNECA], m[punta]) > 1.12 * _d(m[MUNECA], m[pip])
    pulgar_ext = completa(m, (4, 2, 17)) and _d(m[4], m[17]) > 1.25 * _d(m[2], m[17])
    if len(ext) < 3:
        return ""
    abiertos = sum(ext.values())
    if abiertos >= 4 and pulgar_ext:
        return "palma"
    if ext.get(8) and abiertos == 1:
        return "apuntar"
    if abiertos == 0:
        return "pulgar" if pulgar_ext else "puno"
    return ""


class Gestos(object):
    """Suaviza gestos: uno cuenta solo si se mantiene 'estable_s'. Da eventos al iniciar y al sostener."""

    def __init__(self, estable_s=0.25):
        self.estable_s = estable_s
        self.actual, self.cand, self.t_cand, self.t_ini = "", "", 0.0, 0.0
        self.disparados = set()

    def actualizar(self, gesto, ahora):
        """Regresa (gesto_estable, segundos_sostenido, es_nuevo)."""
        nuevo = False
        if gesto != self.cand:
            self.cand, self.t_cand = gesto, ahora
        if self.cand != self.actual and ahora - self.t_cand >= self.estable_s:
            self.actual, self.t_ini, nuevo = self.cand, ahora, True
            self.disparados = set()
        return self.actual, (ahora - self.t_ini if self.actual else 0.0), nuevo

    def una_vez(self, clave):
        """True solo la primera vez que se pide 'clave' mientras dura el gesto actual."""
        if clave in self.disparados:
            return False
        self.disparados.add(clave)
        return True


# ------------------------------------------------------------------ Objetos
# Clases COCO del modelo general de detectNet (ssd-mobilenet-v2), en español para mostrar
COCO_ES = {"person": "persona", "bottle": "botella", "cup": "taza", "scissors": "tijeras", "cell phone": "celular",
           "keyboard": "teclado", "mouse": "mouse", "book": "libro", "laptop": "laptop", "knife": "cuchillo",
           "spoon": "cuchara", "fork": "tenedor", "bowl": "tazón", "clock": "reloj", "remote": "control",
           "toothbrush": "cepillo", "vase": "florero", "wine glass": "copa", "banana": "plátano", "apple": "manzana",
           "orange": "naranja", "chair": "silla", "backpack": "mochila", "handbag": "bolsa", "umbrella": "paraguas",
           "teddy bear": "peluche", "hair drier": "secadora", "tv": "pantalla", "sports ball": "pelota"}


class Objetos(object):
    """modelo='general'  -> ssd-mobilenet-v2 (90 objetos COCO, solo en Jetson)
       modelo='carpeta'  -> ONNX entrenado con train_ssd.py (ssd-mobilenet.onnx + labels.txt)"""

    def __init__(self, modelo="general", carpeta="modelo_detector", umbral=0.5):
        self.ok, self.motor, self.error = False, "ninguno", ""
        self.umbral, self.modelo = umbral, modelo
        self.etiquetas = []
        if modelo == "general":
            if HAY_JETSON:
                try:
                    self.net = detectNet("ssd-mobilenet-v2", threshold=umbral)
                    self.motor, self.ok = "detectNet", True
                except Exception as e:
                    self.error = "detectNet: %s" % e
            else:
                self.error = "El modelo general necesita jetson-inference (solo en la Jetson)"
            return
        carp = carpeta if os.path.isabs(carpeta) else os.path.join(BASE, carpeta)
        onnx = os.path.join(carp, "ssd-mobilenet.onnx")
        lab = os.path.join(carp, "labels.txt")
        if not (os.path.exists(onnx) and os.path.exists(lab)):
            self.error = "Falta %s o labels.txt (ver GUIA_DETECTOR.md)" % onnx
            return
        with open(lab, encoding="utf-8") as f:
            self.etiquetas = [l.strip() for l in f if l.strip()]
        if HAY_JETSON:
            try:
                self.net = detectNet(argv=["--model=" + onnx, "--labels=" + lab, "--input-blob=input_0",
                                           "--output-cvg=scores", "--output-bbox=boxes"], threshold=umbral)
                self.motor, self.ok = "detectNet", True
                return
            except Exception as e:
                self.error = "detectNet: %s" % e
        try:
            self.dnn = cv2.dnn.readNetFromONNX(onnx)
            self.motor, self.ok, self.error = "OpenCV DNN", True, ""
        except Exception as e:
            self.error = "OpenCV DNN: %s" % e

    def nombre(self, clase):
        return COCO_ES.get(clase, clase) if self.modelo == "general" else clase

    def detectar(self, bgr):
        """Lista de (clase, confianza, x1, y1, x2, y2) en pixeles."""
        if not self.ok:
            return []
        if self.motor == "detectNet":
            img = cudaFromNumpy(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
            out = []
            for d in self.net.Detect(img, overlay="none"):
                clase = self.net.GetClassDesc(d.ClassID)
                if clase.upper() == "BACKGROUND":
                    continue
                out.append((self.nombre(clase), float(d.Confidence), d.Left, d.Top, d.Right, d.Bottom))
            return out
        return self._dnn(bgr)

    def _dnn(self, bgr):
        h, w = bgr.shape[:2]
        x = cv2.resize(bgr, (300, 300))
        x = cv2.cvtColor(x, cv2.COLOR_BGR2RGB).astype(np.float32)
        x = ((x - 127.0) / 128.0).transpose(2, 0, 1)[None]
        self.dnn.setInput(x)
        nombres = self.dnn.getUnconnectedOutLayersNames()
        salidas = dict(zip(nombres, self.dnn.forward(nombres)))
        scores = salidas.get("scores", list(salidas.values())[0])[0]
        boxes = salidas.get("boxes", list(salidas.values())[1])[0]
        out = []
        for c in range(1, scores.shape[1]):  # 0 = fondo
            idx = np.where(scores[:, c] > self.umbral)[0]
            if not len(idx):
                continue
            bb = boxes[idx] * np.array([w, h, w, h], np.float32)
            rects = [[float(b[0]), float(b[1]), float(b[2] - b[0]), float(b[3] - b[1])] for b in bb]
            keep = cv2.dnn.NMSBoxes(rects, scores[idx, c].tolist(), self.umbral, 0.45)
            for k in np.array(keep).flatten():
                b = bb[k]
                nombre = self.etiquetas[c] if c < len(self.etiquetas) else str(c)
                out.append((nombre, float(scores[idx[k], c]), float(b[0]), float(b[1]), float(b[2]), float(b[3])))
        return out


def contar(detecciones):
    cuenta = {}
    for d in detecciones:
        cuenta[d[0]] = cuenta.get(d[0], 0) + 1
    return cuenta


# ------------------------------------------------------------------ OSC (para TouchDesigner)
def _osc_str(s):
    b = s.encode("utf-8") + b"\x00"
    return b + b"\x00" * ((4 - len(b) % 4) % 4)


def mensaje_osc(direccion, *args):
    tags, datos = ",", b""
    for a in args:
        if isinstance(a, float):
            tags += "f"
            datos += struct.pack(">f", a)
        elif isinstance(a, int):
            tags += "i"
            datos += struct.pack(">i", a)
        else:
            tags += "s"
            datos += _osc_str(str(a))
    return _osc_str(direccion) + _osc_str(tags) + datos


class EmisorOSC(object):
    """Manda por UDP en formato OSC. En TouchDesigner: OSC In CHOP (numeros) y OSC In DAT (textos).
    Direcciones:  /manos/n  (cantidad)   /mano/<i>/p<k>  x y   (0..1 sobre la mesa)
                  /mano/<i>/gesto  texto   /objetos/<clase>  cantidad   /modo  texto"""

    def __init__(self, host="127.0.0.1", puerto=7000):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.destino = (host, int(puerto))
        self.enviados = 0

    def enviar(self, direccion, *args):
        try:
            self.sock.sendto(mensaje_osc(direccion, *args), self.destino)
            self.enviados += 1
        except Exception:
            pass
