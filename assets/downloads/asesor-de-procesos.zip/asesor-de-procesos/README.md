# Asesor de procesos (Jetson)

Estación de guiado por proyección. Proyecta sobre la mesa los pasos de una **receta** (ensamble, charola por lugares o conteo de instrumental), revisa con la cámara que cada paso se haya hecho y avisa con voz y colores. Se controla con la mano, la voz o el teclado, y también desde un **panel web**.

Toda la explicación (modos, controles, instalación y archivos) está en **[LEEME.md](LEEME.md)**.

## Versiones

| Versión | Qué tiene |
|---|---|
| **v1 (vigente)** | `asesor.py` (motor de recetas), `panel.py` + `panel.html` (menú proyectado y panel web), `vision.py` y `manos.py` (manos y objetos), captura y entrenamiento de la charola, detector de instrumental y recetas de ejemplo. |

Cuando haya una versión nueva de un programa, se guarda con su número en esta misma carpeta (por ejemplo `asesor_v2.py`) y se agrega una fila aquí.

> La IA de voz ("oye asesor") se hizo en otra conversación y su código no está aquí. Si me pasas esos archivos, entran como siguiente versión.

## Guías

- [LEEME.md](LEEME.md): instalación, modos y controles.
- [GUIA_ENTRENAMIENTO.md](GUIA_ENTRENAMIENTO.md): entrenar la charola por lugares con Teachable Machine.
- [GUIA_DETECTOR.md](GUIA_DETECTOR.md): detector de objetos y de tu instrumental quirúrgico.

## Archivos principales

| Archivo | Para qué |
|---|---|
| `panel.py`, `panel.html` | Programa principal: arranque, menú proyectado, modos y panel web |
| `asesor.py` | Motor de la receta (también corre solo) |
| `vision.py`, `manos.py`, `dedos.py` | Manos, gestos y objetos |
| `captura_charola.py`, `preparar_voc.py` | Fotos y dataset para entrenar |
| `receta*.json`, `config.json` | Recetas de ejemplo y configuración |
| `marcadores_mesa.png` | Marcadores para calibrar la mesa |
| `instalar.sh`, `instalar_vision.sh`, `iniciar.sh` | Instalación y arranque |
