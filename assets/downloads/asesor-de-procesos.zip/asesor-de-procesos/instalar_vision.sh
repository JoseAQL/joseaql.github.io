#!/bin/bash
# Instala jetson-inference de NVIDIA en la Jetson:
#   poseNet 'resnet18-hand'  -> manos (21 puntos) para gestos, dedos, esqueleto, particulas, pizarra
#   detectNet                -> objetos e instrumental
# En la Jetson Nano tarda entre 30 y 90 minutos. Dejala conectada a la corriente.
# Uso:  bash instalar_vision.sh
set -e
echo "=== 1/5 Paquetes"
sudo apt-get update
sudo apt-get install -y git cmake libpython3-dev python3-numpy

echo "=== 2/5 Memoria de intercambio (la Nano se queda sin RAM al compilar)"
SWAP_MB=$(free -m | awk '/Swap/ {print $2}')
if [ "${SWAP_MB:-0}" -lt 3000 ] && [ ! -f /mnt/4GB.swap ]; then
  sudo fallocate -l 4G /mnt/4GB.swap
  sudo chmod 600 /mnt/4GB.swap
  sudo mkswap /mnt/4GB.swap
  sudo swapon /mnt/4GB.swap
  grep -q "/mnt/4GB.swap" /etc/fstab || echo "/mnt/4GB.swap  none  swap  sw 0  0" | sudo tee -a /etc/fstab
fi

echo "=== 3/5 Descargar jetson-inference"
cd ~
if [ ! -d jetson-inference ]; then
  git clone --recursive --depth=1 https://github.com/dusty-nv/jetson-inference
fi
cd jetson-inference
git submodule update --init

echo "=== 4/5 Compilar (si aparece un menu de modelos o de PyTorch, puedes aceptar lo que trae marcado;"
echo "          PyTorch solo hace falta si vas a ENTRENAR el detector dentro de la Jetson)"
mkdir -p build && cd build
cmake ../
make -j"$(nproc)"
sudo make install
sudo ldconfig

echo "=== 5/5 Prueba"
python3 -c "from jetson_inference import poseNet, detectNet; print('jetson-inference OK')"
echo
echo "Listo. Los modelos resnet18-hand y ssd-mobilenet-v2 se descargan solos la primera vez que se usan."
echo "La primera vez que corre cada modelo, TensorRT tarda unos minutos en optimizarlo; despues arranca rapido."
echo "Reinicia el panel:  python3 ~/asesor/panel.py"
