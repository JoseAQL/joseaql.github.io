# Asesor de Procesos

Estación de guiado por proyección para Jetson. Arranca **como una consola retro**: prendes la Jetson, aparece la pantalla de inicio y después un **menú proyectado sobre la mesa** con 14 modos que eliges con la mano, la voz o el teclado. Todo se controla y ajusta también desde un **panel web estilo TouchDesigner**.

## Los 14 modos

| # | Modo | Qué hace |
|---|---|---|
| 1 | **Asesor** | La receta completa: pasos, voz, botones proyectados, torque y validaciones |
| 2 | **Calibración** | Calibra cámara y proyector con los marcadores |
| 3 | **Patrones** | Rejilla en mm, puntero y rectángulos para armar recetas |
| 4 | **Zonas** | Ocupación en vivo de zonas y botones, para ajustar umbrales |
| 5 | **Guante** | Ajusta el color del guante |
| 6 | **Clasificador** | Prueba el modelo de Teachable Machine en la charola |
| 7 | **Captura** | Toma fotos para entrenar (lugares de la charola o mesa completa) |
| 8 | **Gestos** | Prueba palma, pellizco, pulgar y puño |
| 9 | **Esqueleto** | Manos de neón con estelas en las puntas de los dedos |
| 10 | **Dedos** | Efecto dentro del cuadro entre pulgar e índice de las dos manos |
| 11 | **Partículas** | Miles de partículas que siguen, esquivan u orbitan tus dedos; pellizco = explosión |
| 12 | **Pizarra** | Dibuja en la mesa pellizcando |
| 13 | **Reactivo** | La luz sigue cualquier movimiento |
| 14 | **Objetos** | Detecta y cuenta objetos o tu instrumental quirúrgico |

## Cómo se controla

| Acción | Con la mano | Con la voz | Teclado en la Jetson |
|---|---|---|---|
| Elegir un modo en el menú | Pellizco o mano quieta 1.5 s sobre el recuadro | Decir su nombre: "partículas" | Flechas + Enter, o 1–9 |
| Volver al menú | Puño cerrado 1.5 s | "menú" | M o Esc |
| Iniciar la receta | Palma abierta 1 s | "iniciar" | I |
| Siguiente paso | Pulgar arriba, o pellizco sobre SIGUIENTE | "siguiente" / "listo" | N |
| Repetir instrucción | Pellizco sobre REPETIR | "repetir" | R |
| Salir del programa | | | Q |

En el modo Asesor el puño **no** regresa al menú (para que no se active al agarrar herramientas); usa la voz, la tecla M o el panel.

---

## Instalación

### 1. Pasar la carpeta a la Jetson
En MobaXterm, arrastra la carpeta `asesor` al panel SFTP de la izquierda (a `/home/TU_USUARIO/`). En la terminal:
```bash
cd ~/asesor
bash instalar.sh          # sistema, voz, OpenCV, arranque automático (unos minutos)
bash instalar_vision.sh   # manos y objetos con NVIDIA jetson-inference (30 a 90 minutos)
```
Sin `instalar_vision.sh` todo funciona excepto los modos que necesitan ver las manos o los objetos (en su lugar, el menú y la pizarra siguen la mano por el color del guante).

### 2. Marcadores de la mesa
```bash
python3 asesor.py --imprimir
```
Descarga `marcadores_mesa.png` por SFTP, imprímelo al 100 % y pega los 4 marcadores en las esquinas del área de trabajo, **viendo la mesa desde el lado del operario**:
```
   ID 40 ─────────────────── ID 41      ← lado lejano
     │          MESA            │
   ID 43 ─────────────────── ID 42      ← lado del operario
```
Mide en milímetros la distancia **entre los centros**: 40 → 41 = `ancho_mm`, 40 → 43 = `alto_mm`, y ponlas en `config.json` → `mesa`. Las posiciones de las recetas se miden desde el centro del marcador 40 (X a la derecha, Y hacia el operario).

### 3. Ajustar config.json
- `camara.tipo`: `"usb"` o `"csi"`; `indice`: normalmente 0 (`ls /dev/video*`).
- `proyector.ancho/alto`: resolución real (`DISPLAY=:0 xrandr | grep '*'`).

### 4. Primera prueba
```bash
python3 panel.py
```
Verás la pantalla de arranque en el proyector. Como aún no hay calibración, entra al modo Calibración: abre el panel web (siguiente sección) y presiona **Calibrar**. Luego di "menú" o presiona M.

### 5. Arranque automático
`instalar.sh` ya lo dejó: la Jetson inicia sesión sola y corre `iniciar.sh`, que abre la pantalla retro y el menú. Reinicia con `sudo reboot`. El log queda en `registros/asesor.log`.
- **Modo con el que arranca:** en el panel web, modo Menú → *Modo al encender* (por ejemplo, directo a Asesor).
- **Sin pantalla retro:** desmarca *Pantalla de arranque retro*.
- **Asesor clásico sin menú:** `./iniciar.sh --clasico`.

---

## Panel web (estilo TouchDesigner)
Mientras corre `panel.py`, abre en tu PC o celular: **`http://IP-DE-LA-JETSON:8080`** (con Tailscale, la IP 100.x de la Jetson).

- Red de operadores: `camara1 → vistaMesa1 → mascara1 → zonas1 → receta1 → proyector1`, más `manos1`, `clasificador1`, `objetos1`, `torque1`, `voz1` y `osc1`, cada uno con vista en vivo. Los nodos se arrastran.
- Clic en un nodo: sus parámetros con sliders, aplicados en vivo. **Guardar en config.json** los deja fijos.
- **Mapa de la mesa**: en Patrones, toca para poner un puntero o arrastra para dibujar un rectángulo; las medidas salen listas para pegar en la receta.
- **Simulación sin hardware:** `python3 panel.py --simular` crea una mesa virtual que se calibra sola; arrastra sobre el mapa para mover una mano con guante.
- No uses `panel.py` y `asesor.py` al mismo tiempo (los dos usan la cámara y el proyector).
- El panel no tiene contraseña: ábrelo solo por Tailscale o en tu red local.

## Conectar con TouchDesigner (OSC)
La Jetson detecta y tu PC hace los efectos pesados.
1. En el panel web, nodo **osc1**: activa *Enviar OSC*, escribe la **IP de tu PC** (la de Tailscale sirve) y el puerto (7000).
2. En TouchDesigner agrega un **OSC In CHOP** con *Network Port* 7000 (y un **OSC In DAT** si quieres los textos de gestos).

Lo que llega (coordenadas de 0 a 1 sobre la mesa):

| Dirección | Valores |
|---|---|
| `/manos/n` | cuántas manos se ven |
| `/mano/0/p8` | x y de la punta del índice de la mano 0 (p0 muñeca, p4 pulgar, p8 índice, p12 medio, p16 anular, p20 meñique) |
| `/mano/0/gesto` | palma, puno, pellizco, pulgar, apuntar |
| `/puntero` | x y del índice (o de la mano por color de guante) |
| `/objetos/<clase>` | cuántos hay de cada objeto |
| `/modo` | modo actual |

## Detectores: qué usa cada equipo
| | Jetson (con `instalar_vision.sh`) | PC |
|---|---|---|
| Manos (21 puntos) | poseNet `resnet18-hand` de NVIDIA, con TensorRT | MediaPipe |
| Objetos | detectNet (general de 90 objetos, o tu modelo) | OpenCV con tu `.onnx` (solo modelo propio) |

El programa elige solo. En el panel, nodo **manos1** → *Detector de manos*, puedes forzarlo.

---

## Recetas
Tipos de paso:

| tipo | Qué espera | Campos útiles |
|---|---|---|
| `presencia` | Que haya algo en la zona 1.5 s | `zona`, `umbral`, `segundos` |
| `pick` | Mano en la gaveta correcta (error si entra a otra `gaveta_*`) | `zona`, `umbral` |
| `confirmar` | SIGUIENTE (mano, pulgar o voz) | `marca` opcional |
| `torque` | Valor recibido dentro de `min`–`max` | `marca`, `min`, `max`, `unidad` |
| `espera` | Pasan N segundos | `segundos` |
| `charola` | Cada lugar tiene su instrumento (Teachable Machine) | ver `GUIA_ENTRENAMIENTO.md` |
| `contar` | Cantidades exactas de objetos o instrumental | `esperado`, `zona`, `estricto` — ver `GUIA_DETECTOR.md` |
| `detectar` | Un objeto en la mesa | `objeto`, `cantidad` |

Todos aceptan `texto` (lo que se proyecta), `voz` (lo que se dice) y `ayuda`. Ejemplos: `receta.json` (ensamble), `receta_charola.json` (charola por lugares), `receta_conteo.json` (conteo de instrumental).

## Guías
- **`GUIA_ENTRENAMIENTO.md`** — charola por lugares con Teachable Machine.
- **`GUIA_DETECTOR.md`** — detector de objetos y de tu instrumental quirúrgico.

## Archivos
| Archivo | Para qué |
|---|---|
| `panel.py` + `panel.html` | Programa principal: arranque retro, menú, 14 modos y panel web |
| `asesor.py` | Motor de la receta (también corre solo, sin menú) |
| `vision.py` | Manos, gestos, objetos y OSC |
| `manos.py` | MediaPipe y efectos entre los dedos |
| `dedos.py` | Efecto entre los dedos con la webcam de tu PC |
| `captura_charola.py` | Fotos para Teachable Machine desde la terminal |
| `preparar_voc.py` | Ordena un dataset etiquetado para entrenar el detector |
| `config.json` | Cámara, proyector, mesa, voz, torque, detectores, OSC |
| `receta*.json` | Recetas de ejemplo |
| `instalar.sh` / `instalar_vision.sh` | Instaladores |
| `iniciar.sh` | Lo que corre al encender |
| `modelo/` | Modelo de Teachable Machine (`.tflite` + `labels.txt`) |
| `modelo_detector/` | Tu detector de instrumental (`ssd-mobilenet.onnx` + `labels.txt`) |
| `dataset/`, `dataset_detector/` | Fotos capturadas |
| `registros/` | `ensambles.csv`, `asesor.log`, imágenes de depuración |

## Otros
- **Torque sin torquímetro:** `python3 -c "import socket;s=socket.create_connection(('localhost',5005));s.sendall(b'18.5\n')"`, o el nodo torque1 del panel. Un torquímetro o PLC real manda el valor por TCP (5005) o serial (`torque.serial_puerto`).
- **Micrófono:** si no es el predeterminado, búscalo con `arecord -L` y ponlo en `comandos_voz.dispositivo_mic` (p. ej. `plughw:1,0`).
- **Voz más natural:** instala Piper en `~/piper/` con un modelo en español (p. ej. `es_MX-ald-medium.onnx`) y se usa solo.
- **Efecto de dedos en tu PC:** `python3 -m pip install mediapipe opencv-python` y `python3 dedos.py` (teclas 1–5 efectos, F pantalla completa, Q salir).

## Problemas comunes
- **"tu OpenCV no trae ArUco"**: `python3 -m pip install --user opencv-contrib-python==4.5.5.64`. Con cámara **CSI** ese OpenCV de pip no trae GStreamer; usa cámara USB o compila OpenCV con contrib.
- **No ve los marcadores**: revisa `registros/calib_fallo_mesa.jpg` (enfoque, reflejos, que no estén tapados).
- **No ve el patrón proyectado**: baja la luz del cuarto, enfoca el proyector; revisa `registros/calib_fallo_patron.jpg`.
- **Botones o menú se activan solos**: sube *Umbral de diferencia* en el nodo zonas1.
- **La cámara cambia de brillo sola**: fija la exposición, p. ej. `v4l2-ctl -d /dev/video0 -c exposure_auto=1 -c exposure_absolute=200`.
- **Gestos poco estables**: mejor luz sobre las manos; los guantes muy brillantes o blancos cuestan más.
- **Primer arranque de Objetos o Manos muy lento**: normal solo la primera vez (TensorRT optimiza los modelos).
