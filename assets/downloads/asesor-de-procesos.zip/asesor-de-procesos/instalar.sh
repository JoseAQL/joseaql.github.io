#!/bin/bash
# Instalador del Asesor de Procesos para Jetson (JetPack 4.x / 5.x / 6.x)
# Uso:  bash instalar.sh
DIR="$(cd "$(dirname "$0")" && pwd)"
USUARIO="$(whoami)"
echo "=== Carpeta del proyecto: $DIR  (usuario: $USUARIO)"

echo "=== 1/6 Paquetes del sistema"
sudo apt-get update
sudo apt-get install -y python3-pip python3-numpy python3-pil python3-serial \
     espeak-ng alsa-utils unclutter x11-xserver-utils v4l-utils wget unzip fonts-dejavu-core

echo "=== 2/6 OpenCV con ArUco"
if python3 -c "import cv2; cv2.aruco" 2>/dev/null; then
  echo "OK: tu OpenCV ya trae ArUco"
else
  echo "Tu OpenCV no trae ArUco. Instalando opencv-contrib..."
  python3 -m pip install --user --upgrade "pip<22"
  python3 -m pip install --user "opencv-contrib-python==4.5.5.64" \
    || echo "!! No se pudo instalar opencv-contrib. Ver LEEME.md (seccion ArUco)"
fi

echo "=== 3/6 Comandos de voz (Vosk, sin internet)"
python3 -m pip install --user vosk || echo "!! Vosk no se instalo; el sistema funciona igual sin comandos de voz"
mkdir -p ~/modelos
if [ ! -d ~/modelos/vosk-model-small-es-0.42 ]; then
  wget -q --show-progress -O /tmp/vosk-es.zip https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip \
    && unzip -q /tmp/vosk-es.zip -d ~/modelos && rm /tmp/vosk-es.zip \
    || echo "!! No se pudo descargar el modelo de voz"
fi

echo "=== 3b Clasificador (TensorFlow Lite para el modelo de Teachable Machine)"
if ! python3 -c "import tflite_runtime" 2>/dev/null; then
  python3 -m pip install --user tflite-runtime \
    || echo "!! tflite-runtime no se instalo. Ver GUIA_ENTRENAMIENTO.md paso 8 (plan B)"
fi
mkdir -p "$DIR/modelo" "$DIR/dataset" "$DIR/modelo_detector" "$DIR/dataset_detector"

echo "=== 4/6 Permisos (camara, audio, puerto serial)"
sudo usermod -aG video,audio,dialout "$USUARIO"

echo "=== 5/6 Inicio de sesion automatico"
if [ -f /etc/gdm3/custom.conf ]; then
  sudo sed -i "s/^#\?\s*AutomaticLoginEnable.*/AutomaticLoginEnable=true/; s/^#\?\s*AutomaticLogin\s*=.*/AutomaticLogin=$USUARIO/" /etc/gdm3/custom.conf
  echo "OK: autologin configurado en gdm3"
else
  echo "!! No encontre gdm3. Activa 'Inicio de sesion automatico' en Configuracion > Usuarios"
fi

echo "=== 6/6 Arranque automatico del asesor"
chmod +x "$DIR/iniciar.sh"
mkdir -p ~/.config/autostart
cat > ~/.config/autostart/asesor.desktop <<EOF
[Desktop Entry]
Type=Application
Name=Asesor de Procesos
Exec=/bin/bash -c "sleep 8; $DIR/iniciar.sh"
X-GNOME-Autostart-enabled=true
EOF
echo "OK: la estacion arrancara sola al prender la Jetson (pantalla retro + menu)"

echo
echo "=== Listo. Siguientes pasos:"
echo "  1) python3 $DIR/asesor.py --imprimir     (genera marcadores_mesa.png)"
echo "  2) Imprime, pega los 4 marcadores en las esquinas y mide distancias (LEEME.md)"
echo "  3) Edita config.json (camara, proyector, medidas de mesa)"
echo "  4) Prueba:  python3 $DIR/panel.py   y abre http://IP-de-la-jetson:8080"
echo "  5) Manos y objetos (opcional, 30-90 min):  bash $DIR/instalar_vision.sh"
echo "  6) Reinicia la Jetson: sudo reboot"
