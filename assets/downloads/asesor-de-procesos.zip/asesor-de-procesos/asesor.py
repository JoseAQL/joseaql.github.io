#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ASESOR DE PROCESOS - Estacion de guiado por proyeccion (Jetson Nano / Orin)
===========================================================================
- Calibracion automatica camara-proyector con marcadores ArUco (tipo QR)
- Botones virtuales proyectados que se activan con la mano
- Instrucciones por voz (Piper o espeak-ng) y tonos OK / ERROR
- Comandos de voz sin internet (Vosk): iniciar, siguiente, repetir, ayuda, cancelar
- Receta de ensamble editable (receta.json): presencia, pick, confirmar, torque, espera, charola
- Verificacion de charola con modelo de Teachable Machine (TensorFlow Lite)
- Deteccion de guantes por color para botones y gavetas
- Lectura de torque por TCP y/o puerto serial
- Registro CSV de cada ciclo

Uso:
  python3 asesor.py                 -> arranca normal (verifica calibracion)
  python3 asesor.py --calibrar      -> fuerza calibracion
  python3 asesor.py --imprimir      -> genera marcadores_mesa.png para imprimir
  python3 asesor.py --debug         -> guarda registros/debug_vista.jpg cada segundo
Teclas (si hay teclado en la Jetson): q/ESC salir, c calibrar, i iniciar, n siguiente, r repetir
Compatible con Python 3.6+ y OpenCV 4.1+ (API ArUco vieja y nueva).
"""
from __future__ import print_function

import argparse
import csv
import glob
import json
import os
import queue
import re
import shutil
import socket
import subprocess
import sys
import textwrap
import threading
import time
import unicodedata
import wave

import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
VENTANA = "ASESOR"

BLANCO = (255, 255, 255)
GRIS = (140, 140, 140)
VERDE = (0, 220, 0)
ROJO = (0, 0, 255)
AMARILLO = (0, 220, 255)
CIAN = (255, 200, 0)
AZUL = (255, 120, 40)


def ruta(p):
    p = os.path.expanduser(p)
    return p if os.path.isabs(p) else os.path.join(BASE, p)


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a)
    sys.stdout.flush()


def cargar_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def preparar_pantalla(pantalla):
    """Manda la ventana a la pantalla de la Jetson (proyector), no a MobaXterm."""
    if pantalla:
        os.environ["DISPLAY"] = pantalla
    if "XAUTHORITY" not in os.environ:
        candidatos = ["/run/user/%d/gdm/Xauthority" % os.getuid(),
                      os.path.expanduser("~/.Xauthority")]
        for c in candidatos:
            if os.path.exists(c):
                os.environ["XAUTHORITY"] = c
                break


import cv2  # noqa: E402  (despues de definir helpers)

# ------------------------------------------------------------------ ArUco (compatibilidad)
if not hasattr(cv2, "aruco"):
    aruco = None
else:
    aruco = cv2.aruco
DICCIONARIO = 0  # DICT_4X4_50


def _diccionario():
    if hasattr(aruco, "getPredefinedDictionary"):
        return aruco.getPredefinedDictionary(DICCIONARIO)
    return aruco.Dictionary_get(DICCIONARIO)


def crear_detector():
    d = _diccionario()
    if hasattr(aruco, "ArucoDetector"):
        p = aruco.DetectorParameters()
        p.cornerRefinementMethod = aruco.CORNER_REFINE_SUBPIX
        det = aruco.ArucoDetector(d, p)
        return lambda g: det.detectMarkers(g)
    p = aruco.DetectorParameters_create()
    p.cornerRefinementMethod = aruco.CORNER_REFINE_SUBPIX
    return lambda g: aruco.detectMarkers(g, d, parameters=p)


def imagen_marcador(id_, lado):
    d = _diccionario()
    if hasattr(aruco, "generateImageMarker"):
        return aruco.generateImageMarker(d, id_, lado)
    return aruco.drawMarker(d, id_, lado)


# ------------------------------------------------------------------ Texto (con acentos si hay PIL)
try:
    from PIL import Image, ImageDraw, ImageFont
    HAY_PIL = True
except ImportError:
    HAY_PIL = False

FUENTES = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
           "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
           "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"]
FUENTES_MONO = ["/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf",
                "/usr/share/fonts/truetype/freefont/FreeMonoBold.ttf",
                "/usr/share/fonts/truetype/liberation/LiberationMono-Bold.ttf"]
_cache_fuentes = {}
_cache_txt = {}


def sin_acentos(s):
    return unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode("ascii")


def _fuente(tam, mono=False):
    if not HAY_PIL:
        return None
    clave = (tam, mono)
    if clave not in _cache_fuentes:
        f = None
        for p in (FUENTES_MONO + FUENTES if mono else FUENTES):
            if os.path.exists(p):
                f = ImageFont.truetype(p, tam)
                break
        _cache_fuentes[clave] = f
    return _cache_fuentes[clave]


def _sprite_texto(texto, tam, mono=False):
    clave = (texto, tam, mono)
    if clave in _cache_txt:
        return _cache_txt[clave]
    fnt = _fuente(tam, mono)
    if fnt is not None:
        if hasattr(fnt, "getbbox"):
            b = fnt.getbbox(texto)
            w, h = b[2], b[3]
        else:
            w, h = fnt.getsize(texto)
        im = Image.new("L", (max(1, w + 4), max(1, h + 6)), 0)
        ImageDraw.Draw(im).text((2, 0), texto, font=fnt, fill=255)
        m = np.array(im)
    else:
        t = sin_acentos(texto)
        esc = tam / 30.0
        grosor = max(1, int(tam / 14))
        (w, h), base = cv2.getTextSize(t, cv2.FONT_HERSHEY_SIMPLEX, esc, grosor)
        m = np.zeros((h + base + 6, w + 4), np.uint8)
        cv2.putText(m, t, (2, h + 2), cv2.FONT_HERSHEY_SIMPLEX, esc, 255, grosor, cv2.LINE_AA)
    if len(_cache_txt) > 400:
        _cache_txt.clear()
    _cache_txt[clave] = m
    return m


def poner_texto(img, texto, x, y, tam, color, centrado=False, mono=False):
    m = _sprite_texto(texto, int(tam), mono)
    h, w = m.shape
    if centrado:
        x, y = int(x - w / 2), int(y - h / 2)
    x, y = int(x), int(y)
    H, W = img.shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0:
        return w, h
    a = (m[y0 - y:y1 - y, x0 - x:x1 - x].astype(np.float32) / 255.0)[..., None]
    reg = img[y0:y1, x0:x1].astype(np.float32)
    img[y0:y1, x0:x1] = (reg * (1 - a) + np.array(color, np.float32) * a).astype(np.uint8)
    return w, h


def poner_parrafo(img, texto, x, y, ancho, tam, color):
    """Escribe texto con saltos de linea automaticos. Regresa la y final."""
    chars = max(8, int(ancho / (tam * 0.55)))
    for bloque in texto.split("\n"):
        for linea in textwrap.wrap(bloque, chars) or [""]:
            _, h = poner_texto(img, linea, x, y, tam, color)
            y += int(tam * 1.25)
    return y


# ------------------------------------------------------------------ Camara (hilo propio)
class Camara(object):
    def __init__(self, cfg):
        c = cfg["camara"]
        if c.get("tipo", "usb") == "csi":
            pipe = ("nvarguscamerasrc sensor-id=%d ! video/x-raw(memory:NVMM),width=%d,height=%d,"
                    "framerate=%d/1 ! nvvidconv ! video/x-raw,format=BGRx ! videoconvert ! "
                    "video/x-raw,format=BGR ! appsink drop=1 max-buffers=1"
                    % (c.get("indice", 0), c["ancho"], c["alto"], c.get("fps", 30)))
            self.cap = cv2.VideoCapture(pipe, cv2.CAP_GSTREAMER)
        else:
            self.cap = cv2.VideoCapture(c.get("indice", 0), cv2.CAP_V4L2)
            if c.get("mjpg", True):
                self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, c["ancho"])
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, c["alto"])
            self.cap.set(cv2.CAP_PROP_FPS, c.get("fps", 30))
        if not self.cap.isOpened():
            raise RuntimeError("No se pudo abrir la camara. Revisa config.json -> camara")
        self.frame, self.t = None, 0.0
        self.lock = threading.Lock()
        self.vivo = True
        th = threading.Thread(target=self._loop)
        th.daemon = True
        th.start()
        t0 = time.time()
        while self.frame is None and time.time() - t0 < 6:
            time.sleep(0.05)
        if self.frame is None:
            raise RuntimeError("La camara abrio pero no entrega imagen")
        log("Camara OK:", self.frame.shape[1], "x", self.frame.shape[0])

    def _loop(self):
        while self.vivo:
            ok, f = self.cap.read()
            if ok:
                with self.lock:
                    self.frame, self.t = f, time.time()
            else:
                time.sleep(0.01)

    def leer(self):
        with self.lock:
            return self.frame, self.t

    def leer_nuevo(self, despues_de, tope=2.0):
        t0 = time.time()
        while time.time() - t0 < tope:
            f, t = self.leer()
            if f is not None and t > despues_de:
                return f
            time.sleep(0.005)
        return self.leer()[0]

    def cerrar(self):
        self.vivo = False
        time.sleep(0.1)
        self.cap.release()


# ------------------------------------------------------------------ Proyector (ventana full screen)
class Proyector(object):
    def __init__(self, cfg):
        p = cfg["proyector"]
        self.w, self.h = int(p["ancho"]), int(p["alto"])
        cv2.namedWindow(VENTANA, cv2.WINDOW_NORMAL)
        cv2.moveWindow(VENTANA, int(p.get("offset_x", 0)), int(p.get("offset_y", 0)))
        cv2.setWindowProperty(VENTANA, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        self.mostrar(self.negro(), 50)

    def negro(self):
        return np.zeros((self.h, self.w, 3), np.uint8)

    def mostrar(self, img, espera_ms=1):
        cv2.imshow(VENTANA, img)
        k = cv2.waitKeyEx(espera_ms)  # codigo completo: tambien flechas
        return 255 if k == -1 else k

    def pausa(self, img, seg):
        t0 = time.time()
        while time.time() - t0 < seg:
            self.mostrar(img, 15)


# ------------------------------------------------------------------ Calibracion automatica
def patron_aruco(w, h, cols=5, filas=3):
    """Patron de marcadores (IDs 0..cols*filas-1) y sus esquinas en pixeles del proyector."""
    lienzo = np.full((h, w), 255, np.uint8)
    lado = int(min(w / (cols * 1.8), h / (filas * 1.8)))
    margen = int(lado * 0.4)
    xs = np.linspace(margen, w - margen - lado, cols).astype(int)
    ys = np.linspace(margen, h - margen - lado, filas).astype(int)
    esquinas, i = {}, 0
    for y in ys:
        for x in xs:
            lienzo[y:y + lado, x:x + lado] = imagen_marcador(i, lado)
            a, b = x - 0.5, y - 0.5
            esquinas[i] = np.array([[a, b], [a + lado, b], [a + lado, b + lado], [a, b + lado]], np.float32)
            i += 1
    return cv2.cvtColor(lienzo, cv2.COLOR_GRAY2BGR), esquinas


def detectar_marcadores(gris, detectar, ids_validos):
    esq, ids, _ = detectar(gris)
    res = {}
    if ids is not None:
        for c, i in zip(esq, ids.flatten()):
            if int(i) in ids_validos:
                res[int(i)] = c.reshape(4, 2)
    return res


def detectar_promedio(cam, proy, img, detectar, ids_validos, asentar=1.0, n=12):
    proy.pausa(img, asentar)
    acum, frame, t_ref = {}, None, time.time()
    for _ in range(n):
        frame = cam.leer_nuevo(t_ref)
        t_ref = time.time()
        proy.mostrar(img, 1)
        gris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        for i, c in detectar_marcadores(gris, detectar, ids_validos).items():
            acum.setdefault(i, []).append(c)
    minimo = max(2, n // 3)
    return {i: np.mean(v, axis=0) for i, v in acum.items() if len(v) >= minimo}, frame


def homografia_cam_proy(vistos, esq_proy):
    ids = sorted(vistos)
    pc = np.concatenate([vistos[i] for i in ids]).astype(np.float32)
    pp = np.concatenate([esq_proy[i] for i in ids]).astype(np.float32)
    H, _ = cv2.findHomography(pc, pp, cv2.RANSAC, 4.0)
    if H is None:
        return None, 999.0
    rep = cv2.perspectiveTransform(pc.reshape(-1, 1, 2), H).reshape(-1, 2)
    return H, float(np.mean(np.linalg.norm(rep - pp, axis=1)))


def _aviso_proyector(proy, texto, color, seg, voz=None):
    img = proy.negro()
    poner_parrafo(img, texto, 60, proy.h // 2 - 80, proy.w - 120, 48, color)
    if voz:
        voz.decir(texto)
    proy.pausa(img, seg)


def calibrar(cfg, cam, proy, voz=None):
    det = crear_detector()
    ids_mesa = cfg["calibracion"]["marcadores_mesa"]
    archivo = ruta(cfg["calibracion"]["archivo"])
    for intento in range(1, 4):
        log("Calibracion, intento", intento)
        _aviso_proyector(proy, "Calibrando... no toque la mesa", AMARILLO, 1.5,
                         voz if intento == 1 else None)
        # 1) Marcadores impresos de la mesa (proyector en negro)
        mesa, frame = detectar_promedio(cam, proy, proy.negro(), det, set(ids_mesa), 1.0)
        faltan = [i for i in ids_mesa if i not in mesa]
        if faltan:
            cv2.imwrite(ruta("registros/calib_fallo_mesa.jpg"), frame)
            _aviso_proyector(proy, "No veo los marcadores de mesa: %s. Revise que esten visibles."
                             % ", ".join(map(str, faltan)), ROJO, 4, voz)
            continue
        # 2) Patron proyectado
        patron, esq_proy = patron_aruco(proy.w, proy.h)
        vistos, frame = detectar_promedio(cam, proy, patron, det, set(esq_proy), 1.5)
        log("Marcadores proyectados detectados:", len(vistos), "de", len(esq_proy))
        if len(vistos) < 6:
            cv2.imwrite(ruta("registros/calib_fallo_patron.jpg"), frame)
            _aviso_proyector(proy, "La camara no ve bien la proyeccion. Baje la luz del cuarto "
                             "o ajuste el enfoque del proyector.", ROJO, 4, voz)
            continue
        H, err = homografia_cam_proy(vistos, esq_proy)
        if H is None or err > 6:
            _aviso_proyector(proy, "Calibracion imprecisa (error %.1f px). Reintentando." % err, ROJO, 3)
            continue
        calib = {
            "fecha": time.strftime("%Y-%m-%d %H:%M:%S"),
            "H_cam2proj": H.tolist(),
            "centros_mesa_cam": {str(i): mesa[i].mean(axis=0).tolist() for i in ids_mesa},
            "error_px": err,
            "marcadores_vistos": len(vistos),
            "camara_px": [frame.shape[1], frame.shape[0]],
            "proyector_px": [proy.w, proy.h],
        }
        with open(archivo, "w", encoding="utf-8") as f:
            json.dump(calib, f, indent=2)
        log("Calibracion guardada. Error medio: %.2f px" % err)
        # 3) Verificacion visual: circulos sobre los marcadores impresos
        vis = proy.negro()
        for i in ids_mesa:
            c = np.array([[mesa[i].mean(axis=0)]], np.float32)
            p = cv2.perspectiveTransform(c, H)[0, 0]
            px, py = int(p[0]), int(p[1])
            cv2.circle(vis, (px, py), 45, VERDE, 4)
            cv2.line(vis, (px - 60, py), (px + 60, py), VERDE, 2)
            cv2.line(vis, (px, py - 60), (px, py + 60), VERDE, 2)
        poner_texto(vis, "Calibracion OK  (error %.1f px)" % err, proy.w // 2, proy.h // 2, 48, VERDE, True)
        if voz:
            voz.tono("ok")
            voz.decir("Calibracion completa")
        proy.pausa(vis, 3)
        return calib
    return None


def verificar_calibracion(cfg, cam, proy, calib):
    """True = sigue bien, False = la camara se movio, None = no se pudo comprobar."""
    det = crear_detector()
    ids_mesa = cfg["calibracion"]["marcadores_mesa"]
    if calib.get("proyector_px") != [proy.w, proy.h]:
        log("Cambio la resolucion del proyector")
        return False
    mesa, _ = detectar_promedio(cam, proy, proy.negro(), det, set(ids_mesa), 0.8, 8)
    if len(mesa) < len(ids_mesa):
        log("Verificacion: no se ven todos los marcadores de mesa (algo los tapa?)")
        return None
    tol = float(cfg["calibracion"].get("tolerancia_px", 6))
    peor = max(np.linalg.norm(mesa[i].mean(axis=0) - np.array(calib["centros_mesa_cam"][str(i)]))
               for i in ids_mesa)
    log("Verificacion: desplazamiento maximo %.1f px (tolerancia %.1f)" % (peor, tol))
    return peor <= tol


# ------------------------------------------------------------------ Geometria mesa <-> camara <-> proyector
class Geometria(object):
    """Todo en la receta se da en milimetros sobre la mesa.
    Origen (0,0) = centro del marcador 40 (izquierda, lado lejano);
    X hacia el marcador 41 (derecha); Y hacia el operario (marcador 43)."""

    def __init__(self, cfg, calib):
        m = cfg["mesa"]
        self.W, self.H = float(m["ancho_mm"]), float(m["alto_mm"])
        self.s = float(m.get("px_por_mm", 1.0))
        self.sd = float(m.get("deteccion_px_por_mm", 0.5))
        ids = cfg["calibracion"]["marcadores_mesa"]
        cam = np.array([calib["centros_mesa_cam"][str(i)] for i in ids], np.float32)
        mm = np.array([[0, 0], [self.W, 0], [self.W, self.H], [0, self.H]], np.float32)
        self.H_mm2cam = cv2.getPerspectiveTransform(mm, cam)
        H_cam2proj = np.array(calib["H_cam2proj"], np.float64)
        self.H_mm2proj = H_cam2proj.dot(self.H_mm2cam)
        self.H_lienzo2proj = self.H_mm2proj.dot(np.diag([1.0 / self.s, 1.0 / self.s, 1.0]))
        self.H_cam2det = np.diag([self.sd, self.sd, 1.0]).dot(np.linalg.inv(self.H_mm2cam))
        self.H_cam2mm = np.linalg.inv(self.H_mm2cam)
        self.H_cam2lienzo = np.diag([self.s, self.s, 1.0]).dot(self.H_cam2mm)
        self.tam_lienzo = (int(round(self.W * self.s)), int(round(self.H * self.s)))
        self.tam_det = (int(round(self.W * self.sd)), int(round(self.H * self.sd)))

    def lienzo(self):
        return np.zeros((self.tam_lienzo[1], self.tam_lienzo[0], 3), np.uint8)

    def a_proyector(self, lienzo, w, h):
        return cv2.warpPerspective(lienzo, self.H_lienzo2proj, (w, h))

    def vista_mesa(self, gris):
        return cv2.warpPerspective(gris, self.H_cam2det, self.tam_det)

    def px(self, v):
        return int(round(v * self.s))

    def rect(self, r):
        x, y, w, h = r
        return (self.px(x), self.px(y)), (self.px(x + w), self.px(y + h))

    def recorte(self, frame, rect_mm, margen_mm=6, esc=2.0):
        """Recorta un rectangulo de la mesa (en mm) desde la imagen de camara, ya enderezado."""
        x, y, w, h = rect_mm
        x, y, w, h = x + margen_mm, y + margen_mm, max(1, w - 2 * margen_mm), max(1, h - 2 * margen_mm)
        T = np.array([[1.0 / esc, 0, x], [0, 1.0 / esc, y], [0, 0, 1]])
        M = self.H_mm2cam.dot(T)  # pixel de salida -> pixel de camara
        return cv2.warpPerspective(frame, M, (max(1, int(w * esc)), max(1, int(h * esc))),
                                   flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP)


def cuadrar(img, tam=300):
    """Rellena a cuadrado (sin recortar) y escala. Asi Teachable Machine ve el instrumento completo."""
    h, w = img.shape[:2]
    lado = max(h, w)
    fondo = np.full((lado, lado, 3), 114, np.uint8)
    y0, x0 = (lado - h) // 2, (lado - w) // 2
    fondo[y0:y0 + h, x0:x0 + w] = img
    return cv2.resize(fondo, (tam, tam), interpolation=cv2.INTER_AREA)


def _norm(s):
    return sin_acentos(str(s)).strip().lower()


# ------------------------------------------------------------------ Guante (manos por color)
class Guante(object):
    """Detecta guantes (nitrilo azul, morado, etc.) por color. Se calibra con captura_charola.py --medir-guante."""

    def __init__(self, cfg):
        g = cfg.get("guante", {})
        self.hab = bool(g.get("habilitado", False))
        self.en_botones = g.get("usar_en_botones", True)
        self.en_pick = g.get("usar_en_pick", True)
        self.lo = np.array(g.get("hsv_min", [100, 80, 40]), np.uint8)
        self.hi = np.array(g.get("hsv_max", [130, 255, 255]), np.uint8)
        self.kernel = np.ones((3, 3), np.uint8)

    def mascara(self, img_bgr):
        if not self.hab:
            return None
        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
        if self.lo[0] <= self.hi[0]:
            m = cv2.inRange(hsv, self.lo, self.hi)
        else:  # tono que da la vuelta (rojos)
            m = cv2.inRange(hsv, self.lo, np.array([179, self.hi[1], self.hi[2]], np.uint8)) | \
                cv2.inRange(hsv, np.array([0, self.lo[1], self.lo[2]], np.uint8), self.hi)
        return cv2.morphologyEx(m, cv2.MORPH_OPEN, self.kernel)


# ------------------------------------------------------------------ Clasificador (modelo de Teachable Machine)
class Clasificador(object):
    """Carga el modelo exportado de Teachable Machine (TensorFlow Lite) desde la carpeta 'modelo/'.
    Corre en un hilo aparte para no congelar la proyeccion."""

    def __init__(self, cfg):
        c = cfg.get("clasificador", {})
        self.ok = False
        self.umbral = float(c.get("umbral", 0.8))
        self.vacio = c.get("clase_vacio", "Vacio")
        self.margen = c.get("margen_recorte_mm", 6)
        carpeta = ruta(c.get("carpeta", "modelo"))
        modelos = sorted(glob.glob(os.path.join(carpeta, "*.tflite")))
        if not modelos:
            log("Clasificador: no hay modelo .tflite en", carpeta)
            return
        Interprete = None
        for mod in ("tflite_runtime.interpreter", "ai_edge_litert.interpreter"):
            try:
                Interprete = __import__(mod, fromlist=["Interpreter"]).Interpreter
                break
            except ImportError:
                pass
        if Interprete is None:
            try:
                import tensorflow as tf
                Interprete = tf.lite.Interpreter
            except ImportError:
                log("Clasificador: instala tflite-runtime (ver GUIA_ENTRENAMIENTO.md)")
                return
        try:
            self.it = Interprete(model_path=modelos[0], num_threads=4)
        except TypeError:
            self.it = Interprete(model_path=modelos[0])
        self.it.allocate_tensors()
        self.inp = self.it.get_input_details()[0]
        self.out = self.it.get_output_details()[0]
        self.tam = (int(self.inp["shape"][2]), int(self.inp["shape"][1]))
        etiquetas = os.path.join(carpeta, "labels.txt")
        if os.path.exists(etiquetas):
            with open(etiquetas, encoding="utf-8") as f:
                self.etiquetas = [re.sub(r"^\d+\s+", "", l.strip()) for l in f if l.strip()]
        else:
            self.etiquetas = []
        self.lock = threading.Lock()
        self.hay_pedido = threading.Event()
        self.pedido, self.n, self.resultado = None, 0, (0, {})
        th = threading.Thread(target=self._loop)
        th.daemon = True
        th.start()
        self.ok = True
        log("Clasificador:", os.path.basename(modelos[0]), "clases:", ", ".join(self.etiquetas))

    def clasificar(self, img_bgr):
        x = cv2.cvtColor(cv2.resize(img_bgr, self.tam, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
        if self.inp["dtype"] == np.float32:
            x = x.astype(np.float32) / 127.5 - 1.0  # normalizacion de Teachable Machine
        else:
            x = x.astype(self.inp["dtype"])
        self.it.set_tensor(self.inp["index"], x[None])
        self.it.invoke()
        y = self.it.get_tensor(self.out["index"])[0].astype(np.float32)
        if self.out["dtype"] != np.float32:
            esc, cero = self.out.get("quantization", (0.0, 0))
            y = (y - cero) * esc if esc else y / 255.0
        if y.min() < 0 or abs(float(y.sum()) - 1.0) > 0.05:
            e = np.exp(y - y.max())
            y = e / e.sum()
        i = int(np.argmax(y))
        return (self.etiquetas[i] if i < len(self.etiquetas) else str(i)), float(y[i])

    def pedir(self, recortes):
        """Manda recortes {lugar: imagen}. Regresa el numero de pedido, o None si esta ocupado."""
        with self.lock:
            if self.pedido is not None:
                return None
            self.pedido = recortes
            self.hay_pedido.set()
            return self.n + 1

    def _loop(self):
        while True:
            self.hay_pedido.wait()
            with self.lock:
                pedido = self.pedido
            try:
                res = {k: self.clasificar(v) for k, v in pedido.items()}
            except Exception as e:
                log("Clasificador error:", e)
                res = {}
            with self.lock:
                self.n += 1
                self.resultado = (self.n, res)
                self.pedido = None
                self.hay_pedido.clear()


# ------------------------------------------------------------------ Deteccion por zonas
class Zona(object):
    """Detecta 'algo' (mano, pieza) dentro de un rectangulo de la mesa comparando contra un fondo.
    Los cambios que se quedan quietos 'absorber_s' segundos se vuelven el nuevo fondo."""

    def __init__(self, nombre, rect_mm, geo, cfg, reduccion=0.12):
        self.nombre = nombre
        x, y, w, h = rect_mm
        sd = geo.sd
        W, H = geo.tam_det
        self.x0 = min(max(0, int((x + w * reduccion) * sd)), W - 1)
        self.y0 = min(max(0, int((y + h * reduccion) * sd)), H - 1)
        self.x1 = min(max(self.x0 + 1, int((x + w * (1 - reduccion)) * sd)), W)
        self.y1 = min(max(self.y0 + 1, int((y + h * (1 - reduccion)) * sd)), H)
        d = cfg["deteccion"]
        self.umbral_dif = d.get("umbral_diferencia", 35)
        self.absorber_s = d.get("absorber_quieto_s", 3.0)
        self.ocupacion = 0.0
        self.reiniciar()

    def reiniciar(self, cuadros=8):
        self.ref, self.prev, self.t_quieto = None, None, None
        self.asentar = cuadros
        self.ocupacion = 0.0
        self.mov = 1.0

    def actualizar(self, vista, ahora, mascara=None):
        """mascara: si se da (p.ej. pixeles de guante), la ocupacion es la fraccion de esa mascara."""
        roi = vista[self.y0:self.y1, self.x0:self.x1]
        if self.ref is None:
            if self.asentar > 0:
                self.asentar -= 1
            else:
                self.ref = roi.astype(np.float32)
                self.prev = roi.copy()
            self.ocupacion = 0.0
            return 0.0
        mov = np.count_nonzero(cv2.absdiff(roi, self.prev) > self.umbral_dif) / float(roi.size)
        self.mov = mov
        self.prev = roi.copy()
        if mascara is not None:
            m = mascara[self.y0:self.y1, self.x0:self.x1]
            self.ocupacion = np.count_nonzero(m) / float(m.size)
            return self.ocupacion
        if mov < 0.01:
            if self.t_quieto is None:
                self.t_quieto = ahora
            elif ahora - self.t_quieto >= self.absorber_s:
                self.ref = roi.astype(np.float32)
                self.t_quieto = None
        else:
            self.t_quieto = None
        dif = cv2.absdiff(roi, cv2.convertScaleAbs(self.ref))
        self.ocupacion = np.count_nonzero(dif > self.umbral_dif) / float(dif.size)
        if self.ocupacion < 0.03:
            cv2.accumulateWeighted(roi, self.ref, 0.05)
        return self.ocupacion


class Retencion(object):
    """Dispara una vez cuando la ocupacion se mantiene arriba del umbral 'seg' segundos."""

    def __init__(self, seg, umbral):
        self.seg, self.umbral = seg, umbral
        self.reiniciar()

    def reiniciar(self):
        self.t_ini, self.armado = None, True

    def actualizar(self, ocup, ahora):
        if ocup >= self.umbral:
            if self.t_ini is None:
                self.t_ini = ahora
            if self.armado and ahora - self.t_ini >= self.seg:
                self.armado = False
                return True
        else:
            self.t_ini, self.armado = None, True
        return False

    def progreso(self, ahora):
        if self.t_ini is None or not self.armado:
            return 0.0
        return min(1.0, (ahora - self.t_ini) / self.seg)


# ------------------------------------------------------------------ Voz (hablar)
def generar_tono(path, freqs, dur=0.12, sr=22050):
    partes = []
    for f in freqs:
        t = np.arange(int(sr * dur)) / float(sr)
        env = np.clip(np.minimum(t / 0.01, (dur - t) / 0.03), 0, 1)
        partes.append(0.5 * np.sin(2 * np.pi * f * t) * env)
    datos = (np.concatenate(partes) * 32767).astype(np.int16)
    w = wave.open(path, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(sr)
    w.writeframes(datos.tobytes())
    w.close()


class Voz(object):
    def __init__(self, cfg):
        v = cfg.get("voz", {})
        self.hab = v.get("habilitada", True)
        self.cfg = v
        self.q = queue.Queue()
        self.hablando = threading.Event()
        self.aplay = shutil.which("aplay")
        self.piper = ruta(v["piper_bin"]) if v.get("piper_bin") else ""
        self.piper_modelo = ruta(v["piper_modelo"]) if v.get("piper_modelo") else ""
        pref = v.get("motor", "auto")
        self.motor = None
        if pref in ("auto", "piper") and self.piper and os.path.exists(self.piper) \
                and os.path.exists(self.piper_modelo):
            self.motor = "piper"
        elif shutil.which("espeak-ng"):
            self.motor = "espeak-ng"
        elif shutil.which("espeak"):
            self.motor = "espeak"
        log("Voz:", self.motor or "SIN MOTOR (solo texto)")
        d = ruta(cfg.get("registro_dir", "registros"))
        self.tonos = {"ok": os.path.join(d, "tono_ok.wav"),
                      "error": os.path.join(d, "tono_error.wav"),
                      "clic": os.path.join(d, "tono_clic.wav"),
                      "inicio": os.path.join(d, "tono_inicio.wav")}
        generar_tono(self.tonos["ok"], [880, 1320])
        generar_tono(self.tonos["error"], [300, 220], dur=0.25)
        generar_tono(self.tonos["clic"], [1500], dur=0.05)
        generar_tono(self.tonos["inicio"], [523, 659, 784, 1047, 1319], dur=0.11)
        th = threading.Thread(target=self._loop)
        th.daemon = True
        th.start()

    def decir(self, texto):
        if not self.hab or not texto:
            return
        pendientes = []
        while True:  # descarta frases viejas, conserva tonos
            try:
                it = self.q.get_nowait()
                if it[0] == "tono":
                    pendientes.append(it)
            except queue.Empty:
                break
        for it in pendientes:
            self.q.put(it)
        self.q.put(("voz", texto))

    def tono(self, nombre):
        if self.hab:
            self.q.put(("tono", nombre))

    def _loop(self):
        while True:
            tipo, x = self.q.get()
            self.hablando.set()
            try:
                if tipo == "tono" and self.aplay:
                    subprocess.call([self.aplay, "-q", self.tonos[x]])
                elif tipo == "voz":
                    log("VOZ:", x)
                    self._hablar(x)
            except Exception as e:
                log("Error de audio:", e)
            finally:
                time.sleep(0.25)
                if self.q.empty():
                    self.hablando.clear()

    def _hablar(self, t):
        if self.motor == "piper" and self.aplay:
            sr = str(self.cfg.get("piper_frecuencia", 22050))
            p1 = subprocess.Popen([self.piper, "--model", self.piper_modelo, "--output_raw"],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.DEVNULL)
            p2 = subprocess.Popen([self.aplay, "-q", "-r", sr, "-f", "S16_LE", "-t", "raw", "-c", "1", "-"],
                                  stdin=p1.stdout)
            p1.stdin.write(t.encode("utf-8"))
            p1.stdin.close()
            p1.stdout.close()
            p2.wait()
            p1.wait()
        elif self.motor in ("espeak-ng", "espeak"):
            subprocess.call([self.motor, "-v", self.cfg.get("espeak_voz", "es-419"),
                             "-s", str(self.cfg.get("velocidad", 150)), t],
                            stderr=subprocess.DEVNULL)


# ------------------------------------------------------------------ Comandos de voz (Vosk, sin internet)
PALABRAS = {"iniciar": "iniciar", "inicio": "iniciar", "empezar": "iniciar", "comenzar": "iniciar",
            "siguiente": "siguiente", "listo": "siguiente",
            "repetir": "repetir", "repite": "repetir",
            "ayuda": "ayuda", "cancelar": "cancelar",
            # cambio de modo (lo usa panel.py)
            "menú": "menu", "menu": "menu", "asesor": "modo:asesor", "calibración": "modo:calibracion",
            "patrones": "modo:patrones", "zonas": "modo:zonas", "guante": "modo:guante",
            "clasificador": "modo:clasificador", "captura": "modo:captura", "gestos": "modo:gestos",
            "esqueleto": "modo:esqueleto", "dedos": "modo:dedos", "partículas": "modo:particulas",
            "pizarra": "modo:pizarra", "reactivo": "modo:reactivo", "objetos": "modo:objetos"}


class Oido(object):
    def __init__(self, cfg, voz, eventos):
        c = cfg.get("comandos_voz", {})
        self.voz, self.eventos, self.cfg = voz, eventos, c
        if not c.get("habilitados", False):
            log("Comandos de voz: desactivados en config")
            return
        try:
            import vosk  # noqa: F401
        except ImportError:
            log("Comandos de voz: Vosk no esta instalado (python3 -m pip install --user vosk)")
            return
        self.modelo = ruta(c.get("modelo_vosk", ""))
        if not os.path.isdir(self.modelo):
            log("Comandos de voz: no encuentro el modelo en", self.modelo)
            return
        if not shutil.which("arecord"):
            log("Comandos de voz: falta arecord (sudo apt install alsa-utils)")
            return
        th = threading.Thread(target=self._loop)
        th.daemon = True
        th.start()

    def _loop(self):
        from vosk import Model, KaldiRecognizer, SetLogLevel
        SetLogLevel(-1)
        rec = KaldiRecognizer(Model(self.modelo), 16000, json.dumps(list(PALABRAS) + ["[unk]"]))
        cmd = ["arecord", "-q", "-D", self.cfg.get("dispositivo_mic", "default"),
               "-f", "S16_LE", "-r", "16000", "-c", "1", "-t", "raw"]
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        log("Comandos de voz: escuchando")
        while True:
            data = p.stdout.read(4000)
            if not data:
                log("Comandos de voz: el microfono dejo de enviar audio")
                return
            if self.voz.hablando.is_set():  # no escucharse a si mismo
                if hasattr(rec, "Reset"):
                    rec.Reset()
                continue
            if rec.AcceptWaveform(data):
                txt = json.loads(rec.Result()).get("text", "")
                for w in txt.split():
                    if w in PALABRAS:
                        log("Comando de voz:", w)
                        self.eventos.put(("cmd", PALABRAS[w]))
                        break


# ------------------------------------------------------------------ Torque (TCP y/o serial)
class EntradaTorque(object):
    """Acepta lineas de texto con un numero, p.ej. '18.5' o 'TORQUE=18.5 Nm'."""

    def __init__(self, cfg, eventos):
        self.eventos = eventos
        t = cfg.get("torque", {})
        if t.get("tcp_puerto"):
            self._hilo(self._tcp, int(t["tcp_puerto"]))
        if t.get("serial_puerto"):
            self._hilo(self._serial, t["serial_puerto"], int(t.get("serial_baudios", 9600)))

    def _hilo(self, fn, *a):
        th = threading.Thread(target=fn, args=a)
        th.daemon = True
        th.start()

    def _parse(self, linea):
        m = re.search(r"[-+]?\d+(?:[.,]\d+)?", linea)
        if m:
            v = float(m.group().replace(",", "."))
            log("Torque recibido:", v)
            self.eventos.put(("torque", v))

    def _tcp(self, puerto):
        try:
            srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(("0.0.0.0", puerto))
            srv.listen(4)
            log("Torque: escuchando TCP en puerto", puerto)
        except Exception as e:
            log("Torque TCP no disponible:", e)
            return
        while True:
            conn, _ = srv.accept()
            self._hilo(self._cliente, conn)

    def _cliente(self, conn):
        try:
            with conn, conn.makefile("r", encoding="utf-8", errors="ignore") as f:
                for linea in f:
                    self._parse(linea)
        except Exception as e:
            log("Torque TCP:", e)

    def _serial(self, puerto, baudios):
        try:
            import serial
        except ImportError:
            log("Torque serial: falta pyserial (sudo apt install python3-serial)")
            return
        while True:
            try:
                s = serial.Serial(puerto, baudios, timeout=1)
                log("Torque: leyendo serial", puerto)
                while True:
                    l = s.readline().decode("utf-8", "ignore").strip()
                    if l:
                        self._parse(l)
            except Exception as e:
                log("Torque serial:", e, "- reintento en 5 s")
                time.sleep(5)


# ------------------------------------------------------------------ Registro CSV
class Registro(object):
    def __init__(self, carpeta):
        self.path = os.path.join(carpeta, "ensambles.csv")
        if not os.path.exists(self.path):
            with open(self.path, "w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["ciclo", "fecha_hora", "paso", "nombre", "resultado", "segundos", "valor"])
        self.ciclo, self.t_ini = "", time.time()

    def nuevo_ciclo(self):
        self.ciclo = time.strftime("%Y%m%d-%H%M%S")
        self.t_ini = time.time()

    def paso(self, n, nombre, resultado, seg, valor=""):
        with open(self.path, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([self.ciclo, time.strftime("%Y-%m-%d %H:%M:%S"), n, nombre,
                                    resultado, "%.1f" % seg, valor])


# ------------------------------------------------------------------ Aplicacion principal (maquina de estados)
class Asesor(object):
    def __init__(self, cfg, args, cam=None, proy=None, voz=None, eventos=None, calib=None, servicios=True,
                 clasif=None, objetos=None):
        """cam/proy/voz/eventos/calib se pueden inyectar (lo usa panel.py). servicios=False no arranca
        microfono ni TCP de torque (el panel los arranca una sola vez)."""
        self.cfg, self.args = cfg, args
        self.dir_reg = ruta(cfg.get("registro_dir", "registros"))
        self.receta = cargar_json(ruta(cfg["receta"]))
        self.eventos = eventos if eventos is not None else queue.Queue()
        self.voz = voz or Voz(cfg)
        self.cam = cam or Camara(cfg)
        self.proy = proy or Proyector(cfg)
        self.reg = Registro(self.dir_reg)
        self.guante = Guante(cfg)
        self.clasif = clasif or Clasificador(cfg)
        self.objetos = objetos  # detector de objetos (vision.Objetos); se crea solo si una receta lo usa
        self.frame = None
        if servicios:
            Oido(cfg, self.voz, self.eventos)
            EntradaTorque(cfg, self.eventos)
        self.calib = calib if calib is not None else self._obtener_calibracion(getattr(args, "calibrar", False))
        if self.calib is None:
            _aviso_proyector(self.proy, "No se pudo calibrar. Revise marcadores y luz.", ROJO, 5, self.voz)
            raise SystemExit(2)
        self._preparar()
        self.ir_espera()

    # ---------- calibracion
    def _obtener_calibracion(self, forzar):
        archivo = ruta(self.cfg["calibracion"]["archivo"])
        if not forzar and os.path.exists(archivo):
            calib = cargar_json(archivo)
            ok = verificar_calibracion(self.cfg, self.cam, self.proy, calib)
            if ok is not False:
                return calib
            self.voz.decir("La camara se movio. Recalibrando")
        return calibrar(self.cfg, self.cam, self.proy, self.voz)

    def _preparar(self):
        self.geo = Geometria(self.cfg, self.calib)
        b = self.cfg["botones"]
        self.zonas = {n: Zona(n, r, self.geo, self.cfg) for n, r in self.receta["zonas"].items()}
        self.botones = {}
        for n, r in self.receta["botones"].items():
            self.botones[n] = {"rect": r, "zona": Zona(n, r, self.geo, self.cfg),
                               "ret": Retencion(b.get("tiempo_activacion_s", 1.5), b.get("umbral_ocupacion", 0.25))}
        self.area_texto = self.receta.get("area_texto", [20, 160, self.geo.W - 200, 90])
        self.lugares = {}
        for n, d in self.receta.get("lugares", {}).items():
            self.lugares[n] = {"rect": d["rect"], "instrumento": d.get("instrumento", ""),
                               "zona": Zona(n, d["rect"], self.geo, self.cfg)}

    # ---------- estados
    def _reiniciar_detectores(self, cuadros=8):
        for z in list(self.zonas.values()) + [d["zona"] for d in self.lugares.values()]:
            z.reiniciar(cuadros)
        for b in self.botones.values():
            b["zona"].reiniciar(cuadros)
            b["ret"].reiniciar()

    def ir_espera(self, hablar=True):
        self.estado, self.i, self.p, self.aviso = "ESPERA", -1, None, None
        self._reiniciar_detectores()
        if hablar:
            self.voz.decir(self.receta.get("voz_espera", "Sistema listo. Toque iniciar para comenzar"))

    def iniciar_ciclo(self):
        self.reg.nuevo_ciclo()
        self.estado = "PASO"
        log("=== Nuevo ciclo", self.reg.ciclo)
        self.ir_paso(0)

    def ir_paso(self, i):
        pasos = self.receta["pasos"]
        if i >= len(pasos):
            return self.fin()
        self.i, self.p = i, pasos[i]
        self.t_paso, self.t_avanzar, self.aviso = time.time(), None, None
        self.sub, self.ultimo_torque = {}, None
        self._reiniciar_detectores()
        log("Paso %d: %s" % (i + 1, self.p.get("nombre", self.p["tipo"])))
        self.voz.decir(self.p.get("voz", self.p.get("texto", "")))

    def _nombre_paso(self):
        return self.p.get("nombre", self.p.get("texto", self.p["tipo"]))

    def paso_ok(self, valor=""):
        if self.t_avanzar:
            return
        self.voz.tono("ok")
        self.aviso = ("ok", "Correcto", time.time() + 1.0)
        self.reg.paso(self.i + 1, self._nombre_paso(), "OK", time.time() - self.t_paso, valor)
        self.t_avanzar = time.time() + 1.0

    def paso_error(self, msg, valor=""):
        log("ERROR:", msg)
        self.voz.tono("error")
        self.voz.decir(msg)
        self.aviso = ("error", msg, time.time() + 3.5)
        self.reg.paso(self.i + 1, self._nombre_paso(), "ERROR: " + msg, time.time() - self.t_paso, valor)

    def fin(self):
        self.dur_total = time.time() - self.reg.t_ini
        self.estado, self.t_fin = "FIN", time.time() + 5
        self.reg.paso(0, "CICLO COMPLETO", "OK", self.dur_total)
        self.voz.tono("ok")
        self.voz.decir("Ensamble completo en %d segundos" % round(self.dur_total))

    def _botones_activos(self):
        if self.estado == "ESPERA":
            return ["iniciar"]
        if self.estado == "PASO":
            act = ["repetir"]
            if self.p["tipo"] == "confirmar":
                act.append("siguiente")
            return act
        return []

    # ---------- logica por cuadro
    def actualizar(self, vista, ahora, frame=None, mascara=None):
        self.frame = frame
        m_boton = mascara if self.guante.en_botones else None
        disparados = set()
        for n in self._botones_activos():
            b = self.botones.get(n)
            if b and b["ret"].actualizar(b["zona"].actualizar(vista, ahora, m_boton), ahora):
                log("Boton:", n)
                self.voz.tono("clic")
                disparados.add(n)
        torques = []
        while True:
            try:
                tipo, val = self.eventos.get_nowait()
            except queue.Empty:
                break
            if tipo == "cmd":
                disparados.add(val)
            elif tipo == "torque":
                torques.append(val)

        if "cancelar" in disparados and self.estado != "ESPERA":
            if self.estado == "PASO":
                self.reg.paso(self.i + 1, self._nombre_paso(), "CANCELADO", time.time() - self.t_paso)
            self.voz.decir("Ciclo cancelado")
            return self.ir_espera(hablar=False)
        if self.estado == "ESPERA":
            if "iniciar" in disparados:
                self.iniciar_ciclo()
            return
        if self.estado == "FIN":
            if ahora >= self.t_fin:
                self.ir_espera()
            return
        # ---- PASO
        if self.t_avanzar:
            if ahora >= self.t_avanzar:
                self.ir_paso(self.i + 1)
            return
        p = self.p
        if "repetir" in disparados:
            self.voz.decir(p.get("voz", p.get("texto", "")))
        if "ayuda" in disparados:
            self.voz.decir(p.get("ayuda", p.get("voz", p.get("texto", ""))))
        tipo = p["tipo"]
        if tipo == "confirmar":
            if "siguiente" in disparados:
                self.paso_ok()
        elif tipo == "presencia":
            oc = self.zonas[p["zona"]].actualizar(vista, ahora)
            if "ret" not in self.sub:
                self.sub["ret"] = Retencion(p.get("segundos", 1.5), p.get("umbral", 0.2))
            if self.sub["ret"].actualizar(oc, ahora):
                self.paso_ok("ocupacion %.0f%%" % (oc * 100))
        elif tipo == "pick":
            self._pick(vista, ahora, mascara if self.guante.en_pick else None)
        elif tipo == "charola":
            self._charola(vista, ahora, mascara)
        elif tipo in ("contar", "detectar"):
            self._contar(vista, ahora)
        elif tipo == "torque":
            lo, hi, u = p.get("min", 0), p.get("max", 1e9), p.get("unidad", "Nm")
            for v in torques:
                self.ultimo_torque = v
                if lo <= v <= hi:
                    self.paso_ok("%.2f %s" % (v, u))
                    break
                self.paso_error("Torque fuera de rango: %.1f %s. Repita el apriete." % (v, u), "%.2f" % v)
        elif tipo == "espera":
            if ahora - self.t_paso >= p.get("segundos", 3):
                self.paso_ok()

    def _pick(self, vista, ahora, mascara=None):
        p, s = self.p, self.sub
        correcta = p["zona"]
        umbral = p.get("umbral", 0.2)
        oc = self.zonas[correcta].actualizar(vista, ahora, mascara)
        if oc >= umbral:
            s.setdefault("t_in", ahora)
            if ahora - s["t_in"] >= p.get("segundos", 0.4):
                return self.paso_ok()
        else:
            s.pop("t_in", None)
        prefijo = p.get("prefijo_gavetas", "gaveta")
        for n, z in self.zonas.items():
            if n == correcta or not n.startswith(prefijo):
                continue
            k = "err_" + n
            if z.actualizar(vista, ahora, mascara) >= umbral:
                s.setdefault(k, ahora)
                if ahora - s[k] >= 0.4 and not s.get(k + "_av"):
                    s[k + "_av"] = True
                    self.paso_error("Gaveta equivocada. Tome de %s" % correcta.replace("_", " "))
            else:
                s.pop(k, None)
                s.pop(k + "_av", None)

    # ---------- conteo de objetos / instrumental con el detector (vision.py)
    def _detector(self):
        if self.objetos is None:
            import vision
            c = self.cfg.get("objetos", {})
            self.objetos = vision.Objetos(c.get("modelo", "general"), c.get("carpeta", "modelo_detector"),
                                          c.get("umbral", 0.5))
            if not self.objetos.ok:
                log("Objetos:", self.objetos.error)
        return self.objetos

    def _esperado(self):
        p = self.p
        return p.get("esperado") or {p.get("objeto", "?"): int(p.get("cantidad", 1))}

    def _contar(self, vista, ahora):
        p, s = self.p, self.sub
        det = self._detector()
        if not det.ok:
            if not s.get("sin_modelo"):
                s["sin_modelo"] = True
                self.paso_error("No hay detector de objetos. " + det.error)
            return
        prev, s["prev"] = s.get("prev"), vista
        if prev is not None and np.count_nonzero(cv2.absdiff(vista, prev) > 30) > 0.01 * vista.size:
            s["t_quieto"], s["aciertos"] = None, 0  # hay manos trabajando
            return
        if s.get("t_quieto") is None:
            s["t_quieto"] = ahora
        if ahora - s["t_quieto"] < p.get("segundos_quieto", 0.8) or ahora - s.get("t_ult", 0) < 0.4 \
                or self.frame is None:
            return
        s["t_ult"] = ahora
        dets = []
        zona = self.receta.get("zonas", {}).get(p.get("zona", ""))
        for d in det.detectar(self.frame):
            clase, conf, x1, y1, x2, y2 = d
            c_mm = cv2.perspectiveTransform(np.float32([[[(x1 + x2) / 2, (y1 + y2) / 2]]]), self.geo.H_cam2mm)[0, 0]
            if zona and not (zona[0] <= c_mm[0] <= zona[0] + zona[2] and zona[1] <= c_mm[1] <= zona[1] + zona[3]):
                continue
            esq = np.float32([[[x1, y1]], [[x2, y1]], [[x2, y2]], [[x1, y2]]])
            poly = cv2.perspectiveTransform(esq, self.geo.H_cam2lienzo).astype(np.int32)
            dets.append((clase, conf, poly))
        s["dets"] = dets
        cuenta = {}
        for d in dets:
            cuenta[_norm(d[0])] = cuenta.get(_norm(d[0]), 0) + 1
        esperado = self._esperado()
        faltan = [(k, v - cuenta.get(_norm(k), 0)) for k, v in esperado.items() if cuenta.get(_norm(k), 0) < v]
        sobran = [(k, cuenta.get(_norm(k), 0) - v) for k, v in esperado.items() if cuenta.get(_norm(k), 0) > v]
        if p.get("estricto"):
            conocidos = set(_norm(k) for k in esperado)
            sobran += [(d[0], 1) for d in dets if _norm(d[0]) not in conocidos]
        s["cuenta"] = cuenta
        if not faltan and not sobran:
            s["aciertos"] = s.get("aciertos", 0) + 1
            if s["aciertos"] >= p.get("confirmaciones", 3):
                self.paso_ok("conteo correcto")
            return
        s["aciertos"] = 0
        partes = []
        if faltan:
            partes.append("Falta%s: %s." % ("n" if len(faltan) > 1 or faltan[0][1] > 1 else "",
                                            ", ".join("%d %s" % (n, k) for k, n in faltan[:3])))
        if sobran:
            partes.append("Sobra%s: %s." % ("n" if len(sobran) > 1 or sobran[0][1] > 1 else "",
                                            ", ".join("%d %s" % (n, k) for k, n in sobran[:3])))
        firma = " ".join(partes)
        s["repet"] = s.get("repet", 0) + 1 if firma == s.get("firma_prev") else 0
        s["firma_prev"] = firma
        if s["repet"] == 2 and firma != s.get("firma_dicha"):
            s["firma_dicha"] = firma
            self.voz.decir(firma)
            self.reg.paso(self.i + 1, self._nombre_paso(), "REVISION: " + firma, time.time() - self.t_paso)

    def _dibujar_conteo(self, L, ok, x, y, ancho):
        g = self.geo
        esperado = {_norm(k): k for k in self._esperado()}
        for clase, conf, poly in self.sub.get("dets", []):
            col = VERDE if (ok or _norm(clase) in esperado) else GRIS
            cv2.polylines(L, [poly], True, col, max(2, g.px(3)))
            p0 = poly[:, 0, :].min(axis=0)
            poner_texto(L, "%s %d%%" % (clase, round(conf * 100)), int(p0[0]), int(p0[1]) - g.px(22), g.px(16), col)
        cuenta = self.sub.get("cuenta", {})
        lineas = []
        for k, v in self._esperado().items():
            n = cuenta.get(_norm(k), 0)
            lineas.append(("%s: %d de %d" % (k, n, v), VERDE if n == v else (AMARILLO if n < v else ROJO)))
        for i, (t, col) in enumerate(lineas[:6]):
            poner_texto(L, t, x, y + g.px(4 + 26 * i), g.px(22), col)

    # ---------- verificacion de charola con el modelo de Teachable Machine
    def _lugares_paso(self):
        return self.p.get("lugares") or list(self.lugares)

    def _charola(self, vista, ahora, mascara):
        p, s = self.p, self.sub
        if not self.clasif.ok:
            if not s.get("sin_modelo"):
                s["sin_modelo"] = True
                self.paso_error("No hay modelo cargado. Copie el modelo a la carpeta modelo.")
            return
        nombres = self._lugares_paso()
        quieto = True
        for n in nombres:
            z = self.lugares[n]["zona"]
            z.actualizar(vista, ahora)
            if z.mov > 0.02:
                quieto = False
            if mascara is not None:
                m = mascara[z.y0:z.y1, z.x0:z.x1]
                if np.count_nonzero(m) > 0.02 * m.size:
                    quieto = False
        if not quieto:  # hay manos trabajando: no se juzga
            s["t_quieto"], s["aciertos"] = None, 0
            return
        if s.get("t_quieto") is None:
            s["t_quieto"] = ahora
        if ahora - s["t_quieto"] < p.get("segundos_quieto", 0.6):
            return
        if s.get("pend") is None and self.frame is not None and ahora - s.get("t_ult", 0) >= 0.3:
            rec = {n: cuadrar(self.geo.recorte(self.frame, self.lugares[n]["rect"], self.clasif.margen))
                   for n in nombres}
            s["pend"] = self.clasif.pedir(rec)
        n_res, res = self.clasif.resultado
        if s.get("pend") is not None and n_res >= s["pend"]:
            s["pend"], s["t_ult"] = None, ahora
            self._evaluar_charola(res, nombres)

    def _evaluar_charola(self, res, nombres):
        p, s = self.p, self.sub
        umbral = p.get("umbral", self.clasif.umbral)
        estado = {}
        for n in nombres:
            esperado = self.lugares[n]["instrumento"]
            etq, conf = res.get(n, ("?", 0.0))
            if conf < umbral:
                est = "duda"
            elif _norm(etq) == _norm(esperado):
                est = "ok"
            elif _norm(etq) == _norm(self.clasif.vacio):
                est = "vacio"
            else:
                est = "mal"
            estado[n] = (est, etq, conf)
        s["estado"] = estado
        if all(e[0] == "ok" for e in estado.values()):
            s["aciertos"] = s.get("aciertos", 0) + 1
            if s["aciertos"] >= p.get("confirmaciones", 3):
                self.paso_ok("charola completa")
            return
        s["aciertos"] = 0
        firma = tuple(sorted((n, e[0], e[1]) for n, e in estado.items() if e[0] != "ok"))
        s["repet"] = s.get("repet", 0) + 1 if firma == s.get("firma_prev") else 0
        s["firma_prev"] = firma
        if s["repet"] == 2 and firma != s.get("firma_dicha"):  # mismo problema estable: avisar una vez
            s["firma_dicha"] = firma
            if any(e[0] == "mal" for e in estado.values()):
                self.voz.tono("error")
            self.voz.decir(self._resumen_charola(estado))
            self.reg.paso(self.i + 1, self._nombre_paso(), "REVISION: " + self._resumen_charola(estado),
                          time.time() - self.t_paso)

    def _resumen_charola(self, estado):
        faltan = [self.lugares[n]["instrumento"] for n, e in estado.items() if e[0] == "vacio"]
        mal = [(n, e[1], self.lugares[n]["instrumento"]) for n, e in estado.items() if e[0] == "mal"]
        dudas = [n for n, e in estado.items() if e[0] == "duda"]
        partes = []
        if faltan:
            partes.append("Falta%s: %s." % ("n" if len(faltan) > 1 else "", ", ".join(faltan[:3])))
        for n, hay, va in mal[:2]:
            partes.append("En %s hay %s, va %s." % (n, hay, va))
        if dudas:
            partes.append("Acomode bien %s." % ", ".join(dudas[:3]))
        return " ".join(partes)

    # ---------- dibujo
    def _boton(self, L, nombre, texto, color, ahora):
        b = self.botones.get(nombre)
        if not b:
            return
        g = self.geo
        (x0, y0), (x1, y1) = g.rect(b["rect"])
        cv2.rectangle(L, (x0, y0), (x1, y1), tuple(int(c * 0.35) for c in color), -1)
        cv2.rectangle(L, (x0, y0), (x1, y1), color, max(2, g.px(4)))
        tam = min(g.px(26), int((x1 - x0) * 0.9 / (len(texto) * 0.68)))
        poner_texto(L, texto, (x0 + x1) // 2, (y0 + y1) // 2, tam, BLANCO, True)
        prog = b["ret"].progreso(ahora)
        by0, by1 = y0 - g.px(20), y0 - g.px(8)
        if by0 < 0:
            by0, by1 = y1 + g.px(8), y1 + g.px(20)
        cv2.rectangle(L, (x0, by0), (x1, by1), GRIS, 1)
        if prog > 0:
            cv2.rectangle(L, (x0, by0), (x0 + int((x1 - x0) * prog), by1), color, -1)

    def _rect_zona(self, L, nombre, color, etiqueta):
        g = self.geo
        r = self.receta["zonas"][nombre]
        (x0, y0), (x1, y1) = g.rect(r)
        cv2.rectangle(L, (x0, y0), (x1, y1), color, max(2, g.px(6)))
        ty = y0 - g.px(34) if r[1] > 45 else y1 + g.px(6)
        poner_texto(L, etiqueta, x0, ty, g.px(26), color)

    def _marca(self, L, xy, color):
        g = self.geo
        c = (g.px(xy[0]), g.px(xy[1]))
        for r in (12, 26, 42):
            cv2.circle(L, c, g.px(r), color, max(2, g.px(3)))
        cv2.line(L, (c[0] - g.px(55), c[1]), (c[0] + g.px(55), c[1]), color, max(1, g.px(2)))
        cv2.line(L, (c[0], c[1] - g.px(55)), (c[0], c[1] + g.px(55)), color, max(1, g.px(2)))

    def dibujar(self, ahora):
        g = self.geo
        L = g.lienzo()
        ax, ay, aw, ah = self.area_texto
        x, y, ancho = g.px(ax), g.px(ay), g.px(aw)
        if self.estado == "ESPERA":
            poner_texto(L, self.receta.get("nombre", "Asesor de procesos"), x, y, g.px(24), GRIS)
            poner_parrafo(L, "Listo. Toque INICIAR o diga \u201ciniciar\u201d", x, y + g.px(34), ancho, g.px(34), BLANCO)
            self._boton(L, "iniciar", "INICIAR", VERDE, ahora)
        elif self.estado == "FIN":
            poner_parrafo(L, "Ensamble completo\nTiempo: %d s" % round(self.dur_total), x, y, ancho, g.px(40), VERDE)
        elif self.estado == "PASO":
            p = self.p
            ok = self.t_avanzar is not None
            poner_texto(L, "Paso %d de %d" % (self.i + 1, len(self.receta["pasos"])), x, y, g.px(22), GRIS)
            yf = poner_parrafo(L, p.get("texto", ""), x, y + g.px(28), ancho, g.px(28), BLANCO)
            if self.aviso and ahora < self.aviso[2]:
                col = VERDE if self.aviso[0] == "ok" else ROJO
                poner_parrafo(L, self.aviso[1], x, yf + g.px(4), ancho, g.px(30), col)
            if p.get("zona"):
                if p["tipo"] == "pick":
                    self._rect_zona(L, p["zona"], VERDE if ok else AMARILLO, "TOMAR AQU\u00cd")
                else:
                    self._rect_zona(L, p["zona"], VERDE if ok else CIAN, p.get("etiqueta", "COLOQUE AQU\u00cd"))
            if p.get("marca"):
                self._marca(L, p["marca"], VERDE if ok else AMARILLO)
                if p["tipo"] == "torque":
                    t = "%s-%s %s" % (p.get("min", "?"), p.get("max", "?"), p.get("unidad", "Nm"))
                    if self.ultimo_torque is not None:
                        t += "   \u00faltimo: %.1f" % self.ultimo_torque
                    poner_texto(L, t, g.px(p["marca"][0] + 60), g.px(p["marca"][1] - 15), g.px(24), AMARILLO)
            if p["tipo"] in ("contar", "detectar"):
                self._dibujar_conteo(L, ok, x, yf, ancho)
            if p["tipo"] == "charola":
                est = self.sub.get("estado", {})
                for n in self._lugares_paso():
                    d = self.lugares[n]
                    e = est.get(n)
                    if ok or (e and e[0] == "ok"):
                        col, txt = VERDE, d["instrumento"]
                    elif e is None:
                        col, txt = GRIS, d["instrumento"]
                    elif e[0] == "vacio":
                        col, txt = AMARILLO, "Falta: " + d["instrumento"]
                    elif e[0] == "mal":
                        col, txt = ROJO, "Va: " + d["instrumento"]
                    else:
                        col, txt = AMARILLO, "Acomode"
                    (x0, y0), (x1, y1) = g.rect(d["rect"])
                    cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
                    poner_texto(L, n, x0, y0 - g.px(20), g.px(16), GRIS)
                    poner_parrafo(L, txt, x0, y1 + g.px(4), x1 - x0, g.px(16), col)
            self._boton(L, "repetir", "REPETIR", AZUL, ahora)
            if p["tipo"] == "confirmar":
                self._boton(L, "siguiente", "SIGUIENTE", VERDE, ahora)
        return L

    def imagen_debug(self, vista, mascara=None):
        img = cv2.cvtColor(vista, cv2.COLOR_GRAY2BGR)
        if mascara is not None:
            img[mascara > 0] = (255, 0, 255)
        todas = list(self.zonas.values()) + [b["zona"] for b in self.botones.values()] + \
            [d["zona"] for d in self.lugares.values()]
        for z in todas:
            col = (0, 0, 255) if z.ocupacion > 0.2 else (0, 255, 0)
            cv2.rectangle(img, (z.x0, z.y0), (z.x1, z.y1), col, 1)
            cv2.putText(img, "%s %.0f%%" % (z.nombre, z.ocupacion * 100), (z.x0 + 2, z.y0 + 12),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.35, col, 1)
        return img

    def _debug(self, vista, mascara=None):
        cv2.imwrite(os.path.join(self.dir_reg, "debug_vista.jpg"), self.imagen_debug(vista, mascara))

    def procesar(self, frame, ahora):
        """Procesa un cuadro de camara. Regresa (vista_gris, mascara_guante)."""
        vista_col = self.geo.vista_mesa(frame)
        vista = cv2.GaussianBlur(cv2.cvtColor(vista_col, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        mascara = self.guante.mascara(vista_col)
        self.actualizar(vista, ahora, frame, mascara)
        return vista, mascara

    def imagen_proyector(self, ahora):
        return self.geo.a_proyector(self.dibujar(ahora), self.proy.w, self.proy.h)

    # ---------- bucle principal
    def correr(self):
        t_prev, t_debug, t_fps, cuadros = 0.0, 0.0, time.time(), 0
        while True:
            frame, t = self.cam.leer()
            ahora = time.time()
            if t != t_prev:
                t_prev = t
                vista, mascara = self.procesar(frame, ahora)
                if self.args.debug and ahora - t_debug > 1.0:
                    t_debug = ahora
                    self._debug(vista, mascara)
                cuadros += 1
            img = self.imagen_proyector(ahora)
            k = self.proy.mostrar(img, 1)
            if ahora - t_fps > 10:
                log("FPS procesamiento: %.1f" % (cuadros / (ahora - t_fps)))
                t_fps, cuadros = ahora, 0
            if k in (27, ord("q")):
                break
            if k == ord("c"):
                c = calibrar(self.cfg, self.cam, self.proy, self.voz)
                if c:
                    self.calib = c
                    self._preparar()
                self.ir_espera()
            elif k in (ord("i"), ord("n"), ord("r")):
                self.eventos.put(("cmd", {"i": "iniciar", "n": "siguiente", "r": "repetir"}[chr(k)]))
        self.cam.cerrar()
        cv2.destroyAllWindows()


# ------------------------------------------------------------------ Marcadores para imprimir
def imprimir_marcadores(cfg):
    ids = cfg["calibracion"]["marcadores_mesa"]
    nombres = ["izquierda-lejos", "derecha-lejos", "derecha-cerca (operario)", "izquierda-cerca (operario)"]
    W, H = 2480, 3508  # A4 a 300 dpi
    hoja = np.full((H, W), 255, np.uint8)
    lado = 945  # 8 cm
    pos = [(250, 350), (1285, 350), (1285, 1950), (250, 1950)]
    for (x, y), i, n in zip(pos, ids, nombres):
        hoja[y:y + lado, x:x + lado] = imagen_marcador(i, lado)
        cv2.putText(hoja, "ID %d" % i, (x, y + lado + 90), cv2.FONT_HERSHEY_SIMPLEX, 2.5, 0, 6)
        cv2.putText(hoja, n, (x, y + lado + 170), cv2.FONT_HERSHEY_SIMPLEX, 1.5, 0, 3)
    cv2.putText(hoja, "Recortar y pegar en las 4 esquinas de la mesa. Imprimir al 100%.",
                (150, 180), cv2.FONT_HERSHEY_SIMPLEX, 1.6, 0, 3)
    out = ruta("marcadores_mesa.png")
    cv2.imwrite(out, hoja)
    log("Generado:", out)


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description="Asesor de procesos con proyeccion")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--receta", default="", help="usar otra receta (p.ej. receta_charola.json)")
    ap.add_argument("--calibrar", action="store_true", help="forzar calibracion")
    ap.add_argument("--imprimir", action="store_true", help="generar marcadores_mesa.png")
    ap.add_argument("--debug", action="store_true", help="guardar registros/debug_vista.jpg")
    ap.add_argument("--pantalla", default=":0", help="DISPLAY del proyector ('' = usar el actual)")
    args = ap.parse_args()

    cfg = cargar_json(ruta(args.config))
    if args.receta:
        cfg["receta"] = args.receta
    os.makedirs(ruta(cfg.get("registro_dir", "registros")), exist_ok=True)
    if aruco is None:
        log("ERROR: tu OpenCV no trae el modulo ArUco. Corre instalar.sh o ve LEEME.md")
        sys.exit(1)
    if args.imprimir:
        imprimir_marcadores(cfg)
        return
    preparar_pantalla(args.pantalla)
    app = Asesor(cfg, args)
    app.correr()


if __name__ == "__main__":
    main()
