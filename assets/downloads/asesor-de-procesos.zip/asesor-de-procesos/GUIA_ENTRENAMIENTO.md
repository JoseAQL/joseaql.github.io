# Guía paso a paso: entrenar la charola con Teachable Machine

Al terminar esta guía, el asesor revisa solo una charola de instrumentos: proyecta un rectángulo por lugar, reconoce qué instrumento hay en cada uno y avisa en voz y con colores:

- **Verde**: correcto.
- **Rojo**: instrumento equivocado ("En L2 hay porta agujas, va pinza Kelly").
- **Amarillo**: falta el instrumento o está mal acomodado.

Mientras hay manos (o guantes) sobre la charola no juzga nada; revisa cuando se quitan. Con la charola completa y 3 revisiones seguidas correctas, pasa al siguiente paso.

```
Jetson: capturar fotos ──► PC: Teachable Machine (entrenar) ──► Jetson: copiar modelo y usar
```

---

## Paso 0. Antes de empezar
- El asesor ya debe estar instalado y **calibrado** (`python3 asesor.py --calibrar` terminó con círculos verdes).
- **Fija la charola a la mesa** con topes, escuadras o cinta. Si la charola se mueve, los lugares ya no coinciden con lo proyectado.
- Ten a la mano los instrumentos reales, y si puedes, **varias piezas de cada tipo**.

## Paso 1. Definir los lugares de la charola
Abre `receta_charola.json` y edita la sección `lugares`. Cada lugar tiene su rectángulo en milímetros, medido desde el centro del marcador 40 (X hacia la derecha, Y hacia el operario), y el instrumento que va ahí:

```json
"lugares": {
  "L1": {"rect": [60, 170, 90, 220], "instrumento": "Tijera Mayo"},
  "L2": {"rect": [170, 170, 90, 220], "instrumento": "Pinza Kelly"}
}
```
`rect` = `[x, y, ancho, alto]`. Deja unos 20 mm entre lugares.

**Para comprobar que los rectángulos caen bien sobre la charola**, corre:
```bash
cd ~/asesor
python3 captura_charola.py --receta receta_charola.json --clase Vacio --max 1
```
El proyector dibuja los lugares. Si no coinciden con la charola, corrige los números y repite.

## Paso 2 (opcional). Enseñarle el color del guante
Solo si los operarios usan guantes de color (nitrilo azul, morado, negro). Los guantes blancos o transparentes no sirven para esto.
```bash
python3 captura_charola.py --medir-guante
```
Pon la mano con guante dentro del círculo proyectado y déjala quieta unos segundos. El color se guarda solo en `config.json`. Si al final dice que "la mesa se parece al color del guante", no lo uses (cambia `guante.habilitado` a `false`).

Con esto, los botones y las gavetas reaccionan **solo a manos con guante** y la charola no se revisa mientras hay un guante encima.

## Paso 3. Tomar las fotos
Una sesión por clase. **El nombre de la clase debe ser igual al `instrumento` de la receta** (mayúsculas y acentos no importan).

**Primero la charola vacía** (es obligatoria, se llama `Vacio`):
```bash
python3 captura_charola.py --receta receta_charola.json --clase Vacio --max 80
```
Toma una foto de cada lugar cada 1.5 s. Entre fotos cambia un poco las condiciones: prende o apaga una luz del cuarto, mueve una sombra.

**Luego cada instrumento:**
```bash
python3 captura_charola.py --receta receta_charola.json --clase "Tijera Mayo" --max 120
```
1. Te pide dejar los lugares vacíos 4 segundos (para saber cómo se ven sin nada).
2. Pon el instrumento en **uno o varios lugares** a la vez. Así juntas fotos más rápido.
3. Quita las manos. Cuando todo está quieto suena un "clic" y guarda la foto de los lugares ocupados.
4. **Mueve, gira o cambia de lugar el instrumento** entre fotos. Si no cambió nada, no repite la foto.

Repite con cada instrumento: `"Pinza Kelly"`, `"Porta agujas"`, etc.

**Qué fotos juntar para que aprenda bien:**
| Haz esto | Por qué |
|---|---|
| 80 a 150 fotos por clase | Con menos, confunde instrumentos parecidos |
| Instrumento abierto y cerrado | Así va a llegar en la vida real |
| Un poco chueco o movido dentro del lugar | El operario no lo pone perfecto |
| Distintas piezas del mismo tipo | Que no aprenda una sola pieza |
| Con la luz real del cuarto | La luz cambia cómo se ve el metal |
| Instrumentos equivocados en cada lugar | Para que sepa distinguirlos en cualquier lugar |

Las fotos quedan en `~/asesor/dataset/<clase>/`.

## Paso 4. Pasar las fotos a tu computadora
En MobaXterm, en el panel SFTP de la izquierda, entra a `asesor`, clic derecho sobre la carpeta `dataset` y elige **Download**. Guárdala en tu PC.

## Paso 5. Entrenar en Teachable Machine
1. Entra a **teachablemachine.withgoogle.com** y da clic en **Comenzar** (Get Started).
2. Elige **Proyecto de imagen** → **Modelo de imagen estándar**.
3. **Crea una clase por carpeta** con el mismo nombre exacto: `Vacio`, `Tijera Mayo`, `Pinza Kelly`… Para renombrar, da clic en el lápiz junto a "Class 1". Usa **Agregar una clase** para más.
4. En cada clase, clic en **Subir** → elige las fotos de su carpeta (puedes seleccionarlas todas con Ctrl+A).
5. Da clic en **Entrenar modelo** y espera. No cierres la pestaña; tarda de 1 a 5 minutos.
6. **Pruébalo** en el panel de vista previa: cambia la entrada de "Webcam" a **Archivo** y sube algunas fotos que *no* usaste para entrenar. Debe acertar con más de 90 %.

Si confunde dos instrumentos, junta más fotos de esos dos y vuelve a entrenar. Si son casi iguales vistos desde arriba, considera juntarlos en una sola clase.

## Paso 6. Exportar el modelo
1. Clic en **Exportar modelo**.
2. Pestaña **Tensorflow Lite** → elige **Punto flotante** (Floating point).
3. **Descargar mi modelo**. Te baja un `.zip` con un archivo `.tflite` y `labels.txt`.

**Guarda también tu proyecto** (menú ☰ → Guardar proyecto en Drive o descargar), para poder agregar fotos y reentrenar después.

## Paso 7. Copiar el modelo a la Jetson
Descomprime el `.zip` en tu PC. Con el panel SFTP de MobaXterm, arrastra el `.tflite` y el `labels.txt` a `~/asesor/modelo/`.

Debe quedar así:
```
~/asesor/modelo/model_unquant.tflite   (el nombre puede variar)
~/asesor/modelo/labels.txt
```
Deja **un solo** `.tflite` en esa carpeta.

## Paso 8. Instalar el lector de modelos en la Jetson
`instalar.sh` ya lo intenta. Para comprobar:
```bash
python3 -c "import tflite_runtime; print('OK')"
```
Si dice OK, sigue al paso 9. Si da error:
```bash
python3 -m pip install --user tflite-runtime
```
**Plan B** (si pip no encuentra versión para tu Jetson): instala TensorFlow de NVIDIA para tu JetPack. Busca "Installing TensorFlow for Jetson Platform" en la documentación de NVIDIA y usa el comando de tu versión de JetPack (lo ves con `cat /etc/nv_tegra_release`). El asesor usa TensorFlow automáticamente si no encuentra `tflite_runtime`.

## Paso 9. Probar el modelo en vivo
```bash
python3 captura_charola.py --receta receta_charola.json --probar
```
Sobre cada lugar proyecta lo que reconoce y qué tan seguro está, por ejemplo "Pinza Kelly 97%":
- **Verde**: es lo que debe ir ahí.
- **Rojo**: es otro instrumento.
- **Amarillo**: duda (menos del 80 %).
- **Gris**: vacío.

En MobaXterm también ves los resultados cada segundo. Pon y quita instrumentos, intercámbialos y revisa que acierte.

## Paso 10. Usarlo en el asesor
Para correr el asesor con la receta de la charola:
```bash
python3 asesor.py --receta receta_charola.json
```
Para que arranque así siempre, en `config.json` cambia `"receta": "receta.json"` por `"receta": "receta_charola.json"`.

El paso de tipo `charola` en la receta acepta:
| Campo | Qué hace | Valor por defecto |
|---|---|---|
| `lugares` | Lista de lugares a revisar, p. ej. `["L1","L2"]` | todos |
| `umbral` | Seguridad mínima para aceptar (0 a 1) | 0.8 |
| `confirmaciones` | Revisiones correctas seguidas para dar por buena la charola | 3 |
| `segundos_quieto` | Tiempo sin movimiento antes de revisar | 0.6 |

Puedes combinarlo con los otros pasos (pick de gavetas, torque, confirmar) en la misma receta.

---

## Problemas comunes
| Problema | Solución |
|---|---|
| Confunde dos instrumentos | Más fotos de ambos, con variedad; reentrena. Si son casi idénticos desde arriba, júntalos en una clase |
| Dice "Acomode" muy seguido | El modelo duda: más fotos, o baja `umbral` a 0.7 en el paso |
| Funciona en la prueba pero falla de noche | Faltan fotos con esa luz; captura más con la iluminación de ese turno |
| Revisa mientras el operario todavía acomoda | Sube `segundos_quieto` a 1.0 o activa la detección de guante |
| Nunca revisa | Algo se mueve en la imagen (ventilador, sombra). Revisa con `python3 asesor.py --debug` y la imagen `registros/debug_vista.jpg` |
| Reflejos del metal | Luz difusa, sin focos directos sobre la charola; un filtro polarizador en la cámara ayuda mucho |
| Cambiaste de charola o de lugares | Repite desde el paso 3: las fotos deben tomarse con la charola final |
