#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
captura_charola.py - Herramientas para entrenar el modelo de la charola con Teachable Machine
===============================================================================================
Usa la misma calibracion, camara y proyector que asesor.py.

  python3 captura_charola.py --clase "Vacio"           -> fotos de los lugares vacios
  python3 captura_charola.py --clase "Tijera Mayo"     -> fotos de los lugares donde pongas tijeras
  python3 captura_charola.py --probar                  -> proyecta lo que el modelo reconoce en cada lugar
  python3 captura_charola.py --medir-guante            -> aprende el color del guante y lo guarda en config.json

Las fotos quedan en dataset/<clase>/ listas para subir a Teachable Machine.
Salir: Ctrl+C en MobaXterm (o tecla q en un teclado conectado a la Jetson).
"""
from __future__ import print_function

import argparse
import json
import os
import sys
import time

import numpy as np

import asesor as A

cv2 = A.cv2
log = A.log


def gris(img):
    return cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (5, 5), 0)


def frac_dif(a, b, umbral=30):
    return np.count_nonzero(cv2.absdiff(a, b) > umbral) / float(a.size)


class Estacion(object):
    def __init__(self, args):
        A.preparar_pantalla(args.pantalla)
        self.cfg = A.cargar_json(A.ruta(args.config))
        self.receta = A.cargar_json(A.ruta(args.receta or self.cfg["receta"]))
        os.makedirs(A.ruta(self.cfg.get("registro_dir", "registros")), exist_ok=True)
        archivo = A.ruta(self.cfg["calibracion"]["archivo"])
        if not os.path.exists(archivo):
            sys.exit("Primero calibra la estacion:  python3 asesor.py --calibrar")
        self.lugares = self.receta.get("lugares", {})
        if not self.lugares and not args.medir_guante:
            sys.exit("La receta no tiene 'lugares'. Usa --receta receta_charola.json o agregalos.")
        self.voz = A.Voz(self.cfg)
        self.cam = A.Camara(self.cfg)
        self.proy = A.Proyector(self.cfg)
        self.geo = A.Geometria(self.cfg, A.cargar_json(archivo))
        self.margen = self.cfg.get("clasificador", {}).get("margen_recorte_mm", 6)
        self.t_frame = 0.0

    def frame_nuevo(self):
        f = self.cam.leer_nuevo(self.t_frame)
        self.t_frame = time.time()
        return f

    def recortes(self, frame):
        return {n: A.cuadrar(self.geo.recorte(frame, d["rect"], self.margen)) for n, d in self.lugares.items()}

    def dibujar(self, textos, colores=None, etiquetas=None, extra=None):
        g = self.geo
        L = g.lienzo()
        for n, d in self.lugares.items():
            col = (colores or {}).get(n, A.GRIS)
            (x0, y0), (x1, y1) = g.rect(d["rect"])
            cv2.rectangle(L, (x0, y0), (x1, y1), col, max(2, g.px(3)))
            A.poner_texto(L, n, x0, y0 - g.px(20), g.px(16), A.GRIS)
            if etiquetas and n in etiquetas:
                A.poner_parrafo(L, etiquetas[n], x0, y1 + g.px(4), x1 - x0, g.px(16), col)
        y = g.px(15)
        for t, tam, col in textos:
            y = A.poner_parrafo(L, t, g.px(30), y, g.px(g.W - 250), g.px(tam), col)
        if extra:
            extra(L)
        return g.a_proyector(L, self.proy.w, self.proy.h)

    def mostrar(self, img, ms=10):
        k = self.proy.mostrar(img, ms)
        return k in (27, ord("q"))

    def cerrar(self):
        self.cam.cerrar()
        cv2.destroyAllWindows()


# ------------------------------------------------------------------ 1) Captura de fotos
def capturar(est, args):
    clase = args.clase.strip()
    carpeta = A.ruta(os.path.join(args.salida, clase))
    os.makedirs(carpeta, exist_ok=True)
    previas = len([f for f in os.listdir(carpeta) if f.lower().endswith(".jpg")])
    vacio = A._norm(clase) == A._norm(est.cfg.get("clasificador", {}).get("clase_vacio", "Vacio"))
    guante = A.Guante(est.cfg)
    nombre_arch = A.sin_acentos(clase).replace(" ", "_")

    ref = None
    if not vacio:
        est.voz.decir("Deje los lugares vacíos")
        t0 = time.time()
        while time.time() - t0 < 4:
            falta = 4 - int(time.time() - t0)
            if est.mostrar(est.dibujar([("Captura: " + clase, 24, A.GRIS),
                                        ("Deje los lugares VACÍOS...  %d" % falta, 32, A.AMARILLO)])):
                return
        ref = {k: gris(v) for k, v in est.recortes(est.frame_nuevo()).items()}
        est.voz.decir("Coloque %s en uno o varios lugares. Muévalo o gírelo entre cada foto" % clase)
    else:
        est.voz.decir("Capturando lugares vacíos. Cambie la luz o mueva la charola entre fotos")

    n, t_ult, prev, t_quieto = 0, 0.0, None, None
    ultimo_guardado = {}
    log("Capturando '%s' en %s (ya habia %d fotos). Ctrl+C para terminar." % (clase, carpeta, previas))
    while n < args.max:
        f = est.frame_nuevo()
        ahora = time.time()
        rec = est.recortes(f)
        g = {k: gris(v) for k, v in rec.items()}
        hay_mov = prev is not None and any(frac_dif(g[k], prev[k]) > 0.01 for k in g)
        prev = g
        hay_guante = guante.hab and any(
            np.count_nonzero(guante.mascara(v)) > 0.01 * v.shape[0] * v.shape[1] for v in rec.values())
        if hay_mov or hay_guante:
            t_quieto = None
        elif t_quieto is None:
            t_quieto = ahora
        quieto = t_quieto is not None and ahora - t_quieto >= 0.5

        ocupados = [k for k in rec if vacio or frac_dif(g[k], ref[k]) > args.umbral]
        colores = {k: (A.VERDE if k in ocupados else A.GRIS) for k in rec}
        if quieto and ocupados and ahora - t_ult >= args.cada:
            guardados = 0
            for k in ocupados:
                if not vacio and k in ultimo_guardado and frac_dif(g[k], ultimo_guardado[k]) < 0.02:
                    continue  # no cambio desde la ultima foto: no repetir
                cv2.imwrite(os.path.join(carpeta, "%s_%d_%s.jpg" % (nombre_arch, int(ahora * 1000), k)), rec[k])
                ultimo_guardado[k] = g[k]
                guardados += 1
            if guardados:
                n += guardados
                t_ult = ahora
                est.voz.tono("clic")
                log("  +%d  (total %d)" % (guardados, n + previas))

        estado = "QUIETO - tomando foto" if quieto else ("manos en la charola" if hay_guante else "esperando que se quede quieto")
        textos = [("Captura: %s" % clase, 24, A.GRIS),
                  ("Fotos: %d   (en carpeta: %d)" % (n, n + previas), 34, A.BLANCO),
                  (estado, 22, A.VERDE if quieto else A.AMARILLO),
                  ("Mueva o gire el instrumento entre cada foto", 20, A.GRIS)]
        if est.mostrar(est.dibujar(textos, colores)):
            break
    est.voz.decir("Listo, %d fotos de %s" % (n, clase))
    est.mostrar(est.dibujar([("Listo: %d fotos de %s" % (n, clase), 34, A.VERDE)]), 1500)
    log("Terminado: %d fotos nuevas, %d en total en %s" % (n, n + previas, carpeta))


# ------------------------------------------------------------------ 2) Probar el modelo
def probar(est, args):
    clasif = A.Clasificador(est.cfg)
    if not clasif.ok:
        sys.exit("No se pudo cargar el modelo. Revisa la carpeta 'modelo/' y la GUIA (paso 7-8).")
    est.voz.decir("Probando el modelo")
    t_log = 0.0
    while True:
        f = est.frame_nuevo()
        res = {k: clasif.clasificar(v) for k, v in est.recortes(f).items()}
        etiquetas, colores = {}, {}
        for k, (etq, conf) in res.items():
            esperado = est.lugares[k].get("instrumento", "")
            etiquetas[k] = "%s %d%%" % (etq, round(conf * 100))
            if conf < clasif.umbral:
                colores[k] = A.AMARILLO
            elif A._norm(etq) == A._norm(esperado):
                colores[k] = A.VERDE
            elif A._norm(etq) == A._norm(clasif.vacio):
                colores[k] = A.GRIS
            else:
                colores[k] = A.ROJO
        if time.time() - t_log > 1.0:
            t_log = time.time()
            log("  ".join("%s=%s" % (k, etiquetas[k]) for k in sorted(etiquetas)))
        textos = [("Prueba del modelo", 24, A.GRIS),
                  ("Verde = correcto   Rojo = otro instrumento   Amarillo = duda", 20, A.BLANCO)]
        if est.mostrar(est.dibujar(textos, colores, etiquetas)):
            break


# ------------------------------------------------------------------ 3) Medir color del guante
def medir_guante(est, args):
    g = est.geo
    cx, cy, r = g.W / 2.0, g.H / 2.0, 70.0

    def circulo(color):
        return lambda L: cv2.circle(L, (g.px(cx), g.px(cy)), g.px(r), color, max(2, g.px(4)))

    est.voz.decir("Ponga la mano con guante dentro del círculo y déjela quieta")
    t0 = time.time()
    while time.time() - t0 < 6:
        falta = 6 - int(time.time() - t0)
        if est.mostrar(est.dibujar([("Medir guante", 24, A.GRIS),
                                    ("Ponga la mano CON GUANTE dentro del círculo...  %d" % falta, 30, A.AMARILLO)],
                                   extra=circulo(A.AMARILLO))):
            return
    sd = g.sd
    Hd, Wd = g.tam_det[1], g.tam_det[0]
    yy, xx = np.mgrid[0:Hd, 0:Wd]
    dentro = (xx - cx * sd) ** 2 + (yy - cy * sd) ** 2 < (r * 0.7 * sd) ** 2
    fuera = (xx - cx * sd) ** 2 + (yy - cy * sd) ** 2 > (r * 1.6 * sd) ** 2
    muestras, fondo = [], []
    for _ in range(15):
        hsv = cv2.cvtColor(g.vista_mesa(est.frame_nuevo()), cv2.COLOR_BGR2HSV)
        muestras.append(hsv[dentro])
        fondo.append(hsv[fuera])
        est.mostrar(est.dibujar([("Midiendo...", 30, A.VERDE)], extra=circulo(A.VERDE)), 1)
    px = np.concatenate(muestras).astype(np.int32)
    Hh, S, V = px[:, 0], px[:, 1], px[:, 2]
    if np.median(S) < 50:
        est.voz.decir("El guante casi no tiene color. No se recomienda usar detección por color")
        log("AVISO: saturacion mediana %d. Guantes blancos/transparentes no sirven para esto." % np.median(S))
    rojo = np.mean((Hh < 12) | (Hh > 167)) > 0.5  # tonos rojizos dan la vuelta en 0/180
    if rojo:
        Hs = (Hh + 90) % 180
        lo_h, hi_h = (int(np.percentile(Hs, 3)) - 8 - 90) % 180, (int(np.percentile(Hs, 97)) + 8 - 90) % 180
    else:
        lo_h, hi_h = max(0, int(np.percentile(Hh, 3)) - 8), min(179, int(np.percentile(Hh, 97)) + 8)
    lo = [lo_h, max(0, int(np.percentile(S, 5)) - 30), max(0, int(np.percentile(V, 5)) - 50)]
    hi = [hi_h, 255, 255]
    cfg_g = est.cfg.get("guante", {})
    cfg_g.update({"habilitado": True, "hsv_min": lo, "hsv_max": hi})
    cfg_g.setdefault("usar_en_botones", True)
    cfg_g.setdefault("usar_en_pick", True)
    est.cfg["guante"] = cfg_g
    # Revisar falsos positivos en la mesa
    prueba = A.Guante(est.cfg)
    fondo_px = np.concatenate(fondo)[None, :, :].astype(np.uint8)
    lo_a, hi_a = prueba.lo, prueba.hi
    if lo_a[0] <= hi_a[0]:
        m = cv2.inRange(fondo_px, lo_a, hi_a)
    else:
        m = cv2.inRange(fondo_px, lo_a, np.array([179, 255, 255], np.uint8)) | \
            cv2.inRange(fondo_px, np.array([0, lo_a[1], lo_a[2]], np.uint8), hi_a)
    falso = np.count_nonzero(m) / float(m.size)
    with open(A.ruta(args.config), "w", encoding="utf-8") as f:
        json.dump(est.cfg, f, indent=2, ensure_ascii=False)
    log("Guante guardado en config.json: hsv_min=%s hsv_max=%s" % (lo, hi))
    log("Mesa detectada como guante por error: %.1f%%" % (falso * 100))
    if falso > 0.02:
        est.voz.decir("Cuidado: parte de la mesa se parece al color del guante")
        log("AVISO: la mesa u otros objetos tienen un color parecido al guante.")
    else:
        est.voz.decir("Color del guante guardado")
    est.mostrar(est.dibujar([("Guante guardado", 34, A.VERDE),
                             ("Mesa confundida: %.1f%%" % (falso * 100), 24, A.BLANCO)]), 2500)


def main():
    ap = argparse.ArgumentParser(description="Captura y prueba para Teachable Machine")
    ap.add_argument("--config", default="config.json")
    ap.add_argument("--receta", default="", help="receta con 'lugares' (p.ej. receta_charola.json)")
    ap.add_argument("--clase", default="", help="nombre de la clase a capturar (igual que en Teachable Machine)")
    ap.add_argument("--probar", action="store_true", help="probar el modelo en vivo")
    ap.add_argument("--medir-guante", dest="medir_guante", action="store_true")
    ap.add_argument("--salida", default="dataset")
    ap.add_argument("--cada", type=float, default=1.5, help="segundos minimos entre fotos")
    ap.add_argument("--max", type=int, default=150, help="fotos maximas en esta sesion")
    ap.add_argument("--umbral", type=float, default=0.04, help="que tanto debe cambiar un lugar para contarlo ocupado")
    ap.add_argument("--pantalla", default=":0")
    args = ap.parse_args()
    if not (args.clase or args.probar or args.medir_guante):
        ap.print_help()
        sys.exit(1)
    if A.aruco is None:
        sys.exit("Tu OpenCV no trae ArUco. Corre instalar.sh")
    est = Estacion(args)
    try:
        if args.medir_guante:
            medir_guante(est, args)
        elif args.probar:
            probar(est, args)
        else:
            capturar(est, args)
    except KeyboardInterrupt:
        log("Detenido por el usuario")
    finally:
        est.cerrar()


if __name__ == "__main__":
    main()
