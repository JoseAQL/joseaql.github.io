#!/bin/bash
# Arranca la estacion como una consola: pantalla de inicio -> menu proyectado -> modos.
# Tambien levanta el panel web (http://IP-de-la-jetson:8080). Se reinicia solo si se cae.
# Para usar el asesor clasico sin menu:  ./iniciar.sh --clasico
DIR="$(cd "$(dirname "$0")" && pwd)"
export DISPLAY=${DISPLAY:-:0}
xset s off 2>/dev/null; xset -dpms 2>/dev/null; xset s noblank 2>/dev/null   # que no se apague la pantalla
pgrep -x unclutter >/dev/null || (unclutter -idle 1 -root &)                 # esconde el mouse
cd "$DIR"
mkdir -p registros
PROGRAMA="panel.py"
if [ "$1" = "--clasico" ]; then PROGRAMA="asesor.py"; shift; fi
while true; do
  echo "--- inicio $(date) ($PROGRAMA)" >> registros/asesor.log
  python3 "$PROGRAMA" "$@" >> registros/asesor.log 2>&1
  codigo=$?
  [ $codigo -eq 0 ] && break          # salida normal (tecla q)
  echo "--- se cerro con codigo $codigo, reinicio en 3 s" >> registros/asesor.log
  sleep 3
done
