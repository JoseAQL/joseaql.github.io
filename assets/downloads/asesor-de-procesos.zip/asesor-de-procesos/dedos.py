#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dedos.py - Efecto "entre los dedos" como el video de TouchDesigner, con la webcam de tu PC.
Junta pulgar e indice de las dos manos para formar un cuadro; dentro de el se aplica un efecto.

  python3 -m pip install mediapipe opencv-python      (una vez, en tu PC)
  python3 dedos.py                     -> webcam 0
  python3 dedos.py --camara 1          -> otra camara
  python3 dedos.py --grabar            -> ademas guarda dedos.mp4

Teclas:  1-5 elegir efecto   E siguiente efecto   S mostrar/ocultar esqueleto
         F pantalla completa  Q o ESC salir
"""
import argparse
import time

import cv2

import manos as M


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--camara", type=int, default=0)
    ap.add_argument("--ancho", type=int, default=1280)
    ap.add_argument("--alto", type=int, default=720)
    ap.add_argument("--efecto", default="termico", choices=M.EFECTOS)
    ap.add_argument("--grabar", action="store_true")
    args = ap.parse_args()

    det = M.DetectorManos()
    if not det.ok:
        raise SystemExit(det.error)
    cap = cv2.VideoCapture(args.camara)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.ancho)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.alto)
    if not cap.isOpened():
        raise SystemExit("No se pudo abrir la camara %d" % args.camara)

    ventana = "Dedos"
    cv2.namedWindow(ventana, cv2.WINDOW_NORMAL)
    efecto = M.EFECTOS.index(args.efecto)
    esqueleto, completa, escritor = True, False, None
    t_prev, fps = time.time(), 0.0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        frame = cv2.flip(frame, 1)  # espejo, como en el video
        manos = det.detectar(frame)
        out, quad = M.componer(frame, manos, M.EFECTOS[efecto], esqueleto=esqueleto)
        ahora = time.time()
        fps = 0.9 * fps + 0.1 / max(1e-3, ahora - t_prev)
        t_prev = ahora
        estado = "Junta pulgar e indice de las dos manos" if quad is None else M.NOMBRES_EFECTOS[M.EFECTOS[efecto]]
        cv2.rectangle(out, (0, 0), (out.shape[1], 38), (0, 0, 0), -1)
        cv2.putText(out, "%s   |  manos: %d  |  %.0f fps  |  1-5 efecto  S esqueleto  F pantalla  Q salir"
                    % (estado, len(manos), fps), (12, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1,
                    cv2.LINE_AA)
        if args.grabar:
            if escritor is None:
                escritor = cv2.VideoWriter("dedos.mp4", cv2.VideoWriter_fourcc(*"mp4v"), 24,
                                           (out.shape[1], out.shape[0]))
            escritor.write(out)
        cv2.imshow(ventana, out)
        k = cv2.waitKey(1) & 0xFF
        if k in (27, ord("q")):
            break
        if ord("1") <= k <= ord("0") + len(M.EFECTOS):
            efecto = k - ord("1")
        elif k == ord("e"):
            efecto = (efecto + 1) % len(M.EFECTOS)
        elif k == ord("s"):
            esqueleto = not esqueleto
        elif k == ord("f"):
            completa = not completa
            cv2.setWindowProperty(ventana, cv2.WND_PROP_FULLSCREEN,
                                  cv2.WINDOW_FULLSCREEN if completa else cv2.WINDOW_NORMAL)
    cap.release()
    if escritor:
        escritor.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
