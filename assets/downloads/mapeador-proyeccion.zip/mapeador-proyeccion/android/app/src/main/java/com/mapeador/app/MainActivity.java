package com.mapeador.app;

import android.Manifest;
import android.app.Activity;
import android.app.Presentation;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Mapeador de proyección.
 * - El teléfono muestra el editor (la misma página web del Mapeador, en assets/web/index.html).
 * - Si hay una pantalla externa (HDMI en modo "Duplicar pantalla"), se abre una Presentation
 *   con la misma página en modo "#output": solo el lienzo, sin panel.
 * - Las dos páginas se comunican por este puente nativo (estado de figuras, comandos de sonido y nivel de audio).
 * - Las imágenes, videos y canciones que eliges se copian a la memoria de la app y se sirven en
 *   https://mapeador.local/media/... para que ambas pantallas las vean y se conserven al cerrar.
 */
public class MainActivity extends Activity {

    static final String HOST = "mapeador.local";
    static final String BASE = "https://" + HOST + "/";
    static final int REQ_PICK = 10;
    static final int REQ_MIC = 11;

    final Handler ui = new Handler(Looper.getMainLooper());
    WebView control;
    Proyector proyector;
    DisplayManager dm;
    PermissionRequest pendingWebPerm;
    String pendingKind = "", pendingTarget = "";

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true); // depurar con chrome://inspect
        }
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        control = makeWebView(this);
        control.addJavascriptInterface(new ControlBridge(), "Android");
        control.loadUrl(BASE + "app/index.html");
        setContentView(control);
        immersive(w);

        dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        dm.registerDisplayListener(displayListener, ui);
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersive(getWindow());
        checkDisplays();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive(getWindow());
    }

    @Override
    protected void onDestroy() {
        dm.unregisterDisplayListener(displayListener);
        if (proyector != null) {
            Proyector p = proyector;
            proyector = null;
            p.dismiss();
        }
        control.destroy();
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    static void immersive(Window w) {
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    // ---------------------------------------------------------------- pantalla HDMI

    final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int id) { checkDisplays(); }
        @Override public void onDisplayRemoved(int id) { checkDisplays(); }
        @Override public void onDisplayChanged(int id) { }
    };

    void checkDisplays() {
        Display[] ds = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        Display target = ds.length > 0 ? ds[0] : null;
        if (proyector != null && (target == null || proyector.getDisplay().getDisplayId() != target.getDisplayId())) {
            Proyector p = proyector;
            proyector = null;
            p.dismiss();
        }
        if (target != null && proyector == null) {
            Proyector p = new Proyector(this, target);
            p.setOnDismissListener(d -> {
                p.destroyWeb();
                if (proyector == null || proyector == p) {
                    proyector = null;
                    js(control, "window.onOutput&&onOutput(0,0)");
                }
            });
            try {
                p.show();
                proyector = p;
            } catch (WindowManager.InvalidDisplayException e) {
                toast("No se pudo abrir la pantalla externa.");
            }
        }
    }

    /** Ventana que se dibuja en la pantalla externa: solo el lienzo. */
    class Proyector extends Presentation {
        WebView web;

        Proyector(Context ctx, Display display) { super(ctx, display); }

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            web = makeWebView(getContext());
            web.addJavascriptInterface(new OutputBridge(), "Android");
            web.loadUrl(BASE + "app/index.html#output");
            setContentView(web);
            immersive(getWindow());
        }

        void destroyWeb() {
            if (web != null) { web.destroy(); web = null; }
        }
    }

    // ---------------------------------------------------------------- puentes JS

    /** Lo que llama la página del teléfono. */
    class ControlBridge {
        @JavascriptInterface public void send(String json) {
            ui.post(() -> { if (proyector != null) js(proyector.web, "window.applyState&&applyState(" + q(json) + ")"); });
        }
        @JavascriptInterface public void audio(String json) {
            ui.post(() -> { if (proyector != null) js(proyector.web, "window.audioCmd&&audioCmd(" + q(json) + ")"); });
        }
        @JavascriptInterface public void pick(String kind, String target) {
            ui.post(() -> pickFile(kind, target));
        }
    }

    /** Lo que llama la página del proyector. */
    class OutputBridge {
        @JavascriptInterface public void ready(int w, int h) {
            ui.post(() -> js(control, "window.onOutput&&onOutput(" + w + "," + h + ")"));
        }
        @JavascriptInterface public void frame(String json) {
            ui.post(() -> js(control, "window.audioFrame&&audioFrame(" + q(json) + ")"));
        }
    }

    static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    static void js(WebView w, String code) { if (w != null) w.evaluateJavascript(code, null); }

    void toast(String t) { Toast.makeText(this, t, Toast.LENGTH_LONG).show(); }

    // ---------------------------------------------------------------- WebView

    WebView makeWebView(Context ctx) {
        WebView w = new WebView(ctx);
        w.setBackgroundColor(Color.BLACK);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return serve(req);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return !HOST.equals(req.getUrl().getHost());
            }
        });
        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest req) {
                ui.post(() -> handleWebPermission(req));
            }
        });
        return w;
    }

    // ---------------------------------------------------------------- micrófono

    boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    void handleWebPermission(PermissionRequest req) {
        boolean audio = Arrays.asList(req.getResources()).contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE);
        if (!audio) { req.deny(); return; }
        if (hasMic()) {
            req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
        } else {
            if (pendingWebPerm != null) pendingWebPerm.deny();
            pendingWebPerm = req;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MIC && pendingWebPerm != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                pendingWebPerm.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                pendingWebPerm.deny();
            }
            pendingWebPerm = null;
        }
    }

    // ---------------------------------------------------------------- elegir archivos

    @SuppressWarnings("deprecation")
    void pickFile(String kind, String target) {
        pendingKind = kind;
        pendingTarget = target;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if ("media".equals(kind)) {
            i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        } else if ("song".equals(kind)) {
            i.setType("audio/*");
        } else {
            i.setType("image/*");
        }
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Exception e) {
            toast("No hay una app para elegir archivos.");
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final String kind = pendingKind, target = pendingTarget;
        new Thread(() -> {
            try {
                String mime = getContentResolver().getType(uri);
                if (mime == null) mime = "";
                String shown = displayName(uri);
                String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
                if (ext == null) {
                    int dot = shown.lastIndexOf('.');
                    ext = dot >= 0 ? shown.substring(dot + 1).toLowerCase(Locale.ROOT) : "bin";
                }
                String name = UUID.randomUUID().toString().substring(0, 12) + "." + ext;
                File out = new File(mediaDir(), name);
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream os = new FileOutputStream(out)) {
                    if (in == null) throw new IOException("sin datos");
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                }
                final String url = BASE + "media/" + name, m = mime;
                ui.post(() -> js(control, "window.onPicked&&onPicked(" + q(kind) + "," + q(target) + "," + q(url) + "," + q(shown) + "," + q(m) + ")"));
            } catch (Exception e) {
                ui.post(() -> toast("No se pudo copiar el archivo."));
            }
        }).start();
    }

    String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) { }
        return "archivo";
    }

    File mediaDir() {
        File d = new File(getFilesDir(), "media");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    // ---------------------------------------------------------------- servidor interno (https://mapeador.local/...)

    WebResourceResponse serve(WebResourceRequest req) {
        Uri u = req.getUrl();
        if (!HOST.equals(u.getHost())) return null;
        String path = u.getPath() == null ? "" : u.getPath();
        try {
            if (path.startsWith("/app/")) {
                String asset = "web/" + path.substring(5);
                return response(mimeOf(asset), 200, "OK", getAssets().open(asset), null);
            }
            if (path.startsWith("/media/")) {
                String name = path.substring(7);
                if (name.isEmpty() || name.contains("/") || name.contains("..")) return notFound();
                File f = new File(mediaDir(), name);
                if (!f.isFile()) return notFound();
                return fileResponse(f, req.getRequestHeaders());
            }
        } catch (IOException ignored) { }
        return notFound();
    }

    WebResourceResponse fileResponse(File f, Map<String, String> reqHeaders) throws IOException {
        long len = f.length();
        String mime = mimeOf(f.getName());
        String range = null;
        if (reqHeaders != null) {
            for (Map.Entry<String, String> e : reqHeaders.entrySet()) {
                if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
            }
        }
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        if (range != null && range.startsWith("bytes=")) {
            String[] p = range.substring(6).split(",")[0].split("-", -1);
            long start, end;
            try {
                if (p[0].trim().isEmpty()) {             // bytes=-500 (últimos 500)
                    long n = Long.parseLong(p[1].trim());
                    start = Math.max(0, len - n);
                    end = len - 1;
                } else {
                    start = Long.parseLong(p[0].trim());
                    end = (p.length > 1 && !p[1].trim().isEmpty()) ? Long.parseLong(p[1].trim()) : len - 1;
                }
            } catch (NumberFormatException e) {
                start = 0;
                end = len - 1;
            }
            end = Math.min(end, len - 1);
            if (start >= len || start > end) {
                h.put("Content-Range", "bytes */" + len);
                return response(mime, 416, "Range Not Satisfiable", new ByteArrayInputStream(new byte[0]), h);
            }
            FileInputStream in = new FileInputStream(f);
            long skip = start;
            while (skip > 0) {
                long k = in.skip(skip);
                if (k <= 0) break;
                skip -= k;
            }
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + len);
            h.put("Content-Length", String.valueOf(end - start + 1));
            return response(mime, 206, "Partial Content", new Limited(in, end - start + 1), h);
        }
        h.put("Content-Length", String.valueOf(len));
        return response(mime, 200, "OK", new FileInputStream(f), h);
    }

    static WebResourceResponse response(String mime, int code, String reason, InputStream in, Map<String, String> extra) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-cache");
        if (extra != null) h.putAll(extra);
        String enc = (mime.startsWith("text/") || mime.contains("javascript")) ? "utf-8" : null;
        return new WebResourceResponse(mime, enc, code, reason, h, in);
    }

    static WebResourceResponse notFound() {
        return response("text/plain", 404, "Not Found", new ByteArrayInputStream(new byte[0]), null);
    }

    static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        String ext = dot >= 0 ? name.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
        switch (ext) {
            case "html": return "text/html";
            case "js": return "application/javascript";
            case "css": return "text/css";
            case "svg": return "image/svg+xml";
            default:
                String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                return m != null ? m : "application/octet-stream";
        }
    }

    /** Corta un stream a cierta cantidad de bytes (para respuestas parciales de video). */
    static class Limited extends FilterInputStream {
        long left;

        Limited(InputStream in, long n) { super(in); left = n; }

        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int b = super.read();
            if (b >= 0) left--;
            return b;
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }

        @Override public long skip(long n) throws IOException {
            long k = super.skip(Math.min(n, left));
            left -= k;
            return k;
        }

        @Override public int available() throws IOException {
            return (int) Math.min(super.available(), left);
        }
    }
}
