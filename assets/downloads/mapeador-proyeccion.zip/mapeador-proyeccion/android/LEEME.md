# Mapeador (Android)

App para hacer projection mapping desde un teléfono Samsung conectado a un proyector por HDMI.

- **El teléfono** muestra el editor: figuras, esquinas, efectos, imágenes, video, sonido.
- **El proyector** muestra solo la luz. Mientras editas también ve las guías; con **Proyectar** se ocultan.
- Sin proyector conectado, el teléfono funciona solo (igual que la página web).

## Compilar

### Opción A: Android Studio
1. Abre esta carpeta con **File > Open**.
2. Espera a que termine "Gradle sync" (la primera vez descarga cosas, necesita internet).
3. Conecta el teléfono con depuración USB activada y dale **Run ▶**.
   O bien: **Build > Build APK(s)**. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B: GitHub (sin instalar nada)
El repositorio ya trae `.github/workflows/mapeador-apk.yml`, que compila el APK solo cada vez que cambia esta carpeta.
1. En la pestaña **Actions** corre "APK Mapeador" (se corre solo en cada push).
2. Al terminar, descarga el artefacto **Mapeador-apk** y pásalo al teléfono.

Al instalar, Android pedirá permitir "instalar apps de origen desconocido".

## Conectar al proyector (Samsung)
1. Usa un adaptador **USB-C a HDMI**. Solo los modelos con salida de video lo soportan
   (Galaxy S8 o más nuevo, Note, Z Fold, Tab S). La mayoría de los Galaxy A **no** tienen salida HDMI.
2. Al conectar, si se abre **Samsung DeX**, cámbialo a **Duplicar pantalla** (Screen mirroring):
   desde la notificación de DeX o en Ajustes > Dispositivos conectados > Samsung DeX.
3. Abre Mapeador. El panel dirá "Proyector conectado" y el teléfono mostrará un recuadro con la forma del proyector.

## Sonido
- **Canción**: suena por el teléfono o por el HDMI y las figuras con "Reacciona al sonido" laten.
- **Micrófono**: la primera vez pide permiso. Escucha la música del cuarto.

## Archivos
- `app/src/main/assets/web/index.html`: la página del Mapeador (la misma que la versión web).
  Si la modificas, vuelve a compilar.
- `MainActivity.java`: abre la pantalla externa, conecta las dos páginas, elige archivos y maneja el micrófono.
