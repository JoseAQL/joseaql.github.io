# Mapeador de proyección

Projection mapping casero para decoraciones (Halloween, cosplay, escenografía). Pones figuras sobre objetos reales,
arrastras sus 4 esquinas hasta que el patrón de cuadros cae justo encima del objeto, y luego proyectas efectos neón,
imágenes, video o visuales que reaccionan a la música.

Inspirado en los videos de projection mapping hechos desde un iPad. Esta versión funciona en cualquier navegador,
en una Raspberry Pi 4B y como app de Android con salida HDMI.

![Teléfono (control) y proyector](imagenes/telefono_y_proyector.png)

Demo animada: [imagenes/demo.mp4](imagenes/demo.mp4)

## Carpetas

| Carpeta | Qué es |
|---|---|
| [`web/Mapeador.html`](web/Mapeador.html) | La página completa. Doble clic para abrir, funciona sin internet (Chrome, Chromium en la Raspberry, Edge). |
| [`android/`](android/) | Proyecto de Android Studio. El teléfono es el control y el HDMI muestra solo la proyección. Ver [`android/LEEME.md`](android/LEEME.md). |
| `imagenes/` | Capturas y el video de demostración. |

## Funciones

- **Figuras:** círculo, rectángulo, triángulo, hexágono, estrella, corazón y **silueta de un PNG** con fondo transparente.
- **Deformación por 4 esquinas** (homografía) para que la figura caiga en perspectiva sobre el objeto. Ajuste fino con flechas.
- **Efectos:** cuadros para alinear, rejilla neón, borde neón, relleno que late, escaneo, pulso, barras de sonido, onda de sonido.
- **Imagen o video** recortado a la forma de la figura, con zoom y modo llenar/completa.
- **Reactivo al sonido:** con una canción o con el micrófono. Sensibilidad ajustable.
- El acomodo se guarda solo.

## Raspberry Pi 4B

```
chromium-browser --kiosk --start-fullscreen ~/Mapeador.html
```

Con teclado, **H** muestra y oculta el panel. Para el micrófono se necesita uno USB.

## App Android (Samsung + HDMI)

- Necesita un teléfono con salida de video por USB-C (Galaxy S8 o más nuevo, Note, Z Fold, Tab S).
- Si al conectar se abre Samsung DeX, cámbialo a **Duplicar pantalla**.
- El APK se compila solo en GitHub: pestaña **Actions** > "APK Mapeador" > artefacto **Mapeador-apk**.

## Versiones

| Versión | Cambios |
|---|---|
| v1 | Página web: círculos y rectángulos con 4 esquinas, patrón de cuadros, efectos neón, imagen o video. |
| v2 | Más figuras y silueta de PNG, la imagen se recorta a la figura, efectos reactivos al sonido (canción y micrófono). |
| v3 | App Android con salida HDMI (teléfono = control, proyector = salida), archivos guardados en la app. Arreglo: en el archivo sin internet no se ocultaban partes del panel. |
